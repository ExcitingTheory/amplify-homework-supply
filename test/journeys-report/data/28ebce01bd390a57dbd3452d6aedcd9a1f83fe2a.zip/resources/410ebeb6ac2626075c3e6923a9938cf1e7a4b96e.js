(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0kgqv9_._.js","static/chunks/node_modules_@mui_icons-material_esm_0~71c.z._.js"],
    source: "dynamic"
});
