(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/LazyCardMedia.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LazyCardMedia
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getResponsiveImageUrls$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getResponsiveImageUrls.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function LazyCardMedia(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "4d24c36048e5ea79e412c1e445af3b4f450538ab37080c231466099aa22d934c") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4d24c36048e5ea79e412c1e445af3b4f450538ab37080c231466099aa22d934c";
    }
    const { s3Key, identityId, fileId, level: t1, filter: t2, grade: t3 } = t0;
    t1 === undefined ? "protected" : t1;
    const filter = t2 === undefined ? null : t2;
    t3 === undefined ? null : t3;
    const [url, setUrl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [srcSet, setSrcSet] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [sizes, setSizes] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [loaded, setLoaded] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [isVisible, setIsVisible] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const containerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    let t4;
    let t5;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "LazyCardMedia[useEffect()]": ()=>{
                const el = containerRef.current;
                if (!el) {
                    return;
                }
                const observer = new IntersectionObserver((t6)=>{
                    const [entry] = t6;
                    if (entry.isIntersecting) {
                        setIsVisible(true);
                        observer.disconnect();
                    }
                }, {
                    rootMargin: "200px"
                });
                observer.observe(el);
                return ()=>observer.disconnect();
            }
        })["LazyCardMedia[useEffect()]"];
        t5 = [];
        $[1] = t4;
        $[2] = t5;
    } else {
        t4 = $[1];
        t5 = $[2];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t4, t5);
    let t6;
    let t7;
    if ($[3] !== fileId || $[4] !== identityId || $[5] !== isVisible || $[6] !== s3Key) {
        t6 = ({
            "LazyCardMedia[useEffect()]": ()=>{
                if (!isVisible || !s3Key) {
                    return;
                }
                setLoaded(false);
                let cancelled = false;
                const fetchUrl = {
                    "LazyCardMedia[useEffect() > fetchUrl]": async ()=>{
                        const _url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(s3Key);
                        if (!cancelled) {
                            setUrl(_url);
                        }
                    }
                }["LazyCardMedia[useEffect() > fetchUrl]"];
                fetchUrl();
                if (fileId && identityId) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getResponsiveImageUrls$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getResponsiveImageUrls"])(fileId, identityId).then({
                        "LazyCardMedia[useEffect() > (anonymous)()]": (result)=>{
                            if (!cancelled && result) {
                                setSrcSet(result.srcSet);
                                setSizes(result.sizes);
                            }
                        }
                    }["LazyCardMedia[useEffect() > (anonymous)()]"]).catch(_LazyCardMediaUseEffectAnonymous);
                }
                return ()=>{
                    cancelled = true;
                };
            }
        })["LazyCardMedia[useEffect()]"];
        t7 = [
            isVisible,
            s3Key,
            fileId,
            identityId
        ];
        $[3] = fileId;
        $[4] = identityId;
        $[5] = isVisible;
        $[6] = s3Key;
        $[7] = t6;
        $[8] = t7;
    } else {
        t6 = $[7];
        t7 = $[8];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t6, t7);
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            position: "relative",
            width: 400,
            alignSelf: "left",
            flexShrink: 0
        };
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    let t9;
    if ($[10] !== filter || $[11] !== isVisible || $[12] !== loaded || $[13] !== sizes || $[14] !== srcSet || $[15] !== url) {
        t9 = isVisible && url ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            src: url,
            srcSet: srcSet || undefined,
            sizes: sizes || undefined,
            loading: "lazy",
            decoding: "async",
            style: {
                width: "100%",
                height: "100%",
                objectFit: "cover",
                display: "block",
                visibility: loaded ? "visible" : "hidden",
                filter: filter || undefined
            },
            onLoad: {
                "LazyCardMedia[<img>.onLoad]": ()=>setLoaded(true)
            }["LazyCardMedia[<img>.onLoad]"]
        }, void 0, false, {
            fileName: "[project]/src/components/LazyCardMedia.jsx",
            lineNumber: 130,
            columnNumber: 29
        }, this) : null;
        $[10] = filter;
        $[11] = isVisible;
        $[12] = loaded;
        $[13] = sizes;
        $[14] = srcSet;
        $[15] = url;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    let t10;
    if ($[17] !== loaded) {
        t10 = !loaded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "rectangular",
            animation: "wave",
            sx: {
                position: "absolute",
                inset: 0,
                width: "100%",
                height: "100%"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/LazyCardMedia.jsx",
            lineNumber: 152,
            columnNumber: 22
        }, this);
        $[17] = loaded;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    let t11;
    if ($[19] !== t10 || $[20] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ref: containerRef,
            sx: t8,
            children: [
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/LazyCardMedia.jsx",
            lineNumber: 165,
            columnNumber: 11
        }, this);
        $[19] = t10;
        $[20] = t9;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    return t11;
}
_s(LazyCardMedia, "fttu1d96oMR5teXgml+F/YsIypE=");
_c = LazyCardMedia;
function _LazyCardMediaUseEffectAnonymous() {}
var _c;
__turbopack_context__.k.register(_c, "LazyCardMedia");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/CommunityUnitCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommunityUnitCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript) <export default as CardContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ContentCopy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ContentCopy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LazyCardMedia.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function CommunityUnitCard(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(51);
    if ($[0] !== "7f222dc5bf394cebc9afb6da54a283d89f876b6185c532ab8bf6acf4d2fc8196") {
        for(let $i = 0; $i < 51; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7f222dc5bf394cebc9afb6da54a283d89f876b6185c532ab8bf6acf4d2fc8196";
    }
    const { unit, onFork, forking: t1 } = t0;
    const forking = t1 === undefined ? false : t1;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            display: "flex",
            margin: "1rem auto",
            width: "90vw",
            maxWidth: "80rem",
            height: 180,
            borderRadius: 2,
            borderLeft: "4px solid",
            borderLeftColor: "info.main",
            transition: "all 0.3s ease-in-out",
            overflow: "hidden",
            "&:hover": {
                transform: "translateY(-2px)",
                boxShadow: "0 8px 24px rgba(0,0,0,0.12)"
            }
        };
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    let t3;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            display: "flex",
            flexDirection: "column",
            flexGrow: 1,
            p: 0.5
        };
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    let t4;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            flex: "1 0 auto",
            pb: 1
        };
        $[3] = t4;
    } else {
        t4 = $[3];
    }
    let t5;
    if ($[4] !== t || $[5] !== unit.name) {
        t5 = unit.name || t("communityUnitCard.untitledUnit");
        $[4] = t;
        $[5] = unit.name;
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h6",
            component: "div",
            noWrap: true,
            children: t5
        }, void 0, false, {
            fileName: "[project]/src/components/CommunityUnitCard.tsx",
            lineNumber: 98,
            columnNumber: 10
        }, this);
        $[7] = t5;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            overflow: "hidden",
            textOverflow: "ellipsis",
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical"
        };
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] !== t || $[11] !== unit.description) {
        t8 = unit.description || t("communityUnitCard.noDescription");
        $[10] = t;
        $[11] = unit.description;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            sx: t7,
            children: t8
        }, void 0, false, {
            fileName: "[project]/src/components/CommunityUnitCard.tsx",
            lineNumber: 128,
            columnNumber: 10
        }, this);
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            display: "flex",
            alignItems: "center",
            gap: 1,
            mt: 1
        };
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    const t11 = unit.owner || "Unknown";
    let t12;
    if ($[16] !== t || $[17] !== t11) {
        t12 = t("communityUnitCard.byAuthor", {
            author: t11
        });
        $[16] = t;
        $[17] = t11;
        $[18] = t12;
    } else {
        t12 = $[18];
    }
    let t13;
    if ($[19] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            label: t12,
            size: "small",
            variant: "outlined"
        }, void 0, false, {
            fileName: "[project]/src/components/CommunityUnitCard.tsx",
            lineNumber: 160,
            columnNumber: 11
        }, this);
        $[19] = t12;
        $[20] = t13;
    } else {
        t13 = $[20];
    }
    let t14;
    if ($[21] !== unit.publishedAt) {
        t14 = unit.publishedAt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            children: [
                "Published ",
                new Date(unit.publishedAt).toLocaleDateString()
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/CommunityUnitCard.tsx",
            lineNumber: 168,
            columnNumber: 31
        }, this);
        $[21] = unit.publishedAt;
        $[22] = t14;
    } else {
        t14 = $[22];
    }
    let t15;
    if ($[23] !== t13 || $[24] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t10,
            children: [
                t13,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/CommunityUnitCard.tsx",
            lineNumber: 176,
            columnNumber: 11
        }, this);
        $[23] = t13;
        $[24] = t14;
        $[25] = t15;
    } else {
        t15 = $[25];
    }
    let t16;
    if ($[26] !== t15 || $[27] !== t6 || $[28] !== t9) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
            sx: t4,
            children: [
                t6,
                t9,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/CommunityUnitCard.tsx",
            lineNumber: 185,
            columnNumber: 11
        }, this);
        $[26] = t15;
        $[27] = t6;
        $[28] = t9;
        $[29] = t16;
    } else {
        t16 = $[29];
    }
    let t17;
    if ($[30] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = {
            display: "flex",
            alignItems: "center",
            pl: 2,
            pb: 1,
            gap: 1
        };
        $[30] = t17;
    } else {
        t17 = $[30];
    }
    let t18;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ContentCopy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/CommunityUnitCard.tsx",
            lineNumber: 208,
            columnNumber: 11
        }, this);
        $[31] = t18;
    } else {
        t18 = $[31];
    }
    let t19;
    if ($[32] !== onFork || $[33] !== unit.id) {
        t19 = ({
            "CommunityUnitCard[<Button>.onClick]": ()=>onFork(unit.id)
        })["CommunityUnitCard[<Button>.onClick]"];
        $[32] = onFork;
        $[33] = unit.id;
        $[34] = t19;
    } else {
        t19 = $[34];
    }
    let t20;
    if ($[35] !== forking || $[36] !== t) {
        t20 = forking ? t("communityUnitCard.forking") : t("communityUnitCard.fork");
        $[35] = forking;
        $[36] = t;
        $[37] = t20;
    } else {
        t20 = $[37];
    }
    let t21;
    if ($[38] !== forking || $[39] !== t19 || $[40] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t17,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                variant: "outlined",
                size: "small",
                startIcon: t18,
                onClick: t19,
                disabled: forking,
                children: t20
            }, void 0, false, {
                fileName: "[project]/src/components/CommunityUnitCard.tsx",
                lineNumber: 235,
                columnNumber: 25
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/CommunityUnitCard.tsx",
            lineNumber: 235,
            columnNumber: 11
        }, this);
        $[38] = forking;
        $[39] = t19;
        $[40] = t20;
        $[41] = t21;
    } else {
        t21 = $[41];
    }
    let t22;
    if ($[42] !== t16 || $[43] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t3,
            children: [
                t16,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/CommunityUnitCard.tsx",
            lineNumber: 245,
            columnNumber: 11
        }, this);
        $[42] = t16;
        $[43] = t21;
        $[44] = t22;
    } else {
        t22 = $[44];
    }
    let t23;
    if ($[45] !== unit.featuredImage || $[46] !== unit.identityId) {
        t23 = unit?.featuredImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            s3Key: unit.featuredImage,
            identityId: unit.identityId,
            fileId: null
        }, void 0, false, {
            fileName: "[project]/src/components/CommunityUnitCard.tsx",
            lineNumber: 254,
            columnNumber: 34
        }, this);
        $[45] = unit.featuredImage;
        $[46] = unit.identityId;
        $[47] = t23;
    } else {
        t23 = $[47];
    }
    let t24;
    if ($[48] !== t22 || $[49] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
            elevation: 2,
            sx: t2,
            children: [
                t22,
                t23
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/CommunityUnitCard.tsx",
            lineNumber: 263,
            columnNumber: 11
        }, this);
        $[48] = t22;
        $[49] = t23;
        $[50] = t24;
    } else {
        t24 = $[50];
    }
    return t24;
}
_s(CommunityUnitCard, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = CommunityUnitCard;
var _c;
__turbopack_context__.k.register(_c, "CommunityUnitCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/SharedUnitCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SharedUnitCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript) <export default as CardContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Edit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Visibility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Visibility.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LazyCardMedia.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function SharedUnitCard(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(62);
    if ($[0] !== "fc3c84c8c7d27204c431f77866663554a827ef133d92cabc078e460474f36940") {
        for(let $i = 0; $i < 62; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "fc3c84c8c7d27204c431f77866663554a827ef133d92cabc078e460474f36940";
    }
    const { unit, onOpen } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const canEdit = unit._collaboratorPermission === "EDIT";
    const t1 = canEdit ? "success.main" : "warning.main";
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            transform: "translateY(-2px)",
            boxShadow: "0 8px 24px rgba(0,0,0,0.12)"
        };
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    let t3;
    if ($[2] !== t1) {
        t3 = {
            display: "flex",
            margin: "1rem auto",
            width: "90vw",
            maxWidth: "80rem",
            height: 180,
            borderRadius: 2,
            borderLeft: "4px solid",
            borderLeftColor: t1,
            transition: "all 0.3s ease-in-out",
            overflow: "hidden",
            "&:hover": t2
        };
        $[2] = t1;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            display: "flex",
            flexDirection: "column",
            flexGrow: 1,
            p: 0.5
        };
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    let t5;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            flex: "1 0 auto",
            pb: 1
        };
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    let t6;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            display: "flex",
            alignItems: "center",
            gap: 1,
            mb: 0.5
        };
        $[6] = t6;
    } else {
        t6 = $[6];
    }
    let t7;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            flexGrow: 1
        };
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    let t8;
    if ($[8] !== t || $[9] !== unit.name) {
        t8 = unit.name || t("sharedUnitCard.untitledUnit");
        $[8] = t;
        $[9] = unit.name;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h6",
            component: "div",
            noWrap: true,
            sx: t7,
            children: t8
        }, void 0, false, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 127,
            columnNumber: 10
        }, this);
        $[11] = t8;
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    let t10;
    if ($[13] !== canEdit || $[14] !== t) {
        t10 = canEdit ? t("sharedUnitCard.editAccess") : t("sharedUnitCard.readOnly");
        $[13] = canEdit;
        $[14] = t;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    const t11 = canEdit ? "success" : "warning";
    let t12;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            height: 22,
            fontSize: "0.7rem"
        };
        $[16] = t12;
    } else {
        t12 = $[16];
    }
    let t13;
    if ($[17] !== t10 || $[18] !== t11) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            label: t10,
            size: "small",
            color: t11,
            variant: "filled",
            sx: t12
        }, void 0, false, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 155,
            columnNumber: 11
        }, this);
        $[17] = t10;
        $[18] = t11;
        $[19] = t13;
    } else {
        t13 = $[19];
    }
    let t14;
    if ($[20] !== t13 || $[21] !== t9) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t6,
            children: [
                t9,
                t13
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 164,
            columnNumber: 11
        }, this);
        $[20] = t13;
        $[21] = t9;
        $[22] = t14;
    } else {
        t14 = $[22];
    }
    let t15;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            overflow: "hidden",
            textOverflow: "ellipsis",
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical"
        };
        $[23] = t15;
    } else {
        t15 = $[23];
    }
    let t16;
    if ($[24] !== t || $[25] !== unit.description) {
        t16 = unit.description || t("sharedUnitCard.noDescription");
        $[24] = t;
        $[25] = unit.description;
        $[26] = t16;
    } else {
        t16 = $[26];
    }
    let t17;
    if ($[27] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            sx: t15,
            children: t16
        }, void 0, false, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 195,
            columnNumber: 11
        }, this);
        $[27] = t16;
        $[28] = t17;
    } else {
        t17 = $[28];
    }
    let t18;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = {
            mt: 0.5
        };
        $[29] = t18;
    } else {
        t18 = $[29];
    }
    const t19 = unit.owner || "Unknown";
    let t20;
    if ($[30] !== t || $[31] !== t19) {
        t20 = t("sharedUnitCard.sharedBy", {
            owner: t19
        });
        $[30] = t;
        $[31] = t19;
        $[32] = t20;
    } else {
        t20 = $[32];
    }
    let t21;
    if ($[33] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            sx: t18,
            children: t20
        }, void 0, false, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 224,
            columnNumber: 11
        }, this);
        $[33] = t20;
        $[34] = t21;
    } else {
        t21 = $[34];
    }
    let t22;
    if ($[35] !== t14 || $[36] !== t17 || $[37] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
            sx: t5,
            children: [
                t14,
                t17,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 232,
            columnNumber: 11
        }, this);
        $[35] = t14;
        $[36] = t17;
        $[37] = t21;
        $[38] = t22;
    } else {
        t22 = $[38];
    }
    let t23;
    if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = {
            display: "flex",
            alignItems: "center",
            pl: 2,
            pb: 1,
            gap: 1
        };
        $[39] = t23;
    } else {
        t23 = $[39];
    }
    let t24;
    if ($[40] !== canEdit) {
        t24 = canEdit ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 255,
            columnNumber: 21
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Visibility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 255,
            columnNumber: 36
        }, this);
        $[40] = canEdit;
        $[41] = t24;
    } else {
        t24 = $[41];
    }
    let t25;
    if ($[42] !== onOpen || $[43] !== unit.id) {
        t25 = ({
            "SharedUnitCard[<Button>.onClick]": ()=>onOpen(unit.id)
        })["SharedUnitCard[<Button>.onClick]"];
        $[42] = onOpen;
        $[43] = unit.id;
        $[44] = t25;
    } else {
        t25 = $[44];
    }
    let t26;
    if ($[45] !== canEdit || $[46] !== t) {
        t26 = canEdit ? t("sharedUnitCard.edit") : t("sharedUnitCard.view");
        $[45] = canEdit;
        $[46] = t;
        $[47] = t26;
    } else {
        t26 = $[47];
    }
    let t27;
    if ($[48] !== t24 || $[49] !== t25 || $[50] !== t26) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t23,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                variant: "outlined",
                size: "small",
                startIcon: t24,
                onClick: t25,
                children: t26
            }, void 0, false, {
                fileName: "[project]/src/components/SharedUnitCard.tsx",
                lineNumber: 283,
                columnNumber: 25
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 283,
            columnNumber: 11
        }, this);
        $[48] = t24;
        $[49] = t25;
        $[50] = t26;
        $[51] = t27;
    } else {
        t27 = $[51];
    }
    let t28;
    if ($[52] !== t22 || $[53] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t4,
            children: [
                t22,
                t27
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 293,
            columnNumber: 11
        }, this);
        $[52] = t22;
        $[53] = t27;
        $[54] = t28;
    } else {
        t28 = $[54];
    }
    let t29;
    if ($[55] !== unit.featuredImage || $[56] !== unit.identityId) {
        t29 = unit?.featuredImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            s3Key: unit.featuredImage,
            identityId: unit.identityId,
            fileId: null
        }, void 0, false, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 302,
            columnNumber: 34
        }, this);
        $[55] = unit.featuredImage;
        $[56] = unit.identityId;
        $[57] = t29;
    } else {
        t29 = $[57];
    }
    let t30;
    if ($[58] !== t28 || $[59] !== t29 || $[60] !== t3) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
            elevation: 2,
            sx: t3,
            children: [
                t28,
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/SharedUnitCard.tsx",
            lineNumber: 311,
            columnNumber: 11
        }, this);
        $[58] = t28;
        $[59] = t29;
        $[60] = t3;
        $[61] = t30;
    } else {
        t30 = $[61];
    }
    return t30;
}
_s(SharedUnitCard, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = SharedUnitCard;
var _c;
__turbopack_context__.k.register(_c, "SharedUnitCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useChatPageContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useChatPageContext",
    ()=>useChatPageContext
]);
/**
 * useChatPageContext - Register page-specific context with ChatContext
 * 
 * This hook allows pages to register their available context (unit, files, sections, etc.)
 * with the global ChatContext, making that context available to the chat sidebar.
 * 
 * @example
 * // In Unit Editor page
 * function UnitEditorPage() {
 *   const { unit, files, dictionary, questions } = useContext(UnitContext);
 *   const { sections } = useContext(SectionContext);
 *   const { vectorStoreSearch } = useContext(VectorStoreContext);
 *   const editorRef = useRef(null);
 *   
 *   useChatPageContext({
 *     unit,
 *     files,
 *     dictionary,
 *     questions,
 *     sections,
 *     editorRef,
 *     vectorStoreSearch,
 *   });
 *   
 *   return <...>
 * }
 * 
 * @see docs/GLOBAL_CHAT_INTEGRATION_PLAN.md
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/chatContext.jsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useChatPageContext(context = {}) {
    _s();
    const { setPageContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { unit = null, files = [], dictionary = [], questions = [], sections = [], editorRef = null, vectorStoreSearch = null } = context;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChatPageContext.useEffect": ()=>{
            console.log('[useChatPageContext] Registering page context:', {
                hasUnit: !!unit,
                filesCount: files?.length || 0,
                dictionaryCount: dictionary?.length || 0,
                questionsCount: questions?.length || 0,
                sectionsCount: sections?.length || 0,
                hasEditorRef: !!editorRef,
                hasVectorStoreSearch: !!vectorStoreSearch
            });
            setPageContext({
                unit,
                files,
                dictionary,
                questions,
                sections,
                editorRef,
                vectorStoreSearch
            });
            // Cleanup: reset to empty context when component unmounts
            return ({
                "useChatPageContext.useEffect": ()=>{
                    console.log('[useChatPageContext] Cleaning up page context');
                    setPageContext({
                        unit: null,
                        files: [],
                        dictionary: [],
                        questions: [],
                        sections: [],
                        editorRef: null,
                        vectorStoreSearch: null
                    });
                }
            })["useChatPageContext.useEffect"];
        }
    }["useChatPageContext.useEffect"], [
        // Dependencies - update when any context changes
        unit?.id,
        files?.length,
        dictionary?.length,
        questions?.length,
        sections?.length,
        editorRef?.current,
        vectorStoreSearch,
        setPageContext
    ]);
}
_s(useChatPageContext, "0aGcDEhsgvDsw4KhinDnLq0Ig9M=");
const __TURBOPACK__default__export__ = useChatPageContext;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/antiBadgeRegistry.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Anti-Badge Registry — Sardonic, 4th-wall-breaking badges of shame.
 *
 * These are the "achievements" nobody asked for: punishments wrapped in
 * glitter, educational puns taken too far, and pointed commentary on
 * the very concept of gamifying homework.
 *
 * Each anti-badge comes with a **debuff** — a whimsical, mostly-harmless
 * penalty that makes earning them memorably funny rather than demoralizing.
 *
 * @module antiBadgeRegistry
 */ __turbopack_context__.s([
    "ANTI_BADGE_REGISTRY",
    ()=>ANTI_BADGE_REGISTRY,
    "getAllAntiBadgeTypes",
    ()=>getAllAntiBadgeTypes,
    "getAntiBadgeConfig",
    ()=>getAntiBadgeConfig,
    "getAntiBadgesByRarity",
    ()=>getAntiBadgesByRarity,
    "getRedeemableAntiBadges",
    ()=>getRedeemableAntiBadges
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/gi/index.mjs [app-client] (ecmascript)");
;
const ANTI_BADGE_REGISTRY = {
    // ── The Classics: Late & Missing Work ─────────────────────────────────
    FASHIONABLY_LATE: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSnail"],
        name: "Fashionably Late",
        description: "Submitted homework so late it arrived in a different academic calendar.",
        bgColor: "#795548",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#a1887f",
                    position: "0%"
                },
                {
                    color: "#3e2723",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffcc80",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        rarity: "common",
        category: "anti",
        debuff: {
            xpMultiplier: 0.75,
            xpMultiplierDurationHours: 12,
            temporaryTitle: "⏰ Fashionably Late",
            cosmeticDurationHours: 24,
            shameText: "Time is a social construct, but due dates are not."
        },
        redeemable: true,
        redemptionHint: "Submit your next 3 assignments on time to clear this badge.",
        redemptionCondition: {
            type: "CONSECUTIVE_ON_TIME",
            count: 3
        }
    },
    THE_GHOST: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiGhost"],
        name: "The Ghost",
        description: "Vanished from the platform for so long we filed a missing persons report.",
        bgColor: "#455a64",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#78909c",
                    position: "0%"
                },
                {
                    color: "#263238",
                    position: "100%"
                }
            ]
        },
        iconColor: "#b0bec5",
        shape: "hexagon",
        animation: "pulse",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            streakFreezesRemoved: 1,
            temporaryTitle: "👻 The Ghost",
            cosmeticDurationHours: 48,
            shameText: "They say if you whisper their username three times, they still won't log in."
        },
        redeemable: true,
        redemptionHint: "Log in for 3 consecutive days to exorcise this badge.",
        redemptionCondition: {
            type: "LOGIN_STREAK",
            count: 3
        }
    },
    HOMEWORK_ATE_MY_DOG: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiEarthWorm"],
        name: "Homework Ate My Dog",
        description: "The excuse was so creative it deserved its own grade. The homework did not.",
        bgColor: "#e65100",
        gradient: {
            type: "linear",
            angle: "180deg",
            stops: [
                {
                    color: "#ff9800",
                    position: "0%"
                },
                {
                    color: "#bf360c",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fff3e0",
        shape: "shield",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            extraDrills: 1,
            temporaryTitle: "🐕 My Dog Ate My Excuse",
            cosmeticDurationHours: 24,
            shameText: "Plot twist: the homework ate the dog."
        },
        redeemable: true,
        redemptionHint: "Complete the missing assignment to adopt a new excuse.",
        redemptionCondition: {
            type: "COMPLETE_ASSIGNMENT"
        }
    },
    // ── Academic Misadventures ────────────────────────────────────────────
    SPEED_RUN_SCHOLAR: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiAlarmClock"],
        name: "Speed Run Scholar",
        description: "Completed a quiz in under 30 seconds. Either a genius or a very fast guesser.",
        bgColor: "#f44336",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#e57373",
                    position: "0%"
                },
                {
                    color: "#b71c1c",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffcdd2",
        shape: "diamond",
        animation: "spin-in",
        hoverAnimation: "shake",
        rarity: "rare",
        category: "anti",
        debuff: {
            xpMultiplier: 0.5,
            xpMultiplierDurationHours: 6,
            temporaryTitle: "⚡ Speed Run Scholar",
            cosmeticDurationHours: 12,
            shameText: "Any% homework speedrun, no glitches (but also no reading)."
        },
        redeemable: true,
        redemptionHint: "Retake the quiz spending at least 2 minutes per question.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    CONSISTENTLY_WRONG: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBrokenBone"],
        name: "Consistently Wrong",
        description: "Got the same question wrong 5 times. At this point it's a commitment.",
        bgColor: "#880e4f",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#f48fb1",
                    position: "0%"
                },
                {
                    color: "#4a0028",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fce4ec",
        shape: "circle",
        animation: "shake",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            extraDrills: 2,
            temporaryTitle: "🔄 Consistently Wrong™",
            cosmeticDurationHours: 24,
            shameText: "Wrong answers given with such confidence they almost became right."
        },
        redeemable: true,
        redemptionHint: "Get the question right once. Just once. We believe in you.",
        redemptionCondition: {
            type: "ACCURACY_ABOVE",
            percent: 50
        }
    },
    COPY_PASTE_CONNOISSEUR: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiStabbedNote"],
        name: "Copy-Paste Connoisseur",
        description: "Submitted an answer that was suspiciously identical to the question prompt.",
        bgColor: "#37474f",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#607d8b",
                    position: "0%"
                },
                {
                    color: "#102027",
                    position: "100%"
                }
            ]
        },
        iconColor: "#90a4ae",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "pulse",
        rarity: "rare",
        category: "anti",
        debuff: {
            xpMultiplier: 0.25,
            xpMultiplierDurationHours: 24,
            avatarDowngrade: "simple",
            temporaryTitle: "📋 Ctrl+C Ctrl+V",
            cosmeticDurationHours: 48,
            shameText: '"I wrote this myself" — narrator: they did not.'
        },
        redeemable: true,
        redemptionHint: "Submit an original answer of at least 100 words.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    // ── Meta & 4th Wall Breaking ──────────────────────────────────────────
    BADGE_COLLECTOR_ANONYMOUS: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBirdCage"],
        name: "Badge Collector Anonymous",
        description: "You earned this badge for caring too much about badges. The irony is the reward.",
        bgColor: "#6a1b9a",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#ce93d8",
                    position: "0%"
                },
                {
                    color: "#38006b",
                    position: "100%"
                }
            ]
        },
        iconColor: "#e1bee7",
        shape: "diamond",
        animation: "spin-in",
        hoverAnimation: "glow",
        rarity: "epic",
        category: "anti",
        debuff: {
            temporaryTitle: "🏅 Badge Addict",
            cosmeticDurationHours: 72,
            shameText: "Congratulations! You have earned a badge about earning badges. This is what peak gamification looks like.",
            hideFromLeaderboard: true,
            hideFromLeaderboardHours: 1
        },
        redeemable: false
    },
    GAMIFICATION_VICTIM: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBoxTrap"],
        name: "Gamification Victim",
        description: "You noticed you're being manipulated by points and still can't stop. Welcome.",
        bgColor: "#1a237e",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#3f51b5",
                    position: "0%"
                },
                {
                    color: "#0d0d3b",
                    position: "100%"
                }
            ]
        },
        iconColor: "#c5cae9",
        shape: "hexagon",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "legendary",
        category: "anti",
        debuff: {
            temporaryTitle: "🎮 Willing Participant",
            cosmeticDurationHours: 168,
            shameText: "B.F. Skinner would be proud. You are the pigeon. The XP is the pellet. Keep pecking."
        },
        redeemable: false
    },
    SKINNER_BOX_RESIDENT: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiCage"],
        name: "Skinner Box Resident",
        description: "Checked the leaderboard more than 20 times today. The experiment is working.",
        bgColor: "#004d40",
        gradient: {
            type: "linear",
            angle: "180deg",
            stops: [
                {
                    color: "#009688",
                    position: "0%"
                },
                {
                    color: "#001a14",
                    position: "100%"
                }
            ]
        },
        iconColor: "#80cbc4",
        shape: "circle",
        animation: "pulse",
        hoverAnimation: "glow",
        rarity: "rare",
        category: "anti",
        debuff: {
            hideFromLeaderboard: true,
            hideFromLeaderboardHours: 6,
            temporaryTitle: "🐀 Lab Rat",
            cosmeticDurationHours: 24,
            shameText: "Variable-ratio reinforcement schedule applied successfully. Subject shows no signs of stopping."
        },
        redeemable: true,
        redemptionHint: "Don't check the leaderboard for 24 hours. We dare you.",
        redemptionCondition: {
            type: "WAIT_PERIOD",
            hours: 24
        }
    },
    // ── Educational Puns ──────────────────────────────────────────────────
    PARTICIPATION_ATROPHY: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTiredEye"],
        name: "Participation Atrophy",
        description: "Your participation has atrophied to the point where your avatar started yawning.",
        bgColor: "#5d4037",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#8d6e63",
                    position: "0%"
                },
                {
                    color: "#321911",
                    position: "100%"
                }
            ]
        },
        iconColor: "#d7ccc8",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        rarity: "common",
        category: "anti",
        debuff: {
            xpMultiplier: 0.8,
            xpMultiplierDurationHours: 48,
            avatarDowngrade: "simple",
            temporaryTitle: "💤 Participation Atrophy",
            cosmeticDurationHours: 48,
            shameText: "Your muscles aren't the only things you haven't exercised."
        },
        redeemable: true,
        redemptionHint: "Complete 3 activities in a single day to rehabilitate.",
        redemptionCondition: {
            type: "ACTIVITY_COUNT",
            count: 3,
            period: "day"
        }
    },
    PROCRASTINATION_STATION: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSleepy"],
        name: "Procrastination Station",
        description: "Opened the assignment page 12 times without submitting. The buffer state of homework.",
        bgColor: "#1565c0",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#42a5f5",
                    position: "0%"
                },
                {
                    color: "#0a3069",
                    position: "100%"
                }
            ]
        },
        iconColor: "#bbdefb",
        shape: "hexagon",
        animation: "pulse",
        hoverAnimation: "shake",
        rarity: "common",
        category: "anti",
        debuff: {
            temporaryTitle: "🚂 All Aboard the Procrastination Station",
            cosmeticDurationHours: 24,
            shameText: "You have earned a PhD in Looking At The Assignment Without Doing The Assignment."
        },
        redeemable: true,
        redemptionHint: "Just... submit something. Anything. Please.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    SYLLABUS_SAYS_NO: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiDungeonGate"],
        name: "Syllabus Says No",
        description: "Asked a question that was clearly answered on page 1 of the syllabus.",
        bgColor: "#b71c1c",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#ef5350",
                    position: "0%"
                },
                {
                    color: "#560027",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffcdd2",
        shape: "shield",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            extraDrills: 1,
            temporaryTitle: "📖 Did You Read The Syllabus?",
            cosmeticDurationHours: 24,
            shameText: "The syllabus weeps. It was all there. Page one. Bold. Underlined. Highlighted."
        },
        redeemable: true,
        redemptionHint: "Read the syllabus. (We'll know.)",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    EXTRA_CREDIT_JUNKIE: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSpikedSnail"],
        name: "Extra Credit Junkie",
        description: "Requested extra credit before completing the regular credit. The audacity.",
        bgColor: "#ff6f00",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#ffb74d",
                    position: "0%"
                },
                {
                    color: "#e65100",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fff8e1",
        shape: "circle",
        animation: "bounce-in",
        hoverAnimation: "pulse",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            xpMultiplier: 0.9,
            xpMultiplierDurationHours: 24,
            temporaryTitle: "✨ Extra Credit Enthusiast",
            cosmeticDurationHours: 48,
            shameText: "Asking for extra credit is the academic equivalent of asking for dessert before dinner."
        },
        redeemable: true,
        redemptionHint: "Complete all regular assignments first. Then we'll talk.",
        redemptionCondition: {
            type: "COMPLETE_ASSIGNMENT"
        }
    },
    // ── Making Fun of EdTech ──────────────────────────────────────────────
    ENGAGEMENT_METRICS: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiCuckooClock"],
        name: "Engagement Metrics!",
        description: "Congratulations! Your 'time on platform' metric went up because you left the tab open overnight.",
        bgColor: "#00695c",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#26a69a",
                    position: "0%"
                },
                {
                    color: "#002f29",
                    position: "100%"
                }
            ]
        },
        iconColor: "#b2dfdb",
        shape: "hexagon",
        animation: "spin-in",
        hoverAnimation: "pulse",
        rarity: "rare",
        category: "anti",
        debuff: {
            temporaryTitle: "📊 Metric Manipulator",
            cosmeticDurationHours: 24,
            shameText: "You boosted our engagement metrics! The investors will be thrilled. Learning? That's a different metric."
        },
        redeemable: false
    },
    AI_WHISPERER_ZERO: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSlime"],
        name: "AI Whisperer Zero",
        description: "Asked the AI tutor to do your homework for you. It said no. Even the robot judges you.",
        bgColor: "#4e342e",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#8d6e63",
                    position: "0%"
                },
                {
                    color: "#1b0e08",
                    position: "100%"
                }
            ]
        },
        iconColor: "#a5d6a7",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "shake",
        rarity: "rare",
        category: "anti",
        debuff: {
            xpMultiplier: 0.5,
            xpMultiplierDurationHours: 12,
            temporaryTitle: "🤖 Rejected by AI",
            cosmeticDurationHours: 24,
            shameText: "Even ChatGPT has boundaries. You found them."
        },
        redeemable: true,
        redemptionHint: "Have a genuine learning conversation with the AI tutor.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    ACHIEVEMENT_UNLOCKED_UNLOCKED: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiJesterHat"],
        name: "Achievement Unlocked: Unlocked",
        description: "You unlocked the achievement for unlocking achievements. We need to go deeper.",
        bgColor: "#ad1457",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#f06292",
                    position: "0%"
                },
                {
                    color: "#6a0034",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fce4ec",
        shape: "diamond",
        animation: "spin-in",
        hoverAnimation: "glow",
        rarity: "legendary",
        category: "anti",
        debuff: {
            temporaryTitle: "🎭 Meta Achievement Haver",
            cosmeticDurationHours: 168,
            shameText: "You are now 4 layers deep in gamification irony. There is no going back. The badges are watching."
        },
        redeemable: false
    },
    // ── Streak & Attendance Shame ─────────────────────────────────────────
    STREAK_BREAKER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBrokenShield"],
        name: "Streak Breaker",
        description: "Broke a 14+ day streak. All those consecutive days, gone like tears in rain.",
        bgColor: "#263238",
        gradient: {
            type: "linear",
            angle: "180deg",
            stops: [
                {
                    color: "#546e7a",
                    position: "0%"
                },
                {
                    color: "#000a12",
                    position: "100%"
                }
            ]
        },
        iconColor: "#78909c",
        shape: "shield",
        animation: "shake",
        hoverAnimation: "pulse",
        rarity: "epic",
        category: "anti",
        debuff: {
            streakFreezesRemoved: 2,
            xpMultiplier: 0.7,
            xpMultiplierDurationHours: 48,
            temporaryTitle: "💔 Streak Breaker",
            cosmeticDurationHours: 48,
            shameText: "14 days of dedication, shattered. Your streak didn't die — it was murdered."
        },
        redeemable: true,
        redemptionHint: "Build a new 7-day streak to earn forgiveness.",
        redemptionCondition: {
            type: "BUILD_STREAK",
            count: 7
        }
    },
    GRAVEYARD_SHIFT: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTombstone"],
        name: "Graveyard Shift",
        description: "Submitted homework at 3 AM. The learning was questionable. The dedication was not.",
        bgColor: "#1a1a2e",
        gradient: {
            type: "linear",
            angle: "180deg",
            stops: [
                {
                    color: "#16213e",
                    position: "0%"
                },
                {
                    color: "#0f0f1a",
                    position: "100%"
                }
            ]
        },
        iconColor: "#a0a0b0",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "glow",
        rarity: "common",
        category: "anti",
        debuff: {
            temporaryTitle: "🌙 Night Owl (Derogatory)",
            cosmeticDurationHours: 24,
            shameText: "Nothing good happens after 2 AM. Especially homework."
        },
        redeemable: false
    },
    // ── School-Specific Trouble ───────────────────────────────────────────
    DIGITAL_DETENTION: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiPrisoner"],
        name: "Digital Detention",
        description: "Your behavior in the chat has earned you the world's first virtual detention.",
        bgColor: "#4a148c",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#7b1fa2",
                    position: "0%"
                },
                {
                    color: "#12005e",
                    position: "100%"
                }
            ]
        },
        iconColor: "#e1bee7",
        shape: "shield",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "epic",
        category: "anti",
        debuff: {
            hideFromLeaderboard: true,
            hideFromLeaderboardHours: 24,
            xpMultiplier: 0.5,
            xpMultiplierDurationHours: 24,
            temporaryTitle: "🔒 In Detention",
            cosmeticDurationHours: 24,
            shameText: "You will sit here and think about what you've done. Digitally.",
            extraDrills: 3
        },
        redeemable: true,
        redemptionHint: "Complete your 3 community service drills to earn release.",
        redemptionCondition: {
            type: "COMPLETE_DRILLS",
            count: 3
        }
    },
    THE_GREAT_DISCONNECT: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBrokenHeart"],
        name: "The Great Disconnect",
        description: "Closed the browser tab during a timed quiz. Brave. Foolish. But brave.",
        bgColor: "#c62828",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#ef5350",
                    position: "0%"
                },
                {
                    color: "#7f0000",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffcdd2",
        shape: "diamond",
        animation: "shake",
        hoverAnimation: "pulse",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            xpMultiplier: 0.6,
            xpMultiplierDurationHours: 12,
            temporaryTitle: "🔌 The Disconnector",
            cosmeticDurationHours: 24,
            shameText: '"My internet went out" — your internet, under oath, testifies otherwise.'
        },
        redeemable: true,
        redemptionHint: "Complete a quiz from start to finish without any... interruptions.",
        redemptionCondition: {
            type: "COMPLETE_ASSIGNMENT"
        }
    },
    LOREM_IPSUM_LAUREATE: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiWorms"],
        name: "Lorem Ipsum Laureate",
        description: "Submitted placeholder text as a final answer. Bold strategy, Cotton.",
        bgColor: "#2e7d32",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#66bb6a",
                    position: "0%"
                },
                {
                    color: "#1b3e1f",
                    position: "100%"
                }
            ]
        },
        iconColor: "#c8e6c9",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "shake",
        rarity: "rare",
        category: "anti",
        debuff: {
            xpMultiplier: 0.3,
            xpMultiplierDurationHours: 24,
            avatarDowngrade: "simple",
            temporaryTitle: "📝 Lorem Ipsum Dolor Sit Amet",
            cosmeticDurationHours: 48,
            shameText: "Consectetur adipiscing elit. Sed do eiusmod tempor incididunt. See? We can do it too."
        },
        redeemable: true,
        redemptionHint: "Replace Lorem Ipsum with actual words. In your language. About the topic.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    // ── Gamification Self-Awareness ───────────────────────────────────────
    NOTIFICATION_JUNKIE: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiClown"],
        name: "Notification Junkie",
        description: "Clicked on every single notification within 5 seconds of it appearing. Pavlov sends his regards.",
        bgColor: "#d84315",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#ff8a65",
                    position: "0%"
                },
                {
                    color: "#801a00",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fbe9e7",
        shape: "circle",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            temporaryTitle: "🔔 Ding Ding Ding",
            cosmeticDurationHours: 24,
            shameText: "You hear a notification sound. Your pupils dilate. You click. There is no new content. You wait."
        },
        redeemable: false
    },
    XP_ZERO_HERO: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiCoffin"],
        name: "XP: Zero Hero",
        description: "Completed an entire session and earned exactly 0 XP. A statistical anomaly. A legend.",
        bgColor: "#212121",
        gradient: {
            type: "linear",
            angle: "180deg",
            stops: [
                {
                    color: "#424242",
                    position: "0%"
                },
                {
                    color: "#000000",
                    position: "100%"
                }
            ]
        },
        iconColor: "#757575",
        shape: "shield",
        animation: "draw",
        hoverAnimation: "glow",
        rarity: "legendary",
        category: "anti",
        debuff: {
            temporaryTitle: "🦸 Zero Hero",
            cosmeticDurationHours: 72,
            shameText: "In a system designed to give you points for breathing near homework, you earned none. Respect."
        },
        redeemable: true,
        redemptionHint: "Earn any amount of XP. Literally any. One point. We beg you.",
        redemptionCondition: {
            type: "EARN_XP",
            count: 1
        }
    },
    DUNNING_KRUGER_AWARD: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSpottedMushroom"],
        name: "Dunning-Kruger Award",
        description: "Rated your confidence as 'Expert' on a topic you scored 20% on. Peak human condition.",
        bgColor: "#f57f17",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#ffee58",
                    position: "0%"
                },
                {
                    color: "#f57f17",
                    position: "50%"
                },
                {
                    color: "#8c5100",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fff9c4",
        shape: "diamond",
        animation: "bounce-in",
        hoverAnimation: "glow",
        rarity: "epic",
        category: "anti",
        debuff: {
            xpMultiplier: 0.6,
            xpMultiplierDurationHours: 24,
            temporaryTitle: "🍄 Confidently Incorrect",
            cosmeticDurationHours: 48,
            shameText: "Mount Stupid has a new summit. Plant your flag. You've earned it."
        },
        redeemable: true,
        redemptionHint: "Score 80%+ on the same topic to descend from Mount Stupid.",
        redemptionCondition: {
            type: "SCORE_ON_TOPIC",
            percent: 80
        }
    },
    THE_TUTORIAL_SKIPPER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiDeadEye"],
        name: "The Tutorial Skipper",
        description: "Skipped every tutorial, help text, and instruction. Then asked how everything works.",
        bgColor: "#311b92",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#5c6bc0",
                    position: "0%"
                },
                {
                    color: "#0c0040",
                    position: "100%"
                }
            ]
        },
        iconColor: "#c5cae9",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "shake",
        rarity: "common",
        category: "anti",
        debuff: {
            extraDrills: 1,
            temporaryTitle: "⏩ TLDR Enthusiast",
            cosmeticDurationHours: 24,
            shameText: "Instructions? Where we're going, we don't need instructions. (You do. You really do.)"
        },
        redeemable: true,
        redemptionHint: "Complete the tutorial. The whole thing. Yes, all of it.",
        redemptionCondition: {
            type: "COMPLETE_ASSIGNMENT"
        }
    },
    INFINITE_LOOP_LEARNER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTurtle"],
        name: "Infinite Loop Learner",
        description: "Watched the same lesson video 10+ times without attempting the practice. Loading...",
        bgColor: "#0d47a1",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#1976d2",
                    position: "0%"
                },
                {
                    color: "#051e3e",
                    position: "100%"
                }
            ]
        },
        iconColor: "#bbdefb",
        shape: "hexagon",
        animation: "pulse",
        hoverAnimation: "spin-in",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            temporaryTitle: "🔁 while(true) { watch(); }",
            cosmeticDurationHours: 24,
            shameText: "Watching ≠ learning. We checked. There's a whole field of research about this."
        },
        redeemable: true,
        redemptionHint: "Attempt the practice activity. The video will still be there, we promise.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    MINIMALLY_VIABLE_STUDENT: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiAnvil"],
        name: "Minimally Viable Student",
        description: "Consistently submits work that meets exactly 0.01% above the minimum threshold. An optimization marvel.",
        bgColor: "#546e7a",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#78909c",
                    position: "0%"
                },
                {
                    color: "#1c313a",
                    position: "100%"
                }
            ]
        },
        iconColor: "#cfd8dc",
        shape: "shield",
        animation: "draw",
        hoverAnimation: "pulse",
        rarity: "rare",
        category: "anti",
        debuff: {
            xpMultiplier: 0.85,
            xpMultiplierDurationHours: 48,
            temporaryTitle: "📉 MVP (Minimum Viable Participant)",
            cosmeticDurationHours: 48,
            shameText: "You found the exact minimum effort threshold. Engineers call this optimization. Teachers call it something else."
        },
        redeemable: true,
        redemptionHint: "Score above 90% on any assignment to prove the minimum isn't your maximum.",
        redemptionCondition: {
            type: "ACCURACY_ABOVE",
            percent: 90
        }
    },
    EMPTY_CANVAS_ARTIST: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTransparentSlime"],
        name: "Empty Canvas Artist",
        description: "Submitted a completely blank response. It's not modern art. It's just blank.",
        bgColor: "#e0e0e0",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#fafafa",
                    position: "0%"
                },
                {
                    color: "#9e9e9e",
                    position: "100%"
                }
            ]
        },
        iconColor: "#bdbdbd",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        rarity: "common",
        category: "anti",
        debuff: {
            xpMultiplier: 0,
            xpMultiplierDurationHours: 6,
            temporaryTitle: '🎨 " "',
            cosmeticDurationHours: 12,
            shameText: "John Cage had 4'33\". You have 0 characters. Equally avant-garde. Equally ungraded."
        },
        redeemable: true,
        redemptionHint: "Submit literally anything. A haiku. A grocery list. Just not nothing.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    BUG_REPORT_OR_EXCUSE: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBugNet"],
        name: "Bug Report or Excuse?",
        description: "Filed a 'bug report' that suspiciously coincided with a deadline. The platform worked fine for everyone else.",
        bgColor: "#1b5e20",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#43a047",
                    position: "0%"
                },
                {
                    color: "#0a2e0f",
                    position: "100%"
                }
            ]
        },
        iconColor: "#a5d6a7",
        shape: "hexagon",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            temporaryTitle: "🐛 QA Specialist (Self-Appointed)",
            cosmeticDurationHours: 24,
            shameText: "Steps to reproduce: 1) Have assignment due. 2) Don't do assignment. 3) Report 'bug'."
        },
        redeemable: true,
        redemptionHint: "Submit the assignment and the 'bug' will mysteriously resolve itself.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    }
};
function getAllAntiBadgeTypes() {
    return Object.keys(ANTI_BADGE_REGISTRY);
}
function getAntiBadgeConfig(badgeType) {
    return ANTI_BADGE_REGISTRY[badgeType];
}
function getRedeemableAntiBadges() {
    return Object.entries(ANTI_BADGE_REGISTRY).filter(([, config])=>config.redeemable);
}
function getAntiBadgesByRarity(rarity) {
    return Object.entries(ANTI_BADGE_REGISTRY).filter(([, config])=>config.rarity === rarity);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/BadgeShelf.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BadgeShelf",
    ()=>BadgeShelf,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * BadgeShelf — Grid display of achievement badges.
 * Earned badges show in full color; unearned badges are grayed out with a lock overlay.
 *
 * @module BadgeShelf
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Popover/Popover.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BadgeIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$antiBadgeRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/antiBadgeRegistry.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
const BADGE_DEFINITIONS = {
    FIRST_SUBMISSION: {
        name: 'First Submission',
        description: 'Submitted your first homework'
    },
    GOOD_EYE: {
        name: 'Good Eye',
        description: 'Revised work after AI feedback'
    },
    QUICK_DRAW: {
        name: 'Quick Draw',
        description: 'Submitted before the due date'
    },
    SHARPSHOOTER: {
        name: 'Sharpshooter',
        description: 'Scored 90%+ on an assignment'
    },
    CONSISTENT: {
        name: 'Consistent',
        description: 'Maintained a 7-day streak'
    },
    TEAM_PLAYER: {
        name: 'Team Player',
        description: 'Completed a peer review'
    },
    DEEP_THINKER: {
        name: 'Deep Thinker',
        description: 'Completed all blocks in a unit'
    },
    TOP_OF_CLASS: {
        name: 'Top of Class',
        description: 'Reached #1 on the leaderboard'
    },
    PERFECTIONIST: {
        name: 'Perfectionist',
        description: 'Scored 100% on an assignment'
    },
    // Avatar unlock badges
    AVATAR_COLORS: {
        name: 'Color Unlocked',
        description: 'Reached Level 2 — unlock avatar color picker'
    },
    AVATAR_DETAILED: {
        name: 'New Look',
        description: 'Reached Level 3 — unlocked detailed avatar style'
    },
    AVATAR_ACCESSORIES: {
        name: 'Accessorized',
        description: 'Reached Level 4 — unlock avatar accessories'
    },
    AVATAR_PORTRAIT: {
        name: 'Portrait Mode',
        description: 'Reached Level 5 — unlocked portrait avatar style & full customizer'
    },
    // Bot Whisperer tiered badges
    BOT_WHISPERER_I: {
        name: 'Bot Whisperer I',
        description: 'Had your first real conversation with the AI tutor'
    },
    BOT_WHISPERER_II: {
        name: 'Bot Whisperer II',
        description: 'Earned Deep Thinker — upgraded your bot\'s style'
    },
    BOT_WHISPERER_III: {
        name: 'Bot Whisperer III',
        description: 'Used AI across 5 units — choose your bot\'s eyes & mouth'
    },
    BOT_WHISPERER_IV: {
        name: 'Bot Whisperer IV',
        description: 'AI mastery achieved — full bot customization unlocked'
    },
    // Avatar powerup badges
    AVATAR_GLOW: {
        name: 'Glow Ring',
        description: 'Level up! — rotating gradient ring around your avatar for 24 hours'
    },
    // Storybook documentation promo badges
    DOCS_EXPLORER: {
        name: 'Docs Explorer',
        description: 'Visited the Storybook documentation and started onboarding'
    },
    INSTRUCTOR_ONBOARD: {
        name: 'Instructor Certified',
        description: 'Completed the instructor onboarding in Storybook'
    },
    LEARNER_ONBOARD: {
        name: 'Learner Certified',
        description: 'Completed the learner onboarding in Storybook'
    },
    TRANSLATOR_ONBOARD: {
        name: 'Translator Certified',
        description: 'Completed the translator onboarding in Storybook'
    },
    A11Y_CHAMPION: {
        name: 'Accessibility Champion',
        description: 'Completed accessibility-related tasks in Storybook'
    },
    DOCS_CHAMPION: {
        name: 'Documentation Champion',
        description: 'Completed all onboarding paths — instructor, learner, and translator'
    }
};
const ALL_BADGE_TYPES = Object.keys(BADGE_DEFINITIONS);
_c = ALL_BADGE_TYPES;
function BadgeShelf(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(28);
    if ($[0] !== "ca946ada4559f58dc810c9cdb40a3bb87cf54fa66149c31c23093670e4d98195") {
        for(let $i = 0; $i < 28; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "ca946ada4559f58dc810c9cdb40a3bb87cf54fa66149c31c23093670e4d98195";
    }
    const { earnedBadges, earnedOnly: t1 } = t0;
    const earnedOnly = t1 === undefined ? false : t1;
    const regularEarned = earnedBadges.filter(_BadgeShelfEarnedBadgesFilter);
    const antiEarned = earnedBadges.filter(_BadgeShelfEarnedBadgesFilter2);
    const earnedSet = new Set(regularEarned.map(_BadgeShelfRegularEarnedMap));
    let t2;
    if ($[1] !== earnedBadges) {
        t2 = earnedBadges.reduce(_BadgeShelfEarnedBadgesReduce, {});
        $[1] = earnedBadges;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const earnedCounts = t2;
    const badgesToShow = earnedOnly ? ALL_BADGE_TYPES.filter({
        "BadgeShelf[ALL_BADGE_TYPES.filter()]": (type)=>earnedSet.has(type)
    }["BadgeShelf[ALL_BADGE_TYPES.filter()]"]) : ALL_BADGE_TYPES;
    const [anchorEl, setAnchorEl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [activeBadge, setActiveBadge] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [activeIsAnti, setActiveIsAnti] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "BadgeShelf[handleClick]": (event, type_0, t4)=>{
                const isAnti = t4 === undefined ? false : t4;
                setAnchorEl(event.currentTarget);
                setActiveBadge(type_0);
                setActiveIsAnti(isAnti);
            }
        })["BadgeShelf[handleClick]"];
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const handleClick = t3;
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "BadgeShelf[handleClose]": ()=>{
                setAnchorEl(null);
                setActiveBadge(null);
                setActiveIsAnti(false);
            }
        })["BadgeShelf[handleClose]"];
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    const handleClose = t4;
    const activeDef = activeBadge && !activeIsAnti ? BADGE_DEFINITIONS[activeBadge] : null;
    let t5;
    if ($[5] !== activeBadge || $[6] !== activeIsAnti) {
        t5 = activeBadge && activeIsAnti ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$antiBadgeRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAntiBadgeConfig"])(activeBadge) : null;
        $[5] = activeBadge;
        $[6] = activeIsAnti;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    const activeAntiConfig = t5;
    const activeEarned = activeBadge ? earnedBadges.find({
        "BadgeShelf[earnedBadges.find()]": (b_3)=>b_3.badgeType === activeBadge
    }["BadgeShelf[earnedBadges.find()]"]) : null;
    const activeIsEarned = activeBadge ? activeIsAnti ? antiEarned.some({
        "BadgeShelf[antiEarned.some()]": (b_4)=>b_4.badgeType === activeBadge
    }["BadgeShelf[antiEarned.some()]"]) : earnedSet.has(activeBadge) : false;
    const activeCount = activeBadge ? earnedCounts[activeBadge] || 0 : 0;
    let t6;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            display: "flex",
            flexWrap: "wrap",
            gap: 1,
            alignItems: "center"
        };
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    const t7 = badgesToShow.map({
        "BadgeShelf[badgesToShow.map()]": (type_1)=>{
            const def = BADGE_DEFINITIONS[type_1];
            const isEarned = earnedSet.has(type_1);
            const count = earnedCounts[type_1] || 0;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: def.name,
                arrow: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    onClick: {
                        "BadgeShelf[badgesToShow.map() > <Box>.onClick]": (e)=>handleClick(e, type_1)
                    }["BadgeShelf[badgesToShow.map() > <Box>.onClick]"],
                    sx: {
                        position: "relative",
                        cursor: "pointer"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeIcon"], {
                            badgeType: type_1,
                            size: 56,
                            earned: isEarned,
                            animate: isEarned,
                            drawIcon: isEarned
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                            lineNumber: 254,
                            columnNumber: 12
                        }, this),
                        isEarned && count > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "caption",
                            sx: {
                                position: "absolute",
                                bottom: -2,
                                right: -2,
                                fontSize: "0.625rem",
                                fontWeight: 800,
                                color: "primary.main",
                                bgcolor: "background.paper",
                                borderRadius: "50%",
                                width: 18,
                                height: 18,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                boxShadow: 1,
                                lineHeight: 1
                            },
                            children: [
                                "×",
                                count
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                            lineNumber: 254,
                            columnNumber: 137
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                    lineNumber: 249,
                    columnNumber: 66
                }, this)
            }, type_1, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 249,
                columnNumber: 14
            }, this);
        }
    }["BadgeShelf[badgesToShow.map()]"]);
    let t8;
    if ($[9] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t6,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
            lineNumber: 275,
            columnNumber: 10
        }, this);
        $[9] = t7;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    const t9 = antiEarned.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    my: 2
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    label: "Anti-Badges",
                    size: "small",
                    color: "error",
                    variant: "outlined",
                    sx: {
                        fontWeight: 700,
                        fontSize: "0.7rem"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                    lineNumber: 283,
                    columnNumber: 8
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 281,
                columnNumber: 41
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    display: "flex",
                    flexWrap: "wrap",
                    gap: 1,
                    alignItems: "center"
                },
                children: antiEarned.map({
                    "BadgeShelf[antiEarned.map()]": (badge)=>{
                        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$antiBadgeRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAntiBadgeConfig"])(badge.badgeType);
                        const count_0 = earnedCounts[badge.badgeType] || 1;
                        if (!config) {
                            return null;
                        }
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            title: config.name,
                            arrow: true,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                onClick: {
                                    "BadgeShelf[antiEarned.map() > <Box>.onClick]": (e_0)=>handleClick(e_0, badge.badgeType, true)
                                }["BadgeShelf[antiEarned.map() > <Box>.onClick]"],
                                sx: {
                                    position: "relative",
                                    cursor: "pointer",
                                    border: "2px solid",
                                    borderColor: "error.main",
                                    borderRadius: "50%",
                                    p: 0.25
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeIcon"], {
                                        config: config,
                                        size: 56,
                                        earned: true,
                                        animate: true,
                                        drawIcon: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                                        lineNumber: 307,
                                        columnNumber: 16
                                    }, this),
                                    count_0 > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        variant: "caption",
                                        sx: {
                                            position: "absolute",
                                            bottom: -2,
                                            right: -2,
                                            fontSize: "0.625rem",
                                            fontWeight: 800,
                                            color: "error.main",
                                            bgcolor: "background.paper",
                                            borderRadius: "50%",
                                            width: 18,
                                            height: 18,
                                            display: "flex",
                                            alignItems: "center",
                                            justifyContent: "center",
                                            boxShadow: 1,
                                            lineHeight: 1
                                        },
                                        children: [
                                            "×",
                                            count_0
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                                        lineNumber: 307,
                                        columnNumber: 116
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                                lineNumber: 298,
                                columnNumber: 82
                            }, this)
                        }, badge.badgeType, false, {
                            fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                            lineNumber: 298,
                            columnNumber: 18
                        }, this);
                    }
                }["BadgeShelf[antiEarned.map()]"])
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 286,
                columnNumber: 22
            }, this)
        ]
    }, void 0, true);
    const T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
    const t10 = Boolean(anchorEl);
    let t11;
    let t12;
    let t13;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            vertical: "bottom",
            horizontal: "center"
        };
        t12 = {
            vertical: "top",
            horizontal: "center"
        };
        t13 = {
            paper: {
                sx: {
                    p: 2,
                    maxWidth: 260,
                    borderRadius: 2
                }
            }
        };
        $[11] = t11;
        $[12] = t12;
        $[13] = t13;
    } else {
        t11 = $[11];
        t12 = $[12];
        t13 = $[13];
    }
    const t14 = activeDef && !activeIsAnti && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        spacing: 0.5,
        alignItems: "center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeIcon"], {
                badgeType: activeBadge,
                size: 48,
                earned: activeIsEarned,
                animate: false,
                drawIcon: false
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 357,
                columnNumber: 86
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "subtitle2",
                fontWeight: 700,
                children: activeDef.name
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 357,
                columnNumber: 190
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "text.secondary",
                textAlign: "center",
                children: activeDef.description
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 357,
                columnNumber: 268
            }, this),
            activeIsEarned && activeEarned && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                sx: {
                    opacity: 0.7
                },
                children: [
                    "Earned ",
                    new Date(activeEarned.awardedAt).toLocaleDateString()
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 357,
                columnNumber: 411
            }, this),
            activeIsEarned && activeCount > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                fontWeight: 700,
                color: "primary.main",
                children: [
                    "Earned ",
                    activeCount,
                    " times"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 359,
                columnNumber: 122
            }, this),
            !activeIsEarned && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "text.disabled",
                fontStyle: "italic",
                children: "Locked"
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 359,
                columnNumber: 250
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
        lineNumber: 357,
        columnNumber: 45
    }, this);
    const t15 = activeAntiConfig && activeIsAnti && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        spacing: 0.5,
        alignItems: "center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeIcon"], {
                config: activeAntiConfig,
                size: 48,
                earned: true,
                animate: false,
                drawIcon: false
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 360,
                columnNumber: 92
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "subtitle2",
                fontWeight: 700,
                color: "error.main",
                children: activeAntiConfig.name
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 360,
                columnNumber: 188
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "text.secondary",
                textAlign: "center",
                children: activeAntiConfig.description
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 360,
                columnNumber: 292
            }, this),
            activeAntiConfig.debuff.shameText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                fontStyle: "italic",
                color: "error",
                textAlign: "center",
                sx: {
                    opacity: 0.8
                },
                children: [
                    "“",
                    activeAntiConfig.debuff.shameText,
                    "”"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 360,
                columnNumber: 445
            }, this),
            activeAntiConfig.debuff.xpMultiplier != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                label: `XP ×${activeAntiConfig.debuff.xpMultiplier} for ${activeAntiConfig.debuff.xpMultiplierDurationHours || 24}h`,
                size: "small",
                color: "error",
                variant: "outlined",
                sx: {
                    fontSize: "0.65rem"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 362,
                columnNumber: 108
            }, this),
            activeAntiConfig.debuff.temporaryTitle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                label: `Title: "${activeAntiConfig.debuff.temporaryTitle}"`,
                size: "small",
                variant: "outlined",
                sx: {
                    fontSize: "0.65rem"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 364,
                columnNumber: 54
            }, this),
            activeAntiConfig.redeemable && activeAntiConfig.redemptionHint && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "success.main",
                textAlign: "center",
                sx: {
                    mt: 0.5
                },
                children: [
                    "Redeemable: ",
                    activeAntiConfig.redemptionHint
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 366,
                columnNumber: 78
            }, this),
            activeIsEarned && activeEarned && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                sx: {
                    opacity: 0.7
                },
                children: [
                    "Received ",
                    new Date(activeEarned.awardedAt).toLocaleDateString()
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 368,
                columnNumber: 102
            }, this),
            activeCount > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                fontWeight: 700,
                color: "error.main",
                children: [
                    "Received ",
                    activeCount,
                    " times"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 370,
                columnNumber: 106
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
        lineNumber: 360,
        columnNumber: 51
    }, this);
    let t16;
    if ($[14] !== T0 || $[15] !== anchorEl || $[16] !== handleClose || $[17] !== t10 || $[18] !== t11 || $[19] !== t12 || $[20] !== t13 || $[21] !== t14 || $[22] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            open: t10,
            anchorEl: anchorEl,
            onClose: handleClose,
            anchorOrigin: t11,
            transformOrigin: t12,
            slotProps: t13,
            children: [
                t14,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
            lineNumber: 373,
            columnNumber: 11
        }, this);
        $[14] = T0;
        $[15] = anchorEl;
        $[16] = handleClose;
        $[17] = t10;
        $[18] = t11;
        $[19] = t12;
        $[20] = t13;
        $[21] = t14;
        $[22] = t15;
        $[23] = t16;
    } else {
        t16 = $[23];
    }
    let t17;
    if ($[24] !== t16 || $[25] !== t8 || $[26] !== t9) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t8,
                t9,
                t16
            ]
        }, void 0, true);
        $[24] = t16;
        $[25] = t8;
        $[26] = t9;
        $[27] = t17;
    } else {
        t17 = $[27];
    }
    return t17;
}
_s(BadgeShelf, "zBzQ/K9kM7VNPnGI6jPrHTcDicw=");
_c1 = BadgeShelf;
function _BadgeShelfEarnedBadgesReduce(acc, b_2) {
    const badgeCount = b_2.count && b_2.count > 1 ? b_2.count : 1;
    acc[b_2.badgeType] = (acc[b_2.badgeType] || 0) + badgeCount;
    return acc;
}
function _BadgeShelfRegularEarnedMap(b_1) {
    return b_1.badgeType;
}
function _BadgeShelfEarnedBadgesFilter2(b_0) {
    return b_0.isAnti;
}
function _BadgeShelfEarnedBadgesFilter(b) {
    return !b.isAnti;
}
const __TURBOPACK__default__export__ = BadgeShelf;
var _c, _c1;
__turbopack_context__.k.register(_c, "ALL_BADGE_TYPES");
__turbopack_context__.k.register(_c1, "BadgeShelf");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/ContentLockCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContentLockCard",
    ()=>ContentLockCard,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Lock.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
function ContentLockCard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(34);
    if ($[0] !== "7d2efb353b7fd1102bd2cbd310701a74a9b133789c3005a5f798dd43daed7753") {
        for(let $i = 0; $i < 34; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7d2efb353b7fd1102bd2cbd310701a74a9b133789c3005a5f798dd43daed7753";
    }
    const { title, isLocked, requiredXP, currentXP: t1, requiredBadge, requiredCompletion, currentCompletion: t2, requiredPriorUnitId, requiredPriorUnitName, children } = t0;
    const currentXP = t1 === undefined ? 0 : t1;
    const currentCompletion = t2 === undefined ? 0 : t2;
    if (!isLocked) {
        let t3;
        if ($[1] !== children) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: children
            }, void 0, false);
            $[1] = children;
            $[2] = t3;
        } else {
            t3 = $[2];
        }
        return t3;
    }
    let t3;
    if ($[3] !== currentXP || $[4] !== requiredXP) {
        t3 = requiredXP ? Math.min(100, Math.round(currentXP / requiredXP * 100)) : null;
        $[3] = currentXP;
        $[4] = requiredXP;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const xpProgress = t3;
    let t4;
    if ($[6] !== currentCompletion || $[7] !== requiredCompletion) {
        t4 = requiredCompletion ? Math.min(100, Math.round(currentCompletion / requiredCompletion * 100)) : null;
        $[6] = currentCompletion;
        $[7] = requiredCompletion;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const completionProgress = t4;
    let t5;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            border: "1px solid",
            borderColor: "divider",
            opacity: 0.75,
            position: "relative",
            overflow: "visible"
        };
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    let t7;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            display: "flex",
            alignItems: "center",
            gap: 1,
            mb: 1
        };
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            color: "action"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
            lineNumber: 114,
            columnNumber: 10
        }, this);
        $[10] = t6;
        $[11] = t7;
    } else {
        t6 = $[10];
        t7 = $[11];
    }
    let t8;
    if ($[12] !== title) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t6,
            children: [
                t7,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    color: "text.secondary",
                    children: title
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
                    lineNumber: 123,
                    columnNumber: 27
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
            lineNumber: 123,
            columnNumber: 10
        }, this);
        $[12] = title;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: {
                mb: 1
            },
            children: "Unlock requirements:"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
            lineNumber: 131,
            columnNumber: 10
        }, this);
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== currentXP || $[16] !== requiredXP || $[17] !== xpProgress) {
        t10 = requiredXP != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                mb: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "caption",
                    color: "text.secondary",
                    children: [
                        currentXP,
                        " / ",
                        requiredXP,
                        " XP"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
                    lineNumber: 142,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "determinate",
                    value: xpProgress ?? 0,
                    sx: {
                        height: 6,
                        borderRadius: 3
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
                    lineNumber: 142,
                    columnNumber: 103
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
            lineNumber: 140,
            columnNumber: 33
        }, this);
        $[15] = currentXP;
        $[16] = requiredXP;
        $[17] = xpProgress;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    let t11;
    if ($[19] !== requiredBadge) {
        t11 = requiredBadge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            display: "block",
            sx: {
                mb: 0.5
            },
            children: [
                "🏅 Requires badge: ",
                requiredBadge
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
            lineNumber: 155,
            columnNumber: 28
        }, this);
        $[19] = requiredBadge;
        $[20] = t11;
    } else {
        t11 = $[20];
    }
    let t12;
    if ($[21] !== completionProgress || $[22] !== currentCompletion || $[23] !== requiredCompletion) {
        t12 = requiredCompletion != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                mb: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "caption",
                    color: "text.secondary",
                    children: [
                        "Module: ",
                        currentCompletion,
                        "% / ",
                        requiredCompletion,
                        "%"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
                    lineNumber: 167,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "determinate",
                    value: completionProgress ?? 0,
                    sx: {
                        height: 6,
                        borderRadius: 3
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
                    lineNumber: 167,
                    columnNumber: 126
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
            lineNumber: 165,
            columnNumber: 41
        }, this);
        $[21] = completionProgress;
        $[22] = currentCompletion;
        $[23] = requiredCompletion;
        $[24] = t12;
    } else {
        t12 = $[24];
    }
    let t13;
    if ($[25] !== requiredPriorUnitId || $[26] !== requiredPriorUnitName) {
        t13 = requiredPriorUnitId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            display: "block",
            sx: {
                mb: 0.5
            },
            children: [
                "🔗 Complete “",
                requiredPriorUnitName || "the previous unit",
                "” first"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
            lineNumber: 180,
            columnNumber: 34
        }, this);
        $[25] = requiredPriorUnitId;
        $[26] = requiredPriorUnitName;
        $[27] = t13;
    } else {
        t13 = $[27];
    }
    let t14;
    if ($[28] !== t10 || $[29] !== t11 || $[30] !== t12 || $[31] !== t13 || $[32] !== t8) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t5,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    t8,
                    t9,
                    t10,
                    t11,
                    t12,
                    t13
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
                lineNumber: 191,
                columnNumber: 25
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ContentLockCard.tsx",
            lineNumber: 191,
            columnNumber: 11
        }, this);
        $[28] = t10;
        $[29] = t11;
        $[30] = t12;
        $[31] = t13;
        $[32] = t8;
        $[33] = t14;
    } else {
        t14 = $[33];
    }
    return t14;
}
_c = ContentLockCard;
const __TURBOPACK__default__export__ = ContentLockCard;
var _c;
__turbopack_context__.k.register(_c, "ContentLockCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/RankChangeToast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RankChangeToast",
    ()=>RankChangeToast,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TrendingUp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TrendingDown.js [app-client] (ecmascript)");
;
;
;
;
;
;
function RankChangeToast(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18);
    if ($[0] !== "f54591abbf7d01b3eed979d94218737398e7dbf9ec637eac6519b29230b6c0f2") {
        for(let $i = 0; $i < 18; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f54591abbf7d01b3eed979d94218737398e7dbf9ec637eac6519b29230b6c0f2";
    }
    const { open, positionsChanged, newRank, onClose, autoHideDuration: t1 } = t0;
    const autoHideDuration = t1 === undefined ? 3000 : t1;
    const movedUp = positionsChanged > 0;
    let t2;
    if ($[1] !== movedUp) {
        t2 = movedUp ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 40,
            columnNumber: 20
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 40,
            columnNumber: 41
        }, this);
        $[1] = movedUp;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const icon = t2;
    const severity = movedUp ? "success" : "info";
    let t3;
    if ($[3] !== movedUp || $[4] !== newRank || $[5] !== positionsChanged) {
        t3 = movedUp ? `+${positionsChanged} positions on leaderboard! Now #${newRank} 🚀` : `Dropped ${Math.abs(positionsChanged)} position${Math.abs(positionsChanged) > 1 ? "s" : ""} — now #${newRank}`;
        $[3] = movedUp;
        $[4] = newRank;
        $[5] = positionsChanged;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const message = t3;
    let t4;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            vertical: "bottom",
            horizontal: "left"
        };
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            fontWeight: 600
        };
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] !== icon || $[10] !== message || $[11] !== severity) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            severity: severity,
            icon: icon,
            sx: t5,
            children: message
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        $[9] = icon;
        $[10] = message;
        $[11] = severity;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    let t7;
    if ($[13] !== autoHideDuration || $[14] !== onClose || $[15] !== open || $[16] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            autoHideDuration: autoHideDuration,
            anchorOrigin: t4,
            onClose: onClose,
            children: t6
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[13] = autoHideDuration;
        $[14] = onClose;
        $[15] = open;
        $[16] = t6;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    return t7;
}
_c = RankChangeToast;
const __TURBOPACK__default__export__ = RankChangeToast;
var _c;
__turbopack_context__.k.register(_c, "RankChangeToast");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/BadgeCoinFlip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BadgeCoinFlip",
    ()=>BadgeCoinFlip,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * BadgeCoinFlip — CSS 3D coin-flip animation for badge awards.
 *
 * Shows a spinning coin that resolves to the badge emoji.
 *
 * @module BadgeCoinFlip
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BadgeIcon.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function BadgeCoinFlip(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(36);
    if ($[0] !== "0133f0923054bcc9dfb946f1a5dc16979320d1316602d61f9b2d5e504857e7f7") {
        for(let $i = 0; $i < 36; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0133f0923054bcc9dfb946f1a5dc16979320d1316602d61f9b2d5e504857e7f7";
    }
    const { open, badgeEmoji, badgeType, badgeName, badgeDescription, onClose } = t0;
    const [flipped, setFlipped] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    let t2;
    if ($[1] !== open) {
        t1 = ({
            "BadgeCoinFlip[useEffect()]": ()=>{
                if (open) {
                    setFlipped(false);
                    const timer = setTimeout({
                        "BadgeCoinFlip[useEffect() > setTimeout()]": ()=>setFlipped(true)
                    }["BadgeCoinFlip[useEffect() > setTimeout()]"], 100);
                    return ()=>clearTimeout(timer);
                }
            }
        })["BadgeCoinFlip[useEffect()]"];
        t2 = [
            open
        ];
        $[1] = open;
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            textAlign: "center",
            p: 4
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            perspective: "600px",
            mb: 2
        };
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const t5 = flipped ? "rotateY(720deg)" : "rotateY(0deg)";
    let t6;
    if ($[6] !== t5) {
        t6 = {
            width: 80,
            height: 80,
            mx: "auto",
            position: "relative",
            transformStyle: "preserve-3d",
            transition: "transform 0.8s ease-out",
            transform: t5
        };
        $[6] = t5;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            position: "absolute",
            width: "100%",
            height: "100%",
            borderRadius: "50%",
            bgcolor: "warning.light",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backfaceVisibility: "hidden",
            fontSize: "2.5rem"
        };
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] !== badgeEmoji || $[10] !== badgeType || $[11] !== flipped) {
        t8 = badgeType ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeIcon"], {
            badgeType: badgeType,
            size: 64,
            earned: true,
            animate: flipped,
            drawIcon: flipped
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 124,
            columnNumber: 22
        }, this) : badgeEmoji;
        $[9] = badgeEmoji;
        $[10] = badgeType;
        $[11] = flipped;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t7,
            children: t8
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 134,
            columnNumber: 10
        }, this);
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== t6 || $[16] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t4,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t6,
                children: t9
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
                lineNumber: 142,
                columnNumber: 24
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 142,
            columnNumber: 11
        }, this);
        $[15] = t6;
        $[16] = t9;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h6",
            fontWeight: 700,
            sx: {
                mt: 2
            },
            children: "Badge Earned!"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 151,
            columnNumber: 11
        }, this);
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] !== badgeName) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle1",
            fontWeight: 600,
            color: "primary.main",
            children: badgeName
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 160,
            columnNumber: 11
        }, this);
        $[19] = badgeName;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            mt: 1
        };
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    let t14;
    if ($[22] !== badgeDescription) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: t13,
            children: badgeDescription
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 177,
            columnNumber: 11
        }, this);
        $[22] = badgeDescription;
        $[23] = t14;
    } else {
        t14 = $[23];
    }
    let t15;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            mt: 3
        };
        $[24] = t15;
    } else {
        t15 = $[24];
    }
    let t16;
    if ($[25] !== onClose) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "contained",
            onClick: onClose,
            sx: t15,
            children: "Awesome!"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 194,
            columnNumber: 11
        }, this);
        $[25] = onClose;
        $[26] = t16;
    } else {
        t16 = $[26];
    }
    let t17;
    if ($[27] !== t10 || $[28] !== t12 || $[29] !== t14 || $[30] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t10,
                t11,
                t12,
                t14,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 202,
            columnNumber: 11
        }, this);
        $[27] = t10;
        $[28] = t12;
        $[29] = t14;
        $[30] = t16;
        $[31] = t17;
    } else {
        t17 = $[31];
    }
    let t18;
    if ($[32] !== onClose || $[33] !== open || $[34] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            maxWidth: "xs",
            fullWidth: true,
            onClose: onClose,
            children: t17
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 213,
            columnNumber: 11
        }, this);
        $[32] = onClose;
        $[33] = open;
        $[34] = t17;
        $[35] = t18;
    } else {
        t18 = $[35];
    }
    return t18;
}
_s(BadgeCoinFlip, "AET8kBs2SyxC4Y+I5l5KZF+HKtk=");
_c = BadgeCoinFlip;
const __TURBOPACK__default__export__ = BadgeCoinFlip;
var _c;
__turbopack_context__.k.register(_c, "BadgeCoinFlip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/ContentUnlockAnimation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContentUnlockAnimation",
    ()=>ContentUnlockAnimation,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * ContentUnlockAnimation — Shows a padlock-open + shimmer animation
 * when content transitions from locked to unlocked.
 *
 * @module ContentUnlockAnimation
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LockOpen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/LockOpen.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ContentUnlockAnimation(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "879883009fc7268f972d4a73bc498985b943f8397e3421ec723284abb5cfa2c6") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "879883009fc7268f972d4a73bc498985b943f8397e3421ec723284abb5cfa2c6";
    }
    const { show, title, onComplete } = t0;
    const [phase, setPhase] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    let t1;
    let t2;
    if ($[1] !== onComplete || $[2] !== show) {
        t1 = ({
            "ContentUnlockAnimation[useEffect()]": ()=>{
                if (!show) {
                    setPhase("idle");
                    return;
                }
                setPhase("shake");
                const t1$0 = setTimeout({
                    "ContentUnlockAnimation[useEffect() > setTimeout()]": ()=>setPhase("open")
                }["ContentUnlockAnimation[useEffect() > setTimeout()]"], 600);
                const t2$0 = setTimeout({
                    "ContentUnlockAnimation[useEffect() > setTimeout()]": ()=>setPhase("shimmer")
                }["ContentUnlockAnimation[useEffect() > setTimeout()]"], 1200);
                const t3 = setTimeout({
                    "ContentUnlockAnimation[useEffect() > setTimeout()]": ()=>{
                        setPhase("done");
                        onComplete?.();
                    }
                }["ContentUnlockAnimation[useEffect() > setTimeout()]"], 2400);
                return ()=>{
                    clearTimeout(t1$0);
                    clearTimeout(t2$0);
                    clearTimeout(t3);
                };
            }
        })["ContentUnlockAnimation[useEffect()]"];
        t2 = [
            show,
            onComplete
        ];
        $[1] = onComplete;
        $[2] = show;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    if (phase === "idle" || phase === "done") {
        return null;
    }
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 2000,
            bgcolor: "rgba(0,0,0,0.5)",
            backdropFilter: "blur(4px)",
            pointerEvents: "none"
        };
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const t4 = phase === "shake" ? "unlockShake 0.5s ease-in-out" : phase === "open" ? "unlockOpen 0.5s ease-out forwards" : phase === "shimmer" ? "unlockShimmer 1s ease-out forwards" : "none";
    let t5;
    let t6;
    let t7;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            "0%, 100%": {
                transform: "rotate(0deg)"
            },
            "20%": {
                transform: "rotate(-10deg)"
            },
            "40%": {
                transform: "rotate(10deg)"
            },
            "60%": {
                transform: "rotate(-10deg)"
            },
            "80%": {
                transform: "rotate(10deg)"
            }
        };
        t6 = {
            "0%": {
                transform: "scale(1)",
                opacity: 1
            },
            "50%": {
                transform: "scale(1.3)",
                opacity: 1
            },
            "100%": {
                transform: "scale(1.5)",
                opacity: 0.8
            }
        };
        t7 = {
            "0%": {
                transform: "scale(1.5)",
                opacity: 0.8,
                filter: "brightness(1)"
            },
            "50%": {
                transform: "scale(2)",
                opacity: 1,
                filter: "brightness(2)"
            },
            "100%": {
                transform: "scale(1)",
                opacity: 0,
                filter: "brightness(1)"
            }
        };
        $[6] = t5;
        $[7] = t6;
        $[8] = t7;
    } else {
        t5 = $[6];
        t6 = $[7];
        t7 = $[8];
    }
    let t8;
    if ($[9] !== t4) {
        t8 = {
            fontSize: "4rem",
            animation: t4,
            "@keyframes unlockShake": t5,
            "@keyframes unlockOpen": t6,
            "@keyframes unlockShimmer": t7
        };
        $[9] = t4;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LockOpen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: "inherit",
                color: "warning.main"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 176,
            columnNumber: 10
        }, this);
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    let t10;
    if ($[12] !== t8) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t8,
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        $[12] = t8;
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] !== phase || $[15] !== title) {
        t11 = (phase === "open" || phase === "shimmer") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h4",
            sx: {
                color: "white",
                fontWeight: 700,
                mt: 2,
                textAlign: "center",
                animation: "fadeInUp 0.6s ease-out",
                "@keyframes fadeInUp": {
                    "0%": {
                        opacity: 0,
                        transform: "translateY(20px)"
                    },
                    "100%": {
                        opacity: 1,
                        transform: "translateY(0)"
                    }
                }
            },
            children: [
                "🔓 ",
                title,
                " Unlocked!"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 194,
            columnNumber: 56
        }, this);
        $[14] = phase;
        $[15] = title;
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    let t12;
    if ($[17] !== t10 || $[18] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t10,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 219,
            columnNumber: 11
        }, this);
        $[17] = t10;
        $[18] = t11;
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    return t12;
}
_s(ContentUnlockAnimation, "K+JLQG7QosnBzljigzAIGs/3QEU=");
_c = ContentUnlockAnimation;
const __TURBOPACK__default__export__ = ContentUnlockAnimation;
var _c;
__turbopack_context__.k.register(_c, "ContentUnlockAnimation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/GamificationToastLayer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GamificationToastLayer",
    ()=>GamificationToastLayer,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * GamificationToastLayer — Global overlay that renders event-driven
 * micro-interaction toasts: RankChangeToast, BadgeCoinFlip, EasterEggToast,
 * ContentUnlockAnimation, and AnimatedXPCounter.
 *
 * Mount once inside GamificationProviderWrapper in _app.jsx.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$RankChangeToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/RankChangeToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeCoinFlip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BadgeCoinFlip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/EasterEggToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ContentUnlockAnimation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/ContentUnlockAnimation.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
// Badge metadata (mirrors BadgeShelf definitions)
const BADGE_META = {
    FIRST_SUBMISSION: {
        emoji: '📝',
        name: 'First Steps',
        description: 'Submitted your first assignment'
    },
    GOOD_EYE: {
        emoji: '👁️',
        name: 'Good Eye',
        description: 'Found an error others missed'
    },
    QUICK_DRAW: {
        emoji: '⚡',
        name: 'Quick Draw',
        description: 'First to submit in your section'
    },
    SHARPSHOOTER: {
        emoji: '🎯',
        name: 'Sharpshooter',
        description: '3 perfect scores in a row'
    },
    CONSISTENT: {
        emoji: '🔥',
        name: 'Consistent',
        description: '14-day streak'
    },
    TEAM_PLAYER: {
        emoji: '🤝',
        name: 'Team Player',
        description: 'Completed 5 peer reviews'
    },
    DEEP_THINKER: {
        emoji: '🧠',
        name: 'Deep Thinker',
        description: 'Revised after AI feedback 3 times'
    },
    TOP_OF_CLASS: {
        emoji: '🏆',
        name: 'Top of Class',
        description: 'Reached #1 on leaderboard'
    },
    PERFECTIONIST: {
        emoji: '💎',
        name: 'Perfectionist',
        description: '100% on every workbook in a module'
    }
};
function GamificationToastLayer() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(37);
    if ($[0] !== "c2497af0e7c2f3b9613b747180c741686dc88d221a4b5885da94290ad264a18f") {
        for(let $i = 0; $i < 37; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c2497af0e7c2f3b9613b747180c741686dc88d221a4b5885da94290ad264a18f";
    }
    const { xpLogs } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"])();
    const { locks } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContentLock"])();
    const prevXpLogsCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(xpLogs.length);
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const prevLocksRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            open: false,
            positionsChanged: 0,
            newRank: 0
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [rankToast, setRankToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            open: false,
            emoji: "",
            name: "",
            description: ""
        };
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const [badgeFlip, setBadgeFlip] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            open: false,
            message: "",
            xpReward: 0
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const [easterEgg, setEasterEgg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3);
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            show: false,
            title: ""
        };
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const [unlock, setUnlock] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t4);
    let t5;
    let t6;
    if ($[6] !== xpLogs) {
        t5 = ({
            "GamificationToastLayer[useEffect()]": ()=>{
                const prevCount = prevXpLogsCountRef.current;
                if (xpLogs.length <= prevCount) {
                    prevXpLogsCountRef.current = xpLogs.length;
                    return;
                }
                const newEntries = xpLogs.slice(0, xpLogs.length - prevCount);
                prevXpLogsCountRef.current = xpLogs.length;
                for (const entry of newEntries){
                    const reason = entry.xpReason || "";
                    if (reason === "EASTER_EGG") {
                        setEasterEgg({
                            open: true,
                            message: entry.description || "You found a secret!",
                            xpReward: entry.xpAmount || 0
                        });
                    }
                    if (reason === "BADGE_AWARDED") {
                        const badgeType = entry.metadata?.badgeType || "";
                        const meta = BADGE_META[badgeType] || {
                            emoji: "\uD83C\uDFC5",
                            name: "Badge",
                            description: "Achievement unlocked!"
                        };
                        setBadgeFlip({
                            open: true,
                            ...meta
                        });
                    }
                    if (reason === "RANK_CHANGE" || entry.metadata?.rankChange) {
                        const meta_0 = entry.metadata || {};
                        if (meta_0.positionsChanged && meta_0.newRank) {
                            setRankToast({
                                open: true,
                                positionsChanged: meta_0.positionsChanged,
                                newRank: meta_0.newRank
                            });
                        }
                    }
                }
            }
        })["GamificationToastLayer[useEffect()]"];
        t6 = [
            xpLogs
        ];
        $[6] = xpLogs;
        $[7] = t5;
        $[8] = t6;
    } else {
        t5 = $[7];
        t6 = $[8];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7;
    let t8;
    if ($[9] !== locks) {
        t7 = ({
            "GamificationToastLayer[useEffect()]": ()=>{
                const currentLockedIds = locks.filter(_GamificationToastLayerUseEffectLocksFilter).map(_GamificationToastLayerUseEffectAnonymous);
                const prevLockedIds = prevLocksRef.current;
                if (prevLockedIds.length > 0) {
                    const newlyUnlocked = prevLockedIds.filter({
                        "GamificationToastLayer[useEffect() > prevLockedIds.filter()]": (id)=>!currentLockedIds.includes(id)
                    }["GamificationToastLayer[useEffect() > prevLockedIds.filter()]"]);
                    if (newlyUnlocked.length > 0) {
                        const unlockedLock = locks.find({
                            "GamificationToastLayer[useEffect() > locks.find()]": (l_1)=>l_1.contentId === newlyUnlocked[0]
                        }["GamificationToastLayer[useEffect() > locks.find()]"]);
                        setUnlock({
                            show: true,
                            title: unlockedLock?.title || "Content Unlocked!"
                        });
                    }
                }
                prevLocksRef.current = currentLockedIds;
            }
        })["GamificationToastLayer[useEffect()]"];
        t8 = [
            locks
        ];
        $[9] = locks;
        $[10] = t7;
        $[11] = t8;
    } else {
        t7 = $[10];
        t8 = $[11];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t7, t8);
    let t9;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = ({
            "GamificationToastLayer[closeRank]": ()=>setRankToast(_GamificationToastLayerCloseRankSetRankToast)
        })["GamificationToastLayer[closeRank]"];
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    const closeRank = t9;
    let t10;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = ({
            "GamificationToastLayer[closeBadge]": ()=>setBadgeFlip(_GamificationToastLayerCloseBadgeSetBadgeFlip)
        })["GamificationToastLayer[closeBadge]"];
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    const closeBadge = t10;
    let t11;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = ({
            "GamificationToastLayer[closeEgg]": ()=>setEasterEgg(_GamificationToastLayerCloseEggSetEasterEgg)
        })["GamificationToastLayer[closeEgg]"];
        $[14] = t11;
    } else {
        t11 = $[14];
    }
    const closeEgg = t11;
    let t12;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = ({
            "GamificationToastLayer[closeUnlock]": ()=>setUnlock({
                    show: false,
                    title: ""
                })
        })["GamificationToastLayer[closeUnlock]"];
        $[15] = t12;
    } else {
        t12 = $[15];
    }
    const closeUnlock = t12;
    let t13;
    if ($[16] !== rankToast.newRank || $[17] !== rankToast.open || $[18] !== rankToast.positionsChanged) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$RankChangeToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RankChangeToast"], {
            open: rankToast.open,
            positionsChanged: rankToast.positionsChanged,
            newRank: rankToast.newRank,
            onClose: closeRank
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 294,
            columnNumber: 11
        }, this);
        $[16] = rankToast.newRank;
        $[17] = rankToast.open;
        $[18] = rankToast.positionsChanged;
        $[19] = t13;
    } else {
        t13 = $[19];
    }
    let t14;
    if ($[20] !== badgeFlip.description || $[21] !== badgeFlip.emoji || $[22] !== badgeFlip.name || $[23] !== badgeFlip.open) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeCoinFlip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeCoinFlip"], {
            open: badgeFlip.open,
            badgeEmoji: badgeFlip.emoji,
            badgeName: badgeFlip.name,
            badgeDescription: badgeFlip.description,
            onClose: closeBadge
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 304,
            columnNumber: 11
        }, this);
        $[20] = badgeFlip.description;
        $[21] = badgeFlip.emoji;
        $[22] = badgeFlip.name;
        $[23] = badgeFlip.open;
        $[24] = t14;
    } else {
        t14 = $[24];
    }
    let t15;
    if ($[25] !== easterEgg.message || $[26] !== easterEgg.open || $[27] !== easterEgg.xpReward) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EasterEggToast"], {
            open: easterEgg.open,
            message: easterEgg.message,
            xpReward: easterEgg.xpReward,
            onClose: closeEgg
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 315,
            columnNumber: 11
        }, this);
        $[25] = easterEgg.message;
        $[26] = easterEgg.open;
        $[27] = easterEgg.xpReward;
        $[28] = t15;
    } else {
        t15 = $[28];
    }
    let t16;
    if ($[29] !== unlock.show || $[30] !== unlock.title) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ContentUnlockAnimation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentUnlockAnimation"], {
            show: unlock.show,
            title: unlock.title,
            onComplete: closeUnlock
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 325,
            columnNumber: 11
        }, this);
        $[29] = unlock.show;
        $[30] = unlock.title;
        $[31] = t16;
    } else {
        t16 = $[31];
    }
    let t17;
    if ($[32] !== t13 || $[33] !== t14 || $[34] !== t15 || $[35] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t13,
                t14,
                t15,
                t16
            ]
        }, void 0, true);
        $[32] = t13;
        $[33] = t14;
        $[34] = t15;
        $[35] = t16;
        $[36] = t17;
    } else {
        t17 = $[36];
    }
    return t17;
}
_s(GamificationToastLayer, "GUyfkCLISoaMzEQ9fdGupt+uzWo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContentLock"]
    ];
});
_c = GamificationToastLayer;
function _GamificationToastLayerCloseEggSetEasterEgg(s_1) {
    return {
        ...s_1,
        open: false
    };
}
function _GamificationToastLayerCloseBadgeSetBadgeFlip(s_0) {
    return {
        ...s_0,
        open: false
    };
}
function _GamificationToastLayerCloseRankSetRankToast(s) {
    return {
        ...s,
        open: false
    };
}
function _GamificationToastLayerUseEffectAnonymous(l_0) {
    return l_0.contentId;
}
function _GamificationToastLayerUseEffectLocksFilter(l) {
    return l.isLocked;
}
const __TURBOPACK__default__export__ = GamificationToastLayer;
var _c;
__turbopack_context__.k.register(_c, "GamificationToastLayer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/gamificationProviderWrapper.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GamificationProviderWrapper",
    ()=>GamificationProviderWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$GamificationToastLayer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/GamificationToastLayer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function GamificationProviderWrapper(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "7151689139be499929ce124491916299acef4963acc9fed72473e0c8f3c8605b") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7151689139be499929ce124491916299acef4963acc9fed72473e0c8f3c8605b";
    }
    const { children, cohortId: cohortIdProp } = t0;
    const { user, session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const client = t1;
    const isInstructor = session?.groups?.includes("Instructors") || session?.groups?.includes("Admins");
    const studentId = isInstructor ? "" : user?.username || user?.attributes?.sub || "";
    const { sections, assignments } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {};
    session?.groups;
    let t2;
    if ($[2] !== cohortIdProp || $[3] !== session?.groups) {
        bb0: {
            if (cohortIdProp) {
                t2 = cohortIdProp;
                break bb0;
            }
            const groups = session?.groups || [];
            for (const group of groups){
                const match = group.match(/^section-(.+?)-(learners|instructors)$/);
                if (match) {
                    t2 = match[1];
                    break bb0;
                }
            }
            t2 = undefined;
        }
        $[2] = cohortIdProp;
        $[3] = session?.groups;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const cohortId = t2;
    let t3;
    if ($[5] !== studentId) {
        t3 = studentId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$GamificationToastLayer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationToastLayer"], {}, void 0, false, {
            fileName: "[project]/src/context/gamificationProviderWrapper.jsx",
            lineNumber: 76,
            columnNumber: 23
        }, this);
        $[5] = studentId;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== assignments || $[8] !== children || $[9] !== cohortId || $[10] !== sections || $[11] !== studentId || $[12] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationProvider"], {
            client: client,
            studentId: studentId,
            cohortId: cohortId,
            sections: sections,
            assignments: assignments,
            children: [
                children,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/src/context/gamificationProviderWrapper.jsx",
            lineNumber: 84,
            columnNumber: 10
        }, this);
        $[7] = assignments;
        $[8] = children;
        $[9] = cohortId;
        $[10] = sections;
        $[11] = studentId;
        $[12] = t3;
        $[13] = t4;
    } else {
        t4 = $[13];
    }
    return t4;
}
_s(GamificationProviderWrapper, "KAg+X7S5wlQvcXKzXEV+lune0l8=");
_c = GamificationProviderWrapper;
var _c;
__turbopack_context__.k.register(_c, "GamificationProviderWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PracticeDrillConfigPopup
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview PracticeDrillConfigPopup — Source selection and configuration
 * popup shown before starting a practice drill. Lets students toggle content
 * sources (vocabulary, questions, text, documents) and set question count.
 * All switches default to ON. At least one source must be enabled.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Switch/Switch.js [app-client] (ecmascript) <export default as Switch>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Select/Select.js [app-client] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControl/FormControl.js [app-client] (ecmascript) <export default as FormControl>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputLabel/InputLabel.js [app-client] (ecmascript) <export default as InputLabel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MenuBook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MenuBook.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Quiz$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Quiz.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TextSnippet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TextSnippet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Description.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Groups$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Groups.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
const SOURCE_ROWS = [
    {
        key: 'vocabulary',
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MenuBook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 82,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
        labelKey: 'practiceDrill.config.vocabulary',
        descriptionKey: 'practiceDrill.config.vocabularyDesc',
        countSuffix: 'w'
    },
    {
        key: 'questions',
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Quiz$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 88,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
        labelKey: 'practiceDrill.config.questions',
        descriptionKey: 'practiceDrill.config.questionsDesc',
        countSuffix: 'q'
    },
    {
        key: 'text',
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TextSnippet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 94,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
        labelKey: 'practiceDrill.config.text',
        descriptionKey: 'practiceDrill.config.textDesc',
        countSuffix: 'b'
    },
    {
        key: 'documents',
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 100,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
        labelKey: 'practiceDrill.config.documents',
        descriptionKey: 'practiceDrill.config.documentsDesc',
        countSuffix: 'd'
    }
];
const COUNT_OPTIONS = [
    5,
    10,
    15,
    20
];
function PracticeDrillConfigPopup(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(195);
    if ($[0] !== "d106db5f6aa486b9c3fcccfb23c2ec5a7caa5daf627ef9b4a2f2f95ff16744fb") {
        for(let $i = 0; $i < 195; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d106db5f6aa486b9c3fcccfb23c2ec5a7caa5daf627ef9b4a2f2f95ff16744fb";
    }
    const { open, onClose, onStart, unitName, vocabularyCount, questionCount, textBlockCount, documentCount, coverageSnapshot, initialSources, initialDrillType, loading: t1 } = t0;
    const loading = t1 === undefined ? false : t1;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    let t2;
    if ($[1] !== documentCount || $[2] !== questionCount || $[3] !== textBlockCount || $[4] !== vocabularyCount) {
        t2 = {
            vocabulary: vocabularyCount,
            questions: questionCount,
            text: textBlockCount,
            documents: documentCount
        };
        $[1] = documentCount;
        $[2] = questionCount;
        $[3] = textBlockCount;
        $[4] = vocabularyCount;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    const sourceCounts = t2;
    let t3;
    if ($[6] !== documentCount || $[7] !== initialSources?.documents || $[8] !== initialSources?.questions || $[9] !== initialSources?.text || $[10] !== initialSources?.vocabulary || $[11] !== questionCount || $[12] !== textBlockCount || $[13] !== vocabularyCount) {
        t3 = ({
            "PracticeDrillConfigPopup[useState()]": ()=>({
                    vocabulary: initialSources?.vocabulary ?? vocabularyCount > 0,
                    questions: initialSources?.questions ?? questionCount > 0,
                    text: initialSources?.text ?? textBlockCount > 0,
                    documents: initialSources?.documents ?? documentCount > 0
                })
        })["PracticeDrillConfigPopup[useState()]"];
        $[6] = documentCount;
        $[7] = initialSources?.documents;
        $[8] = initialSources?.questions;
        $[9] = initialSources?.text;
        $[10] = initialSources?.vocabulary;
        $[11] = questionCount;
        $[12] = textBlockCount;
        $[13] = vocabularyCount;
        $[14] = t3;
    } else {
        t3 = $[14];
    }
    const [sources, setSources] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3);
    const [count, setCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(10);
    const [drillType, setDrillType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialDrillType ?? "mixed");
    const [collaborative, setCollaborative] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [maxParticipants, setMaxParticipants] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(5);
    let t4;
    if ($[15] !== documentCount || $[16] !== initialDrillType || $[17] !== initialSources?.documents || $[18] !== initialSources?.questions || $[19] !== initialSources?.text || $[20] !== initialSources?.vocabulary || $[21] !== open || $[22] !== questionCount || $[23] !== textBlockCount || $[24] !== vocabularyCount) {
        t4 = ({
            "PracticeDrillConfigPopup[useEffect()]": ()=>{
                if (open) {
                    setSources({
                        vocabulary: initialSources?.vocabulary ?? vocabularyCount > 0,
                        questions: initialSources?.questions ?? questionCount > 0,
                        text: initialSources?.text ?? textBlockCount > 0,
                        documents: initialSources?.documents ?? documentCount > 0
                    });
                    setCount(10);
                    setDrillType(initialDrillType ?? "mixed");
                    setCollaborative(false);
                    setMaxParticipants(5);
                }
            }
        })["PracticeDrillConfigPopup[useEffect()]"];
        $[15] = documentCount;
        $[16] = initialDrillType;
        $[17] = initialSources?.documents;
        $[18] = initialSources?.questions;
        $[19] = initialSources?.text;
        $[20] = initialSources?.vocabulary;
        $[21] = open;
        $[22] = questionCount;
        $[23] = textBlockCount;
        $[24] = vocabularyCount;
        $[25] = t4;
    } else {
        t4 = $[25];
    }
    let t5;
    if ($[26] !== documentCount || $[27] !== initialDrillType || $[28] !== initialSources || $[29] !== open || $[30] !== questionCount || $[31] !== textBlockCount || $[32] !== vocabularyCount) {
        t5 = [
            open,
            vocabularyCount,
            questionCount,
            textBlockCount,
            documentCount,
            initialSources,
            initialDrillType
        ];
        $[26] = documentCount;
        $[27] = initialDrillType;
        $[28] = initialSources;
        $[29] = open;
        $[30] = questionCount;
        $[31] = textBlockCount;
        $[32] = vocabularyCount;
        $[33] = t5;
    } else {
        t5 = $[33];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t4, t5);
    let t6;
    if ($[34] !== sourceCounts) {
        t6 = ({
            "PracticeDrillConfigPopup[handleToggle]": (key)=>{
                if (sourceCounts[key] === 0) {
                    return;
                }
                setSources({
                    "PracticeDrillConfigPopup[handleToggle > setSources()]": (prev)=>({
                            ...prev,
                            [key]: !prev[key]
                        })
                }["PracticeDrillConfigPopup[handleToggle > setSources()]"]);
            }
        })["PracticeDrillConfigPopup[handleToggle]"];
        $[34] = sourceCounts;
        $[35] = t6;
    } else {
        t6 = $[35];
    }
    const handleToggle = t6;
    const atLeastOneEnabled = Object.values(sources).some(Boolean);
    let t7;
    bb0: {
        if (!coverageSnapshot) {
            t7 = null;
            break bb0;
        }
        let total = 0;
        let covered = 0;
        for (const key_0 of Object.keys(sources)){
            if (sources[key_0] && coverageSnapshot[key_0]) {
                total = total + coverageSnapshot[key_0].total;
                covered = covered + coverageSnapshot[key_0].covered;
            }
        }
        let t8;
        if ($[36] !== covered || $[37] !== total) {
            t8 = total > 0 ? Math.round(covered / total * 100) : 0;
            $[36] = covered;
            $[37] = total;
            $[38] = t8;
        } else {
            t8 = $[38];
        }
        let t9;
        if ($[39] !== covered || $[40] !== t8 || $[41] !== total) {
            t9 = {
                total,
                covered,
                percent: t8
            };
            $[39] = covered;
            $[40] = t8;
            $[41] = total;
            $[42] = t9;
        } else {
            t9 = $[42];
        }
        t7 = t9;
    }
    const coverageTotals = t7;
    let t8;
    if ($[43] !== collaborative || $[44] !== count || $[45] !== drillType || $[46] !== maxParticipants || $[47] !== onStart || $[48] !== sources) {
        t8 = ({
            "PracticeDrillConfigPopup[handleStart]": ()=>{
                onStart({
                    sources,
                    count,
                    drillType,
                    collaborative,
                    maxParticipants: collaborative ? maxParticipants : undefined
                });
            }
        })["PracticeDrillConfigPopup[handleStart]"];
        $[43] = collaborative;
        $[44] = count;
        $[45] = drillType;
        $[46] = maxParticipants;
        $[47] = onStart;
        $[48] = sources;
        $[49] = t8;
    } else {
        t8 = $[49];
    }
    const handleStart = t8;
    let t9;
    if ($[50] !== t || $[51] !== unitName) {
        t9 = t("practiceDrill.config.title", {
            unitName
        });
        $[50] = t;
        $[51] = unitName;
        $[52] = t9;
    } else {
        t9 = $[52];
    }
    let t10;
    if ($[53] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
            id: "practice-drill-config-title",
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 325,
            columnNumber: 11
        }, this);
        $[53] = t9;
        $[54] = t10;
    } else {
        t10 = $[54];
    }
    let t11;
    if ($[55] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            mb: 2
        };
        $[55] = t11;
    } else {
        t11 = $[55];
    }
    let t12;
    if ($[56] !== t) {
        t12 = t("practiceDrill.config.subtitle", "Choose what to practice:");
        $[56] = t;
        $[57] = t12;
    } else {
        t12 = $[57];
    }
    let t13;
    if ($[58] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            sx: t11,
            children: t12
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 350,
            columnNumber: 11
        }, this);
        $[58] = t12;
        $[59] = t13;
    } else {
        t13 = $[59];
    }
    let t14;
    if ($[60] !== coverageSnapshot || $[61] !== handleToggle || $[62] !== sourceCounts || $[63] !== sources || $[64] !== t) {
        t14 = SOURCE_ROWS.map({
            "PracticeDrillConfigPopup[SOURCE_ROWS.map()]": (row)=>{
                const itemCount = sourceCounts[row.key];
                const isDisabled = itemCount === 0;
                const isEnabled = sources[row.key];
                const coverage = coverageSnapshot?.[row.key];
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        p: 1.5,
                        mb: 1,
                        borderRadius: 1,
                        border: "1px solid",
                        borderColor: isEnabled ? "primary.main" : "divider",
                        opacity: isDisabled ? 0.5 : 1,
                        bgcolor: isEnabled ? "action.selected" : "transparent"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                alignItems: "center",
                                gap: 1.5,
                                flex: 1
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        color: isEnabled ? "primary.main" : "text.secondary"
                                    },
                                    children: row.icon
                                }, void 0, false, {
                                    fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                                    lineNumber: 380,
                                    columnNumber: 14
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "body1",
                                            fontWeight: 500,
                                            children: t(row.labelKey, row.key)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                                            lineNumber: 382,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "caption",
                                            color: "text.secondary",
                                            children: t(row.descriptionKey, "")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                                            lineNumber: 382,
                                            columnNumber: 121
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                                    lineNumber: 382,
                                    columnNumber: 32
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                            lineNumber: 375,
                            columnNumber: 12
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                alignItems: "center",
                                gap: 1
                            },
                            children: [
                                coverage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                    size: "small",
                                    label: `${coverage.covered}/${coverage.total}`,
                                    color: coverage.covered === coverage.total ? "success" : "default",
                                    variant: "outlined"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                                    lineNumber: 386,
                                    columnNumber: 27
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                    size: "small",
                                    label: `${itemCount}${row.countSuffix}`,
                                    variant: "outlined"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                                    lineNumber: 386,
                                    columnNumber: 184
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
                                    checked: isEnabled,
                                    onChange: {
                                        "PracticeDrillConfigPopup[SOURCE_ROWS.map() > <Switch>.onChange]": ()=>handleToggle(row.key)
                                    }["PracticeDrillConfigPopup[SOURCE_ROWS.map() > <Switch>.onChange]"],
                                    disabled: isDisabled,
                                    inputProps: {
                                        "aria-label": t(row.labelKey, row.key)
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                                    lineNumber: 386,
                                    columnNumber: 265
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                            lineNumber: 382,
                            columnNumber: 226
                        }, this)
                    ]
                }, row.key, true, {
                    fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                    lineNumber: 364,
                    columnNumber: 16
                }, this);
            }
        }["PracticeDrillConfigPopup[SOURCE_ROWS.map()]"]);
        $[60] = coverageSnapshot;
        $[61] = handleToggle;
        $[62] = sourceCounts;
        $[63] = sources;
        $[64] = t;
        $[65] = t14;
    } else {
        t14 = $[65];
    }
    let t15;
    if ($[66] !== coverageTotals || $[67] !== t) {
        t15 = coverageTotals && coverageTotals.total > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                mt: 2,
                mb: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "body2",
                    color: "text.secondary",
                    children: t("practiceDrill.config.coverage", {
                        covered: coverageTotals.covered,
                        total: coverageTotals.total,
                        percent: coverageTotals.percent
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                    lineNumber: 407,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                    variant: "determinate",
                    value: coverageTotals.percent,
                    sx: {
                        mt: 0.5,
                        height: 8,
                        borderRadius: 4
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                    lineNumber: 411,
                    columnNumber: 25
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 404,
            columnNumber: 57
        }, this);
        $[66] = coverageTotals;
        $[67] = t;
        $[68] = t15;
    } else {
        t15 = $[68];
    }
    let t16;
    if ($[69] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            mt: 2,
            display: "flex",
            gap: 2
        };
        $[69] = t16;
    } else {
        t16 = $[69];
    }
    let t17;
    if ($[70] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = {
            minWidth: 180
        };
        $[70] = t17;
    } else {
        t17 = $[70];
    }
    let t18;
    if ($[71] !== t) {
        t18 = t("practiceDrill.config.questionCount", "Number of questions");
        $[71] = t;
        $[72] = t18;
    } else {
        t18 = $[72];
    }
    let t19;
    if ($[73] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__["InputLabel"], {
            id: "drill-count-label",
            children: t18
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 452,
            columnNumber: 11
        }, this);
        $[73] = t18;
        $[74] = t19;
    } else {
        t19 = $[74];
    }
    let t20;
    if ($[75] !== t) {
        t20 = t("practiceDrill.config.questionCount", "Number of questions");
        $[75] = t;
        $[76] = t20;
    } else {
        t20 = $[76];
    }
    let t21;
    let t22;
    if ($[77] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = ({
            "PracticeDrillConfigPopup[<Select>.onChange]": (e)=>setCount(Number(e.target.value))
        })["PracticeDrillConfigPopup[<Select>.onChange]"];
        t22 = COUNT_OPTIONS.map(_PracticeDrillConfigPopupCOUNT_OPTIONSMap);
        $[77] = t21;
        $[78] = t22;
    } else {
        t21 = $[77];
        t22 = $[78];
    }
    let t23;
    if ($[79] !== count || $[80] !== t20) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
            labelId: "drill-count-label",
            value: count,
            label: t20,
            onChange: t21,
            children: t22
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 481,
            columnNumber: 11
        }, this);
        $[79] = count;
        $[80] = t20;
        $[81] = t23;
    } else {
        t23 = $[81];
    }
    let t24;
    if ($[82] !== t19 || $[83] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__["FormControl"], {
            size: "small",
            sx: t17,
            children: [
                t19,
                t23
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 490,
            columnNumber: 11
        }, this);
        $[82] = t19;
        $[83] = t23;
        $[84] = t24;
    } else {
        t24 = $[84];
    }
    let t25;
    if ($[85] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = {
            minWidth: 180
        };
        $[85] = t25;
    } else {
        t25 = $[85];
    }
    let t26;
    if ($[86] !== t) {
        t26 = t("practiceDrill.config.drillType", "Drill type");
        $[86] = t;
        $[87] = t26;
    } else {
        t26 = $[87];
    }
    let t27;
    if ($[88] !== t26) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__["InputLabel"], {
            id: "drill-type-label",
            children: t26
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 516,
            columnNumber: 11
        }, this);
        $[88] = t26;
        $[89] = t27;
    } else {
        t27 = $[89];
    }
    let t28;
    if ($[90] !== t) {
        t28 = t("practiceDrill.config.drillType", "Drill type");
        $[90] = t;
        $[91] = t28;
    } else {
        t28 = $[91];
    }
    let t29;
    if ($[92] === Symbol.for("react.memo_cache_sentinel")) {
        t29 = ({
            "PracticeDrillConfigPopup[<Select>.onChange]": (e_0)=>setDrillType(e_0.target.value)
        })["PracticeDrillConfigPopup[<Select>.onChange]"];
        $[92] = t29;
    } else {
        t29 = $[92];
    }
    let t30;
    if ($[93] !== t) {
        t30 = t("practiceDrill.config.mixed", "Mixed");
        $[93] = t;
        $[94] = t30;
    } else {
        t30 = $[94];
    }
    let t31;
    if ($[95] !== t30) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            value: "mixed",
            children: t30
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 549,
            columnNumber: 11
        }, this);
        $[95] = t30;
        $[96] = t31;
    } else {
        t31 = $[96];
    }
    let t32;
    if ($[97] !== t) {
        t32 = t("practiceDrill.config.vocabularyType", "Vocabulary");
        $[97] = t;
        $[98] = t32;
    } else {
        t32 = $[98];
    }
    let t33;
    if ($[99] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            value: "vocabulary",
            children: t32
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 565,
            columnNumber: 11
        }, this);
        $[99] = t32;
        $[100] = t33;
    } else {
        t33 = $[100];
    }
    let t34;
    if ($[101] !== t) {
        t34 = t("practiceDrill.config.comprehension", "Comprehension");
        $[101] = t;
        $[102] = t34;
    } else {
        t34 = $[102];
    }
    let t35;
    if ($[103] !== t34) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            value: "comprehension",
            children: t34
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 581,
            columnNumber: 11
        }, this);
        $[103] = t34;
        $[104] = t35;
    } else {
        t35 = $[104];
    }
    let t36;
    if ($[105] !== t) {
        t36 = t("practiceDrill.config.review", "Review mistakes");
        $[105] = t;
        $[106] = t36;
    } else {
        t36 = $[106];
    }
    let t37;
    if ($[107] !== t36) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            value: "review",
            children: t36
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 597,
            columnNumber: 11
        }, this);
        $[107] = t36;
        $[108] = t37;
    } else {
        t37 = $[108];
    }
    let t38;
    if ($[109] !== drillType || $[110] !== t28 || $[111] !== t31 || $[112] !== t33 || $[113] !== t35 || $[114] !== t37) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
            labelId: "drill-type-label",
            value: drillType,
            label: t28,
            onChange: t29,
            children: [
                t31,
                t33,
                t35,
                t37
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 605,
            columnNumber: 11
        }, this);
        $[109] = drillType;
        $[110] = t28;
        $[111] = t31;
        $[112] = t33;
        $[113] = t35;
        $[114] = t37;
        $[115] = t38;
    } else {
        t38 = $[115];
    }
    let t39;
    if ($[116] !== t27 || $[117] !== t38) {
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__["FormControl"], {
            size: "small",
            sx: t25,
            children: [
                t27,
                t38
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 618,
            columnNumber: 11
        }, this);
        $[116] = t27;
        $[117] = t38;
        $[118] = t39;
    } else {
        t39 = $[118];
    }
    let t40;
    if ($[119] !== t24 || $[120] !== t39) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t16,
            children: [
                t24,
                t39
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 627,
            columnNumber: 11
        }, this);
        $[119] = t24;
        $[120] = t39;
        $[121] = t40;
    } else {
        t40 = $[121];
    }
    const t41 = collaborative ? "primary.main" : "divider";
    const t42 = collaborative ? "action.selected" : "transparent";
    let t43;
    if ($[122] !== t41 || $[123] !== t42) {
        t43 = {
            mt: 2,
            p: 1.5,
            borderRadius: 1,
            border: "1px solid",
            borderColor: t41,
            bgcolor: t42
        };
        $[122] = t41;
        $[123] = t42;
        $[124] = t43;
    } else {
        t43 = $[124];
    }
    let t44;
    if ($[125] === Symbol.for("react.memo_cache_sentinel")) {
        t44 = {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between"
        };
        $[125] = t44;
    } else {
        t44 = $[125];
    }
    let t45;
    if ($[126] === Symbol.for("react.memo_cache_sentinel")) {
        t45 = {
            display: "flex",
            alignItems: "center",
            gap: 1.5
        };
        $[126] = t45;
    } else {
        t45 = $[126];
    }
    const t46 = collaborative ? "primary" : "action";
    let t47;
    if ($[127] !== t46) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Groups$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            color: t46
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 677,
            columnNumber: 11
        }, this);
        $[127] = t46;
        $[128] = t47;
    } else {
        t47 = $[128];
    }
    let t48;
    if ($[129] !== t) {
        t48 = t("practiceDrill.config.studyTogether", "Study Together");
        $[129] = t;
        $[130] = t48;
    } else {
        t48 = $[130];
    }
    let t49;
    if ($[131] !== t48) {
        t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body1",
            fontWeight: 500,
            children: t48
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 693,
            columnNumber: 11
        }, this);
        $[131] = t48;
        $[132] = t49;
    } else {
        t49 = $[132];
    }
    let t50;
    if ($[133] !== t) {
        t50 = t("practiceDrill.config.studyTogetherDesc", "Practice with classmates in real-time. A room code will be created to share.");
        $[133] = t;
        $[134] = t50;
    } else {
        t50 = $[134];
    }
    let t51;
    if ($[135] !== t50) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            children: t50
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 709,
            columnNumber: 11
        }, this);
        $[135] = t50;
        $[136] = t51;
    } else {
        t51 = $[136];
    }
    let t52;
    if ($[137] !== t49 || $[138] !== t51) {
        t52 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: [
                t49,
                t51
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 717,
            columnNumber: 11
        }, this);
        $[137] = t49;
        $[138] = t51;
        $[139] = t52;
    } else {
        t52 = $[139];
    }
    let t53;
    if ($[140] !== t47 || $[141] !== t52) {
        t53 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t45,
            children: [
                t47,
                t52
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 726,
            columnNumber: 11
        }, this);
        $[140] = t47;
        $[141] = t52;
        $[142] = t53;
    } else {
        t53 = $[142];
    }
    let t54;
    if ($[143] === Symbol.for("react.memo_cache_sentinel")) {
        t54 = ({
            "PracticeDrillConfigPopup[<Switch>.onChange]": ()=>setCollaborative(_PracticeDrillConfigPopupSwitchOnChangeSetCollaborative)
        })["PracticeDrillConfigPopup[<Switch>.onChange]"];
        $[143] = t54;
    } else {
        t54 = $[143];
    }
    let t55;
    if ($[144] !== t) {
        t55 = t("practiceDrill.config.studyTogether", "Study Together");
        $[144] = t;
        $[145] = t55;
    } else {
        t55 = $[145];
    }
    let t56;
    if ($[146] !== t55) {
        t56 = {
            "aria-label": t55
        };
        $[146] = t55;
        $[147] = t56;
    } else {
        t56 = $[147];
    }
    let t57;
    if ($[148] !== collaborative || $[149] !== t56) {
        t57 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
            checked: collaborative,
            onChange: t54,
            inputProps: t56
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 762,
            columnNumber: 11
        }, this);
        $[148] = collaborative;
        $[149] = t56;
        $[150] = t57;
    } else {
        t57 = $[150];
    }
    let t58;
    if ($[151] !== t53 || $[152] !== t57) {
        t58 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t44,
            children: [
                t53,
                t57
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 771,
            columnNumber: 11
        }, this);
        $[151] = t53;
        $[152] = t57;
        $[153] = t58;
    } else {
        t58 = $[153];
    }
    let t59;
    if ($[154] !== collaborative || $[155] !== maxParticipants || $[156] !== t) {
        t59 = collaborative && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                mt: 1.5,
                pl: 5
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__["FormControl"], {
                size: "small",
                sx: {
                    minWidth: 160
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__["InputLabel"], {
                        id: "max-participants-label",
                        children: t("practiceDrill.config.maxParticipants", "Max participants")
                    }, void 0, false, {
                        fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                        lineNumber: 785,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                        labelId: "max-participants-label",
                        value: maxParticipants,
                        label: t("practiceDrill.config.maxParticipants", "Max participants"),
                        onChange: {
                            "PracticeDrillConfigPopup[<Select>.onChange]": (e_1)=>setMaxParticipants(Number(e_1.target.value))
                        }["PracticeDrillConfigPopup[<Select>.onChange]"],
                        children: [
                            2,
                            3,
                            5,
                            8,
                            10
                        ].map(_PracticeDrillConfigPopupAnonymous)
                    }, void 0, false, {
                        fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                        lineNumber: 785,
                        columnNumber: 126
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
                lineNumber: 783,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 780,
            columnNumber: 28
        }, this);
        $[154] = collaborative;
        $[155] = maxParticipants;
        $[156] = t;
        $[157] = t59;
    } else {
        t59 = $[157];
    }
    let t60;
    if ($[158] !== t43 || $[159] !== t58 || $[160] !== t59) {
        t60 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t43,
            children: [
                t58,
                t59
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 797,
            columnNumber: 11
        }, this);
        $[158] = t43;
        $[159] = t58;
        $[160] = t59;
        $[161] = t60;
    } else {
        t60 = $[161];
    }
    let t61;
    if ($[162] !== atLeastOneEnabled || $[163] !== t) {
        t61 = !atLeastOneEnabled && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "error",
            sx: {
                mt: 2
            },
            children: t("practiceDrill.config.noSourcesWarning", "Enable at least one content source to start practicing.")
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 807,
            columnNumber: 33
        }, this);
        $[162] = atLeastOneEnabled;
        $[163] = t;
        $[164] = t61;
    } else {
        t61 = $[164];
    }
    let t62;
    if ($[165] !== t13 || $[166] !== t14 || $[167] !== t15 || $[168] !== t40 || $[169] !== t60 || $[170] !== t61) {
        t62 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
            children: [
                t13,
                t14,
                t15,
                t40,
                t60,
                t61
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 818,
            columnNumber: 11
        }, this);
        $[165] = t13;
        $[166] = t14;
        $[167] = t15;
        $[168] = t40;
        $[169] = t60;
        $[170] = t61;
        $[171] = t62;
    } else {
        t62 = $[171];
    }
    let t63;
    if ($[172] === Symbol.for("react.memo_cache_sentinel")) {
        t63 = {
            px: 3,
            pb: 2
        };
        $[172] = t63;
    } else {
        t63 = $[172];
    }
    let t64;
    if ($[173] !== t) {
        t64 = t("practiceDrill.config.cancel", "Cancel");
        $[173] = t;
        $[174] = t64;
    } else {
        t64 = $[174];
    }
    let t65;
    if ($[175] !== loading || $[176] !== onClose || $[177] !== t64) {
        t65 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            onClick: onClose,
            disabled: loading,
            children: t64
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 849,
            columnNumber: 11
        }, this);
        $[175] = loading;
        $[176] = onClose;
        $[177] = t64;
        $[178] = t65;
    } else {
        t65 = $[178];
    }
    const t66 = !atLeastOneEnabled || loading;
    let t67;
    if ($[179] !== loading || $[180] !== t) {
        t67 = loading ? t("practiceDrill.config.generating", "Generating...") : t("practiceDrill.config.start", "Start Practice");
        $[179] = loading;
        $[180] = t;
        $[181] = t67;
    } else {
        t67 = $[181];
    }
    let t68;
    if ($[182] !== handleStart || $[183] !== t66 || $[184] !== t67) {
        t68 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            variant: "contained",
            onClick: handleStart,
            disabled: t66,
            children: t67
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 869,
            columnNumber: 11
        }, this);
        $[182] = handleStart;
        $[183] = t66;
        $[184] = t67;
        $[185] = t68;
    } else {
        t68 = $[185];
    }
    let t69;
    if ($[186] !== t65 || $[187] !== t68) {
        t69 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
            sx: t63,
            children: [
                t65,
                t68
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 879,
            columnNumber: 11
        }, this);
        $[186] = t65;
        $[187] = t68;
        $[188] = t69;
    } else {
        t69 = $[188];
    }
    let t70;
    if ($[189] !== onClose || $[190] !== open || $[191] !== t10 || $[192] !== t62 || $[193] !== t69) {
        t70 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
            open: open,
            onClose: onClose,
            maxWidth: "sm",
            fullWidth: true,
            "aria-labelledby": "practice-drill-config-title",
            children: [
                t10,
                t62,
                t69
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
            lineNumber: 888,
            columnNumber: 11
        }, this);
        $[189] = onClose;
        $[190] = open;
        $[191] = t10;
        $[192] = t62;
        $[193] = t69;
        $[194] = t70;
    } else {
        t70 = $[194];
    }
    return t70;
}
_s(PracticeDrillConfigPopup, "T3UDhGR92DpMnmEisy32A7qoWRk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = PracticeDrillConfigPopup;
function _PracticeDrillConfigPopupAnonymous(n_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
        value: n_0,
        children: n_0
    }, n_0, false, {
        fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
        lineNumber: 901,
        columnNumber: 10
    }, this);
}
function _PracticeDrillConfigPopupSwitchOnChangeSetCollaborative(prev_0) {
    return !prev_0;
}
function _PracticeDrillConfigPopupCOUNT_OPTIONSMap(n) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
        value: n,
        children: n
    }, n, false, {
        fileName: "[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx",
        lineNumber: 907,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "PracticeDrillConfigPopup");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx [app-client] (ecmascript) <export default as PracticeDrillConfigPopup>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PracticeDrillConfigPopup",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillConfigPopup$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillConfigPopup$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx [app-client] (ecmascript)");
}),
"[project]/app/actions/data:b0c48b [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "listSharedWithMe",
    ()=>$$RSC_SERVER_ACTION_3
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"4082997868e6e55b6d3432096dbff0265c6d62bb03":{"name":"listSharedWithMe"}},"app/actions/collaborator.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4082997868e6e55b6d3432096dbff0265c6d62bb03", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "listSharedWithMe");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:d36854 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "listCommunityUnits",
    ()=>$$RSC_SERVER_ACTION_4
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40891abc93a90bed09d711c2286c4f54546d2f8b9c":{"name":"listCommunityUnits"}},"app/actions/collaborator.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40891abc93a90bed09d711c2286c4f54546d2f8b9c", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "listCommunityUnits");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:8709a2 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "forkUnit",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"704ae6f797cb0eb1c2108b150cf8cb7550b5d610dc":{"name":"forkUnit"}},"app/actions/forkUnit.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("704ae6f797cb0eb1c2108b150cf8cb7550b5d610dc", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "forkUnit");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[locale]/units/page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript) <export default as CardContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tabs/Tabs.js [app-client] (ecmascript) <export default as Tabs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tab/Tab.js [app-client] (ecmascript) <export default as Tab>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Add.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Edit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EditNote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/EditNote.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$FitnessCenter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/FitnessCenter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LazyCardMedia.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CommunityUnitCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/CommunityUnitCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SharedUnitCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/SharedUnitCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useChatPageContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeShelf$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BadgeShelf.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ContentLockCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/ContentLockCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationProviderWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationProviderWrapper.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillConfigPopup$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PracticeDrillConfigPopup$3e$__ = __turbopack_context__.i("[project]/src/components/PracticeDrill/PracticeDrillConfigPopup.tsx [app-client] (ecmascript) <export default as PracticeDrillConfigPopup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PracticeDrillDialog$3e$__ = __turbopack_context__.i("[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx [app-client] (ecmascript) <export default as PracticeDrillDialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/apis/fetchAuthSession.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$b0c48b__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:b0c48b [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$d36854__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:d36854 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$8709a2__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:8709a2 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function Units() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("pages");
    const { user, isLoading: authLoading } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {
        user: undefined,
        isLoading: true
    };
    /**
   * Units is a page that displays a list of units.
   * For Instructor users, it displays a list of units they are teaching.
   * For Student users, it displays a list of units they are enrolled in.
   * For Admin users, it displays a list of all units.
   *
   * Units can be created by Instructors and Admins.
   * Units can be edited by Instructors and Admins.
   * Units can be deleted by Admins.
   *
   * Units can be searched by name.
   * Units can be filtered by status (draft, published, inactive, archived).
   * Units can be sorted by name, status, and date created.
   *
   * Units can be exported as a CSV file.
   * Units can be imported as a CSV file.
   *
   * Units can be archived by Instructors and Admins.
   * Units can be unarchived by Instructors and Admins.
   * Units can be deleted by Admins.
   *
   * Units can be copied by Instructors and Admins.
   */ const [draftUnits, setDraftUnits] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [publishedUnits, setPublishedUnits] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [archivedUnits, setArchivedUnits] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [unitsLoaded, setUnitsLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Tab state: 0 = My Units, 1 = Shared With Me, 2 = Community
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [sharedUnits, setSharedUnits] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [sharedLoaded, setSharedLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [communityUnits, setCommunityUnits] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [communityLoaded, setCommunityLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [forking, setForking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [work, setIsWorking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const searchQuery = searchParams?.get("q") || "";
    const { badges: earnedBadges } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBadges"])();
    const { isLocked, getLockStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContentLock"])();
    const { totalXP } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"])();
    // Practice drill state
    const [practiceConfigOpen, setPracticeConfigOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [practiceDrillOpen, setPracticeDrillOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [practiceUnit, setPracticeUnit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [drillConfig, setDrillConfig] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleOpenPractice = (unit)=>{
        setPracticeUnit(unit);
        setPracticeConfigOpen(true);
    };
    const handleStartDrill = (config)=>{
        setDrillConfig(config);
        setPracticeConfigOpen(false);
        setPracticeDrillOpen(true);
    };
    const handleCloseDrill = ()=>{
        setPracticeDrillOpen(false);
        setDrillConfig(null);
        setPracticeUnit(null);
    };
    // Group badges by sourceId (unit ID) for per-card display
    const badgesByUnit = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "Units.useMemo[badgesByUnit]": ()=>{
            const map = {};
            earnedBadges.forEach({
                "Units.useMemo[badgesByUnit]": (b)=>{
                    if (!b.sourceId) return;
                    if (!map[b.sourceId]) map[b.sourceId] = [];
                    map[b.sourceId].push(b);
                }
            }["Units.useMemo[badgesByUnit]"]);
            return map;
        }
    }["Units.useMemo[badgesByUnit]"], [
        earnedBadges
    ]);
    // Register page context with global chat
    // Combine all units for chat context
    const allUnits = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "Units.useMemo[allUnits]": ()=>[
                ...draftUnits,
                ...publishedUnits,
                ...archivedUnits
            ]
    }["Units.useMemo[allUnits]"], [
        draftUnits,
        publishedUnits,
        archivedUnits
    ]);
    // Filter units by ?q= search param for URL-driven highlighting
    const filterBySearchQuery = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "Units.useCallback[filterBySearchQuery]": (units)=>{
            if (!searchQuery) return units;
            const q = searchQuery.toLowerCase();
            return units.filter({
                "Units.useCallback[filterBySearchQuery]": (u)=>u.name?.toLowerCase().includes(q) || u.description?.toLowerCase().includes(q)
            }["Units.useCallback[filterBySearchQuery]"]);
        }
    }["Units.useCallback[filterBySearchQuery]"], [
        searchQuery
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPageContext"])({
    });
    // Consolidated Unit observer - handles published, archived, and draft units with client-side filtering
    const unitVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Units.useEffect": ()=>{
            // Wait for authentication
            if (authLoading || !user) {
                console.log("[Units] Waiting for authentication...", {
                    authLoading,
                    hasUser: !!user
                });
                return;
            }
            console.log("[Units] Setting up Unit observeQuery for user:", user.username);
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            let cancelled = false;
            function updateUnitsState(items) {
                const published = items.filter({
                    "Units.useEffect.updateUnitsState.published": (u_0)=>u_0.status === "PUBLISHED"
                }["Units.useEffect.updateUnitsState.published"]);
                const archived = items.filter({
                    "Units.useEffect.updateUnitsState.archived": (u_1)=>u_1.status === "ARCHIVED"
                }["Units.useEffect.updateUnitsState.archived"]);
                const draft = items.filter({
                    "Units.useEffect.updateUnitsState.draft": (u_2)=>u_2.status !== "ARCHIVED" && u_2.status !== "PUBLISHED"
                }["Units.useEffect.updateUnitsState.draft"]);
                setPublishedUnits(published);
                setArchivedUnits(archived);
                setDraftUnits(draft);
            }
            // Single observeQuery replaces list() + 3 manual subscriptions
            const subscription = client.models.Unit.observeQuery().subscribe({
                next: {
                    "Units.useEffect.subscription": ({ items: items_0 })=>{
                        if (cancelled) return;
                        const validItems = (items_0 || []).filter({
                            "Units.useEffect.subscription.validItems": (u_3)=>u_3 != null && u_3.id != null
                        }["Units.useEffect.subscription.validItems"]);
                        // Version map guard: skip if no item has a newer _version
                        const hasChanges = validItems.some({
                            "Units.useEffect.subscription.hasChanges": (item)=>{
                                const tracked = unitVersionMapRef.current[item.id];
                                return tracked == null || item._version > tracked;
                            }
                        }["Units.useEffect.subscription.hasChanges"]);
                        if (!hasChanges && Object.keys(unitVersionMapRef.current).length > 0) {
                            return;
                        }
                        // Update version map
                        unitVersionMapRef.current = {};
                        validItems.forEach({
                            "Units.useEffect.subscription": (item_0)=>{
                                unitVersionMapRef.current[item_0.id] = item_0._version;
                            }
                        }["Units.useEffect.subscription"]);
                        console.log("[Units] Unit observeQuery update:", validItems.length, "units");
                        updateUnitsState(validItems);
                        setUnitsLoaded(true);
                    }
                }["Units.useEffect.subscription"],
                error: {
                    "Units.useEffect.subscription": (error)=>console.error("[Units] observeQuery error:", error)
                }["Units.useEffect.subscription"]
            });
            return function cleanup() {
                cancelled = true;
                subscription.unsubscribe();
            };
        }
    }["Units.useEffect"], [
        user,
        authLoading
    ]);
    async function createUnit(event) {
        setIsWorking(true);
        event.preventDefault();
        const { identityId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAuthSession"])();
        try {
            const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const response = await client_0.models.Unit.create({
                name: "",
                description: "",
                identityId
            });
            if (response.errors?.length > 0) {
                console.error("Error creating unit:", response.errors);
                throw new Error(response.errors[0].message);
            }
            console.log("newUnit", response.data);
            router.push(`/unit/${response.data.id}`);
        } catch (errors) {
            console.error(errors);
            setIsWorking(false);
        }
    }
    // Load "Shared With Me" data when tab is selected
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Units.useEffect": ()=>{
            if (activeTab !== 1 || !user?.username) return;
            if (sharedLoaded) return;
            let cancelled_0 = false;
            async function loadShared() {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$b0c48b__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["listSharedWithMe"])(user.username);
                if (cancelled_0) return;
                if (result.success) {
                    setSharedUnits(result.data || []);
                }
                setSharedLoaded(true);
            }
            loadShared();
            return ({
                "Units.useEffect": ()=>{
                    cancelled_0 = true;
                }
            })["Units.useEffect"];
        }
    }["Units.useEffect"], [
        activeTab,
        user,
        sharedLoaded
    ]);
    // Load "Community" data when tab is selected
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Units.useEffect": ()=>{
            if (activeTab !== 2 || !user?.username) return;
            if (communityLoaded) return;
            let cancelled_1 = false;
            async function loadCommunity() {
                const result_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$d36854__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["listCommunityUnits"])(user.username);
                if (cancelled_1) return;
                if (result_0.success) {
                    setCommunityUnits(result_0.data || []);
                }
                setCommunityLoaded(true);
            }
            loadCommunity();
            return ({
                "Units.useEffect": ()=>{
                    cancelled_1 = true;
                }
            })["Units.useEffect"];
        }
    }["Units.useEffect"], [
        activeTab,
        user,
        communityLoaded
    ]);
    // Fork handler for community tab
    async function handleForkUnit(unitId) {
        setForking(true);
        try {
            const { identityId: identityId_0 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAuthSession"])();
            const result_1 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$8709a2__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["forkUnit"])(unitId, user.username, identityId_0);
            if (result_1.success && result_1.unitId) {
                router.push(`/unit/${result_1.unitId}`);
            } else {
                console.error("[Units] Fork failed:", result_1.error);
            }
        } catch (err) {
            console.error("[Units] Fork error:", err);
        }
        setForking(false);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                "data-tour": "units-page",
                style: {
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            margin: "0",
                            padding: "2rem",
                            flexGrow: "1",
                            minWidth: "min-content",
                            // center the text both horizontally and vertically
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "h2",
                                component: "div",
                                sx: {
                                    flexGrow: 1
                                },
                                children: [
                                    t("units.title"),
                                    " "
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/[locale]/units/page.jsx",
                                lineNumber: 283,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                "data-tour": "create-unit-button",
                                variant: "outlined",
                                color: "primary",
                                disabled: work,
                                onClick: createUnit,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                        lineNumber: 289,
                                        columnNumber: 13
                                    }, this),
                                    " ",
                                    t("units.createNew")
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/[locale]/units/page.jsx",
                                lineNumber: 288,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/[locale]/units/page.jsx",
                        lineNumber: 272,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            width: "90vw",
                            maxWidth: "80rem",
                            margin: "0 auto"
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__["Tabs"], {
                            value: activeTab,
                            onChange: (_, newValue)=>setActiveTab(newValue),
                            sx: {
                                mb: 1
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                    label: t("units.tabMyUnits")
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                    lineNumber: 303,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                    label: t("units.tabSharedWithMe")
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                    lineNumber: 304,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                    label: t("units.tabCommunity")
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                    lineNumber: 305,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[locale]/units/page.jsx",
                            lineNumber: 300,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/[locale]/units/page.jsx",
                        lineNumber: 295,
                        columnNumber: 9
                    }, this),
                    activeTab === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            display: "flex",
                            flexDirection: "column",
                            flexGrow: 1,
                            margin: "1rem auto"
                        },
                        children: !sharedLoaded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                justifyContent: "center",
                                py: 4
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                variant: "rounded",
                                width: "90vw",
                                height: 180,
                                sx: {
                                    maxWidth: "80rem"
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/[locale]/units/page.jsx",
                                lineNumber: 321,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/units/page.jsx",
                            lineNumber: 316,
                            columnNumber: 30
                        }, this) : sharedUnits.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body1",
                            color: "text.secondary",
                            sx: {
                                textAlign: "center",
                                py: 4
                            },
                            children: t("units.noSharedUnits")
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/units/page.jsx",
                            lineNumber: 324,
                            columnNumber: 51
                        }, this) : sharedUnits.map((unit_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SharedUnitCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                unit: unit_0,
                                onOpen: (unitId_0)=>router.push(`/unit/${unitId_0}`)
                            }, unit_0.id, false, {
                                fileName: "[project]/app/[locale]/units/page.jsx",
                                lineNumber: 329,
                                columnNumber: 57
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/[locale]/units/page.jsx",
                        lineNumber: 310,
                        columnNumber: 29
                    }, this),
                    activeTab === 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            display: "flex",
                            flexDirection: "column",
                            flexGrow: 1,
                            margin: "1rem auto"
                        },
                        children: !communityLoaded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                justifyContent: "center",
                                py: 4
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                variant: "rounded",
                                width: "90vw",
                                height: 180,
                                sx: {
                                    maxWidth: "80rem"
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/[locale]/units/page.jsx",
                                lineNumber: 344,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/units/page.jsx",
                            lineNumber: 339,
                            columnNumber: 33
                        }, this) : communityUnits.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body1",
                            color: "text.secondary",
                            sx: {
                                textAlign: "center",
                                py: 4
                            },
                            children: t("units.noCommunityUnits")
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/units/page.jsx",
                            lineNumber: 347,
                            columnNumber: 54
                        }, this) : communityUnits.map((unit_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CommunityUnitCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                unit: unit_1,
                                onFork: handleForkUnit,
                                forking: forking
                            }, unit_1.id, false, {
                                fileName: "[project]/app/[locale]/units/page.jsx",
                                lineNumber: 352,
                                columnNumber: 60
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/[locale]/units/page.jsx",
                        lineNumber: 333,
                        columnNumber: 29
                    }, this),
                    activeTab === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        "data-tour": "units-list",
                        sx: {
                            display: "flex",
                            flexDirection: "column",
                            flexGrow: 1,
                            margin: "1rem auto"
                        },
                        children: [
                            !unitsLoaded && // Loading skeleton placeholders to prevent layout shift
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    1,
                                    2,
                                    3
                                ].map((i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                                        elevation: 2,
                                        sx: {
                                            display: "flex",
                                            margin: "1rem auto",
                                            width: "90vw",
                                            maxWidth: "80rem",
                                            borderRadius: 2,
                                            borderLeft: "4px solid",
                                            borderLeftColor: "action.disabled"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            sx: {
                                                display: "flex",
                                                flexDirection: "column",
                                                flexGrow: "1",
                                                p: 2
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                                    variant: "text",
                                                    width: "60%",
                                                    height: 32,
                                                    sx: {
                                                        mb: 1
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                    lineNumber: 380,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                                    variant: "text",
                                                    width: "90%",
                                                    height: 20
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                    lineNumber: 383,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                                    variant: "text",
                                                    width: "40%",
                                                    height: 20
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                    lineNumber: 384,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        display: "flex",
                                                        gap: 1,
                                                        mt: 2
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                                            variant: "rounded",
                                                            width: 140,
                                                            height: 36
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                                            lineNumber: 390,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                                            variant: "rounded",
                                                            width: 100,
                                                            height: 36
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                                            lineNumber: 391,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                                            variant: "rounded",
                                                            width: 80,
                                                            height: 36
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                                            lineNumber: 392,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                    lineNumber: 385,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                            lineNumber: 374,
                                            columnNumber: 21
                                        }, this)
                                    }, i, false, {
                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                        lineNumber: 365,
                                        columnNumber: 37
                                    }, this))
                            }, void 0, false),
                            unitsLoaded && publishedUnits.length == 0 && //embed url to create a new section
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                                elevation: 3,
                                sx: {
                                    display: "flex",
                                    margin: "3rem auto",
                                    width: "fit-content",
                                    maxWidth: "500px",
                                    minHeight: "300px",
                                    borderRadius: 3
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        display: "flex",
                                        flexDirection: "column",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        flexGrow: "1",
                                        p: 4
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                                        sx: {
                                            flex: "1 1 auto",
                                            display: "flex",
                                            flexDirection: "column",
                                            justifyContent: "center",
                                            alignItems: "center",
                                            textAlign: "center"
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                component: "div",
                                                variant: "h5",
                                                sx: {
                                                    mb: 3
                                                },
                                                children: t("units.noPublishedUnits")
                                            }, void 0, false, {
                                                fileName: "[project]/app/[locale]/units/page.jsx",
                                                lineNumber: 423,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                "data-tour": "create-unit-button",
                                                variant: "outlined",
                                                color: "primary",
                                                onClick: createUnit,
                                                disabled: work,
                                                sx: {
                                                    textTransform: "none",
                                                    fontWeight: 600,
                                                    px: 3,
                                                    py: 1,
                                                    borderRadius: 2
                                                },
                                                children: t("units.createNewUnit")
                                            }, void 0, false, {
                                                fileName: "[project]/app/[locale]/units/page.jsx",
                                                lineNumber: 428,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                        lineNumber: 415,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                    lineNumber: 407,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/[locale]/units/page.jsx",
                                lineNumber: 399,
                                columnNumber: 9
                            }, this),
                            publishedUnits.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h4",
                                        component: "div",
                                        sx: {
                                            flexGrow: 1,
                                            width: "80vw",
                                            margin: "1rem auto"
                                        },
                                        children: t("units.publishedUnits")
                                    }, void 0, false, {
                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                        lineNumber: 441,
                                        columnNumber: 17
                                    }, this),
                                    publishedUnits.map(function(unit_2) {
                                        const lockStatus = getLockStatus(unit_2.id);
                                        const unitLocked = isLocked(unit_2.id);
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ContentLockCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentLockCard"], {
                                            id: `unit-${unit_2.id}`,
                                            title: unit_2.name || t("units.untitledUnit"),
                                            isLocked: unitLocked,
                                            requiredXP: lockStatus?.requiredXP,
                                            currentXP: totalXP,
                                            requiredCompletion: lockStatus?.requiredCompletion,
                                            currentCompletion: lockStatus?.currentCompletion,
                                            requiredBadge: lockStatus?.requiredBadge,
                                            requiredPriorUnitId: lockStatus?.requiredPriorUnitId,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                                                elevation: 2,
                                                sx: {
                                                    display: "flex",
                                                    margin: "1rem auto",
                                                    width: "90vw",
                                                    maxWidth: "80rem",
                                                    height: 180,
                                                    borderRadius: 2,
                                                    borderLeft: "4px solid",
                                                    borderLeftColor: "text.primary",
                                                    transition: "all 0.3s ease-in-out",
                                                    overflow: "hidden",
                                                    "&:hover": {
                                                        elevation: 6,
                                                        transform: "translateY(-2px)",
                                                        boxShadow: "0 8px 24px rgba(0,0,0,0.12)"
                                                    }
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        sx: {
                                                            display: "flex",
                                                            flexDirection: "column",
                                                            flexGrow: "1",
                                                            p: 0.5
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                                                                sx: {
                                                                    flex: "1 0 auto",
                                                                    pb: 1
                                                                },
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                        component: "div",
                                                                        variant: "h5",
                                                                        sx: {
                                                                            fontWeight: 600,
                                                                            mb: 0.5
                                                                        },
                                                                        children: unit_2.name || t("units.untitledUnit")
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 479,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                        variant: "body1",
                                                                        color: "text.secondary",
                                                                        component: "div",
                                                                        sx: {
                                                                            lineHeight: 1.6
                                                                        },
                                                                        children: unit_2.description || ""
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 485,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    badgesByUnit[unit_2.id]?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                                        sx: {
                                                                            mt: 1
                                                                        },
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeShelf$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeShelf"], {
                                                                            earnedBadges: badgesByUnit[unit_2.id],
                                                                            columns: Math.min(badgesByUnit[unit_2.id].length, 5),
                                                                            earnedOnly: true
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                                                            lineNumber: 493,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 490,
                                                                        columnNumber: 69
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/[locale]/units/page.jsx",
                                                                lineNumber: 475,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                                sx: {
                                                                    display: "flex",
                                                                    alignItems: "center",
                                                                    pl: 2,
                                                                    pb: 1.5,
                                                                    flexWrap: "wrap",
                                                                    gap: 1
                                                                },
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                                        variant: "outlined",
                                                                        href: `/workbook/${unit_2.id}`,
                                                                        disabled: work,
                                                                        startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EditNote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                                                            lineNumber: 504,
                                                                            columnNumber: 115
                                                                        }, this),
                                                                        sx: {
                                                                            textTransform: "none",
                                                                            fontWeight: 600,
                                                                            px: 3,
                                                                            py: 1,
                                                                            borderRadius: 2,
                                                                            boxShadow: 2,
                                                                            color: "text.primary",
                                                                            borderColor: "text.primary",
                                                                            "&:hover": {
                                                                                boxShadow: 4,
                                                                                borderColor: "text.primary",
                                                                                backgroundColor: "action.hover"
                                                                            }
                                                                        },
                                                                        children: t("units.viewWorkbook")
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 504,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                                        variant: "outlined",
                                                                        disabled: work,
                                                                        onClick: ()=>handleOpenPractice(unit_2),
                                                                        startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$FitnessCenter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                                                            lineNumber: 521,
                                                                            columnNumber: 126
                                                                        }, this),
                                                                        sx: {
                                                                            textTransform: "none",
                                                                            fontWeight: 600,
                                                                            px: 3,
                                                                            py: 1,
                                                                            borderRadius: 2,
                                                                            boxShadow: 2,
                                                                            color: "text.primary",
                                                                            borderColor: "text.primary",
                                                                            "&:hover": {
                                                                                boxShadow: 4,
                                                                                borderColor: "text.primary",
                                                                                backgroundColor: "action.hover"
                                                                            }
                                                                        },
                                                                        children: t("units.practice", "Practice")
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 521,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                                        variant: "outlined",
                                                                        href: `/unit/${unit_2.id}`,
                                                                        disabled: work,
                                                                        startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                                                            lineNumber: 538,
                                                                            columnNumber: 111
                                                                        }, this),
                                                                        sx: {
                                                                            textTransform: "none",
                                                                            fontWeight: 600,
                                                                            px: 3,
                                                                            py: 1,
                                                                            borderRadius: 2,
                                                                            boxShadow: 2,
                                                                            color: "text.primary",
                                                                            borderColor: "text.primary",
                                                                            "&:hover": {
                                                                                boxShadow: 4,
                                                                                borderColor: "text.primary",
                                                                                backgroundColor: "action.hover"
                                                                            }
                                                                        },
                                                                        children: t("units.editUnit")
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 538,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/[locale]/units/page.jsx",
                                                                lineNumber: 496,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                        lineNumber: 469,
                                                        columnNumber: 25
                                                    }, this),
                                                    unit_2?.featuredImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        s3Key: unit_2?.featuredImage,
                                                        identityId: unit_2?.identityId
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                        lineNumber: 557,
                                                        columnNumber: 51
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/[locale]/units/page.jsx",
                                                lineNumber: 452,
                                                columnNumber: 23
                                            }, this)
                                        }, unit_2.id, false, {
                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                            lineNumber: 451,
                                            columnNumber: 20
                                        }, this);
                                    })
                                ]
                            }, void 0, true),
                            draftUnits.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h4",
                                        component: "div",
                                        sx: {
                                            flexGrow: 1,
                                            width: "80vw",
                                            margin: "1rem auto"
                                        },
                                        children: t("units.myDrafts")
                                    }, void 0, false, {
                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                        lineNumber: 564,
                                        columnNumber: 17
                                    }, this),
                                    draftUnits.map(function(unit_3) {
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                                            id: `unit-${unit_3.id}`,
                                            elevation: 2,
                                            sx: {
                                                display: "flex",
                                                margin: "1rem auto",
                                                width: "90vw",
                                                maxWidth: "80rem",
                                                borderRadius: 2,
                                                borderLeft: "4px solid",
                                                borderLeftColor: "text.primary",
                                                transition: "all 0.3s ease-in-out",
                                                "&:hover": {
                                                    elevation: 6,
                                                    transform: "translateY(-2px)",
                                                    boxShadow: "0 8px 24px rgba(0,0,0,0.12)"
                                                }
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        display: "flex",
                                                        flexDirection: "column",
                                                        flexGrow: "1",
                                                        p: 0.5
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                                                            sx: {
                                                                flex: "1 0 auto",
                                                                pb: 1
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                    component: "div",
                                                                    variant: "h5",
                                                                    sx: {
                                                                        fontWeight: 600,
                                                                        mb: 0.5
                                                                    },
                                                                    children: unit_3.name || t("units.untitledUnit")
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                                    lineNumber: 597,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                    variant: "body1",
                                                                    color: "text.secondary",
                                                                    component: "div",
                                                                    sx: {
                                                                        lineHeight: 1.6
                                                                    },
                                                                    children: unit_3.description || ""
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                                    lineNumber: 603,
                                                                    columnNumber: 27
                                                                }, this),
                                                                badgesByUnit[unit_3.id]?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                                    sx: {
                                                                        mt: 1
                                                                    },
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeShelf$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeShelf"], {
                                                                        earnedBadges: badgesByUnit[unit_3.id],
                                                                        columns: Math.min(badgesByUnit[unit_3.id].length, 5),
                                                                        earnedOnly: true
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 611,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                                    lineNumber: 608,
                                                                    columnNumber: 67
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                                            lineNumber: 593,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                            sx: {
                                                                display: "flex",
                                                                alignItems: "center",
                                                                pl: 2,
                                                                pb: 1.5
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                                    variant: "outlined",
                                                                    href: `/workbook/${unit_3.id}`,
                                                                    disabled: work,
                                                                    startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EditNote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 620,
                                                                        columnNumber: 113
                                                                    }, this),
                                                                    sx: {
                                                                        textTransform: "none",
                                                                        fontWeight: 600,
                                                                        px: 3,
                                                                        py: 1,
                                                                        mr: 1,
                                                                        borderRadius: 2,
                                                                        boxShadow: 2,
                                                                        color: "text.primary",
                                                                        borderColor: "text.primary",
                                                                        "&:hover": {
                                                                            boxShadow: 4,
                                                                            borderColor: "text.primary",
                                                                            backgroundColor: "action.hover"
                                                                        }
                                                                    },
                                                                    children: t("units.viewWorkbook")
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                                    lineNumber: 620,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                                    variant: "outlined",
                                                                    href: `/unit/${unit_3.id}`,
                                                                    disabled: work,
                                                                    startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 638,
                                                                        columnNumber: 109
                                                                    }, this),
                                                                    sx: {
                                                                        textTransform: "none",
                                                                        fontWeight: 600,
                                                                        px: 3,
                                                                        py: 1,
                                                                        borderRadius: 2,
                                                                        boxShadow: 2,
                                                                        color: "text.primary",
                                                                        borderColor: "text.primary",
                                                                        "&:hover": {
                                                                            boxShadow: 4,
                                                                            borderColor: "text.primary",
                                                                            backgroundColor: "action.hover"
                                                                        }
                                                                    },
                                                                    children: t("units.editUnit")
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                                    lineNumber: 638,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                                            lineNumber: 614,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                    lineNumber: 587,
                                                    columnNumber: 23
                                                }, this),
                                                unit_3?.featuredImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    s3Key: unit_3?.featuredImage,
                                                    identityId: unit_3?.identityId
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                    lineNumber: 657,
                                                    columnNumber: 49
                                                }, this)
                                            ]
                                        }, unit_3.id, true, {
                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                            lineNumber: 572,
                                            columnNumber: 20
                                        }, this);
                                    })
                                ]
                            }, void 0, true),
                            archivedUnits.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h4",
                                        component: "div",
                                        sx: {
                                            flexGrow: 1,
                                            width: "80vw",
                                            margin: "1rem auto"
                                        },
                                        children: t("units.archivedUnits")
                                    }, void 0, false, {
                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                        lineNumber: 663,
                                        columnNumber: 17
                                    }, this),
                                    archivedUnits.map(function(unit_4) {
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                                            id: `unit-${unit_4.id}`,
                                            elevation: 2,
                                            sx: {
                                                display: "flex",
                                                margin: "1rem auto",
                                                width: "90vw",
                                                maxWidth: "80rem",
                                                height: 180,
                                                borderRadius: 2,
                                                borderLeft: "4px solid",
                                                borderLeftColor: "text.primary",
                                                transition: "all 0.3s ease-in-out",
                                                overflow: "hidden",
                                                "&:hover": {
                                                    elevation: 6,
                                                    transform: "translateY(-2px)",
                                                    boxShadow: "0 8px 24px rgba(0,0,0,0.12)"
                                                }
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        display: "flex",
                                                        flexDirection: "column",
                                                        flexGrow: "1",
                                                        p: 0.5
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                                                            sx: {
                                                                flex: "1 0 auto",
                                                                pb: 1
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                    component: "div",
                                                                    variant: "h5",
                                                                    sx: {
                                                                        fontWeight: 600,
                                                                        mb: 0.5
                                                                    },
                                                                    children: unit_4.name || t("units.untitledUnit")
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                                    lineNumber: 698,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                    variant: "body1",
                                                                    color: "text.secondary",
                                                                    component: "div",
                                                                    sx: {
                                                                        lineHeight: 1.6
                                                                    },
                                                                    children: unit_4.description || ""
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                                    lineNumber: 704,
                                                                    columnNumber: 27
                                                                }, this),
                                                                badgesByUnit[unit_4.id]?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                                    sx: {
                                                                        mt: 1
                                                                    },
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeShelf$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeShelf"], {
                                                                        earnedBadges: badgesByUnit[unit_4.id],
                                                                        columns: Math.min(badgesByUnit[unit_4.id].length, 5),
                                                                        earnedOnly: true
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 712,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                                    lineNumber: 709,
                                                                    columnNumber: 67
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                                            lineNumber: 694,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                            sx: {
                                                                display: "flex",
                                                                alignItems: "center",
                                                                pl: 2,
                                                                pb: 1.5
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                                    variant: "outlined",
                                                                    href: `/workbook/${unit_4.id}`,
                                                                    disabled: work,
                                                                    startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EditNote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 721,
                                                                        columnNumber: 113
                                                                    }, this),
                                                                    sx: {
                                                                        textTransform: "none",
                                                                        fontWeight: 600,
                                                                        px: 3,
                                                                        py: 1,
                                                                        mr: 1,
                                                                        borderRadius: 2,
                                                                        boxShadow: 2,
                                                                        color: "text.primary",
                                                                        borderColor: "text.primary",
                                                                        "&:hover": {
                                                                            boxShadow: 4,
                                                                            borderColor: "text.primary",
                                                                            backgroundColor: "action.hover"
                                                                        }
                                                                    },
                                                                    children: t("units.viewWorkbook")
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                                    lineNumber: 721,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                                    variant: "outlined",
                                                                    href: `/unit/${unit_4.id}`,
                                                                    disabled: work,
                                                                    startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/units/page.jsx",
                                                                        lineNumber: 739,
                                                                        columnNumber: 109
                                                                    }, this),
                                                                    sx: {
                                                                        textTransform: "none",
                                                                        fontWeight: 600,
                                                                        px: 3,
                                                                        py: 1,
                                                                        borderRadius: 2,
                                                                        boxShadow: 2,
                                                                        color: "text.primary",
                                                                        borderColor: "text.primary",
                                                                        "&:hover": {
                                                                            boxShadow: 4,
                                                                            borderColor: "text.primary",
                                                                            backgroundColor: "action.hover"
                                                                        }
                                                                    },
                                                                    children: t("units.editUnit")
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                                    lineNumber: 739,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                                            lineNumber: 715,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                    lineNumber: 688,
                                                    columnNumber: 23
                                                }, this),
                                                unit_4?.featuredImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    s3Key: unit_4?.featuredImage,
                                                    identityId: unit_4?.identityId
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/units/page.jsx",
                                                    lineNumber: 758,
                                                    columnNumber: 49
                                                }, this)
                                            ]
                                        }, unit_4.id, true, {
                                            fileName: "[project]/app/[locale]/units/page.jsx",
                                            lineNumber: 671,
                                            columnNumber: 20
                                        }, this);
                                    })
                                ]
                            }, void 0, true)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/[locale]/units/page.jsx",
                        lineNumber: 356,
                        columnNumber: 29
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/[locale]/units/page.jsx",
                lineNumber: 269,
                columnNumber: 7
            }, this),
            practiceUnit && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillConfigPopup$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PracticeDrillConfigPopup$3e$__["PracticeDrillConfigPopup"], {
                open: practiceConfigOpen,
                onClose: ()=>{
                    setPracticeConfigOpen(false);
                    setPracticeUnit(null);
                },
                onStart: handleStartDrill,
                unitId: practiceUnit.id,
                unitName: practiceUnit.name || "",
                vocabularyCount: 0,
                questionCount: 0,
                textBlockCount: 0,
                documentCount: 0
            }, void 0, false, {
                fileName: "[project]/app/[locale]/units/page.jsx",
                lineNumber: 766,
                columnNumber: 24
            }, this),
            drillConfig && practiceUnit && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PracticeDrillDialog$3e$__["PracticeDrillDialog"], {
                open: practiceDrillOpen,
                onClose: handleCloseDrill,
                unitId: practiceUnit.id,
                unitName: practiceUnit.name || "",
                config: drillConfig
            }, void 0, false, {
                fileName: "[project]/app/[locale]/units/page.jsx",
                lineNumber: 772,
                columnNumber: 39
            }, this)
        ]
    }, void 0, true);
}
_s(Units, "9BVWRWGLv76VxFPDfuMVgdn4+cs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBadges"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContentLock"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPageContext"]
    ];
});
_c = Units;
function WrappedPage() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "3b1ce4f6136b3fd592c3c0c722eaaddd7e8d62953f730e7d26e03ac19ab86a87") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "3b1ce4f6136b3fd592c3c0c722eaaddd7e8d62953f730e7d26e03ac19ab86a87";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationProviderWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationProviderWrapper"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Units, {}, void 0, false, {
                fileName: "[project]/app/[locale]/units/page.jsx",
                lineNumber: 785,
                columnNumber: 39
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/units/page.jsx",
            lineNumber: 785,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c1 = WrappedPage;
const __TURBOPACK__default__export__ = WrappedPage;
var _c, _c1;
__turbopack_context__.k.register(_c, "Units");
__turbopack_context__.k.register(_c1, "WrappedPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_0kgqv9_._.js.map