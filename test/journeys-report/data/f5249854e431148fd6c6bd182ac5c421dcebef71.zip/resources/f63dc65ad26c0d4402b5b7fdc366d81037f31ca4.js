(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/utils/debug/StateSnapshot.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_utils_debug_0x03.zc._.js",
  "static/chunks/src_utils_debug_StateSnapshot_ts_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/utils/debug/StateSnapshot.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/src/offline/SyncQueue.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_offline_0zv8k4m._.js",
  "static/chunks/src_offline_SyncQueue_ts_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/offline/SyncQueue.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_offline_OfflineDataStore_ts_0b_0oq9._.js",
  "static/chunks/src_offline_OfflineDataStore_ts_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/components/ImageComponent.jsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_0qlviz0._.js",
  "static/chunks/src_components_Editor3_components_ImageComponent_jsx_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/ImageComponent.jsx [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/idb/build/index.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_idb_build_index_0gsx_v8.js",
  "static/chunks/node_modules_idb_build_index_0vg.m.c.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/idb/build/index.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/aws-amplify/dist/esm/storage/index.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_0362a-m._.js",
  "static/chunks/node_modules_aws-amplify_dist_esm_storage_index_mjs_0ouzc3t._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/aws-amplify/dist/esm/storage/index.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/pako/dist/pako.esm.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_pako_dist_pako_esm_mjs_09ei-9a._.js",
  "static/chunks/node_modules_pako_dist_pako_esm_mjs_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/pako/dist/pako.esm.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/components/ConversationPlayerComponent.jsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_0djbmn-._.js",
  "static/chunks/src_components_Editor3_components_ConversationPlayerComponent_jsx_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/ConversationPlayerComponent.jsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/components/ConversationPlaylistEditor.jsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_0h_f6ov._.js",
  "static/chunks/src_components_Editor3_components_ConversationPlaylistEditor_jsx_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/ConversationPlaylistEditor.jsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/utils/amplifyClient.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/aws-amplify/dist/esm/auth/index.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_aws-amplify_10cnnt4._.js",
  "static/chunks/node_modules_aws-amplify_dist_esm_auth_index_mjs_0ouzc3t._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/aws-amplify/dist/esm/auth/index.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/src/utils/embeddingStorage.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_utils_embeddingStorage_ts_0n5qrgz._.js",
  "static/chunks/src_utils_embeddingStorage_ts_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/utils/embeddingStorage.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/components/MediaPlayerComponent.jsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@xmldom_xmldom_lib_12chyy6._.js",
  "static/chunks/node_modules_video_js_dist_video_es_11rghpk.js",
  "static/chunks/node_modules_0putkn0._.js",
  "static/chunks/src_components_Editor3_components_MediaPlayerComponent_jsx_0z9-5yn._.js",
  {
    "path": "static/chunks/node_modules_video_js_dist_video-js_0h~.xii.css",
    "included": [
      "[project]/node_modules/video.js/dist/video-js.css [app-client] (css)"
    ]
  },
  "static/chunks/src_components_Editor3_components_MediaPlayerComponent_jsx_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/MediaPlayerComponent.jsx [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/canvas-confetti/dist/confetti.module.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_canvas-confetti_dist_confetti_module_mjs_0yfsgy6._.js",
  "static/chunks/node_modules_canvas-confetti_dist_confetti_module_mjs_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/canvas-confetti/dist/confetti.module.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/components/SketchPad.jsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  {
    "path": "static/chunks/node_modules_@excalidraw_excalidraw_dist_dev_index_0cb_fch.css",
    "included": [
      "[project]/node_modules/@excalidraw/excalidraw/dist/dev/index.css [app-client] (css)"
    ]
  },
  "static/chunks/node_modules_@excalidraw_excalidraw_dist_dev_index_0esaz5f.js",
  "static/chunks/_0.~.vwt._.js",
  "static/chunks/src_components_Editor3_components_SketchPad_jsx_0n-ifym._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/SketchPad.jsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/Editor3/components/PdfViewerComponent.jsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_0m0lg0~._.js",
  "static/chunks/src_components_Editor3_components_PdfViewerComponent_jsx_0.izze.._.js",
  {
    "path": "static/chunks/node_modules_react-pdf_dist_Page_0rb9cui._.css",
    "included": [
      "[project]/node_modules/react-pdf/dist/Page/TextLayer.css [app-client] (css)",
      "[project]/node_modules/react-pdf/dist/Page/AnnotationLayer.css [app-client] (css)"
    ],
    "moduleChunks": [
      "static/chunks/node_modules_react-pdf_dist_Page_TextLayer_css_0w3-wzy._.single.css",
      "static/chunks/node_modules_react-pdf_dist_Page_AnnotationLayer_css_0w3-wzy._.single.css"
    ]
  },
  "static/chunks/src_components_Editor3_components_PdfViewerComponent_jsx_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/PdfViewerComponent.jsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/nodes/CustomAINode/CustomAIEditor.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_0me0et~._.js",
  "static/chunks/src_components_Editor3_nodes_CustomAINode_CustomAIEditor_tsx_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/nodes/CustomAINode/CustomAIEditor.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/nodes/CustomAINode/CustomAIComponent.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_Editor3_components_SketchPad_jsx_0zx-nc~._.js",
  "static/chunks/src_components_Editor3_nodes_CustomAINode_CustomAIComponent_tsx_09yrhc4._.js",
  "static/chunks/src_components_Editor3_nodes_CustomAINode_CustomAIComponent_tsx_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/nodes/CustomAINode/CustomAIComponent.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/offline/AIRouter.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@mlc-ai_web-llm_lib_index_12vnl8..js",
  "static/chunks/src_offline_0p.zrhf._.js",
  "static/chunks/src_offline_AIRouter_ts_0vg.m.c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/offline/AIRouter.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/aws-amplify/dist/esm/api/index.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_0cd6y7.._.js",
  "static/chunks/node_modules_aws-amplify_dist_esm_api_index_mjs_0ouzc3t._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/aws-amplify/dist/esm/api/index.mjs [app-client] (ecmascript)");
    });
});
}),
]);