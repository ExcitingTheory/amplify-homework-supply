(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/LazyCardMedia.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LazyCardMedia
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getResponsiveImageUrls$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getResponsiveImageUrls.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function LazyCardMedia(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "4d24c36048e5ea79e412c1e445af3b4f450538ab37080c231466099aa22d934c") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4d24c36048e5ea79e412c1e445af3b4f450538ab37080c231466099aa22d934c";
    }
    const { s3Key, identityId, fileId, level: t1, filter: t2, grade: t3 } = t0;
    t1 === undefined ? "protected" : t1;
    const filter = t2 === undefined ? null : t2;
    t3 === undefined ? null : t3;
    const [url, setUrl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [srcSet, setSrcSet] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [sizes, setSizes] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [loaded, setLoaded] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [isVisible, setIsVisible] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const containerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    let t4;
    let t5;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "LazyCardMedia[useEffect()]": ()=>{
                const el = containerRef.current;
                if (!el) {
                    return;
                }
                const observer = new IntersectionObserver((t6)=>{
                    const [entry] = t6;
                    if (entry.isIntersecting) {
                        setIsVisible(true);
                        observer.disconnect();
                    }
                }, {
                    rootMargin: "200px"
                });
                observer.observe(el);
                return ()=>observer.disconnect();
            }
        })["LazyCardMedia[useEffect()]"];
        t5 = [];
        $[1] = t4;
        $[2] = t5;
    } else {
        t4 = $[1];
        t5 = $[2];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t4, t5);
    let t6;
    let t7;
    if ($[3] !== fileId || $[4] !== identityId || $[5] !== isVisible || $[6] !== s3Key) {
        t6 = ({
            "LazyCardMedia[useEffect()]": ()=>{
                if (!isVisible || !s3Key) {
                    return;
                }
                setLoaded(false);
                let cancelled = false;
                const fetchUrl = {
                    "LazyCardMedia[useEffect() > fetchUrl]": async ()=>{
                        const _url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(s3Key);
                        if (!cancelled) {
                            setUrl(_url);
                        }
                    }
                }["LazyCardMedia[useEffect() > fetchUrl]"];
                fetchUrl();
                if (fileId && identityId) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getResponsiveImageUrls$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getResponsiveImageUrls"])(fileId, identityId).then({
                        "LazyCardMedia[useEffect() > (anonymous)()]": (result)=>{
                            if (!cancelled && result) {
                                setSrcSet(result.srcSet);
                                setSizes(result.sizes);
                            }
                        }
                    }["LazyCardMedia[useEffect() > (anonymous)()]"]).catch(_LazyCardMediaUseEffectAnonymous);
                }
                return ()=>{
                    cancelled = true;
                };
            }
        })["LazyCardMedia[useEffect()]"];
        t7 = [
            isVisible,
            s3Key,
            fileId,
            identityId
        ];
        $[3] = fileId;
        $[4] = identityId;
        $[5] = isVisible;
        $[6] = s3Key;
        $[7] = t6;
        $[8] = t7;
    } else {
        t6 = $[7];
        t7 = $[8];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t6, t7);
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            position: "relative",
            width: 400,
            alignSelf: "left",
            flexShrink: 0
        };
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    let t9;
    if ($[10] !== filter || $[11] !== isVisible || $[12] !== loaded || $[13] !== sizes || $[14] !== srcSet || $[15] !== url) {
        t9 = isVisible && url ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            src: url,
            srcSet: srcSet || undefined,
            sizes: sizes || undefined,
            loading: "lazy",
            decoding: "async",
            style: {
                width: "100%",
                height: "100%",
                objectFit: "cover",
                display: "block",
                visibility: loaded ? "visible" : "hidden",
                filter: filter || undefined
            },
            onLoad: {
                "LazyCardMedia[<img>.onLoad]": ()=>setLoaded(true)
            }["LazyCardMedia[<img>.onLoad]"]
        }, void 0, false, {
            fileName: "[project]/src/components/LazyCardMedia.jsx",
            lineNumber: 130,
            columnNumber: 29
        }, this) : null;
        $[10] = filter;
        $[11] = isVisible;
        $[12] = loaded;
        $[13] = sizes;
        $[14] = srcSet;
        $[15] = url;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    let t10;
    if ($[17] !== loaded) {
        t10 = !loaded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "rectangular",
            animation: "wave",
            sx: {
                position: "absolute",
                inset: 0,
                width: "100%",
                height: "100%"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/LazyCardMedia.jsx",
            lineNumber: 152,
            columnNumber: 22
        }, this);
        $[17] = loaded;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    let t11;
    if ($[19] !== t10 || $[20] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ref: containerRef,
            sx: t8,
            children: [
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/LazyCardMedia.jsx",
            lineNumber: 165,
            columnNumber: 11
        }, this);
        $[19] = t10;
        $[20] = t9;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    return t11;
}
_s(LazyCardMedia, "fttu1d96oMR5teXgml+F/YsIypE=");
_c = LazyCardMedia;
function _LazyCardMediaUseEffectAnonymous() {}
var _c;
__turbopack_context__.k.register(_c, "LazyCardMedia");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useChatPageContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useChatPageContext",
    ()=>useChatPageContext
]);
/**
 * useChatPageContext - Register page-specific context with ChatContext
 * 
 * This hook allows pages to register their available context (unit, files, sections, etc.)
 * with the global ChatContext, making that context available to the chat sidebar.
 * 
 * @example
 * // In Unit Editor page
 * function UnitEditorPage() {
 *   const { unit, files, dictionary, questions } = useContext(UnitContext);
 *   const { sections } = useContext(SectionContext);
 *   const { vectorStoreSearch } = useContext(VectorStoreContext);
 *   const editorRef = useRef(null);
 *   
 *   useChatPageContext({
 *     unit,
 *     files,
 *     dictionary,
 *     questions,
 *     sections,
 *     editorRef,
 *     vectorStoreSearch,
 *   });
 *   
 *   return <...>
 * }
 * 
 * @see docs/GLOBAL_CHAT_INTEGRATION_PLAN.md
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/chatContext.jsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useChatPageContext(context = {}) {
    _s();
    const { setPageContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { unit = null, files = [], dictionary = [], questions = [], sections = [], editorRef = null, vectorStoreSearch = null } = context;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChatPageContext.useEffect": ()=>{
            console.log('[useChatPageContext] Registering page context:', {
                hasUnit: !!unit,
                filesCount: files?.length || 0,
                dictionaryCount: dictionary?.length || 0,
                questionsCount: questions?.length || 0,
                sectionsCount: sections?.length || 0,
                hasEditorRef: !!editorRef,
                hasVectorStoreSearch: !!vectorStoreSearch
            });
            setPageContext({
                unit,
                files,
                dictionary,
                questions,
                sections,
                editorRef,
                vectorStoreSearch
            });
            // Cleanup: reset to empty context when component unmounts
            return ({
                "useChatPageContext.useEffect": ()=>{
                    console.log('[useChatPageContext] Cleaning up page context');
                    setPageContext({
                        unit: null,
                        files: [],
                        dictionary: [],
                        questions: [],
                        sections: [],
                        editorRef: null,
                        vectorStoreSearch: null
                    });
                }
            })["useChatPageContext.useEffect"];
        }
    }["useChatPageContext.useEffect"], [
        // Dependencies - update when any context changes
        unit?.id,
        files?.length,
        dictionary?.length,
        questions?.length,
        sections?.length,
        editorRef?.current,
        vectorStoreSearch,
        setPageContext
    ]);
}
_s(useChatPageContext, "0aGcDEhsgvDsw4KhinDnLq0Ig9M=");
const __TURBOPACK__default__export__ = useChatPageContext;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/antiBadgeRegistry.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Anti-Badge Registry — Sardonic, 4th-wall-breaking badges of shame.
 *
 * These are the "achievements" nobody asked for: punishments wrapped in
 * glitter, educational puns taken too far, and pointed commentary on
 * the very concept of gamifying homework.
 *
 * Each anti-badge comes with a **debuff** — a whimsical, mostly-harmless
 * penalty that makes earning them memorably funny rather than demoralizing.
 *
 * @module antiBadgeRegistry
 */ __turbopack_context__.s([
    "ANTI_BADGE_REGISTRY",
    ()=>ANTI_BADGE_REGISTRY,
    "getAllAntiBadgeTypes",
    ()=>getAllAntiBadgeTypes,
    "getAntiBadgeConfig",
    ()=>getAntiBadgeConfig,
    "getAntiBadgesByRarity",
    ()=>getAntiBadgesByRarity,
    "getRedeemableAntiBadges",
    ()=>getRedeemableAntiBadges
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/gi/index.mjs [app-client] (ecmascript)");
;
const ANTI_BADGE_REGISTRY = {
    // ── The Classics: Late & Missing Work ─────────────────────────────────
    FASHIONABLY_LATE: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSnail"],
        name: "Fashionably Late",
        description: "Submitted homework so late it arrived in a different academic calendar.",
        bgColor: "#795548",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#a1887f",
                    position: "0%"
                },
                {
                    color: "#3e2723",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffcc80",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        rarity: "common",
        category: "anti",
        debuff: {
            xpMultiplier: 0.75,
            xpMultiplierDurationHours: 12,
            temporaryTitle: "⏰ Fashionably Late",
            cosmeticDurationHours: 24,
            shameText: "Time is a social construct, but due dates are not."
        },
        redeemable: true,
        redemptionHint: "Submit your next 3 assignments on time to clear this badge.",
        redemptionCondition: {
            type: "CONSECUTIVE_ON_TIME",
            count: 3
        }
    },
    THE_GHOST: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiGhost"],
        name: "The Ghost",
        description: "Vanished from the platform for so long we filed a missing persons report.",
        bgColor: "#455a64",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#78909c",
                    position: "0%"
                },
                {
                    color: "#263238",
                    position: "100%"
                }
            ]
        },
        iconColor: "#b0bec5",
        shape: "hexagon",
        animation: "pulse",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            streakFreezesRemoved: 1,
            temporaryTitle: "👻 The Ghost",
            cosmeticDurationHours: 48,
            shameText: "They say if you whisper their username three times, they still won't log in."
        },
        redeemable: true,
        redemptionHint: "Log in for 3 consecutive days to exorcise this badge.",
        redemptionCondition: {
            type: "LOGIN_STREAK",
            count: 3
        }
    },
    HOMEWORK_ATE_MY_DOG: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiEarthWorm"],
        name: "Homework Ate My Dog",
        description: "The excuse was so creative it deserved its own grade. The homework did not.",
        bgColor: "#e65100",
        gradient: {
            type: "linear",
            angle: "180deg",
            stops: [
                {
                    color: "#ff9800",
                    position: "0%"
                },
                {
                    color: "#bf360c",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fff3e0",
        shape: "shield",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            extraDrills: 1,
            temporaryTitle: "🐕 My Dog Ate My Excuse",
            cosmeticDurationHours: 24,
            shameText: "Plot twist: the homework ate the dog."
        },
        redeemable: true,
        redemptionHint: "Complete the missing assignment to adopt a new excuse.",
        redemptionCondition: {
            type: "COMPLETE_ASSIGNMENT"
        }
    },
    // ── Academic Misadventures ────────────────────────────────────────────
    SPEED_RUN_SCHOLAR: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiAlarmClock"],
        name: "Speed Run Scholar",
        description: "Completed a quiz in under 30 seconds. Either a genius or a very fast guesser.",
        bgColor: "#f44336",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#e57373",
                    position: "0%"
                },
                {
                    color: "#b71c1c",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffcdd2",
        shape: "diamond",
        animation: "spin-in",
        hoverAnimation: "shake",
        rarity: "rare",
        category: "anti",
        debuff: {
            xpMultiplier: 0.5,
            xpMultiplierDurationHours: 6,
            temporaryTitle: "⚡ Speed Run Scholar",
            cosmeticDurationHours: 12,
            shameText: "Any% homework speedrun, no glitches (but also no reading)."
        },
        redeemable: true,
        redemptionHint: "Retake the quiz spending at least 2 minutes per question.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    CONSISTENTLY_WRONG: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBrokenBone"],
        name: "Consistently Wrong",
        description: "Got the same question wrong 5 times. At this point it's a commitment.",
        bgColor: "#880e4f",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#f48fb1",
                    position: "0%"
                },
                {
                    color: "#4a0028",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fce4ec",
        shape: "circle",
        animation: "shake",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            extraDrills: 2,
            temporaryTitle: "🔄 Consistently Wrong™",
            cosmeticDurationHours: 24,
            shameText: "Wrong answers given with such confidence they almost became right."
        },
        redeemable: true,
        redemptionHint: "Get the question right once. Just once. We believe in you.",
        redemptionCondition: {
            type: "ACCURACY_ABOVE",
            percent: 50
        }
    },
    COPY_PASTE_CONNOISSEUR: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiStabbedNote"],
        name: "Copy-Paste Connoisseur",
        description: "Submitted an answer that was suspiciously identical to the question prompt.",
        bgColor: "#37474f",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#607d8b",
                    position: "0%"
                },
                {
                    color: "#102027",
                    position: "100%"
                }
            ]
        },
        iconColor: "#90a4ae",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "pulse",
        rarity: "rare",
        category: "anti",
        debuff: {
            xpMultiplier: 0.25,
            xpMultiplierDurationHours: 24,
            avatarDowngrade: "simple",
            temporaryTitle: "📋 Ctrl+C Ctrl+V",
            cosmeticDurationHours: 48,
            shameText: '"I wrote this myself" — narrator: they did not.'
        },
        redeemable: true,
        redemptionHint: "Submit an original answer of at least 100 words.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    // ── Meta & 4th Wall Breaking ──────────────────────────────────────────
    BADGE_COLLECTOR_ANONYMOUS: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBirdCage"],
        name: "Badge Collector Anonymous",
        description: "You earned this badge for caring too much about badges. The irony is the reward.",
        bgColor: "#6a1b9a",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#ce93d8",
                    position: "0%"
                },
                {
                    color: "#38006b",
                    position: "100%"
                }
            ]
        },
        iconColor: "#e1bee7",
        shape: "diamond",
        animation: "spin-in",
        hoverAnimation: "glow",
        rarity: "epic",
        category: "anti",
        debuff: {
            temporaryTitle: "🏅 Badge Addict",
            cosmeticDurationHours: 72,
            shameText: "Congratulations! You have earned a badge about earning badges. This is what peak gamification looks like.",
            hideFromLeaderboard: true,
            hideFromLeaderboardHours: 1
        },
        redeemable: false
    },
    GAMIFICATION_VICTIM: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBoxTrap"],
        name: "Gamification Victim",
        description: "You noticed you're being manipulated by points and still can't stop. Welcome.",
        bgColor: "#1a237e",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#3f51b5",
                    position: "0%"
                },
                {
                    color: "#0d0d3b",
                    position: "100%"
                }
            ]
        },
        iconColor: "#c5cae9",
        shape: "hexagon",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "legendary",
        category: "anti",
        debuff: {
            temporaryTitle: "🎮 Willing Participant",
            cosmeticDurationHours: 168,
            shameText: "B.F. Skinner would be proud. You are the pigeon. The XP is the pellet. Keep pecking."
        },
        redeemable: false
    },
    SKINNER_BOX_RESIDENT: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiCage"],
        name: "Skinner Box Resident",
        description: "Checked the leaderboard more than 20 times today. The experiment is working.",
        bgColor: "#004d40",
        gradient: {
            type: "linear",
            angle: "180deg",
            stops: [
                {
                    color: "#009688",
                    position: "0%"
                },
                {
                    color: "#001a14",
                    position: "100%"
                }
            ]
        },
        iconColor: "#80cbc4",
        shape: "circle",
        animation: "pulse",
        hoverAnimation: "glow",
        rarity: "rare",
        category: "anti",
        debuff: {
            hideFromLeaderboard: true,
            hideFromLeaderboardHours: 6,
            temporaryTitle: "🐀 Lab Rat",
            cosmeticDurationHours: 24,
            shameText: "Variable-ratio reinforcement schedule applied successfully. Subject shows no signs of stopping."
        },
        redeemable: true,
        redemptionHint: "Don't check the leaderboard for 24 hours. We dare you.",
        redemptionCondition: {
            type: "WAIT_PERIOD",
            hours: 24
        }
    },
    // ── Educational Puns ──────────────────────────────────────────────────
    PARTICIPATION_ATROPHY: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTiredEye"],
        name: "Participation Atrophy",
        description: "Your participation has atrophied to the point where your avatar started yawning.",
        bgColor: "#5d4037",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#8d6e63",
                    position: "0%"
                },
                {
                    color: "#321911",
                    position: "100%"
                }
            ]
        },
        iconColor: "#d7ccc8",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        rarity: "common",
        category: "anti",
        debuff: {
            xpMultiplier: 0.8,
            xpMultiplierDurationHours: 48,
            avatarDowngrade: "simple",
            temporaryTitle: "💤 Participation Atrophy",
            cosmeticDurationHours: 48,
            shameText: "Your muscles aren't the only things you haven't exercised."
        },
        redeemable: true,
        redemptionHint: "Complete 3 activities in a single day to rehabilitate.",
        redemptionCondition: {
            type: "ACTIVITY_COUNT",
            count: 3,
            period: "day"
        }
    },
    PROCRASTINATION_STATION: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSleepy"],
        name: "Procrastination Station",
        description: "Opened the assignment page 12 times without submitting. The buffer state of homework.",
        bgColor: "#1565c0",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#42a5f5",
                    position: "0%"
                },
                {
                    color: "#0a3069",
                    position: "100%"
                }
            ]
        },
        iconColor: "#bbdefb",
        shape: "hexagon",
        animation: "pulse",
        hoverAnimation: "shake",
        rarity: "common",
        category: "anti",
        debuff: {
            temporaryTitle: "🚂 All Aboard the Procrastination Station",
            cosmeticDurationHours: 24,
            shameText: "You have earned a PhD in Looking At The Assignment Without Doing The Assignment."
        },
        redeemable: true,
        redemptionHint: "Just... submit something. Anything. Please.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    SYLLABUS_SAYS_NO: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiDungeonGate"],
        name: "Syllabus Says No",
        description: "Asked a question that was clearly answered on page 1 of the syllabus.",
        bgColor: "#b71c1c",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#ef5350",
                    position: "0%"
                },
                {
                    color: "#560027",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffcdd2",
        shape: "shield",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            extraDrills: 1,
            temporaryTitle: "📖 Did You Read The Syllabus?",
            cosmeticDurationHours: 24,
            shameText: "The syllabus weeps. It was all there. Page one. Bold. Underlined. Highlighted."
        },
        redeemable: true,
        redemptionHint: "Read the syllabus. (We'll know.)",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    EXTRA_CREDIT_JUNKIE: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSpikedSnail"],
        name: "Extra Credit Junkie",
        description: "Requested extra credit before completing the regular credit. The audacity.",
        bgColor: "#ff6f00",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#ffb74d",
                    position: "0%"
                },
                {
                    color: "#e65100",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fff8e1",
        shape: "circle",
        animation: "bounce-in",
        hoverAnimation: "pulse",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            xpMultiplier: 0.9,
            xpMultiplierDurationHours: 24,
            temporaryTitle: "✨ Extra Credit Enthusiast",
            cosmeticDurationHours: 48,
            shameText: "Asking for extra credit is the academic equivalent of asking for dessert before dinner."
        },
        redeemable: true,
        redemptionHint: "Complete all regular assignments first. Then we'll talk.",
        redemptionCondition: {
            type: "COMPLETE_ASSIGNMENT"
        }
    },
    // ── Making Fun of EdTech ──────────────────────────────────────────────
    ENGAGEMENT_METRICS: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiCuckooClock"],
        name: "Engagement Metrics!",
        description: "Congratulations! Your 'time on platform' metric went up because you left the tab open overnight.",
        bgColor: "#00695c",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#26a69a",
                    position: "0%"
                },
                {
                    color: "#002f29",
                    position: "100%"
                }
            ]
        },
        iconColor: "#b2dfdb",
        shape: "hexagon",
        animation: "spin-in",
        hoverAnimation: "pulse",
        rarity: "rare",
        category: "anti",
        debuff: {
            temporaryTitle: "📊 Metric Manipulator",
            cosmeticDurationHours: 24,
            shameText: "You boosted our engagement metrics! The investors will be thrilled. Learning? That's a different metric."
        },
        redeemable: false
    },
    AI_WHISPERER_ZERO: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSlime"],
        name: "AI Whisperer Zero",
        description: "Asked the AI tutor to do your homework for you. It said no. Even the robot judges you.",
        bgColor: "#4e342e",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#8d6e63",
                    position: "0%"
                },
                {
                    color: "#1b0e08",
                    position: "100%"
                }
            ]
        },
        iconColor: "#a5d6a7",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "shake",
        rarity: "rare",
        category: "anti",
        debuff: {
            xpMultiplier: 0.5,
            xpMultiplierDurationHours: 12,
            temporaryTitle: "🤖 Rejected by AI",
            cosmeticDurationHours: 24,
            shameText: "Even ChatGPT has boundaries. You found them."
        },
        redeemable: true,
        redemptionHint: "Have a genuine learning conversation with the AI tutor.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    ACHIEVEMENT_UNLOCKED_UNLOCKED: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiJesterHat"],
        name: "Achievement Unlocked: Unlocked",
        description: "You unlocked the achievement for unlocking achievements. We need to go deeper.",
        bgColor: "#ad1457",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#f06292",
                    position: "0%"
                },
                {
                    color: "#6a0034",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fce4ec",
        shape: "diamond",
        animation: "spin-in",
        hoverAnimation: "glow",
        rarity: "legendary",
        category: "anti",
        debuff: {
            temporaryTitle: "🎭 Meta Achievement Haver",
            cosmeticDurationHours: 168,
            shameText: "You are now 4 layers deep in gamification irony. There is no going back. The badges are watching."
        },
        redeemable: false
    },
    // ── Streak & Attendance Shame ─────────────────────────────────────────
    STREAK_BREAKER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBrokenShield"],
        name: "Streak Breaker",
        description: "Broke a 14+ day streak. All those consecutive days, gone like tears in rain.",
        bgColor: "#263238",
        gradient: {
            type: "linear",
            angle: "180deg",
            stops: [
                {
                    color: "#546e7a",
                    position: "0%"
                },
                {
                    color: "#000a12",
                    position: "100%"
                }
            ]
        },
        iconColor: "#78909c",
        shape: "shield",
        animation: "shake",
        hoverAnimation: "pulse",
        rarity: "epic",
        category: "anti",
        debuff: {
            streakFreezesRemoved: 2,
            xpMultiplier: 0.7,
            xpMultiplierDurationHours: 48,
            temporaryTitle: "💔 Streak Breaker",
            cosmeticDurationHours: 48,
            shameText: "14 days of dedication, shattered. Your streak didn't die — it was murdered."
        },
        redeemable: true,
        redemptionHint: "Build a new 7-day streak to earn forgiveness.",
        redemptionCondition: {
            type: "BUILD_STREAK",
            count: 7
        }
    },
    GRAVEYARD_SHIFT: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTombstone"],
        name: "Graveyard Shift",
        description: "Submitted homework at 3 AM. The learning was questionable. The dedication was not.",
        bgColor: "#1a1a2e",
        gradient: {
            type: "linear",
            angle: "180deg",
            stops: [
                {
                    color: "#16213e",
                    position: "0%"
                },
                {
                    color: "#0f0f1a",
                    position: "100%"
                }
            ]
        },
        iconColor: "#a0a0b0",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "glow",
        rarity: "common",
        category: "anti",
        debuff: {
            temporaryTitle: "🌙 Night Owl (Derogatory)",
            cosmeticDurationHours: 24,
            shameText: "Nothing good happens after 2 AM. Especially homework."
        },
        redeemable: false
    },
    // ── School-Specific Trouble ───────────────────────────────────────────
    DIGITAL_DETENTION: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiPrisoner"],
        name: "Digital Detention",
        description: "Your behavior in the chat has earned you the world's first virtual detention.",
        bgColor: "#4a148c",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#7b1fa2",
                    position: "0%"
                },
                {
                    color: "#12005e",
                    position: "100%"
                }
            ]
        },
        iconColor: "#e1bee7",
        shape: "shield",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "epic",
        category: "anti",
        debuff: {
            hideFromLeaderboard: true,
            hideFromLeaderboardHours: 24,
            xpMultiplier: 0.5,
            xpMultiplierDurationHours: 24,
            temporaryTitle: "🔒 In Detention",
            cosmeticDurationHours: 24,
            shameText: "You will sit here and think about what you've done. Digitally.",
            extraDrills: 3
        },
        redeemable: true,
        redemptionHint: "Complete your 3 community service drills to earn release.",
        redemptionCondition: {
            type: "COMPLETE_DRILLS",
            count: 3
        }
    },
    THE_GREAT_DISCONNECT: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBrokenHeart"],
        name: "The Great Disconnect",
        description: "Closed the browser tab during a timed quiz. Brave. Foolish. But brave.",
        bgColor: "#c62828",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#ef5350",
                    position: "0%"
                },
                {
                    color: "#7f0000",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffcdd2",
        shape: "diamond",
        animation: "shake",
        hoverAnimation: "pulse",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            xpMultiplier: 0.6,
            xpMultiplierDurationHours: 12,
            temporaryTitle: "🔌 The Disconnector",
            cosmeticDurationHours: 24,
            shameText: '"My internet went out" — your internet, under oath, testifies otherwise.'
        },
        redeemable: true,
        redemptionHint: "Complete a quiz from start to finish without any... interruptions.",
        redemptionCondition: {
            type: "COMPLETE_ASSIGNMENT"
        }
    },
    LOREM_IPSUM_LAUREATE: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiWorms"],
        name: "Lorem Ipsum Laureate",
        description: "Submitted placeholder text as a final answer. Bold strategy, Cotton.",
        bgColor: "#2e7d32",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#66bb6a",
                    position: "0%"
                },
                {
                    color: "#1b3e1f",
                    position: "100%"
                }
            ]
        },
        iconColor: "#c8e6c9",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "shake",
        rarity: "rare",
        category: "anti",
        debuff: {
            xpMultiplier: 0.3,
            xpMultiplierDurationHours: 24,
            avatarDowngrade: "simple",
            temporaryTitle: "📝 Lorem Ipsum Dolor Sit Amet",
            cosmeticDurationHours: 48,
            shameText: "Consectetur adipiscing elit. Sed do eiusmod tempor incididunt. See? We can do it too."
        },
        redeemable: true,
        redemptionHint: "Replace Lorem Ipsum with actual words. In your language. About the topic.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    // ── Gamification Self-Awareness ───────────────────────────────────────
    NOTIFICATION_JUNKIE: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiClown"],
        name: "Notification Junkie",
        description: "Clicked on every single notification within 5 seconds of it appearing. Pavlov sends his regards.",
        bgColor: "#d84315",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#ff8a65",
                    position: "0%"
                },
                {
                    color: "#801a00",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fbe9e7",
        shape: "circle",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            temporaryTitle: "🔔 Ding Ding Ding",
            cosmeticDurationHours: 24,
            shameText: "You hear a notification sound. Your pupils dilate. You click. There is no new content. You wait."
        },
        redeemable: false
    },
    XP_ZERO_HERO: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiCoffin"],
        name: "XP: Zero Hero",
        description: "Completed an entire session and earned exactly 0 XP. A statistical anomaly. A legend.",
        bgColor: "#212121",
        gradient: {
            type: "linear",
            angle: "180deg",
            stops: [
                {
                    color: "#424242",
                    position: "0%"
                },
                {
                    color: "#000000",
                    position: "100%"
                }
            ]
        },
        iconColor: "#757575",
        shape: "shield",
        animation: "draw",
        hoverAnimation: "glow",
        rarity: "legendary",
        category: "anti",
        debuff: {
            temporaryTitle: "🦸 Zero Hero",
            cosmeticDurationHours: 72,
            shameText: "In a system designed to give you points for breathing near homework, you earned none. Respect."
        },
        redeemable: true,
        redemptionHint: "Earn any amount of XP. Literally any. One point. We beg you.",
        redemptionCondition: {
            type: "EARN_XP",
            count: 1
        }
    },
    DUNNING_KRUGER_AWARD: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSpottedMushroom"],
        name: "Dunning-Kruger Award",
        description: "Rated your confidence as 'Expert' on a topic you scored 20% on. Peak human condition.",
        bgColor: "#f57f17",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#ffee58",
                    position: "0%"
                },
                {
                    color: "#f57f17",
                    position: "50%"
                },
                {
                    color: "#8c5100",
                    position: "100%"
                }
            ]
        },
        iconColor: "#fff9c4",
        shape: "diamond",
        animation: "bounce-in",
        hoverAnimation: "glow",
        rarity: "epic",
        category: "anti",
        debuff: {
            xpMultiplier: 0.6,
            xpMultiplierDurationHours: 24,
            temporaryTitle: "🍄 Confidently Incorrect",
            cosmeticDurationHours: 48,
            shameText: "Mount Stupid has a new summit. Plant your flag. You've earned it."
        },
        redeemable: true,
        redemptionHint: "Score 80%+ on the same topic to descend from Mount Stupid.",
        redemptionCondition: {
            type: "SCORE_ON_TOPIC",
            percent: 80
        }
    },
    THE_TUTORIAL_SKIPPER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiDeadEye"],
        name: "The Tutorial Skipper",
        description: "Skipped every tutorial, help text, and instruction. Then asked how everything works.",
        bgColor: "#311b92",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#5c6bc0",
                    position: "0%"
                },
                {
                    color: "#0c0040",
                    position: "100%"
                }
            ]
        },
        iconColor: "#c5cae9",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "shake",
        rarity: "common",
        category: "anti",
        debuff: {
            extraDrills: 1,
            temporaryTitle: "⏩ TLDR Enthusiast",
            cosmeticDurationHours: 24,
            shameText: "Instructions? Where we're going, we don't need instructions. (You do. You really do.)"
        },
        redeemable: true,
        redemptionHint: "Complete the tutorial. The whole thing. Yes, all of it.",
        redemptionCondition: {
            type: "COMPLETE_ASSIGNMENT"
        }
    },
    INFINITE_LOOP_LEARNER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTurtle"],
        name: "Infinite Loop Learner",
        description: "Watched the same lesson video 10+ times without attempting the practice. Loading...",
        bgColor: "#0d47a1",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#1976d2",
                    position: "0%"
                },
                {
                    color: "#051e3e",
                    position: "100%"
                }
            ]
        },
        iconColor: "#bbdefb",
        shape: "hexagon",
        animation: "pulse",
        hoverAnimation: "spin-in",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            temporaryTitle: "🔁 while(true) { watch(); }",
            cosmeticDurationHours: 24,
            shameText: "Watching ≠ learning. We checked. There's a whole field of research about this."
        },
        redeemable: true,
        redemptionHint: "Attempt the practice activity. The video will still be there, we promise.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    MINIMALLY_VIABLE_STUDENT: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiAnvil"],
        name: "Minimally Viable Student",
        description: "Consistently submits work that meets exactly 0.01% above the minimum threshold. An optimization marvel.",
        bgColor: "#546e7a",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#78909c",
                    position: "0%"
                },
                {
                    color: "#1c313a",
                    position: "100%"
                }
            ]
        },
        iconColor: "#cfd8dc",
        shape: "shield",
        animation: "draw",
        hoverAnimation: "pulse",
        rarity: "rare",
        category: "anti",
        debuff: {
            xpMultiplier: 0.85,
            xpMultiplierDurationHours: 48,
            temporaryTitle: "📉 MVP (Minimum Viable Participant)",
            cosmeticDurationHours: 48,
            shameText: "You found the exact minimum effort threshold. Engineers call this optimization. Teachers call it something else."
        },
        redeemable: true,
        redemptionHint: "Score above 90% on any assignment to prove the minimum isn't your maximum.",
        redemptionCondition: {
            type: "ACCURACY_ABOVE",
            percent: 90
        }
    },
    EMPTY_CANVAS_ARTIST: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTransparentSlime"],
        name: "Empty Canvas Artist",
        description: "Submitted a completely blank response. It's not modern art. It's just blank.",
        bgColor: "#e0e0e0",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#fafafa",
                    position: "0%"
                },
                {
                    color: "#9e9e9e",
                    position: "100%"
                }
            ]
        },
        iconColor: "#bdbdbd",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        rarity: "common",
        category: "anti",
        debuff: {
            xpMultiplier: 0,
            xpMultiplierDurationHours: 6,
            temporaryTitle: '🎨 " "',
            cosmeticDurationHours: 12,
            shameText: "John Cage had 4'33\". You have 0 characters. Equally avant-garde. Equally ungraded."
        },
        redeemable: true,
        redemptionHint: "Submit literally anything. A haiku. A grocery list. Just not nothing.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    },
    BUG_REPORT_OR_EXCUSE: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBugNet"],
        name: "Bug Report or Excuse?",
        description: "Filed a 'bug report' that suspiciously coincided with a deadline. The platform worked fine for everyone else.",
        bgColor: "#1b5e20",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#43a047",
                    position: "0%"
                },
                {
                    color: "#0a2e0f",
                    position: "100%"
                }
            ]
        },
        iconColor: "#a5d6a7",
        shape: "hexagon",
        animation: "bounce-in",
        hoverAnimation: "shake",
        rarity: "uncommon",
        category: "anti",
        debuff: {
            temporaryTitle: "🐛 QA Specialist (Self-Appointed)",
            cosmeticDurationHours: 24,
            shameText: "Steps to reproduce: 1) Have assignment due. 2) Don't do assignment. 3) Report 'bug'."
        },
        redeemable: true,
        redemptionHint: "Submit the assignment and the 'bug' will mysteriously resolve itself.",
        redemptionCondition: {
            type: "SUBMIT_ANY"
        }
    }
};
function getAllAntiBadgeTypes() {
    return Object.keys(ANTI_BADGE_REGISTRY);
}
function getAntiBadgeConfig(badgeType) {
    return ANTI_BADGE_REGISTRY[badgeType];
}
function getRedeemableAntiBadges() {
    return Object.entries(ANTI_BADGE_REGISTRY).filter(([, config])=>config.redeemable);
}
function getAntiBadgesByRarity(rarity) {
    return Object.entries(ANTI_BADGE_REGISTRY).filter(([, config])=>config.rarity === rarity);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/BadgeShelf.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BadgeShelf",
    ()=>BadgeShelf,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * BadgeShelf — Grid display of achievement badges.
 * Earned badges show in full color; unearned badges are grayed out with a lock overlay.
 *
 * @module BadgeShelf
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Popover/Popover.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BadgeIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$antiBadgeRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/antiBadgeRegistry.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
const BADGE_DEFINITIONS = {
    FIRST_SUBMISSION: {
        name: 'First Submission',
        description: 'Submitted your first homework'
    },
    GOOD_EYE: {
        name: 'Good Eye',
        description: 'Revised work after AI feedback'
    },
    QUICK_DRAW: {
        name: 'Quick Draw',
        description: 'Submitted before the due date'
    },
    SHARPSHOOTER: {
        name: 'Sharpshooter',
        description: 'Scored 90%+ on an assignment'
    },
    CONSISTENT: {
        name: 'Consistent',
        description: 'Maintained a 7-day streak'
    },
    TEAM_PLAYER: {
        name: 'Team Player',
        description: 'Completed a peer review'
    },
    DEEP_THINKER: {
        name: 'Deep Thinker',
        description: 'Completed all blocks in a unit'
    },
    TOP_OF_CLASS: {
        name: 'Top of Class',
        description: 'Reached #1 on the leaderboard'
    },
    PERFECTIONIST: {
        name: 'Perfectionist',
        description: 'Scored 100% on an assignment'
    },
    // Avatar unlock badges
    AVATAR_COLORS: {
        name: 'Color Unlocked',
        description: 'Reached Level 2 — unlock avatar color picker'
    },
    AVATAR_DETAILED: {
        name: 'New Look',
        description: 'Reached Level 3 — unlocked detailed avatar style'
    },
    AVATAR_ACCESSORIES: {
        name: 'Accessorized',
        description: 'Reached Level 4 — unlock avatar accessories'
    },
    AVATAR_PORTRAIT: {
        name: 'Portrait Mode',
        description: 'Reached Level 5 — unlocked portrait avatar style & full customizer'
    },
    // Bot Whisperer tiered badges
    BOT_WHISPERER_I: {
        name: 'Bot Whisperer I',
        description: 'Had your first real conversation with the AI tutor'
    },
    BOT_WHISPERER_II: {
        name: 'Bot Whisperer II',
        description: 'Earned Deep Thinker — upgraded your bot\'s style'
    },
    BOT_WHISPERER_III: {
        name: 'Bot Whisperer III',
        description: 'Used AI across 5 units — choose your bot\'s eyes & mouth'
    },
    BOT_WHISPERER_IV: {
        name: 'Bot Whisperer IV',
        description: 'AI mastery achieved — full bot customization unlocked'
    },
    // Avatar powerup badges
    AVATAR_GLOW: {
        name: 'Glow Ring',
        description: 'Level up! — rotating gradient ring around your avatar for 24 hours'
    },
    // Storybook documentation promo badges
    DOCS_EXPLORER: {
        name: 'Docs Explorer',
        description: 'Visited the Storybook documentation and started onboarding'
    },
    INSTRUCTOR_ONBOARD: {
        name: 'Instructor Certified',
        description: 'Completed the instructor onboarding in Storybook'
    },
    LEARNER_ONBOARD: {
        name: 'Learner Certified',
        description: 'Completed the learner onboarding in Storybook'
    },
    TRANSLATOR_ONBOARD: {
        name: 'Translator Certified',
        description: 'Completed the translator onboarding in Storybook'
    },
    A11Y_CHAMPION: {
        name: 'Accessibility Champion',
        description: 'Completed accessibility-related tasks in Storybook'
    },
    DOCS_CHAMPION: {
        name: 'Documentation Champion',
        description: 'Completed all onboarding paths — instructor, learner, and translator'
    }
};
const ALL_BADGE_TYPES = Object.keys(BADGE_DEFINITIONS);
_c = ALL_BADGE_TYPES;
function BadgeShelf(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(28);
    if ($[0] !== "ca946ada4559f58dc810c9cdb40a3bb87cf54fa66149c31c23093670e4d98195") {
        for(let $i = 0; $i < 28; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "ca946ada4559f58dc810c9cdb40a3bb87cf54fa66149c31c23093670e4d98195";
    }
    const { earnedBadges, earnedOnly: t1 } = t0;
    const earnedOnly = t1 === undefined ? false : t1;
    const regularEarned = earnedBadges.filter(_BadgeShelfEarnedBadgesFilter);
    const antiEarned = earnedBadges.filter(_BadgeShelfEarnedBadgesFilter2);
    const earnedSet = new Set(regularEarned.map(_BadgeShelfRegularEarnedMap));
    let t2;
    if ($[1] !== earnedBadges) {
        t2 = earnedBadges.reduce(_BadgeShelfEarnedBadgesReduce, {});
        $[1] = earnedBadges;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const earnedCounts = t2;
    const badgesToShow = earnedOnly ? ALL_BADGE_TYPES.filter({
        "BadgeShelf[ALL_BADGE_TYPES.filter()]": (type)=>earnedSet.has(type)
    }["BadgeShelf[ALL_BADGE_TYPES.filter()]"]) : ALL_BADGE_TYPES;
    const [anchorEl, setAnchorEl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [activeBadge, setActiveBadge] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [activeIsAnti, setActiveIsAnti] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "BadgeShelf[handleClick]": (event, type_0, t4)=>{
                const isAnti = t4 === undefined ? false : t4;
                setAnchorEl(event.currentTarget);
                setActiveBadge(type_0);
                setActiveIsAnti(isAnti);
            }
        })["BadgeShelf[handleClick]"];
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const handleClick = t3;
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "BadgeShelf[handleClose]": ()=>{
                setAnchorEl(null);
                setActiveBadge(null);
                setActiveIsAnti(false);
            }
        })["BadgeShelf[handleClose]"];
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    const handleClose = t4;
    const activeDef = activeBadge && !activeIsAnti ? BADGE_DEFINITIONS[activeBadge] : null;
    let t5;
    if ($[5] !== activeBadge || $[6] !== activeIsAnti) {
        t5 = activeBadge && activeIsAnti ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$antiBadgeRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAntiBadgeConfig"])(activeBadge) : null;
        $[5] = activeBadge;
        $[6] = activeIsAnti;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    const activeAntiConfig = t5;
    const activeEarned = activeBadge ? earnedBadges.find({
        "BadgeShelf[earnedBadges.find()]": (b_3)=>b_3.badgeType === activeBadge
    }["BadgeShelf[earnedBadges.find()]"]) : null;
    const activeIsEarned = activeBadge ? activeIsAnti ? antiEarned.some({
        "BadgeShelf[antiEarned.some()]": (b_4)=>b_4.badgeType === activeBadge
    }["BadgeShelf[antiEarned.some()]"]) : earnedSet.has(activeBadge) : false;
    const activeCount = activeBadge ? earnedCounts[activeBadge] || 0 : 0;
    let t6;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            display: "flex",
            flexWrap: "wrap",
            gap: 1,
            alignItems: "center"
        };
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    const t7 = badgesToShow.map({
        "BadgeShelf[badgesToShow.map()]": (type_1)=>{
            const def = BADGE_DEFINITIONS[type_1];
            const isEarned = earnedSet.has(type_1);
            const count = earnedCounts[type_1] || 0;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: def.name,
                arrow: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    onClick: {
                        "BadgeShelf[badgesToShow.map() > <Box>.onClick]": (e)=>handleClick(e, type_1)
                    }["BadgeShelf[badgesToShow.map() > <Box>.onClick]"],
                    sx: {
                        position: "relative",
                        cursor: "pointer"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeIcon"], {
                            badgeType: type_1,
                            size: 56,
                            earned: isEarned,
                            animate: isEarned,
                            drawIcon: isEarned
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                            lineNumber: 254,
                            columnNumber: 12
                        }, this),
                        isEarned && count > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "caption",
                            sx: {
                                position: "absolute",
                                bottom: -2,
                                right: -2,
                                fontSize: "0.625rem",
                                fontWeight: 800,
                                color: "primary.main",
                                bgcolor: "background.paper",
                                borderRadius: "50%",
                                width: 18,
                                height: 18,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                boxShadow: 1,
                                lineHeight: 1
                            },
                            children: [
                                "×",
                                count
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                            lineNumber: 254,
                            columnNumber: 137
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                    lineNumber: 249,
                    columnNumber: 66
                }, this)
            }, type_1, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 249,
                columnNumber: 14
            }, this);
        }
    }["BadgeShelf[badgesToShow.map()]"]);
    let t8;
    if ($[9] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t6,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
            lineNumber: 275,
            columnNumber: 10
        }, this);
        $[9] = t7;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    const t9 = antiEarned.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    my: 2
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    label: "Anti-Badges",
                    size: "small",
                    color: "error",
                    variant: "outlined",
                    sx: {
                        fontWeight: 700,
                        fontSize: "0.7rem"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                    lineNumber: 283,
                    columnNumber: 8
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 281,
                columnNumber: 41
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    display: "flex",
                    flexWrap: "wrap",
                    gap: 1,
                    alignItems: "center"
                },
                children: antiEarned.map({
                    "BadgeShelf[antiEarned.map()]": (badge)=>{
                        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$antiBadgeRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAntiBadgeConfig"])(badge.badgeType);
                        const count_0 = earnedCounts[badge.badgeType] || 1;
                        if (!config) {
                            return null;
                        }
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            title: config.name,
                            arrow: true,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                onClick: {
                                    "BadgeShelf[antiEarned.map() > <Box>.onClick]": (e_0)=>handleClick(e_0, badge.badgeType, true)
                                }["BadgeShelf[antiEarned.map() > <Box>.onClick]"],
                                sx: {
                                    position: "relative",
                                    cursor: "pointer",
                                    border: "2px solid",
                                    borderColor: "error.main",
                                    borderRadius: "50%",
                                    p: 0.25
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeIcon"], {
                                        config: config,
                                        size: 56,
                                        earned: true,
                                        animate: true,
                                        drawIcon: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                                        lineNumber: 307,
                                        columnNumber: 16
                                    }, this),
                                    count_0 > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        variant: "caption",
                                        sx: {
                                            position: "absolute",
                                            bottom: -2,
                                            right: -2,
                                            fontSize: "0.625rem",
                                            fontWeight: 800,
                                            color: "error.main",
                                            bgcolor: "background.paper",
                                            borderRadius: "50%",
                                            width: 18,
                                            height: 18,
                                            display: "flex",
                                            alignItems: "center",
                                            justifyContent: "center",
                                            boxShadow: 1,
                                            lineHeight: 1
                                        },
                                        children: [
                                            "×",
                                            count_0
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                                        lineNumber: 307,
                                        columnNumber: 116
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                                lineNumber: 298,
                                columnNumber: 82
                            }, this)
                        }, badge.badgeType, false, {
                            fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                            lineNumber: 298,
                            columnNumber: 18
                        }, this);
                    }
                }["BadgeShelf[antiEarned.map()]"])
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 286,
                columnNumber: 22
            }, this)
        ]
    }, void 0, true);
    const T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
    const t10 = Boolean(anchorEl);
    let t11;
    let t12;
    let t13;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            vertical: "bottom",
            horizontal: "center"
        };
        t12 = {
            vertical: "top",
            horizontal: "center"
        };
        t13 = {
            paper: {
                sx: {
                    p: 2,
                    maxWidth: 260,
                    borderRadius: 2
                }
            }
        };
        $[11] = t11;
        $[12] = t12;
        $[13] = t13;
    } else {
        t11 = $[11];
        t12 = $[12];
        t13 = $[13];
    }
    const t14 = activeDef && !activeIsAnti && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        spacing: 0.5,
        alignItems: "center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeIcon"], {
                badgeType: activeBadge,
                size: 48,
                earned: activeIsEarned,
                animate: false,
                drawIcon: false
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 357,
                columnNumber: 86
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "subtitle2",
                fontWeight: 700,
                children: activeDef.name
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 357,
                columnNumber: 190
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "text.secondary",
                textAlign: "center",
                children: activeDef.description
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 357,
                columnNumber: 268
            }, this),
            activeIsEarned && activeEarned && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                sx: {
                    opacity: 0.7
                },
                children: [
                    "Earned ",
                    new Date(activeEarned.awardedAt).toLocaleDateString()
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 357,
                columnNumber: 411
            }, this),
            activeIsEarned && activeCount > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                fontWeight: 700,
                color: "primary.main",
                children: [
                    "Earned ",
                    activeCount,
                    " times"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 359,
                columnNumber: 122
            }, this),
            !activeIsEarned && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "text.disabled",
                fontStyle: "italic",
                children: "Locked"
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 359,
                columnNumber: 250
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
        lineNumber: 357,
        columnNumber: 45
    }, this);
    const t15 = activeAntiConfig && activeIsAnti && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        spacing: 0.5,
        alignItems: "center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeIcon"], {
                config: activeAntiConfig,
                size: 48,
                earned: true,
                animate: false,
                drawIcon: false
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 360,
                columnNumber: 92
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "subtitle2",
                fontWeight: 700,
                color: "error.main",
                children: activeAntiConfig.name
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 360,
                columnNumber: 188
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "text.secondary",
                textAlign: "center",
                children: activeAntiConfig.description
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 360,
                columnNumber: 292
            }, this),
            activeAntiConfig.debuff.shameText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                fontStyle: "italic",
                color: "error",
                textAlign: "center",
                sx: {
                    opacity: 0.8
                },
                children: [
                    "“",
                    activeAntiConfig.debuff.shameText,
                    "”"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 360,
                columnNumber: 445
            }, this),
            activeAntiConfig.debuff.xpMultiplier != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                label: `XP ×${activeAntiConfig.debuff.xpMultiplier} for ${activeAntiConfig.debuff.xpMultiplierDurationHours || 24}h`,
                size: "small",
                color: "error",
                variant: "outlined",
                sx: {
                    fontSize: "0.65rem"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 362,
                columnNumber: 108
            }, this),
            activeAntiConfig.debuff.temporaryTitle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                label: `Title: "${activeAntiConfig.debuff.temporaryTitle}"`,
                size: "small",
                variant: "outlined",
                sx: {
                    fontSize: "0.65rem"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 364,
                columnNumber: 54
            }, this),
            activeAntiConfig.redeemable && activeAntiConfig.redemptionHint && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "success.main",
                textAlign: "center",
                sx: {
                    mt: 0.5
                },
                children: [
                    "Redeemable: ",
                    activeAntiConfig.redemptionHint
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 366,
                columnNumber: 78
            }, this),
            activeIsEarned && activeEarned && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                sx: {
                    opacity: 0.7
                },
                children: [
                    "Received ",
                    new Date(activeEarned.awardedAt).toLocaleDateString()
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 368,
                columnNumber: 102
            }, this),
            activeCount > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                fontWeight: 700,
                color: "error.main",
                children: [
                    "Received ",
                    activeCount,
                    " times"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
                lineNumber: 370,
                columnNumber: 106
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
        lineNumber: 360,
        columnNumber: 51
    }, this);
    let t16;
    if ($[14] !== T0 || $[15] !== anchorEl || $[16] !== handleClose || $[17] !== t10 || $[18] !== t11 || $[19] !== t12 || $[20] !== t13 || $[21] !== t14 || $[22] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            open: t10,
            anchorEl: anchorEl,
            onClose: handleClose,
            anchorOrigin: t11,
            transformOrigin: t12,
            slotProps: t13,
            children: [
                t14,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/BadgeShelf.tsx",
            lineNumber: 373,
            columnNumber: 11
        }, this);
        $[14] = T0;
        $[15] = anchorEl;
        $[16] = handleClose;
        $[17] = t10;
        $[18] = t11;
        $[19] = t12;
        $[20] = t13;
        $[21] = t14;
        $[22] = t15;
        $[23] = t16;
    } else {
        t16 = $[23];
    }
    let t17;
    if ($[24] !== t16 || $[25] !== t8 || $[26] !== t9) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t8,
                t9,
                t16
            ]
        }, void 0, true);
        $[24] = t16;
        $[25] = t8;
        $[26] = t9;
        $[27] = t17;
    } else {
        t17 = $[27];
    }
    return t17;
}
_s(BadgeShelf, "zBzQ/K9kM7VNPnGI6jPrHTcDicw=");
_c1 = BadgeShelf;
function _BadgeShelfEarnedBadgesReduce(acc, b_2) {
    const badgeCount = b_2.count && b_2.count > 1 ? b_2.count : 1;
    acc[b_2.badgeType] = (acc[b_2.badgeType] || 0) + badgeCount;
    return acc;
}
function _BadgeShelfRegularEarnedMap(b_1) {
    return b_1.badgeType;
}
function _BadgeShelfEarnedBadgesFilter2(b_0) {
    return b_0.isAnti;
}
function _BadgeShelfEarnedBadgesFilter(b) {
    return !b.isAnti;
}
const __TURBOPACK__default__export__ = BadgeShelf;
var _c, _c1;
__turbopack_context__.k.register(_c, "ALL_BADGE_TYPES");
__turbopack_context__.k.register(_c1, "BadgeShelf");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/NailedItWall.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NailedItWall",
    ()=>NailedItWall,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Grid/Grid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
;
;
;
;
;
;
function formatDate(dateStr) {
    try {
        return new Date(dateStr).toLocaleDateString();
    } catch  {
        return dateStr;
    }
}
function NailedItWall(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "48123b89d4a4d0738094895703603c36fbc08778d02e972f49b5f637c60dd00e") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "48123b89d4a4d0738094895703603c36fbc08778d02e972f49b5f637c60dd00e";
    }
    const { blocks } = t0;
    if (!blocks || blocks.length === 0) {
        let t1;
        if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
            t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "body2",
                color: "text.secondary",
                children: "No Nailed It moments yet — keep going!"
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/NailedItWall.tsx",
                lineNumber: 44,
                columnNumber: 12
            }, this);
            $[1] = t1;
        } else {
            t1 = $[1];
        }
        return t1;
    }
    let t1;
    if ($[2] !== blocks) {
        t1 = blocks.map(_NailedItWallBlocksMap);
        $[2] = blocks;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    let t2;
    if ($[4] !== t1) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            container: true,
            spacing: 2,
            children: t1
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/NailedItWall.tsx",
            lineNumber: 61,
            columnNumber: 10
        }, this);
        $[4] = t1;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    return t2;
}
_c = NailedItWall;
function _NailedItWallBlocksMap(block) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        size: {
            xs: 12,
            sm: 6
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                borderLeft: "4px solid",
                borderColor: "success.main"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "overline",
                        color: "success.main",
                        children: "🎯 Nailed It"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/NailedItWall.tsx",
                        lineNumber: 76,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "body2",
                        fontWeight: 600,
                        children: block.question
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/NailedItWall.tsx",
                        lineNumber: 76,
                        columnNumber: 98
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "caption",
                        color: "text.secondary",
                        component: "p",
                        mt: 1,
                        children: block.nailedItReason
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/NailedItWall.tsx",
                        lineNumber: 76,
                        columnNumber: 172
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "caption",
                        display: "block",
                        color: "text.disabled",
                        mt: 0.5,
                        children: [
                            block.homeworkTitle,
                            " · ",
                            formatDate(block.createdAt)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Gamification/NailedItWall.tsx",
                        lineNumber: 76,
                        columnNumber: 281
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/NailedItWall.tsx",
                lineNumber: 76,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/NailedItWall.tsx",
            lineNumber: 73,
            columnNumber: 21
        }, this)
    }, block.id, false, {
        fileName: "[project]/src/components/Gamification/NailedItWall.tsx",
        lineNumber: 70,
        columnNumber: 10
    }, this);
}
const __TURBOPACK__default__export__ = NailedItWall;
var _c;
__turbopack_context__.k.register(_c, "NailedItWall");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/ProgressRings.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProgressRings",
    ()=>ProgressRings,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * ProgressRings — Circular progress indicators showing per-module completion.
 *
 * Renders 1–5 rings with milestone markers at 25%, 50%, 75%.
 *
 * @module ProgressRings
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CircularProgress/CircularProgress.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Star.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
function getMilestoneStars(percent) {
    if (percent >= 75) return 3;
    if (percent >= 50) return 2;
    if (percent >= 25) return 1;
    return 0;
}
function ProgressRing(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(27);
    if ($[0] !== "e78714e2aa43b2d05a0b22897494d6f4686339a4d6f5afaa849c8425b413c28d") {
        for(let $i = 0; $i < 27; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e78714e2aa43b2d05a0b22897494d6f4686339a4d6f5afaa849c8425b413c28d";
    }
    const { module } = t0;
    let t1;
    if ($[1] !== module.completionPercent || $[2] !== module.moduleName) {
        const stars = getMilestoneStars(module.completionPercent);
        let t2;
        if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = {
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 0.5
            };
            $[4] = t2;
        } else {
            t2 = $[4];
        }
        let t3;
        if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = {
                position: "relative",
                display: "inline-flex"
            };
            $[5] = t3;
        } else {
            t3 = $[5];
        }
        let t4;
        if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "determinate",
                value: 100,
                size: 72,
                thickness: 4,
                sx: {
                    color: "action.disabledBackground"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
                lineNumber: 72,
                columnNumber: 12
            }, this);
            $[6] = t4;
        } else {
            t4 = $[6];
        }
        const t5 = module.completionPercent >= 100 ? "success.main" : "primary.main";
        let t6;
        if ($[7] !== t5) {
            t6 = {
                position: "absolute",
                left: 0,
                color: t5
            };
            $[7] = t5;
            $[8] = t6;
        } else {
            t6 = $[8];
        }
        let t7;
        if ($[9] !== module.completionPercent || $[10] !== t6) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "determinate",
                value: module.completionPercent,
                size: 72,
                thickness: 4,
                sx: t6
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
                lineNumber: 94,
                columnNumber: 12
            }, this);
            $[9] = module.completionPercent;
            $[10] = t6;
            $[11] = t7;
        } else {
            t7 = $[11];
        }
        let t8;
        if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
            t8 = {
                top: 0,
                left: 0,
                bottom: 0,
                right: 0,
                position: "absolute",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            };
            $[12] = t8;
        } else {
            t8 = $[12];
        }
        let t9;
        if ($[13] !== module.completionPercent) {
            t9 = Math.round(module.completionPercent);
            $[13] = module.completionPercent;
            $[14] = t9;
        } else {
            t9 = $[14];
        }
        let t10;
        if ($[15] !== t9) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t8,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "caption",
                    fontWeight: 700,
                    color: "text.primary",
                    children: [
                        t9,
                        "%"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
                    lineNumber: 127,
                    columnNumber: 26
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
                lineNumber: 127,
                columnNumber: 13
            }, this);
            $[15] = t9;
            $[16] = t10;
        } else {
            t10 = $[16];
        }
        let t11;
        if ($[17] !== t10 || $[18] !== t7) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t3,
                children: [
                    t4,
                    t7,
                    t10
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
                lineNumber: 135,
                columnNumber: 13
            }, this);
            $[17] = t10;
            $[18] = t7;
            $[19] = t11;
        } else {
            t11 = $[19];
        }
        let t12;
        if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
            t12 = {
                maxWidth: 80,
                textAlign: "center",
                lineHeight: 1.2
            };
            $[20] = t12;
        } else {
            t12 = $[20];
        }
        let t13;
        if ($[21] !== module.moduleName) {
            t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "text.secondary",
                sx: t12,
                children: module.moduleName
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
                lineNumber: 155,
                columnNumber: 13
            }, this);
            $[21] = module.moduleName;
            $[22] = t13;
        } else {
            t13 = $[22];
        }
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t2,
            children: [
                t11,
                t13,
                stars > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        display: "flex",
                        gap: 0.25
                    },
                    children: Array.from({
                        length: stars
                    }).map(_ProgressRingAnonymous)
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
                    lineNumber: 161,
                    columnNumber: 47
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
            lineNumber: 161,
            columnNumber: 10
        }, this);
        $[1] = module.completionPercent;
        $[2] = module.moduleName;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const content = t1;
    const t2 = `/unit/${module.moduleId}`;
    let t3;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            textDecoration: "none",
            color: "inherit"
        };
        $[23] = t3;
    } else {
        t3 = $[23];
    }
    let t4;
    if ($[24] !== content || $[25] !== t2) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: t2,
            style: t3,
            children: content
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
            lineNumber: 187,
            columnNumber: 10
        }, this);
        $[24] = content;
        $[25] = t2;
        $[26] = t4;
    } else {
        t4 = $[26];
    }
    return t4;
}
_c = ProgressRing;
function _ProgressRingAnonymous(_, i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: 12,
            color: "warning.main"
        }
    }, i, false, {
        fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
        lineNumber: 197,
        columnNumber: 10
    }, this);
}
function ProgressRings(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "e78714e2aa43b2d05a0b22897494d6f4686339a4d6f5afaa849c8425b413c28d") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e78714e2aa43b2d05a0b22897494d6f4686339a4d6f5afaa849c8425b413c28d";
    }
    const { modules } = t0;
    if (modules.length === 0) {
        let t1;
        if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
            t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "body2",
                color: "text.secondary",
                children: "No modules started yet."
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
                lineNumber: 216,
                columnNumber: 12
            }, this);
            $[1] = t1;
        } else {
            t1 = $[1];
        }
        return t1;
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            flexWrap: "wrap",
            gap: 2,
            justifyContent: "center"
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== modules) {
        t2 = modules.map(_ProgressRingsModulesMap);
        $[3] = modules;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            spacing: 2,
            sx: t1,
            children: t2
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
            lineNumber: 244,
            columnNumber: 10
        }, this);
        $[5] = t2;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    return t3;
}
_c1 = ProgressRings;
function _ProgressRingsModulesMap(mod) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ProgressRing, {
        module: mod
    }, mod.moduleId, false, {
        fileName: "[project]/src/components/Gamification/ProgressRings.tsx",
        lineNumber: 253,
        columnNumber: 10
    }, this);
}
const __TURBOPACK__default__export__ = ProgressRings;
var _c, _c1;
__turbopack_context__.k.register(_c, "ProgressRing");
__turbopack_context__.k.register(_c1, "ProgressRings");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/NarrativeReader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NarrativeReader",
    ()=>NarrativeReader,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposer.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalRichTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalRichTextPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalContentEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalErrorBoundary.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalCheckListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalCheckListPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalClickableLinkPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalClickableLinkPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHashtagPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHashtagPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHorizontalRulePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHorizontalRulePlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalListPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalTabIndentationPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalTabIndentationPlugin.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalTablePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalTablePlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalMarkdownShortcutPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalMarkdownShortcutPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$AudioPlayerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/context/AudioPlayerContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$SharedAutocompleteContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/context/SharedAutocompleteContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DndWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/DndWrapper.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$config$2f$LanguageEditorTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/config/LanguageEditorTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$YouTubePlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/YouTubePlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$WordBlockPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/QuizPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/MeaningAssociationPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PdfViewerPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/PdfViewerPlugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ImagesPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/ImagesPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/AnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/CustomAnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ArmorEditorPlugin$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/ArmorEditorPlugin.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/editorConfig.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function NarrativeStatePlugin({ contentJson }) {
    _s();
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const hasLoaded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NarrativeStatePlugin.useEffect": ()=>{
            if (hasLoaded.current || !contentJson) return;
            // Plain text that isn't JSON (e.g. AI-generated text responses)
            // Insert as a plain paragraph so it still renders visibly
            if (typeof contentJson === 'string') {
                const trimmed = contentJson.trimStart();
                if (trimmed.length > 0 && trimmed[0] !== '{' && trimmed[0] !== '[') {
                    editor.update({
                        "NarrativeStatePlugin.useEffect": ()=>{
                            const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
                            root.clear();
                            const paragraph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])();
                            paragraph.append((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(contentJson));
                            root.append(paragraph);
                        }
                    }["NarrativeStatePlugin.useEffect"]);
                    hasLoaded.current = true;
                    return;
                }
            }
            try {
                const parsed = typeof contentJson === 'string' ? JSON.parse(contentJson) : contentJson;
                if (parsed) {
                    const editorState = editor.parseEditorState(parsed);
                    queueMicrotask({
                        "NarrativeStatePlugin.useEffect": ()=>{
                            editor.setEditorState(editorState);
                        }
                    }["NarrativeStatePlugin.useEffect"]);
                    hasLoaded.current = true;
                }
            } catch (err) {
                console.error('[NarrativeStatePlugin] Failed to load content:', err);
            }
        }
    }["NarrativeStatePlugin.useEffect"], [
        contentJson,
        editor
    ]);
    // Reset when content changes (e.g. navigating between chapters)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NarrativeStatePlugin.useEffect": ()=>{
            hasLoaded.current = false;
        }
    }["NarrativeStatePlugin.useEffect"], [
        contentJson
    ]);
    return null;
}
_s(NarrativeStatePlugin, "YSLMNhc5pS+6fZMuegi/kQB4590=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = NarrativeStatePlugin;
function NarrativeReader(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(37);
    if ($[0] !== "1512fda47bd0c5fa1045c77fbe95d232203c7f9891def09b8fd866fd44123f92") {
        for(let $i = 0; $i < 37; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "1512fda47bd0c5fa1045c77fbe95d232203c7f9891def09b8fd866fd44123f92";
    }
    const { contentJson, maxHeight, ariaLabel: t1, className, padding: t2 } = t0;
    const ariaLabel = t1 === undefined ? "Narrative content" : t1;
    const padding = t2 === undefined ? "1rem" : t2;
    let t3;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            namespace: "NarrativeReader",
            theme: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$config$2f$LanguageEditorTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
            onError: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onError"],
            editable: false,
            editorState: null,
            nodes: [
                ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EditorNodes"]
            ]
        };
        $[1] = t3;
    } else {
        t3 = $[1];
    }
    const initialConfig = t3;
    let t10;
    let t11;
    let t12;
    let t13;
    let t14;
    let t15;
    let t16;
    let t17;
    let t18;
    let t19;
    let t20;
    let t21;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalCheckListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CheckListPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 169,
            columnNumber: 10
        }, this);
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHashtagPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HashtagPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 170,
            columnNumber: 10
        }, this);
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHorizontalRulePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HorizontalRulePlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 171,
            columnNumber: 10
        }, this);
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 172,
            columnNumber: 10
        }, this);
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalTabIndentationPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TabIndentationPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 173,
            columnNumber: 10
        }, this);
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalMarkdownShortcutPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MarkdownShortcutPlugin"], {
            transformers: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ALL_TRANSFORMERS"]
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 174,
            columnNumber: 10
        }, this);
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalTablePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TablePlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 175,
            columnNumber: 11
        }, this);
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalClickableLinkPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ClickableLinkPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 176,
            columnNumber: 11
        }, this);
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$YouTubePlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 177,
            columnNumber: 11
        }, this);
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$WordBlockPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 178,
            columnNumber: 11
        }, this);
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 179,
            columnNumber: 11
        }, this);
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 180,
            columnNumber: 11
        }, this);
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 181,
            columnNumber: 11
        }, this);
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PdfViewerPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 182,
            columnNumber: 11
        }, this);
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ImagesPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            captionsEnabled: false
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 183,
            columnNumber: 11
        }, this);
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 184,
            columnNumber: 11
        }, this);
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 185,
            columnNumber: 11
        }, this);
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ArmorEditorPlugin$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        $[2] = t10;
        $[3] = t11;
        $[4] = t12;
        $[5] = t13;
        $[6] = t14;
        $[7] = t15;
        $[8] = t16;
        $[9] = t17;
        $[10] = t18;
        $[11] = t19;
        $[12] = t20;
        $[13] = t21;
        $[14] = t4;
        $[15] = t5;
        $[16] = t6;
        $[17] = t7;
        $[18] = t8;
        $[19] = t9;
    } else {
        t10 = $[2];
        t11 = $[3];
        t12 = $[4];
        t13 = $[5];
        t14 = $[6];
        t15 = $[7];
        t16 = $[8];
        t17 = $[9];
        t18 = $[10];
        t19 = $[11];
        t20 = $[12];
        t21 = $[13];
        t4 = $[14];
        t5 = $[15];
        t6 = $[16];
        t7 = $[17];
        t8 = $[18];
        t9 = $[19];
    }
    let t22;
    if ($[20] !== contentJson) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NarrativeStatePlugin, {
            contentJson: contentJson
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 227,
            columnNumber: 11
        }, this);
        $[20] = contentJson;
        $[21] = t22;
    } else {
        t22 = $[21];
    }
    const t23 = maxHeight || undefined;
    const t24 = maxHeight ? "auto" : undefined;
    let t25;
    if ($[22] !== t23 || $[23] !== t24) {
        t25 = {
            maxHeight: t23,
            overflowY: t24
        };
        $[22] = t23;
        $[23] = t24;
        $[24] = t25;
    } else {
        t25 = $[24];
    }
    const t26 = typeof padding === "number" ? `${padding}px` : padding;
    let t27;
    if ($[25] !== t26) {
        t27 = {
            width: "100%",
            padding: t26,
            outline: "none"
        };
        $[25] = t26;
        $[26] = t27;
    } else {
        t27 = $[26];
    }
    let t28;
    if ($[27] !== ariaLabel || $[28] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalRichTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RichTextPlugin"], {
            contentEditable: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentEditable"], {
                "aria-label": ariaLabel,
                style: t27
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
                lineNumber: 262,
                columnNumber: 44
            }, this),
            placeholder: null,
            ErrorBoundary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalErrorBoundary"]
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 262,
            columnNumber: 11
        }, this);
        $[27] = ariaLabel;
        $[28] = t27;
        $[29] = t28;
    } else {
        t28 = $[29];
    }
    let t29;
    if ($[30] !== className || $[31] !== t25 || $[32] !== t28) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: className,
            sx: t25,
            children: t28
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 271,
            columnNumber: 11
        }, this);
        $[30] = className;
        $[31] = t25;
        $[32] = t28;
        $[33] = t29;
    } else {
        t29 = $[33];
    }
    let t30;
    if ($[34] !== t22 || $[35] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DndWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndWrapper"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$SharedAutocompleteContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AutocompleteProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$AudioPlayerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AudioPlayerProvider"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalComposer"], {
                        initialConfig: initialConfig,
                        children: [
                            t4,
                            t5,
                            t6,
                            t7,
                            t8,
                            t9,
                            t10,
                            t11,
                            t12,
                            t13,
                            t14,
                            t15,
                            t16,
                            t17,
                            t18,
                            t19,
                            t20,
                            t21,
                            t22,
                            t29
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
                        lineNumber: 281,
                        columnNumber: 66
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
                    lineNumber: 281,
                    columnNumber: 45
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
                lineNumber: 281,
                columnNumber: 23
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/NarrativeReader.tsx",
            lineNumber: 281,
            columnNumber: 11
        }, this);
        $[34] = t22;
        $[35] = t29;
        $[36] = t30;
    } else {
        t30 = $[36];
    }
    return t30;
}
_c1 = NarrativeReader;
const __TURBOPACK__default__export__ = NarrativeReader;
var _c, _c1;
__turbopack_context__.k.register(_c, "NarrativeStatePlugin");
__turbopack_context__.k.register(_c1, "NarrativeReader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/CampaignBriefing.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CampaignBriefing",
    ()=>CampaignBriefing,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoStories$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AutoStories.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$NarrativeReader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/NarrativeReader.tsx [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
function CampaignBriefing(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(33);
    if ($[0] !== "a4a2bff2bab2e5ff4947417668e28b9d7c07950c9f8382fe9f5e77fc79b93447") {
        for(let $i = 0; $i < 33; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a4a2bff2bab2e5ff4947417668e28b9d7c07950c9f8382fe9f5e77fc79b93447";
    }
    const { title, setting, stakes, chapterText, contentJson, contentMaxHeight, isLoading: t1, compact: t2 } = t0;
    const isLoading = t1 === undefined ? false : t1;
    const compact = t2 === undefined ? false : t2;
    if (isLoading) {
        let t3;
        if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = {
                mb: 2
            };
            $[1] = t3;
        } else {
            t3 = $[1];
        }
        let t4;
        if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "outlined",
                sx: t3,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "text",
                            width: "60%",
                            height: 32
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                            lineNumber: 86,
                            columnNumber: 58
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "text",
                            width: "100%"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                            lineNumber: 86,
                            columnNumber: 109
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "text",
                            width: "90%"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                            lineNumber: 86,
                            columnNumber: 149
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                    lineNumber: 86,
                    columnNumber: 45
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                lineNumber: 86,
                columnNumber: 12
            }, this);
            $[2] = t4;
        } else {
            t4 = $[2];
        }
        return t4;
    }
    if (compact) {
        let t3;
        if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = {
                px: 2,
                py: 1.5,
                bgcolor: "action.hover",
                borderRadius: 1,
                borderLeft: 4,
                borderColor: "primary.main",
                mb: 2
            };
            $[3] = t3;
        } else {
            t3 = $[3];
        }
        let t4;
        if ($[4] !== chapterText) {
            t4 = chapterText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "body2",
                sx: {
                    fontStyle: "italic",
                    color: "text.secondary"
                },
                children: chapterText
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                lineNumber: 111,
                columnNumber: 27
            }, this);
            $[4] = chapterText;
            $[5] = t4;
        } else {
            t4 = $[5];
        }
        let t5;
        if ($[6] !== chapterText || $[7] !== setting) {
            t5 = !chapterText && setting && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "body2",
                sx: {
                    fontStyle: "italic",
                    color: "text.secondary"
                },
                children: setting
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                lineNumber: 122,
                columnNumber: 39
            }, this);
            $[6] = chapterText;
            $[7] = setting;
            $[8] = t5;
        } else {
            t5 = $[8];
        }
        let t6;
        if ($[9] !== t4 || $[10] !== t5) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t3,
                children: [
                    t4,
                    t5
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                lineNumber: 134,
                columnNumber: 12
            }, this);
            $[9] = t4;
            $[10] = t5;
            $[11] = t6;
        } else {
            t6 = $[11];
        }
        return t6;
    }
    let t3;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            mb: 2,
            background: "linear-gradient(135deg, rgba(25,118,210,0.04) 0%, rgba(156,39,176,0.04) 100%)",
            border: "1px solid",
            borderColor: "divider"
        };
        $[12] = t3;
    } else {
        t3 = $[12];
    }
    let t4;
    let t5;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            display: "flex",
            alignItems: "center",
            gap: 1,
            mb: 1.5
        };
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoStories$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            color: "primary"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
            lineNumber: 164,
            columnNumber: 10
        }, this);
        $[13] = t4;
        $[14] = t5;
    } else {
        t4 = $[13];
        t5 = $[14];
    }
    let t6;
    if ($[15] !== title) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t4,
            children: [
                t5,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "h6",
                    fontWeight: 700,
                    children: title
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                    lineNumber: 173,
                    columnNumber: 27
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
            lineNumber: 173,
            columnNumber: 10
        }, this);
        $[15] = title;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    let t7;
    if ($[17] !== setting) {
        t7 = setting && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                mb: 1.5
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "overline",
                    color: "text.secondary",
                    sx: {
                        letterSpacing: 1.5,
                        fontSize: "0.65rem"
                    },
                    children: "Setting"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                    lineNumber: 183,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "body1",
                    sx: {
                        fontStyle: "italic",
                        lineHeight: 1.6
                    },
                    children: setting
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                    lineNumber: 186,
                    columnNumber: 30
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
            lineNumber: 181,
            columnNumber: 21
        }, this);
        $[17] = setting;
        $[18] = t7;
    } else {
        t7 = $[18];
    }
    let t8;
    if ($[19] !== stakes) {
        t8 = stakes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                mb: 1.5
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "overline",
                    color: "text.secondary",
                    sx: {
                        letterSpacing: 1.5,
                        fontSize: "0.65rem"
                    },
                    children: "Stakes"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                    lineNumber: 199,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "body1",
                    sx: {
                        lineHeight: 1.6,
                        fontWeight: 500
                    },
                    children: stakes
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                    lineNumber: 202,
                    columnNumber: 29
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
            lineNumber: 197,
            columnNumber: 20
        }, this);
        $[19] = stakes;
        $[20] = t8;
    } else {
        t8 = $[20];
    }
    let t9;
    if ($[21] !== chapterText) {
        t9 = chapterText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        my: 1.5
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                    lineNumber: 213,
                    columnNumber: 27
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "overline",
                            color: "text.secondary",
                            sx: {
                                letterSpacing: 1.5,
                                fontSize: "0.65rem"
                            },
                            children: "Mission Briefing"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                            lineNumber: 215,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "body1",
                            sx: {
                                fontStyle: "italic",
                                lineHeight: 1.6,
                                color: "primary.dark"
                            },
                            children: [
                                "“",
                                chapterText,
                                "”"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                            lineNumber: 218,
                            columnNumber: 41
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                    lineNumber: 215,
                    columnNumber: 12
                }, this)
            ]
        }, void 0, true);
        $[21] = chapterText;
        $[22] = t9;
    } else {
        t9 = $[22];
    }
    let t10;
    if ($[23] !== contentJson || $[24] !== contentMaxHeight || $[25] !== title) {
        t10 = contentJson && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        my: 1.5
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                    lineNumber: 230,
                    columnNumber: 28
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$NarrativeReader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NarrativeReader"], {
                    contentJson: contentJson,
                    maxHeight: contentMaxHeight,
                    ariaLabel: `${title} narrative content`,
                    padding: "0.5rem 0"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                    lineNumber: 232,
                    columnNumber: 12
                }, this)
            ]
        }, void 0, true);
        $[23] = contentJson;
        $[24] = contentMaxHeight;
        $[25] = title;
        $[26] = t10;
    } else {
        t10 = $[26];
    }
    let t11;
    if ($[27] !== t10 || $[28] !== t6 || $[29] !== t7 || $[30] !== t8 || $[31] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "outlined",
            sx: t3,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    t6,
                    t7,
                    t8,
                    t9,
                    t10
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
                lineNumber: 242,
                columnNumber: 44
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/CampaignBriefing.tsx",
            lineNumber: 242,
            columnNumber: 11
        }, this);
        $[27] = t10;
        $[28] = t6;
        $[29] = t7;
        $[30] = t8;
        $[31] = t9;
        $[32] = t11;
    } else {
        t11 = $[32];
    }
    return t11;
}
_c = CampaignBriefing;
const __TURBOPACK__default__export__ = CampaignBriefing;
var _c;
__turbopack_context__.k.register(_c, "CampaignBriefing");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/BossBattleCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BossBattleCard",
    ()=>BossBattleCard,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stepper$2f$Stepper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stepper/Stepper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Step$2f$Step$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Step/Step.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$StepLabel$2f$StepLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/StepLabel/StepLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Timer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Timer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Shield$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Shield.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SportsKabaddi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/SportsKabaddi.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// ============================================================================
// Helpers
// ============================================================================
function formatTimeRemaining(deadline) {
    const diff = new Date(deadline).getTime() - Date.now();
    if (diff <= 0) return 'Expired';
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ${hours % 24}h left`;
    return `${hours}h left`;
}
function getActivePhaseIndex(phases) {
    const idx = phases.findIndex((p)=>p.status === 'ACTIVE');
    return idx >= 0 ? idx : phases.length;
}
function BossBattleCard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(102);
    if ($[0] !== "39d593d810914f20f00acb840fb59f3d69a2a3ddc7bfe94c4f9a8b9cf11bd8f8") {
        for(let $i = 0; $i < 102; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "39d593d810914f20f00acb840fb59f3d69a2a3ddc7bfe94c4f9a8b9cf11bd8f8";
    }
    const { title, narrative, phases, totalHP, totalDamage, deadline, active, bonusMultiplier: t1, contributors: t2, maxContributorsShown: t3, currentUserRole } = t0;
    const bonusMultiplier = t1 === undefined ? 2 : t1;
    let T0;
    let T1;
    let T2;
    let t10;
    let t11;
    let t12;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[1] !== active || $[2] !== bonusMultiplier || $[3] !== currentUserRole || $[4] !== narrative || $[5] !== phases || $[6] !== t2 || $[7] !== t3 || $[8] !== title || $[9] !== totalDamage || $[10] !== totalHP) {
        const contributors = t2 === undefined ? [] : t2;
        const maxContributorsShown = t3 === undefined ? 5 : t3;
        let t13;
        if ($[23] !== totalDamage || $[24] !== totalHP) {
            t13 = totalHP > 0 ? Math.min(100, Math.round(totalDamage / totalHP * 100)) : 0;
            $[23] = totalDamage;
            $[24] = totalHP;
            $[25] = t13;
        } else {
            t13 = $[25];
        }
        const overallProgress = t13;
        const defeated = totalDamage >= totalHP;
        let t14;
        if ($[26] !== phases) {
            t14 = getActivePhaseIndex(phases);
            $[26] = phases;
            $[27] = t14;
        } else {
            t14 = $[27];
        }
        const activePhaseIdx = t14;
        T2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        t11 = "outlined";
        const t15 = active ? 1 : 0.7;
        const t16 = defeated ? "2px solid" : "1px solid";
        const t17 = defeated ? "success.main" : "divider";
        const t18 = active ? "linear-gradient(135deg, rgba(211,47,47,0.04) 0%, rgba(156,39,176,0.04) 100%)" : undefined;
        if ($[28] !== t15 || $[29] !== t16 || $[30] !== t17 || $[31] !== t18) {
            t12 = {
                opacity: t15,
                border: t16,
                borderColor: t17,
                background: t18
            };
            $[28] = t15;
            $[29] = t16;
            $[30] = t17;
            $[31] = t18;
            $[32] = t12;
        } else {
            t12 = $[32];
        }
        T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        let t19;
        if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
            t19 = {
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                mb: 1
            };
            $[33] = t19;
        } else {
            t19 = $[33];
        }
        let t20;
        if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
            t20 = {
                display: "flex",
                alignItems: "center",
                gap: 1
            };
            $[34] = t20;
        } else {
            t20 = $[34];
        }
        const t21 = defeated ? "success" : "error";
        let t22;
        if ($[35] !== t21) {
            t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SportsKabaddi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                color: t21
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 205,
                columnNumber: 13
            }, this);
            $[35] = t21;
            $[36] = t22;
        } else {
            t22 = $[36];
        }
        let t23;
        if ($[37] !== title) {
            t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "h6",
                fontWeight: 700,
                children: title
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 213,
                columnNumber: 13
            }, this);
            $[37] = title;
            $[38] = t23;
        } else {
            t23 = $[38];
        }
        let t24;
        if ($[39] !== t22 || $[40] !== t23) {
            t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t20,
                children: [
                    t22,
                    t23
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 221,
                columnNumber: 13
            }, this);
            $[39] = t22;
            $[40] = t23;
            $[41] = t24;
        } else {
            t24 = $[41];
        }
        let t25;
        if ($[42] !== bonusMultiplier) {
            t25 = bonusMultiplier > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                label: `${bonusMultiplier}× bonus`,
                size: "small",
                color: "warning",
                sx: {
                    height: 22,
                    fontSize: "0.75rem"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 230,
                columnNumber: 36
            }, this);
            $[42] = bonusMultiplier;
            $[43] = t25;
        } else {
            t25 = $[43];
        }
        let t26;
        if ($[44] !== currentUserRole) {
            t26 = currentUserRole && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Shield$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        fontSize: 14
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                    lineNumber: 241,
                    columnNumber: 44
                }, this),
                label: currentUserRole,
                size: "small",
                variant: "outlined",
                sx: {
                    height: 22,
                    fontSize: "0.75rem"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 241,
                columnNumber: 32
            }, this);
            $[44] = currentUserRole;
            $[45] = t26;
        } else {
            t26 = $[45];
        }
        let t27;
        if ($[46] !== t25 || $[47] !== t26) {
            t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                direction: "row",
                spacing: 0.5,
                children: [
                    t25,
                    t26
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 254,
                columnNumber: 13
            }, this);
            $[46] = t25;
            $[47] = t26;
            $[48] = t27;
        } else {
            t27 = $[48];
        }
        if ($[49] !== t24 || $[50] !== t27) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t19,
                children: [
                    t24,
                    t27
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 262,
                columnNumber: 12
            }, this);
            $[49] = t24;
            $[50] = t27;
            $[51] = t6;
        } else {
            t6 = $[51];
        }
        if ($[52] !== narrative) {
            t7 = narrative && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "body2",
                sx: {
                    fontStyle: "italic",
                    color: "text.secondary",
                    mb: 1.5,
                    lineHeight: 1.5
                },
                children: [
                    "“",
                    narrative,
                    "”"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 270,
                columnNumber: 25
            }, this);
            $[52] = narrative;
            $[53] = t7;
        } else {
            t7 = $[53];
        }
        let t28;
        if ($[54] === Symbol.for("react.memo_cache_sentinel")) {
            t28 = {
                mb: 2
            };
            $[54] = t28;
        } else {
            t28 = $[54];
        }
        let t29;
        if ($[55] === Symbol.for("react.memo_cache_sentinel")) {
            t29 = {
                display: "flex",
                justifyContent: "space-between",
                mb: 0.5
            };
            $[55] = t29;
        } else {
            t29 = $[55];
        }
        let t30;
        if ($[56] !== defeated || $[57] !== totalDamage || $[58] !== totalHP) {
            t30 = defeated ? "\uD83D\uDC80 Defeated!" : `Boss HP: ${totalDamage.toLocaleString()} / ${totalHP.toLocaleString()}`;
            $[56] = defeated;
            $[57] = totalDamage;
            $[58] = totalHP;
            $[59] = t30;
        } else {
            t30 = $[59];
        }
        let t31;
        if ($[60] !== t30) {
            t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "body2",
                color: "text.secondary",
                children: t30
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 313,
                columnNumber: 13
            }, this);
            $[60] = t30;
            $[61] = t31;
        } else {
            t31 = $[61];
        }
        let t32;
        if ($[62] !== overallProgress) {
            t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "body2",
                fontWeight: 600,
                children: [
                    overallProgress,
                    "%"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 321,
                columnNumber: 13
            }, this);
            $[62] = overallProgress;
            $[63] = t32;
        } else {
            t32 = $[63];
        }
        let t33;
        if ($[64] !== t31 || $[65] !== t32) {
            t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t29,
                children: [
                    t31,
                    t32
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 329,
                columnNumber: 13
            }, this);
            $[64] = t31;
            $[65] = t32;
            $[66] = t33;
        } else {
            t33 = $[66];
        }
        const t34 = defeated ? "success" : "error";
        let t35;
        if ($[67] === Symbol.for("react.memo_cache_sentinel")) {
            t35 = {
                height: 12,
                borderRadius: 6
            };
            $[67] = t35;
        } else {
            t35 = $[67];
        }
        let t36;
        if ($[68] !== overallProgress || $[69] !== t34) {
            t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "determinate",
                value: overallProgress,
                color: t34,
                sx: t35
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 349,
                columnNumber: 13
            }, this);
            $[68] = overallProgress;
            $[69] = t34;
            $[70] = t36;
        } else {
            t36 = $[70];
        }
        if ($[71] !== t33 || $[72] !== t36) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t28,
                children: [
                    t33,
                    t36
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 357,
                columnNumber: 12
            }, this);
            $[71] = t33;
            $[72] = t36;
            $[73] = t8;
        } else {
            t8 = $[73];
        }
        if ($[74] !== activePhaseIdx || $[75] !== phases) {
            t9 = phases.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    mb: 2
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stepper$2f$Stepper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    activeStep: activePhaseIdx,
                    alternativeLabel: true,
                    children: phases.map(_BossBattleCardPhasesMap)
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                    lineNumber: 367,
                    columnNumber: 10
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 365,
                columnNumber: 33
            }, this);
            $[74] = activePhaseIdx;
            $[75] = phases;
            $[76] = t9;
        } else {
            t9 = $[76];
        }
        if ($[77] !== activePhaseIdx || $[78] !== currentUserRole || $[79] !== phases) {
            t10 = phases[activePhaseIdx] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    bgcolor: "action.hover",
                    borderRadius: 1,
                    p: 1.5,
                    mb: 1.5
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "subtitle2",
                        gutterBottom: true,
                        children: [
                            "Current Phase: ",
                            phases[activePhaseIdx].title
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                        lineNumber: 380,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "body2",
                        color: "text.secondary",
                        sx: {
                            mb: 1
                        },
                        children: phases[activePhaseIdx].description
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                        lineNumber: 380,
                        columnNumber: 120
                    }, this),
                    phases[activePhaseIdx].requiredRoles && phases[activePhaseIdx].requiredRoles.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        direction: "row",
                        spacing: 0.5,
                        children: phases[activePhaseIdx].requiredRoles.map({
                            "BossBattleCard[(anonymous)()]": (role)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    label: role,
                                    size: "small",
                                    variant: "outlined",
                                    color: role === currentUserRole ? "primary" : "default",
                                    sx: {
                                        height: 20,
                                        fontSize: "0.7rem"
                                    }
                                }, role, false, {
                                    fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                                    lineNumber: 383,
                                    columnNumber: 54
                                }, this)
                        }["BossBattleCard[(anonymous)()]"])
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                        lineNumber: 382,
                        columnNumber: 153
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 375,
                columnNumber: 39
            }, this);
            $[77] = activePhaseIdx;
            $[78] = currentUserRole;
            $[79] = phases;
            $[80] = t10;
        } else {
            t10 = $[80];
        }
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        if ($[81] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = {
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between"
            };
            $[81] = t4;
        } else {
            t4 = $[81];
        }
        t5 = contributors.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            spacing: -1,
            children: [
                contributors.slice(0, maxContributorsShown).map(_BossBattleCardAnonymous),
                contributors.length > maxContributorsShown && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        width: 28,
                        height: 28,
                        fontSize: "0.65rem",
                        bgcolor: "grey.400"
                    },
                    children: [
                        "+",
                        contributors.length - maxContributorsShown
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                    lineNumber: 406,
                    columnNumber: 195
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
            lineNumber: 406,
            columnNumber: 37
        }, this);
        $[1] = active;
        $[2] = bonusMultiplier;
        $[3] = currentUserRole;
        $[4] = narrative;
        $[5] = phases;
        $[6] = t2;
        $[7] = t3;
        $[8] = title;
        $[9] = totalDamage;
        $[10] = totalHP;
        $[11] = T0;
        $[12] = T1;
        $[13] = T2;
        $[14] = t10;
        $[15] = t11;
        $[16] = t12;
        $[17] = t4;
        $[18] = t5;
        $[19] = t6;
        $[20] = t7;
        $[21] = t8;
        $[22] = t9;
    } else {
        T0 = $[11];
        T1 = $[12];
        T2 = $[13];
        t10 = $[14];
        t11 = $[15];
        t12 = $[16];
        t4 = $[17];
        t5 = $[18];
        t6 = $[19];
        t7 = $[20];
        t8 = $[21];
        t9 = $[22];
    }
    let t13;
    if ($[82] !== deadline) {
        t13 = deadline && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                display: "flex",
                alignItems: "center",
                gap: 0.5
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Timer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        fontSize: 16,
                        color: "text.secondary"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                    lineNumber: 454,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "caption",
                    color: "text.secondary",
                    children: formatTimeRemaining(deadline)
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                    lineNumber: 457,
                    columnNumber: 12
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
            lineNumber: 450,
            columnNumber: 23
        }, this);
        $[82] = deadline;
        $[83] = t13;
    } else {
        t13 = $[83];
    }
    let t14;
    if ($[84] !== T0 || $[85] !== t13 || $[86] !== t4 || $[87] !== t5) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            sx: t4,
            children: [
                t5,
                t13
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
            lineNumber: 465,
            columnNumber: 11
        }, this);
        $[84] = T0;
        $[85] = t13;
        $[86] = t4;
        $[87] = t5;
        $[88] = t14;
    } else {
        t14 = $[88];
    }
    let t15;
    if ($[89] !== T1 || $[90] !== t10 || $[91] !== t14 || $[92] !== t6 || $[93] !== t7 || $[94] !== t8 || $[95] !== t9) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
            children: [
                t6,
                t7,
                t8,
                t9,
                t10,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
            lineNumber: 476,
            columnNumber: 11
        }, this);
        $[89] = T1;
        $[90] = t10;
        $[91] = t14;
        $[92] = t6;
        $[93] = t7;
        $[94] = t8;
        $[95] = t9;
        $[96] = t15;
    } else {
        t15 = $[96];
    }
    let t16;
    if ($[97] !== T2 || $[98] !== t11 || $[99] !== t12 || $[100] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T2, {
            variant: t11,
            sx: t12,
            children: t15
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
            lineNumber: 490,
            columnNumber: 11
        }, this);
        $[97] = T2;
        $[98] = t11;
        $[99] = t12;
        $[100] = t15;
        $[101] = t16;
    } else {
        t16 = $[101];
    }
    return t16;
}
_c = BossBattleCard;
function _BossBattleCardAnonymous(c) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        title: `${c.displayName}: ${c.xpContributed} XP`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: c.avatarUrl,
            sx: {
                width: 28,
                height: 28,
                fontSize: "0.75rem",
                border: "2px solid white"
            },
            children: c.displayName.charAt(0)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
            lineNumber: 502,
            columnNumber: 84
        }, this)
    }, c.userId, false, {
        fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
        lineNumber: 502,
        columnNumber: 10
    }, this);
}
function _BossBattleCardPhasesMap(phase) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Step$2f$Step$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        completed: phase.status === "COMPLETED",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$StepLabel$2f$StepLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            optional: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "text.secondary",
                children: [
                    phase.currentXP,
                    "/",
                    phase.targetXP,
                    " XP"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
                lineNumber: 510,
                columnNumber: 93
            }, this),
            children: phase.title
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
            lineNumber: 510,
            columnNumber: 72
        }, this)
    }, phase.id, false, {
        fileName: "[project]/src/components/Gamification/BossBattleCard.tsx",
        lineNumber: 510,
        columnNumber: 10
    }, this);
}
const __TURBOPACK__default__export__ = BossBattleCard;
var _c;
__turbopack_context__.k.register(_c, "BossBattleCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/CampaignTimeline.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CampaignTimeline",
    ()=>CampaignTimeline,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Lock.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PlayArrow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PlayArrow.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
function CampaignTimeline(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "68d2026940b5b31330c120001377f852068e717973d632a6b7ac398d9ec921cc") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "68d2026940b5b31330c120001377f852068e717973d632a6b7ac398d9ec921cc";
    }
    const { chapters } = t0;
    if (!chapters || chapters.length === 0) {
        return null;
    }
    let T0;
    let T1;
    let t1;
    let t2;
    let t3;
    let t4;
    if ($[1] !== chapters) {
        const sorted = [
            ...chapters
        ].sort(_CampaignTimelineAnonymous);
        T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = {
                py: 2
            };
            $[8] = t3;
        } else {
            t3 = $[8];
        }
        if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "h6",
                gutterBottom: true,
                sx: {
                    fontWeight: 600
                },
                children: "Campaign Progress"
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                lineNumber: 61,
                columnNumber: 12
            }, this);
            $[9] = t4;
        } else {
            t4 = $[9];
        }
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        t1 = 1.5;
        t2 = sorted.map(_CampaignTimelineSortedMap);
        $[1] = chapters;
        $[2] = T0;
        $[3] = T1;
        $[4] = t1;
        $[5] = t2;
        $[6] = t3;
        $[7] = t4;
    } else {
        T0 = $[2];
        T1 = $[3];
        t1 = $[4];
        t2 = $[5];
        t3 = $[6];
        t4 = $[7];
    }
    let t5;
    if ($[10] !== T0 || $[11] !== t1 || $[12] !== t2) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            spacing: t1,
            children: t2
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
            lineNumber: 88,
            columnNumber: 10
        }, this);
        $[10] = T0;
        $[11] = t1;
        $[12] = t2;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    let t6;
    if ($[14] !== T1 || $[15] !== t3 || $[16] !== t4 || $[17] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
            sx: t3,
            children: [
                t4,
                t5
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
            lineNumber: 98,
            columnNumber: 10
        }, this);
        $[14] = T1;
        $[15] = t3;
        $[16] = t4;
        $[17] = t5;
        $[18] = t6;
    } else {
        t6 = $[18];
    }
    return t6;
}
_c = CampaignTimeline;
function _CampaignTimelineSortedMap(chapter, index) {
    const progress = chapter.targetXP > 0 ? Math.min(100, Math.round(chapter.currentXP / chapter.targetXP * 100)) : 0;
    const isCompleted = chapter.currentXP >= chapter.targetXP;
    const isActive = chapter.active && !isCompleted;
    const isLocked = !chapter.active && !isCompleted;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            display: "flex",
            alignItems: "center",
            gap: 1.5,
            opacity: isLocked ? 0.5 : 1
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    width: 32,
                    height: 32,
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    bgcolor: isCompleted ? "success.main" : isActive ? "primary.main" : "grey.300",
                    color: "white",
                    fontSize: "0.75rem",
                    fontWeight: 700,
                    flexShrink: 0
                },
                children: isCompleted ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                    lineNumber: 131,
                    columnNumber: 23
                }, this) : isLocked ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                    lineNumber: 131,
                    columnNumber: 73
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PlayArrow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                    lineNumber: 131,
                    columnNumber: 105
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                lineNumber: 119,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    flex: 1,
                    minWidth: 0
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            display: "flex",
                            alignItems: "center",
                            gap: 1
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "body2",
                                fontWeight: 600,
                                noWrap: true,
                                children: [
                                    "Chapter ",
                                    index + 1,
                                    ": ",
                                    chapter.title
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                                lineNumber: 138,
                                columnNumber: 10
                            }, this),
                            isCompleted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                label: "Complete",
                                size: "small",
                                color: "success",
                                sx: {
                                    height: 18,
                                    fontSize: "0.6rem"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                                lineNumber: 138,
                                columnNumber: 134
                            }, this),
                            isActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                label: `${progress}%`,
                                size: "small",
                                color: "primary",
                                sx: {
                                    height: 18,
                                    fontSize: "0.6rem"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                                lineNumber: 141,
                                columnNumber: 28
                            }, this),
                            isLocked && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                label: "Locked",
                                size: "small",
                                sx: {
                                    height: 18,
                                    fontSize: "0.6rem"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                                lineNumber: 144,
                                columnNumber: 28
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                        lineNumber: 134,
                        columnNumber: 8
                    }, this),
                    isActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "determinate",
                        value: progress,
                        sx: {
                            mt: 0.5,
                            height: 6,
                            borderRadius: 3
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                        lineNumber: 147,
                        columnNumber: 34
                    }, this),
                    chapter.setting && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "caption",
                        color: "text.secondary",
                        noWrap: true,
                        children: chapter.setting
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                        lineNumber: 151,
                        columnNumber: 33
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
                lineNumber: 131,
                columnNumber: 146
            }, this)
        ]
    }, chapter.id, true, {
        fileName: "[project]/src/components/Gamification/CampaignTimeline.tsx",
        lineNumber: 114,
        columnNumber: 10
    }, this);
}
function _CampaignTimelineAnonymous(a, b) {
    if (a.chapterOrder != null && b.chapterOrder != null) {
        return a.chapterOrder - b.chapterOrder;
    }
    return 0;
}
const __TURBOPACK__default__export__ = CampaignTimeline;
var _c;
__turbopack_context__.k.register(_c, "CampaignTimeline");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/RankChangeToast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RankChangeToast",
    ()=>RankChangeToast,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TrendingUp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TrendingDown.js [app-client] (ecmascript)");
;
;
;
;
;
;
function RankChangeToast(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18);
    if ($[0] !== "f54591abbf7d01b3eed979d94218737398e7dbf9ec637eac6519b29230b6c0f2") {
        for(let $i = 0; $i < 18; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f54591abbf7d01b3eed979d94218737398e7dbf9ec637eac6519b29230b6c0f2";
    }
    const { open, positionsChanged, newRank, onClose, autoHideDuration: t1 } = t0;
    const autoHideDuration = t1 === undefined ? 3000 : t1;
    const movedUp = positionsChanged > 0;
    let t2;
    if ($[1] !== movedUp) {
        t2 = movedUp ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 40,
            columnNumber: 20
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 40,
            columnNumber: 41
        }, this);
        $[1] = movedUp;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const icon = t2;
    const severity = movedUp ? "success" : "info";
    let t3;
    if ($[3] !== movedUp || $[4] !== newRank || $[5] !== positionsChanged) {
        t3 = movedUp ? `+${positionsChanged} positions on leaderboard! Now #${newRank} 🚀` : `Dropped ${Math.abs(positionsChanged)} position${Math.abs(positionsChanged) > 1 ? "s" : ""} — now #${newRank}`;
        $[3] = movedUp;
        $[4] = newRank;
        $[5] = positionsChanged;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const message = t3;
    let t4;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            vertical: "bottom",
            horizontal: "left"
        };
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            fontWeight: 600
        };
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] !== icon || $[10] !== message || $[11] !== severity) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            severity: severity,
            icon: icon,
            sx: t5,
            children: message
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        $[9] = icon;
        $[10] = message;
        $[11] = severity;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    let t7;
    if ($[13] !== autoHideDuration || $[14] !== onClose || $[15] !== open || $[16] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            autoHideDuration: autoHideDuration,
            anchorOrigin: t4,
            onClose: onClose,
            children: t6
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[13] = autoHideDuration;
        $[14] = onClose;
        $[15] = open;
        $[16] = t6;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    return t7;
}
_c = RankChangeToast;
const __TURBOPACK__default__export__ = RankChangeToast;
var _c;
__turbopack_context__.k.register(_c, "RankChangeToast");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/BadgeCoinFlip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BadgeCoinFlip",
    ()=>BadgeCoinFlip,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * BadgeCoinFlip — CSS 3D coin-flip animation for badge awards.
 *
 * Shows a spinning coin that resolves to the badge emoji.
 *
 * @module BadgeCoinFlip
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BadgeIcon.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function BadgeCoinFlip(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(36);
    if ($[0] !== "0133f0923054bcc9dfb946f1a5dc16979320d1316602d61f9b2d5e504857e7f7") {
        for(let $i = 0; $i < 36; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0133f0923054bcc9dfb946f1a5dc16979320d1316602d61f9b2d5e504857e7f7";
    }
    const { open, badgeEmoji, badgeType, badgeName, badgeDescription, onClose } = t0;
    const [flipped, setFlipped] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    let t2;
    if ($[1] !== open) {
        t1 = ({
            "BadgeCoinFlip[useEffect()]": ()=>{
                if (open) {
                    setFlipped(false);
                    const timer = setTimeout({
                        "BadgeCoinFlip[useEffect() > setTimeout()]": ()=>setFlipped(true)
                    }["BadgeCoinFlip[useEffect() > setTimeout()]"], 100);
                    return ()=>clearTimeout(timer);
                }
            }
        })["BadgeCoinFlip[useEffect()]"];
        t2 = [
            open
        ];
        $[1] = open;
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            textAlign: "center",
            p: 4
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            perspective: "600px",
            mb: 2
        };
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const t5 = flipped ? "rotateY(720deg)" : "rotateY(0deg)";
    let t6;
    if ($[6] !== t5) {
        t6 = {
            width: 80,
            height: 80,
            mx: "auto",
            position: "relative",
            transformStyle: "preserve-3d",
            transition: "transform 0.8s ease-out",
            transform: t5
        };
        $[6] = t5;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            position: "absolute",
            width: "100%",
            height: "100%",
            borderRadius: "50%",
            bgcolor: "warning.light",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backfaceVisibility: "hidden",
            fontSize: "2.5rem"
        };
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] !== badgeEmoji || $[10] !== badgeType || $[11] !== flipped) {
        t8 = badgeType ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeIcon"], {
            badgeType: badgeType,
            size: 64,
            earned: true,
            animate: flipped,
            drawIcon: flipped
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 124,
            columnNumber: 22
        }, this) : badgeEmoji;
        $[9] = badgeEmoji;
        $[10] = badgeType;
        $[11] = flipped;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t7,
            children: t8
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 134,
            columnNumber: 10
        }, this);
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== t6 || $[16] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t4,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t6,
                children: t9
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
                lineNumber: 142,
                columnNumber: 24
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 142,
            columnNumber: 11
        }, this);
        $[15] = t6;
        $[16] = t9;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h6",
            fontWeight: 700,
            sx: {
                mt: 2
            },
            children: "Badge Earned!"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 151,
            columnNumber: 11
        }, this);
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] !== badgeName) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle1",
            fontWeight: 600,
            color: "primary.main",
            children: badgeName
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 160,
            columnNumber: 11
        }, this);
        $[19] = badgeName;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            mt: 1
        };
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    let t14;
    if ($[22] !== badgeDescription) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: t13,
            children: badgeDescription
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 177,
            columnNumber: 11
        }, this);
        $[22] = badgeDescription;
        $[23] = t14;
    } else {
        t14 = $[23];
    }
    let t15;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            mt: 3
        };
        $[24] = t15;
    } else {
        t15 = $[24];
    }
    let t16;
    if ($[25] !== onClose) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "contained",
            onClick: onClose,
            sx: t15,
            children: "Awesome!"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 194,
            columnNumber: 11
        }, this);
        $[25] = onClose;
        $[26] = t16;
    } else {
        t16 = $[26];
    }
    let t17;
    if ($[27] !== t10 || $[28] !== t12 || $[29] !== t14 || $[30] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t10,
                t11,
                t12,
                t14,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 202,
            columnNumber: 11
        }, this);
        $[27] = t10;
        $[28] = t12;
        $[29] = t14;
        $[30] = t16;
        $[31] = t17;
    } else {
        t17 = $[31];
    }
    let t18;
    if ($[32] !== onClose || $[33] !== open || $[34] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            maxWidth: "xs",
            fullWidth: true,
            onClose: onClose,
            children: t17
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 213,
            columnNumber: 11
        }, this);
        $[32] = onClose;
        $[33] = open;
        $[34] = t17;
        $[35] = t18;
    } else {
        t18 = $[35];
    }
    return t18;
}
_s(BadgeCoinFlip, "AET8kBs2SyxC4Y+I5l5KZF+HKtk=");
_c = BadgeCoinFlip;
const __TURBOPACK__default__export__ = BadgeCoinFlip;
var _c;
__turbopack_context__.k.register(_c, "BadgeCoinFlip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/ContentUnlockAnimation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContentUnlockAnimation",
    ()=>ContentUnlockAnimation,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * ContentUnlockAnimation — Shows a padlock-open + shimmer animation
 * when content transitions from locked to unlocked.
 *
 * @module ContentUnlockAnimation
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LockOpen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/LockOpen.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ContentUnlockAnimation(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "879883009fc7268f972d4a73bc498985b943f8397e3421ec723284abb5cfa2c6") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "879883009fc7268f972d4a73bc498985b943f8397e3421ec723284abb5cfa2c6";
    }
    const { show, title, onComplete } = t0;
    const [phase, setPhase] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    let t1;
    let t2;
    if ($[1] !== onComplete || $[2] !== show) {
        t1 = ({
            "ContentUnlockAnimation[useEffect()]": ()=>{
                if (!show) {
                    setPhase("idle");
                    return;
                }
                setPhase("shake");
                const t1$0 = setTimeout({
                    "ContentUnlockAnimation[useEffect() > setTimeout()]": ()=>setPhase("open")
                }["ContentUnlockAnimation[useEffect() > setTimeout()]"], 600);
                const t2$0 = setTimeout({
                    "ContentUnlockAnimation[useEffect() > setTimeout()]": ()=>setPhase("shimmer")
                }["ContentUnlockAnimation[useEffect() > setTimeout()]"], 1200);
                const t3 = setTimeout({
                    "ContentUnlockAnimation[useEffect() > setTimeout()]": ()=>{
                        setPhase("done");
                        onComplete?.();
                    }
                }["ContentUnlockAnimation[useEffect() > setTimeout()]"], 2400);
                return ()=>{
                    clearTimeout(t1$0);
                    clearTimeout(t2$0);
                    clearTimeout(t3);
                };
            }
        })["ContentUnlockAnimation[useEffect()]"];
        t2 = [
            show,
            onComplete
        ];
        $[1] = onComplete;
        $[2] = show;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    if (phase === "idle" || phase === "done") {
        return null;
    }
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 2000,
            bgcolor: "rgba(0,0,0,0.5)",
            backdropFilter: "blur(4px)",
            pointerEvents: "none"
        };
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const t4 = phase === "shake" ? "unlockShake 0.5s ease-in-out" : phase === "open" ? "unlockOpen 0.5s ease-out forwards" : phase === "shimmer" ? "unlockShimmer 1s ease-out forwards" : "none";
    let t5;
    let t6;
    let t7;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            "0%, 100%": {
                transform: "rotate(0deg)"
            },
            "20%": {
                transform: "rotate(-10deg)"
            },
            "40%": {
                transform: "rotate(10deg)"
            },
            "60%": {
                transform: "rotate(-10deg)"
            },
            "80%": {
                transform: "rotate(10deg)"
            }
        };
        t6 = {
            "0%": {
                transform: "scale(1)",
                opacity: 1
            },
            "50%": {
                transform: "scale(1.3)",
                opacity: 1
            },
            "100%": {
                transform: "scale(1.5)",
                opacity: 0.8
            }
        };
        t7 = {
            "0%": {
                transform: "scale(1.5)",
                opacity: 0.8,
                filter: "brightness(1)"
            },
            "50%": {
                transform: "scale(2)",
                opacity: 1,
                filter: "brightness(2)"
            },
            "100%": {
                transform: "scale(1)",
                opacity: 0,
                filter: "brightness(1)"
            }
        };
        $[6] = t5;
        $[7] = t6;
        $[8] = t7;
    } else {
        t5 = $[6];
        t6 = $[7];
        t7 = $[8];
    }
    let t8;
    if ($[9] !== t4) {
        t8 = {
            fontSize: "4rem",
            animation: t4,
            "@keyframes unlockShake": t5,
            "@keyframes unlockOpen": t6,
            "@keyframes unlockShimmer": t7
        };
        $[9] = t4;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LockOpen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: "inherit",
                color: "warning.main"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 176,
            columnNumber: 10
        }, this);
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    let t10;
    if ($[12] !== t8) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t8,
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        $[12] = t8;
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] !== phase || $[15] !== title) {
        t11 = (phase === "open" || phase === "shimmer") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h4",
            sx: {
                color: "white",
                fontWeight: 700,
                mt: 2,
                textAlign: "center",
                animation: "fadeInUp 0.6s ease-out",
                "@keyframes fadeInUp": {
                    "0%": {
                        opacity: 0,
                        transform: "translateY(20px)"
                    },
                    "100%": {
                        opacity: 1,
                        transform: "translateY(0)"
                    }
                }
            },
            children: [
                "🔓 ",
                title,
                " Unlocked!"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 194,
            columnNumber: 56
        }, this);
        $[14] = phase;
        $[15] = title;
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    let t12;
    if ($[17] !== t10 || $[18] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t10,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 219,
            columnNumber: 11
        }, this);
        $[17] = t10;
        $[18] = t11;
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    return t12;
}
_s(ContentUnlockAnimation, "K+JLQG7QosnBzljigzAIGs/3QEU=");
_c = ContentUnlockAnimation;
const __TURBOPACK__default__export__ = ContentUnlockAnimation;
var _c;
__turbopack_context__.k.register(_c, "ContentUnlockAnimation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/GamificationToastLayer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GamificationToastLayer",
    ()=>GamificationToastLayer,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * GamificationToastLayer — Global overlay that renders event-driven
 * micro-interaction toasts: RankChangeToast, BadgeCoinFlip, EasterEggToast,
 * ContentUnlockAnimation, and AnimatedXPCounter.
 *
 * Mount once inside GamificationProviderWrapper in _app.jsx.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$RankChangeToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/RankChangeToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeCoinFlip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BadgeCoinFlip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/EasterEggToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ContentUnlockAnimation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/ContentUnlockAnimation.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
// Badge metadata (mirrors BadgeShelf definitions)
const BADGE_META = {
    FIRST_SUBMISSION: {
        emoji: '📝',
        name: 'First Steps',
        description: 'Submitted your first assignment'
    },
    GOOD_EYE: {
        emoji: '👁️',
        name: 'Good Eye',
        description: 'Found an error others missed'
    },
    QUICK_DRAW: {
        emoji: '⚡',
        name: 'Quick Draw',
        description: 'First to submit in your section'
    },
    SHARPSHOOTER: {
        emoji: '🎯',
        name: 'Sharpshooter',
        description: '3 perfect scores in a row'
    },
    CONSISTENT: {
        emoji: '🔥',
        name: 'Consistent',
        description: '14-day streak'
    },
    TEAM_PLAYER: {
        emoji: '🤝',
        name: 'Team Player',
        description: 'Completed 5 peer reviews'
    },
    DEEP_THINKER: {
        emoji: '🧠',
        name: 'Deep Thinker',
        description: 'Revised after AI feedback 3 times'
    },
    TOP_OF_CLASS: {
        emoji: '🏆',
        name: 'Top of Class',
        description: 'Reached #1 on leaderboard'
    },
    PERFECTIONIST: {
        emoji: '💎',
        name: 'Perfectionist',
        description: '100% on every workbook in a module'
    }
};
function GamificationToastLayer() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(37);
    if ($[0] !== "c2497af0e7c2f3b9613b747180c741686dc88d221a4b5885da94290ad264a18f") {
        for(let $i = 0; $i < 37; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c2497af0e7c2f3b9613b747180c741686dc88d221a4b5885da94290ad264a18f";
    }
    const { xpLogs } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"])();
    const { locks } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContentLock"])();
    const prevXpLogsCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(xpLogs.length);
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const prevLocksRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            open: false,
            positionsChanged: 0,
            newRank: 0
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [rankToast, setRankToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            open: false,
            emoji: "",
            name: "",
            description: ""
        };
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const [badgeFlip, setBadgeFlip] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            open: false,
            message: "",
            xpReward: 0
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const [easterEgg, setEasterEgg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3);
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            show: false,
            title: ""
        };
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const [unlock, setUnlock] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t4);
    let t5;
    let t6;
    if ($[6] !== xpLogs) {
        t5 = ({
            "GamificationToastLayer[useEffect()]": ()=>{
                const prevCount = prevXpLogsCountRef.current;
                if (xpLogs.length <= prevCount) {
                    prevXpLogsCountRef.current = xpLogs.length;
                    return;
                }
                const newEntries = xpLogs.slice(0, xpLogs.length - prevCount);
                prevXpLogsCountRef.current = xpLogs.length;
                for (const entry of newEntries){
                    const reason = entry.xpReason || "";
                    if (reason === "EASTER_EGG") {
                        setEasterEgg({
                            open: true,
                            message: entry.description || "You found a secret!",
                            xpReward: entry.xpAmount || 0
                        });
                    }
                    if (reason === "BADGE_AWARDED") {
                        const badgeType = entry.metadata?.badgeType || "";
                        const meta = BADGE_META[badgeType] || {
                            emoji: "\uD83C\uDFC5",
                            name: "Badge",
                            description: "Achievement unlocked!"
                        };
                        setBadgeFlip({
                            open: true,
                            ...meta
                        });
                    }
                    if (reason === "RANK_CHANGE" || entry.metadata?.rankChange) {
                        const meta_0 = entry.metadata || {};
                        if (meta_0.positionsChanged && meta_0.newRank) {
                            setRankToast({
                                open: true,
                                positionsChanged: meta_0.positionsChanged,
                                newRank: meta_0.newRank
                            });
                        }
                    }
                }
            }
        })["GamificationToastLayer[useEffect()]"];
        t6 = [
            xpLogs
        ];
        $[6] = xpLogs;
        $[7] = t5;
        $[8] = t6;
    } else {
        t5 = $[7];
        t6 = $[8];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7;
    let t8;
    if ($[9] !== locks) {
        t7 = ({
            "GamificationToastLayer[useEffect()]": ()=>{
                const currentLockedIds = locks.filter(_GamificationToastLayerUseEffectLocksFilter).map(_GamificationToastLayerUseEffectAnonymous);
                const prevLockedIds = prevLocksRef.current;
                if (prevLockedIds.length > 0) {
                    const newlyUnlocked = prevLockedIds.filter({
                        "GamificationToastLayer[useEffect() > prevLockedIds.filter()]": (id)=>!currentLockedIds.includes(id)
                    }["GamificationToastLayer[useEffect() > prevLockedIds.filter()]"]);
                    if (newlyUnlocked.length > 0) {
                        const unlockedLock = locks.find({
                            "GamificationToastLayer[useEffect() > locks.find()]": (l_1)=>l_1.contentId === newlyUnlocked[0]
                        }["GamificationToastLayer[useEffect() > locks.find()]"]);
                        setUnlock({
                            show: true,
                            title: unlockedLock?.title || "Content Unlocked!"
                        });
                    }
                }
                prevLocksRef.current = currentLockedIds;
            }
        })["GamificationToastLayer[useEffect()]"];
        t8 = [
            locks
        ];
        $[9] = locks;
        $[10] = t7;
        $[11] = t8;
    } else {
        t7 = $[10];
        t8 = $[11];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t7, t8);
    let t9;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = ({
            "GamificationToastLayer[closeRank]": ()=>setRankToast(_GamificationToastLayerCloseRankSetRankToast)
        })["GamificationToastLayer[closeRank]"];
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    const closeRank = t9;
    let t10;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = ({
            "GamificationToastLayer[closeBadge]": ()=>setBadgeFlip(_GamificationToastLayerCloseBadgeSetBadgeFlip)
        })["GamificationToastLayer[closeBadge]"];
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    const closeBadge = t10;
    let t11;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = ({
            "GamificationToastLayer[closeEgg]": ()=>setEasterEgg(_GamificationToastLayerCloseEggSetEasterEgg)
        })["GamificationToastLayer[closeEgg]"];
        $[14] = t11;
    } else {
        t11 = $[14];
    }
    const closeEgg = t11;
    let t12;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = ({
            "GamificationToastLayer[closeUnlock]": ()=>setUnlock({
                    show: false,
                    title: ""
                })
        })["GamificationToastLayer[closeUnlock]"];
        $[15] = t12;
    } else {
        t12 = $[15];
    }
    const closeUnlock = t12;
    let t13;
    if ($[16] !== rankToast.newRank || $[17] !== rankToast.open || $[18] !== rankToast.positionsChanged) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$RankChangeToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RankChangeToast"], {
            open: rankToast.open,
            positionsChanged: rankToast.positionsChanged,
            newRank: rankToast.newRank,
            onClose: closeRank
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 294,
            columnNumber: 11
        }, this);
        $[16] = rankToast.newRank;
        $[17] = rankToast.open;
        $[18] = rankToast.positionsChanged;
        $[19] = t13;
    } else {
        t13 = $[19];
    }
    let t14;
    if ($[20] !== badgeFlip.description || $[21] !== badgeFlip.emoji || $[22] !== badgeFlip.name || $[23] !== badgeFlip.open) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeCoinFlip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeCoinFlip"], {
            open: badgeFlip.open,
            badgeEmoji: badgeFlip.emoji,
            badgeName: badgeFlip.name,
            badgeDescription: badgeFlip.description,
            onClose: closeBadge
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 304,
            columnNumber: 11
        }, this);
        $[20] = badgeFlip.description;
        $[21] = badgeFlip.emoji;
        $[22] = badgeFlip.name;
        $[23] = badgeFlip.open;
        $[24] = t14;
    } else {
        t14 = $[24];
    }
    let t15;
    if ($[25] !== easterEgg.message || $[26] !== easterEgg.open || $[27] !== easterEgg.xpReward) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EasterEggToast"], {
            open: easterEgg.open,
            message: easterEgg.message,
            xpReward: easterEgg.xpReward,
            onClose: closeEgg
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 315,
            columnNumber: 11
        }, this);
        $[25] = easterEgg.message;
        $[26] = easterEgg.open;
        $[27] = easterEgg.xpReward;
        $[28] = t15;
    } else {
        t15 = $[28];
    }
    let t16;
    if ($[29] !== unlock.show || $[30] !== unlock.title) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ContentUnlockAnimation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentUnlockAnimation"], {
            show: unlock.show,
            title: unlock.title,
            onComplete: closeUnlock
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 325,
            columnNumber: 11
        }, this);
        $[29] = unlock.show;
        $[30] = unlock.title;
        $[31] = t16;
    } else {
        t16 = $[31];
    }
    let t17;
    if ($[32] !== t13 || $[33] !== t14 || $[34] !== t15 || $[35] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t13,
                t14,
                t15,
                t16
            ]
        }, void 0, true);
        $[32] = t13;
        $[33] = t14;
        $[34] = t15;
        $[35] = t16;
        $[36] = t17;
    } else {
        t17 = $[36];
    }
    return t17;
}
_s(GamificationToastLayer, "GUyfkCLISoaMzEQ9fdGupt+uzWo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContentLock"]
    ];
});
_c = GamificationToastLayer;
function _GamificationToastLayerCloseEggSetEasterEgg(s_1) {
    return {
        ...s_1,
        open: false
    };
}
function _GamificationToastLayerCloseBadgeSetBadgeFlip(s_0) {
    return {
        ...s_0,
        open: false
    };
}
function _GamificationToastLayerCloseRankSetRankToast(s) {
    return {
        ...s,
        open: false
    };
}
function _GamificationToastLayerUseEffectAnonymous(l_0) {
    return l_0.contentId;
}
function _GamificationToastLayerUseEffectLocksFilter(l) {
    return l.isLocked;
}
const __TURBOPACK__default__export__ = GamificationToastLayer;
var _c;
__turbopack_context__.k.register(_c, "GamificationToastLayer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/gamificationProviderWrapper.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GamificationProviderWrapper",
    ()=>GamificationProviderWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$GamificationToastLayer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/GamificationToastLayer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function GamificationProviderWrapper(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "7151689139be499929ce124491916299acef4963acc9fed72473e0c8f3c8605b") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7151689139be499929ce124491916299acef4963acc9fed72473e0c8f3c8605b";
    }
    const { children, cohortId: cohortIdProp } = t0;
    const { user, session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const client = t1;
    const isInstructor = session?.groups?.includes("Instructors") || session?.groups?.includes("Admins");
    const studentId = isInstructor ? "" : user?.username || user?.attributes?.sub || "";
    const { sections, assignments } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {};
    session?.groups;
    let t2;
    if ($[2] !== cohortIdProp || $[3] !== session?.groups) {
        bb0: {
            if (cohortIdProp) {
                t2 = cohortIdProp;
                break bb0;
            }
            const groups = session?.groups || [];
            for (const group of groups){
                const match = group.match(/^section-(.+?)-(learners|instructors)$/);
                if (match) {
                    t2 = match[1];
                    break bb0;
                }
            }
            t2 = undefined;
        }
        $[2] = cohortIdProp;
        $[3] = session?.groups;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const cohortId = t2;
    let t3;
    if ($[5] !== studentId) {
        t3 = studentId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$GamificationToastLayer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationToastLayer"], {}, void 0, false, {
            fileName: "[project]/src/context/gamificationProviderWrapper.jsx",
            lineNumber: 76,
            columnNumber: 23
        }, this);
        $[5] = studentId;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== assignments || $[8] !== children || $[9] !== cohortId || $[10] !== sections || $[11] !== studentId || $[12] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationProvider"], {
            client: client,
            studentId: studentId,
            cohortId: cohortId,
            sections: sections,
            assignments: assignments,
            children: [
                children,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/src/context/gamificationProviderWrapper.jsx",
            lineNumber: 84,
            columnNumber: 10
        }, this);
        $[7] = assignments;
        $[8] = children;
        $[9] = cohortId;
        $[10] = sections;
        $[11] = studentId;
        $[12] = t3;
        $[13] = t4;
    } else {
        t4 = $[13];
    }
    return t4;
}
_s(GamificationProviderWrapper, "KAg+X7S5wlQvcXKzXEV+lune0l8=");
_c = GamificationProviderWrapper;
var _c;
__turbopack_context__.k.register(_c, "GamificationProviderWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:894db5 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateSkillTreeFromUnit",
    ()=>$$RSC_SERVER_ACTION_4
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"70cee74d9083b5e7f4beed90d2410c133ce91c34f1":{"name":"generateSkillTreeFromUnit"}},"app/actions/gamification.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("70cee74d9083b5e7f4beed90d2410c133ce91c34f1", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateSkillTreeFromUnit");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/SkillTree.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SkillTree",
    ()=>SkillTree,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * SkillTree — Renders a skill DAG using React Flow.
 * Nodes represent skills, edges represent prerequisites.
 * Node colors are driven by StudentSkillProgress status.
 *
 * @module SkillTree
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@xyflow/react/dist/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@xyflow/system/dist/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Lock.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PlayArrow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PlayArrow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RadioButtonUnchecked$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RadioButtonUnchecked.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoFixHigh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AutoFixHigh.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$894db5__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:894db5 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// ============================================================================
// Status → Visual Mapping
// ============================================================================
const STATUS_COLORS = {
    LOCKED: '#616161',
    // darker grey for contrast
    AVAILABLE: '#1565c0',
    // darker blue
    IN_PROGRESS: '#e65100',
    // deep orange
    MASTERED: '#1b5e20' // dark green
};
const STATUS_BG = {
    LOCKED: '#eeeeee',
    AVAILABLE: '#bbdefb',
    IN_PROGRESS: '#ffe0b2',
    MASTERED: '#c8e6c9'
};
const STATUS_TEXT = {
    LOCKED: '#212121',
    AVAILABLE: '#0d47a1',
    IN_PROGRESS: '#bf360c',
    MASTERED: '#1b5e20'
};
const STATUS_ICONS = {
    LOCKED: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: 20
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
        lineNumber: 100,
        columnNumber: 11
    }, ("TURBOPACK compile-time value", void 0)),
    AVAILABLE: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RadioButtonUnchecked$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: 20
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
        lineNumber: 103,
        columnNumber: 14
    }, ("TURBOPACK compile-time value", void 0)),
    IN_PROGRESS: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PlayArrow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: 20
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
        lineNumber: 106,
        columnNumber: 16
    }, ("TURBOPACK compile-time value", void 0)),
    MASTERED: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: 20
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
        lineNumber: 109,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0))
};
// ============================================================================
// Custom Node Component
// ============================================================================
const SkillNodeContent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(_c = function SkillNodeContent(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(36);
    if ($[0] !== "69460c630ffc3daf913418612561382d95f3b0952d0e581812efb5baa4e98588") {
        for(let $i = 0; $i < 36; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "69460c630ffc3daf913418612561382d95f3b0952d0e581812efb5baa4e98588";
    }
    const { data } = t0;
    const status = data.status || "LOCKED";
    const isSelected = data.selected === true;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Handle"], {
            type: "target",
            position: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Top,
            style: {
                visibility: "hidden"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 133,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const t2 = `3px solid ${STATUS_COLORS[status]}`;
    const t3 = STATUS_BG[status];
    const t4 = status === "LOCKED" ? "not-allowed" : "pointer";
    const t5 = status === "LOCKED" ? 0.7 : 1;
    const t6 = isSelected ? `3px solid ${STATUS_COLORS[status]}` : "none";
    const t7 = isSelected ? `0 0 16px ${STATUS_COLORS[status]}50` : "0 2px 8px rgba(0,0,0,0.1)";
    const t8 = isSelected ? "scale(1.05)" : undefined;
    let t9;
    if ($[2] !== isSelected || $[3] !== status) {
        t9 = status !== "LOCKED" ? {
            boxShadow: isSelected ? `0 0 20px ${STATUS_COLORS[status]}60` : "0 4px 16px rgba(0,0,0,0.15)",
            transform: isSelected ? "scale(1.07)" : "scale(1.03)"
        } : {};
        $[2] = isSelected;
        $[3] = status;
        $[4] = t9;
    } else {
        t9 = $[4];
    }
    let t10;
    if ($[5] !== t2 || $[6] !== t3 || $[7] !== t4 || $[8] !== t5 || $[9] !== t6 || $[10] !== t7 || $[11] !== t8 || $[12] !== t9) {
        t10 = {
            p: 2,
            borderRadius: 2.5,
            border: t2,
            bgcolor: t3,
            minWidth: 200,
            maxWidth: 280,
            textAlign: "center",
            cursor: t4,
            opacity: t5,
            transition: "box-shadow 0.3s, transform 0.3s, outline 0.2s",
            outline: t6,
            outlineOffset: 3,
            boxShadow: t7,
            transform: t8,
            "&:hover": t9
        };
        $[5] = t2;
        $[6] = t3;
        $[7] = t4;
        $[8] = t5;
        $[9] = t6;
        $[10] = t7;
        $[11] = t8;
        $[12] = t9;
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 0.75,
            mb: 0.75
        };
        $[14] = t11;
    } else {
        t11 = $[14];
    }
    const t12 = STATUS_ICONS[status];
    const t13 = STATUS_TEXT[status];
    let t14;
    if ($[15] !== t13) {
        t14 = {
            fontWeight: 700,
            color: t13,
            lineHeight: 1.3,
            fontSize: "0.95rem"
        };
        $[15] = t13;
        $[16] = t14;
    } else {
        t14 = $[16];
    }
    let t15;
    if ($[17] !== data.title || $[18] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle1",
            sx: t14,
            children: data.title
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 220,
            columnNumber: 11
        }, this);
        $[17] = data.title;
        $[18] = t14;
        $[19] = t15;
    } else {
        t15 = $[19];
    }
    let t16;
    if ($[20] !== t12 || $[21] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t11,
            children: [
                t12,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 229,
            columnNumber: 11
        }, this);
        $[20] = t12;
        $[21] = t15;
        $[22] = t16;
    } else {
        t16 = $[22];
    }
    let t17;
    if ($[23] !== data.description) {
        t17 = data.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            sx: {
                color: "text.secondary",
                fontSize: "0.8rem",
                lineHeight: 1.3,
                mb: 0.75,
                overflow: "hidden",
                textOverflow: "ellipsis",
                display: "-webkit-box",
                WebkitLineClamp: 2,
                WebkitBoxOrient: "vertical"
            },
            children: data.description
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 238,
            columnNumber: 31
        }, this);
        $[23] = data.description;
        $[24] = t17;
    } else {
        t17 = $[24];
    }
    let t18;
    if ($[25] !== data.xpReward || $[26] !== status) {
        t18 = data.xpReward != null && data.xpReward > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: `+${data.xpReward} XP`,
            size: "small",
            sx: {
                height: 24,
                fontSize: "0.8rem",
                fontWeight: 600,
                bgcolor: STATUS_COLORS[status],
                color: "white"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 256,
            columnNumber: 57
        }, this);
        $[25] = data.xpReward;
        $[26] = status;
        $[27] = t18;
    } else {
        t18 = $[27];
    }
    let t19;
    if ($[28] !== t10 || $[29] !== t16 || $[30] !== t17 || $[31] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t10,
            children: [
                t16,
                t17,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 271,
            columnNumber: 11
        }, this);
        $[28] = t10;
        $[29] = t16;
        $[30] = t17;
        $[31] = t18;
        $[32] = t19;
    } else {
        t19 = $[32];
    }
    let t20;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Handle"], {
            type: "source",
            position: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Bottom,
            style: {
                visibility: "hidden"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 282,
            columnNumber: 11
        }, this);
        $[33] = t20;
    } else {
        t20 = $[33];
    }
    let t21;
    if ($[34] !== t19) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t1,
                t19,
                t20
            ]
        }, void 0, true);
        $[34] = t19;
        $[35] = t21;
    } else {
        t21 = $[35];
    }
    return t21;
});
_c1 = SkillNodeContent;
// ============================================================================
// Layout Helpers
// ============================================================================
/**
 * Simple layered DAG layout — skills with no prerequisites at the top,
 * each subsequent layer below. This is a basic topological sort approach.
 */ function layoutSkills(skills) {
    const skillMap = new Map(skills.map((s)=>[
            s.skillId,
            s
        ]));
    const prereqMap = new Map();
    skills.forEach((s)=>{
        prereqMap.set(s.skillId, s.prerequisites || []);
    });
    // Topological layer assignment
    const layers = new Map();
    function getLayer(id, visited) {
        if (layers.has(id)) return layers.get(id);
        if (visited.has(id)) return 0; // cycle guard
        visited.add(id);
        const prereqs = prereqMap.get(id) || [];
        if (prereqs.length === 0) {
            layers.set(id, 0);
            return 0;
        }
        const maxPrereqLayer = Math.max(...prereqs.filter((pid)=>skillMap.has(pid)).map((pid)=>getLayer(pid, visited)), -1);
        const layer = maxPrereqLayer + 1;
        layers.set(id, layer);
        return layer;
    }
    skills.forEach((s)=>getLayer(s.skillId, new Set()));
    // Group skills by layer
    const layerGroups = new Map();
    layers.forEach((layer, id)=>{
        if (!layerGroups.has(layer)) layerGroups.set(layer, []);
        layerGroups.get(layer).push(id);
    });
    const LAYER_GAP_Y = 180;
    const NODE_GAP_X = 300;
    const nodes = [];
    layerGroups.forEach((ids, layer)=>{
        const totalWidth = ids.length * NODE_GAP_X;
        const startX = -totalWidth / 2 + NODE_GAP_X / 2;
        ids.forEach((id, idx)=>{
            const skill = skillMap.get(id);
            nodes.push({
                id,
                position: {
                    x: startX + idx * NODE_GAP_X,
                    y: layer * LAYER_GAP_Y
                },
                data: skill,
                type: 'skillNode',
                sourcePosition: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Bottom,
                targetPosition: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Top
            });
        });
    });
    // Build edges from prerequisites
    const edges = [];
    skills.forEach((s)=>{
        ;
        (s.prerequisites || []).forEach((prereqId)=>{
            if (skillMap.has(prereqId)) {
                edges.push({
                    id: `${prereqId}->${s.skillId}`,
                    source: prereqId,
                    target: s.skillId,
                    animated: s.status === 'IN_PROGRESS',
                    style: {
                        stroke: STATUS_COLORS[s.status],
                        strokeWidth: 2
                    },
                    markerEnd: {
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MarkerType"].ArrowClosed,
                        color: STATUS_COLORS[s.status]
                    }
                });
            }
        });
    });
    return {
        nodes,
        edges
    };
}
// ============================================================================
// Physics System — spring/damping/repulsion with CSS transition smoothing
// ============================================================================
/** Spring stiffness */ const SPRING_K = 0.04;
/** Damping — higher = less bounce */ const DAMPING = 0.88;
/** Impulse on click */ const TOUCH_IMPULSE = 8;
/** How far impulse propagates (px) */ const IMPULSE_FALLOFF = 300;
/** Repulsion between nearby nodes */ const REPULSION_STRENGTH = 800;
/** Distance where repulsion activates */ const REPULSION_RADIUS = 200;
/** Minimum distance for hard collision */ const MIN_NODE_DISTANCE = 180;
/** Velocity threshold to stop simulation */ const VEL_THRESHOLD = 0.05;
/** Position threshold to snap to rest */ const POS_THRESHOLD = 0.3;
/** Strength of pull on connected nodes during drag */ const DRAG_PULL = 0.15;
/** Pull decay per graph hop */ const DRAG_HOP_DECAY = 0.5;
function buildAdjacency(edges) {
    const adj = new Map();
    for (const edge of edges){
        if (!adj.has(edge.source)) adj.set(edge.source, new Set());
        if (!adj.has(edge.target)) adj.set(edge.target, new Set());
        adj.get(edge.source).add(edge.target);
        adj.get(edge.target).add(edge.source);
    }
    return adj;
}
function bfsDistances(sourceId, adjacency) {
    const distances = new Map();
    distances.set(sourceId, 0);
    const queue = [
        sourceId
    ];
    let i = 0;
    while(i < queue.length){
        const current = queue[i++];
        const currentDist = distances.get(current);
        const neighbors = adjacency.get(current);
        if (!neighbors) continue;
        for (const neighbor of neighbors){
            if (!distances.has(neighbor)) {
                distances.set(neighbor, currentDist + 1);
                queue.push(neighbor);
            }
        }
    }
    return distances;
}
/**
 * Physics hook that computes node positions via spring/damping simulation.
 * Positions are applied to React Flow nodes; CSS transitions on the
 * `.react-flow__node` elements provide smooth interpolation between frames.
 * The dragged node is exempt from physics (React Flow handles it directly).
 */ function usePhysicsPositions(nodes, edges, setNodes, enabled) {
    _s();
    const bodiesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    const animRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const runningRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const draggedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Sync rest positions when nodes change from external source (layout, skills prop)
    const prevNodeCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePhysicsPositions.useEffect": ()=>{
            if (!enabled) return;
            // Only reset rest positions when node count changes (new layout)
            if (nodes.length !== prevNodeCountRef.current) {
                const bodies = bodiesRef.current;
                bodies.clear();
                nodes.forEach({
                    "usePhysicsPositions.useEffect": (n)=>{
                        bodies.set(n.id, {
                            x: n.position.x,
                            y: n.position.y,
                            vx: 0,
                            vy: 0,
                            restX: n.position.x,
                            restY: n.position.y
                        });
                    }
                }["usePhysicsPositions.useEffect"]);
                prevNodeCountRef.current = nodes.length;
            }
        }
    }["usePhysicsPositions.useEffect"], [
        nodes,
        enabled
    ]);
    const step = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[step]": ()=>{
            if (!enabled) return;
            const bodies_0 = bodiesRef.current;
            const ids = Array.from(bodies_0.keys());
            let hasMotion = false;
            // Spring force toward rest position
            for (const id of ids){
                if (id === draggedRef.current) continue;
                const body = bodies_0.get(id);
                const fx = (body.restX - body.x) * SPRING_K;
                const fy = (body.restY - body.y) * SPRING_K;
                body.vx = (body.vx + fx) * DAMPING;
                body.vy = (body.vy + fy) * DAMPING;
            }
            // Pairwise repulsion
            for(let i = 0; i < ids.length; i++){
                if (ids[i] === draggedRef.current) continue;
                for(let j = i + 1; j < ids.length; j++){
                    if (ids[j] === draggedRef.current) continue;
                    const a = bodies_0.get(ids[i]);
                    const b = bodies_0.get(ids[j]);
                    const dx = a.x - b.x;
                    const dy = a.y - b.y;
                    const dist = Math.sqrt(dx * dx + dy * dy) || 1;
                    if (dist < REPULSION_RADIUS) {
                        const force = REPULSION_STRENGTH / (dist * dist);
                        const nx = dx / dist;
                        const ny = dy / dist;
                        a.vx += nx * force * 0.5;
                        a.vy += ny * force * 0.5;
                        b.vx -= nx * force * 0.5;
                        b.vy -= ny * force * 0.5;
                    }
                    // Hard collision
                    if (dist < MIN_NODE_DISTANCE) {
                        const overlap = (MIN_NODE_DISTANCE - dist) / 2;
                        const nx_0 = dx / dist;
                        const ny_0 = dy / dist;
                        a.x += nx_0 * overlap;
                        a.y += ny_0 * overlap;
                        b.x -= nx_0 * overlap;
                        b.y -= ny_0 * overlap;
                    }
                }
            }
            // Integrate positions
            for (const id_0 of ids){
                if (id_0 === draggedRef.current) continue;
                const body_0 = bodies_0.get(id_0);
                body_0.x += body_0.vx;
                body_0.y += body_0.vy;
                if (Math.abs(body_0.vx) > VEL_THRESHOLD || Math.abs(body_0.vy) > VEL_THRESHOLD || Math.abs(body_0.x - body_0.restX) > POS_THRESHOLD || Math.abs(body_0.y - body_0.restY) > POS_THRESHOLD) {
                    hasMotion = true;
                }
            }
            // Snap settled nodes
            if (!hasMotion) {
                for (const id_1 of ids){
                    const body_1 = bodies_0.get(id_1);
                    body_1.x = body_1.restX;
                    body_1.y = body_1.restY;
                    body_1.vx = 0;
                    body_1.vy = 0;
                }
            }
            // Apply to React Flow nodes
            setNodes({
                "usePhysicsPositions.useCallback[step]": (currentNodes)=>currentNodes.map({
                        "usePhysicsPositions.useCallback[step]": (n_0)=>{
                            if (n_0.id === draggedRef.current) return n_0;
                            const body_2 = bodies_0.get(n_0.id);
                            if (!body_2) return n_0;
                            if (n_0.position.x === body_2.x && n_0.position.y === body_2.y) return n_0;
                            return {
                                ...n_0,
                                position: {
                                    x: body_2.x,
                                    y: body_2.y
                                }
                            };
                        }
                    }["usePhysicsPositions.useCallback[step]"])
            }["usePhysicsPositions.useCallback[step]"]);
            if (hasMotion) {
                animRef.current = requestAnimationFrame(step);
            } else {
                runningRef.current = false;
            }
        }
    }["usePhysicsPositions.useCallback[step]"], [
        enabled,
        setNodes
    ]);
    const startSim = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[startSim]": ()=>{
            if (!runningRef.current && enabled) {
                runningRef.current = true;
                animRef.current = requestAnimationFrame(step);
            }
        }
    }["usePhysicsPositions.useCallback[startSim]"], [
        enabled,
        step
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePhysicsPositions.useEffect": ()=>{
            return ({
                "usePhysicsPositions.useEffect": ()=>{
                    if (animRef.current) cancelAnimationFrame(animRef.current);
                }
            })["usePhysicsPositions.useEffect"];
        }
    }["usePhysicsPositions.useEffect"], []);
    /** Apply click impulse — source bounces, neighbors push away */ const applyImpulse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[applyImpulse]": (sourceId)=>{
            if (!enabled) return;
            const bodies_1 = bodiesRef.current;
            const source = bodies_1.get(sourceId);
            if (!source) return;
            // Source bounces up
            source.vy -= TOUCH_IMPULSE * 0.5;
            // Push neighbors
            bodies_1.forEach({
                "usePhysicsPositions.useCallback[applyImpulse]": (body_3, id_2)=>{
                    if (id_2 === sourceId) return;
                    const dx_0 = body_3.x - source.x;
                    const dy_0 = body_3.y - source.y;
                    const dist_0 = Math.sqrt(dx_0 * dx_0 + dy_0 * dy_0) || 1;
                    const strength = TOUCH_IMPULSE * Math.exp(-dist_0 / IMPULSE_FALLOFF);
                    body_3.vx += dx_0 / dist_0 * strength;
                    body_3.vy += dy_0 / dist_0 * strength;
                }
            }["usePhysicsPositions.useCallback[applyImpulse]"]);
            startSim();
        }
    }["usePhysicsPositions.useCallback[applyImpulse]"], [
        enabled,
        startSim
    ]);
    /** Notify physics that a node is being dragged — pull connected nodes */ const onDragMove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[onDragMove]": (nodeId, x, y)=>{
            if (!enabled) return;
            const bodies_2 = bodiesRef.current;
            const body_4 = bodies_2.get(nodeId);
            if (!body_4) return;
            const deltaX = x - body_4.x;
            const deltaY = y - body_4.y;
            body_4.x = x;
            body_4.y = y;
            body_4.restX = x;
            body_4.restY = y;
            // Pull connected nodes along the drag direction
            const adj = buildAdjacency(edges);
            const hops = bfsDistances(nodeId, adj);
            hops.forEach({
                "usePhysicsPositions.useCallback[onDragMove]": (hopCount, id_3)=>{
                    if (id_3 === nodeId) return;
                    const neighbor = bodies_2.get(id_3);
                    if (!neighbor) return;
                    const factor = DRAG_PULL * Math.pow(DRAG_HOP_DECAY, hopCount);
                    if (factor < 0.01) return;
                    neighbor.vx += deltaX * factor;
                    neighbor.vy += deltaY * factor;
                    // Also shift rest position slightly for plasticity
                    neighbor.restX += deltaX * factor * 0.3;
                    neighbor.restY += deltaY * factor * 0.3;
                }
            }["usePhysicsPositions.useCallback[onDragMove]"]);
            startSim();
        }
    }["usePhysicsPositions.useCallback[onDragMove]"], [
        enabled,
        edges,
        startSim
    ]);
    const onDragStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[onDragStart]": (nodeId_0)=>{
            draggedRef.current = nodeId_0;
        }
    }["usePhysicsPositions.useCallback[onDragStart]"], []);
    const onDragStop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[onDragStop]": (nodeId_1)=>{
            draggedRef.current = null;
            // Update rest position to where node was dropped
            const body_5 = bodiesRef.current.get(nodeId_1);
            if (body_5) {
                body_5.restX = body_5.x;
                body_5.restY = body_5.y;
                body_5.vx = 0;
                body_5.vy = 0;
            }
            startSim();
        }
    }["usePhysicsPositions.useCallback[onDragStop]"], [
        startSim
    ]);
    return {
        applyImpulse,
        onDragStart,
        onDragMove,
        onDragStop
    };
}
_s(usePhysicsPositions, "oVfPqaVBfRu5yHjBAcDs2CjdTok=");
// ============================================================================
// SkillTree Inner (needs ReactFlowProvider parent for useReactFlow)
// ============================================================================
const nodeTypes = {
    skillNode: SkillNodeContent
};
function SkillTreeInner({ skills, onSkillClick, height = '100%', unitId, cohortId, canGenerate = false, onGenerated, editable = false, onPrerequisiteChange, selectedSkillId }) {
    _s1();
    const { nodes: initialNodes, edges: initialEdges } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SkillTreeInner.useMemo": ()=>layoutSkills(skills)
    }["SkillTreeInner.useMemo"], [
        skills
    ]);
    const [nodes, setNodes, onNodesChange] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useNodesState"])(initialNodes);
    const [edges, setEdges, onEdgesChange] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEdgesState"])(initialEdges);
    const [generating, setGenerating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isDragging, setIsDragging] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const reactFlow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useReactFlow"])();
    // Physics — spring/repulsion with CSS transition smoothing
    const { applyImpulse, onDragStart, onDragMove, onDragStop } = usePhysicsPositions(nodes, edges, setNodes, !editable);
    // Sync when skills prop changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SkillTreeInner.useEffect": ()=>{
            const layout = layoutSkills(skills);
            setNodes(layout.nodes.map({
                "SkillTreeInner.useEffect": (n)=>({
                        ...n,
                        data: {
                            ...n.data,
                            selected: n.id === selectedSkillId
                        }
                    })
            }["SkillTreeInner.useEffect"]));
            setEdges(layout.edges);
        }
    }["SkillTreeInner.useEffect"], [
        skills,
        selectedSkillId,
        setNodes,
        setEdges
    ]);
    // Keyboard zoom: capture +/- when container is focused or hovered
    const handleKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleKeyDown]": (e)=>{
            const isZoomIn = (e.key === '=' || e.key === '+') && (e.ctrlKey || e.metaKey);
            const isZoomOut = e.key === '-' && (e.ctrlKey || e.metaKey);
            if (isZoomIn || isZoomOut) {
                e.preventDefault();
                e.stopPropagation();
                const currentZoom = reactFlow.getZoom();
                const newZoom = isZoomIn ? Math.min(currentZoom * 1.2, 2.5) : Math.max(currentZoom / 1.2, 0.2);
                reactFlow.zoomTo(newZoom, {
                    duration: 200
                });
            }
        }
    }["SkillTreeInner.useCallback[handleKeyDown]"], [
        reactFlow
    ]);
    // Handle new edge connection (source is prerequisite of target)
    const handleConnect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleConnect]": (connection)=>{
            if (!connection.source || !connection.target) return;
            if (connection.source === connection.target) return;
            setEdges({
                "SkillTreeInner.useCallback[handleConnect]": (eds)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEdge"])({
                        ...connection,
                        animated: false,
                        style: {
                            stroke: '#1976d2',
                            strokeWidth: 2
                        },
                        markerEnd: {
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MarkerType"].ArrowClosed,
                            color: '#1976d2'
                        }
                    }, eds)
            }["SkillTreeInner.useCallback[handleConnect]"]);
            if (onPrerequisiteChange) {
                const targetSkill = skills.find({
                    "SkillTreeInner.useCallback[handleConnect].targetSkill": (s)=>s.skillId === connection.target
                }["SkillTreeInner.useCallback[handleConnect].targetSkill"]);
                const currentPrereqs = targetSkill?.prerequisites || [];
                if (!currentPrereqs.includes(connection.source)) {
                    onPrerequisiteChange(connection.target, [
                        ...currentPrereqs,
                        connection.source
                    ]);
                }
            }
        }
    }["SkillTreeInner.useCallback[handleConnect]"], [
        skills,
        setEdges,
        onPrerequisiteChange
    ]);
    // Handle edge deletion
    const handleEdgesDelete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleEdgesDelete]": (deletedEdges)=>{
            if (!onPrerequisiteChange) return;
            for (const edge of deletedEdges){
                const targetSkill_0 = skills.find({
                    "SkillTreeInner.useCallback[handleEdgesDelete].targetSkill_0": (s_0)=>s_0.skillId === edge.target
                }["SkillTreeInner.useCallback[handleEdgesDelete].targetSkill_0"]);
                if (targetSkill_0) {
                    const updatedPrereqs = (targetSkill_0.prerequisites || []).filter({
                        "SkillTreeInner.useCallback[handleEdgesDelete].updatedPrereqs": (prereqId)=>prereqId !== edge.source
                    }["SkillTreeInner.useCallback[handleEdgesDelete].updatedPrereqs"]);
                    onPrerequisiteChange(edge.target, updatedPrereqs);
                }
            }
        }
    }["SkillTreeInner.useCallback[handleEdgesDelete]"], [
        skills,
        onPrerequisiteChange
    ]);
    const handleGenerate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleGenerate]": async ()=>{
            if (!unitId) return;
            setGenerating(true);
            setError(null);
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$894db5__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateSkillTreeFromUnit"])(unitId, cohortId);
                if (result?.generated) {
                    onGenerated?.({
                        skillCount: result.skillCount ?? 0
                    });
                } else {
                    setError(result?.reason ?? 'Failed to generate skill tree');
                }
            } catch  {
                setError('An unexpected error occurred');
            } finally{
                setGenerating(false);
            }
        }
    }["SkillTreeInner.useCallback[handleGenerate]"], [
        unitId,
        cohortId,
        onGenerated
    ]);
    // Node click: fire onSkillClick AND trigger physics impulse
    const handleNodeClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleNodeClick]": (_event, node)=>{
            const data = node.data;
            applyImpulse(node.id);
            if (data.status !== 'LOCKED' && onSkillClick) {
                onSkillClick(data.skillId);
            }
        }
    }["SkillTreeInner.useCallback[handleNodeClick]"], [
        onSkillClick,
        applyImpulse
    ]);
    // Node drag: propagate pull to connected nodes via physics
    const handleNodeDragStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleNodeDragStart]": (_event_0, node_0)=>{
            setIsDragging(true);
            onDragStart(node_0.id);
        }
    }["SkillTreeInner.useCallback[handleNodeDragStart]"], [
        onDragStart
    ]);
    const handleNodeDrag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleNodeDrag]": (_event_1, node_1)=>{
            onDragMove(node_1.id, node_1.position.x, node_1.position.y);
        }
    }["SkillTreeInner.useCallback[handleNodeDrag]"], [
        onDragMove
    ]);
    const handleNodeDragStop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleNodeDragStop]": (_event_2, node_2)=>{
            setIsDragging(false);
            onDragStop(node_2.id);
        }
    }["SkillTreeInner.useCallback[handleNodeDragStop]"], [
        onDragStop
    ]);
    // Determine if panning should be allowed based on zoom level and container size
    // Only allow pan when content exceeds container width at current zoom
    const [panEnabled, setPanEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    if (skills.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                p: 3,
                textAlign: 'center'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    color: "text.secondary",
                    children: "No skills defined yet."
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                    lineNumber: 822,
                    columnNumber: 9
                }, this),
                canGenerate && unitId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        mt: 2
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "contained",
                            startIcon: generating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "circular",
                                width: 18,
                                height: 18
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                                lineNumber: 826,
                                columnNumber: 65
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoFixHigh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                                lineNumber: 826,
                                columnNumber: 122
                            }, this),
                            onClick: handleGenerate,
                            disabled: generating,
                            children: generating ? 'Generating…' : 'Generate from Unit Content'
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                            lineNumber: 826,
                            columnNumber: 13
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            color: "error",
                            variant: "caption",
                            sx: {
                                display: 'block',
                                mt: 1
                            },
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                            lineNumber: 829,
                            columnNumber: 23
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                    lineNumber: 823,
                    columnNumber: 35
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 818,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ref: containerRef,
        tabIndex: 0,
        onKeyDown: handleKeyDown,
        sx: {
            height,
            width: '100%',
            position: 'relative',
            bgcolor: 'background.default',
            outline: 'none',
            overflow: 'visible',
            '& .react-flow__renderer': {
                overflow: 'visible'
            },
            '& .react-flow__viewport': {
                overflow: 'visible'
            },
            // CSS transitions smooth the physics position updates
            '& .react-flow__node': {
                transition: isDragging ? 'none' : 'transform 0.15s ease-out'
            },
            // Dragged node follows cursor immediately (no transition)
            '& .react-flow__node.dragging': {
                transition: 'none !important'
            }
        },
        children: [
            editable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "text.secondary",
                sx: {
                    position: 'absolute',
                    top: 4,
                    left: 8,
                    zIndex: 10,
                    bgcolor: 'background.paper',
                    px: 0.5,
                    borderRadius: 0.5
                },
                children: "Drag nodes to reposition • Draw edges to add prerequisites • Select + Backspace to remove"
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 860,
                columnNumber: 20
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ReactFlow"], {
                nodes: nodes,
                edges: edges,
                nodeTypes: nodeTypes,
                onNodesChange: onNodesChange,
                onEdgesChange: editable ? onEdgesChange : undefined,
                onConnect: editable ? handleConnect : undefined,
                onEdgesDelete: editable ? handleEdgesDelete : undefined,
                onNodeClick: handleNodeClick,
                onNodeDragStart: handleNodeDragStart,
                onNodeDrag: handleNodeDrag,
                onNodeDragStop: handleNodeDragStop,
                fitView: true,
                fitViewOptions: {
                    padding: 0.3,
                    maxZoom: 1.5
                },
                proOptions: {
                    hideAttribution: true
                },
                nodesDraggable: true,
                nodesConnectable: editable,
                elementsSelectable: editable,
                deleteKeyCode: editable ? 'Backspace' : null,
                panOnDrag: panEnabled,
                zoomOnScroll: true,
                zoomOnPinch: true,
                zoomOnDoubleClick: true,
                minZoom: 0.2,
                maxZoom: 2.5,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Background"], {
                        gap: 24,
                        size: 1
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                        lineNumber: 877,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Controls"], {
                        showInteractive: editable
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                        lineNumber: 878,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 871,
                columnNumber: 7
            }, this),
            canGenerate && unitId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: generating ? 'Generating…' : 'Regenerate skill tree from unit content',
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        position: 'absolute',
                        top: 8,
                        right: 8,
                        zIndex: 10
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        size: "small",
                        onClick: handleGenerate,
                        disabled: generating,
                        "aria-label": generating ? 'Generating…' : 'Regenerate skill tree from unit content',
                        sx: {
                            bgcolor: 'background.paper',
                            boxShadow: 1,
                            '&:hover': {
                                bgcolor: 'action.hover'
                            }
                        },
                        children: generating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "circular",
                            width: 20,
                            height: 20
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                            lineNumber: 894,
                            columnNumber: 29
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoFixHigh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            fontSize: "small"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                            lineNumber: 894,
                            columnNumber: 86
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                        lineNumber: 887,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                    lineNumber: 881,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 880,
                columnNumber: 33
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                color: "error",
                variant: "caption",
                sx: {
                    position: 'absolute',
                    bottom: 8,
                    left: 8,
                    zIndex: 10,
                    bgcolor: 'background.paper',
                    px: 1,
                    borderRadius: 1
                },
                children: error
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 898,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
        lineNumber: 838,
        columnNumber: 10
    }, this);
}
_s1(SkillTreeInner, "iEy4Jhbxw+h8Ky0aBcPDHzckVVY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useNodesState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEdgesState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useReactFlow"],
        usePhysicsPositions
    ];
});
_c2 = SkillTreeInner;
function SkillTree(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "69460c630ffc3daf913418612561382d95f3b0952d0e581812efb5baa4e98588") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "69460c630ffc3daf913418612561382d95f3b0952d0e581812efb5baa4e98588";
    }
    let loading;
    let rest;
    if ($[1] !== props) {
        const { compact: _compact, loading: t0, ...t1 } = props;
        loading = t0;
        rest = t1;
        $[1] = props;
        $[2] = loading;
        $[3] = rest;
    } else {
        loading = $[2];
        rest = $[3];
    }
    if (loading) {
        const t0 = rest.height || "100%";
        let t1;
        if ($[4] !== t0) {
            t1 = {
                height: t0,
                width: "100%",
                p: 3,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 3
            };
            $[4] = t0;
            $[5] = t1;
        } else {
            t1 = $[5];
        }
        let t2;
        if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = {
                display: "flex",
                justifyContent: "center"
            };
            $[6] = t2;
        } else {
            t2 = $[6];
        }
        let t3;
        if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t2,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "rectangular",
                    width: 240,
                    height: 100,
                    sx: {
                        borderRadius: 2
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                    lineNumber: 971,
                    columnNumber: 25
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 971,
                columnNumber: 12
            }, this);
            $[7] = t3;
        } else {
            t3 = $[7];
        }
        let t4;
        if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = {
                display: "flex",
                gap: 4,
                justifyContent: "center"
            };
            $[8] = t4;
        } else {
            t4 = $[8];
        }
        let t5;
        if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                width: 220,
                height: 90,
                sx: {
                    borderRadius: 2
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 991,
                columnNumber: 12
            }, this);
            $[9] = t5;
        } else {
            t5 = $[9];
        }
        let t6;
        if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t4,
                children: [
                    t5,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "rectangular",
                        width: 220,
                        height: 90,
                        sx: {
                            borderRadius: 2
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                        lineNumber: 1000,
                        columnNumber: 29
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1000,
                columnNumber: 12
            }, this);
            $[10] = t6;
        } else {
            t6 = $[10];
        }
        let t7;
        if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = {
                display: "flex",
                gap: 4,
                justifyContent: "center"
            };
            $[11] = t7;
        } else {
            t7 = $[11];
        }
        let t8;
        if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                width: 200,
                height: 85,
                sx: {
                    borderRadius: 2
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1020,
                columnNumber: 12
            }, this);
            $[12] = t8;
        } else {
            t8 = $[12];
        }
        let t9;
        if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                width: 200,
                height: 85,
                sx: {
                    borderRadius: 2
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1029,
                columnNumber: 12
            }, this);
            $[13] = t9;
        } else {
            t9 = $[13];
        }
        let t10;
        if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t7,
                children: [
                    t8,
                    t9,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "rectangular",
                        width: 200,
                        height: 85,
                        sx: {
                            borderRadius: 2
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                        lineNumber: 1038,
                        columnNumber: 34
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1038,
                columnNumber: 13
            }, this);
            $[14] = t10;
        } else {
            t10 = $[14];
        }
        let t11;
        if ($[15] !== t1) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t1,
                children: [
                    t3,
                    t6,
                    t10
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1047,
                columnNumber: 13
            }, this);
            $[15] = t1;
            $[16] = t11;
        } else {
            t11 = $[16];
        }
        return t11;
    }
    let t0;
    if ($[17] !== rest) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ReactFlowProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SkillTreeInner, {
                ...rest
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1057,
                columnNumber: 29
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 1057,
            columnNumber: 10
        }, this);
        $[17] = rest;
        $[18] = t0;
    } else {
        t0 = $[18];
    }
    return t0;
}
_c3 = SkillTree;
const __TURBOPACK__default__export__ = SkillTree;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "SkillNodeContent$memo");
__turbopack_context__.k.register(_c1, "SkillNodeContent");
__turbopack_context__.k.register(_c2, "SkillTreeInner");
__turbopack_context__.k.register(_c3, "SkillTree");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/SkillTreePopupButton.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SkillTreePopupButton",
    ()=>SkillTreePopupButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationProviderWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationProviderWrapper.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$SkillTree$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/SkillTree.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
function SkillTreePopupButton(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "c72a3d27378a7a3b2914b7af95728b8950cc649a8a2ff18d41daa15c3211e00d") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c72a3d27378a7a3b2914b7af95728b8950cc649a8a2ff18d41daa15c3211e00d";
    }
    const { sectionId } = t0;
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "SkillTreePopupButton[<Button>.onClick]": ()=>setOpen(true)
        })["SkillTreePopupButton[<Button>.onClick]"];
        t2 = {
            mb: 2
        };
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    const t3 = !sectionId;
    let t4;
    if ($[3] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            variant: "outlined",
            color: "primary",
            onClick: t1,
            sx: t2,
            disabled: t3,
            children: "View Skill Tree"
        }, void 0, false, {
            fileName: "[project]/src/components/SkillTreePopupButton.jsx",
            lineNumber: 38,
            columnNumber: 10
        }, this);
        $[3] = t3;
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    let t5;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "SkillTreePopupButton[<Dialog>.onClose]": ()=>setOpen(false)
        })["SkillTreePopupButton[<Dialog>.onClose]"];
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    let t6;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between"
        };
        $[6] = t6;
    } else {
        t6 = $[6];
    }
    let t7;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
            sx: t6,
            children: [
                "Skill Tree",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                    onClick: {
                        "SkillTreePopupButton[<IconButton>.onClick]": ()=>setOpen(false)
                    }["SkillTreePopupButton[<IconButton>.onClick]"],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/SkillTreePopupButton.jsx",
                        lineNumber: 68,
                        columnNumber: 56
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/SkillTreePopupButton.jsx",
                    lineNumber: 66,
                    columnNumber: 41
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/SkillTreePopupButton.jsx",
            lineNumber: 66,
            columnNumber: 10
        }, this);
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    let t8;
    if ($[8] !== sectionId) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
            children: sectionId ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationProviderWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationProviderWrapper"], {
                cohortId: sectionId,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SkillTreeModalContent, {}, void 0, false, {
                    fileName: "[project]/src/components/SkillTreePopupButton.jsx",
                    lineNumber: 75,
                    columnNumber: 88
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/SkillTreePopupButton.jsx",
                lineNumber: 75,
                columnNumber: 38
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "No section selected."
            }, void 0, false, {
                fileName: "[project]/src/components/SkillTreePopupButton.jsx",
                lineNumber: 75,
                columnNumber: 146
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/SkillTreePopupButton.jsx",
            lineNumber: 75,
            columnNumber: 10
        }, this);
        $[8] = sectionId;
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    let t9;
    if ($[10] !== open || $[11] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
            open: open,
            onClose: t5,
            maxWidth: "lg",
            fullWidth: true,
            children: [
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/SkillTreePopupButton.jsx",
            lineNumber: 83,
            columnNumber: 10
        }, this);
        $[10] = open;
        $[11] = t8;
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    let t10;
    if ($[13] !== t4 || $[14] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t4,
                t9
            ]
        }, void 0, true);
        $[13] = t4;
        $[14] = t9;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    return t10;
}
_s(SkillTreePopupButton, "xG1TONbKtDWtdOTrXaTAsNhPg/Q=");
_c = SkillTreePopupButton;
function SkillTreeModalContent() {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "c72a3d27378a7a3b2914b7af95728b8950cc649a8a2ff18d41daa15c3211e00d") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c72a3d27378a7a3b2914b7af95728b8950cc649a8a2ff18d41daa15c3211e00d";
    }
    const { skillNodes, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSkillTree"])();
    if (isLoading) {
        let t0;
        if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
            t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "Loading..."
            }, void 0, false, {
                fileName: "[project]/src/components/SkillTreePopupButton.jsx",
                lineNumber: 116,
                columnNumber: 12
            }, this);
            $[1] = t0;
        } else {
            t0 = $[1];
        }
        return t0;
    }
    if (!skillNodes?.length) {
        let t0;
        if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
            t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "No skills available for this section."
            }, void 0, false, {
                fileName: "[project]/src/components/SkillTreePopupButton.jsx",
                lineNumber: 126,
                columnNumber: 12
            }, this);
            $[2] = t0;
        } else {
            t0 = $[2];
        }
        return t0;
    }
    let t0;
    if ($[3] !== skillNodes) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$SkillTree$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SkillTree"], {
            skills: skillNodes,
            height: 450
        }, void 0, false, {
            fileName: "[project]/src/components/SkillTreePopupButton.jsx",
            lineNumber: 135,
            columnNumber: 10
        }, this);
        $[3] = skillNodes;
        $[4] = t0;
    } else {
        t0 = $[4];
    }
    return t0;
}
_s1(SkillTreeModalContent, "Wyu48qayWJlb9eOrmaer2w8lrXI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSkillTree"]
    ];
});
_c1 = SkillTreeModalContent;
var _c, _c1;
__turbopack_context__.k.register(_c, "SkillTreePopupButton");
__turbopack_context__.k.register(_c1, "SkillTreeModalContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PrefetchButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PrefetchButton",
    ()=>PrefetchButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
'use client';
;
;
;
;
;
const PrefetchButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = function PrefetchButton(t0, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "f483fd7fccc39dccf0fe1d7fc1d966ef625fd3a1ebfe4b2dac4f40898acbb3db") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f483fd7fccc39dccf0fe1d7fc1d966ef625fd3a1ebfe4b2dac4f40898acbb3db";
    }
    let buttonProps;
    let children;
    let href;
    let t1;
    if ($[1] !== t0) {
        ({ href, prefetch: t1, children, ...buttonProps } = t0);
        $[1] = t0;
        $[2] = buttonProps;
        $[3] = children;
        $[4] = href;
        $[5] = t1;
    } else {
        buttonProps = $[2];
        children = $[3];
        href = $[4];
        t1 = $[5];
    }
    const prefetch = t1 === undefined ? true : t1;
    let t2;
    if ($[6] !== buttonProps || $[7] !== children || $[8] !== href || $[9] !== prefetch || $[10] !== ref) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            component: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
            href: href,
            prefetch: prefetch,
            ref: ref,
            ...buttonProps,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/PrefetchButton.tsx",
            lineNumber: 50,
            columnNumber: 10
        }, this);
        $[6] = buttonProps;
        $[7] = children;
        $[8] = href;
        $[9] = prefetch;
        $[10] = ref;
        $[11] = t2;
    } else {
        t2 = $[11];
    }
    return t2;
});
_c1 = PrefetchButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "PrefetchButton$React.forwardRef");
__turbopack_context__.k.register(_c1, "PrefetchButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[locale]/page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript) <export default as CardContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$People$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/People.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Edit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EditNote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/EditNote.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LazyCardMedia.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/fileContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useChatPageContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeShelf$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BadgeShelf.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$NailedItWall$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/NailedItWall.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$StreakIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/StreakIndicator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$StreakShield$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/StreakShield.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ProgressRings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/ProgressRings.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$CampaignBriefing$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/CampaignBriefing.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BossBattleCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BossBattleCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$CampaignTimeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/CampaignTimeline.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SkillTreePopupButton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/SkillTreePopupButton.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationProviderWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationProviderWrapper.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PrefetchButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PrefetchButton.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function getColor(grade = 0) {
    let gradeColor = "";
    if (Math.round(grade) > 80) {
        gradeColor = "success";
    } else if (Math.round(grade) > 60) {
        gradeColor = "warning";
    } else if (Math.round(grade) > 50) {
        gradeColor = "error";
    }
    return gradeColor;
}
function getUserId(user) {
    return user?.signInUserSession?.idToken?.payload?.sub || user?.userId || user?.username;
}
function Index(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(106);
    if ($[0] !== "132dc4325b1a8544fdcd25d0a5e093c1c3d33e1a95c9ab16106697d471d3c659") {
        for(let $i = 0; $i < 106; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "132dc4325b1a8544fdcd25d0a5e093c1c3d33e1a95c9ab16106697d471d3c659";
    }
    const { user } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("pages");
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const [sections, setSections] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [];
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const [mySections, setMySections] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    const [work] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [];
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const [assignments, setAssignment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3);
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = [];
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    const [myAssignments, setMyAssignment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t4);
    let t5;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = [];
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    const [units, setUnits] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t5);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    let t6;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {};
        $[6] = t6;
    } else {
        t6 = $[6];
    }
    const [myGradeMap, setMyGradeMap] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(t6);
    let t7;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = [];
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    const [, setMyGrades] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(t7);
    let t8;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = [];
        $[8] = t8;
    } else {
        t8 = $[8];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(t8);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"])();
    const { modules: progressModules, streak } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProgress"])();
    const { campaign, activeChallenges, completedChallenges } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCampaign"])();
    const { badges: earnedBadges } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBadges"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSkillTree"])();
    let t9;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = [];
        $[9] = t9;
    } else {
        t9 = $[9];
    }
    const [nailedItBlocks, setNailedItBlocks] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(t9);
    const gradeCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const assignmentCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const sectionCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    let t10;
    if ($[10] !== mySections) {
        t10 = {
            sections: mySections
        };
        $[10] = mySections;
        $[11] = t10;
    } else {
        t10 = $[11];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPageContext"])(t10);
    let t11;
    if ($[12] !== user) {
        t11 = ({
            "Index[useEffect()]": ()=>{
                const myUserId = getUserId(user);
                if (!myUserId) {
                    return;
                }
                const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const subscription = client.models.Grade.observeQuery().subscribe({
                    next: (t12)=>{
                        let { items } = t12;
                        items = items.filter(_IndexUseEffectAnonymousItemsFilter);
                        if (items.length === gradeCountRef.current && gradeCountRef.current > 0) {
                            return;
                        }
                        gradeCountRef.current = items.length;
                        const myCompletedGrades = items.filter({
                            "Index[useEffect() > <anonymous> > items.filter()]": (g)=>g.complete === true && g.owner === myUserId
                        }["Index[useEffect() > <anonymous> > items.filter()]"]);
                        setMyGrades(myCompletedGrades);
                        const gradeMap = {};
                        for (const g_0 of myCompletedGrades){
                            if (g_0.unitID) {
                                if (!gradeMap[g_0.unitID]) {
                                    gradeMap[g_0.unitID] = [];
                                }
                                gradeMap[g_0.unitID].push(g_0);
                            }
                        }
                        setMyGradeMap(gradeMap);
                    },
                    error: _temp
                });
                return function cleanup() {
                    subscription.unsubscribe();
                };
            }
        })["Index[useEffect()]"];
        $[12] = user;
        $[13] = t11;
    } else {
        t11 = $[13];
    }
    const t12 = user?.username;
    let t13;
    if ($[14] !== t12) {
        t13 = [
            t12
        ];
        $[14] = t12;
        $[15] = t13;
    } else {
        t13 = $[15];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t11, t13);
    let t14;
    if ($[16] !== user) {
        t14 = ({
            "Index[useEffect()]": ()=>{
                const myUserId_0 = getUserId(user);
                if (!myUserId_0) {
                    return;
                }
                const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const subscription_0 = client_0.models.Assignment.observeQuery().subscribe({
                    next: (t15)=>{
                        let { items: items_0 } = t15;
                        items_0 = items_0.filter(_IndexUseEffectAnonymousItems_0Filter);
                        if (items_0.length === assignmentCountRef.current && assignmentCountRef.current > 0) {
                            return;
                        }
                        assignmentCountRef.current = items_0.length;
                        const myAssignments_0 = items_0.filter({
                            "Index[useEffect() > <anonymous> > items_0.filter()]": (a)=>a.owner === myUserId_0
                        }["Index[useEffect() > <anonymous> > items_0.filter()]"]);
                        const othersAssignments = items_0.filter({
                            "Index[useEffect() > <anonymous> > items_0.filter()]": (a_0)=>a_0.owner !== myUserId_0
                        }["Index[useEffect() > <anonymous> > items_0.filter()]"]);
                        setMyAssignment(myAssignments_0);
                        setAssignment(othersAssignments);
                    },
                    error: _temp2
                });
                return function cleanup() {
                    subscription_0.unsubscribe();
                };
            }
        })["Index[useEffect()]"];
        $[16] = user;
        $[17] = t14;
    } else {
        t14 = $[17];
    }
    const t15 = user?.username;
    let t16;
    if ($[18] !== t15) {
        t16 = [
            t15
        ];
        $[18] = t15;
        $[19] = t16;
    } else {
        t16 = $[19];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t14, t16);
    let t17;
    if ($[20] !== user) {
        t17 = ({
            "Index[useEffect()]": ()=>{
                const myUserId_1 = getUserId(user);
                if (!myUserId_1) {
                    return;
                }
                const myGroups = user?.groups || [];
                const client_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const subscription_1 = client_1.models.Section.observeQuery().subscribe({
                    next: (t18)=>{
                        const { items: items_1 } = t18;
                        const validItems = items_1.filter(_IndexUseEffectAnonymousItems_1Filter);
                        if (validItems.length === sectionCountRef.current && sectionCountRef.current > 0) {
                            return;
                        }
                        sectionCountRef.current = validItems.length;
                        const mySections_0 = validItems.filter({
                            "Index[useEffect() > <anonymous> > validItems.filter()]": (s)=>s.owner === myUserId_1
                        }["Index[useEffect() > <anonymous> > validItems.filter()]"]);
                        const othersSections = validItems.filter({
                            "Index[useEffect() > <anonymous> > validItems.filter()]": (s_0)=>s_0.owner !== myUserId_1 && s_0.learner && myGroups.includes(s_0.learner)
                        }["Index[useEffect() > <anonymous> > validItems.filter()]"]);
                        setMySections(mySections_0);
                        setSections(othersSections);
                    },
                    error: _temp3
                });
                return function cleanup() {
                    subscription_1.unsubscribe();
                };
            }
        })["Index[useEffect()]"];
        $[20] = user;
        $[21] = t17;
    } else {
        t17 = $[21];
    }
    const t18 = user?.username;
    let t19;
    if ($[22] !== t18) {
        t19 = [
            t18
        ];
        $[22] = t18;
        $[23] = t19;
    } else {
        t19 = $[23];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t17, t19);
    let t20;
    if ($[24] !== user) {
        t20 = ({
            "Index[useEffect()]": ()=>{
                const myUserId_2 = getUserId(user);
                if (!myUserId_2) {
                    return;
                }
                const client_2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const subscription_2 = client_2.models.Unit.observeQuery().subscribe({
                    next: (t21)=>{
                        const { items: items_2 } = t21;
                        const unitsById = {};
                        items_2.forEach({
                            "Index[useEffect() > <anonymous> > items_2.forEach()]": function(unit) {
                                unitsById[unit.id] = unit;
                            }
                        }["Index[useEffect() > <anonymous> > items_2.forEach()]"]);
                        setUnits(unitsById);
                    },
                    error: _temp4
                });
                return function cleanup() {
                    subscription_2.unsubscribe();
                };
            }
        })["Index[useEffect()]"];
        $[24] = user;
        $[25] = t20;
    } else {
        t20 = $[25];
    }
    const t21 = user?.username;
    let t22;
    if ($[26] !== t21) {
        t22 = [
            t21
        ];
        $[26] = t21;
        $[27] = t22;
    } else {
        t22 = $[27];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t20, t22);
    let t23;
    if ($[28] !== user) {
        t23 = ({
            "Index[useEffect()]": ()=>{
                const myUserId_3 = getUserId(user);
                if (!myUserId_3) {
                    return;
                }
                const client_3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const nailedItSub = client_3.models.NailedIt?.observeQuery?.({
                    filter: {
                        owner: {
                            eq: myUserId_3
                        }
                    }
                })?.subscribe?.({
                    next: (t24)=>{
                        const { items: items_3 } = t24;
                        const valid = items_3.filter(_IndexUseEffectAnonymousItems_3Filter);
                        setNailedItBlocks(valid.map(_IndexUseEffectAnonymousValidMap));
                    },
                    error: _temp5
                });
                return ()=>{
                    nailedItSub?.unsubscribe?.();
                };
            }
        })["Index[useEffect()]"];
        $[28] = user;
        $[29] = t23;
    } else {
        t23 = $[29];
    }
    const t24 = user?.username;
    let t25;
    if ($[30] !== t24) {
        t25 = [
            t24
        ];
        $[30] = t24;
        $[31] = t25;
    } else {
        t25 = $[31];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t23, t25);
    let t26;
    bb0: {
        let t27;
        if ($[32] !== activeChallenges) {
            t27 = activeChallenges || [];
            $[32] = activeChallenges;
            $[33] = t27;
        } else {
            t27 = $[33];
        }
        let t28;
        if ($[34] !== completedChallenges) {
            t28 = completedChallenges || [];
            $[34] = completedChallenges;
            $[35] = t28;
        } else {
            t28 = $[35];
        }
        let t29;
        if ($[36] !== t27 || $[37] !== t28) {
            t29 = [
                ...t27,
                ...t28
            ];
            $[36] = t27;
            $[37] = t28;
            $[38] = t29;
        } else {
            t29 = $[38];
        }
        const all = t29;
        if (all.length === 0) {
            let t30;
            if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
                t30 = [];
                $[39] = t30;
            } else {
                t30 = $[39];
            }
            t26 = t30;
            break bb0;
        }
        let t30;
        if ($[40] !== all) {
            t30 = all.map(_IndexAllMap);
            $[40] = all;
            $[41] = t30;
        } else {
            t30 = $[41];
        }
        t26 = t30;
    }
    const campaignChapters = t26;
    let t27;
    let t28;
    if ($[42] !== myAssignments || $[43] !== router) {
        t27 = ({
            "Index[useEffect()]": ()=>{
                if (!myAssignments?.length) {
                    return;
                }
                const toPrefetch = myAssignments.slice(0, 3);
                toPrefetch.forEach({
                    "Index[useEffect() > toPrefetch.forEach()]": (assignment)=>{
                        if (assignment.unitID) {
                            router.prefetch(`/workbook/${assignment.unitID}`);
                        }
                    }
                }["Index[useEffect() > toPrefetch.forEach()]"]);
            }
        })["Index[useEffect()]"];
        t28 = [
            myAssignments,
            router
        ];
        $[42] = myAssignments;
        $[43] = router;
        $[44] = t27;
        $[45] = t28;
    } else {
        t27 = $[44];
        t28 = $[45];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t27, t28);
    let t29;
    if ($[46] === Symbol.for("react.memo_cache_sentinel")) {
        t29 = {
            width: "100%",
            maxWidth: "80rem",
            mx: "auto",
            px: 2
        };
        $[46] = t29;
    } else {
        t29 = $[46];
    }
    let t30;
    if ($[47] === Symbol.for("react.memo_cache_sentinel")) {
        t30 = {
            py: 3
        };
        $[47] = t30;
    } else {
        t30 = $[47];
    }
    let t31;
    if ($[48] !== streak) {
        t31 = streak && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                alignItems: "center",
                gap: 2,
                mb: 2,
                flexWrap: "wrap"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$StreakIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StreakIndicator"], {
                    current: streak.current,
                    longest: streak.longest
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/page.jsx",
                    lineNumber: 513,
                    columnNumber: 8
                }, this),
                streak.freezesAvailable > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$StreakShield$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StreakShield"], {
                    freezesAvailable: streak.freezesAvailable
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/page.jsx",
                    lineNumber: 513,
                    columnNumber: 109
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 507,
            columnNumber: 21
        }, this);
        $[48] = streak;
        $[49] = t31;
    } else {
        t31 = $[49];
    }
    let t32;
    if ($[50] !== progressModules) {
        t32 = progressModules?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                mb: 3
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ProgressRings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProgressRings"], {
                modules: progressModules
            }, void 0, false, {
                fileName: "[project]/app/[locale]/page.jsx",
                lineNumber: 523,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 521,
            columnNumber: 42
        }, this);
        $[50] = progressModules;
        $[51] = t32;
    } else {
        t32 = $[51];
    }
    let t33;
    if ($[52] !== campaign) {
        t33 = campaign && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                mb: 3
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$CampaignBriefing$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CampaignBriefing"], {
                title: campaign.title,
                setting: campaign.setting,
                stakes: campaign.stakes
            }, void 0, false, {
                fileName: "[project]/app/[locale]/page.jsx",
                lineNumber: 533,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 531,
            columnNumber: 23
        }, this);
        $[52] = campaign;
        $[53] = t33;
    } else {
        t33 = $[53];
    }
    let t34;
    if ($[54] !== campaignChapters) {
        t34 = campaignChapters.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                mb: 3
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$CampaignTimeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CampaignTimeline"], {
                chapters: campaignChapters
            }, void 0, false, {
                fileName: "[project]/app/[locale]/page.jsx",
                lineNumber: 543,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 541,
            columnNumber: 42
        }, this);
        $[54] = campaignChapters;
        $[55] = t34;
    } else {
        t34 = $[55];
    }
    let t35;
    if ($[56] !== activeChallenges) {
        t35 = activeChallenges?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                mb: 3
            },
            children: activeChallenges.map(_IndexActiveChallengesMap)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 551,
            columnNumber: 43
        }, this);
        $[56] = activeChallenges;
        $[57] = t35;
    } else {
        t35 = $[57];
    }
    const t36 = mySections?.[0]?.id;
    let t37;
    if ($[58] !== t36) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SkillTreePopupButton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SkillTreePopupButton"], {
            sectionId: t36
        }, void 0, false, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 562,
            columnNumber: 11
        }, this);
        $[58] = t36;
        $[59] = t37;
    } else {
        t37 = $[59];
    }
    let t38;
    if ($[60] !== earnedBadges) {
        t38 = earnedBadges?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                mb: 3
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeShelf$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeShelf"], {
                earnedBadges: earnedBadges,
                earnedOnly: true
            }, void 0, false, {
                fileName: "[project]/app/[locale]/page.jsx",
                lineNumber: 572,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 570,
            columnNumber: 39
        }, this);
        $[60] = earnedBadges;
        $[61] = t38;
    } else {
        t38 = $[61];
    }
    let t39;
    if ($[62] !== nailedItBlocks) {
        t39 = nailedItBlocks?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                mb: 3
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$NailedItWall$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NailedItWall"], {
                blocks: nailedItBlocks
            }, void 0, false, {
                fileName: "[project]/app/[locale]/page.jsx",
                lineNumber: 582,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 580,
            columnNumber: 41
        }, this);
        $[62] = nailedItBlocks;
        $[63] = t39;
    } else {
        t39 = $[63];
    }
    let t40;
    if ($[64] === Symbol.for("react.memo_cache_sentinel")) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                my: 3
            }
        }, void 0, false, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 590,
            columnNumber: 11
        }, this);
        $[64] = t40;
    } else {
        t40 = $[64];
    }
    let t41;
    if ($[65] !== t31 || $[66] !== t32 || $[67] !== t33 || $[68] !== t34 || $[69] !== t35 || $[70] !== t37 || $[71] !== t38 || $[72] !== t39) {
        t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t30,
            children: [
                t31,
                t32,
                t33,
                t34,
                t35,
                t37,
                t38,
                t39,
                t40
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 599,
            columnNumber: 11
        }, this);
        $[65] = t31;
        $[66] = t32;
        $[67] = t33;
        $[68] = t34;
        $[69] = t35;
        $[70] = t37;
        $[71] = t38;
        $[72] = t39;
        $[73] = t41;
    } else {
        t41 = $[73];
    }
    let t42;
    if ($[74] !== assignments || $[75] !== myGradeMap || $[76] !== t || $[77] !== units) {
        t42 = assignments?.length > 0 && units && Object.values(myGradeMap).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            "data-tour": "my-grades",
            style: {
                padding: "1rem",
                marginBottom: "3rem",
                margin: "1rem auto",
                maxWidth: "80rem"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "h3",
                    component: "div",
                    sx: {
                        flexGrow: 1,
                        padding: "1rem",
                        margin: "1rem auto"
                    },
                    children: t("index.completedAssignments")
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/page.jsx",
                    lineNumber: 619,
                    columnNumber: 8
                }, this),
                assignments?.map({
                    "Index[(anonymous)()]": function(assignment_0, index) {
                        const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
                        const localTime = new Date(assignment_0.dueDate).toLocaleString(undefined, {
                            timeZone
                        });
                        const itemPrimary = `${localTime} - ${units[assignment_0.unitID]?.name}`;
                        const itemSecondary = units[assignment_0.unitID]?.description;
                        units[assignment_0.unitID]?.featuredImage;
                        units[assignment_0.unitID]?.identityId;
                        const workbookUrl = `/workbook/${assignment_0.unitID}`;
                        assignment_0?.unitID;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                            sx: {
                                mb: 1,
                                mx: 1
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                                sx: {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 2,
                                    py: 1,
                                    "&:last-child": {
                                        pb: 1
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                        sx: {
                                            flexGrow: 1
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                variant: "body1",
                                                children: itemPrimary
                                            }, void 0, false, {
                                                fileName: "[project]/app/[locale]/page.jsx",
                                                lineNumber: 648,
                                                columnNumber: 18
                                            }, this),
                                            itemSecondary && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                variant: "body2",
                                                color: "text.secondary",
                                                children: itemSecondary
                                            }, void 0, false, {
                                                fileName: "[project]/app/[locale]/page.jsx",
                                                lineNumber: 648,
                                                columnNumber: 90
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/[locale]/page.jsx",
                                        lineNumber: 646,
                                        columnNumber: 16
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PrefetchButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PrefetchButton"], {
                                        href: workbookUrl,
                                        size: "small",
                                        variant: "outlined",
                                        children: "Review"
                                    }, void 0, false, {
                                        fileName: "[project]/app/[locale]/page.jsx",
                                        lineNumber: 648,
                                        columnNumber: 176
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/[locale]/page.jsx",
                                lineNumber: 638,
                                columnNumber: 14
                            }, this)
                        }, assignment_0.id || index, false, {
                            fileName: "[project]/app/[locale]/page.jsx",
                            lineNumber: 635,
                            columnNumber: 18
                        }, this);
                    }
                }["Index[(anonymous)()]"])
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 614,
            columnNumber: 87
        }, this);
        $[74] = assignments;
        $[75] = myGradeMap;
        $[76] = t;
        $[77] = units;
        $[78] = t42;
    } else {
        t42 = $[78];
    }
    let t43;
    if ($[79] !== myAssignments || $[80] !== t || $[81] !== units || $[82] !== work) {
        t43 = myAssignments?.length > 0 && units && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            style: {
                padding: "1rem",
                marginBottom: "3rem",
                margin: "1rem auto",
                maxWidth: "80rem"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "h3",
                    component: "div",
                    sx: {
                        flexGrow: 1,
                        padding: "1rem",
                        margin: "1rem auto"
                    },
                    children: t("index.myAssignments")
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/page.jsx",
                    lineNumber: 666,
                    columnNumber: 8
                }, this),
                myAssignments?.map({
                    "Index[(anonymous)()]": function(assignment_1, index_0) {
                        const timeZone_0 = Intl.DateTimeFormat().resolvedOptions().timeZone;
                        const localTime_0 = new Date(assignment_1.dueDate).toLocaleString(undefined, {
                            timeZone: timeZone_0
                        });
                        const itemPrimary_0 = `${localTime_0} - ${units[assignment_1.unitID]?.name}`;
                        const itemSecondary_0 = units[assignment_1.unitID]?.description;
                        const featuredImage_0 = units[assignment_1.unitID]?.featuredImage;
                        const identityId_0 = units[assignment_1.unitID]?.identityId;
                        const workbookUrl_0 = `/workbook/${assignment_1.unitID}`;
                        const unitUrl_0 = `/unit/${assignment_1.unitID}`;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                                elevation: 2,
                                sx: {
                                    display: "flex",
                                    margin: "1rem auto",
                                    width: "90vw",
                                    maxWidth: "80rem",
                                    height: 180,
                                    borderRadius: 2,
                                    borderLeft: "4px solid",
                                    borderLeftColor: "text.primary",
                                    transition: "all 0.3s ease-in-out",
                                    overflow: "hidden",
                                    "&:hover": {
                                        elevation: 6,
                                        transform: "translateY(-2px)",
                                        boxShadow: "0 8px 24px rgba(0,0,0,0.12)"
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                        sx: {
                                            display: "flex",
                                            flexDirection: "column",
                                            flexGrow: "1",
                                            p: 0.5
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                                                sx: {
                                                    flex: "1 0 auto",
                                                    pb: 1
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        component: "div",
                                                        variant: "h5",
                                                        sx: {
                                                            fontWeight: 600,
                                                            mb: 0.5
                                                        },
                                                        children: itemPrimary_0
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/[locale]/page.jsx",
                                                        lineNumber: 706,
                                                        columnNumber: 20
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "body1",
                                                        color: "text.secondary",
                                                        component: "div",
                                                        sx: {
                                                            lineHeight: 1.6
                                                        },
                                                        children: itemSecondary_0
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/[locale]/page.jsx",
                                                        lineNumber: 709,
                                                        columnNumber: 50
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/[locale]/page.jsx",
                                                lineNumber: 703,
                                                columnNumber: 18
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                sx: {
                                                    display: "flex",
                                                    alignItems: "center",
                                                    pl: 2,
                                                    pb: 1.5
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PrefetchButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PrefetchButton"], {
                                                        variant: "outlined",
                                                        href: workbookUrl_0,
                                                        disabled: work,
                                                        startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EditNote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                            fileName: "[project]/app/[locale]/page.jsx",
                                                            lineNumber: 716,
                                                            columnNumber: 103
                                                        }, this),
                                                        sx: {
                                                            textTransform: "none",
                                                            fontWeight: 600,
                                                            px: 3,
                                                            py: 1,
                                                            mr: 1,
                                                            borderRadius: 2,
                                                            boxShadow: 2,
                                                            color: "text.primary",
                                                            borderColor: "text.primary",
                                                            "&:hover": {
                                                                boxShadow: 4,
                                                                borderColor: "text.primary",
                                                                backgroundColor: "action.hover"
                                                            }
                                                        },
                                                        children: t("index.viewWorkbook")
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/[locale]/page.jsx",
                                                        lineNumber: 716,
                                                        columnNumber: 20
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PrefetchButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PrefetchButton"], {
                                                        variant: "outlined",
                                                        href: unitUrl_0,
                                                        disabled: work,
                                                        startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                            fileName: "[project]/app/[locale]/page.jsx",
                                                            lineNumber: 731,
                                                            columnNumber: 143
                                                        }, this),
                                                        sx: {
                                                            textTransform: "none",
                                                            fontWeight: 600,
                                                            px: 3,
                                                            py: 1,
                                                            borderRadius: 2,
                                                            boxShadow: 2,
                                                            color: "text.primary",
                                                            borderColor: "text.primary",
                                                            "&:hover": {
                                                                boxShadow: 4,
                                                                borderColor: "text.primary",
                                                                backgroundColor: "action.hover"
                                                            }
                                                        },
                                                        children: t("index.editUnit")
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/[locale]/page.jsx",
                                                        lineNumber: 731,
                                                        columnNumber: 64
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/[locale]/page.jsx",
                                                lineNumber: 711,
                                                columnNumber: 66
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/[locale]/page.jsx",
                                        lineNumber: 698,
                                        columnNumber: 16
                                    }, this),
                                    featuredImage_0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        s3Key: featuredImage_0,
                                        identityId: identityId_0
                                    }, void 0, false, {
                                        fileName: "[project]/app/[locale]/page.jsx",
                                        lineNumber: 745,
                                        columnNumber: 92
                                    }, this)
                                ]
                            }, index_0, true, {
                                fileName: "[project]/app/[locale]/page.jsx",
                                lineNumber: 682,
                                columnNumber: 20
                            }, this)
                        }, void 0, false);
                    }
                }["Index[(anonymous)()]"])
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 661,
            columnNumber: 49
        }, this);
        $[79] = myAssignments;
        $[80] = t;
        $[81] = units;
        $[82] = work;
        $[83] = t43;
    } else {
        t43 = $[83];
    }
    let t44;
    if ($[84] !== mySections?.length || $[85] !== sections?.length || $[86] !== t || $[87] !== work) {
        t44 = sections?.length == 0 && mySections?.length == 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
            elevation: 3,
            sx: {
                display: "flex",
                margin: "3rem auto",
                width: "fit-content",
                maxWidth: "500px",
                minHeight: "300px",
                borderRadius: 3
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center",
                    flexGrow: "1",
                    p: 4
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                    sx: {
                        flex: "1 1 auto",
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        alignItems: "center",
                        textAlign: "center"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            component: "div",
                            variant: "h5",
                            sx: {
                                mb: 3
                            },
                            children: t("index.noSectionsYet")
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/page.jsx",
                            lineNumber: 779,
                            columnNumber: 12
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                flexDirection: "column",
                                gap: 2,
                                width: "100%"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PrefetchButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PrefetchButton"], {
                                    variant: "outlined",
                                    color: "primary",
                                    href: "sections",
                                    disabled: work,
                                    sx: {
                                        textTransform: "none",
                                        fontWeight: 600,
                                        px: 3,
                                        py: 1,
                                        borderRadius: 2
                                    },
                                    children: t("index.joinSection")
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/page.jsx",
                                    lineNumber: 786,
                                    columnNumber: 14
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PrefetchButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PrefetchButton"], {
                                    variant: "outlined",
                                    color: "primary",
                                    href: "sections",
                                    disabled: work,
                                    sx: {
                                        textTransform: "none",
                                        fontWeight: 600,
                                        px: 3,
                                        py: 1,
                                        borderRadius: 2
                                    },
                                    children: t("index.createNewSection")
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/page.jsx",
                                    lineNumber: 792,
                                    columnNumber: 57
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[locale]/page.jsx",
                            lineNumber: 781,
                            columnNumber: 53
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/[locale]/page.jsx",
                    lineNumber: 772,
                    columnNumber: 10
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/[locale]/page.jsx",
                lineNumber: 765,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 758,
            columnNumber: 63
        }, this);
        $[84] = mySections?.length;
        $[85] = sections?.length;
        $[86] = t;
        $[87] = work;
        $[88] = t44;
    } else {
        t44 = $[88];
    }
    let t45;
    if ($[89] !== mySections || $[90] !== t || $[91] !== work) {
        t45 = mySections?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            style: {
                padding: "1rem",
                marginBottom: "3rem",
                margin: "1rem auto",
                maxWidth: "80rem"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "h3",
                    component: "div",
                    sx: {
                        flexGrow: 1,
                        padding: "1rem",
                        margin: "1rem auto"
                    },
                    children: t("index.mySections")
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/page.jsx",
                    lineNumber: 814,
                    columnNumber: 8
                }, this),
                mySections?.map({
                    "Index[(anonymous)()]": function(section, index_1) {
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                            elevation: 2,
                            sx: {
                                display: "flex",
                                margin: "1rem auto",
                                width: "\u0192",
                                maxWidth: "80rem",
                                height: 180,
                                borderRadius: 2,
                                borderLeft: "4px solid",
                                borderLeftColor: "text.primary",
                                transition: "all 0.3s ease-in-out",
                                overflow: "hidden",
                                "&:hover": {
                                    elevation: 6,
                                    transform: "translateY(-2px)",
                                    boxShadow: "0 8px 24px rgba(0,0,0,0.12)"
                                }
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        display: "flex",
                                        flexDirection: "column",
                                        flexGrow: "1",
                                        p: 0.5
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                                            sx: {
                                                flex: "1 0 auto",
                                                pb: 1
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    component: "div",
                                                    variant: "h5",
                                                    sx: {
                                                        fontWeight: 600,
                                                        mb: 0.5
                                                    },
                                                    children: section?.name || t("index.untitledSection")
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/page.jsx",
                                                    lineNumber: 844,
                                                    columnNumber: 18
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    variant: "body1",
                                                    color: "text.secondary",
                                                    component: "div",
                                                    sx: {
                                                        lineHeight: 1.6
                                                    },
                                                    children: section?.description || t("index.noDescription")
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/page.jsx",
                                                    lineNumber: 847,
                                                    columnNumber: 78
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/[locale]/page.jsx",
                                            lineNumber: 841,
                                            columnNumber: 16
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            sx: {
                                                display: "flex",
                                                alignItems: "center",
                                                pl: 2,
                                                pb: 1.5
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PrefetchButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PrefetchButton"], {
                                                variant: "outlined",
                                                href: `section/${section.id}`,
                                                disabled: work,
                                                startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$People$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                    fileName: "[project]/app/[locale]/page.jsx",
                                                    lineNumber: 854,
                                                    columnNumber: 111
                                                }, this),
                                                sx: {
                                                    textTransform: "none",
                                                    fontWeight: 600,
                                                    px: 3,
                                                    py: 1,
                                                    borderRadius: 2,
                                                    boxShadow: 2,
                                                    color: "text.primary",
                                                    borderColor: "text.primary",
                                                    "&:hover": {
                                                        boxShadow: 4,
                                                        borderColor: "text.primary",
                                                        backgroundColor: "action.hover"
                                                    }
                                                },
                                                children: t("index.viewSection")
                                            }, void 0, false, {
                                                fileName: "[project]/app/[locale]/page.jsx",
                                                lineNumber: 854,
                                                columnNumber: 18
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/[locale]/page.jsx",
                                            lineNumber: 849,
                                            columnNumber: 97
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[locale]/page.jsx",
                                    lineNumber: 836,
                                    columnNumber: 14
                                }, this),
                                section?.featuredImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    s3Key: section.featuredImage,
                                    identityId: section.identityId
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/page.jsx",
                                    lineNumber: 868,
                                    columnNumber: 100
                                }, this)
                            ]
                        }, index_1, true, {
                            fileName: "[project]/app/[locale]/page.jsx",
                            lineNumber: 820,
                            columnNumber: 18
                        }, this);
                    }
                }["Index[(anonymous)()]"])
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 809,
            columnNumber: 37
        }, this);
        $[89] = mySections;
        $[90] = t;
        $[91] = work;
        $[92] = t45;
    } else {
        t45 = $[92];
    }
    let t46;
    if ($[93] !== sections || $[94] !== t || $[95] !== work) {
        t46 = sections?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            style: {
                padding: "1rem",
                marginBottom: "3rem",
                margin: "1rem auto",
                maxWidth: "80rem"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "h3",
                    component: "div",
                    sx: {
                        flexGrow: 1,
                        padding: "1rem",
                        margin: "1rem auto"
                    },
                    children: t("index.sections")
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/page.jsx",
                    lineNumber: 885,
                    columnNumber: 8
                }, this),
                sections?.map({
                    "Index[(anonymous)()]": function(section_0, index_2) {
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                            elevation: 2,
                            sx: {
                                display: "flex",
                                margin: "1rem auto",
                                width: "90vw",
                                maxWidth: "80rem",
                                height: 180,
                                borderRadius: 2,
                                borderLeft: "4px solid",
                                borderLeftColor: "text.primary",
                                transition: "all 0.3s ease-in-out",
                                overflow: "hidden",
                                "&:hover": {
                                    elevation: 6,
                                    transform: "translateY(-2px)",
                                    boxShadow: "0 8px 24px rgba(0,0,0,0.12)"
                                }
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        display: "flex",
                                        flexDirection: "column",
                                        flexGrow: "1",
                                        p: 0.5
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                                            sx: {
                                                flex: "1 0 auto",
                                                pb: 1
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    component: "div",
                                                    variant: "h5",
                                                    sx: {
                                                        fontWeight: 600,
                                                        mb: 0.5
                                                    },
                                                    children: section_0?.name || t("index.untitledSection")
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/page.jsx",
                                                    lineNumber: 915,
                                                    columnNumber: 18
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    variant: "body1",
                                                    color: "text.secondary",
                                                    component: "div",
                                                    sx: {
                                                        lineHeight: 1.6
                                                    },
                                                    children: section_0?.description || t("index.noDescription")
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/page.jsx",
                                                    lineNumber: 918,
                                                    columnNumber: 80
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/[locale]/page.jsx",
                                            lineNumber: 912,
                                            columnNumber: 16
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            sx: {
                                                display: "flex",
                                                alignItems: "center",
                                                pl: 2,
                                                pb: 1.5
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PrefetchButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PrefetchButton"], {
                                                variant: "outlined",
                                                href: `section/${section_0.id}`,
                                                disabled: work,
                                                startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EditNote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                    fileName: "[project]/app/[locale]/page.jsx",
                                                    lineNumber: 925,
                                                    columnNumber: 113
                                                }, this),
                                                sx: {
                                                    textTransform: "none",
                                                    fontWeight: 600,
                                                    px: 3,
                                                    py: 1,
                                                    borderRadius: 2,
                                                    boxShadow: 2,
                                                    color: "text.primary",
                                                    borderColor: "text.primary",
                                                    "&:hover": {
                                                        boxShadow: 4,
                                                        borderColor: "text.primary",
                                                        backgroundColor: "action.hover"
                                                    }
                                                },
                                                children: t("index.viewSection")
                                            }, void 0, false, {
                                                fileName: "[project]/app/[locale]/page.jsx",
                                                lineNumber: 925,
                                                columnNumber: 18
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/[locale]/page.jsx",
                                            lineNumber: 920,
                                            columnNumber: 99
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[locale]/page.jsx",
                                    lineNumber: 907,
                                    columnNumber: 14
                                }, this),
                                section_0?.featuredImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    s3Key: section_0.featuredImage,
                                    identityId: section_0.identityId
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/page.jsx",
                                    lineNumber: 939,
                                    columnNumber: 102
                                }, this)
                            ]
                        }, index_2, true, {
                            fileName: "[project]/app/[locale]/page.jsx",
                            lineNumber: 891,
                            columnNumber: 18
                        }, this);
                    }
                }["Index[(anonymous)()]"])
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 880,
            columnNumber: 35
        }, this);
        $[93] = sections;
        $[94] = t;
        $[95] = work;
        $[96] = t46;
    } else {
        t46 = $[96];
    }
    let t47;
    if ($[97] !== t42 || $[98] !== t43 || $[99] !== t44 || $[100] !== t45 || $[101] !== t46) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: [
                t42,
                t43,
                t44,
                t45,
                t46
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 951,
            columnNumber: 11
        }, this);
        $[97] = t42;
        $[98] = t43;
        $[99] = t44;
        $[100] = t45;
        $[101] = t46;
        $[102] = t47;
    } else {
        t47 = $[102];
    }
    let t48;
    if ($[103] !== t41 || $[104] !== t47) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t29,
                children: [
                    t41,
                    t47
                ]
            }, void 0, true, {
                fileName: "[project]/app/[locale]/page.jsx",
                lineNumber: 963,
                columnNumber: 13
            }, this)
        }, void 0, false);
        $[103] = t41;
        $[104] = t47;
        $[105] = t48;
    } else {
        t48 = $[105];
    }
    return t48;
}
_s(Index, "5GxlGPmLifzbDkYDQOqpdaKBRCE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProgress"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCampaign"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBadges"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSkillTree"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPageContext"]
    ];
});
_c = Index;
function _IndexActiveChallengesMap(challenge) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            mb: 2
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BossBattleCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BossBattleCard"], {
            title: challenge.title,
            narrative: challenge.setting,
            totalHP: challenge.targetXP || 0,
            totalDamage: challenge.currentXP || 0,
            deadline: challenge.deadline,
            active: challenge.active,
            bonusMultiplier: challenge.bonusMultiplier,
            phases: [],
            contributors: (challenge.contributions || []).map(_IndexActiveChallengesMapAnonymous)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 975,
            columnNumber: 6
        }, this)
    }, challenge.id, false, {
        fileName: "[project]/app/[locale]/page.jsx",
        lineNumber: 973,
        columnNumber: 10
    }, this);
}
function _IndexActiveChallengesMapAnonymous(c_0) {
    return {
        userId: c_0.studentId,
        displayName: c_0.studentId,
        xpContributed: c_0.xpContributed
    };
}
function _IndexAllMap(c, i_0) {
    return {
        id: c.id,
        title: c.title || `Challenge ${i_0 + 1}`,
        setting: c.setting,
        stakes: c.stakes,
        targetXP: c.targetXP || 0,
        currentXP: c.currentXP || 0,
        active: c.active ?? false,
        chapterOrder: c.chapterOrder ?? i_0
    };
}
function _temp5(err) {
    return console.warn("[Index] NailedIt subscription error:", err);
}
function _IndexUseEffectAnonymousValidMap(n) {
    return {
        id: n.id,
        question: n.question || "",
        nailedItReason: n.nailedItReason || "",
        homeworkTitle: n.homeworkTitle || "",
        createdAt: n.createdAt || new Date().toISOString()
    };
}
function _IndexUseEffectAnonymousItems_3Filter(i) {
    return i != null && i.id != null;
}
function _temp4(error_2) {
    console.error("[Index] Unit subscription error:", error_2);
}
function _temp3(error_1) {
    console.error("[Index] Section subscription error:", error_1);
}
function _IndexUseEffectAnonymousItems_1Filter(item_1) {
    return item_1 != null && item_1.id != null;
}
function _temp2(error_0) {
    console.error("[Index] Assignment subscription error:", error_0);
}
function _IndexUseEffectAnonymousItems_0Filter(item_0) {
    return item_0 != null && item_0.id != null;
}
function _temp(error) {
    console.error("[Index] Grade subscription error:", error);
}
function _IndexUseEffectAnonymousItemsFilter(item) {
    return item != null && item.id != null;
}
function WrappedPage(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "132dc4325b1a8544fdcd25d0a5e093c1c3d33e1a95c9ab16106697d471d3c659") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "132dc4325b1a8544fdcd25d0a5e093c1c3d33e1a95c9ab16106697d471d3c659";
    }
    let args;
    let signOut;
    let user;
    if ($[1] !== t0) {
        ({ signOut, user, ...args } = t0);
        $[1] = t0;
        $[2] = args;
        $[3] = signOut;
        $[4] = user;
    } else {
        args = $[2];
        signOut = $[3];
        user = $[4];
    }
    let t1;
    if ($[5] !== args || $[6] !== signOut || $[7] !== user) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationProviderWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationProviderWrapper"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilesProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Index, {
                    signOut: signOut,
                    user: user,
                    ...args
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/page.jsx",
                    lineNumber: 1060,
                    columnNumber: 54
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/[locale]/page.jsx",
                lineNumber: 1060,
                columnNumber: 39
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/page.jsx",
            lineNumber: 1060,
            columnNumber: 10
        }, this);
        $[5] = args;
        $[6] = signOut;
        $[7] = user;
        $[8] = t1;
    } else {
        t1 = $[8];
    }
    return t1;
}
_c1 = WrappedPage;
const __TURBOPACK__default__export__ = WrappedPage;
var _c, _c1;
__turbopack_context__.k.register(_c, "Index");
__turbopack_context__.k.register(_c1, "WrappedPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_0ea_hop._.js.map