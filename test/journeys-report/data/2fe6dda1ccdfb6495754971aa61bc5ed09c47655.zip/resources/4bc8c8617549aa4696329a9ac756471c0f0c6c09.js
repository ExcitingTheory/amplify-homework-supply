(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/AIAgentConfig.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AIAgentConfig",
    ()=>AIAgentConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Slider/Slider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Select/Select.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControl/FormControl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputLabel/InputLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Switch/Switch.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Accordion/Accordion.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AccordionSummary/AccordionSummary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AccordionDetails/AccordionDetails.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandMore.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const AVAILABLE_MODELS = [
    {
        id: "gpt-4o",
        label: "GPT-4o",
        tier: "premium"
    },
    {
        id: "gpt-4o-mini",
        label: "GPT-4o Mini",
        tier: "standard"
    },
    {
        id: "gpt-4.1",
        label: "GPT-4.1",
        tier: "premium"
    },
    {
        id: "gpt-4.1-mini",
        label: "GPT-4.1 Mini",
        tier: "standard"
    },
    {
        id: "gpt-4.1-nano",
        label: "GPT-4.1 Nano",
        tier: "budget"
    }
];
function AIAgentConfig(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(197);
    if ($[0] !== "55683fc9af94ba7548ede537fb41865b69c389824395de69e64c45bf1eaca12c") {
        for(let $i = 0; $i < 197; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "55683fc9af94ba7548ede537fb41865b69c389824395de69e64c45bf1eaca12c";
    }
    const { values, onChange, onSave, saving, mode } = t0;
    let t1;
    if ($[1] !== onChange || $[2] !== values) {
        t1 = ({
            "AIAgentConfig[update]": (key, value)=>{
                onChange({
                    ...values,
                    [key]: value
                });
            }
        })["AIAgentConfig[update]"];
        $[1] = onChange;
        $[2] = values;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const update = t1;
    let t2;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            mt: 2
        };
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h6",
            gutterBottom: true,
            children: "AI Agent Configuration"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 150,
            columnNumber: 10
        }, this);
        $[4] = t2;
        $[5] = t3;
    } else {
        t2 = $[4];
        t3 = $[5];
    }
    let t4;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 159,
                columnNumber: 40
            }, this),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "subtitle1",
                children: "Model Selection"
            }, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 159,
                columnNumber: 60
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 159,
            columnNumber: 10
        }, this);
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== mode || $[8] !== update || $[9] !== values.defaultAIModel) {
        t5 = mode === "platform" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fullWidth: true,
            size: "small",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: "Default Model"
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 166,
                    columnNumber: 76
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    label: "Default Model",
                    value: values.defaultAIModel || "gpt-4o",
                    onChange: {
                        "AIAgentConfig[<Select>.onChange]": (e)=>update("defaultAIModel", e.target.value)
                    }["AIAgentConfig[<Select>.onChange]"],
                    children: AVAILABLE_MODELS.map(_AIAgentConfigAVAILABLE_MODELSMap)
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 166,
                    columnNumber: 114
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 166,
            columnNumber: 33
        }, this);
        $[7] = mode;
        $[8] = update;
        $[9] = values.defaultAIModel;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    let t6;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: "Kai Model"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 178,
            columnNumber: 10
        }, this);
        $[11] = t6;
    } else {
        t6 = $[11];
    }
    const t7 = values.kaiModel || "";
    let t8;
    if ($[12] !== update) {
        t8 = ({
            "AIAgentConfig[<Select>.onChange]": (e_0)=>update("kaiModel", e_0.target.value || null)
        })["AIAgentConfig[<Select>.onChange]"];
        $[12] = update;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    const t9 = mode === "section" ? "Use platform default" : "Use default model";
    let t10;
    if ($[14] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            value: "",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("em", {
                children: t9
            }, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 197,
                columnNumber: 30
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 197,
            columnNumber: 11
        }, this);
        $[14] = t9;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    let t11;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = AVAILABLE_MODELS.map(_AIAgentConfigAVAILABLE_MODELSMap2);
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    let t12;
    if ($[17] !== t10 || $[18] !== t7 || $[19] !== t8) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fullWidth: true,
            size: "small",
            children: [
                t6,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    label: "Kai Model",
                    value: t7,
                    onChange: t8,
                    displayEmpty: true,
                    children: [
                        t10,
                        t11
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 212,
                    columnNumber: 58
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 212,
            columnNumber: 11
        }, this);
        $[17] = t10;
        $[18] = t7;
        $[19] = t8;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: "Sage Model"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 222,
            columnNumber: 11
        }, this);
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    const t14 = values.sageModel || "";
    let t15;
    if ($[22] !== update) {
        t15 = ({
            "AIAgentConfig[<Select>.onChange]": (e_1)=>update("sageModel", e_1.target.value || null)
        })["AIAgentConfig[<Select>.onChange]"];
        $[22] = update;
        $[23] = t15;
    } else {
        t15 = $[23];
    }
    const t16 = mode === "section" ? "Use platform default" : "Use default model";
    let t17;
    if ($[24] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            value: "",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("em", {
                children: t16
            }, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 241,
                columnNumber: 30
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 241,
            columnNumber: 11
        }, this);
        $[24] = t16;
        $[25] = t17;
    } else {
        t17 = $[25];
    }
    let t18;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = AVAILABLE_MODELS.map(_AIAgentConfigAVAILABLE_MODELSMap3);
        $[26] = t18;
    } else {
        t18 = $[26];
    }
    let t19;
    if ($[27] !== t14 || $[28] !== t15 || $[29] !== t17) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fullWidth: true,
            size: "small",
            children: [
                t13,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    label: "Sage Model",
                    value: t14,
                    onChange: t15,
                    displayEmpty: true,
                    children: [
                        t17,
                        t18
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 256,
                    columnNumber: 59
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 256,
            columnNumber: 11
        }, this);
        $[27] = t14;
        $[28] = t15;
        $[29] = t17;
        $[30] = t19;
    } else {
        t19 = $[30];
    }
    let t20;
    if ($[31] !== t12 || $[32] !== t19 || $[33] !== t5) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            defaultExpanded: true,
            children: [
                t4,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        spacing: 2,
                        children: [
                            t5,
                            t12,
                            t19
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/AIAgentConfig.tsx",
                        lineNumber: 266,
                        columnNumber: 67
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 266,
                    columnNumber: 49
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 266,
            columnNumber: 11
        }, this);
        $[31] = t12;
        $[32] = t19;
        $[33] = t5;
        $[34] = t20;
    } else {
        t20 = $[34];
    }
    let t21;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 276,
                columnNumber: 41
            }, this),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "subtitle1",
                children: "Behavior Tuning"
            }, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 276,
                columnNumber: 61
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 276,
            columnNumber: 11
        }, this);
        $[35] = t21;
    } else {
        t21 = $[35];
    }
    const t22 = values.kaiTemperature ?? 0.7;
    let t23;
    if ($[36] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            gutterBottom: true,
            children: [
                "Kai Temperature: ",
                t22
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 284,
            columnNumber: 11
        }, this);
        $[36] = t22;
        $[37] = t23;
    } else {
        t23 = $[37];
    }
    const t24 = values.kaiTemperature ?? 0.7;
    let t25;
    if ($[38] !== update) {
        t25 = ({
            "AIAgentConfig[<Slider>.onChange]": (_, v)=>update("kaiTemperature", v)
        })["AIAgentConfig[<Slider>.onChange]"];
        $[38] = update;
        $[39] = t25;
    } else {
        t25 = $[39];
    }
    let t26;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t26 = [
            {
                value: 0,
                label: "0"
            },
            {
                value: 0.7,
                label: "0.7"
            },
            {
                value: 1.5,
                label: "1.5"
            }
        ];
        $[40] = t26;
    } else {
        t26 = $[40];
    }
    let t27;
    if ($[41] !== t24 || $[42] !== t25) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            value: t24,
            onChange: t25,
            min: 0,
            max: 1.5,
            step: 0.1,
            marks: t26,
            valueLabelDisplay: "auto"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 319,
            columnNumber: 11
        }, this);
        $[41] = t24;
        $[42] = t25;
        $[43] = t27;
    } else {
        t27 = $[43];
    }
    let t28;
    if ($[44] !== t23 || $[45] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t23,
                t27
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 328,
            columnNumber: 11
        }, this);
        $[44] = t23;
        $[45] = t27;
        $[46] = t28;
    } else {
        t28 = $[46];
    }
    const t29 = values.sageTemperature ?? 0.7;
    let t30;
    if ($[47] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            gutterBottom: true,
            children: [
                "Sage Temperature: ",
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 338,
            columnNumber: 11
        }, this);
        $[47] = t29;
        $[48] = t30;
    } else {
        t30 = $[48];
    }
    const t31 = values.sageTemperature ?? 0.7;
    let t32;
    if ($[49] !== update) {
        t32 = ({
            "AIAgentConfig[<Slider>.onChange]": (__0, v_0)=>update("sageTemperature", v_0)
        })["AIAgentConfig[<Slider>.onChange]"];
        $[49] = update;
        $[50] = t32;
    } else {
        t32 = $[50];
    }
    let t33;
    if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
        t33 = [
            {
                value: 0,
                label: "0"
            },
            {
                value: 0.7,
                label: "0.7"
            },
            {
                value: 1.5,
                label: "1.5"
            }
        ];
        $[51] = t33;
    } else {
        t33 = $[51];
    }
    let t34;
    if ($[52] !== t31 || $[53] !== t32) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            value: t31,
            onChange: t32,
            min: 0,
            max: 1.5,
            step: 0.1,
            marks: t33,
            valueLabelDisplay: "auto"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 373,
            columnNumber: 11
        }, this);
        $[52] = t31;
        $[53] = t32;
        $[54] = t34;
    } else {
        t34 = $[54];
    }
    let t35;
    if ($[55] !== t30 || $[56] !== t34) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t30,
                t34
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 382,
            columnNumber: 11
        }, this);
        $[55] = t30;
        $[56] = t34;
        $[57] = t35;
    } else {
        t35 = $[57];
    }
    const t36 = values.kaiMaxTokens ?? 2000;
    let t37;
    if ($[58] !== update) {
        t37 = ({
            "AIAgentConfig[<TextField>.onChange]": (e_2)=>update("kaiMaxTokens", e_2.target.value ? parseInt(e_2.target.value, 10) : null)
        })["AIAgentConfig[<TextField>.onChange]"];
        $[58] = update;
        $[59] = t37;
    } else {
        t37 = $[59];
    }
    let t38;
    if ($[60] === Symbol.for("react.memo_cache_sentinel")) {
        t38 = {
            htmlInput: {
                min: 100,
                max: 8000
            }
        };
        $[60] = t38;
    } else {
        t38 = $[60];
    }
    let t39;
    if ($[61] !== t36 || $[62] !== t37) {
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Kai Max Tokens",
            type: "number",
            size: "small",
            value: t36,
            onChange: t37,
            slotProps: t38
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 414,
            columnNumber: 11
        }, this);
        $[61] = t36;
        $[62] = t37;
        $[63] = t39;
    } else {
        t39 = $[63];
    }
    const t40 = values.sageMaxTokens ?? 4000;
    let t41;
    if ($[64] !== update) {
        t41 = ({
            "AIAgentConfig[<TextField>.onChange]": (e_3)=>update("sageMaxTokens", e_3.target.value ? parseInt(e_3.target.value, 10) : null)
        })["AIAgentConfig[<TextField>.onChange]"];
        $[64] = update;
        $[65] = t41;
    } else {
        t41 = $[65];
    }
    let t42;
    if ($[66] === Symbol.for("react.memo_cache_sentinel")) {
        t42 = {
            htmlInput: {
                min: 100,
                max: 8000
            }
        };
        $[66] = t42;
    } else {
        t42 = $[66];
    }
    let t43;
    if ($[67] !== t40 || $[68] !== t41) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Sage Max Tokens",
            type: "number",
            size: "small",
            value: t40,
            onChange: t41,
            slotProps: t42
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 446,
            columnNumber: 11
        }, this);
        $[67] = t40;
        $[68] = t41;
        $[69] = t43;
    } else {
        t43 = $[69];
    }
    const t44 = values.agentMaxSteps ?? 5;
    let t45;
    if ($[70] !== update) {
        t45 = ({
            "AIAgentConfig[<TextField>.onChange]": (e_4)=>update("agentMaxSteps", e_4.target.value ? parseInt(e_4.target.value, 10) : null)
        })["AIAgentConfig[<TextField>.onChange]"];
        $[70] = update;
        $[71] = t45;
    } else {
        t45 = $[71];
    }
    let t46;
    if ($[72] === Symbol.for("react.memo_cache_sentinel")) {
        t46 = {
            htmlInput: {
                min: 1,
                max: 10
            }
        };
        $[72] = t46;
    } else {
        t46 = $[72];
    }
    let t47;
    if ($[73] !== t44 || $[74] !== t45) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Max Agent Steps",
            type: "number",
            size: "small",
            value: t44,
            onChange: t45,
            slotProps: t46,
            helperText: "Maximum tool-calling rounds per conversation turn"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 478,
            columnNumber: 11
        }, this);
        $[73] = t44;
        $[74] = t45;
        $[75] = t47;
    } else {
        t47 = $[75];
    }
    let t48;
    if ($[76] !== t28 || $[77] !== t35 || $[78] !== t39 || $[79] !== t43 || $[80] !== t47) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t21,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        spacing: 3,
                        children: [
                            t28,
                            t35,
                            t39,
                            t43,
                            t47
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/AIAgentConfig.tsx",
                        lineNumber: 487,
                        columnNumber: 45
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 487,
                    columnNumber: 27
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 487,
            columnNumber: 11
        }, this);
        $[76] = t28;
        $[77] = t35;
        $[78] = t39;
        $[79] = t43;
        $[80] = t47;
        $[81] = t48;
    } else {
        t48 = $[81];
    }
    let t49;
    if ($[82] === Symbol.for("react.memo_cache_sentinel")) {
        t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 499,
                columnNumber: 41
            }, this),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "subtitle1",
                children: "Search Tuning"
            }, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 499,
                columnNumber: 61
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 499,
            columnNumber: 11
        }, this);
        $[82] = t49;
    } else {
        t49 = $[82];
    }
    const t50 = values.searchThreshold ?? 0.3;
    let t51;
    if ($[83] !== t50) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            gutterBottom: true,
            children: [
                "Similarity Threshold: ",
                t50
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 507,
            columnNumber: 11
        }, this);
        $[83] = t50;
        $[84] = t51;
    } else {
        t51 = $[84];
    }
    const t52 = values.searchThreshold ?? 0.3;
    let t53;
    if ($[85] !== update) {
        t53 = ({
            "AIAgentConfig[<Slider>.onChange]": (__1, v_1)=>update("searchThreshold", v_1)
        })["AIAgentConfig[<Slider>.onChange]"];
        $[85] = update;
        $[86] = t53;
    } else {
        t53 = $[86];
    }
    let t54;
    if ($[87] === Symbol.for("react.memo_cache_sentinel")) {
        t54 = [
            {
                value: 0.1,
                label: "0.1"
            },
            {
                value: 0.3,
                label: "0.3"
            },
            {
                value: 0.9,
                label: "0.9"
            }
        ];
        $[87] = t54;
    } else {
        t54 = $[87];
    }
    let t55;
    if ($[88] !== t52 || $[89] !== t53) {
        t55 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            value: t52,
            onChange: t53,
            min: 0.1,
            max: 0.9,
            step: 0.05,
            marks: t54,
            valueLabelDisplay: "auto"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 542,
            columnNumber: 11
        }, this);
        $[88] = t52;
        $[89] = t53;
        $[90] = t55;
    } else {
        t55 = $[90];
    }
    let t56;
    if ($[91] !== t51 || $[92] !== t55) {
        t56 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t51,
                t55
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 551,
            columnNumber: 11
        }, this);
        $[91] = t51;
        $[92] = t55;
        $[93] = t56;
    } else {
        t56 = $[93];
    }
    let t57;
    if ($[94] !== mode || $[95] !== update || $[96] !== values.searchDefaultLimit) {
        t57 = mode === "platform" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Default Result Limit",
            type: "number",
            size: "small",
            value: values.searchDefaultLimit ?? 5,
            onChange: {
                "AIAgentConfig[<TextField>.onChange]": (e_5)=>update("searchDefaultLimit", e_5.target.value ? parseInt(e_5.target.value, 10) : null)
            }["AIAgentConfig[<TextField>.onChange]"],
            slotProps: {
                htmlInput: {
                    min: 1,
                    max: 20
                }
            }
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 560,
            columnNumber: 34
        }, this);
        $[94] = mode;
        $[95] = update;
        $[96] = values.searchDefaultLimit;
        $[97] = t57;
    } else {
        t57 = $[97];
    }
    let t58;
    if ($[98] !== t56 || $[99] !== t57) {
        t58 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t49,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        spacing: 3,
                        children: [
                            t56,
                            t57
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/AIAgentConfig.tsx",
                        lineNumber: 577,
                        columnNumber: 45
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 577,
                    columnNumber: 27
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 577,
            columnNumber: 11
        }, this);
        $[98] = t56;
        $[99] = t57;
        $[100] = t58;
    } else {
        t58 = $[100];
    }
    let t59;
    if ($[101] === Symbol.for("react.memo_cache_sentinel")) {
        t59 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 586,
                columnNumber: 41
            }, this),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "subtitle1",
                children: "Conversation Memory"
            }, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 586,
                columnNumber: 61
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 586,
            columnNumber: 11
        }, this);
        $[101] = t59;
    } else {
        t59 = $[101];
    }
    const t60 = values.memoryEnabled ?? true;
    let t61;
    if ($[102] !== update) {
        t61 = ({
            "AIAgentConfig[<Switch>.onChange]": (e_6)=>update("memoryEnabled", e_6.target.checked)
        })["AIAgentConfig[<Switch>.onChange]"];
        $[102] = update;
        $[103] = t61;
    } else {
        t61 = $[103];
    }
    let t62;
    if ($[104] !== t60 || $[105] !== t61) {
        t62 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                checked: t60,
                onChange: t61
            }, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 604,
                columnNumber: 38
            }, this),
            label: "Enable conversation memory"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 604,
            columnNumber: 11
        }, this);
        $[104] = t60;
        $[105] = t61;
        $[106] = t62;
    } else {
        t62 = $[106];
    }
    let t63;
    if ($[107] !== mode || $[108] !== update || $[109] !== values.memorySummarizationModel) {
        t63 = mode === "platform" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fullWidth: true,
            size: "small",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: "Summarization Model"
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 613,
                    columnNumber: 77
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    label: "Summarization Model",
                    value: values.memorySummarizationModel || "gpt-4o-mini",
                    onChange: {
                        "AIAgentConfig[<Select>.onChange]": (e_7)=>update("memorySummarizationModel", e_7.target.value)
                    }["AIAgentConfig[<Select>.onChange]"],
                    children: AVAILABLE_MODELS.map(_AIAgentConfigAVAILABLE_MODELSMap4)
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 613,
                    columnNumber: 121
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 613,
            columnNumber: 34
        }, this);
        $[107] = mode;
        $[108] = update;
        $[109] = values.memorySummarizationModel;
        $[110] = t63;
    } else {
        t63 = $[110];
    }
    let t64;
    if ($[111] !== t62 || $[112] !== t63) {
        t64 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t59,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        spacing: 2,
                        children: [
                            t62,
                            t63
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/AIAgentConfig.tsx",
                        lineNumber: 625,
                        columnNumber: 45
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 625,
                    columnNumber: 27
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 625,
            columnNumber: 11
        }, this);
        $[111] = t62;
        $[112] = t63;
        $[113] = t64;
    } else {
        t64 = $[113];
    }
    let t65;
    if ($[114] === Symbol.for("react.memo_cache_sentinel")) {
        t65 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 634,
                columnNumber: 41
            }, this),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "subtitle1",
                children: "Token Budgets"
            }, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 634,
                columnNumber: 61
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 634,
            columnNumber: 11
        }, this);
        $[114] = t65;
    } else {
        t65 = $[114];
    }
    let t66;
    if ($[115] === Symbol.for("react.memo_cache_sentinel")) {
        t66 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            children: "Control how many tokens are allocated to each part of an agent turn. Lower budgets reduce cost; higher budgets allow richer context."
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 641,
            columnNumber: 11
        }, this);
        $[115] = t66;
    } else {
        t66 = $[115];
    }
    const t67 = values.enforceTokenBudget ?? true;
    let t68;
    if ($[116] !== update) {
        t68 = ({
            "AIAgentConfig[<Switch>.onChange]": (e_8)=>update("enforceTokenBudget", e_8.target.checked)
        })["AIAgentConfig[<Switch>.onChange]"];
        $[116] = update;
        $[117] = t68;
    } else {
        t68 = $[117];
    }
    let t69;
    if ($[118] !== t67 || $[119] !== t68) {
        t69 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                checked: t67,
                onChange: t68
            }, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 659,
                columnNumber: 38
            }, this),
            label: "Enforce token budgets"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 659,
            columnNumber: 11
        }, this);
        $[118] = t67;
        $[119] = t68;
        $[120] = t69;
    } else {
        t69 = $[120];
    }
    let t70;
    if ($[121] === Symbol.for("react.memo_cache_sentinel")) {
        t70 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            sx: {
                mt: -2
            },
            children: "When enabled, the agent will truncate system prompts and tool results to their budget limits, and abort multi-step turns that exceed the total turn budget."
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 668,
            columnNumber: 11
        }, this);
        $[121] = t70;
    } else {
        t70 = $[121];
    }
    const t71 = values.systemPromptBudget ?? 2000;
    let t72;
    if ($[122] !== update) {
        t72 = ({
            "AIAgentConfig[<TextField>.onChange]": (e_9)=>update("systemPromptBudget", e_9.target.value ? parseInt(e_9.target.value, 10) : null)
        })["AIAgentConfig[<TextField>.onChange]"];
        $[122] = update;
        $[123] = t72;
    } else {
        t72 = $[123];
    }
    let t73;
    if ($[124] === Symbol.for("react.memo_cache_sentinel")) {
        t73 = {
            htmlInput: {
                min: 500,
                max: 8000
            }
        };
        $[124] = t73;
    } else {
        t73 = $[124];
    }
    let t74;
    if ($[125] !== t71 || $[126] !== t72) {
        t74 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "System Prompt Budget",
            type: "number",
            size: "small",
            value: t71,
            onChange: t72,
            slotProps: t73,
            helperText: "Max tokens for Tier 1 context in system prompt (default: 2000)"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 700,
            columnNumber: 11
        }, this);
        $[125] = t71;
        $[126] = t72;
        $[127] = t74;
    } else {
        t74 = $[127];
    }
    const t75 = values.toolResultBudget ?? 4000;
    let t76;
    if ($[128] !== update) {
        t76 = ({
            "AIAgentConfig[<TextField>.onChange]": (e_10)=>update("toolResultBudget", e_10.target.value ? parseInt(e_10.target.value, 10) : null)
        })["AIAgentConfig[<TextField>.onChange]"];
        $[128] = update;
        $[129] = t76;
    } else {
        t76 = $[129];
    }
    let t77;
    if ($[130] === Symbol.for("react.memo_cache_sentinel")) {
        t77 = {
            htmlInput: {
                min: 500,
                max: 16000
            }
        };
        $[130] = t77;
    } else {
        t77 = $[130];
    }
    let t78;
    if ($[131] !== t75 || $[132] !== t76) {
        t78 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Tool Result Budget",
            type: "number",
            size: "small",
            value: t75,
            onChange: t76,
            slotProps: t77,
            helperText: "Max tokens per tool result returned to model (default: 4000)"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 732,
            columnNumber: 11
        }, this);
        $[131] = t75;
        $[132] = t76;
        $[133] = t78;
    } else {
        t78 = $[133];
    }
    const t79 = values.totalTurnBudget ?? 16000;
    let t80;
    if ($[134] !== update) {
        t80 = ({
            "AIAgentConfig[<TextField>.onChange]": (e_11)=>update("totalTurnBudget", e_11.target.value ? parseInt(e_11.target.value, 10) : null)
        })["AIAgentConfig[<TextField>.onChange]"];
        $[134] = update;
        $[135] = t80;
    } else {
        t80 = $[135];
    }
    let t81;
    if ($[136] === Symbol.for("react.memo_cache_sentinel")) {
        t81 = {
            htmlInput: {
                min: 2000,
                max: 64000
            }
        };
        $[136] = t81;
    } else {
        t81 = $[136];
    }
    let t82;
    if ($[137] !== t79 || $[138] !== t80) {
        t82 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Total Turn Budget",
            type: "number",
            size: "small",
            value: t79,
            onChange: t80,
            slotProps: t81,
            helperText: "Max total tokens consumed per agent turn across all steps (default: 16000)"
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 764,
            columnNumber: 11
        }, this);
        $[137] = t79;
        $[138] = t80;
        $[139] = t82;
    } else {
        t82 = $[139];
    }
    let t83;
    if ($[140] !== mode || $[141] !== update || $[142] !== values.kaiSystemPromptBudget || $[143] !== values.kaiToolResultBudget || $[144] !== values.kaiTotalTurnBudget || $[145] !== values.sageSystemPromptBudget || $[146] !== values.sageToolResultBudget || $[147] !== values.sageTotalTurnBudget) {
        t83 = mode === "platform" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    sx: {
                        mt: 1,
                        fontWeight: 600
                    },
                    children: "Per-Persona Overrides"
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 773,
                    columnNumber: 36
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    direction: "row",
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: "Kai System Prompt",
                            type: "number",
                            size: "small",
                            fullWidth: true,
                            value: values.kaiSystemPromptBudget ?? "",
                            onChange: {
                                "AIAgentConfig[<TextField>.onChange]": (e_12)=>update("kaiSystemPromptBudget", e_12.target.value ? parseInt(e_12.target.value, 10) : null)
                            }["AIAgentConfig[<TextField>.onChange]"],
                            slotProps: {
                                htmlInput: {
                                    min: 500,
                                    max: 8000
                                }
                            },
                            placeholder: "Use default"
                        }, void 0, false, {
                            fileName: "[project]/src/components/AIAgentConfig.tsx",
                            lineNumber: 776,
                            columnNumber: 79
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: "Sage System Prompt",
                            type: "number",
                            size: "small",
                            fullWidth: true,
                            value: values.sageSystemPromptBudget ?? "",
                            onChange: {
                                "AIAgentConfig[<TextField>.onChange]": (e_13)=>update("sageSystemPromptBudget", e_13.target.value ? parseInt(e_13.target.value, 10) : null)
                            }["AIAgentConfig[<TextField>.onChange]"],
                            slotProps: {
                                htmlInput: {
                                    min: 500,
                                    max: 8000
                                }
                            },
                            placeholder: "Use default"
                        }, void 0, false, {
                            fileName: "[project]/src/components/AIAgentConfig.tsx",
                            lineNumber: 783,
                            columnNumber: 40
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 776,
                    columnNumber: 44
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    direction: "row",
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: "Kai Tool Result",
                            type: "number",
                            size: "small",
                            fullWidth: true,
                            value: values.kaiToolResultBudget ?? "",
                            onChange: {
                                "AIAgentConfig[<TextField>.onChange]": (e_14)=>update("kaiToolResultBudget", e_14.target.value ? parseInt(e_14.target.value, 10) : null)
                            }["AIAgentConfig[<TextField>.onChange]"],
                            slotProps: {
                                htmlInput: {
                                    min: 500,
                                    max: 16000
                                }
                            },
                            placeholder: "Use default"
                        }, void 0, false, {
                            fileName: "[project]/src/components/AIAgentConfig.tsx",
                            lineNumber: 790,
                            columnNumber: 83
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: "Sage Tool Result",
                            type: "number",
                            size: "small",
                            fullWidth: true,
                            value: values.sageToolResultBudget ?? "",
                            onChange: {
                                "AIAgentConfig[<TextField>.onChange]": (e_15)=>update("sageToolResultBudget", e_15.target.value ? parseInt(e_15.target.value, 10) : null)
                            }["AIAgentConfig[<TextField>.onChange]"],
                            slotProps: {
                                htmlInput: {
                                    min: 500,
                                    max: 16000
                                }
                            },
                            placeholder: "Use default"
                        }, void 0, false, {
                            fileName: "[project]/src/components/AIAgentConfig.tsx",
                            lineNumber: 797,
                            columnNumber: 40
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 790,
                    columnNumber: 48
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    direction: "row",
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: "Kai Total Turn",
                            type: "number",
                            size: "small",
                            fullWidth: true,
                            value: values.kaiTotalTurnBudget ?? "",
                            onChange: {
                                "AIAgentConfig[<TextField>.onChange]": (e_16)=>update("kaiTotalTurnBudget", e_16.target.value ? parseInt(e_16.target.value, 10) : null)
                            }["AIAgentConfig[<TextField>.onChange]"],
                            slotProps: {
                                htmlInput: {
                                    min: 2000,
                                    max: 64000
                                }
                            },
                            placeholder: "Use default"
                        }, void 0, false, {
                            fileName: "[project]/src/components/AIAgentConfig.tsx",
                            lineNumber: 804,
                            columnNumber: 83
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: "Sage Total Turn",
                            type: "number",
                            size: "small",
                            fullWidth: true,
                            value: values.sageTotalTurnBudget ?? "",
                            onChange: {
                                "AIAgentConfig[<TextField>.onChange]": (e_17)=>update("sageTotalTurnBudget", e_17.target.value ? parseInt(e_17.target.value, 10) : null)
                            }["AIAgentConfig[<TextField>.onChange]"],
                            slotProps: {
                                htmlInput: {
                                    min: 2000,
                                    max: 64000
                                }
                            },
                            placeholder: "Use default"
                        }, void 0, false, {
                            fileName: "[project]/src/components/AIAgentConfig.tsx",
                            lineNumber: 811,
                            columnNumber: 40
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 804,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true);
        $[140] = mode;
        $[141] = update;
        $[142] = values.kaiSystemPromptBudget;
        $[143] = values.kaiToolResultBudget;
        $[144] = values.kaiTotalTurnBudget;
        $[145] = values.sageSystemPromptBudget;
        $[146] = values.sageToolResultBudget;
        $[147] = values.sageTotalTurnBudget;
        $[148] = t83;
    } else {
        t83 = $[148];
    }
    let t84;
    if ($[149] !== t69 || $[150] !== t74 || $[151] !== t78 || $[152] !== t82 || $[153] !== t83) {
        t84 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t65,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        spacing: 3,
                        children: [
                            t66,
                            t69,
                            t70,
                            t74,
                            t78,
                            t82,
                            t83
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/AIAgentConfig.tsx",
                        lineNumber: 833,
                        columnNumber: 45
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 833,
                    columnNumber: 27
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 833,
            columnNumber: 11
        }, this);
        $[149] = t69;
        $[150] = t74;
        $[151] = t78;
        $[152] = t82;
        $[153] = t83;
        $[154] = t84;
    } else {
        t84 = $[154];
    }
    let t85;
    if ($[155] !== mode || $[156] !== update || $[157] !== values.kaiEnabled || $[158] !== values.sageEnabled) {
        t85 = mode === "platform" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/AIAgentConfig.tsx",
                        lineNumber: 845,
                        columnNumber: 75
                    }, this),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "subtitle1",
                        children: "Persona Toggles"
                    }, void 0, false, {
                        fileName: "[project]/src/components/AIAgentConfig.tsx",
                        lineNumber: 845,
                        columnNumber: 95
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 845,
                    columnNumber: 45
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    checked: values.kaiEnabled ?? true,
                                    onChange: {
                                        "AIAgentConfig[<Switch>.onChange]": (e_18)=>update("kaiEnabled", e_18.target.checked)
                                    }["AIAgentConfig[<Switch>.onChange]"]
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                                    lineNumber: 845,
                                    columnNumber: 238
                                }, this),
                                label: "Enable Kai (student tutor bot)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/AIAgentConfig.tsx",
                                lineNumber: 845,
                                columnNumber: 211
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    checked: values.sageEnabled ?? true,
                                    onChange: {
                                        "AIAgentConfig[<Switch>.onChange]": (e_19)=>update("sageEnabled", e_19.target.checked)
                                    }["AIAgentConfig[<Switch>.onChange]"]
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                                    lineNumber: 847,
                                    columnNumber: 122
                                }, this),
                                label: "Enable Sage (instructor assistant bot)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/AIAgentConfig.tsx",
                                lineNumber: 847,
                                columnNumber: 95
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/AIAgentConfig.tsx",
                        lineNumber: 845,
                        columnNumber: 192
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/AIAgentConfig.tsx",
                    lineNumber: 845,
                    columnNumber: 174
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 845,
            columnNumber: 34
        }, this);
        $[155] = mode;
        $[156] = update;
        $[157] = values.kaiEnabled;
        $[158] = values.sageEnabled;
        $[159] = t85;
    } else {
        t85 = $[159];
    }
    let t86;
    if ($[160] === Symbol.for("react.memo_cache_sentinel")) {
        t86 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 860,
            columnNumber: 11
        }, this);
        $[160] = t86;
    } else {
        t86 = $[160];
    }
    const t87 = mode === "section" ? "Section-Specific Instructions" : "Prompt Overrides";
    let t88;
    if ($[161] !== t87) {
        t88 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            expandIcon: t86,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "subtitle1",
                children: t87
            }, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 868,
                columnNumber: 46
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 868,
            columnNumber: 11
        }, this);
        $[161] = t87;
        $[162] = t88;
    } else {
        t88 = $[162];
    }
    const t89 = mode === "section" ? "Kai instructions (appended to system prompt)" : "Kai System Prompt Override";
    const t90 = (mode === "section" ? values.kaiSystemPromptAppend : values.kaiSystemPromptOverride) || "";
    let t91;
    if ($[163] !== mode || $[164] !== update) {
        t91 = ({
            "AIAgentConfig[<TextField>.onChange]": (e_20)=>update(mode === "section" ? "kaiSystemPromptAppend" : "kaiSystemPromptOverride", e_20.target.value || null)
        })["AIAgentConfig[<TextField>.onChange]"];
        $[163] = mode;
        $[164] = update;
        $[165] = t91;
    } else {
        t91 = $[165];
    }
    let t92;
    if ($[166] !== t89 || $[167] !== t90 || $[168] !== t91) {
        t92 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: t89,
            multiline: true,
            minRows: 3,
            maxRows: 8,
            size: "small",
            value: t90,
            onChange: t91
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 889,
            columnNumber: 11
        }, this);
        $[166] = t89;
        $[167] = t90;
        $[168] = t91;
        $[169] = t92;
    } else {
        t92 = $[169];
    }
    const t93 = mode === "section" ? "Sage instructions (appended to system prompt)" : "Sage System Prompt Override";
    const t94 = (mode === "section" ? values.sageSystemPromptAppend : values.sageSystemPromptOverride) || "";
    let t95;
    if ($[170] !== mode || $[171] !== update) {
        t95 = ({
            "AIAgentConfig[<TextField>.onChange]": (e_21)=>update(mode === "section" ? "sageSystemPromptAppend" : "sageSystemPromptOverride", e_21.target.value || null)
        })["AIAgentConfig[<TextField>.onChange]"];
        $[170] = mode;
        $[171] = update;
        $[172] = t95;
    } else {
        t95 = $[172];
    }
    let t96;
    if ($[173] !== t93 || $[174] !== t94 || $[175] !== t95) {
        t96 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: t93,
            multiline: true,
            minRows: 3,
            maxRows: 8,
            size: "small",
            value: t94,
            onChange: t95
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 912,
            columnNumber: 11
        }, this);
        $[173] = t93;
        $[174] = t94;
        $[175] = t95;
        $[176] = t96;
    } else {
        t96 = $[176];
    }
    let t97;
    if ($[177] !== t92 || $[178] !== t96) {
        t97 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                spacing: 2,
                children: [
                    t92,
                    t96
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 922,
                columnNumber: 29
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 922,
            columnNumber: 11
        }, this);
        $[177] = t92;
        $[178] = t96;
        $[179] = t97;
    } else {
        t97 = $[179];
    }
    let t98;
    if ($[180] !== t88 || $[181] !== t97) {
        t98 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t88,
                t97
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 931,
            columnNumber: 11
        }, this);
        $[180] = t88;
        $[181] = t97;
        $[182] = t98;
    } else {
        t98 = $[182];
    }
    let t99;
    if ($[183] === Symbol.for("react.memo_cache_sentinel")) {
        t99 = {
            mt: 2,
            display: "flex",
            justifyContent: "flex-end"
        };
        $[183] = t99;
    } else {
        t99 = $[183];
    }
    const t100 = saving ? "Saving..." : "Save Changes";
    let t101;
    if ($[184] !== onSave || $[185] !== saving || $[186] !== t100) {
        t101 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t99,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "contained",
                onClick: onSave,
                disabled: saving,
                children: t100
            }, void 0, false, {
                fileName: "[project]/src/components/AIAgentConfig.tsx",
                lineNumber: 952,
                columnNumber: 26
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 952,
            columnNumber: 12
        }, this);
        $[184] = onSave;
        $[185] = saving;
        $[186] = t100;
        $[187] = t101;
    } else {
        t101 = $[187];
    }
    let t102;
    if ($[188] !== t101 || $[189] !== t20 || $[190] !== t48 || $[191] !== t58 || $[192] !== t64 || $[193] !== t84 || $[194] !== t85 || $[195] !== t98) {
        t102 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t2,
            children: [
                t3,
                t20,
                t48,
                t58,
                t64,
                t84,
                t85,
                t98,
                t101
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AIAgentConfig.tsx",
            lineNumber: 962,
            columnNumber: 12
        }, this);
        $[188] = t101;
        $[189] = t20;
        $[190] = t48;
        $[191] = t58;
        $[192] = t64;
        $[193] = t84;
        $[194] = t85;
        $[195] = t98;
        $[196] = t102;
    } else {
        t102 = $[196];
    }
    return t102;
}
_c = AIAgentConfig;
function _AIAgentConfigAVAILABLE_MODELSMap4(m_2) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        value: m_2.id,
        children: m_2.label
    }, m_2.id, false, {
        fileName: "[project]/src/components/AIAgentConfig.tsx",
        lineNumber: 978,
        columnNumber: 10
    }, this);
}
function _AIAgentConfigAVAILABLE_MODELSMap3(m_1) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        value: m_1.id,
        children: [
            m_1.label,
            " (",
            m_1.tier,
            ")"
        ]
    }, m_1.id, true, {
        fileName: "[project]/src/components/AIAgentConfig.tsx",
        lineNumber: 981,
        columnNumber: 10
    }, this);
}
function _AIAgentConfigAVAILABLE_MODELSMap2(m_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        value: m_0.id,
        children: [
            m_0.label,
            " (",
            m_0.tier,
            ")"
        ]
    }, m_0.id, true, {
        fileName: "[project]/src/components/AIAgentConfig.tsx",
        lineNumber: 984,
        columnNumber: 10
    }, this);
}
function _AIAgentConfigAVAILABLE_MODELSMap(m) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        value: m.id,
        children: [
            m.label,
            " (",
            m.tier,
            ")"
        ]
    }, m.id, true, {
        fileName: "[project]/src/components/AIAgentConfig.tsx",
        lineNumber: 987,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "AIAgentConfig");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_AIAgentConfig_tsx_10zcwmj._.js.map