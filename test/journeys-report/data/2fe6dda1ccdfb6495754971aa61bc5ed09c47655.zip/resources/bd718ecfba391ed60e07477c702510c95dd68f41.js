(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/utils/xpProjection.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "computeXPPerLevelForTarget",
    ()=>computeXPPerLevelForTarget,
    "drillSessionsForXP",
    ()=>drillSessionsForXP,
    "getDrillXP",
    ()=>getDrillXP,
    "getMaxXPPerUnit",
    ()=>getMaxXPPerUnit,
    "projectSectionXP",
    ()=>projectSectionXP,
    "tuneLevelConfig",
    ()=>tuneLevelConfig
]);
/**
 * XP Projection & Level Balancing — Calculates total available XP from
 * assigned units in a section, projects achievable levels, computes drill
 * gaps, and offers an algorithmic tuner to balance the level curve against
 * available content.
 *
 * @module xpProjection
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/xpCalculation.ts [app-client] (ecmascript)");
;
// ============================================================================
// Constants
// ============================================================================
/** XP from drills with diminishing returns per day */ const DRILL_XP_SCHEDULE = [
    30,
    15,
    8,
    5
] // sessions 1, 2, 3, 4+ per day
;
function getMaxXPPerUnit(xpConfig) {
    const get = (reason)=>xpConfig ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getXPForActionWithConfig"])(reason, xpConfig) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getXPForAction"])(reason);
    const submission = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].HOMEWORK_SUBMITTED);
    const allBlocks = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].ALL_BLOCKS_COMPLETED);
    const onTime = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].ON_TIME_SUBMISSION);
    const perfectScore = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PERFECT_SCORE);
    const revision = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].AI_FEEDBACK_REVISED);
    return {
        submission,
        allBlocks,
        onTime,
        perfectScore,
        revision,
        total: submission + allBlocks + onTime + perfectScore + revision
    };
}
function getDrillXP(sessionCount, xpConfig) {
    if (sessionCount <= 0) return 0;
    const baseXP = xpConfig ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getXPForActionWithConfig"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PRACTICE_DRILL_COMPLETED, xpConfig) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getXPForAction"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PRACTICE_DRILL_COMPLETED);
    // Optimal strategy: spread sessions across days (1 per day = max XP)
    // But account for realistic bunching with diminishing returns
    const accuracyBonus = xpConfig ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getXPForActionWithConfig"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PRACTICE_DRILL_ACCURACY_BONUS, xpConfig) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getXPForAction"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PRACTICE_DRILL_ACCURACY_BONUS);
    // Assume optimal distribution: 1 session per day at full value + accuracy bonus
    // This gives the "minimum sessions needed" scenario
    return sessionCount * (baseXP + accuracyBonus);
}
function drillSessionsForXP(targetXP, xpConfig) {
    if (targetXP <= 0) return 0;
    const baseXP = xpConfig ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getXPForActionWithConfig"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PRACTICE_DRILL_COMPLETED, xpConfig) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getXPForAction"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PRACTICE_DRILL_COMPLETED);
    const accuracyBonus = xpConfig ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getXPForActionWithConfig"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PRACTICE_DRILL_ACCURACY_BONUS, xpConfig) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getXPForAction"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PRACTICE_DRILL_ACCURACY_BONUS);
    const xpPerOptimalSession = baseXP + accuracyBonus;
    if (xpPerOptimalSession <= 0) return Infinity;
    return Math.ceil(targetXP / xpPerOptimalSession);
}
function projectSectionXP(unitCount, xpConfig) {
    const perUnitXP = getMaxXPPerUnit(xpConfig);
    const totalAssignmentXP = perUnitXP.total * unitCount;
    const levelConfig = xpConfig?.levelConfig;
    const maxLevelFromAssignments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLevelInfo"])(totalAssignmentXP, levelConfig);
    const thresholds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateLevelThresholds"])(levelConfig);
    const levelGaps = thresholds.map((t)=>{
        const deficit = Math.max(0, t.xpRequired - totalAssignmentXP);
        return {
            level: t.level,
            label: t.label,
            xpRequired: t.xpRequired,
            reachableFromAssignments: deficit === 0,
            xpDeficit: deficit,
            drillSessionsNeeded: drillSessionsForXP(deficit, xpConfig)
        };
    });
    return {
        unitCount,
        totalAssignmentXP,
        perUnitXP,
        maxLevelFromAssignments,
        levelGaps,
        xpConfig
    };
}
function tuneLevelConfig(options) {
    const { unitCount, desiredMaxLevel, assignmentReachFraction = 0.7, maxDrillsPerGap = 10, xpConfig } = options;
    const perUnitXP = getMaxXPPerUnit(xpConfig);
    const totalAssignmentXP = perUnitXP.total * unitCount;
    if (unitCount <= 0 || desiredMaxLevel <= 1) {
        return {
            recommendedConfig: {
                maxLevel: Math.max(1, desiredMaxLevel),
                xpPerLevel: 150,
                levelScaling: 1.6
            },
            thresholds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateLevelThresholds"])({
                maxLevel: desiredMaxLevel
            }),
            levelsReachableFromAssignments: desiredMaxLevel <= 1 ? 1 : 0,
            avgDrillsPerLevelGap: 0,
            feasible: false,
            explanation: 'Cannot tune: no units assigned or max level is 1.'
        };
    }
    // Target: levels 1..targetAssignmentLevel should be reachable from assignments
    const targetAssignmentLevel = Math.max(1, Math.floor(desiredMaxLevel * assignmentReachFraction));
    // The highest level fully reachable needs xpRequired ≤ totalAssignmentXP
    // Work backwards: find xpPerLevel such that level `targetAssignmentLevel` requires ≤ totalAssignmentXP
    // Cumulative XP for level L = sum(xpPerLevel * scaling^(i-1), i=1..L-1)
    // We need this ≤ totalAssignmentXP
    // Binary search on xpPerLevel (scaling held constant first, then adjusted)
    let bestConfig = {
        maxLevel: desiredMaxLevel,
        xpPerLevel: 150,
        levelScaling: 1.6
    };
    // Try different scaling values and find the best xpPerLevel for each
    const scalingCandidates = [
        1.0,
        1.2,
        1.4,
        1.6,
        1.8,
        2.0
    ];
    let bestScore = -Infinity;
    for (const scaling of scalingCandidates){
        // For a given scaling, find xpPerLevel such that
        // cumulative XP at targetAssignmentLevel ≤ totalAssignmentXP
        // Cumulative = xpPerLevel * sum(scaling^(i-1), i=1..targetAssignmentLevel-1)
        const geometricSum = sumGeometric(scaling, targetAssignmentLevel - 1);
        if (geometricSum <= 0) continue;
        const maxBase = totalAssignmentXP / geometricSum;
        const xpPerLevel = Math.max(10, Math.floor(maxBase));
        const config = {
            maxLevel: desiredMaxLevel,
            xpPerLevel,
            levelScaling: scaling
        };
        const thresholds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateLevelThresholds"])(config);
        // Score: how well does this satisfy constraints?
        let reachable = 0;
        let totalDrills = 0;
        let maxDrillsForAny = 0;
        const drillXPPerSession = getDrillXP(1, xpConfig);
        for (const t of thresholds){
            if (t.xpRequired <= totalAssignmentXP) {
                reachable++;
            } else {
                const deficit = t.xpRequired - totalAssignmentXP;
                const drills = drillSessionsForXP(deficit, xpConfig);
                totalDrills += drills;
                maxDrillsForAny = Math.max(maxDrillsForAny, drills);
            }
        }
        // Penalize if max drills exceeds limit
        const drillPenalty = maxDrillsForAny > maxDrillsPerGap ? (maxDrillsForAny - maxDrillsPerGap) * -10 : 0;
        // Reward more levels reachable from assignments
        const reachableScore = reachable * 10;
        // Reward closeness to target assignment reach
        const reachDiff = Math.abs(reachable - targetAssignmentLevel);
        const reachScore = -reachDiff * 5;
        const score = reachableScore + reachScore + drillPenalty;
        if (score > bestScore) {
            bestScore = score;
            bestConfig = config;
        }
    }
    // Generate final analysis with best config
    const thresholds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateLevelThresholds"])(bestConfig);
    let levelsReachable = 0;
    let totalDrillGaps = 0;
    let gapCount = 0;
    for (const t of thresholds){
        if (t.xpRequired <= totalAssignmentXP) {
            levelsReachable++;
        } else {
            const deficit = t.xpRequired - totalAssignmentXP;
            totalDrillGaps += drillSessionsForXP(deficit, xpConfig);
            gapCount++;
        }
    }
    const avgDrills = gapCount > 0 ? Math.round(totalDrillGaps / gapCount) : 0;
    const maxLevelXP = thresholds[thresholds.length - 1]?.xpRequired ?? 0;
    const feasible = levelsReachable >= targetAssignmentLevel || maxLevelXP - totalAssignmentXP <= maxDrillsPerGap * getDrillXP(1, xpConfig) * gapCount;
    const explanation = [
        `With ${unitCount} units (${totalAssignmentXP} max XP from assignments):`,
        `• Levels 1–${levelsReachable} reachable from assignments alone`,
        levelsReachable < desiredMaxLevel ? `• Levels ${levelsReachable + 1}–${desiredMaxLevel} require practice drills (~${avgDrills} sessions avg)` : `• All levels reachable from assignments!`,
        `• Recommended curve: base=${bestConfig.xpPerLevel} XP, scaling=${bestConfig.levelScaling}×`
    ].join('\n');
    return {
        recommendedConfig: bestConfig,
        thresholds,
        levelsReachableFromAssignments: levelsReachable,
        avgDrillsPerLevelGap: avgDrills,
        feasible,
        explanation
    };
}
function computeXPPerLevelForTarget(totalAvailableXP, maxLevel, levelScaling = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LEVEL_DEFAULTS"].levelScaling) {
    if (maxLevel <= 1 || totalAvailableXP <= 0) return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LEVEL_DEFAULTS"].xpPerLevel;
    const geometricSum = sumGeometric(levelScaling, maxLevel - 1);
    if (geometricSum <= 0) return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LEVEL_DEFAULTS"].xpPerLevel;
    return Math.max(10, Math.round(totalAvailableXP / geometricSum));
}
// ============================================================================
// Helpers
// ============================================================================
/** Sum of geometric series: sum(scaling^(i-1), i=1..n) */ function sumGeometric(scaling, n) {
    if (n <= 0) return 0;
    if (scaling === 1) return n;
    return (Math.pow(scaling, n) - 1) / (scaling - 1);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/gamificationProviderWrapper.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GamificationProviderWrapper",
    ()=>GamificationProviderWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$GamificationToastLayer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/GamificationToastLayer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function GamificationProviderWrapper(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "7151689139be499929ce124491916299acef4963acc9fed72473e0c8f3c8605b") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7151689139be499929ce124491916299acef4963acc9fed72473e0c8f3c8605b";
    }
    const { children, cohortId: cohortIdProp } = t0;
    const { user, session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const client = t1;
    const isInstructor = session?.groups?.includes("Instructors") || session?.groups?.includes("Admins");
    const studentId = isInstructor ? "" : user?.username || user?.attributes?.sub || "";
    const { sections, assignments } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {};
    session?.groups;
    let t2;
    if ($[2] !== cohortIdProp || $[3] !== session?.groups) {
        bb0: {
            if (cohortIdProp) {
                t2 = cohortIdProp;
                break bb0;
            }
            const groups = session?.groups || [];
            for (const group of groups){
                const match = group.match(/^section-(.+?)-(learners|instructors)$/);
                if (match) {
                    t2 = match[1];
                    break bb0;
                }
            }
            t2 = undefined;
        }
        $[2] = cohortIdProp;
        $[3] = session?.groups;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const cohortId = t2;
    let t3;
    if ($[5] !== studentId) {
        t3 = studentId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$GamificationToastLayer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationToastLayer"], {}, void 0, false, {
            fileName: "[project]/src/context/gamificationProviderWrapper.jsx",
            lineNumber: 76,
            columnNumber: 23
        }, this);
        $[5] = studentId;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== assignments || $[8] !== children || $[9] !== cohortId || $[10] !== sections || $[11] !== studentId || $[12] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationProvider"], {
            client: client,
            studentId: studentId,
            cohortId: cohortId,
            sections: sections,
            assignments: assignments,
            children: [
                children,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/src/context/gamificationProviderWrapper.jsx",
            lineNumber: 84,
            columnNumber: 10
        }, this);
        $[7] = assignments;
        $[8] = children;
        $[9] = cohortId;
        $[10] = sections;
        $[11] = studentId;
        $[12] = t3;
        $[13] = t4;
    } else {
        t4 = $[13];
    }
    return t4;
}
_s(GamificationProviderWrapper, "KAg+X7S5wlQvcXKzXEV+lune0l8=");
_c = GamificationProviderWrapper;
var _c;
__turbopack_context__.k.register(_c, "GamificationProviderWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_07h-8ix._.js.map