(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_components_Gamification_0ejf9gg._.js","static/chunks/src_components_AIAgentConfig_tsx_10zcwmj._.js","static/chunks/src_07h-8ix._.js","static/chunks/app_0l7569v._.js","static/chunks/node_modules_@xyflow_system_dist_esm_index_0g85hui.js","static/chunks/node_modules_@xyflow_react_dist_esm_index_117ncqw.js","static/chunks/node_modules_react-icons_fa6_index_mjs_0k-ey1c._.js","static/chunks/node_modules_react-icons_md_index_mjs_0hk925t._.js","static/chunks/node_modules_0vpzfsk._.js","static/chunks/node_modules_@xyflow_react_dist_style_0iupz4v.css"],
    source: "dynamic"
});
