(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/[locale]/admin/_components/AdminRouteGuard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AdminRouteGuard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
"use client";
;
;
;
;
function getUserGroups(user) {
    const accessGroups = user?.signInUserSession?.accessToken?.payload?.["cognito:groups"];
    if (Array.isArray(accessGroups)) return accessGroups;
    const idGroups = user?.signInUserSession?.idToken?.payload?.["cognito:groups"];
    if (Array.isArray(idGroups)) return idGroups;
    return Array.isArray(user?.groups) ? user.groups : [];
}
function canAccessAdminRoutes(user) {
    const groups = getUserGroups(user);
    return groups.includes("Admins") || groups.includes("Instructors");
}
function AdminRouteGuard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "ebe38306ece48fd50091530562986fc7651638e0cc12bd1c6ae83e171a36239f") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "ebe38306ece48fd50091530562986fc7651638e0cc12bd1c6ae83e171a36239f";
    }
    const { user, children } = t0;
    if (!canAccessAdminRoutes(user)) {
        let t1;
        if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
            t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    p: 4,
                    maxWidth: 720,
                    mx: "auto"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "h5",
                        gutterBottom: true,
                        children: "Access denied"
                    }, void 0, false, {
                        fileName: "[project]/app/[locale]/admin/_components/AdminRouteGuard.tsx",
                        lineNumber: 52,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        color: "text.secondary",
                        children: "Admin pages are restricted to instructors and admins."
                    }, void 0, false, {
                        fileName: "[project]/app/[locale]/admin/_components/AdminRouteGuard.tsx",
                        lineNumber: 52,
                        columnNumber: 81
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/[locale]/admin/_components/AdminRouteGuard.tsx",
                lineNumber: 48,
                columnNumber: 12
            }, this);
            $[1] = t1;
        } else {
            t1 = $[1];
        }
        return t1;
    }
    let t1;
    if ($[2] !== children) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: children
        }, void 0, false);
        $[2] = children;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    return t1;
}
_c = AdminRouteGuard;
var _c;
__turbopack_context__.k.register(_c, "AdminRouteGuard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:894db5 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateSkillTreeFromUnit",
    ()=>$$RSC_SERVER_ACTION_4
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"70cee74d9083b5e7f4beed90d2410c133ce91c34f1":{"name":"generateSkillTreeFromUnit"}},"app/actions/gamification.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("70cee74d9083b5e7f4beed90d2410c133ce91c34f1", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateSkillTreeFromUnit");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:74c0ad [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateCampaignNarrative",
    ()=>$$RSC_SERVER_ACTION_6
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60a4c0bf71d1aaca8efef4fbf68821a55307d2a856":{"name":"generateCampaignNarrative"}},"app/actions/gamification.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60a4c0bf71d1aaca8efef4fbf68821a55307d2a856", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateCampaignNarrative");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[locale]/admin/settings/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WrappedPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$locale$5d2f$admin$2f$_components$2f$AdminRouteGuard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/[locale]/admin/_components/AdminRouteGuard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$InstructorGamificationPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/InstructorGamificationPanel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AIAgentConfig$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/AIAgentConfig.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationProviderWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationProviderWrapper.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$74c0ad__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:74c0ad [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// ============================================================================
// Trigger type mapping (identity — schema now uses new enum directly)
// ============================================================================
const TRIGGER_TYPE_TO_SCHEMA = {
    KEYWORD: "KEYWORD",
    SCHEDULE: "SCHEDULE",
    SECRET_LINK: "SECRET_LINK",
    ACHIEVEMENT: "ACHIEVEMENT"
};
const SCHEMA_TO_TRIGGER_TYPE = {
    KEYWORD: "KEYWORD",
    SCHEDULE: "SCHEDULE",
    SECRET_LINK: "SECRET_LINK",
    ACHIEVEMENT: "ACHIEVEMENT"
};
// ============================================================================
// Container component — wires context data + CRUD to the panel
// ============================================================================
function GamificationAdmin() {
    _s();
    const client = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "GamificationAdmin.useMemo[client]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])()
    }["GamificationAdmin.useMemo[client]"], []);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    // --- Section selection with URL persistence ---
    const { sections } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [selectedSectionId, setSelectedSectionId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        "GamificationAdmin.useState": ()=>params.section || null
    }["GamificationAdmin.useState"]);
    // Update URL when section changes
    const handleSectionChange = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleSectionChange]": (sectionId)=>{
            setSelectedSectionId(sectionId);
            const searchParams = new URLSearchParams();
            if (sectionId) {
                searchParams.set("section", sectionId);
            }
            router.replace(`${pathname}${sectionId ? `?section=${sectionId}` : ""}`, {
                scroll: false
            });
        }
    }["GamificationAdmin.useCallback[handleSectionChange]"], [
        router,
        pathname
    ]);
    // Sync from URL on initial load
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "GamificationAdmin.useEffect": ()=>{
            if (params.section && params.section !== selectedSectionId) {
                setSelectedSectionId(params.section);
            }
        }
    }["GamificationAdmin.useEffect"], [
        params.section
    ]);
    // --- Data from existing gamification context hooks ---
    const { skillNodes } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSkillTree"])();
    const { campaign, activeChallenges, completedChallenges } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCampaign"])();
    const { squadLeaderboard } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSquad"])();
    // --- Local state for models not in the gamification context ---
    const [easterEggs, setEasterEggs] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [bossBattles, setBossBattles] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [badgeOverrides, setBadgeOverrides] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [customBadges, setCustomBadges] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [xpConfig, setXpConfig] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const [platformSettingsRecord, setPlatformSettingsRecord] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const [linearLockEnabled, setLinearLockEnabled] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [unitLockRequirements, setUnitLockRequirements] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({});
    const [availableUnits, setAvailableUnits] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [availableBadges, setAvailableBadges] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    // Load all units for the availableUnits list
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "GamificationAdmin.useEffect": ()=>{
            if (!client?.models?.Unit) return;
            const sub = client.models.Unit.observeQuery().subscribe({
                next: {
                    "GamificationAdmin.useEffect.sub": ({ items })=>{
                        const units = items.filter({
                            "GamificationAdmin.useEffect.sub.units": (u)=>u != null && !u._deleted
                        }["GamificationAdmin.useEffect.sub.units"]).map({
                            "GamificationAdmin.useEffect.sub.units": (u_0)=>({
                                    id: u_0.id,
                                    name: u_0.name || u_0.id
                                })
                        }["GamificationAdmin.useEffect.sub.units"]);
                        setAvailableUnits(units);
                        // Build unit lock requirements from unit data
                        const locks = {};
                        items.filter({
                            "GamificationAdmin.useEffect.sub": (u_1)=>u_1 != null && !u_1._deleted
                        }["GamificationAdmin.useEffect.sub"]).forEach({
                            "GamificationAdmin.useEffect.sub": (u_2)=>{
                                if (u_2.requiredXP || u_2.requiredBadgeId || u_2.requiredModuleCompletion) {
                                    locks[u_2.id] = {
                                        requiredXP: u_2.requiredXP || undefined,
                                        requiredBadgeId: u_2.requiredBadgeId || undefined,
                                        requiredModuleCompletion: u_2.requiredModuleCompletion || undefined
                                    };
                                }
                            }
                        }["GamificationAdmin.useEffect.sub"]);
                        setUnitLockRequirements(locks);
                    }
                }["GamificationAdmin.useEffect.sub"],
                error: {
                    "GamificationAdmin.useEffect.sub": (err)=>console.warn("[GamificationAdmin] Unit subscription error:", err)
                }["GamificationAdmin.useEffect.sub"]
            });
            return ({
                "GamificationAdmin.useEffect": ()=>sub.unsubscribe()
            })["GamificationAdmin.useEffect"];
        }
    }["GamificationAdmin.useEffect"], [
        client
    ]);
    // Load available badges for the selected section
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "GamificationAdmin.useEffect": ()=>{
            if (!client?.models?.Badge) return;
            const sub_0 = client.models.Badge.observeQuery().subscribe({
                next: {
                    "GamificationAdmin.useEffect.sub_0": ({ items: items_0 })=>{
                        const valid = items_0.filter({
                            "GamificationAdmin.useEffect.sub_0.valid": (b)=>b != null && !b._deleted
                        }["GamificationAdmin.useEffect.sub_0.valid"]);
                        const filtered = selectedSectionId ? valid.filter({
                            "GamificationAdmin.useEffect.sub_0": (b_0)=>!b_0.cohortId || b_0.cohortId === selectedSectionId
                        }["GamificationAdmin.useEffect.sub_0"]) : valid;
                        setAvailableBadges(filtered.map({
                            "GamificationAdmin.useEffect.sub_0": (b_1)=>({
                                    id: b_1.id,
                                    title: b_1.title || b_1.id
                                })
                        }["GamificationAdmin.useEffect.sub_0"]));
                    }
                }["GamificationAdmin.useEffect.sub_0"],
                error: {
                    "GamificationAdmin.useEffect.sub_0": (err_0)=>console.warn("[GamificationAdmin] Badge subscription error:", err_0)
                }["GamificationAdmin.useEffect.sub_0"]
            });
            return ({
                "GamificationAdmin.useEffect": ()=>sub_0.unsubscribe()
            })["GamificationAdmin.useEffect"];
        }
    }["GamificationAdmin.useEffect"], [
        client,
        selectedSectionId
    ]);
    // Load xpConfig from global PlatformSettings (singleton)
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "GamificationAdmin.useEffect": ()=>{
            if (!client?.models?.PlatformSettings) return;
            const sub_1 = client.models.PlatformSettings.observeQuery().subscribe({
                next: {
                    "GamificationAdmin.useEffect.sub_1": ({ items: items_1 })=>{
                        const valid_0 = (items_1 || []).filter({
                            "GamificationAdmin.useEffect.sub_1.valid_0": (i)=>i != null && i.id != null
                        }["GamificationAdmin.useEffect.sub_1.valid_0"]);
                        const record = valid_0[0] || null;
                        setPlatformSettingsRecord(record);
                        if (record) {
                            // Reconstruct XPTunerConfig shape from the flat PlatformSettings fields
                            const multipliers = record.xpMultipliers ? typeof record.xpMultipliers === "string" ? JSON.parse(record.xpMultipliers) : record.xpMultipliers : undefined;
                            const levelThresholds = record.levelThresholds ? typeof record.levelThresholds === "string" ? JSON.parse(record.levelThresholds) : record.levelThresholds : undefined;
                            const avatarUnlocks = record.avatarUnlockConfig ? typeof record.avatarUnlockConfig === "string" ? JSON.parse(record.avatarUnlockConfig) : record.avatarUnlockConfig : undefined;
                            setXpConfig({
                                multipliers: multipliers || undefined,
                                dailyCap: record.dailyCap ?? undefined,
                                weeklyCap: record.weeklyCap ?? undefined,
                                enabled: true,
                                levelConfig: levelThresholds ? {
                                    thresholds: levelThresholds
                                } : undefined,
                                avatarUnlocks: avatarUnlocks || undefined
                            });
                        } else {
                            setXpConfig(null);
                        }
                    }
                }["GamificationAdmin.useEffect.sub_1"],
                error: {
                    "GamificationAdmin.useEffect.sub_1": (err_1)=>console.warn("[GamificationAdmin] PlatformSettings subscription error:", err_1)
                }["GamificationAdmin.useEffect.sub_1"]
            });
            return ({
                "GamificationAdmin.useEffect": ()=>sub_1.unsubscribe()
            })["GamificationAdmin.useEffect"];
        }
    }["GamificationAdmin.useEffect"], [
        client
    ]);
    // Load linearLockEnabled from the selected section (still section-specific)
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "GamificationAdmin.useEffect": ()=>{
            if (!selectedSectionId || !sections) {
                setLinearLockEnabled(false);
                return;
            }
            const section = sections.find({
                "GamificationAdmin.useEffect.section": (s)=>s.id === selectedSectionId
            }["GamificationAdmin.useEffect.section"]);
            setLinearLockEnabled(!!section?.linearLockEnabled);
        }
    }["GamificationAdmin.useEffect"], [
        selectedSectionId,
        sections
    ]);
    // Subscribe to EasterEgg model — filter by selected section
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "GamificationAdmin.useEffect": ()=>{
            if (!client?.models?.EasterEgg) return;
            const sub_2 = client.models.EasterEgg.observeQuery().subscribe({
                next: {
                    "GamificationAdmin.useEffect.sub_2": ({ items: items_2 })=>{
                        const valid_1 = items_2.filter({
                            "GamificationAdmin.useEffect.sub_2.valid_1": (item)=>item != null && !item._deleted
                        }["GamificationAdmin.useEffect.sub_2.valid_1"]);
                        // Client-side section filter (cohortId may not exist on all eggs yet)
                        const filtered_0 = selectedSectionId ? valid_1.filter({
                            "GamificationAdmin.useEffect.sub_2": (egg)=>!egg.cohortId || egg.cohortId === selectedSectionId
                        }["GamificationAdmin.useEffect.sub_2"]) : valid_1;
                        setEasterEggs(filtered_0.map({
                            "GamificationAdmin.useEffect.sub_2": (egg_0)=>({
                                    id: egg_0.id,
                                    type: SCHEMA_TO_TRIGGER_TYPE[egg_0.trigger] || egg_0.trigger,
                                    message: egg_0.revealMessage || "",
                                    xpReward: egg_0.xpReward || 0,
                                    keyword: egg_0.trigger === "KEYWORD" ? egg_0.triggerValue || "" : undefined,
                                    triggerValue: egg_0.triggerValue || "",
                                    achievementRule: egg_0.trigger === "ACHIEVEMENT" ? egg_0.triggerValue || "" : undefined,
                                    secretLinkUnitId: egg_0.trigger === "SECRET_LINK" ? egg_0.triggerValue || "" : undefined,
                                    badgeId: egg_0.badgeId || undefined,
                                    _version: egg_0._version
                                })
                        }["GamificationAdmin.useEffect.sub_2"]));
                    }
                }["GamificationAdmin.useEffect.sub_2"],
                error: {
                    "GamificationAdmin.useEffect.sub_2": (err_2)=>console.warn("[GamificationAdmin] EasterEgg subscription error:", err_2)
                }["GamificationAdmin.useEffect.sub_2"]
            });
            return ({
                "GamificationAdmin.useEffect": ()=>sub_2.unsubscribe()
            })["GamificationAdmin.useEffect"];
        }
    }["GamificationAdmin.useEffect"], [
        client,
        selectedSectionId
    ]);
    // Subscribe to GroupChallenge (boss battles) model — filter by section
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "GamificationAdmin.useEffect": ()=>{
            if (!client?.models?.GroupChallenge) return;
            const sub_3 = client.models.GroupChallenge.observeQuery().subscribe({
                next: {
                    "GamificationAdmin.useEffect.sub_3": ({ items: items_3 })=>{
                        const valid_2 = items_3.filter({
                            "GamificationAdmin.useEffect.sub_3.valid_2": (item_0)=>item_0 != null && !item_0._deleted
                        }["GamificationAdmin.useEffect.sub_3.valid_2"]);
                        const filtered_1 = selectedSectionId ? valid_2.filter({
                            "GamificationAdmin.useEffect.sub_3": (boss)=>boss.cohortId === selectedSectionId
                        }["GamificationAdmin.useEffect.sub_3"]) : valid_2;
                        setBossBattles(filtered_1.map({
                            "GamificationAdmin.useEffect.sub_3": (boss_0)=>({
                                    id: boss_0.id,
                                    title: boss_0.title || "",
                                    targetXP: boss_0.targetXP || 0,
                                    currentXP: boss_0.currentXP || 0,
                                    active: boss_0.active ?? true,
                                    startDate: boss_0.startDate || undefined,
                                    deadline: boss_0.deadline || undefined,
                                    bonusMultiplier: boss_0.bonusMultiplier || 1.5,
                                    setting: boss_0.setting || undefined,
                                    stakes: boss_0.stakes || undefined,
                                    featuredImage: boss_0.featuredImage || undefined,
                                    contributors: boss_0.contributions || [],
                                    _version: boss_0._version
                                })
                        }["GamificationAdmin.useEffect.sub_3"]));
                    }
                }["GamificationAdmin.useEffect.sub_3"],
                error: {
                    "GamificationAdmin.useEffect.sub_3": (err_3)=>console.warn("[GamificationAdmin] GroupChallenge subscription error:", err_3)
                }["GamificationAdmin.useEffect.sub_3"]
            });
            return ({
                "GamificationAdmin.useEffect": ()=>sub_3.unsubscribe()
            })["GamificationAdmin.useEffect"];
        }
    }["GamificationAdmin.useEffect"], [
        client,
        selectedSectionId
    ]);
    // --- Transform context data to panel prop shapes ---
    const skills = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "GamificationAdmin.useMemo[skills]": ()=>skillNodes.map({
                "GamificationAdmin.useMemo[skills]": (node)=>({
                        id: node.skillId,
                        title: node.title,
                        description: node.description,
                        xpReward: node.xpReward,
                        prerequisites: node.prerequisites,
                        unitIds: node.unitIds,
                        minimumAccuracy: node.minimumAccuracy
                    })
            }["GamificationAdmin.useMemo[skills]"])
    }["GamificationAdmin.useMemo[skills]"], [
        skillNodes
    ]);
    // Build section options for the selector
    const sectionOptions = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "GamificationAdmin.useMemo[sectionOptions]": ()=>(sections || []).map({
                "GamificationAdmin.useMemo[sectionOptions]": (s_0)=>({
                        id: s_0.id,
                        name: s_0.name || s_0.id,
                        description: s_0.description
                    })
            }["GamificationAdmin.useMemo[sectionOptions]"])
    }["GamificationAdmin.useMemo[sectionOptions]"], [
        sections
    ]);
    const campaigns = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "GamificationAdmin.useMemo[campaigns]": ()=>{
            if (!campaign) return [];
            return [
                {
                    id: campaign.id,
                    title: campaign.title || "",
                    setting: campaign.setting,
                    stakes: campaign.stakes
                }
            ];
        }
    }["GamificationAdmin.useMemo[campaigns]"], [
        campaign
    ]);
    const squads = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "GamificationAdmin.useMemo[squads]": ()=>squadLeaderboard.map({
                "GamificationAdmin.useMemo[squads]": (g)=>({
                        id: g.id,
                        name: g.name || "",
                        memberCount: g.memberCount
                    })
            }["GamificationAdmin.useMemo[squads]"])
    }["GamificationAdmin.useMemo[squads]"], [
        squadLeaderboard
    ]);
    // --- CRUD Callbacks ---
    const handlePrerequisiteChange = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handlePrerequisiteChange]": async (skillId, prerequisites)=>{
            try {
                const { data } = await client.models.Skill.get({
                    id: skillId
                });
                await client.models.Skill.update({
                    id: skillId,
                    prerequisites: JSON.stringify(prerequisites),
                    _version: data?._version
                });
            } catch (err_4) {
                console.error("[GamificationAdmin] Failed to update prerequisites:", err_4);
            }
        }
    }["GamificationAdmin.useCallback[handlePrerequisiteChange]"], [
        client
    ]);
    const handleAddSkill = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleAddSkill]": async (skill)=>{
            try {
                await client.models.Skill.create({
                    title: skill.title,
                    description: skill.description || "",
                    xpReward: skill.xpReward || 0,
                    cohortId: selectedSectionId || undefined
                });
            } catch (err_5) {
                console.error("[GamificationAdmin] Failed to create Skill:", err_5);
            }
        }
    }["GamificationAdmin.useCallback[handleAddSkill]"], [
        client,
        selectedSectionId
    ]);
    const handleDeleteSkill = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleDeleteSkill]": async (skillId_0)=>{
            try {
                const { data: data_0 } = await client.models.Skill.get({
                    id: skillId_0
                });
                await client.models.Skill.delete({
                    id: skillId_0,
                    _version: data_0?._version
                });
            } catch (err_6) {
                console.error("[GamificationAdmin] Failed to delete Skill:", err_6);
            }
        }
    }["GamificationAdmin.useCallback[handleDeleteSkill]"], [
        client
    ]);
    const handleSaveCampaign = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleSaveCampaign]": async (campaignData)=>{
            // Campaign model was removed — campaigns are now GroupChallenge records with chapterOrder
            console.warn("[GamificationAdmin] handleSaveCampaign called but Campaign model no longer exists. Use GroupChallenge instead.");
        }
    }["GamificationAdmin.useCallback[handleSaveCampaign]"], []);
    const handleDeleteCampaign = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleDeleteCampaign]": async (campaignId)=>{
            // Campaign model was removed — campaigns are now GroupChallenge records with chapterOrder
            console.warn("[GamificationAdmin] handleDeleteCampaign called but Campaign model no longer exists. Use GroupChallenge instead.");
        }
    }["GamificationAdmin.useCallback[handleDeleteCampaign]"], []);
    const handleGenerateCampaign = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleGenerateCampaign]": async (title)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$74c0ad__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateCampaignNarrative"])(title, selectedSectionId || undefined);
        }
    }["GamificationAdmin.useCallback[handleGenerateCampaign]"], [
        selectedSectionId
    ]);
    // --- Badge customization handlers ---
    const handleBadgeOverrideChange = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleBadgeOverrideChange]": (override)=>{
            setBadgeOverrides({
                "GamificationAdmin.useCallback[handleBadgeOverrideChange]": (prev)=>{
                    const idx = prev.findIndex({
                        "GamificationAdmin.useCallback[handleBadgeOverrideChange].idx": (o)=>o.badgeType === override.badgeType
                    }["GamificationAdmin.useCallback[handleBadgeOverrideChange].idx"]);
                    if (idx >= 0) {
                        const next = [
                            ...prev
                        ];
                        next[idx] = override;
                        return next;
                    }
                    return [
                        ...prev,
                        override
                    ];
                }
            }["GamificationAdmin.useCallback[handleBadgeOverrideChange]"]);
        }
    }["GamificationAdmin.useCallback[handleBadgeOverrideChange]"], []);
    const handleBadgeOverrideReset = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleBadgeOverrideReset]": (badgeType)=>{
            setBadgeOverrides({
                "GamificationAdmin.useCallback[handleBadgeOverrideReset]": (prev_0)=>prev_0.filter({
                        "GamificationAdmin.useCallback[handleBadgeOverrideReset]": (o_0)=>o_0.badgeType !== badgeType
                    }["GamificationAdmin.useCallback[handleBadgeOverrideReset]"])
            }["GamificationAdmin.useCallback[handleBadgeOverrideReset]"]);
        }
    }["GamificationAdmin.useCallback[handleBadgeOverrideReset]"], []);
    const handleAddCustomBadge = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleAddCustomBadge]": (badge)=>{
            setCustomBadges({
                "GamificationAdmin.useCallback[handleAddCustomBadge]": (prev_1)=>[
                        ...prev_1,
                        {
                            ...badge,
                            id: `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
                        }
                    ]
            }["GamificationAdmin.useCallback[handleAddCustomBadge]"]);
        }
    }["GamificationAdmin.useCallback[handleAddCustomBadge]"], []);
    const handleDeleteCustomBadge = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleDeleteCustomBadge]": (badgeId)=>{
            setCustomBadges({
                "GamificationAdmin.useCallback[handleDeleteCustomBadge]": (prev_2)=>prev_2.filter({
                        "GamificationAdmin.useCallback[handleDeleteCustomBadge]": (b_2)=>b_2.id !== badgeId
                    }["GamificationAdmin.useCallback[handleDeleteCustomBadge]"])
            }["GamificationAdmin.useCallback[handleDeleteCustomBadge]"]);
        }
    }["GamificationAdmin.useCallback[handleDeleteCustomBadge]"], []);
    const handleCreateSquad = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleCreateSquad]": async (name, cohortId)=>{
            try {
                await client.models.Squad.create({
                    name,
                    cohortId,
                    totalXP: 0
                });
            } catch (err_7) {
                console.error("[GamificationAdmin] Failed to create Squad:", err_7);
            }
        }
    }["GamificationAdmin.useCallback[handleCreateSquad]"], [
        client
    ]);
    const handleDeleteSquad = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleDeleteSquad]": async (squadId)=>{
            try {
                const { data: data_1 } = await client.models.Squad.get({
                    id: squadId
                });
                await client.models.Squad.delete({
                    id: squadId,
                    _version: data_1?._version
                });
            } catch (err_8) {
                console.error("[GamificationAdmin] Failed to delete Squad:", err_8);
            }
        }
    }["GamificationAdmin.useCallback[handleDeleteSquad]"], [
        client
    ]);
    const handleAddEasterEgg = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleAddEasterEgg]": async (egg_1)=>{
            try {
                // Build triggerValue based on type
                let triggerValue = "";
                switch(egg_1.type){
                    case "KEYWORD":
                        triggerValue = egg_1.keyword || "";
                        break;
                    case "SCHEDULE":
                        triggerValue = JSON.stringify({
                            start: egg_1.scheduleStart,
                            end: egg_1.scheduleEnd
                        });
                        break;
                    case "SECRET_LINK":
                        triggerValue = egg_1.secretLinkUnitId || "";
                        break;
                    case "ACHIEVEMENT":
                        triggerValue = egg_1.achievementRule || "";
                        break;
                }
                await client.models.EasterEgg.create({
                    trigger: TRIGGER_TYPE_TO_SCHEMA[egg_1.type] || "KEYWORD",
                    triggerValue,
                    xpReward: egg_1.xpReward || 50,
                    revealMessage: egg_1.message,
                    active: true,
                    cohortId: selectedSectionId || undefined,
                    badgeId: egg_1.badgeId || undefined
                });
            } catch (err_9) {
                console.error("[GamificationAdmin] Failed to create EasterEgg:", err_9);
            }
        }
    }["GamificationAdmin.useCallback[handleAddEasterEgg]"], [
        client,
        selectedSectionId
    ]);
    const handleDeleteEasterEgg = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleDeleteEasterEgg]": async (eggId)=>{
            try {
                const existing = easterEggs.find({
                    "GamificationAdmin.useCallback[handleDeleteEasterEgg].existing": (e)=>e.id === eggId
                }["GamificationAdmin.useCallback[handleDeleteEasterEgg].existing"]);
                await client.models.EasterEgg.delete({
                    id: eggId,
                    _version: existing?._version
                });
            } catch (err_10) {
                console.error("[GamificationAdmin] Failed to delete EasterEgg:", err_10);
            }
        }
    }["GamificationAdmin.useCallback[handleDeleteEasterEgg]"], [
        client,
        easterEggs
    ]);
    const handleDeleteBoss = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleDeleteBoss]": async (bossId)=>{
            try {
                const existing_0 = bossBattles.find({
                    "GamificationAdmin.useCallback[handleDeleteBoss].existing_0": (b_3)=>b_3.id === bossId
                }["GamificationAdmin.useCallback[handleDeleteBoss].existing_0"]);
                await client.models.GroupChallenge.delete({
                    id: bossId,
                    _version: existing_0?._version
                });
            } catch (err_11) {
                console.error("[GamificationAdmin] Failed to delete GroupChallenge:", err_11);
            }
        }
    }["GamificationAdmin.useCallback[handleDeleteBoss]"], [
        client,
        bossBattles
    ]);
    const handleAddBoss = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleAddBoss]": async (bossData)=>{
            try {
                await client.models.GroupChallenge.create({
                    title: bossData.title,
                    targetXP: bossData.targetXP,
                    currentXP: 0,
                    active: true,
                    bonusMultiplier: bossData.bonusMultiplier || 1.5,
                    startDate: bossData.startDate || undefined,
                    deadline: bossData.deadline || undefined,
                    setting: bossData.setting || "",
                    stakes: bossData.stakes || "",
                    cohortId: selectedSectionId || ""
                });
            } catch (err_12) {
                console.error("[GamificationAdmin] Failed to create GroupChallenge:", err_12);
            }
        }
    }["GamificationAdmin.useCallback[handleAddBoss]"], [
        client,
        selectedSectionId
    ]);
    const handleEditBoss = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleEditBoss]": async (bossId_0, bossData_0)=>{
            try {
                const existing_1 = bossBattles.find({
                    "GamificationAdmin.useCallback[handleEditBoss].existing_1": (b_4)=>b_4.id === bossId_0
                }["GamificationAdmin.useCallback[handleEditBoss].existing_1"]);
                await client.models.GroupChallenge.update({
                    id: bossId_0,
                    title: bossData_0.title,
                    targetXP: bossData_0.targetXP,
                    bonusMultiplier: bossData_0.bonusMultiplier || 1.5,
                    startDate: bossData_0.startDate || undefined,
                    deadline: bossData_0.deadline || undefined,
                    setting: bossData_0.setting || "",
                    stakes: bossData_0.stakes || "",
                    featuredImage: bossData_0.featuredImage || undefined,
                    _version: existing_1?._version
                });
            } catch (err_13) {
                console.error("[GamificationAdmin] Failed to update GroupChallenge:", err_13);
            }
        }
    }["GamificationAdmin.useCallback[handleEditBoss]"], [
        client,
        bossBattles
    ]);
    const handleToggleBossActive = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleToggleBossActive]": async (bossId_1, active)=>{
            try {
                const existing_2 = bossBattles.find({
                    "GamificationAdmin.useCallback[handleToggleBossActive].existing_2": (b_5)=>b_5.id === bossId_1
                }["GamificationAdmin.useCallback[handleToggleBossActive].existing_2"]);
                await client.models.GroupChallenge.update({
                    id: bossId_1,
                    active,
                    _version: existing_2?._version
                });
            } catch (err_14) {
                console.error("[GamificationAdmin] Failed to toggle GroupChallenge:", err_14);
            }
        }
    }["GamificationAdmin.useCallback[handleToggleBossActive]"], [
        client,
        bossBattles
    ]);
    const handleSaveXPConfig = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleSaveXPConfig]": async (newConfig)=>{
            try {
                // Convert XPTunerConfig shape into flat PlatformSettings fields
                const input = {
                    xpMultipliers: newConfig.multipliers ? JSON.stringify(newConfig.multipliers) : null,
                    dailyCap: newConfig.dailyCap ?? null,
                    weeklyCap: newConfig.weeklyCap ?? null,
                    levelThresholds: newConfig.levelConfig?.thresholds ? JSON.stringify(newConfig.levelConfig.thresholds) : null,
                    avatarUnlockConfig: newConfig.avatarUnlocks ? JSON.stringify(newConfig.avatarUnlocks) : null,
                    badgesEnabled: newConfig.enabled !== false
                };
                if (platformSettingsRecord?.id) {
                    // Update existing record
                    await client.models.PlatformSettings.update({
                        id: platformSettingsRecord.id,
                        ...input
                    });
                } else {
                    // Create the singleton record
                    await client.models.PlatformSettings.create(input);
                }
                setXpConfig(newConfig);
            } catch (err_15) {
                console.error("[GamificationAdmin] Failed to save XP config:", err_15);
            }
        }
    }["GamificationAdmin.useCallback[handleSaveXPConfig]"], [
        client,
        platformSettingsRecord
    ]);
    const handleToggleLinearLock = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleToggleLinearLock]": async (enabled)=>{
            if (!selectedSectionId) return;
            try {
                const section_0 = sections.find({
                    "GamificationAdmin.useCallback[handleToggleLinearLock].section_0": (s_1)=>s_1.id === selectedSectionId
                }["GamificationAdmin.useCallback[handleToggleLinearLock].section_0"]);
                await client.models.Section.update({
                    id: selectedSectionId,
                    linearLockEnabled: enabled,
                    _version: section_0?._version
                });
                setLinearLockEnabled(enabled);
            } catch (err_16) {
                console.error("[GamificationAdmin] Failed to toggle linear lock:", err_16);
            }
        }
    }["GamificationAdmin.useCallback[handleToggleLinearLock]"], [
        client,
        selectedSectionId,
        sections
    ]);
    const handleUpdateUnitLock = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleUpdateUnitLock]": async (unitId, requirements)=>{
            try {
                const { data: unit } = await client.models.Unit.get({
                    id: unitId
                });
                await client.models.Unit.update({
                    id: unitId,
                    requiredXP: requirements.requiredXP || null,
                    requiredBadgeId: requirements.requiredBadgeId || null,
                    requiredModuleCompletion: requirements.requiredModuleCompletion || null,
                    _version: unit?._version
                });
                setUnitLockRequirements({
                    "GamificationAdmin.useCallback[handleUpdateUnitLock]": (prev_3)=>({
                            ...prev_3,
                            [unitId]: requirements
                        })
                }["GamificationAdmin.useCallback[handleUpdateUnitLock]"]);
            } catch (err_17) {
                console.error("[GamificationAdmin] Failed to update unit lock:", err_17);
            }
        }
    }["GamificationAdmin.useCallback[handleUpdateUnitLock]"], [
        client
    ]);
    const handleClearUnitLock = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleClearUnitLock]": async (unitId_0)=>{
            try {
                const { data: unit_0 } = await client.models.Unit.get({
                    id: unitId_0
                });
                await client.models.Unit.update({
                    id: unitId_0,
                    requiredXP: null,
                    requiredBadgeId: null,
                    requiredModuleCompletion: null,
                    _version: unit_0?._version
                });
                setUnitLockRequirements({
                    "GamificationAdmin.useCallback[handleClearUnitLock]": (prev_4)=>{
                        const next_0 = {
                            ...prev_4
                        };
                        delete next_0[unitId_0];
                        return next_0;
                    }
                }["GamificationAdmin.useCallback[handleClearUnitLock]"]);
            } catch (err_18) {
                console.error("[GamificationAdmin] Failed to clear unit lock:", err_18);
            }
        }
    }["GamificationAdmin.useCallback[handleClearUnitLock]"], [
        client
    ]);
    // Copy gamification settings from another section
    const handleCopyFromSection = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "GamificationAdmin.useCallback[handleCopyFromSection]": async (sourceSectionId)=>{
            if (!selectedSectionId || !sourceSectionId) return;
            try {
                // 1. Copy Skills (reset progress, keep structure)
                const { data: sourceSkills } = await client.models.Skill.list({
                    filter: {
                        cohortId: {
                            eq: sourceSectionId
                        }
                    }
                });
                for (const skill_0 of sourceSkills || []){
                    await client.models.Skill.create({
                        title: skill_0.title,
                        description: skill_0.description,
                        prerequisites: skill_0.prerequisites,
                        xpReward: skill_0.xpReward,
                        cohortId: selectedSectionId,
                        unitIds: skill_0.unitIds || [],
                        minimumAccuracy: skill_0.minimumAccuracy || 70
                    });
                }
                // 2. Copy Easter Eggs (reset discoveries)
                const { data: sourceEggs } = await client.models.EasterEgg.list({
                    filter: {
                        cohortId: {
                            eq: sourceSectionId
                        }
                    }
                });
                for (const egg_2 of sourceEggs || []){
                    await client.models.EasterEgg.create({
                        trigger: egg_2.trigger,
                        triggerValue: egg_2.triggerValue,
                        xpReward: egg_2.xpReward,
                        badgeId: egg_2.badgeId,
                        revealMessage: egg_2.revealMessage,
                        active: true,
                        cohortId: selectedSectionId,
                        discoveries: []
                    });
                }
                // 3. Copy Group Challenges (reset currentXP and contributions)
                const { data: sourceChallenges } = await client.models.GroupChallenge.list({
                    filter: {
                        cohortId: {
                            eq: sourceSectionId
                        }
                    }
                });
                for (const challenge of sourceChallenges || []){
                    await client.models.GroupChallenge.create({
                        title: challenge.title,
                        targetXP: challenge.targetXP,
                        currentXP: 0,
                        deadline: challenge.deadline,
                        active: true,
                        bonusMultiplier: challenge.bonusMultiplier,
                        setting: challenge.setting,
                        stakes: challenge.stakes,
                        systemPromptSeed: challenge.systemPromptSeed,
                        chapterOrder: challenge.chapterOrder,
                        cohortId: selectedSectionId,
                        contributions: []
                    });
                }
            } catch (err_19) {
                console.error("[GamificationAdmin] Copy settings failed:", err_19);
            }
        }
    }["GamificationAdmin.useCallback[handleCopyFromSection]"], [
        client,
        selectedSectionId
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    marginTop: "1rem",
                    marginBottom: "3rem",
                    padding: "1rem",
                    maxWidth: "80rem",
                    margin: "1rem auto 3rem"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$InstructorGamificationPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstructorGamificationPanel"], {
                    sections: sectionOptions,
                    selectedSectionId: selectedSectionId,
                    onSectionChange: handleSectionChange,
                    availableUnits: availableUnits,
                    availableBadges: availableBadges,
                    skills: skills,
                    campaigns: campaigns,
                    squads: squads,
                    easterEggs: easterEggs,
                    bossBattles: bossBattles,
                    onAddSkill: handleAddSkill,
                    onDeleteSkill: handleDeleteSkill,
                    onPrerequisiteChange: handlePrerequisiteChange,
                    onSaveCampaign: handleSaveCampaign,
                    onDeleteCampaign: handleDeleteCampaign,
                    onGenerateCampaign: handleGenerateCampaign,
                    onCreateSquad: handleCreateSquad,
                    onDeleteSquad: handleDeleteSquad,
                    onAddEasterEgg: handleAddEasterEgg,
                    onDeleteEasterEgg: handleDeleteEasterEgg,
                    onAddBoss: handleAddBoss,
                    onEditBoss: handleEditBoss,
                    onDeleteBoss: handleDeleteBoss,
                    onToggleBossActive: handleToggleBossActive,
                    badgeOverrides: badgeOverrides,
                    customBadges: customBadges,
                    onBadgeOverrideChange: handleBadgeOverrideChange,
                    onBadgeOverrideReset: handleBadgeOverrideReset,
                    onAddCustomBadge: handleAddCustomBadge,
                    onDeleteCustomBadge: handleDeleteCustomBadge,
                    xpConfig: xpConfig || {},
                    onSaveXPConfig: handleSaveXPConfig,
                    linearLockEnabled: linearLockEnabled,
                    onToggleLinearLock: handleToggleLinearLock,
                    unitLockRequirements: unitLockRequirements,
                    onUpdateUnitLock: handleUpdateUnitLock,
                    onClearUnitLock: handleClearUnitLock,
                    onCopyFromSection: handleCopyFromSection
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/admin/settings/page.tsx",
                    lineNumber: 666,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/[locale]/admin/settings/page.tsx",
                lineNumber: 659,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    maxWidth: "80rem",
                    margin: "0 auto 3rem",
                    padding: "1rem"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AdminAIConfig, {
                    platformSettings: platformSettingsRecord,
                    client: client
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/admin/settings/page.tsx",
                    lineNumber: 673,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/[locale]/admin/settings/page.tsx",
                lineNumber: 668,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(GamificationAdmin, "ev3iI/q+9fZ5wgU9kPlj1mYcWO0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSkillTree"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCampaign"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSquad"]
    ];
});
_c = GamificationAdmin;
// ============================================================================
// Admin AI Configuration — reads/writes PlatformSettings agent fields
// ============================================================================
function AdminAIConfig({ platformSettings, client }) {
    _s1();
    const [values, setValues] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({});
    const [saving, setSaving] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    // Hydrate from PlatformSettings record
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "AdminAIConfig.useEffect": ()=>{
            if (!platformSettings) return;
            setValues({
                defaultAIModel: platformSettings.defaultAIModel || "gpt-4o",
                kaiModel: platformSettings.kaiModel || "",
                sageModel: platformSettings.sageModel || "",
                kaiTemperature: platformSettings.kaiTemperature ?? null,
                sageTemperature: platformSettings.sageTemperature ?? null,
                kaiMaxTokens: platformSettings.kaiMaxTokens ?? null,
                sageMaxTokens: platformSettings.sageMaxTokens ?? null,
                agentMaxSteps: platformSettings.agentMaxSteps ?? null,
                kaiMaxSteps: platformSettings.kaiMaxSteps ?? null,
                sageMaxSteps: platformSettings.sageMaxSteps ?? null,
                searchThreshold: platformSettings.searchThreshold ?? null,
                searchDefaultLimit: platformSettings.searchDefaultLimit ?? null,
                memoryEnabled: platformSettings.memoryEnabled ?? true,
                memorySummarizationModel: platformSettings.memorySummarizationModel || "gpt-4o-mini",
                kaiEnabled: platformSettings.kaiEnabled ?? true,
                sageEnabled: platformSettings.sageEnabled ?? true,
                kaiSystemPromptOverride: platformSettings.kaiSystemPromptOverride || "",
                sageSystemPromptOverride: platformSettings.sageSystemPromptOverride || "",
                systemPromptBudget: platformSettings.systemPromptBudget ?? null,
                toolResultBudget: platformSettings.toolResultBudget ?? null,
                totalTurnBudget: platformSettings.totalTurnBudget ?? null,
                kaiSystemPromptBudget: platformSettings.kaiSystemPromptBudget ?? null,
                sageSystemPromptBudget: platformSettings.sageSystemPromptBudget ?? null,
                kaiToolResultBudget: platformSettings.kaiToolResultBudget ?? null,
                sageToolResultBudget: platformSettings.sageToolResultBudget ?? null,
                kaiTotalTurnBudget: platformSettings.kaiTotalTurnBudget ?? null,
                sageTotalTurnBudget: platformSettings.sageTotalTurnBudget ?? null
            });
        }
    }["AdminAIConfig.useEffect"], [
        platformSettings
    ]);
    const handleSave = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "AdminAIConfig.useCallback[handleSave]": async ()=>{
            if (!platformSettings?.id || !client?.models?.PlatformSettings) return;
            setSaving(true);
            try {
                const updatePayload = {
                    id: platformSettings.id,
                    _version: platformSettings._version
                };
                // Only include non-default values
                if (values.defaultAIModel) updatePayload.defaultAIModel = values.defaultAIModel;
                if (values.kaiModel) updatePayload.kaiModel = values.kaiModel;
                if (values.sageModel) updatePayload.sageModel = values.sageModel;
                if (values.kaiTemperature != null) updatePayload.kaiTemperature = values.kaiTemperature;
                if (values.sageTemperature != null) updatePayload.sageTemperature = values.sageTemperature;
                if (values.kaiMaxTokens != null) updatePayload.kaiMaxTokens = values.kaiMaxTokens;
                if (values.sageMaxTokens != null) updatePayload.sageMaxTokens = values.sageMaxTokens;
                if (values.agentMaxSteps != null) updatePayload.agentMaxSteps = values.agentMaxSteps;
                if (values.kaiMaxSteps != null) updatePayload.kaiMaxSteps = values.kaiMaxSteps;
                if (values.sageMaxSteps != null) updatePayload.sageMaxSteps = values.sageMaxSteps;
                if (values.searchThreshold != null) updatePayload.searchThreshold = values.searchThreshold;
                if (values.searchDefaultLimit != null) updatePayload.searchDefaultLimit = values.searchDefaultLimit;
                updatePayload.memoryEnabled = values.memoryEnabled ?? true;
                if (values.memorySummarizationModel) updatePayload.memorySummarizationModel = values.memorySummarizationModel;
                updatePayload.kaiEnabled = values.kaiEnabled ?? true;
                updatePayload.sageEnabled = values.sageEnabled ?? true;
                if (values.kaiSystemPromptOverride) updatePayload.kaiSystemPromptOverride = values.kaiSystemPromptOverride;
                if (values.sageSystemPromptOverride) updatePayload.sageSystemPromptOverride = values.sageSystemPromptOverride;
                // Token budgets
                if (values.systemPromptBudget != null) updatePayload.systemPromptBudget = values.systemPromptBudget;
                if (values.toolResultBudget != null) updatePayload.toolResultBudget = values.toolResultBudget;
                if (values.totalTurnBudget != null) updatePayload.totalTurnBudget = values.totalTurnBudget;
                if (values.kaiSystemPromptBudget != null) updatePayload.kaiSystemPromptBudget = values.kaiSystemPromptBudget;
                if (values.sageSystemPromptBudget != null) updatePayload.sageSystemPromptBudget = values.sageSystemPromptBudget;
                if (values.kaiToolResultBudget != null) updatePayload.kaiToolResultBudget = values.kaiToolResultBudget;
                if (values.sageToolResultBudget != null) updatePayload.sageToolResultBudget = values.sageToolResultBudget;
                if (values.kaiTotalTurnBudget != null) updatePayload.kaiTotalTurnBudget = values.kaiTotalTurnBudget;
                if (values.sageTotalTurnBudget != null) updatePayload.sageTotalTurnBudget = values.sageTotalTurnBudget;
                await client.models.PlatformSettings.update(updatePayload);
            } catch (err) {
                console.error("[AdminAIConfig] Save failed:", err);
            } finally{
                setSaving(false);
            }
        }
    }["AdminAIConfig.useCallback[handleSave]"], [
        platformSettings,
        client,
        values
    ]);
    if (!platformSettings) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            children: "Loading platform settings..."
        }, void 0, false, {
            fileName: "[project]/app/[locale]/admin/settings/page.tsx",
            lineNumber: 771,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AIAgentConfig$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AIAgentConfig"], {
        values: values,
        onChange: setValues,
        onSave: handleSave,
        saving: saving,
        mode: "platform"
    }, void 0, false, {
        fileName: "[project]/app/[locale]/admin/settings/page.tsx",
        lineNumber: 775,
        columnNumber: 10
    }, this);
}
_s1(AdminAIConfig, "cdtkdduuKp+J70PzVbWD9GvIRRs=");
_c1 = AdminAIConfig;
function WrappedPage() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "51695cdd746718397a1f9c38804db41b5453e91d4bb379f88168bc8ccd9fdca7") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "51695cdd746718397a1f9c38804db41b5453e91d4bb379f88168bc8ccd9fdca7";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$locale$5d2f$admin$2f$_components$2f$AdminRouteGuard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationProviderWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationProviderWrapper"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(GamificationAdmin, {}, void 0, false, {
                        fileName: "[project]/app/[locale]/admin/settings/page.tsx",
                        lineNumber: 787,
                        columnNumber: 73
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/admin/settings/page.tsx",
                    lineNumber: 787,
                    columnNumber: 44
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/[locale]/admin/settings/page.tsx",
                lineNumber: 787,
                columnNumber: 27
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/admin/settings/page.tsx",
            lineNumber: 787,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c2 = WrappedPage;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "GamificationAdmin");
__turbopack_context__.k.register(_c1, "AdminAIConfig");
__turbopack_context__.k.register(_c2, "WrappedPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_0l7569v._.js.map