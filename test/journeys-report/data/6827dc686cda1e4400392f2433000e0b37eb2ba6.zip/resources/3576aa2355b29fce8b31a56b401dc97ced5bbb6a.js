(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0es.6a_._.js","static/chunks/node_modules_12yunkc._.js","static/chunks/node_modules_@xyflow_react_dist_style_0iupz4v.css"],
    source: "dynamic"
});
