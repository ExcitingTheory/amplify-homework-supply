(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/yjs/ChatCollaborationProvider.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * ChatCollaborationProvider — Specialized Yjs provider for collaborative chat rooms.
 *
 * Supports two room types:
 * - Section chat (`chat-section-{sectionId}`) — shared by all section members,
 *   with topics scoped to section/unit/workbook contexts
 * - Squad chat (`chat-squad-{squadId}`) — squad members only
 *
 * Y.Doc structure:
 * - `meta` Y.Map — room metadata (name, type, createdAt)
 * - `topics` Y.Map — topic objects keyed by topicId
 * - `threads` Y.Map — each key is a topicId, value references a Y.Array of messages
 * - Awareness — online/typing presence
 *
 * @module ChatCollaborationProvider
 */ __turbopack_context__.s([
    "ChatCollaborationProvider",
    ()=>ChatCollaborationProvider,
    "extractMentions",
    ()=>extractMentions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/YjsProvider.ts [app-client] (ecmascript)");
;
class ChatCollaborationProvider extends __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YjsDocProvider"] {
    roomType;
    roomId;
    user;
    metaMap;
    topicsMap;
    constructor(config){
        const docName = `chat-${config.roomType}-${config.roomId}`;
        super({
            ...config,
            docName
        });
        this.roomType = config.roomType;
        this.roomId = config.roomId;
        this.user = config.user;
        this.metaMap = this.getMap("meta");
        this.topicsMap = this.getMap("topics");
        this.initializeAwareness();
    }
    // ========================================================================
    // Awareness
    // ========================================================================
    initializeAwareness() {
        const awareness = this.getAwareness();
        awareness.setLocalState({
            user: this.user,
            typing: false,
            activeTopic: null
        });
    }
    setTyping(typing) {
        const awareness = this.getAwareness();
        const currentState = awareness.getLocalState();
        awareness.setLocalState({
            ...currentState,
            typing
        });
    }
    setActiveTopic(topicId) {
        const awareness = this.getAwareness();
        const currentState = awareness.getLocalState();
        awareness.setLocalState({
            ...currentState,
            activeTopic: topicId
        });
    }
    // ========================================================================
    // Room Meta
    // ========================================================================
    initializeRoom(name) {
        if (this.metaMap.get("createdAt")) return; // Already initialized
        this.metaMap.set("name", name);
        this.metaMap.set("roomType", this.roomType);
        this.metaMap.set("roomId", this.roomId);
        this.metaMap.set("createdAt", new Date().toISOString());
    }
    getRoomMeta() {
        return {
            name: this.metaMap.get("name") || "",
            roomType: this.metaMap.get("roomType") || this.roomType,
            roomId: this.metaMap.get("roomId") || this.roomId,
            createdAt: this.metaMap.get("createdAt") || ""
        };
    }
    // ========================================================================
    // Topics
    // ========================================================================
    createTopic(name, scope) {
        const topic = {
            id: crypto.randomUUID(),
            name: name.startsWith("#") ? name : `#${name}`,
            scope,
            createdBy: this.user.username,
            createdByName: this.user.displayName,
            createdAt: new Date().toISOString(),
            pinned: false,
            archived: false
        };
        this.topicsMap.set(topic.id, topic);
        // Initialize the thread array for this topic
        this.getDoc().getArray(`thread-${topic.id}`);
        return topic;
    }
    getTopic(topicId) {
        return this.topicsMap.get(topicId) || null;
    }
    getTopics() {
        const topics = [];
        this.topicsMap.forEach((value)=>{
            if (value && !value.archived) {
                topics.push(value);
            }
        });
        return topics;
    }
    getTopicsByScope(scope) {
        return this.getTopics().filter((t)=>t.scope === scope);
    }
    pinTopic(topicId, pinned) {
        const topic = this.topicsMap.get(topicId);
        if (topic) {
            this.topicsMap.set(topicId, {
                ...topic,
                pinned
            });
        }
    }
    archiveTopic(topicId) {
        const topic = this.topicsMap.get(topicId);
        if (topic) {
            this.topicsMap.set(topicId, {
                ...topic,
                archived: true
            });
        }
    }
    // ========================================================================
    // Messages / Threads
    // ========================================================================
    getThreadArray(topicId) {
        return this.getDoc().getArray(`thread-${topicId}`);
    }
    sendMessage(topicId, content, parentId) {
        const mentions = extractMentions(content);
        const message = {
            id: crypto.randomUUID(),
            parentId: parentId || null,
            authorId: this.user.username,
            authorName: this.user.displayName,
            content,
            contentJson: null,
            mentions,
            createdAt: new Date().toISOString(),
            editedAt: null,
            reactions: {},
            isStreaming: false
        };
        const threadArray = this.getThreadArray(topicId);
        threadArray.push([
            message
        ]);
        return message;
    }
    editMessage(topicId, messageId, newContent, contentJson) {
        const threadArray = this.getThreadArray(topicId);
        const items = Array.from(threadArray);
        const index = items.findIndex((m)=>m.id === messageId);
        if (index === -1) return;
        if (items[index].authorId !== this.user.username) return; // Can only edit own messages
        const updated = {
            ...items[index],
            content: newContent,
            contentJson: contentJson ?? items[index].contentJson,
            mentions: extractMentions(newContent),
            editedAt: new Date().toISOString()
        };
        this.getDoc().transact(()=>{
            threadArray.delete(index, 1);
            threadArray.insert(index, [
                updated
            ]);
        });
    }
    deleteMessage(topicId, messageId) {
        const threadArray = this.getThreadArray(topicId);
        const items = Array.from(threadArray);
        const index = items.findIndex((m)=>m.id === messageId);
        if (index === -1) return;
        if (items[index].authorId !== this.user.username) return; // Can only delete own messages
        threadArray.delete(index, 1);
    }
    addReaction(topicId, messageId, emoji) {
        const threadArray = this.getThreadArray(topicId);
        const items = Array.from(threadArray);
        const index = items.findIndex((m)=>m.id === messageId);
        if (index === -1) return;
        const message = items[index];
        const reactions = {
            ...message.reactions
        };
        const users = reactions[emoji] || [];
        if (users.includes(this.user.username)) {
            // Remove reaction
            reactions[emoji] = users.filter((u)=>u !== this.user.username);
            if (reactions[emoji].length === 0) delete reactions[emoji];
        } else {
            // Add reaction
            reactions[emoji] = [
                ...users,
                this.user.username
            ];
        }
        const updated = {
            ...message,
            reactions
        };
        this.getDoc().transact(()=>{
            threadArray.delete(index, 1);
            threadArray.insert(index, [
                updated
            ]);
        });
    }
    getMessages(topicId) {
        return Array.from(this.getThreadArray(topicId));
    }
    getThreadReplies(topicId, parentId) {
        return this.getMessages(topicId).filter((m)=>m.parentId === parentId);
    }
    getTopLevelMessages(topicId) {
        return this.getMessages(topicId).filter((m)=>m.parentId === null);
    }
    // ========================================================================
    // Accessors
    // ========================================================================
    getMetaMap() {
        return this.metaMap;
    }
    getTopicsMap() {
        return this.topicsMap;
    }
    getRoomId() {
        return this.roomId;
    }
    getRoomType() {
        return this.roomType;
    }
    getUser() {
        return this.user;
    }
}
function extractMentions(content) {
    const mentions = [];
    // Match @kai
    const kaiMatch = content.match(/@kai\b/gi);
    if (kaiMatch) mentions.push("@kai");
    // Match @"Name With Spaces" or @username
    const userMatches = content.matchAll(/@"([^"]+)"|@(\w+)/g);
    for (const match of userMatches){
        const name = match[1] || match[2];
        if (name.toLowerCase() !== "kai") {
            mentions.push(`@${name}`);
        }
    }
    return [
        ...new Set(mentions)
    ];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/yjs/chatHooks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useChatPresence",
    ()=>useChatPresence,
    "useChatRoom",
    ()=>useChatRoom,
    "useChatThread",
    ()=>useChatThread,
    "useChatTopics",
    ()=>useChatTopics
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * React hooks for collaborative chat rooms.
 *
 * Provides reactive state bindings for topics, threads, messages,
 * and presence from a ChatCollaborationProvider.
 *
 * @module chatHooks
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$ChatCollaborationProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/ChatCollaborationProvider.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
;
;
;
function useChatRoom(options) {
    _s();
    const { roomType, roomId, user, wsUrl, connect = true, persistence = true } = options || {};
    const providerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isConnected, setIsConnected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isSynced, setIsSynced] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChatRoom.useEffect": ()=>{
            if (!options || !roomId || !user?.username) return;
            const provider = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$ChatCollaborationProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChatCollaborationProvider"]({
                roomType,
                roomId,
                user,
                wsUrl,
                connect,
                persistence
            });
            providerRef.current = provider;
            // Track connection & sync status
            const wsProvider = provider.wsProvider;
            if (wsProvider) {
                wsProvider.on("status", {
                    "useChatRoom.useEffect": ({ status })=>{
                        setIsConnected(status === "connected");
                    }
                }["useChatRoom.useEffect"]);
                wsProvider.on("sync", {
                    "useChatRoom.useEffect": (synced)=>{
                        setIsSynced(synced);
                    }
                }["useChatRoom.useEffect"]);
            }
            return ({
                "useChatRoom.useEffect": ()=>{
                    provider.destroy();
                    providerRef.current = null;
                    setIsConnected(false);
                    setIsSynced(false);
                }
            })["useChatRoom.useEffect"];
        }
    }["useChatRoom.useEffect"], [
        roomType,
        roomId,
        user?.username
    ]);
    return {
        provider: providerRef.current,
        isConnected,
        isSynced
    };
}
_s(useChatRoom, "9tDjhjCOhEc5S8IFYrLfDcYxPb8=");
function useChatTopics(provider, scope) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [topics, setTopics] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== provider || $[3] !== scope) {
        t1 = ({
            "useChatTopics[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const topicsMap = provider.getTopicsMap();
                const handleChange = {
                    "useChatTopics[useEffect() > handleChange]": ()=>{
                        const allTopics = provider.getTopics();
                        if (scope) {
                            setTopics(allTopics.filter({
                                "useChatTopics[useEffect() > handleChange > allTopics.filter()]": (t)=>t.scope === "section" || t.scope === scope
                            }["useChatTopics[useEffect() > handleChange > allTopics.filter()]"]));
                        } else {
                            setTopics(allTopics);
                        }
                    }
                }["useChatTopics[useEffect() > handleChange]"];
                handleChange();
                topicsMap.observeDeep(handleChange);
                return ()=>{
                    topicsMap.unobserveDeep(handleChange);
                };
            }
        })["useChatTopics[useEffect()]"];
        t2 = [
            provider,
            scope
        ];
        $[2] = provider;
        $[3] = scope;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[6] !== provider) {
        t3 = ({
            "useChatTopics[createTopic]": (name, topicScope)=>{
                if (!provider) {
                    return null;
                }
                return provider.createTopic(name, topicScope);
            }
        })["useChatTopics[createTopic]"];
        $[6] = provider;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    const createTopic = t3;
    let t4;
    if ($[8] !== provider) {
        t4 = ({
            "useChatTopics[pinTopic]": (topicId, pinned)=>{
                provider?.pinTopic(topicId, pinned);
            }
        })["useChatTopics[pinTopic]"];
        $[8] = provider;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    const pinTopic = t4;
    let t5;
    if ($[10] !== provider) {
        t5 = ({
            "useChatTopics[archiveTopic]": (topicId_0)=>{
                provider?.archiveTopic(topicId_0);
            }
        })["useChatTopics[archiveTopic]"];
        $[10] = provider;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    const archiveTopic = t5;
    let t6;
    if ($[12] !== archiveTopic || $[13] !== createTopic || $[14] !== pinTopic || $[15] !== topics) {
        t6 = {
            topics,
            createTopic,
            pinTopic,
            archiveTopic
        };
        $[12] = archiveTopic;
        $[13] = createTopic;
        $[14] = pinTopic;
        $[15] = topics;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    return t6;
}
_s1(useChatTopics, "Z4rPjMfp4RLx3ToDgpfq685D3kI=");
function useChatThread(provider, topicId) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(30);
    if ($[0] !== "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d") {
        for(let $i = 0; $i < 30; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== provider || $[3] !== topicId) {
        t1 = ({
            "useChatThread[useEffect()]": ()=>{
                if (!provider || !topicId) {
                    setMessages([]);
                    return;
                }
                const threadArray = provider.getThreadArray(topicId);
                const handleChange = {
                    "useChatThread[useEffect() > handleChange]": ()=>{
                        setMessages(Array.from(threadArray));
                    }
                }["useChatThread[useEffect() > handleChange]"];
                handleChange();
                threadArray.observe(handleChange);
                provider.setActiveTopic(topicId);
                return ()=>{
                    threadArray.unobserve(handleChange);
                    provider.setActiveTopic(null);
                };
            }
        })["useChatThread[useEffect()]"];
        t2 = [
            provider,
            topicId
        ];
        $[2] = provider;
        $[3] = topicId;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[6] !== messages) {
        t3 = messages.filter(_useChatThreadMessagesFilter);
        $[6] = messages;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    const topLevelMessages = t3;
    let t4;
    if ($[8] !== provider || $[9] !== topicId) {
        t4 = ({
            "useChatThread[sendMessage]": (content, parentId)=>{
                if (!provider || !topicId) {
                    return null;
                }
                return provider.sendMessage(topicId, content, parentId);
            }
        })["useChatThread[sendMessage]"];
        $[8] = provider;
        $[9] = topicId;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    const sendMessage = t4;
    let t5;
    if ($[11] !== provider || $[12] !== topicId) {
        t5 = ({
            "useChatThread[editMessage]": (messageId, content_0, contentJson)=>{
                if (!provider || !topicId) {
                    return;
                }
                provider.editMessage(topicId, messageId, content_0, contentJson);
            }
        })["useChatThread[editMessage]"];
        $[11] = provider;
        $[12] = topicId;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    const editMessage = t5;
    let t6;
    if ($[14] !== provider || $[15] !== topicId) {
        t6 = ({
            "useChatThread[deleteMessage]": (messageId_0)=>{
                if (!provider || !topicId) {
                    return;
                }
                provider.deleteMessage(topicId, messageId_0);
            }
        })["useChatThread[deleteMessage]"];
        $[14] = provider;
        $[15] = topicId;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    const deleteMessage = t6;
    let t7;
    if ($[17] !== provider || $[18] !== topicId) {
        t7 = ({
            "useChatThread[addReaction]": (messageId_1, emoji)=>{
                if (!provider || !topicId) {
                    return;
                }
                provider.addReaction(topicId, messageId_1, emoji);
            }
        })["useChatThread[addReaction]"];
        $[17] = provider;
        $[18] = topicId;
        $[19] = t7;
    } else {
        t7 = $[19];
    }
    const addReaction = t7;
    let t8;
    if ($[20] !== messages) {
        t8 = ({
            "useChatThread[getReplies]": (parentId_0)=>messages.filter({
                    "useChatThread[getReplies > messages.filter()]": (m_0)=>m_0.parentId === parentId_0
                }["useChatThread[getReplies > messages.filter()]"])
        })["useChatThread[getReplies]"];
        $[20] = messages;
        $[21] = t8;
    } else {
        t8 = $[21];
    }
    const getReplies = t8;
    let t9;
    if ($[22] !== addReaction || $[23] !== deleteMessage || $[24] !== editMessage || $[25] !== getReplies || $[26] !== messages || $[27] !== sendMessage || $[28] !== topLevelMessages) {
        t9 = {
            messages,
            topLevelMessages,
            sendMessage,
            editMessage,
            deleteMessage,
            addReaction,
            getReplies
        };
        $[22] = addReaction;
        $[23] = deleteMessage;
        $[24] = editMessage;
        $[25] = getReplies;
        $[26] = messages;
        $[27] = sendMessage;
        $[28] = topLevelMessages;
        $[29] = t9;
    } else {
        t9 = $[29];
    }
    return t9;
}
_s2(useChatThread, "dMiLn6t5LC6b/+LW9v6mSM5lssk=");
/**
 * Hook for chat room presence — online users, typing indicators, active topics.
 */ function _useChatThreadMessagesFilter(m) {
    return m.parentId === null;
}
function useChatPresence(provider, topicId) {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [onlineUsers, setOnlineUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [typingUsers, setTypingUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const [usersInTopic, setUsersInTopic] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    let t4;
    if ($[4] !== provider || $[5] !== topicId) {
        t3 = ({
            "useChatPresence[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const awareness = provider.getAwareness();
                const handleChange = {
                    "useChatPresence[useEffect() > handleChange]": ()=>{
                        const online = [];
                        const typing = [];
                        const inTopic = [];
                        awareness.getStates().forEach({
                            "useChatPresence[useEffect() > handleChange > (anonymous)()]": (state, clientId)=>{
                                if (clientId === awareness.clientID) {
                                    return;
                                }
                                const peerUser = state.user;
                                if (!peerUser) {
                                    return;
                                }
                                online.push(peerUser);
                                if (state.typing) {
                                    typing.push(peerUser);
                                }
                                if (topicId && state.activeTopic === topicId) {
                                    inTopic.push(peerUser);
                                }
                            }
                        }["useChatPresence[useEffect() > handleChange > (anonymous)()]"]);
                        setOnlineUsers(online);
                        setTypingUsers(typing);
                        setUsersInTopic(inTopic);
                    }
                }["useChatPresence[useEffect() > handleChange]"];
                handleChange();
                awareness.on("change", handleChange);
                return ()=>{
                    awareness.off("change", handleChange);
                };
            }
        })["useChatPresence[useEffect()]"];
        t4 = [
            provider,
            topicId
        ];
        $[4] = provider;
        $[5] = topicId;
        $[6] = t3;
        $[7] = t4;
    } else {
        t3 = $[6];
        t4 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    let t5;
    if ($[8] !== onlineUsers || $[9] !== typingUsers || $[10] !== usersInTopic) {
        t5 = {
            onlineUsers,
            typingUsers,
            usersInTopic
        };
        $[8] = onlineUsers;
        $[9] = typingUsers;
        $[10] = usersInTopic;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    return t5;
}
_s3(useChatPresence, "895iuv1s1S0fDfDisjcEyQGP4Dc=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/TopicList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TopicList",
    ()=>TopicList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * TopicList — Displays #topics with create, pin, and archive actions.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemButton/ListItemButton.js [app-client] (ecmascript) <export default as ListItemButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Add.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PushPin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PushPin.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function TopicList(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(45);
    if ($[0] !== "b0a3d6662286d90f8c1e1a25fb35dc8c769e23666b7b4ad2466c97a831eaab3a") {
        for(let $i = 0; $i < 45; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b0a3d6662286d90f8c1e1a25fb35dc8c769e23666b7b4ad2466c97a831eaab3a";
    }
    const { topics, activeTopicId, onSelectTopic, onCreateTopic, onPinTopic } = t0;
    const [showInput, setShowInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [newTopicName, setNewTopicName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let T0;
    let T1;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    if ($[1] !== activeTopicId || $[2] !== newTopicName || $[3] !== onCreateTopic || $[4] !== onPinTopic || $[5] !== onSelectTopic || $[6] !== showInput || $[7] !== topics) {
        const sortedTopics = [
            ...topics
        ].sort(_TopicListAnonymous);
        let t8;
        if ($[17] !== newTopicName || $[18] !== onCreateTopic) {
            const handleCreate = {
                "TopicList[handleCreate]": ()=>{
                    const name = newTopicName.trim();
                    if (!name) {
                        return;
                    }
                    onCreateTopic(name);
                    setNewTopicName("");
                    setShowInput(false);
                }
            }["TopicList[handleCreate]"];
            t8 = ({
                "TopicList[handleKeyDown]": (e)=>{
                    if (e.key === "Enter") {
                        e.preventDefault();
                        handleCreate();
                    }
                    if (e.key === "Escape") {
                        setShowInput(false);
                        setNewTopicName("");
                    }
                }
            })["TopicList[handleKeyDown]"];
            $[17] = newTopicName;
            $[18] = onCreateTopic;
            $[19] = t8;
        } else {
            t8 = $[19];
        }
        const handleKeyDown = t8;
        T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"];
        if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = {
                display: "flex",
                flexDirection: "column",
                height: "100%"
            };
            $[20] = t5;
        } else {
            t5 = $[20];
        }
        let t10;
        let t9;
        if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = {
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                p: 1,
                px: 2
            };
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "subtitle2",
                color: "text.secondary",
                children: "Topics"
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/TopicList.tsx",
                lineNumber: 111,
                columnNumber: 13
            }, this);
            $[21] = t10;
            $[22] = t9;
        } else {
            t10 = $[21];
            t9 = $[22];
        }
        if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t9,
                children: [
                    t10,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                        size: "small",
                        onClick: {
                            "TopicList[<IconButton>.onClick]": ()=>setShowInput(true)
                        }["TopicList[<IconButton>.onClick]"],
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            fontSize: "small"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Chat/TopicList.tsx",
                            lineNumber: 121,
                            columnNumber: 47
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/TopicList.tsx",
                        lineNumber: 119,
                        columnNumber: 30
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Chat/TopicList.tsx",
                lineNumber: 119,
                columnNumber: 12
            }, this);
            $[23] = t6;
        } else {
            t6 = $[23];
        }
        if ($[24] !== handleKeyDown || $[25] !== newTopicName || $[26] !== showInput) {
            t7 = showInput && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    px: 2,
                    pb: 1
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                    size: "small",
                    fullWidth: true,
                    autoFocus: true,
                    placeholder: "#new-topic",
                    value: newTopicName,
                    onChange: {
                        "TopicList[<TextField>.onChange]": (e_0)=>setNewTopicName(e_0.target.value)
                    }["TopicList[<TextField>.onChange]"],
                    onKeyDown: handleKeyDown,
                    onBlur: {
                        "TopicList[<TextField>.onBlur]": ()=>{
                            if (!newTopicName.trim()) {
                                setShowInput(false);
                            }
                        }
                    }["TopicList[<TextField>.onBlur]"],
                    slotProps: {
                        input: {
                            sx: {
                                fontSize: "0.875rem"
                            }
                        }
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/TopicList.tsx",
                    lineNumber: 130,
                    columnNumber: 10
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/TopicList.tsx",
                lineNumber: 127,
                columnNumber: 25
            }, this);
            $[24] = handleKeyDown;
            $[25] = newTopicName;
            $[26] = showInput;
            $[27] = t7;
        } else {
            t7 = $[27];
        }
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"];
        t1 = true;
        if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = {
                flex: 1,
                overflow: "auto",
                py: 0
            };
            $[28] = t2;
        } else {
            t2 = $[28];
        }
        t3 = sortedTopics.length === 0 && !showInput && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                secondary: "No topics yet. Create one to start chatting.",
                secondaryTypographyProps: {
                    variant: "caption"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/TopicList.tsx",
                lineNumber: 164,
                columnNumber: 63
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/TopicList.tsx",
            lineNumber: 164,
            columnNumber: 53
        }, this);
        let t11;
        if ($[29] !== activeTopicId || $[30] !== onPinTopic || $[31] !== onSelectTopic) {
            t11 = ({
                "TopicList[sortedTopics.map()]": (topic)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                        disablePadding: true,
                        secondaryAction: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                gap: 0
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                size: "small",
                                onClick: {
                                    "TopicList[sortedTopics.map() > <IconButton>.onClick]": (e_1)=>{
                                        e_1.stopPropagation();
                                        onPinTopic(topic.id, !topic.pinned);
                                    }
                                }["TopicList[sortedTopics.map() > <IconButton>.onClick]"],
                                sx: {
                                    opacity: topic.pinned ? 1 : 0.3
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PushPin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    sx: {
                                        fontSize: 14
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Chat/TopicList.tsx",
                                    lineNumber: 180,
                                    columnNumber: 14
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Chat/TopicList.tsx",
                                lineNumber: 173,
                                columnNumber: 12
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Chat/TopicList.tsx",
                            lineNumber: 170,
                            columnNumber: 115
                        }, this),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__["ListItemButton"], {
                            selected: topic.id === activeTopicId,
                            onClick: {
                                "TopicList[sortedTopics.map() > <ListItemButton>.onClick]": ()=>onSelectTopic(topic.id)
                            }["TopicList[sortedTopics.map() > <ListItemButton>.onClick]"],
                            sx: {
                                py: 0.5
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                primary: topic.name,
                                primaryTypographyProps: {
                                    variant: "body2",
                                    fontWeight: topic.pinned ? 600 : 400
                                },
                                secondary: topic.scope !== "section" && topic.scope !== "squad" ? topic.scope.split(":")[0] : undefined,
                                secondaryTypographyProps: {
                                    variant: "caption"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Chat/TopicList.tsx",
                                lineNumber: 186,
                                columnNumber: 14
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Chat/TopicList.tsx",
                            lineNumber: 182,
                            columnNumber: 39
                        }, this)
                    }, topic.id, false, {
                        fileName: "[project]/src/components/Chat/TopicList.tsx",
                        lineNumber: 170,
                        columnNumber: 51
                    }, this)
            })["TopicList[sortedTopics.map()]"];
            $[29] = activeTopicId;
            $[30] = onPinTopic;
            $[31] = onSelectTopic;
            $[32] = t11;
        } else {
            t11 = $[32];
        }
        t4 = sortedTopics.map(t11);
        $[1] = activeTopicId;
        $[2] = newTopicName;
        $[3] = onCreateTopic;
        $[4] = onPinTopic;
        $[5] = onSelectTopic;
        $[6] = showInput;
        $[7] = topics;
        $[8] = T0;
        $[9] = T1;
        $[10] = t1;
        $[11] = t2;
        $[12] = t3;
        $[13] = t4;
        $[14] = t5;
        $[15] = t6;
        $[16] = t7;
    } else {
        T0 = $[8];
        T1 = $[9];
        t1 = $[10];
        t2 = $[11];
        t3 = $[12];
        t4 = $[13];
        t5 = $[14];
        t6 = $[15];
        t7 = $[16];
    }
    let t8;
    if ($[33] !== T0 || $[34] !== t1 || $[35] !== t2 || $[36] !== t3 || $[37] !== t4) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            dense: t1,
            sx: t2,
            children: [
                t3,
                t4
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/TopicList.tsx",
            lineNumber: 230,
            columnNumber: 10
        }, this);
        $[33] = T0;
        $[34] = t1;
        $[35] = t2;
        $[36] = t3;
        $[37] = t4;
        $[38] = t8;
    } else {
        t8 = $[38];
    }
    let t9;
    if ($[39] !== T1 || $[40] !== t5 || $[41] !== t6 || $[42] !== t7 || $[43] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
            sx: t5,
            children: [
                t6,
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/TopicList.tsx",
            lineNumber: 242,
            columnNumber: 10
        }, this);
        $[39] = T1;
        $[40] = t5;
        $[41] = t6;
        $[42] = t7;
        $[43] = t8;
        $[44] = t9;
    } else {
        t9 = $[44];
    }
    return t9;
}
_s(TopicList, "mmq1Q2eQkPqFyTC+ARaFQpTg5jc=");
_c = TopicList;
function _TopicListAnonymous(a, b) {
    if (a.pinned && !b.pinned) {
        return -1;
    }
    if (!a.pinned && b.pinned) {
        return 1;
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
}
var _c;
__turbopack_context__.k.register(_c, "TopicList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/MentionChip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MentionChip",
    ()=>MentionChip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SmartToy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/SmartToy.js [app-client] (ecmascript)");
;
;
;
;
function MentionChip(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "6b9d16b42aedf19e54e20ac85c3e19dcd9a594e6c3902e9254c7f66935f15db1") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6b9d16b42aedf19e54e20ac85c3e19dcd9a594e6c3902e9254c7f66935f15db1";
    }
    const { name, onClick } = t0;
    let t1;
    if ($[1] !== name) {
        t1 = name.toLowerCase();
        $[1] = name;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const isBot = t1 === "kai";
    const t2 = `@${name}`;
    let t3;
    if ($[3] !== isBot) {
        t3 = isBot ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SmartToy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Chat/MentionChip.tsx",
            lineNumber: 37,
            columnNumber: 18
        }, this) : undefined;
        $[3] = isBot;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const t4 = isBot ? "secondary" : "primary";
    const t5 = !!onClick;
    const t6 = onClick ? "pointer" : "default";
    let t7;
    if ($[5] !== t6) {
        t7 = {
            height: 20,
            fontSize: "0.8rem",
            verticalAlign: "middle",
            mx: 0.25,
            cursor: t6
        };
        $[5] = t6;
        $[6] = t7;
    } else {
        t7 = $[6];
    }
    let t8;
    if ($[7] !== onClick || $[8] !== t2 || $[9] !== t3 || $[10] !== t4 || $[11] !== t5 || $[12] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            component: "span",
            label: t2,
            size: "small",
            icon: t3,
            color: t4,
            variant: "outlined",
            onClick: onClick,
            clickable: t5,
            sx: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/MentionChip.tsx",
            lineNumber: 62,
            columnNumber: 10
        }, this);
        $[7] = onClick;
        $[8] = t2;
        $[9] = t3;
        $[10] = t4;
        $[11] = t5;
        $[12] = t7;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    return t8;
}
_c = MentionChip;
var _c;
__turbopack_context__.k.register(_c, "MentionChip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/ThreadView.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThreadView",
    ()=>ThreadView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * ThreadView — Displays messages in a topic with threading support.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript) <export default as Avatar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Collapse/Collapse.js [app-client] (ecmascript) <export default as Collapse>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Reply$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Reply.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiEmotions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/EmojiEmotions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Edit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Delete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$MentionChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/MentionChip.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
function ThreadView(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(32);
    if ($[0] !== "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24") {
        for(let $i = 0; $i < 32; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24";
    }
    const { messages, getReplies, onReact, onEdit, onDelete, onReply, currentUser, typingUsers } = t0;
    const scrollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = new Set();
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const [expandedThreads, setExpandedThreads] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "ThreadView[useEffect()]": ()=>{
                if (scrollRef.current) {
                    scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
                }
            }
        })["ThreadView[useEffect()]"];
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== messages.length) {
        t3 = [
            messages.length
        ];
        $[3] = messages.length;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "ThreadView[toggleThread]": (messageId)=>{
                setExpandedThreads({
                    "ThreadView[toggleThread > setExpandedThreads()]": (prev)=>{
                        const next = new Set(prev);
                        if (next.has(messageId)) {
                            next.delete(messageId);
                        } else {
                            next.add(messageId);
                        }
                        return next;
                    }
                }["ThreadView[toggleThread > setExpandedThreads()]"]);
            }
        })["ThreadView[toggleThread]"];
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const toggleThread = t4;
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            flex: 1,
            overflow: "auto",
            p: 2,
            display: "flex",
            flexDirection: "column",
            gap: 1
        };
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] !== messages.length) {
        t6 = messages.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                textAlign: "center",
                py: 4,
                color: "text.secondary"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                children: "No messages yet. Start the conversation!"
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                lineNumber: 125,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 121,
            columnNumber: 35
        }, this);
        $[7] = messages.length;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] !== currentUser || $[10] !== expandedThreads || $[11] !== getReplies || $[12] !== messages || $[13] !== onDelete || $[14] !== onEdit || $[15] !== onReact || $[16] !== onReply) {
        let t8;
        if ($[18] !== currentUser || $[19] !== expandedThreads || $[20] !== getReplies || $[21] !== onDelete || $[22] !== onEdit || $[23] !== onReact || $[24] !== onReply) {
            t8 = ({
                "ThreadView[messages.map()]": (message)=>{
                    const replies = getReplies(message.id);
                    const isExpanded = expandedThreads.has(message.id);
                    const isOwn = message.authorId === currentUser.username;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MessageBubble, {
                                message: message,
                                isOwn: isOwn,
                                replyCount: replies.length,
                                onToggleReplies: {
                                    "ThreadView[messages.map() > <MessageBubble>.onToggleReplies]": ()=>toggleThread(message.id)
                                }["ThreadView[messages.map() > <MessageBubble>.onToggleReplies]"],
                                onReact: onReact,
                                onEdit: isOwn ? onEdit : undefined,
                                onDelete: isOwn ? onDelete : undefined,
                                onReply: onReply
                            }, void 0, false, {
                                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                                lineNumber: 140,
                                columnNumber: 40
                            }, this),
                            replies.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__["Collapse"], {
                                in: isExpanded,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        ml: 4,
                                        borderLeft: 2,
                                        borderColor: "divider",
                                        pl: 1
                                    },
                                    children: replies.map({
                                        "ThreadView[messages.map() > replies.map()]": (reply)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MessageBubble, {
                                                message: reply,
                                                isOwn: reply.authorId === currentUser.username,
                                                onReact: onReact,
                                                onEdit: reply.authorId === currentUser.username ? onEdit : undefined,
                                                onDelete: reply.authorId === currentUser.username ? onDelete : undefined,
                                                compact: true
                                            }, reply.id, false, {
                                                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                                                lineNumber: 148,
                                                columnNumber: 74
                                            }, this)
                                    }["ThreadView[messages.map() > replies.map()]"])
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                                    lineNumber: 142,
                                    columnNumber: 243
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                                lineNumber: 142,
                                columnNumber: 217
                            }, this)
                        ]
                    }, message.id, true, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 140,
                        columnNumber: 18
                    }, this);
                }
            })["ThreadView[messages.map()]"];
            $[18] = currentUser;
            $[19] = expandedThreads;
            $[20] = getReplies;
            $[21] = onDelete;
            $[22] = onEdit;
            $[23] = onReact;
            $[24] = onReply;
            $[25] = t8;
        } else {
            t8 = $[25];
        }
        t7 = messages.map(t8);
        $[9] = currentUser;
        $[10] = expandedThreads;
        $[11] = getReplies;
        $[12] = messages;
        $[13] = onDelete;
        $[14] = onEdit;
        $[15] = onReact;
        $[16] = onReply;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    let t8;
    if ($[26] !== typingUsers) {
        t8 = typingUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                alignItems: "center",
                gap: 1,
                opacity: 0.6
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "caption",
                children: [
                    typingUsers.map(_ThreadViewTypingUsersMap).join(", "),
                    " ",
                    typingUsers.length === 1 ? "is" : "are",
                    " typing..."
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                lineNumber: 183,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 178,
            columnNumber: 36
        }, this);
        $[26] = typingUsers;
        $[27] = t8;
    } else {
        t8 = $[27];
    }
    let t9;
    if ($[28] !== t6 || $[29] !== t7 || $[30] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            ref: scrollRef,
            sx: t5,
            children: [
                t6,
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 191,
            columnNumber: 10
        }, this);
        $[28] = t6;
        $[29] = t7;
        $[30] = t8;
        $[31] = t9;
    } else {
        t9 = $[31];
    }
    return t9;
}
_s(ThreadView, "v4/PpG8f9+o+Jom7TeNotUZVLRs=");
_c = ThreadView;
// ============================================================================
// MessageBubble (internal)
// ============================================================================
function _ThreadViewTypingUsersMap(u) {
    return u.displayName;
}
function MessageBubble(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(47);
    if ($[0] !== "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24") {
        for(let $i = 0; $i < 47; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24";
    }
    const { message, replyCount: t1, onToggleReplies, onReact, onEdit, onDelete, onReply, compact: t2 } = t0;
    const replyCount = t1 === undefined ? 0 : t1;
    const compact = t2 === undefined ? false : t2;
    const [hovered, setHovered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t3;
    if ($[1] !== message.authorName) {
        t3 = message.authorName.split(" ").map(_MessageBubbleAnonymous).join("").slice(0, 2).toUpperCase();
        $[1] = message.authorName;
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    const initials = t3;
    const isBot = message.authorId === "kai-bot";
    let t4;
    let t5;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "MessageBubble[<Box>.onMouseEnter]": ()=>setHovered(true)
        })["MessageBubble[<Box>.onMouseEnter]"];
        t5 = ({
            "MessageBubble[<Box>.onMouseLeave]": ()=>setHovered(false)
        })["MessageBubble[<Box>.onMouseLeave]"];
        $[3] = t4;
        $[4] = t5;
    } else {
        t4 = $[3];
        t5 = $[4];
    }
    const t6 = compact ? 0.5 : 1;
    let t7;
    if ($[5] !== t6) {
        t7 = {
            display: "flex",
            gap: 1,
            py: t6,
            alignItems: "flex-start",
            position: "relative"
        };
        $[5] = t6;
        $[6] = t7;
    } else {
        t7 = $[6];
    }
    let t8;
    if ($[7] !== compact || $[8] !== initials || $[9] !== isBot) {
        t8 = !compact && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__["Avatar"], {
            sx: {
                width: 32,
                height: 32,
                fontSize: "0.75rem",
                bgcolor: isBot ? "secondary.main" : "primary.main"
            },
            children: isBot ? "\uD83E\uDD16" : initials
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 282,
            columnNumber: 22
        }, this);
        $[7] = compact;
        $[8] = initials;
        $[9] = isBot;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            flex: 1,
            minWidth: 0
        };
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    let t10;
    if ($[12] !== compact || $[13] !== isBot || $[14] !== message.authorName || $[15] !== message.createdAt || $[16] !== message.editedAt) {
        t10 = !compact && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                alignItems: "baseline",
                gap: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "subtitle2",
                    component: "span",
                    children: [
                        message.authorName,
                        isBot && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                            label: "AI",
                            size: "small",
                            color: "secondary",
                            sx: {
                                ml: 0.5,
                                height: 18
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Chat/ThreadView.tsx",
                            lineNumber: 311,
                            columnNumber: 87
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 311,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "caption",
                    color: "text.secondary",
                    children: [
                        formatTime(message.createdAt),
                        message.editedAt && " (edited)"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 314,
                    columnNumber: 28
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 307,
            columnNumber: 23
        }, this);
        $[12] = compact;
        $[13] = isBot;
        $[14] = message.authorName;
        $[15] = message.createdAt;
        $[16] = message.editedAt;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            whiteSpace: "pre-wrap",
            wordBreak: "break-word"
        };
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] !== message.content) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            sx: t11,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RenderContent, {
                content: message.content
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                lineNumber: 336,
                columnNumber: 48
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 336,
            columnNumber: 11
        }, this);
        $[19] = message.content;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] !== message.id || $[22] !== message.reactions || $[23] !== onReact) {
        t13 = Object.keys(message.reactions).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                gap: 0.5,
                mt: 0.5,
                flexWrap: "wrap"
            },
            children: Object.entries(message.reactions).map({
                "MessageBubble[(anonymous)()]": (t14)=>{
                    const [emoji, users] = t14;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                        label: `${emoji} ${users.length}`,
                        size: "small",
                        variant: "outlined",
                        onClick: {
                            "MessageBubble[(anonymous)() > <Chip>.onClick]": ()=>onReact(message.id, emoji)
                        }["MessageBubble[(anonymous)() > <Chip>.onClick]"],
                        sx: {
                            height: 22,
                            fontSize: "0.75rem"
                        }
                    }, emoji, false, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 352,
                        columnNumber: 18
                    }, this);
                }
            }["MessageBubble[(anonymous)()]"])
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 344,
            columnNumber: 56
        }, this);
        $[21] = message.id;
        $[22] = message.reactions;
        $[23] = onReact;
        $[24] = t13;
    } else {
        t13 = $[24];
    }
    let t14;
    if ($[25] !== onToggleReplies || $[26] !== replyCount) {
        t14 = replyCount > 0 && onToggleReplies && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "primary",
            sx: {
                cursor: "pointer",
                mt: 0.5,
                display: "block"
            },
            onClick: onToggleReplies,
            children: [
                replyCount,
                " ",
                replyCount === 1 ? "reply" : "replies"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 369,
            columnNumber: 48
        }, this);
        $[25] = onToggleReplies;
        $[26] = replyCount;
        $[27] = t14;
    } else {
        t14 = $[27];
    }
    let t15;
    if ($[28] !== t10 || $[29] !== t12 || $[30] !== t13 || $[31] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t9,
            children: [
                t10,
                t12,
                t13,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 382,
            columnNumber: 11
        }, this);
        $[28] = t10;
        $[29] = t12;
        $[30] = t13;
        $[31] = t14;
        $[32] = t15;
    } else {
        t15 = $[32];
    }
    let t16;
    if ($[33] !== hovered || $[34] !== message.content || $[35] !== message.id || $[36] !== message.parentId || $[37] !== onDelete || $[38] !== onEdit || $[39] !== onReact || $[40] !== onReply) {
        t16 = hovered && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                position: "absolute",
                top: 0,
                right: 0,
                display: "flex",
                bgcolor: "background.paper",
                borderRadius: 1,
                boxShadow: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                    size: "small",
                    onClick: {
                        "MessageBubble[<IconButton>.onClick]": ()=>onReact(message.id, "\uD83D\uDC4D")
                    }["MessageBubble[<IconButton>.onClick]"],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiEmotions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 16
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 403,
                        columnNumber: 49
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 401,
                    columnNumber: 8
                }, this),
                onReply && !message.parentId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                    size: "small",
                    onClick: {
                        "MessageBubble[<IconButton>.onClick]": ()=>onReply(message.id)
                    }["MessageBubble[<IconButton>.onClick]"],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Reply$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 16
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 407,
                        columnNumber: 49
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 405,
                    columnNumber: 60
                }, this),
                onEdit && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                    size: "small",
                    onClick: {
                        "MessageBubble[<IconButton>.onClick]": ()=>onEdit(message.id, message.content)
                    }["MessageBubble[<IconButton>.onClick]"],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 16
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 411,
                        columnNumber: 49
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 409,
                    columnNumber: 39
                }, this),
                onDelete && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                    size: "small",
                    onClick: {
                        "MessageBubble[<IconButton>.onClick]": ()=>onDelete(message.id)
                    }["MessageBubble[<IconButton>.onClick]"],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 16
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 415,
                        columnNumber: 49
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 413,
                    columnNumber: 41
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 393,
            columnNumber: 22
        }, this);
        $[33] = hovered;
        $[34] = message.content;
        $[35] = message.id;
        $[36] = message.parentId;
        $[37] = onDelete;
        $[38] = onEdit;
        $[39] = onReact;
        $[40] = onReply;
        $[41] = t16;
    } else {
        t16 = $[41];
    }
    let t17;
    if ($[42] !== t15 || $[43] !== t16 || $[44] !== t7 || $[45] !== t8) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            onMouseEnter: t4,
            onMouseLeave: t5,
            sx: t7,
            children: [
                t8,
                t15,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 432,
            columnNumber: 11
        }, this);
        $[42] = t15;
        $[43] = t16;
        $[44] = t7;
        $[45] = t8;
        $[46] = t17;
    } else {
        t17 = $[46];
    }
    return t17;
}
_s1(MessageBubble, "V8YbV+gTZxGliGj1g0fftBlvsq4=");
_c1 = MessageBubble;
// ============================================================================
// Helpers
// ============================================================================
function _MessageBubbleAnonymous(n) {
    return n[0];
}
function RenderContent(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24";
    }
    const { content } = t0;
    let t1;
    if ($[1] !== content) {
        const parts = [];
        let t2;
        if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = /@"([^"]+)"|@(\w[\w.-]*)/g;
            $[3] = t2;
        } else {
            t2 = $[3];
        }
        const mentionRegex = t2;
        let lastIndex = 0;
        let match;
        mentionRegex.lastIndex = 0;
        while((match = mentionRegex.exec(content)) !== null){
            if (match.index > lastIndex) {
                parts.push(content.slice(lastIndex, match.index));
            }
            const name = match[1] || match[2];
            parts.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$MentionChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MentionChip"], {
                name: name
            }, match.index, false, {
                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                lineNumber: 480,
                columnNumber: 18
            }, this));
            lastIndex = match.index + match[0].length;
        }
        if (lastIndex < content.length) {
            let t3;
            if ($[4] !== content || $[5] !== lastIndex) {
                t3 = content.slice(lastIndex);
                $[4] = content;
                $[5] = lastIndex;
                $[6] = t3;
            } else {
                t3 = $[6];
            }
            parts.push(t3);
        }
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: parts
        }, void 0, false);
        $[1] = content;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    return t1;
}
_c2 = RenderContent;
function formatTime(isoString) {
    try {
        const date = new Date(isoString);
        const now = new Date();
        const diffMs = now.getTime() - date.getTime();
        const diffMins = Math.floor(diffMs / 60000);
        if (diffMins < 1) return 'just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        const diffHours = Math.floor(diffMins / 60);
        if (diffHours < 24) return `${diffHours}h ago`;
        return date.toLocaleDateString(undefined, {
            month: 'short',
            day: 'numeric'
        });
    } catch  {
        return '';
    }
}
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ThreadView");
__turbopack_context__.k.register(_c1, "MessageBubble");
__turbopack_context__.k.register(_c2, "RenderContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/chatMentions.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Chat mention parsing and resolution utilities.
 *
 * Handles:
 * - @kai — AI bot trigger
 * - @"Display Name" — user with spaces in name
 * - @username — simple user mention
 * - #topic — topic reference (for auto-linking)
 *
 * @module chatMentions
 */ // ============================================================================
// Types
// ============================================================================
__turbopack_context__.s([
    "extractBotPrompt",
    ()=>extractBotPrompt,
    "getAutocompleteSuggestions",
    ()=>getAutocompleteSuggestions,
    "parseContent",
    ()=>parseContent,
    "resolveMentions",
    ()=>resolveMentions
]);
// ============================================================================
// Parsing
// ============================================================================
const MENTION_REGEX = /@"([^"]+)"|@(\w[\w.-]*)/g;
const TOPIC_REGEX = /#([\w-]+)/g;
const BOT_NAME = "kai";
function parseContent(content) {
    const mentions = [];
    let hasBotMention = false;
    // Parse @mentions
    let match;
    MENTION_REGEX.lastIndex = 0;
    while((match = MENTION_REGEX.exec(content)) !== null){
        const value = match[1] || match[2]; // Quoted name or plain username
        const isBotMention = value.toLowerCase() === BOT_NAME;
        if (isBotMention) {
            hasBotMention = true;
        }
        mentions.push({
            type: isBotMention ? "bot" : "user",
            raw: match[0],
            value,
            startIndex: match.index,
            endIndex: match.index + match[0].length
        });
    }
    // Parse #topics
    TOPIC_REGEX.lastIndex = 0;
    while((match = TOPIC_REGEX.exec(content)) !== null){
        mentions.push({
            type: "topic",
            raw: match[0],
            value: match[1],
            startIndex: match.index,
            endIndex: match.index + match[0].length
        });
    }
    // Sort by position
    mentions.sort((a, b)=>a.startIndex - b.startIndex);
    return {
        text: content,
        mentions,
        hasBotMention
    };
}
function extractBotPrompt(content) {
    return content.replace(/@kai\b/gi, "").trim();
}
function getAutocompleteSuggestions(query, members, maxResults = 8) {
    const lowerQuery = query.toLowerCase();
    const suggestions = [];
    // Check if @kai matches
    if (BOT_NAME.startsWith(lowerQuery) || lowerQuery === "") {
        suggestions.push({
            label: "Kai (AI Assistant)",
            value: "@kai",
            type: "bot"
        });
    }
    // Filter members
    for (const member of members){
        if (suggestions.length >= maxResults) break;
        const matchesUsername = member.username.toLowerCase().startsWith(lowerQuery);
        const matchesDisplay = member.displayName.toLowerCase().startsWith(lowerQuery);
        if (matchesUsername || matchesDisplay) {
            const hasSpaces = member.displayName.includes(" ");
            suggestions.push({
                label: member.displayName,
                value: hasSpaces ? `@"${member.displayName}"` : `@${member.username}`,
                type: "user"
            });
        }
    }
    return suggestions;
}
function resolveMentions(mentions, members) {
    const resolved = [];
    for (const mention of mentions){
        if (mention.type !== "user") continue;
        const found = members.find((m)=>m.username.toLowerCase() === mention.value.toLowerCase() || m.displayName.toLowerCase() === mention.value.toLowerCase());
        if (found && !resolved.some((r)=>r.username === found.username)) {
            resolved.push(found);
        }
    }
    return resolved;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/MessageComposer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MessageComposer",
    ()=>MessageComposer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * MessageComposer — Input with @mention autocomplete and typing indicators.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript) <export default as Paper>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemButton/ListItemButton.js [app-client] (ecmascript) <export default as ListItemButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemIcon/ListItemIcon.js [app-client] (ecmascript) <export default as ListItemIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popper$2f$Popper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Popper$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Popper/Popper.js [app-client] (ecmascript) <export default as Popper>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Send.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SmartToy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/SmartToy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Person$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Person.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatMentions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/chatMentions.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
function MessageComposer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(62);
    if ($[0] !== "095adf84ccaff5050c804b31bc55f03dfb438fa4525d376049b914c49d705db4") {
        for(let $i = 0; $i < 62; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "095adf84ccaff5050c804b31bc55f03dfb438fa4525d376049b914c49d705db4";
    }
    const { onSend, members, onTyping, replyTo, onCancelReply, placeholder: t1 } = t0;
    const placeholder = t1 === undefined ? "Type a message... (@kai for AI)" : t1;
    const [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [mentionQuery, setMentionQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [mentionAnchor, setMentionAnchor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedIndex, setSelectedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const typingTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t2;
    if ($[1] !== members || $[2] !== mentionQuery) {
        t2 = mentionQuery !== null ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatMentions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAutocompleteSuggestions"])(mentionQuery, members) : [];
        $[1] = members;
        $[2] = mentionQuery;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const suggestions = t2;
    let t3;
    if ($[4] !== onTyping) {
        t3 = ({
            "MessageComposer[handleTyping]": ()=>{
                onTyping?.(true);
                if (typingTimeoutRef.current) {
                    clearTimeout(typingTimeoutRef.current);
                }
                typingTimeoutRef.current = setTimeout({
                    "MessageComposer[handleTyping > setTimeout()]": ()=>{
                        onTyping?.(false);
                    }
                }["MessageComposer[handleTyping > setTimeout()]"], 2000);
            }
        })["MessageComposer[handleTyping]"];
        $[4] = onTyping;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const handleTyping = t3;
    let t4;
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "MessageComposer[useEffect()]": ()=>()=>{
                    if (typingTimeoutRef.current) {
                        clearTimeout(typingTimeoutRef.current);
                    }
                }
        })["MessageComposer[useEffect()]"];
        t5 = [];
        $[6] = t4;
        $[7] = t5;
    } else {
        t4 = $[6];
        t5 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t4, t5);
    let t6;
    if ($[8] !== handleTyping) {
        t6 = ({
            "MessageComposer[handleChange]": (e)=>{
                const newValue = e.target.value;
                setValue(newValue);
                handleTyping();
                const cursorPos = e.target.selectionStart || newValue.length;
                const textBefore = newValue.slice(0, cursorPos);
                const atMatch = textBefore.match(/@(\w*)$/);
                if (atMatch) {
                    setMentionQuery(atMatch[1]);
                    setMentionAnchor(e.target);
                    setSelectedIndex(0);
                } else {
                    setMentionQuery(null);
                    setMentionAnchor(null);
                }
            }
        })["MessageComposer[handleChange]"];
        $[8] = handleTyping;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    const handleChange = t6;
    let t7;
    if ($[10] !== value) {
        t7 = ({
            "MessageComposer[insertMention]": (mentionValue)=>{
                const cursorPos_0 = inputRef.current?.selectionStart || value.length;
                const textBefore_0 = value.slice(0, cursorPos_0);
                const textAfter = value.slice(cursorPos_0);
                const atIndex = textBefore_0.lastIndexOf("@");
                const newText = textBefore_0.slice(0, atIndex) + mentionValue + " " + textAfter;
                setValue(newText);
                setMentionQuery(null);
                setMentionAnchor(null);
                setTimeout({
                    "MessageComposer[insertMention > setTimeout()]": ()=>inputRef.current?.focus()
                }["MessageComposer[insertMention > setTimeout()]"], 0);
            }
        })["MessageComposer[insertMention]"];
        $[10] = value;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    const insertMention = t7;
    let handleKeyDown;
    let handleSend;
    if ($[12] !== insertMention || $[13] !== mentionQuery || $[14] !== onSend || $[15] !== onTyping || $[16] !== replyTo?.id || $[17] !== selectedIndex || $[18] !== suggestions || $[19] !== value) {
        handleKeyDown = ({
            "MessageComposer[handleKeyDown]": (e_0)=>{
                if (mentionQuery !== null && suggestions.length > 0) {
                    if (e_0.key === "ArrowDown") {
                        e_0.preventDefault();
                        setSelectedIndex({
                            "MessageComposer[handleKeyDown > setSelectedIndex()]": (i)=>Math.min(i + 1, suggestions.length - 1)
                        }["MessageComposer[handleKeyDown > setSelectedIndex()]"]);
                        return;
                    }
                    if (e_0.key === "ArrowUp") {
                        e_0.preventDefault();
                        setSelectedIndex(_MessageComposerHandleKeyDownSetSelectedIndex);
                        return;
                    }
                    if (e_0.key === "Enter" || e_0.key === "Tab") {
                        e_0.preventDefault();
                        insertMention(suggestions[selectedIndex].value);
                        return;
                    }
                    if (e_0.key === "Escape") {
                        setMentionQuery(null);
                        setMentionAnchor(null);
                        return;
                    }
                }
                if (e_0.key === "Enter" && !e_0.shiftKey) {
                    e_0.preventDefault();
                    handleSend();
                }
            }
        })["MessageComposer[handleKeyDown]"];
        handleSend = ({
            "MessageComposer[handleSend]": ()=>{
                const content = value.trim();
                if (!content) {
                    return;
                }
                onSend(content, replyTo?.id);
                setValue("");
                setMentionQuery(null);
                onTyping?.(false);
                if (typingTimeoutRef.current) {
                    clearTimeout(typingTimeoutRef.current);
                }
            }
        })["MessageComposer[handleSend]"];
        $[12] = insertMention;
        $[13] = mentionQuery;
        $[14] = onSend;
        $[15] = onTyping;
        $[16] = replyTo?.id;
        $[17] = selectedIndex;
        $[18] = suggestions;
        $[19] = value;
        $[20] = handleKeyDown;
        $[21] = handleSend;
    } else {
        handleKeyDown = $[20];
        handleSend = $[21];
    }
    let t8;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            p: 2,
            borderTop: 1,
            borderColor: "divider"
        };
        $[22] = t8;
    } else {
        t8 = $[22];
    }
    let t9;
    if ($[23] !== onCancelReply || $[24] !== replyTo) {
        t9 = replyTo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                mb: 1,
                px: 1,
                py: 0.5,
                bgcolor: "action.hover",
                borderRadius: 1,
                borderLeft: 3,
                borderColor: "primary.main"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "caption",
                    noWrap: true,
                    sx: {
                        flex: 1
                    },
                    children: [
                        "Replying to ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                            children: replyTo.authorName
                        }, void 0, false, {
                            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                            lineNumber: 245,
                            columnNumber: 22
                        }, this),
                        ": ",
                        replyTo.content
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                    lineNumber: 243,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                    size: "small",
                    onClick: onCancelReply,
                    children: "×"
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                    lineNumber: 245,
                    columnNumber: 91
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 232,
            columnNumber: 21
        }, this);
        $[23] = onCancelReply;
        $[24] = replyTo;
        $[25] = t9;
    } else {
        t9 = $[25];
    }
    let t10;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            display: "flex",
            gap: 1,
            alignItems: "flex-end"
        };
        $[26] = t10;
    } else {
        t10 = $[26];
    }
    let t11;
    if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            input: {
                sx: {
                    fontSize: "0.875rem"
                }
            }
        };
        $[27] = t11;
    } else {
        t11 = $[27];
    }
    let t12;
    if ($[28] !== handleChange || $[29] !== handleKeyDown || $[30] !== placeholder || $[31] !== value) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
            inputRef: inputRef,
            fullWidth: true,
            multiline: true,
            maxRows: 4,
            size: "small",
            value: value,
            onChange: handleChange,
            onKeyDown: handleKeyDown,
            placeholder: placeholder,
            slotProps: t11
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 278,
            columnNumber: 11
        }, this);
        $[28] = handleChange;
        $[29] = handleKeyDown;
        $[30] = placeholder;
        $[31] = value;
        $[32] = t12;
    } else {
        t12 = $[32];
    }
    let t13;
    if ($[33] !== value) {
        t13 = value.trim();
        $[33] = value;
        $[34] = t13;
    } else {
        t13 = $[34];
    }
    const t14 = !t13;
    let t15;
    let t16;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            mb: 0.5
        };
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 302,
            columnNumber: 11
        }, this);
        $[35] = t15;
        $[36] = t16;
    } else {
        t15 = $[35];
        t16 = $[36];
    }
    let t17;
    if ($[37] !== handleSend || $[38] !== t14) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            color: "primary",
            onClick: handleSend,
            disabled: t14,
            sx: t15,
            children: t16
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 311,
            columnNumber: 11
        }, this);
        $[37] = handleSend;
        $[38] = t14;
        $[39] = t17;
    } else {
        t17 = $[39];
    }
    let t18;
    if ($[40] !== t12 || $[41] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t10,
            children: [
                t12,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 320,
            columnNumber: 11
        }, this);
        $[40] = t12;
        $[41] = t17;
        $[42] = t18;
    } else {
        t18 = $[42];
    }
    const t19 = mentionQuery !== null && suggestions.length > 0;
    let t20;
    if ($[43] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = {
            zIndex: 1400
        };
        $[43] = t20;
    } else {
        t20 = $[43];
    }
    let t21;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = {
            maxHeight: 200,
            overflow: "auto",
            minWidth: 200
        };
        $[44] = t21;
    } else {
        t21 = $[44];
    }
    let t22;
    if ($[45] !== insertMention || $[46] !== selectedIndex || $[47] !== suggestions) {
        let t23;
        if ($[49] !== insertMention || $[50] !== selectedIndex) {
            t23 = ({
                "MessageComposer[suggestions.map()]": (suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                        disablePadding: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__["ListItemButton"], {
                            selected: index === selectedIndex,
                            onClick: {
                                "MessageComposer[suggestions.map() > <ListItemButton>.onClick]": ()=>insertMention(suggestion.value)
                            }["MessageComposer[suggestions.map() > <ListItemButton>.onClick]"],
                            dense: true,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                    sx: {
                                        minWidth: 32
                                    },
                                    children: suggestion.type === "bot" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SmartToy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small",
                                        color: "secondary"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                                        lineNumber: 357,
                                        columnNumber: 45
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Person$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                                        lineNumber: 357,
                                        columnNumber: 99
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                                    lineNumber: 355,
                                    columnNumber: 92
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                    primary: suggestion.label,
                                    primaryTypographyProps: {
                                        variant: "body2"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                                    lineNumber: 357,
                                    columnNumber: 146
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                            lineNumber: 353,
                            columnNumber: 125
                        }, this)
                    }, suggestion.value, false, {
                        fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                        lineNumber: 353,
                        columnNumber: 70
                    }, this)
            })["MessageComposer[suggestions.map()]"];
            $[49] = insertMention;
            $[50] = selectedIndex;
            $[51] = t23;
        } else {
            t23 = $[51];
        }
        t22 = suggestions.map(t23);
        $[45] = insertMention;
        $[46] = selectedIndex;
        $[47] = suggestions;
        $[48] = t22;
    } else {
        t22 = $[48];
    }
    let t23;
    if ($[52] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
            elevation: 4,
            sx: t21,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                dense: true,
                children: t22
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                lineNumber: 377,
                columnNumber: 41
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 377,
            columnNumber: 11
        }, this);
        $[52] = t22;
        $[53] = t23;
    } else {
        t23 = $[53];
    }
    let t24;
    if ($[54] !== mentionAnchor || $[55] !== t19 || $[56] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popper$2f$Popper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Popper$3e$__["Popper"], {
            open: t19,
            anchorEl: mentionAnchor,
            placement: "top-start",
            sx: t20,
            children: t23
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 385,
            columnNumber: 11
        }, this);
        $[54] = mentionAnchor;
        $[55] = t19;
        $[56] = t23;
        $[57] = t24;
    } else {
        t24 = $[57];
    }
    let t25;
    if ($[58] !== t18 || $[59] !== t24 || $[60] !== t9) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t8,
            children: [
                t9,
                t18,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 395,
            columnNumber: 11
        }, this);
        $[58] = t18;
        $[59] = t24;
        $[60] = t9;
        $[61] = t25;
    } else {
        t25 = $[61];
    }
    return t25;
}
_s(MessageComposer, "jAuBndA4gS4NLlzQvHEyHBlfQMY=");
_c = MessageComposer;
function _MessageComposerHandleKeyDownSetSelectedIndex(i_0) {
    return Math.max(i_0 - 1, 0);
}
var _c;
__turbopack_context__.k.register(_c, "MessageComposer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/ChatPanel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChatPanel",
    ()=>ChatPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * ChatPanel — Main container for collaborative peer chat.
 *
 * Renders a topic sidebar + active thread view. Connects to the
 * ChatCollaborationProvider based on the current section/squad context.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Drawer$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Drawer/Drawer.js [app-client] (ecmascript) <export default as Drawer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Badge/Badge.js [app-client] (ecmascript) <export default as Badge>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/useMediaQuery/index.js [app-client] (ecmascript) <export default as useMediaQuery>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/useTheme.js [app-client] (ecmascript) <export default as useTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Forum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Forum.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/chatHooks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$TopicList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/TopicList.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$ThreadView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/ThreadView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$MessageComposer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/MessageComposer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
function ChatPanel(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(79);
    if ($[0] !== "7b6ddf8518ef3f0e1e2a0ff815b249ca44e5f66badb8e755865ff39d7323ca50") {
        for(let $i = 0; $i < 79; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7b6ddf8518ef3f0e1e2a0ff815b249ca44e5f66badb8e755865ff39d7323ca50";
    }
    const { roomType, roomId, user, scope, members: t1, wsUrl } = t0;
    let t2;
    if ($[1] !== t1) {
        t2 = t1 === undefined ? [] : t1;
        $[1] = t1;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const members = t2;
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"])();
    let t3;
    if ($[3] !== theme.breakpoints) {
        t3 = theme.breakpoints.down("md");
        $[3] = theme.breakpoints;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const isMobile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__["useMediaQuery"])(t3);
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeTopicId, setActiveTopicId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t4;
    if ($[5] !== roomId || $[6] !== roomType || $[7] !== user || $[8] !== wsUrl) {
        t4 = roomId ? {
            roomType,
            roomId,
            user,
            wsUrl,
            connect: true,
            persistence: true
        } : null;
        $[5] = roomId;
        $[6] = roomType;
        $[7] = user;
        $[8] = wsUrl;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    const { provider, isConnected } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatRoom"])(t4);
    const { topics, createTopic, pinTopic, archiveTopic } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatTopics"])(provider, scope);
    const { topLevelMessages, sendMessage, editMessage, deleteMessage, addReaction, getReplies } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatThread"])(provider, activeTopicId);
    const { onlineUsers, typingUsers } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPresence"])(provider, activeTopicId);
    const defaultScope = scope || (roomType === "squad" ? "squad" : "section");
    let t5;
    if ($[10] !== activeTopicId || $[11] !== topics) {
        t5 = topics.find({
            "ChatPanel[topics.find()]": (t)=>t.id === activeTopicId
        }["ChatPanel[topics.find()]"]) || null;
        $[10] = activeTopicId;
        $[11] = topics;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    const activeTopic = t5;
    let t6;
    if ($[13] !== createTopic || $[14] !== defaultScope) {
        t6 = ({
            "ChatPanel[handleCreateTopic]": (name)=>{
                const topic = createTopic(name, defaultScope);
                if (topic) {
                    setActiveTopicId(topic.id);
                }
            }
        })["ChatPanel[handleCreateTopic]"];
        $[13] = createTopic;
        $[14] = defaultScope;
        $[15] = t6;
    } else {
        t6 = $[15];
    }
    const handleCreateTopic = t6;
    let t7;
    if ($[16] !== sendMessage) {
        t7 = ({
            "ChatPanel[handleSendMessage]": (content, parentId)=>{
                sendMessage(content, parentId);
            }
        })["ChatPanel[handleSendMessage]"];
        $[16] = sendMessage;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    const handleSendMessage = t7;
    const drawerWidth = isMobile ? "100%" : 420;
    let t8;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = ({
            "ChatPanel[<IconButton>.onClick]": ()=>setOpen(true)
        })["ChatPanel[<IconButton>.onClick]"];
        $[18] = t8;
    } else {
        t8 = $[18];
    }
    let t9;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            bgcolor: "primary.dark"
        };
        $[19] = t9;
    } else {
        t9 = $[19];
    }
    let t10;
    if ($[20] !== theme.zIndex.fab) {
        t10 = {
            position: "fixed",
            bottom: 24,
            right: 24,
            bgcolor: "primary.main",
            color: "primary.contrastText",
            width: 56,
            height: 56,
            "&:hover": t9,
            zIndex: theme.zIndex.fab
        };
        $[20] = theme.zIndex.fab;
        $[21] = t10;
    } else {
        t10 = $[21];
    }
    const t11 = !isConnected;
    let t12;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Forum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 203,
            columnNumber: 11
        }, this);
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    let t13;
    if ($[23] !== t11) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__["Badge"], {
            color: "success",
            variant: "dot",
            invisible: t11,
            children: t12
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 210,
            columnNumber: 11
        }, this);
        $[23] = t11;
        $[24] = t13;
    } else {
        t13 = $[24];
    }
    let t14;
    if ($[25] !== t10 || $[26] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            onClick: t8,
            "data-testid": "collaborative-chat-button",
            sx: t10,
            children: t13
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 218,
            columnNumber: 11
        }, this);
        $[25] = t10;
        $[26] = t13;
        $[27] = t14;
    } else {
        t14 = $[27];
    }
    let t15;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = ({
            "ChatPanel[<Drawer>.onClose]": ()=>setOpen(false)
        })["ChatPanel[<Drawer>.onClose]"];
        $[28] = t15;
    } else {
        t15 = $[28];
    }
    const t16 = isMobile ? "temporary" : "persistent";
    let t17;
    if ($[29] !== drawerWidth) {
        t17 = {
            "& .MuiDrawer-paper": {
                width: drawerWidth,
                maxWidth: "100vw"
            }
        };
        $[29] = drawerWidth;
        $[30] = t17;
    } else {
        t17 = $[30];
    }
    let t18;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = {
            display: "flex",
            flexDirection: "column",
            height: "100%"
        };
        $[31] = t18;
    } else {
        t18 = $[31];
    }
    let t19;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            p: 2,
            borderBottom: 1,
            borderColor: "divider"
        };
        $[32] = t19;
    } else {
        t19 = $[32];
    }
    const t20 = activeTopic ? activeTopic.name : "Chat";
    let t21;
    if ($[33] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h6",
            children: t20
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 276,
            columnNumber: 11
        }, this);
        $[33] = t20;
        $[34] = t21;
    } else {
        t21 = $[34];
    }
    let t22;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = {
            display: "flex",
            alignItems: "center",
            gap: 1
        };
        $[35] = t22;
    } else {
        t22 = $[35];
    }
    let t23;
    if ($[36] !== onlineUsers.length) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            children: [
                onlineUsers.length,
                " online"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 295,
            columnNumber: 11
        }, this);
        $[36] = onlineUsers.length;
        $[37] = t23;
    } else {
        t23 = $[37];
    }
    let t24;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            size: "small",
            onClick: {
                "ChatPanel[<IconButton>.onClick]": ()=>setOpen(false)
            }["ChatPanel[<IconButton>.onClick]"],
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                lineNumber: 305,
                columnNumber: 43
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 303,
            columnNumber: 11
        }, this);
        $[38] = t24;
    } else {
        t24 = $[38];
    }
    let t25;
    if ($[39] !== t23) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t22,
            children: [
                t23,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 312,
            columnNumber: 11
        }, this);
        $[39] = t23;
        $[40] = t25;
    } else {
        t25 = $[40];
    }
    let t26;
    if ($[41] !== t21 || $[42] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t19,
            children: [
                t21,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 320,
            columnNumber: 11
        }, this);
        $[41] = t21;
        $[42] = t25;
        $[43] = t26;
    } else {
        t26 = $[43];
    }
    let t27;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = {
            display: "flex",
            flex: 1,
            overflow: "hidden"
        };
        $[44] = t27;
    } else {
        t27 = $[44];
    }
    let t28;
    if ($[45] !== activeTopicId || $[46] !== archiveTopic || $[47] !== handleCreateTopic || $[48] !== isMobile || $[49] !== pinTopic || $[50] !== topics) {
        t28 = (!activeTopicId || !isMobile) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                width: activeTopicId ? 180 : "100%",
                borderRight: activeTopicId ? 1 : 0,
                borderColor: "divider",
                overflow: "auto"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$TopicList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TopicList"], {
                topics: topics,
                activeTopicId: activeTopicId,
                onSelectTopic: setActiveTopicId,
                onCreateTopic: handleCreateTopic,
                onPinTopic: pinTopic,
                onArchiveTopic: archiveTopic
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                lineNumber: 345,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 340,
            columnNumber: 44
        }, this);
        $[45] = activeTopicId;
        $[46] = archiveTopic;
        $[47] = handleCreateTopic;
        $[48] = isMobile;
        $[49] = pinTopic;
        $[50] = topics;
        $[51] = t28;
    } else {
        t28 = $[51];
    }
    let t29;
    if ($[52] !== activeTopicId || $[53] !== addReaction || $[54] !== deleteMessage || $[55] !== editMessage || $[56] !== getReplies || $[57] !== handleSendMessage || $[58] !== isMobile || $[59] !== members || $[60] !== provider || $[61] !== topLevelMessages || $[62] !== typingUsers || $[63] !== user) {
        t29 = activeTopicId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                flexDirection: "column",
                flex: 1,
                overflow: "hidden"
            },
            children: [
                isMobile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        p: 1,
                        borderBottom: 1,
                        borderColor: "divider"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                        size: "small",
                        onClick: {
                            "ChatPanel[<IconButton>.onClick]": ()=>setActiveTopicId(null)
                        }["ChatPanel[<IconButton>.onClick]"],
                        children: "← Topics"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                        lineNumber: 367,
                        columnNumber: 10
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                    lineNumber: 363,
                    columnNumber: 21
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$ThreadView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThreadView"], {
                    messages: topLevelMessages,
                    getReplies: getReplies,
                    onReact: addReaction,
                    onEdit: editMessage,
                    onDelete: deleteMessage,
                    currentUser: user,
                    typingUsers: typingUsers
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                    lineNumber: 369,
                    columnNumber: 75
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$MessageComposer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageComposer"], {
                    onSend: handleSendMessage,
                    members: members,
                    onTyping: {
                        "ChatPanel[<MessageComposer>.onTyping]": (typing)=>provider?.setTyping(typing)
                    }["ChatPanel[<MessageComposer>.onTyping]"]
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                    lineNumber: 369,
                    columnNumber: 254
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 358,
            columnNumber: 28
        }, this);
        $[52] = activeTopicId;
        $[53] = addReaction;
        $[54] = deleteMessage;
        $[55] = editMessage;
        $[56] = getReplies;
        $[57] = handleSendMessage;
        $[58] = isMobile;
        $[59] = members;
        $[60] = provider;
        $[61] = topLevelMessages;
        $[62] = typingUsers;
        $[63] = user;
        $[64] = t29;
    } else {
        t29 = $[64];
    }
    let t30;
    if ($[65] !== t28 || $[66] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t27,
            children: [
                t28,
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 390,
            columnNumber: 11
        }, this);
        $[65] = t28;
        $[66] = t29;
        $[67] = t30;
    } else {
        t30 = $[67];
    }
    let t31;
    if ($[68] !== t26 || $[69] !== t30) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t18,
            children: [
                t26,
                t30
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 399,
            columnNumber: 11
        }, this);
        $[68] = t26;
        $[69] = t30;
        $[70] = t31;
    } else {
        t31 = $[70];
    }
    let t32;
    if ($[71] !== open || $[72] !== t16 || $[73] !== t17 || $[74] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Drawer$3e$__["Drawer"], {
            anchor: "right",
            open: open,
            onClose: t15,
            variant: t16,
            sx: t17,
            children: t31
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 408,
            columnNumber: 11
        }, this);
        $[71] = open;
        $[72] = t16;
        $[73] = t17;
        $[74] = t31;
        $[75] = t32;
    } else {
        t32 = $[75];
    }
    let t33;
    if ($[76] !== t14 || $[77] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t14,
                t32
            ]
        }, void 0, true);
        $[76] = t14;
        $[77] = t32;
        $[78] = t33;
    } else {
        t33 = $[78];
    }
    return t33;
}
_s(ChatPanel, "d9HyrPP2CjUomoj+sTx+hSq+DpM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__["useMediaQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatRoom"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatTopics"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatThread"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPresence"]
    ];
});
_c = ChatPanel;
var _c;
__turbopack_context__.k.register(_c, "ChatPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/CollaborativeChatWrapper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CollaborativeChatWrapper",
    ()=>CollaborativeChatWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$ChatPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/ChatPanel.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
/**
 * CollaborativeChatWrapper — Connects ChatPanel to app context.
 *
 * This component bridges SectionContext/GamificationContext with the ChatPanel.
 * Place it inside any page that has SectionProvider to enable collaborative chat.
 */ 'use client';
;
;
;
;
;
;
function CollaborativeChatWrapper(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "0f258f51196b2d374985d07896e71477a7ddd310d9bc6eecaa7cddc42d1acf9f") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0f258f51196b2d374985d07896e71477a7ddd310d9bc6eecaa7cddc42d1acf9f";
    }
    let t1;
    if ($[1] !== t0) {
        t1 = t0 === undefined ? {} : t0;
        $[1] = t0;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const { roomType: roomTypeProp, roomId: roomIdProp, scope: scopeProp, members: membersProp } = t1;
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { sections } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t2;
    bb0: {
        if (!user?.attributes?.sub) {
            t2 = null;
            break bb0;
        }
        const t3 = user.attributes?.name || user.attributes?.preferred_username || user.username || "Anonymous";
        const t4 = user.attributes?.["custom:role"] || "learner";
        let t5;
        if ($[3] !== t3 || $[4] !== t4 || $[5] !== user.attributes.sub) {
            t5 = {
                username: user.attributes.sub,
                displayName: t3,
                role: t4
            };
            $[3] = t3;
            $[4] = t4;
            $[5] = user.attributes.sub;
            $[6] = t5;
        } else {
            t5 = $[6];
        }
        t2 = t5;
    }
    const chatUser = t2;
    let t3;
    bb1: {
        if (scopeProp) {
            t3 = scopeProp;
            break bb1;
        }
        const id = params?.id;
        if (pathname?.includes("/unit/") && id) {
            t3 = `unit:${id}`;
            break bb1;
        }
        if (pathname?.includes("/workbook/") && id) {
            t3 = `workbook:${id}`;
            break bb1;
        }
        if (pathname?.includes("/squad")) {
            t3 = "squad";
            break bb1;
        }
        t3 = "section";
    }
    const detectedScope = t3;
    const roomType = roomTypeProp || (detectedScope === "squad" ? "squad" : "section");
    let t4;
    bb2: {
        if (roomIdProp) {
            t4 = roomIdProp;
            break bb2;
        }
        if (roomType === "section" && sections?.length > 0) {
            t4 = sections[0].id;
            break bb2;
        }
        t4 = null;
    }
    const roomId = t4;
    let t5;
    bb3: {
        if (membersProp) {
            t5 = membersProp;
            break bb3;
        }
        let t6;
        if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = [];
            $[7] = t6;
        } else {
            t6 = $[7];
        }
        t5 = t6;
    }
    const members = t5;
    if (!chatUser || !roomId) {
        return null;
    }
    let t6;
    if ($[8] !== chatUser || $[9] !== detectedScope || $[10] !== members || $[11] !== roomId || $[12] !== roomType) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$ChatPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChatPanel"], {
            roomType: roomType,
            roomId: roomId,
            user: chatUser,
            scope: detectedScope,
            members: members
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/CollaborativeChatWrapper.tsx",
            lineNumber: 150,
            columnNumber: 10
        }, this);
        $[8] = chatUser;
        $[9] = detectedScope;
        $[10] = members;
        $[11] = roomId;
        $[12] = roomType;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    return t6;
}
_s(CollaborativeChatWrapper, "T+S4Z43CM4T4xv1fU4/Md5JulQ0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = CollaborativeChatWrapper;
var _c;
__turbopack_context__.k.register(_c, "CollaborativeChatWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/LazyCardMedia.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LazyCardMedia
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getResponsiveImageUrls$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getResponsiveImageUrls.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function LazyCardMedia(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "4d24c36048e5ea79e412c1e445af3b4f450538ab37080c231466099aa22d934c") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4d24c36048e5ea79e412c1e445af3b4f450538ab37080c231466099aa22d934c";
    }
    const { s3Key, identityId, fileId, level: t1, filter: t2, grade: t3 } = t0;
    t1 === undefined ? "protected" : t1;
    const filter = t2 === undefined ? null : t2;
    t3 === undefined ? null : t3;
    const [url, setUrl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [srcSet, setSrcSet] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [sizes, setSizes] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [loaded, setLoaded] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [isVisible, setIsVisible] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const containerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    let t4;
    let t5;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "LazyCardMedia[useEffect()]": ()=>{
                const el = containerRef.current;
                if (!el) {
                    return;
                }
                const observer = new IntersectionObserver((t6)=>{
                    const [entry] = t6;
                    if (entry.isIntersecting) {
                        setIsVisible(true);
                        observer.disconnect();
                    }
                }, {
                    rootMargin: "200px"
                });
                observer.observe(el);
                return ()=>observer.disconnect();
            }
        })["LazyCardMedia[useEffect()]"];
        t5 = [];
        $[1] = t4;
        $[2] = t5;
    } else {
        t4 = $[1];
        t5 = $[2];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t4, t5);
    let t6;
    let t7;
    if ($[3] !== fileId || $[4] !== identityId || $[5] !== isVisible || $[6] !== s3Key) {
        t6 = ({
            "LazyCardMedia[useEffect()]": ()=>{
                if (!isVisible || !s3Key) {
                    return;
                }
                setLoaded(false);
                let cancelled = false;
                const fetchUrl = {
                    "LazyCardMedia[useEffect() > fetchUrl]": async ()=>{
                        const _url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(s3Key);
                        if (!cancelled) {
                            setUrl(_url);
                        }
                    }
                }["LazyCardMedia[useEffect() > fetchUrl]"];
                fetchUrl();
                if (fileId && identityId) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getResponsiveImageUrls$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getResponsiveImageUrls"])(fileId, identityId).then({
                        "LazyCardMedia[useEffect() > (anonymous)()]": (result)=>{
                            if (!cancelled && result) {
                                setSrcSet(result.srcSet);
                                setSizes(result.sizes);
                            }
                        }
                    }["LazyCardMedia[useEffect() > (anonymous)()]"]).catch(_LazyCardMediaUseEffectAnonymous);
                }
                return ()=>{
                    cancelled = true;
                };
            }
        })["LazyCardMedia[useEffect()]"];
        t7 = [
            isVisible,
            s3Key,
            fileId,
            identityId
        ];
        $[3] = fileId;
        $[4] = identityId;
        $[5] = isVisible;
        $[6] = s3Key;
        $[7] = t6;
        $[8] = t7;
    } else {
        t6 = $[7];
        t7 = $[8];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t6, t7);
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            position: "relative",
            width: 400,
            alignSelf: "left",
            flexShrink: 0
        };
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    let t9;
    if ($[10] !== filter || $[11] !== isVisible || $[12] !== loaded || $[13] !== sizes || $[14] !== srcSet || $[15] !== url) {
        t9 = isVisible && url ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            src: url,
            srcSet: srcSet || undefined,
            sizes: sizes || undefined,
            loading: "lazy",
            decoding: "async",
            style: {
                width: "100%",
                height: "100%",
                objectFit: "cover",
                display: "block",
                visibility: loaded ? "visible" : "hidden",
                filter: filter || undefined
            },
            onLoad: {
                "LazyCardMedia[<img>.onLoad]": ()=>setLoaded(true)
            }["LazyCardMedia[<img>.onLoad]"]
        }, void 0, false, {
            fileName: "[project]/src/components/LazyCardMedia.jsx",
            lineNumber: 130,
            columnNumber: 29
        }, this) : null;
        $[10] = filter;
        $[11] = isVisible;
        $[12] = loaded;
        $[13] = sizes;
        $[14] = srcSet;
        $[15] = url;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    let t10;
    if ($[17] !== loaded) {
        t10 = !loaded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "rectangular",
            animation: "wave",
            sx: {
                position: "absolute",
                inset: 0,
                width: "100%",
                height: "100%"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/LazyCardMedia.jsx",
            lineNumber: 152,
            columnNumber: 22
        }, this);
        $[17] = loaded;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    let t11;
    if ($[19] !== t10 || $[20] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ref: containerRef,
            sx: t8,
            children: [
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/LazyCardMedia.jsx",
            lineNumber: 165,
            columnNumber: 11
        }, this);
        $[19] = t10;
        $[20] = t9;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    return t11;
}
_s(LazyCardMedia, "fttu1d96oMR5teXgml+F/YsIypE=");
_c = LazyCardMedia;
function _LazyCardMediaUseEffectAnonymous() {}
var _c;
__turbopack_context__.k.register(_c, "LazyCardMedia");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:894db5 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateSkillTreeFromUnit",
    ()=>$$RSC_SERVER_ACTION_4
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"70cee74d9083b5e7f4beed90d2410c133ce91c34f1":{"name":"generateSkillTreeFromUnit"}},"app/actions/gamification.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("70cee74d9083b5e7f4beed90d2410c133ce91c34f1", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateSkillTreeFromUnit");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/SkillTree.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SkillTree",
    ()=>SkillTree,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * SkillTree — Renders a skill DAG using React Flow.
 * Nodes represent skills, edges represent prerequisites.
 * Node colors are driven by StudentSkillProgress status.
 *
 * @module SkillTree
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@xyflow/react/dist/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@xyflow/system/dist/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Lock.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PlayArrow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PlayArrow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RadioButtonUnchecked$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RadioButtonUnchecked.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoFixHigh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AutoFixHigh.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$894db5__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:894db5 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// ============================================================================
// Status → Visual Mapping
// ============================================================================
const STATUS_COLORS = {
    LOCKED: '#616161',
    // darker grey for contrast
    AVAILABLE: '#1565c0',
    // darker blue
    IN_PROGRESS: '#e65100',
    // deep orange
    MASTERED: '#1b5e20' // dark green
};
const STATUS_BG = {
    LOCKED: '#eeeeee',
    AVAILABLE: '#bbdefb',
    IN_PROGRESS: '#ffe0b2',
    MASTERED: '#c8e6c9'
};
const STATUS_TEXT = {
    LOCKED: '#212121',
    AVAILABLE: '#0d47a1',
    IN_PROGRESS: '#bf360c',
    MASTERED: '#1b5e20'
};
const STATUS_ICONS = {
    LOCKED: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: 20
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
        lineNumber: 100,
        columnNumber: 11
    }, ("TURBOPACK compile-time value", void 0)),
    AVAILABLE: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RadioButtonUnchecked$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: 20
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
        lineNumber: 103,
        columnNumber: 14
    }, ("TURBOPACK compile-time value", void 0)),
    IN_PROGRESS: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PlayArrow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: 20
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
        lineNumber: 106,
        columnNumber: 16
    }, ("TURBOPACK compile-time value", void 0)),
    MASTERED: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: 20
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
        lineNumber: 109,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0))
};
// ============================================================================
// Custom Node Component
// ============================================================================
const SkillNodeContent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(_c = function SkillNodeContent(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(36);
    if ($[0] !== "69460c630ffc3daf913418612561382d95f3b0952d0e581812efb5baa4e98588") {
        for(let $i = 0; $i < 36; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "69460c630ffc3daf913418612561382d95f3b0952d0e581812efb5baa4e98588";
    }
    const { data } = t0;
    const status = data.status || "LOCKED";
    const isSelected = data.selected === true;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Handle"], {
            type: "target",
            position: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Top,
            style: {
                visibility: "hidden"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 133,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const t2 = `3px solid ${STATUS_COLORS[status]}`;
    const t3 = STATUS_BG[status];
    const t4 = status === "LOCKED" ? "not-allowed" : "pointer";
    const t5 = status === "LOCKED" ? 0.7 : 1;
    const t6 = isSelected ? `3px solid ${STATUS_COLORS[status]}` : "none";
    const t7 = isSelected ? `0 0 16px ${STATUS_COLORS[status]}50` : "0 2px 8px rgba(0,0,0,0.1)";
    const t8 = isSelected ? "scale(1.05)" : undefined;
    let t9;
    if ($[2] !== isSelected || $[3] !== status) {
        t9 = status !== "LOCKED" ? {
            boxShadow: isSelected ? `0 0 20px ${STATUS_COLORS[status]}60` : "0 4px 16px rgba(0,0,0,0.15)",
            transform: isSelected ? "scale(1.07)" : "scale(1.03)"
        } : {};
        $[2] = isSelected;
        $[3] = status;
        $[4] = t9;
    } else {
        t9 = $[4];
    }
    let t10;
    if ($[5] !== t2 || $[6] !== t3 || $[7] !== t4 || $[8] !== t5 || $[9] !== t6 || $[10] !== t7 || $[11] !== t8 || $[12] !== t9) {
        t10 = {
            p: 2,
            borderRadius: 2.5,
            border: t2,
            bgcolor: t3,
            minWidth: 200,
            maxWidth: 280,
            textAlign: "center",
            cursor: t4,
            opacity: t5,
            transition: "box-shadow 0.3s, transform 0.3s, outline 0.2s",
            outline: t6,
            outlineOffset: 3,
            boxShadow: t7,
            transform: t8,
            "&:hover": t9
        };
        $[5] = t2;
        $[6] = t3;
        $[7] = t4;
        $[8] = t5;
        $[9] = t6;
        $[10] = t7;
        $[11] = t8;
        $[12] = t9;
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 0.75,
            mb: 0.75
        };
        $[14] = t11;
    } else {
        t11 = $[14];
    }
    const t12 = STATUS_ICONS[status];
    const t13 = STATUS_TEXT[status];
    let t14;
    if ($[15] !== t13) {
        t14 = {
            fontWeight: 700,
            color: t13,
            lineHeight: 1.3,
            fontSize: "0.95rem"
        };
        $[15] = t13;
        $[16] = t14;
    } else {
        t14 = $[16];
    }
    let t15;
    if ($[17] !== data.title || $[18] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle1",
            sx: t14,
            children: data.title
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 220,
            columnNumber: 11
        }, this);
        $[17] = data.title;
        $[18] = t14;
        $[19] = t15;
    } else {
        t15 = $[19];
    }
    let t16;
    if ($[20] !== t12 || $[21] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t11,
            children: [
                t12,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 229,
            columnNumber: 11
        }, this);
        $[20] = t12;
        $[21] = t15;
        $[22] = t16;
    } else {
        t16 = $[22];
    }
    let t17;
    if ($[23] !== data.description) {
        t17 = data.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            sx: {
                color: "text.secondary",
                fontSize: "0.8rem",
                lineHeight: 1.3,
                mb: 0.75,
                overflow: "hidden",
                textOverflow: "ellipsis",
                display: "-webkit-box",
                WebkitLineClamp: 2,
                WebkitBoxOrient: "vertical"
            },
            children: data.description
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 238,
            columnNumber: 31
        }, this);
        $[23] = data.description;
        $[24] = t17;
    } else {
        t17 = $[24];
    }
    let t18;
    if ($[25] !== data.xpReward || $[26] !== status) {
        t18 = data.xpReward != null && data.xpReward > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: `+${data.xpReward} XP`,
            size: "small",
            sx: {
                height: 24,
                fontSize: "0.8rem",
                fontWeight: 600,
                bgcolor: STATUS_COLORS[status],
                color: "white"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 256,
            columnNumber: 57
        }, this);
        $[25] = data.xpReward;
        $[26] = status;
        $[27] = t18;
    } else {
        t18 = $[27];
    }
    let t19;
    if ($[28] !== t10 || $[29] !== t16 || $[30] !== t17 || $[31] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t10,
            children: [
                t16,
                t17,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 271,
            columnNumber: 11
        }, this);
        $[28] = t10;
        $[29] = t16;
        $[30] = t17;
        $[31] = t18;
        $[32] = t19;
    } else {
        t19 = $[32];
    }
    let t20;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Handle"], {
            type: "source",
            position: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Bottom,
            style: {
                visibility: "hidden"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 282,
            columnNumber: 11
        }, this);
        $[33] = t20;
    } else {
        t20 = $[33];
    }
    let t21;
    if ($[34] !== t19) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t1,
                t19,
                t20
            ]
        }, void 0, true);
        $[34] = t19;
        $[35] = t21;
    } else {
        t21 = $[35];
    }
    return t21;
});
_c1 = SkillNodeContent;
// ============================================================================
// Layout Helpers
// ============================================================================
/**
 * Simple layered DAG layout — skills with no prerequisites at the top,
 * each subsequent layer below. This is a basic topological sort approach.
 */ function layoutSkills(skills) {
    const skillMap = new Map(skills.map((s)=>[
            s.skillId,
            s
        ]));
    const prereqMap = new Map();
    skills.forEach((s)=>{
        prereqMap.set(s.skillId, s.prerequisites || []);
    });
    // Topological layer assignment
    const layers = new Map();
    function getLayer(id, visited) {
        if (layers.has(id)) return layers.get(id);
        if (visited.has(id)) return 0; // cycle guard
        visited.add(id);
        const prereqs = prereqMap.get(id) || [];
        if (prereqs.length === 0) {
            layers.set(id, 0);
            return 0;
        }
        const maxPrereqLayer = Math.max(...prereqs.filter((pid)=>skillMap.has(pid)).map((pid)=>getLayer(pid, visited)), -1);
        const layer = maxPrereqLayer + 1;
        layers.set(id, layer);
        return layer;
    }
    skills.forEach((s)=>getLayer(s.skillId, new Set()));
    // Group skills by layer
    const layerGroups = new Map();
    layers.forEach((layer, id)=>{
        if (!layerGroups.has(layer)) layerGroups.set(layer, []);
        layerGroups.get(layer).push(id);
    });
    const LAYER_GAP_Y = 180;
    const NODE_GAP_X = 300;
    const nodes = [];
    layerGroups.forEach((ids, layer)=>{
        const totalWidth = ids.length * NODE_GAP_X;
        const startX = -totalWidth / 2 + NODE_GAP_X / 2;
        ids.forEach((id, idx)=>{
            const skill = skillMap.get(id);
            nodes.push({
                id,
                position: {
                    x: startX + idx * NODE_GAP_X,
                    y: layer * LAYER_GAP_Y
                },
                data: skill,
                type: 'skillNode',
                sourcePosition: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Bottom,
                targetPosition: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Top
            });
        });
    });
    // Build edges from prerequisites
    const edges = [];
    skills.forEach((s)=>{
        ;
        (s.prerequisites || []).forEach((prereqId)=>{
            if (skillMap.has(prereqId)) {
                edges.push({
                    id: `${prereqId}->${s.skillId}`,
                    source: prereqId,
                    target: s.skillId,
                    animated: s.status === 'IN_PROGRESS',
                    style: {
                        stroke: STATUS_COLORS[s.status],
                        strokeWidth: 2
                    },
                    markerEnd: {
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MarkerType"].ArrowClosed,
                        color: STATUS_COLORS[s.status]
                    }
                });
            }
        });
    });
    return {
        nodes,
        edges
    };
}
// ============================================================================
// Physics System — spring/damping/repulsion with CSS transition smoothing
// ============================================================================
/** Spring stiffness */ const SPRING_K = 0.04;
/** Damping — higher = less bounce */ const DAMPING = 0.88;
/** Impulse on click */ const TOUCH_IMPULSE = 8;
/** How far impulse propagates (px) */ const IMPULSE_FALLOFF = 300;
/** Repulsion between nearby nodes */ const REPULSION_STRENGTH = 800;
/** Distance where repulsion activates */ const REPULSION_RADIUS = 200;
/** Minimum distance for hard collision */ const MIN_NODE_DISTANCE = 180;
/** Velocity threshold to stop simulation */ const VEL_THRESHOLD = 0.05;
/** Position threshold to snap to rest */ const POS_THRESHOLD = 0.3;
/** Strength of pull on connected nodes during drag */ const DRAG_PULL = 0.15;
/** Pull decay per graph hop */ const DRAG_HOP_DECAY = 0.5;
function buildAdjacency(edges) {
    const adj = new Map();
    for (const edge of edges){
        if (!adj.has(edge.source)) adj.set(edge.source, new Set());
        if (!adj.has(edge.target)) adj.set(edge.target, new Set());
        adj.get(edge.source).add(edge.target);
        adj.get(edge.target).add(edge.source);
    }
    return adj;
}
function bfsDistances(sourceId, adjacency) {
    const distances = new Map();
    distances.set(sourceId, 0);
    const queue = [
        sourceId
    ];
    let i = 0;
    while(i < queue.length){
        const current = queue[i++];
        const currentDist = distances.get(current);
        const neighbors = adjacency.get(current);
        if (!neighbors) continue;
        for (const neighbor of neighbors){
            if (!distances.has(neighbor)) {
                distances.set(neighbor, currentDist + 1);
                queue.push(neighbor);
            }
        }
    }
    return distances;
}
/**
 * Physics hook that computes node positions via spring/damping simulation.
 * Positions are applied to React Flow nodes; CSS transitions on the
 * `.react-flow__node` elements provide smooth interpolation between frames.
 * The dragged node is exempt from physics (React Flow handles it directly).
 */ function usePhysicsPositions(nodes, edges, setNodes, enabled) {
    _s();
    const bodiesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    const animRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const runningRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const draggedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Sync rest positions when nodes change from external source (layout, skills prop)
    const prevNodeCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePhysicsPositions.useEffect": ()=>{
            if (!enabled) return;
            // Only reset rest positions when node count changes (new layout)
            if (nodes.length !== prevNodeCountRef.current) {
                const bodies = bodiesRef.current;
                bodies.clear();
                nodes.forEach({
                    "usePhysicsPositions.useEffect": (n)=>{
                        bodies.set(n.id, {
                            x: n.position.x,
                            y: n.position.y,
                            vx: 0,
                            vy: 0,
                            restX: n.position.x,
                            restY: n.position.y
                        });
                    }
                }["usePhysicsPositions.useEffect"]);
                prevNodeCountRef.current = nodes.length;
            }
        }
    }["usePhysicsPositions.useEffect"], [
        nodes,
        enabled
    ]);
    const step = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[step]": ()=>{
            if (!enabled) return;
            const bodies_0 = bodiesRef.current;
            const ids = Array.from(bodies_0.keys());
            let hasMotion = false;
            // Spring force toward rest position
            for (const id of ids){
                if (id === draggedRef.current) continue;
                const body = bodies_0.get(id);
                const fx = (body.restX - body.x) * SPRING_K;
                const fy = (body.restY - body.y) * SPRING_K;
                body.vx = (body.vx + fx) * DAMPING;
                body.vy = (body.vy + fy) * DAMPING;
            }
            // Pairwise repulsion
            for(let i = 0; i < ids.length; i++){
                if (ids[i] === draggedRef.current) continue;
                for(let j = i + 1; j < ids.length; j++){
                    if (ids[j] === draggedRef.current) continue;
                    const a = bodies_0.get(ids[i]);
                    const b = bodies_0.get(ids[j]);
                    const dx = a.x - b.x;
                    const dy = a.y - b.y;
                    const dist = Math.sqrt(dx * dx + dy * dy) || 1;
                    if (dist < REPULSION_RADIUS) {
                        const force = REPULSION_STRENGTH / (dist * dist);
                        const nx = dx / dist;
                        const ny = dy / dist;
                        a.vx += nx * force * 0.5;
                        a.vy += ny * force * 0.5;
                        b.vx -= nx * force * 0.5;
                        b.vy -= ny * force * 0.5;
                    }
                    // Hard collision
                    if (dist < MIN_NODE_DISTANCE) {
                        const overlap = (MIN_NODE_DISTANCE - dist) / 2;
                        const nx_0 = dx / dist;
                        const ny_0 = dy / dist;
                        a.x += nx_0 * overlap;
                        a.y += ny_0 * overlap;
                        b.x -= nx_0 * overlap;
                        b.y -= ny_0 * overlap;
                    }
                }
            }
            // Integrate positions
            for (const id_0 of ids){
                if (id_0 === draggedRef.current) continue;
                const body_0 = bodies_0.get(id_0);
                body_0.x += body_0.vx;
                body_0.y += body_0.vy;
                if (Math.abs(body_0.vx) > VEL_THRESHOLD || Math.abs(body_0.vy) > VEL_THRESHOLD || Math.abs(body_0.x - body_0.restX) > POS_THRESHOLD || Math.abs(body_0.y - body_0.restY) > POS_THRESHOLD) {
                    hasMotion = true;
                }
            }
            // Snap settled nodes
            if (!hasMotion) {
                for (const id_1 of ids){
                    const body_1 = bodies_0.get(id_1);
                    body_1.x = body_1.restX;
                    body_1.y = body_1.restY;
                    body_1.vx = 0;
                    body_1.vy = 0;
                }
            }
            // Apply to React Flow nodes
            setNodes({
                "usePhysicsPositions.useCallback[step]": (currentNodes)=>currentNodes.map({
                        "usePhysicsPositions.useCallback[step]": (n_0)=>{
                            if (n_0.id === draggedRef.current) return n_0;
                            const body_2 = bodies_0.get(n_0.id);
                            if (!body_2) return n_0;
                            if (n_0.position.x === body_2.x && n_0.position.y === body_2.y) return n_0;
                            return {
                                ...n_0,
                                position: {
                                    x: body_2.x,
                                    y: body_2.y
                                }
                            };
                        }
                    }["usePhysicsPositions.useCallback[step]"])
            }["usePhysicsPositions.useCallback[step]"]);
            if (hasMotion) {
                animRef.current = requestAnimationFrame(step);
            } else {
                runningRef.current = false;
            }
        }
    }["usePhysicsPositions.useCallback[step]"], [
        enabled,
        setNodes
    ]);
    const startSim = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[startSim]": ()=>{
            if (!runningRef.current && enabled) {
                runningRef.current = true;
                animRef.current = requestAnimationFrame(step);
            }
        }
    }["usePhysicsPositions.useCallback[startSim]"], [
        enabled,
        step
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePhysicsPositions.useEffect": ()=>{
            return ({
                "usePhysicsPositions.useEffect": ()=>{
                    if (animRef.current) cancelAnimationFrame(animRef.current);
                }
            })["usePhysicsPositions.useEffect"];
        }
    }["usePhysicsPositions.useEffect"], []);
    /** Apply click impulse — source bounces, neighbors push away */ const applyImpulse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[applyImpulse]": (sourceId)=>{
            if (!enabled) return;
            const bodies_1 = bodiesRef.current;
            const source = bodies_1.get(sourceId);
            if (!source) return;
            // Source bounces up
            source.vy -= TOUCH_IMPULSE * 0.5;
            // Push neighbors
            bodies_1.forEach({
                "usePhysicsPositions.useCallback[applyImpulse]": (body_3, id_2)=>{
                    if (id_2 === sourceId) return;
                    const dx_0 = body_3.x - source.x;
                    const dy_0 = body_3.y - source.y;
                    const dist_0 = Math.sqrt(dx_0 * dx_0 + dy_0 * dy_0) || 1;
                    const strength = TOUCH_IMPULSE * Math.exp(-dist_0 / IMPULSE_FALLOFF);
                    body_3.vx += dx_0 / dist_0 * strength;
                    body_3.vy += dy_0 / dist_0 * strength;
                }
            }["usePhysicsPositions.useCallback[applyImpulse]"]);
            startSim();
        }
    }["usePhysicsPositions.useCallback[applyImpulse]"], [
        enabled,
        startSim
    ]);
    /** Notify physics that a node is being dragged — pull connected nodes */ const onDragMove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[onDragMove]": (nodeId, x, y)=>{
            if (!enabled) return;
            const bodies_2 = bodiesRef.current;
            const body_4 = bodies_2.get(nodeId);
            if (!body_4) return;
            const deltaX = x - body_4.x;
            const deltaY = y - body_4.y;
            body_4.x = x;
            body_4.y = y;
            body_4.restX = x;
            body_4.restY = y;
            // Pull connected nodes along the drag direction
            const adj = buildAdjacency(edges);
            const hops = bfsDistances(nodeId, adj);
            hops.forEach({
                "usePhysicsPositions.useCallback[onDragMove]": (hopCount, id_3)=>{
                    if (id_3 === nodeId) return;
                    const neighbor = bodies_2.get(id_3);
                    if (!neighbor) return;
                    const factor = DRAG_PULL * Math.pow(DRAG_HOP_DECAY, hopCount);
                    if (factor < 0.01) return;
                    neighbor.vx += deltaX * factor;
                    neighbor.vy += deltaY * factor;
                    // Also shift rest position slightly for plasticity
                    neighbor.restX += deltaX * factor * 0.3;
                    neighbor.restY += deltaY * factor * 0.3;
                }
            }["usePhysicsPositions.useCallback[onDragMove]"]);
            startSim();
        }
    }["usePhysicsPositions.useCallback[onDragMove]"], [
        enabled,
        edges,
        startSim
    ]);
    const onDragStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[onDragStart]": (nodeId_0)=>{
            draggedRef.current = nodeId_0;
        }
    }["usePhysicsPositions.useCallback[onDragStart]"], []);
    const onDragStop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePhysicsPositions.useCallback[onDragStop]": (nodeId_1)=>{
            draggedRef.current = null;
            // Update rest position to where node was dropped
            const body_5 = bodiesRef.current.get(nodeId_1);
            if (body_5) {
                body_5.restX = body_5.x;
                body_5.restY = body_5.y;
                body_5.vx = 0;
                body_5.vy = 0;
            }
            startSim();
        }
    }["usePhysicsPositions.useCallback[onDragStop]"], [
        startSim
    ]);
    return {
        applyImpulse,
        onDragStart,
        onDragMove,
        onDragStop
    };
}
_s(usePhysicsPositions, "oVfPqaVBfRu5yHjBAcDs2CjdTok=");
// ============================================================================
// SkillTree Inner (needs ReactFlowProvider parent for useReactFlow)
// ============================================================================
const nodeTypes = {
    skillNode: SkillNodeContent
};
function SkillTreeInner({ skills, onSkillClick, height = '100%', unitId, cohortId, canGenerate = false, onGenerated, editable = false, onPrerequisiteChange, selectedSkillId }) {
    _s1();
    const { nodes: initialNodes, edges: initialEdges } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SkillTreeInner.useMemo": ()=>layoutSkills(skills)
    }["SkillTreeInner.useMemo"], [
        skills
    ]);
    const [nodes, setNodes, onNodesChange] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useNodesState"])(initialNodes);
    const [edges, setEdges, onEdgesChange] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEdgesState"])(initialEdges);
    const [generating, setGenerating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isDragging, setIsDragging] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const reactFlow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useReactFlow"])();
    // Physics — spring/repulsion with CSS transition smoothing
    const { applyImpulse, onDragStart, onDragMove, onDragStop } = usePhysicsPositions(nodes, edges, setNodes, !editable);
    // Sync when skills prop changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SkillTreeInner.useEffect": ()=>{
            const layout = layoutSkills(skills);
            setNodes(layout.nodes.map({
                "SkillTreeInner.useEffect": (n)=>({
                        ...n,
                        data: {
                            ...n.data,
                            selected: n.id === selectedSkillId
                        }
                    })
            }["SkillTreeInner.useEffect"]));
            setEdges(layout.edges);
        }
    }["SkillTreeInner.useEffect"], [
        skills,
        selectedSkillId,
        setNodes,
        setEdges
    ]);
    // Keyboard zoom: capture +/- when container is focused or hovered
    const handleKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleKeyDown]": (e)=>{
            const isZoomIn = (e.key === '=' || e.key === '+') && (e.ctrlKey || e.metaKey);
            const isZoomOut = e.key === '-' && (e.ctrlKey || e.metaKey);
            if (isZoomIn || isZoomOut) {
                e.preventDefault();
                e.stopPropagation();
                const currentZoom = reactFlow.getZoom();
                const newZoom = isZoomIn ? Math.min(currentZoom * 1.2, 2.5) : Math.max(currentZoom / 1.2, 0.2);
                reactFlow.zoomTo(newZoom, {
                    duration: 200
                });
            }
        }
    }["SkillTreeInner.useCallback[handleKeyDown]"], [
        reactFlow
    ]);
    // Handle new edge connection (source is prerequisite of target)
    const handleConnect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleConnect]": (connection)=>{
            if (!connection.source || !connection.target) return;
            if (connection.source === connection.target) return;
            setEdges({
                "SkillTreeInner.useCallback[handleConnect]": (eds)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEdge"])({
                        ...connection,
                        animated: false,
                        style: {
                            stroke: '#1976d2',
                            strokeWidth: 2
                        },
                        markerEnd: {
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MarkerType"].ArrowClosed,
                            color: '#1976d2'
                        }
                    }, eds)
            }["SkillTreeInner.useCallback[handleConnect]"]);
            if (onPrerequisiteChange) {
                const targetSkill = skills.find({
                    "SkillTreeInner.useCallback[handleConnect].targetSkill": (s)=>s.skillId === connection.target
                }["SkillTreeInner.useCallback[handleConnect].targetSkill"]);
                const currentPrereqs = targetSkill?.prerequisites || [];
                if (!currentPrereqs.includes(connection.source)) {
                    onPrerequisiteChange(connection.target, [
                        ...currentPrereqs,
                        connection.source
                    ]);
                }
            }
        }
    }["SkillTreeInner.useCallback[handleConnect]"], [
        skills,
        setEdges,
        onPrerequisiteChange
    ]);
    // Handle edge deletion
    const handleEdgesDelete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleEdgesDelete]": (deletedEdges)=>{
            if (!onPrerequisiteChange) return;
            for (const edge of deletedEdges){
                const targetSkill_0 = skills.find({
                    "SkillTreeInner.useCallback[handleEdgesDelete].targetSkill_0": (s_0)=>s_0.skillId === edge.target
                }["SkillTreeInner.useCallback[handleEdgesDelete].targetSkill_0"]);
                if (targetSkill_0) {
                    const updatedPrereqs = (targetSkill_0.prerequisites || []).filter({
                        "SkillTreeInner.useCallback[handleEdgesDelete].updatedPrereqs": (prereqId)=>prereqId !== edge.source
                    }["SkillTreeInner.useCallback[handleEdgesDelete].updatedPrereqs"]);
                    onPrerequisiteChange(edge.target, updatedPrereqs);
                }
            }
        }
    }["SkillTreeInner.useCallback[handleEdgesDelete]"], [
        skills,
        onPrerequisiteChange
    ]);
    const handleGenerate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleGenerate]": async ()=>{
            if (!unitId) return;
            setGenerating(true);
            setError(null);
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$894db5__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateSkillTreeFromUnit"])(unitId, cohortId);
                if (result?.generated) {
                    onGenerated?.({
                        skillCount: result.skillCount ?? 0
                    });
                } else {
                    setError(result?.reason ?? 'Failed to generate skill tree');
                }
            } catch  {
                setError('An unexpected error occurred');
            } finally{
                setGenerating(false);
            }
        }
    }["SkillTreeInner.useCallback[handleGenerate]"], [
        unitId,
        cohortId,
        onGenerated
    ]);
    // Node click: fire onSkillClick AND trigger physics impulse
    const handleNodeClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleNodeClick]": (_event, node)=>{
            const data = node.data;
            applyImpulse(node.id);
            if (data.status !== 'LOCKED' && onSkillClick) {
                onSkillClick(data.skillId);
            }
        }
    }["SkillTreeInner.useCallback[handleNodeClick]"], [
        onSkillClick,
        applyImpulse
    ]);
    // Node drag: propagate pull to connected nodes via physics
    const handleNodeDragStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleNodeDragStart]": (_event_0, node_0)=>{
            setIsDragging(true);
            onDragStart(node_0.id);
        }
    }["SkillTreeInner.useCallback[handleNodeDragStart]"], [
        onDragStart
    ]);
    const handleNodeDrag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleNodeDrag]": (_event_1, node_1)=>{
            onDragMove(node_1.id, node_1.position.x, node_1.position.y);
        }
    }["SkillTreeInner.useCallback[handleNodeDrag]"], [
        onDragMove
    ]);
    const handleNodeDragStop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SkillTreeInner.useCallback[handleNodeDragStop]": (_event_2, node_2)=>{
            setIsDragging(false);
            onDragStop(node_2.id);
        }
    }["SkillTreeInner.useCallback[handleNodeDragStop]"], [
        onDragStop
    ]);
    // Determine if panning should be allowed based on zoom level and container size
    // Only allow pan when content exceeds container width at current zoom
    const [panEnabled, setPanEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    if (skills.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                p: 3,
                textAlign: 'center'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    color: "text.secondary",
                    children: "No skills defined yet."
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                    lineNumber: 822,
                    columnNumber: 9
                }, this),
                canGenerate && unitId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        mt: 2
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "contained",
                            startIcon: generating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "circular",
                                width: 18,
                                height: 18
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                                lineNumber: 826,
                                columnNumber: 65
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoFixHigh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                                lineNumber: 826,
                                columnNumber: 122
                            }, this),
                            onClick: handleGenerate,
                            disabled: generating,
                            children: generating ? 'Generating…' : 'Generate from Unit Content'
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                            lineNumber: 826,
                            columnNumber: 13
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            color: "error",
                            variant: "caption",
                            sx: {
                                display: 'block',
                                mt: 1
                            },
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                            lineNumber: 829,
                            columnNumber: 23
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                    lineNumber: 823,
                    columnNumber: 35
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 818,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ref: containerRef,
        tabIndex: 0,
        onKeyDown: handleKeyDown,
        sx: {
            height,
            width: '100%',
            position: 'relative',
            bgcolor: 'background.default',
            outline: 'none',
            overflow: 'visible',
            '& .react-flow__renderer': {
                overflow: 'visible'
            },
            '& .react-flow__viewport': {
                overflow: 'visible'
            },
            // CSS transitions smooth the physics position updates
            '& .react-flow__node': {
                transition: isDragging ? 'none' : 'transform 0.15s ease-out'
            },
            // Dragged node follows cursor immediately (no transition)
            '& .react-flow__node.dragging': {
                transition: 'none !important'
            }
        },
        children: [
            editable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "text.secondary",
                sx: {
                    position: 'absolute',
                    top: 4,
                    left: 8,
                    zIndex: 10,
                    bgcolor: 'background.paper',
                    px: 0.5,
                    borderRadius: 0.5
                },
                children: "Drag nodes to reposition • Draw edges to add prerequisites • Select + Backspace to remove"
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 860,
                columnNumber: 20
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ReactFlow"], {
                nodes: nodes,
                edges: edges,
                nodeTypes: nodeTypes,
                onNodesChange: onNodesChange,
                onEdgesChange: editable ? onEdgesChange : undefined,
                onConnect: editable ? handleConnect : undefined,
                onEdgesDelete: editable ? handleEdgesDelete : undefined,
                onNodeClick: handleNodeClick,
                onNodeDragStart: handleNodeDragStart,
                onNodeDrag: handleNodeDrag,
                onNodeDragStop: handleNodeDragStop,
                fitView: true,
                fitViewOptions: {
                    padding: 0.3,
                    maxZoom: 1.5
                },
                proOptions: {
                    hideAttribution: true
                },
                nodesDraggable: true,
                nodesConnectable: editable,
                elementsSelectable: editable,
                deleteKeyCode: editable ? 'Backspace' : null,
                panOnDrag: panEnabled,
                zoomOnScroll: true,
                zoomOnPinch: true,
                zoomOnDoubleClick: true,
                minZoom: 0.2,
                maxZoom: 2.5,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Background"], {
                        gap: 24,
                        size: 1
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                        lineNumber: 877,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Controls"], {
                        showInteractive: editable
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                        lineNumber: 878,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 871,
                columnNumber: 7
            }, this),
            canGenerate && unitId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: generating ? 'Generating…' : 'Regenerate skill tree from unit content',
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        position: 'absolute',
                        top: 8,
                        right: 8,
                        zIndex: 10
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        size: "small",
                        onClick: handleGenerate,
                        disabled: generating,
                        "aria-label": generating ? 'Generating…' : 'Regenerate skill tree from unit content',
                        sx: {
                            bgcolor: 'background.paper',
                            boxShadow: 1,
                            '&:hover': {
                                bgcolor: 'action.hover'
                            }
                        },
                        children: generating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "circular",
                            width: 20,
                            height: 20
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                            lineNumber: 894,
                            columnNumber: 29
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoFixHigh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            fontSize: "small"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                            lineNumber: 894,
                            columnNumber: 86
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                        lineNumber: 887,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                    lineNumber: 881,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 880,
                columnNumber: 33
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                color: "error",
                variant: "caption",
                sx: {
                    position: 'absolute',
                    bottom: 8,
                    left: 8,
                    zIndex: 10,
                    bgcolor: 'background.paper',
                    px: 1,
                    borderRadius: 1
                },
                children: error
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 898,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
        lineNumber: 838,
        columnNumber: 10
    }, this);
}
_s1(SkillTreeInner, "iEy4Jhbxw+h8Ky0aBcPDHzckVVY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useNodesState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEdgesState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useReactFlow"],
        usePhysicsPositions
    ];
});
_c2 = SkillTreeInner;
function SkillTree(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "69460c630ffc3daf913418612561382d95f3b0952d0e581812efb5baa4e98588") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "69460c630ffc3daf913418612561382d95f3b0952d0e581812efb5baa4e98588";
    }
    let loading;
    let rest;
    if ($[1] !== props) {
        const { compact: _compact, loading: t0, ...t1 } = props;
        loading = t0;
        rest = t1;
        $[1] = props;
        $[2] = loading;
        $[3] = rest;
    } else {
        loading = $[2];
        rest = $[3];
    }
    if (loading) {
        const t0 = rest.height || "100%";
        let t1;
        if ($[4] !== t0) {
            t1 = {
                height: t0,
                width: "100%",
                p: 3,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 3
            };
            $[4] = t0;
            $[5] = t1;
        } else {
            t1 = $[5];
        }
        let t2;
        if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = {
                display: "flex",
                justifyContent: "center"
            };
            $[6] = t2;
        } else {
            t2 = $[6];
        }
        let t3;
        if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t2,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "rectangular",
                    width: 240,
                    height: 100,
                    sx: {
                        borderRadius: 2
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                    lineNumber: 971,
                    columnNumber: 25
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 971,
                columnNumber: 12
            }, this);
            $[7] = t3;
        } else {
            t3 = $[7];
        }
        let t4;
        if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = {
                display: "flex",
                gap: 4,
                justifyContent: "center"
            };
            $[8] = t4;
        } else {
            t4 = $[8];
        }
        let t5;
        if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                width: 220,
                height: 90,
                sx: {
                    borderRadius: 2
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 991,
                columnNumber: 12
            }, this);
            $[9] = t5;
        } else {
            t5 = $[9];
        }
        let t6;
        if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t4,
                children: [
                    t5,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "rectangular",
                        width: 220,
                        height: 90,
                        sx: {
                            borderRadius: 2
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                        lineNumber: 1000,
                        columnNumber: 29
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1000,
                columnNumber: 12
            }, this);
            $[10] = t6;
        } else {
            t6 = $[10];
        }
        let t7;
        if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = {
                display: "flex",
                gap: 4,
                justifyContent: "center"
            };
            $[11] = t7;
        } else {
            t7 = $[11];
        }
        let t8;
        if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                width: 200,
                height: 85,
                sx: {
                    borderRadius: 2
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1020,
                columnNumber: 12
            }, this);
            $[12] = t8;
        } else {
            t8 = $[12];
        }
        let t9;
        if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                width: 200,
                height: 85,
                sx: {
                    borderRadius: 2
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1029,
                columnNumber: 12
            }, this);
            $[13] = t9;
        } else {
            t9 = $[13];
        }
        let t10;
        if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t7,
                children: [
                    t8,
                    t9,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "rectangular",
                        width: 200,
                        height: 85,
                        sx: {
                            borderRadius: 2
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                        lineNumber: 1038,
                        columnNumber: 34
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1038,
                columnNumber: 13
            }, this);
            $[14] = t10;
        } else {
            t10 = $[14];
        }
        let t11;
        if ($[15] !== t1) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t1,
                children: [
                    t3,
                    t6,
                    t10
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1047,
                columnNumber: 13
            }, this);
            $[15] = t1;
            $[16] = t11;
        } else {
            t11 = $[16];
        }
        return t11;
    }
    let t0;
    if ($[17] !== rest) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ReactFlowProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SkillTreeInner, {
                ...rest
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SkillTree.tsx",
                lineNumber: 1057,
                columnNumber: 29
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/SkillTree.tsx",
            lineNumber: 1057,
            columnNumber: 10
        }, this);
        $[17] = rest;
        $[18] = t0;
    } else {
        t0 = $[18];
    }
    return t0;
}
_c3 = SkillTree;
const __TURBOPACK__default__export__ = SkillTree;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "SkillNodeContent$memo");
__turbopack_context__.k.register(_c1, "SkillNodeContent");
__turbopack_context__.k.register(_c2, "SkillTreeInner");
__turbopack_context__.k.register(_c3, "SkillTree");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:6afe97 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "listSectionStudents",
    ()=>$$RSC_SERVER_ACTION_4
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40385707cf9f17ee49ff34347b8d4517670cefff3e":{"name":"listSectionStudents"}},"app/actions/section.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40385707cf9f17ee49ff34347b8d4517670cefff3e", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "listSectionStudents");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/formatUserName.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatFirstLast",
    ()=>formatFirstLast,
    "formatLastFirst",
    ()=>formatLastFirst,
    "getInitials",
    ()=>getInitials
]);
function formatLastFirst(user) {
    const last = user.lastName?.trim();
    const preferred = user.preferredName?.trim();
    const first = user.firstName?.trim();
    if (last && (preferred || first)) {
        return `${last}, ${preferred || first}`;
    }
    return user.name || user.id || "";
}
function formatFirstLast(user) {
    const last = user.lastName?.trim();
    const preferred = user.preferredName?.trim();
    const first = user.firstName?.trim();
    if (last && (preferred || first)) {
        return `${preferred || first} ${last}`;
    }
    return user.name || user.id || "";
}
function getInitials(user) {
    const preferred = user.preferredName?.trim();
    const first = user.firstName?.trim();
    const last = user.lastName?.trim();
    const displayFirst = preferred || first;
    if (displayFirst && last) {
        return `${displayFirst[0]}${last[0]}`.toUpperCase();
    }
    const fallback = user.name || user.id || "";
    return fallback.slice(0, 2).toUpperCase();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/InstructorDashboard.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InstructorDashboard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript) <export default as CardContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Grid/Grid.js [app-client] (ecmascript) <export default as Grid>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Table/Table.js [app-client] (ecmascript) <export default as Table>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableBody$2f$TableBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableBody$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TableBody/TableBody.js [app-client] (ecmascript) <export default as TableBody>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCell$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TableCell/TableCell.js [app-client] (ecmascript) <export default as TableCell>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableContainer$2f$TableContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TableContainer/TableContainer.js [app-client] (ecmascript) <export default as TableContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableHead$2f$TableHead$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableHead$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TableHead/TableHead.js [app-client] (ecmascript) <export default as TableHead>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableRow$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TableRow/TableRow.js [app-client] (ecmascript) <export default as TableRow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript) <export default as Paper>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Accordion/Accordion.js [app-client] (ecmascript) <export default as Accordion>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AccordionSummary/AccordionSummary.js [app-client] (ecmascript) <export default as AccordionSummary>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AccordionDetails/AccordionDetails.js [app-client] (ecmascript) <export default as AccordionDetails>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript) <export default as Avatar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandMore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TrendingUp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$People$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/People.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Assignment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Assignment.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiEvents$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/EmojiEvents.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$SkillTree$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/SkillTree.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$6afe97__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:6afe97 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formatUserName$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/formatUserName.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function InstructorDashboard(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(129);
    if ($[0] !== "298b6c6beb1149c7ef99e80646287d0bc5edcb6811161304f3a1d7296d035aee") {
        for(let $i = 0; $i < 129; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "298b6c6beb1149c7ef99e80646287d0bc5edcb6811161304f3a1d7296d035aee";
    }
    const { sections: t1 } = t0;
    let t2;
    if ($[1] !== t1) {
        t2 = t1 === undefined ? [] : t1;
        $[1] = t1;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const sections = t2;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const client = t3;
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {};
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    const [sectionStats, setSectionStats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t4);
    let t5;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = [];
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    const [allGrades, setAllGrades] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t5);
    let t6;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = [];
        $[6] = t6;
    } else {
        t6 = $[6];
    }
    const [allAssignments, setAllAssignments] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t6);
    let t7;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {};
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    const [sectionStudents, setSectionStudents] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t7);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const { skillNodes } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSkillTree"])();
    let t8;
    let t9;
    if ($[8] !== sections.length) {
        t8 = ({
            "InstructorDashboard[useEffect()]": ()=>{
                if (sections.length === 0) {
                    setLoading(false);
                    return;
                }
                const subscription = client.models.Grade.observeQuery({
                    filter: {
                        complete: {
                            eq: true
                        }
                    }
                }).subscribe({
                    next: (t10)=>{
                        const { items } = t10;
                        const validItems = items.filter(_InstructorDashboardUseEffectAnonymousItemsFilter);
                        const validGrades = validItems.filter(_InstructorDashboardUseEffectAnonymousValidItemsFilter);
                        setAllGrades(validGrades);
                    },
                    error: (err)=>{
                        console.error("Grades subscription error:", err);
                        if (err?.message?.includes("No current user") || err?.message?.includes("NoSignedUser") || err?.message?.includes("401") || err?.message?.includes("403")) {
                            console.warn("[InstructorDashboard] Auth error, stopping Grades subscription retries");
                            subscription.unsubscribe();
                        }
                    }
                });
                return ()=>subscription.unsubscribe();
            }
        })["InstructorDashboard[useEffect()]"];
        t9 = [
            sections.length
        ];
        $[8] = sections.length;
        $[9] = t8;
        $[10] = t9;
    } else {
        t8 = $[9];
        t9 = $[10];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t8, t9);
    let t10;
    if ($[11] !== sections) {
        t10 = ({
            "InstructorDashboard[useEffect()]": ()=>{
                if (sections.length === 0) {
                    return;
                }
                const validSections = sections.filter(_InstructorDashboardUseEffectSectionsFilter);
                if (validSections.length === 0) {
                    return;
                }
                const sectionIDs = validSections.map(_InstructorDashboardUseEffectValidSectionsMap);
                const subscription_0 = client.models.Assignment.observeQuery({
                    filter: {
                        or: sectionIDs.map(_InstructorDashboardUseEffectSectionIDsMap)
                    }
                }).subscribe({
                    next: (t11)=>{
                        const { items: items_0 } = t11;
                        const validItems_0 = items_0.filter(_InstructorDashboardUseEffectAnonymousItems_0Filter);
                        setAllAssignments(validItems_0);
                    },
                    error: (err_0)=>{
                        console.error("Assignments subscription error:", err_0);
                        if (err_0?.message?.includes("No current user") || err_0?.message?.includes("NoSignedUser") || err_0?.message?.includes("401") || err_0?.message?.includes("403")) {
                            console.warn("[InstructorDashboard] Auth error, stopping Assignments subscription retries");
                            subscription_0.unsubscribe();
                        }
                    }
                });
                return ()=>subscription_0.unsubscribe();
            }
        })["InstructorDashboard[useEffect()]"];
        $[11] = sections;
        $[12] = t10;
    } else {
        t10 = $[12];
    }
    let t11;
    if ($[13] !== sections.length) {
        t11 = [
            sections.length
        ];
        $[13] = sections.length;
        $[14] = t11;
    } else {
        t11 = $[14];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t10, t11);
    let t12;
    let t13;
    if ($[15] !== sections) {
        t12 = ({
            "InstructorDashboard[useEffect()]": ()=>{
                if (sections.length === 0) {
                    return;
                }
                const validSections_0 = sections.filter(_InstructorDashboardUseEffectSectionsFilter2);
                if (validSections_0.length === 0) {
                    return;
                }
                const fetchStudentNames = async function fetchStudentNames() {
                    const nameMap = {};
                    for (const section of validSections_0){
                        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$6afe97__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["listSectionStudents"])(section.code);
                        if (result.success && result.students) {
                            result.students.forEach({
                                "InstructorDashboard[useEffect() > fetchStudentNames > result.students.forEach()]": (student)=>{
                                    nameMap[student.id] = student;
                                }
                            }["InstructorDashboard[useEffect() > fetchStudentNames > result.students.forEach()]"]);
                        }
                    }
                    setSectionStudents(nameMap);
                };
                fetchStudentNames();
            }
        })["InstructorDashboard[useEffect()]"];
        t13 = [
            sections
        ];
        $[15] = sections;
        $[16] = t12;
        $[17] = t13;
    } else {
        t12 = $[16];
        t13 = $[17];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t12, t13);
    let t14;
    let t15;
    if ($[18] !== allAssignments || $[19] !== allGrades || $[20] !== sections) {
        t14 = ({
            "InstructorDashboard[useEffect()]": ()=>{
                if (sections.length === 0 || allGrades.length === 0) {
                    setLoading(false);
                    return;
                }
                const calculateSectionStats = {
                    "InstructorDashboard[useEffect() > calculateSectionStats]": async ()=>{
                        const stats = {};
                        const validSections_1 = sections.filter(_InstructorDashboardUseEffectCalculateSectionStatsSectionsFilter);
                        for (const section_0 of validSections_1){
                            const sectionAssignments = allAssignments.filter({
                                "InstructorDashboard[useEffect() > calculateSectionStats > allAssignments.filter()]": (a)=>a.sectionID === section_0.id
                            }["InstructorDashboard[useEffect() > calculateSectionStats > allAssignments.filter()]"]);
                            const studentGradesMap = {};
                            allGrades.forEach({
                                "InstructorDashboard[useEffect() > calculateSectionStats > allGrades.forEach()]": (grade_0)=>{
                                    const assignment = sectionAssignments.find({
                                        "InstructorDashboard[useEffect() > calculateSectionStats > allGrades.forEach() > sectionAssignments.find()]": (a_0)=>a_0.id === grade_0.assignmentID
                                    }["InstructorDashboard[useEffect() > calculateSectionStats > allGrades.forEach() > sectionAssignments.find()]"]);
                                    if (!assignment) {
                                        return;
                                    }
                                    if (!studentGradesMap[grade_0.owner]) {
                                        studentGradesMap[grade_0.owner] = {
                                            totalGrade: 0,
                                            count: 0,
                                            completedAssignments: new Set(),
                                            allGrades: []
                                        };
                                    }
                                    studentGradesMap[grade_0.owner].allGrades.push(grade_0);
                                    studentGradesMap[grade_0.owner].completedAssignments.add(assignment.unitID);
                                }
                            }["InstructorDashboard[useEffect() > calculateSectionStats > allGrades.forEach()]"]);
                            const studentRankings = Object.entries(studentGradesMap).map({
                                "InstructorDashboard[useEffect() > calculateSectionStats > (anonymous)()]": (t16)=>{
                                    const [studentId, data] = t16;
                                    const gradesByAssignment = {};
                                    data.allGrades.forEach({
                                        "InstructorDashboard[useEffect() > calculateSectionStats > (anonymous)() > data.allGrades.forEach()]": (grade_1)=>{
                                            const assignment_0 = sectionAssignments.find({
                                                "InstructorDashboard[useEffect() > calculateSectionStats > (anonymous)() > data.allGrades.forEach() > sectionAssignments.find()]": (a_1)=>a_1.id === grade_1.assignmentID
                                            }["InstructorDashboard[useEffect() > calculateSectionStats > (anonymous)() > data.allGrades.forEach() > sectionAssignments.find()]"]);
                                            if (!assignment_0) {
                                                return;
                                            }
                                            if (!gradesByAssignment[assignment_0.unitID] || grade_1.accuracy > gradesByAssignment[assignment_0.unitID].accuracy) {
                                                gradesByAssignment[assignment_0.unitID] = grade_1;
                                            }
                                        }
                                    }["InstructorDashboard[useEffect() > calculateSectionStats > (anonymous)() > data.allGrades.forEach()]"]);
                                    const grades = Object.values(gradesByAssignment).map(_InstructorDashboardUseEffectCalculateSectionStatsAnonymousAnonymous);
                                    const average = grades.length > 0 ? grades.reduce(_InstructorDashboardUseEffectCalculateSectionStatsAnonymousGradesReduce, 0) / grades.length : 0;
                                    const completion = sectionAssignments.length > 0 ? data.completedAssignments.size / sectionAssignments.length * 100 : 0;
                                    return {
                                        studentId,
                                        average,
                                        completion,
                                        assignmentsCompleted: data.completedAssignments.size,
                                        totalAssignments: sectionAssignments.length
                                    };
                                }
                            }["InstructorDashboard[useEffect() > calculateSectionStats > (anonymous)()]"]);
                            studentRankings.sort(_InstructorDashboardUseEffectCalculateSectionStatsStudentRankingsSort);
                            stats[section_0.id] = {
                                studentCount: studentRankings.length,
                                averageGrade: studentRankings.length > 0 ? Math.round(studentRankings.reduce(_InstructorDashboardUseEffectCalculateSectionStatsStudentRankingsReduce, 0) / studentRankings.length) : 0,
                                averageCompletion: studentRankings.length > 0 ? Math.round(studentRankings.reduce(_InstructorDashboardUseEffectCalculateSectionStatsStudentRankingsReduce2, 0) / studentRankings.length) : 0,
                                leaderboard: studentRankings.slice(0, 10),
                                assignmentCount: sectionAssignments.length
                            };
                        }
                        setSectionStats(stats);
                        setLoading(false);
                    }
                }["InstructorDashboard[useEffect() > calculateSectionStats]"];
                calculateSectionStats();
            }
        })["InstructorDashboard[useEffect()]"];
        t15 = [
            sections,
            allGrades,
            allAssignments
        ];
        $[18] = allAssignments;
        $[19] = allGrades;
        $[20] = sections;
        $[21] = t14;
        $[22] = t15;
    } else {
        t14 = $[21];
        t15 = $[22];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t14, t15);
    let t16;
    if ($[23] !== sectionStats) {
        t16 = Object.values(sectionStats).reduce(_InstructorDashboardAnonymous, 0);
        $[23] = sectionStats;
        $[24] = t16;
    } else {
        t16 = $[24];
    }
    const totalStudents = t16;
    let t17;
    if ($[25] !== sectionStats) {
        t17 = Object.values(sectionStats).length > 0 ? Math.round(Object.values(sectionStats).reduce(_InstructorDashboardAnonymous2, 0) / Object.values(sectionStats).length) : 0;
        $[25] = sectionStats;
        $[26] = t17;
    } else {
        t17 = $[26];
    }
    const avgGrade = t17;
    let t18;
    if ($[27] !== sectionStats) {
        t18 = Object.values(sectionStats).length > 0 ? Math.round(Object.values(sectionStats).reduce(_InstructorDashboardAnonymous3, 0) / Object.values(sectionStats).length) : 0;
        $[27] = sectionStats;
        $[28] = t18;
    } else {
        t18 = $[28];
    }
    const avgCompletion = t18;
    let t19;
    if ($[29] !== sectionStats) {
        t19 = Object.values(sectionStats).reduce(_InstructorDashboardAnonymous4, 0);
        $[29] = sectionStats;
        $[30] = t19;
    } else {
        t19 = $[30];
    }
    const totalAssignments = t19;
    let t20;
    if ($[31] !== avgCompletion || $[32] !== avgGrade || $[33] !== totalAssignments || $[34] !== totalStudents) {
        t20 = {
            totalStudents,
            avgGrade,
            avgCompletion,
            totalAssignments
        };
        $[31] = avgCompletion;
        $[32] = avgGrade;
        $[33] = totalAssignments;
        $[34] = totalStudents;
        $[35] = t20;
    } else {
        t20 = $[35];
    }
    const aggregateStats = t20;
    if (sections.length === 0) {
        return null;
    }
    let t21;
    if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = {
            mb: 4,
            margin: "1rem auto",
            width: "90vw",
            maxWidth: "80rem"
        };
        $[36] = t21;
    } else {
        t21 = $[36];
    }
    let t22;
    if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = {
            mb: 3,
            borderRadius: 2,
            width: "100%"
        };
        $[37] = t22;
    } else {
        t22 = $[37];
    }
    let t23;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = {
            display: "flex",
            alignItems: "center",
            mb: 3
        };
        $[38] = t23;
    } else {
        t23 = $[38];
    }
    let t24;
    if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                mr: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 409,
            columnNumber: 11
        }, this);
        $[39] = t24;
    } else {
        t24 = $[39];
    }
    let t25;
    if ($[40] !== t) {
        t25 = t("instructorDashboard.overallPerformance");
        $[40] = t;
        $[41] = t25;
    } else {
        t25 = $[41];
    }
    let t26;
    if ($[42] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h5",
            gutterBottom: true,
            sx: t23,
            children: [
                t24,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 426,
            columnNumber: 11
        }, this);
        $[42] = t25;
        $[43] = t26;
    } else {
        t26 = $[43];
    }
    let t27;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = {
            textAlign: "center"
        };
        $[44] = t27;
    } else {
        t27 = $[44];
    }
    let t28;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$People$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: 40,
                color: "primary.main",
                mb: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 443,
            columnNumber: 11
        }, this);
        $[45] = t28;
    } else {
        t28 = $[45];
    }
    let t29;
    if ($[46] === Symbol.for("react.memo_cache_sentinel")) {
        t29 = {
            fontWeight: 600
        };
        $[46] = t29;
    } else {
        t29 = $[46];
    }
    let t30;
    if ($[47] !== aggregateStats.totalStudents) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h4",
            sx: t29,
            children: aggregateStats.totalStudents
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 463,
            columnNumber: 11
        }, this);
        $[47] = aggregateStats.totalStudents;
        $[48] = t30;
    } else {
        t30 = $[48];
    }
    let t31;
    if ($[49] !== t) {
        t31 = t("instructorDashboard.totalStudents");
        $[49] = t;
        $[50] = t31;
    } else {
        t31 = $[50];
    }
    let t32;
    if ($[51] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            children: t31
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 479,
            columnNumber: 11
        }, this);
        $[51] = t31;
        $[52] = t32;
    } else {
        t32 = $[52];
    }
    let t33;
    if ($[53] !== t30 || $[54] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
            item: true,
            xs: 12,
            sm: 6,
            md: 3,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t27,
                children: [
                    t28,
                    t30,
                    t32
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/InstructorDashboard.jsx",
                lineNumber: 487,
                columnNumber: 51
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 487,
            columnNumber: 11
        }, this);
        $[53] = t30;
        $[54] = t32;
        $[55] = t33;
    } else {
        t33 = $[55];
    }
    let t34;
    if ($[56] === Symbol.for("react.memo_cache_sentinel")) {
        t34 = {
            textAlign: "center"
        };
        $[56] = t34;
    } else {
        t34 = $[56];
    }
    let t35;
    if ($[57] === Symbol.for("react.memo_cache_sentinel")) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Assignment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: 40,
                color: "secondary.main",
                mb: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 505,
            columnNumber: 11
        }, this);
        $[57] = t35;
    } else {
        t35 = $[57];
    }
    let t36;
    if ($[58] === Symbol.for("react.memo_cache_sentinel")) {
        t36 = {
            fontWeight: 600
        };
        $[58] = t36;
    } else {
        t36 = $[58];
    }
    let t37;
    if ($[59] !== aggregateStats.totalAssignments) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h4",
            sx: t36,
            children: aggregateStats.totalAssignments
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 525,
            columnNumber: 11
        }, this);
        $[59] = aggregateStats.totalAssignments;
        $[60] = t37;
    } else {
        t37 = $[60];
    }
    let t38;
    if ($[61] !== t) {
        t38 = t("instructorDashboard.totalAssignments");
        $[61] = t;
        $[62] = t38;
    } else {
        t38 = $[62];
    }
    let t39;
    if ($[63] !== t38) {
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            children: t38
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 541,
            columnNumber: 11
        }, this);
        $[63] = t38;
        $[64] = t39;
    } else {
        t39 = $[64];
    }
    let t40;
    if ($[65] !== t37 || $[66] !== t39) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
            item: true,
            xs: 12,
            sm: 6,
            md: 3,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t34,
                children: [
                    t35,
                    t37,
                    t39
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/InstructorDashboard.jsx",
                lineNumber: 549,
                columnNumber: 51
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 549,
            columnNumber: 11
        }, this);
        $[65] = t37;
        $[66] = t39;
        $[67] = t40;
    } else {
        t40 = $[67];
    }
    let t41;
    if ($[68] === Symbol.for("react.memo_cache_sentinel")) {
        t41 = {
            textAlign: "center"
        };
        $[68] = t41;
    } else {
        t41 = $[68];
    }
    let t42;
    if ($[69] === Symbol.for("react.memo_cache_sentinel")) {
        t42 = {
            fontWeight: 600,
            color: "success.main"
        };
        $[69] = t42;
    } else {
        t42 = $[69];
    }
    let t43;
    if ($[70] !== aggregateStats.avgGrade) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h4",
            sx: t42,
            children: [
                aggregateStats.avgGrade,
                "%"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 577,
            columnNumber: 11
        }, this);
        $[70] = aggregateStats.avgGrade;
        $[71] = t43;
    } else {
        t43 = $[71];
    }
    let t44;
    if ($[72] !== t) {
        t44 = t("instructorDashboard.averageGrade");
        $[72] = t;
        $[73] = t44;
    } else {
        t44 = $[73];
    }
    let t45;
    if ($[74] !== t44) {
        t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            children: t44
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 593,
            columnNumber: 11
        }, this);
        $[74] = t44;
        $[75] = t45;
    } else {
        t45 = $[75];
    }
    let t46;
    if ($[76] === Symbol.for("react.memo_cache_sentinel")) {
        t46 = {
            mt: 1,
            height: 8,
            borderRadius: 4
        };
        $[76] = t46;
    } else {
        t46 = $[76];
    }
    let t47;
    if ($[77] !== aggregateStats.avgGrade) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
            variant: "determinate",
            value: aggregateStats.avgGrade,
            sx: t46,
            color: "success"
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 612,
            columnNumber: 11
        }, this);
        $[77] = aggregateStats.avgGrade;
        $[78] = t47;
    } else {
        t47 = $[78];
    }
    let t48;
    if ($[79] !== t43 || $[80] !== t45 || $[81] !== t47) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
            item: true,
            xs: 12,
            sm: 6,
            md: 3,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t41,
                children: [
                    t43,
                    t45,
                    t47
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/InstructorDashboard.jsx",
                lineNumber: 620,
                columnNumber: 51
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 620,
            columnNumber: 11
        }, this);
        $[79] = t43;
        $[80] = t45;
        $[81] = t47;
        $[82] = t48;
    } else {
        t48 = $[82];
    }
    let t49;
    if ($[83] === Symbol.for("react.memo_cache_sentinel")) {
        t49 = {
            textAlign: "center"
        };
        $[83] = t49;
    } else {
        t49 = $[83];
    }
    let t50;
    if ($[84] === Symbol.for("react.memo_cache_sentinel")) {
        t50 = {
            fontWeight: 600,
            color: "info.main"
        };
        $[84] = t50;
    } else {
        t50 = $[84];
    }
    let t51;
    if ($[85] !== aggregateStats.avgCompletion) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h4",
            sx: t50,
            children: [
                aggregateStats.avgCompletion,
                "%"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 649,
            columnNumber: 11
        }, this);
        $[85] = aggregateStats.avgCompletion;
        $[86] = t51;
    } else {
        t51 = $[86];
    }
    let t52;
    if ($[87] !== t) {
        t52 = t("instructorDashboard.averageCompletion");
        $[87] = t;
        $[88] = t52;
    } else {
        t52 = $[88];
    }
    let t53;
    if ($[89] !== t52) {
        t53 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            children: t52
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 665,
            columnNumber: 11
        }, this);
        $[89] = t52;
        $[90] = t53;
    } else {
        t53 = $[90];
    }
    let t54;
    if ($[91] === Symbol.for("react.memo_cache_sentinel")) {
        t54 = {
            mt: 1,
            height: 8,
            borderRadius: 4
        };
        $[91] = t54;
    } else {
        t54 = $[91];
    }
    let t55;
    if ($[92] !== aggregateStats.avgCompletion) {
        t55 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
            variant: "determinate",
            value: aggregateStats.avgCompletion,
            sx: t54,
            color: "info"
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 684,
            columnNumber: 11
        }, this);
        $[92] = aggregateStats.avgCompletion;
        $[93] = t55;
    } else {
        t55 = $[93];
    }
    let t56;
    if ($[94] !== t51 || $[95] !== t53 || $[96] !== t55) {
        t56 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
            item: true,
            xs: 12,
            sm: 6,
            md: 3,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t49,
                children: [
                    t51,
                    t53,
                    t55
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/InstructorDashboard.jsx",
                lineNumber: 692,
                columnNumber: 51
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 692,
            columnNumber: 11
        }, this);
        $[94] = t51;
        $[95] = t53;
        $[96] = t55;
        $[97] = t56;
    } else {
        t56 = $[97];
    }
    let t57;
    if ($[98] !== t33 || $[99] !== t40 || $[100] !== t48 || $[101] !== t56) {
        t57 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
            container: true,
            spacing: 3,
            children: [
                t33,
                t40,
                t48,
                t56
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 702,
            columnNumber: 11
        }, this);
        $[98] = t33;
        $[99] = t40;
        $[100] = t48;
        $[101] = t56;
        $[102] = t57;
    } else {
        t57 = $[102];
    }
    let t58;
    if ($[103] !== t26 || $[104] !== t57) {
        t58 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
            elevation: 3,
            sx: t22,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                children: [
                    t26,
                    t57
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/InstructorDashboard.jsx",
                lineNumber: 713,
                columnNumber: 40
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 713,
            columnNumber: 11
        }, this);
        $[103] = t26;
        $[104] = t57;
        $[105] = t58;
    } else {
        t58 = $[105];
    }
    let t59;
    if ($[106] !== skillNodes || $[107] !== t) {
        t59 = skillNodes?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
            elevation: 3,
            sx: {
                mb: 3,
                borderRadius: 2,
                width: "100%"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "h5",
                        gutterBottom: true,
                        sx: {
                            display: "flex",
                            alignItems: "center",
                            mb: 2
                        },
                        children: t("instructorDashboard.skillTree", "Skill Tree")
                    }, void 0, false, {
                        fileName: "[project]/src/components/InstructorDashboard.jsx",
                        lineNumber: 726,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$SkillTree$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SkillTree"], {
                        skills: skillNodes,
                        height: 300,
                        compact: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/InstructorDashboard.jsx",
                        lineNumber: 730,
                        columnNumber: 75
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/InstructorDashboard.jsx",
                lineNumber: 726,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 722,
            columnNumber: 37
        }, this);
        $[106] = skillNodes;
        $[107] = t;
        $[108] = t59;
    } else {
        t59 = $[108];
    }
    let t60;
    if ($[109] === Symbol.for("react.memo_cache_sentinel")) {
        t60 = {
            borderRadius: 2,
            width: "100%"
        };
        $[109] = t60;
    } else {
        t60 = $[109];
    }
    let t61;
    if ($[110] === Symbol.for("react.memo_cache_sentinel")) {
        t61 = {
            display: "flex",
            alignItems: "center",
            mb: 2
        };
        $[110] = t61;
    } else {
        t61 = $[110];
    }
    let t62;
    if ($[111] === Symbol.for("react.memo_cache_sentinel")) {
        t62 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiEvents$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                mr: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 760,
            columnNumber: 11
        }, this);
        $[111] = t62;
    } else {
        t62 = $[111];
    }
    let t63;
    if ($[112] !== t) {
        t63 = t("instructorDashboard.sectionLeaderboards");
        $[112] = t;
        $[113] = t63;
    } else {
        t63 = $[113];
    }
    let t64;
    if ($[114] !== t63) {
        t64 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h5",
            gutterBottom: true,
            sx: t61,
            children: [
                t62,
                t63
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 777,
            columnNumber: 11
        }, this);
        $[114] = t63;
        $[115] = t64;
    } else {
        t64 = $[115];
    }
    let t65;
    if ($[116] !== loading || $[117] !== sectionStats || $[118] !== sectionStudents || $[119] !== sections || $[120] !== t) {
        t65 = loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {}, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 785,
            columnNumber: 21
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: sections.filter(_InstructorDashboardSectionsFilter).map({
                "InstructorDashboard[(anonymous)()]": (section_1, index)=>{
                    const stats_0 = sectionStats[section_1.id] || {
                        studentCount: 0,
                        averageGrade: 0,
                        averageCompletion: 0,
                        leaderboard: [],
                        assignmentCount: 0
                    };
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
                        defaultExpanded: index === 0,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
                                expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/InstructorDashboard.jsx",
                                    lineNumber: 794,
                                    columnNumber: 108
                                }, this),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        display: "flex",
                                        alignItems: "center",
                                        width: "100%",
                                        gap: 2
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "h6",
                                            sx: {
                                                flexGrow: 1
                                            },
                                            children: section_1.name
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/InstructorDashboard.jsx",
                                            lineNumber: 799,
                                            columnNumber: 18
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                            label: `${stats_0.studentCount} ${t("instructorDashboard.students")}`,
                                            size: "small",
                                            color: "primary",
                                            variant: "outlined"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/InstructorDashboard.jsx",
                                            lineNumber: 801,
                                            columnNumber: 49
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                            label: `${stats_0.averageGrade}% ${t("instructorDashboard.avg")}`,
                                            size: "small",
                                            color: "success",
                                            variant: "outlined"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/InstructorDashboard.jsx",
                                            lineNumber: 801,
                                            columnNumber: 176
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/InstructorDashboard.jsx",
                                    lineNumber: 794,
                                    columnNumber: 128
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                lineNumber: 794,
                                columnNumber: 78
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
                                children: stats_0.leaderboard.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    color: "text.secondary",
                                    sx: {
                                        textAlign: "center",
                                        py: 3
                                    },
                                    children: t("instructorDashboard.noDataYet")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/InstructorDashboard.jsx",
                                    lineNumber: 801,
                                    columnNumber: 378
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableContainer$2f$TableContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableContainer$3e$__["TableContainer"], {
                                    component: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"],
                                    variant: "outlined",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"], {
                                        size: "small",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableHead$2f$TableHead$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableHead$3e$__["TableHead"], {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableRow$3e$__["TableRow"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCell$3e$__["TableCell"], {
                                                            children: t("instructorDashboard.rank")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                            lineNumber: 804,
                                                            columnNumber: 164
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCell$3e$__["TableCell"], {
                                                            children: t("instructorDashboard.student")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                            lineNumber: 804,
                                                            columnNumber: 218
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCell$3e$__["TableCell"], {
                                                            align: "right",
                                                            children: t("instructorDashboard.average")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                            lineNumber: 804,
                                                            columnNumber: 275
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCell$3e$__["TableCell"], {
                                                            align: "right",
                                                            children: t("instructorDashboard.completed")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                            lineNumber: 804,
                                                            columnNumber: 346
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCell$3e$__["TableCell"], {
                                                            align: "right",
                                                            children: t("instructorDashboard.completion")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                            lineNumber: 804,
                                                            columnNumber: 419
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                    lineNumber: 804,
                                                    columnNumber: 154
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                lineNumber: 804,
                                                columnNumber: 143
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableBody$2f$TableBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableBody$3e$__["TableBody"], {
                                                children: stats_0.leaderboard.map({
                                                    "InstructorDashboard[(anonymous)() > stats_0.leaderboard.map()]": (student_0, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableRow$3e$__["TableRow"], {
                                                            sx: {
                                                                backgroundColor: idx < 3 ? `rgba(255, 215, 0, ${0.1 - idx * 0.03})` : "inherit",
                                                                "&:hover": {
                                                                    backgroundColor: "grey.100"
                                                                }
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCell$3e$__["TableCell"], {
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                                        sx: {
                                                                            display: "flex",
                                                                            alignItems: "center",
                                                                            gap: 1
                                                                        },
                                                                        children: [
                                                                            idx === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiEvents$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                sx: {
                                                                                    color: "gold"
                                                                                }
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                                lineNumber: 814,
                                                                                columnNumber: 44
                                                                            }, this),
                                                                            idx === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiEvents$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                sx: {
                                                                                    color: "silver"
                                                                                }
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                                lineNumber: 816,
                                                                                columnNumber: 49
                                                                            }, this),
                                                                            idx === 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiEvents$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                sx: {
                                                                                    color: "#cd7f32"
                                                                                }
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                                lineNumber: 818,
                                                                                columnNumber: 49
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                                children: idx + 1
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                                lineNumber: 820,
                                                                                columnNumber: 35
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                        lineNumber: 810,
                                                                        columnNumber: 37
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                    lineNumber: 810,
                                                                    columnNumber: 26
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCell$3e$__["TableCell"], {
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                                        sx: {
                                                                            display: "flex",
                                                                            alignItems: "center",
                                                                            gap: 1
                                                                        },
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__["Avatar"], {
                                                                                sx: {
                                                                                    width: 24,
                                                                                    height: 24,
                                                                                    fontSize: 12
                                                                                },
                                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formatUserName$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(sectionStudents[student_0.studentId] || {
                                                                                    id: student_0.studentId
                                                                                })
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                                lineNumber: 824,
                                                                                columnNumber: 30
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                                variant: "body2",
                                                                                noWrap: true,
                                                                                sx: {
                                                                                    maxWidth: 200
                                                                                },
                                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formatUserName$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatLastFirst"])(sectionStudents[student_0.studentId] || {
                                                                                    id: student_0.studentId
                                                                                })
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                                lineNumber: 830,
                                                                                columnNumber: 43
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                        lineNumber: 820,
                                                                        columnNumber: 98
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                    lineNumber: 820,
                                                                    columnNumber: 87
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCell$3e$__["TableCell"], {
                                                                    align: "right",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                                                        label: `${Math.round(student_0.average)}%`,
                                                                        size: "small",
                                                                        color: student_0.average >= 90 ? "success" : student_0.average >= 70 ? "info" : "warning"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                        lineNumber: 834,
                                                                        columnNumber: 90
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                    lineNumber: 834,
                                                                    columnNumber: 65
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCell$3e$__["TableCell"], {
                                                                    align: "right",
                                                                    children: [
                                                                        student_0.assignmentsCompleted,
                                                                        "/",
                                                                        student_0.totalAssignments
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                    lineNumber: 834,
                                                                    columnNumber: 258
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCell$3e$__["TableCell"], {
                                                                    align: "right",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                                        sx: {
                                                                            display: "flex",
                                                                            alignItems: "center",
                                                                            gap: 1,
                                                                            justifyContent: "flex-end"
                                                                        },
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                                                                                variant: "determinate",
                                                                                value: student_0.completion,
                                                                                sx: {
                                                                                    width: 60,
                                                                                    height: 6,
                                                                                    borderRadius: 3
                                                                                },
                                                                                color: student_0.completion >= 90 ? "success" : student_0.completion >= 70 ? "info" : "warning"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                                lineNumber: 839,
                                                                                columnNumber: 30
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                                variant: "caption",
                                                                                children: [
                                                                                    Math.round(student_0.completion),
                                                                                    "%"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                                lineNumber: 843,
                                                                                columnNumber: 131
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                        lineNumber: 834,
                                                                        columnNumber: 381
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                                    lineNumber: 834,
                                                                    columnNumber: 356
                                                                }, this)
                                                            ]
                                                        }, student_0.studentId, true, {
                                                            fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                            lineNumber: 805,
                                                            columnNumber: 109
                                                        }, this)
                                                }["InstructorDashboard[(anonymous)() > stats_0.leaderboard.map()]"])
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                                lineNumber: 804,
                                                columnNumber: 516
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/InstructorDashboard.jsx",
                                        lineNumber: 804,
                                        columnNumber: 123
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/InstructorDashboard.jsx",
                                    lineNumber: 804,
                                    columnNumber: 70
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/InstructorDashboard.jsx",
                                lineNumber: 801,
                                columnNumber: 324
                            }, this)
                        ]
                    }, section_1.id, true, {
                        fileName: "[project]/src/components/InstructorDashboard.jsx",
                        lineNumber: 794,
                        columnNumber: 18
                    }, this);
                }
            }["InstructorDashboard[(anonymous)()]"])
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 785,
            columnNumber: 42
        }, this);
        $[116] = loading;
        $[117] = sectionStats;
        $[118] = sectionStudents;
        $[119] = sections;
        $[120] = t;
        $[121] = t65;
    } else {
        t65 = $[121];
    }
    let t66;
    if ($[122] !== t64 || $[123] !== t65) {
        t66 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
            elevation: 3,
            sx: t60,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                children: [
                    t64,
                    t65
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/InstructorDashboard.jsx",
                lineNumber: 858,
                columnNumber: 40
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 858,
            columnNumber: 11
        }, this);
        $[122] = t64;
        $[123] = t65;
        $[124] = t66;
    } else {
        t66 = $[124];
    }
    let t67;
    if ($[125] !== t58 || $[126] !== t59 || $[127] !== t66) {
        t67 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t21,
            children: [
                t58,
                t59,
                t66
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/InstructorDashboard.jsx",
            lineNumber: 867,
            columnNumber: 11
        }, this);
        $[125] = t58;
        $[126] = t59;
        $[127] = t66;
        $[128] = t67;
    } else {
        t67 = $[128];
    }
    return t67;
}
_s(InstructorDashboard, "+Lsk+6gR2iO5+Zhjzuqkz+fuwIc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSkillTree"]
    ];
});
_c = InstructorDashboard;
function _InstructorDashboardSectionsFilter(s_9) {
    return s_9 != null && s_9.id != null;
}
function _InstructorDashboardAnonymous4(sum_5, s_8) {
    return sum_5 + s_8.assignmentCount;
}
function _InstructorDashboardAnonymous3(sum_4, s_7) {
    return sum_4 + s_7.averageCompletion;
}
function _InstructorDashboardAnonymous2(sum_3, s_6) {
    return sum_3 + s_6.averageGrade;
}
function _InstructorDashboardAnonymous(sum_2, s_5) {
    return sum_2 + s_5.studentCount;
}
function _InstructorDashboardUseEffectCalculateSectionStatsStudentRankingsReduce2(sum_1, s_4) {
    return sum_1 + s_4.completion;
}
function _InstructorDashboardUseEffectCalculateSectionStatsStudentRankingsReduce(sum_0, s_3) {
    return sum_0 + s_3.average;
}
function _InstructorDashboardUseEffectCalculateSectionStatsStudentRankingsSort(a_2, b) {
    return b.average - a_2.average;
}
function _InstructorDashboardUseEffectCalculateSectionStatsAnonymousGradesReduce(sum, g_0) {
    return sum + g_0;
}
function _InstructorDashboardUseEffectCalculateSectionStatsAnonymousAnonymous(g) {
    return g.accuracy;
}
function _InstructorDashboardUseEffectCalculateSectionStatsSectionsFilter(s_2) {
    return s_2 != null && s_2.id != null;
}
function _InstructorDashboardUseEffectSectionsFilter2(s_1) {
    return s_1 != null && s_1.id != null && s_1.code;
}
function _InstructorDashboardUseEffectAnonymousItems_0Filter(item_0) {
    return item_0 != null && item_0.id != null;
}
function _InstructorDashboardUseEffectSectionIDsMap(id) {
    return {
        sectionID: {
            eq: id
        }
    };
}
function _InstructorDashboardUseEffectValidSectionsMap(s_0) {
    return s_0.id;
}
function _InstructorDashboardUseEffectSectionsFilter(s) {
    return s != null && s.id != null;
}
function _InstructorDashboardUseEffectAnonymousValidItemsFilter(grade) {
    return grade.accuracy != null;
}
function _InstructorDashboardUseEffectAnonymousItemsFilter(item) {
    return item != null && item.id != null;
}
var _c;
__turbopack_context__.k.register(_c, "InstructorDashboard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useChatPageContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useChatPageContext",
    ()=>useChatPageContext
]);
/**
 * useChatPageContext - Register page-specific context with ChatContext
 * 
 * This hook allows pages to register their available context (unit, files, sections, etc.)
 * with the global ChatContext, making that context available to the chat sidebar.
 * 
 * @example
 * // In Unit Editor page
 * function UnitEditorPage() {
 *   const { unit, files, dictionary, questions } = useContext(UnitContext);
 *   const { sections } = useContext(SectionContext);
 *   const { vectorStoreSearch } = useContext(VectorStoreContext);
 *   const editorRef = useRef(null);
 *   
 *   useChatPageContext({
 *     unit,
 *     files,
 *     dictionary,
 *     questions,
 *     sections,
 *     editorRef,
 *     vectorStoreSearch,
 *   });
 *   
 *   return <...>
 * }
 * 
 * @see docs/GLOBAL_CHAT_INTEGRATION_PLAN.md
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/chatContext.jsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useChatPageContext(context = {}) {
    _s();
    const { setPageContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { unit = null, files = [], dictionary = [], questions = [], sections = [], editorRef = null, vectorStoreSearch = null } = context;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChatPageContext.useEffect": ()=>{
            console.log('[useChatPageContext] Registering page context:', {
                hasUnit: !!unit,
                filesCount: files?.length || 0,
                dictionaryCount: dictionary?.length || 0,
                questionsCount: questions?.length || 0,
                sectionsCount: sections?.length || 0,
                hasEditorRef: !!editorRef,
                hasVectorStoreSearch: !!vectorStoreSearch
            });
            setPageContext({
                unit,
                files,
                dictionary,
                questions,
                sections,
                editorRef,
                vectorStoreSearch
            });
            // Cleanup: reset to empty context when component unmounts
            return ({
                "useChatPageContext.useEffect": ()=>{
                    console.log('[useChatPageContext] Cleaning up page context');
                    setPageContext({
                        unit: null,
                        files: [],
                        dictionary: [],
                        questions: [],
                        sections: [],
                        editorRef: null,
                        vectorStoreSearch: null
                    });
                }
            })["useChatPageContext.useEffect"];
        }
    }["useChatPageContext.useEffect"], [
        // Dependencies - update when any context changes
        unit?.id,
        files?.length,
        dictionary?.length,
        questions?.length,
        sections?.length,
        editorRef?.current,
        vectorStoreSearch,
        setPageContext
    ]);
}
_s(useChatPageContext, "0aGcDEhsgvDsw4KhinDnLq0Ig9M=");
const __TURBOPACK__default__export__ = useChatPageContext;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[locale]/sections/page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$CollaborativeChatWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/CollaborativeChatWrapper.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$People$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/People.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Archive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Archive.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Unarchive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Unarchive.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MoreVert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContentText$2f$DialogContentText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContentText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContentText/DialogContentText.js [app-client] (ecmascript) <export default as DialogContentText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript) <export default as CardContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript) <export default as Snackbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Menu/Menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemIcon/ListItemIcon.js [app-client] (ecmascript) <export default as ListItemIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-client] (ecmascript) <export default as FormControlLabel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Switch/Switch.js [app-client] (ecmascript) <export default as Switch>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Add.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/AppShellContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LazyCardMedia.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$InstructorDashboard$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/InstructorDashboard.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useChatPageContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function getUserGroups(user) {
    return user?.signInUserSession?.accessToken?.payload?.["cognito:groups"] || user?.signInUserSession?.idToken?.payload?.["cognito:groups"] || user?.groups || [];
}
function getUserId(user) {
    return user?.signInUserSession?.idToken?.payload?.sub || user?.userId || user?.username;
}
function Sections({ user }) {
    _s();
    /**
   * Sections is a page that displays a list of sections.
   * For Instructor users, it displays a list of sections they are teaching.
   * For Student users, it displays a list of sections they are enrolled in.
   * For Admin users, it displays a list of all sections.
   *
   * Sections can be created by Instructors and Admins.
   * Sections can be edited by Instructors and Admins.
   * Sections can be deleted by Admins.
   *
   * Sections can be searched by name.
   * Sections can be filtered by status (draft, published, inactive, archived).
   * Sections can be sorted by name, status, and date created.
   *
   * Sections can be exported as a CSV file.
   * Sections can be imported as a CSV file.
   *
   * Sections can be archived by Instructors and Admins.
   * Sections can be unarchived by Instructors and Admins.
   *
   * Sections can be deleted by Admins.
   *
   * Sections can be copied by Instructors and Admins.
   *
   */ const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("pages");
    const { drawerOpen, drawerWidth, isDesktop } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppShell"])();
    const { sections, refetchSections } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [work, setIsWorking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [open, setOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [showArchived, setShowArchived] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [menuAnchorEl, setMenuAnchorEl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [menuSectionId, setMenuSectionId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [sectionsLoaded, setSectionsLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [snackbar, setSnackbar] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        open: false,
        message: "",
        severity: "error"
    });
    // Mark sections as loaded once data arrives from subscription
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "Sections.useEffect": ()=>{
            if (sections && sections.length > 0) {
                setSectionsLoaded(true);
            }
            // Also mark loaded after a brief timeout to handle genuinely empty state
            const timer = setTimeout({
                "Sections.useEffect.timer": ()=>setSectionsLoaded(true)
            }["Sections.useEffect.timer"], 2000);
            return ({
                "Sections.useEffect": ()=>clearTimeout(timer)
            })["Sections.useEffect"];
        }
    }["Sections.useEffect"], [
        sections
    ]);
    // Register page context with global chat
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPageContext"])({
        sections
    });
    const userGroups = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "Sections.useMemo[userGroups]": ()=>getUserGroups(user)
    }["Sections.useMemo[userGroups]"], [
        user
    ]);
    const isInstructor = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "Sections.useMemo[isInstructor]": ()=>userGroups.includes("Instructors") || userGroups.includes("Admins")
    }["Sections.useMemo[isInstructor]"], [
        userGroups
    ]);
    const userId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "Sections.useMemo[userId]": ()=>getUserId(user)
    }["Sections.useMemo[userId]"], [
        user
    ]);
    const ownedSections = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "Sections.useMemo[ownedSections]": ()=>{
            if (!userId) return [];
            // Filter out null items explicitly before checking ownership
            const owned = sections.filter({
                "Sections.useMemo[ownedSections].owned": (section)=>section != null && section.id != null && (section.owner === userId || section.instructor === userId)
            }["Sections.useMemo[ownedSections].owned"]);
            return owned;
        }
    }["Sections.useMemo[ownedSections]"], [
        sections,
        userId
    ]);
    const canViewInstructorDashboard = isInstructor || ownedSections.length > 0;
    const handleClickOpen = ()=>{
        setOpen(true);
    };
    const handleClose = ()=>{
        setOpen(false);
    };
    const handleMenuOpen = (event, sectionId)=>{
        setMenuAnchorEl(event.currentTarget);
        setMenuSectionId(sectionId);
    };
    const handleMenuClose = ()=>{
        setMenuAnchorEl(null);
        setMenuSectionId(null);
    };
    async function handleArchiveToggle(section_0) {
        handleMenuClose();
        setIsWorking(true);
        try {
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const newStatus = section_0.status === "ARCHIVED" ? "PUBLISHED" : "ARCHIVED";
            await client.models.Section.update({
                id: section_0.id,
                status: newStatus
            });
            setSnackbar({
                open: true,
                message: newStatus === "ARCHIVED" ? t("sections.archivedSuccess") : t("sections.unarchivedSuccess"),
                severity: "success"
            });
        } catch (error) {
            console.error("[Section Archive] Error:", error);
            setSnackbar({
                open: true,
                message: t("sections.archiveError"),
                severity: "error"
            });
        } finally{
            setIsWorking(false);
        }
    }
    const visibleSections = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "Sections.useMemo[visibleSections]": ()=>{
            if (!sections) return [];
            const valid = sections.filter({
                "Sections.useMemo[visibleSections].valid": (s)=>s != null && s.id != null
            }["Sections.useMemo[visibleSections].valid"]);
            if (showArchived) return valid;
            return valid.filter({
                "Sections.useMemo[visibleSections]": (s_0)=>s_0.status !== "ARCHIVED"
            }["Sections.useMemo[visibleSections]"]);
        }
    }["Sections.useMemo[visibleSections]"], [
        sections,
        showArchived
    ]);
    const archivedCount = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "Sections.useMemo[archivedCount]": ()=>{
            if (!sections) return 0;
            return sections.filter({
                "Sections.useMemo[archivedCount]": (s_1)=>s_1 != null && s_1.status === "ARCHIVED"
            }["Sections.useMemo[archivedCount]"]).length;
        }
    }["Sections.useMemo[archivedCount]"], [
        sections
    ]);
    async function handleCreate(event_0) {
        setIsWorking(true);
        event_0.preventDefault();
        const form = new FormData(event_0.target);
        try {
            const name = form.get("name").toString();
            const description = form.get("description").toString();
            const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const { data, errors } = await client_0.mutations.createSectionGroup({
                name: name.trim(),
                description: description.trim() || null
            });
            if (errors?.length) {
                throw new Error(errors[0]?.message || "Failed to create section");
            }
            const result = typeof data === "string" ? JSON.parse(data) : data;
            // Refetch sections to get the newly created section
            // (subscriptions may not always deliver immediately)
            await refetchSections();
            setIsWorking(false);
            setOpen(false);
        } catch (error_0) {
            // Log detailed error information for debugging
            console.error("[Section Creation] Error:", error_0);
            console.error("[Section Creation] Error details:", {
                message: error_0?.message,
                stack: error_0?.stack,
                response: error_0?.response
            });
            // Show generic user-friendly message (hide implementation details)
            setSnackbar({
                open: true,
                message: "Unable to create section. Please try again.",
                severity: "error"
            });
            setIsWorking(false);
        }
    }
    // Sections now come from SectionContext - no duplicate subscription needed
    // console.log('sections', sections)
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                "data-tour": "sections-page",
                style: {
                    padding: "2rem 1rem"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                        "data-tour": "section-form",
                        open: open,
                        onClose: handleClose,
                        "aria-labelledby": "form-dialog-title",
                        slotProps: {
                            backdrop: {
                                sx: {
                                    //Your style here....
                                    backdropFilter: "blur(1px)"
                                }
                            }
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            onSubmit: handleCreate,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                                    children: t("sections.newSection.title")
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                    lineNumber: 211,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContentText$2f$DialogContentText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContentText$3e$__["DialogContentText"], {
                                            children: t("sections.newSection.description")
                                        }, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 213,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 216,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                            sx: {
                                                width: "100%"
                                            },
                                            required: true,
                                            id: "name",
                                            name: "name",
                                            label: t("sections.newSection.nameLabel"),
                                            variant: "outlined"
                                        }, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 218,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 221,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 222,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                            sx: {
                                                width: "100%"
                                            },
                                            required: true,
                                            multiline: true,
                                            rows: 4,
                                            id: "description",
                                            name: "description",
                                            label: t("sections.newSection.descriptionLabel"),
                                            variant: "outlined"
                                        }, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 223,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 226,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 227,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 229,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 230,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                    lineNumber: 212,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                                    sx: {
                                        padding: "2rem"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                            disabled: work,
                                            onClick: handleClose,
                                            color: "primary",
                                            variant: "outlined",
                                            children: t("sections.newSection.cancel")
                                        }, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 235,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                            disabled: work,
                                            type: "submit",
                                            variant: "contained",
                                            children: t("sections.newSection.create")
                                        }, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 238,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                    lineNumber: 232,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[locale]/sections/page.jsx",
                            lineNumber: 210,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/[locale]/sections/page.jsx",
                        lineNumber: 202,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            display: "flex",
                            flexDirection: "column",
                            margin: "1rem auto"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    margin: "0",
                                    padding: "2rem",
                                    flexGrow: "1",
                                    minWidth: "min-content",
                                    // center the text both horizontally and vertically
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center"
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h2",
                                        component: "div",
                                        sx: {
                                            flexGrow: 1
                                        },
                                        children: [
                                            t("sections.title"),
                                            " "
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/[locale]/sections/page.jsx",
                                        lineNumber: 261,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                        sx: {
                                            display: "flex",
                                            alignItems: "center",
                                            gap: 2
                                        },
                                        children: [
                                            archivedCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__["FormControlLabel"], {
                                                control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
                                                    checked: showArchived,
                                                    onChange: (e)=>setShowArchived(e.target.checked),
                                                    size: "small"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                                    lineNumber: 271,
                                                    columnNumber: 64
                                                }, this),
                                                label: t("sections.showArchived", {
                                                    count: archivedCount
                                                }),
                                                sx: {
                                                    mr: 1
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/app/[locale]/sections/page.jsx",
                                                lineNumber: 271,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                "data-tour": "create-section-button",
                                                variant: "outlined",
                                                color: "primary",
                                                disabled: work,
                                                onClick: handleClickOpen,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                        fileName: "[project]/app/[locale]/sections/page.jsx",
                                                        lineNumber: 277,
                                                        columnNumber: 17
                                                    }, this),
                                                    " ",
                                                    t("sections.createNew")
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/[locale]/sections/page.jsx",
                                                lineNumber: 276,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/[locale]/sections/page.jsx",
                                        lineNumber: 266,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/[locale]/sections/page.jsx",
                                lineNumber: 250,
                                columnNumber: 11
                            }, this),
                            canViewInstructorDashboard && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$InstructorDashboard$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                sections: ownedSections
                            }, void 0, false, {
                                fileName: "[project]/app/[locale]/sections/page.jsx",
                                lineNumber: 284,
                                columnNumber: 42
                            }, this),
                            !sectionsLoaded && sections.length === 0 && null,
                            sectionsLoaded && sections.length === 0 && //embed url to create a new section
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                                elevation: 3,
                                sx: {
                                    display: "flex",
                                    margin: "1rem auto",
                                    maxWidth: "500px",
                                    minHeight: "300px",
                                    borderRadius: 3
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        display: "flex",
                                        flexDirection: "column",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        flexGrow: "1",
                                        p: 4
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                                        sx: {
                                            flex: "1 1 auto",
                                            display: "flex",
                                            flexDirection: "column",
                                            justifyContent: "center",
                                            alignItems: "center",
                                            textAlign: "center"
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                component: "div",
                                                variant: "h5",
                                                sx: {
                                                    mb: 3
                                                },
                                                children: t("sections.noSectionsYet")
                                            }, void 0, false, {
                                                fileName: "[project]/app/[locale]/sections/page.jsx",
                                                lineNumber: 313,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                variant: "outlined",
                                                color: "primary",
                                                onClick: handleClickOpen,
                                                disabled: work,
                                                sx: {
                                                    textTransform: "none",
                                                    fontWeight: 600,
                                                    px: 3,
                                                    py: 1,
                                                    borderRadius: 2
                                                },
                                                children: t("sections.createNewSection")
                                            }, void 0, false, {
                                                fileName: "[project]/app/[locale]/sections/page.jsx",
                                                lineNumber: 318,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/[locale]/sections/page.jsx",
                                        lineNumber: 305,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                    lineNumber: 297,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/[locale]/sections/page.jsx",
                                lineNumber: 290,
                                columnNumber: 9
                            }, this),
                            sections && visibleSections.map(function(section_1) {
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                                    "data-tour": "section-card",
                                    elevation: 2,
                                    sx: {
                                        display: "flex",
                                        margin: "1rem auto",
                                        width: isDesktop && drawerOpen ? `calc(90vw - ${drawerWidth}px)` : "90vw",
                                        maxWidth: "80rem",
                                        borderRadius: 2,
                                        borderLeft: "4px solid",
                                        borderLeftColor: "text.primary",
                                        transition: "all 0.3s ease-in-out",
                                        "&:hover": {
                                            elevation: 6,
                                            transform: "translateY(-2px)",
                                            boxShadow: "0 8px 24px rgba(0,0,0,0.12)"
                                        }
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            sx: {
                                                display: "flex",
                                                flexDirection: "column",
                                                flexGrow: "1",
                                                p: 0.5
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                                                    sx: {
                                                        flex: "1 0 auto",
                                                        pb: 1
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                            sx: {
                                                                display: "flex",
                                                                alignItems: "center",
                                                                justifyContent: "space-between"
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                    component: "div",
                                                                    variant: "h5",
                                                                    sx: {
                                                                        fontWeight: 600,
                                                                        mb: 0.5
                                                                    },
                                                                    children: [
                                                                        section_1?.name || t("sections.untitledSection"),
                                                                        section_1.status === "ARCHIVED" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                                                            label: t("sections.archived"),
                                                                            size: "small",
                                                                            color: "default",
                                                                            sx: {
                                                                                ml: 1,
                                                                                verticalAlign: "middle"
                                                                            }
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                                                            lineNumber: 366,
                                                                            columnNumber: 63
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                                                    lineNumber: 361,
                                                                    columnNumber: 25
                                                                }, this),
                                                                (isInstructor || section_1.owner === userId) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                                    size: "small",
                                                                    onClick: (e_0)=>handleMenuOpen(e_0, section_1.id),
                                                                    disabled: work,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                                        fileName: "[project]/app/[locale]/sections/page.jsx",
                                                                        lineNumber: 372,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                                                    lineNumber: 371,
                                                                    columnNumber: 74
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                                            lineNumber: 356,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "body1",
                                                            color: "text.secondary",
                                                            component: "div",
                                                            sx: {
                                                                lineHeight: 1.6
                                                            },
                                                            children: section_1?.description || ""
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                                            lineNumber: 375,
                                                            columnNumber: 23
                                                        }, this),
                                                        section_1?.code && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                            sx: {
                                                                mt: 1.5,
                                                                display: "flex",
                                                                alignItems: "center",
                                                                gap: 1
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                    variant: "body2",
                                                                    color: "text.secondary",
                                                                    sx: {
                                                                        fontWeight: 500
                                                                    },
                                                                    children: [
                                                                        t("sections.joinCode"),
                                                                        ":"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                                                    lineNumber: 386,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                                                    "data-tour": "join-code",
                                                                    label: section_1.code,
                                                                    size: "small",
                                                                    sx: {
                                                                        fontFamily: "monospace",
                                                                        fontSize: "0.875rem",
                                                                        fontWeight: 600,
                                                                        backgroundColor: "action.selected",
                                                                        border: "1px solid",
                                                                        borderColor: "divider"
                                                                    }
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                                                    lineNumber: 391,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                                            lineNumber: 380,
                                                            columnNumber: 43
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                                    lineNumber: 352,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        display: "flex",
                                                        alignItems: "center",
                                                        pl: 2,
                                                        pb: 1.5
                                                    },
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                        variant: "outlined",
                                                        href: `/section/${section_1.id}`,
                                                        disabled: work,
                                                        startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$People$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                                            lineNumber: 407,
                                                            columnNumber: 111
                                                        }, this),
                                                        sx: {
                                                            textTransform: "none",
                                                            fontWeight: 600,
                                                            px: 3,
                                                            py: 1,
                                                            borderRadius: 2,
                                                            boxShadow: 2,
                                                            color: "text.primary",
                                                            borderColor: "text.primary",
                                                            "&:hover": {
                                                                boxShadow: 4,
                                                                borderColor: "text.primary",
                                                                backgroundColor: "action.hover"
                                                            }
                                                        },
                                                        children: t("sections.viewSection")
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/[locale]/sections/page.jsx",
                                                        lineNumber: 407,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                                    lineNumber: 401,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 346,
                                            columnNumber: 19
                                        }, this),
                                        section_1?.featuredImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LazyCardMedia$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            s3Key: section_1?.featuredImage,
                                            identityId: section_1?.identityId
                                        }, void 0, false, {
                                            fileName: "[project]/app/[locale]/sections/page.jsx",
                                            lineNumber: 426,
                                            columnNumber: 48
                                        }, this)
                                    ]
                                }, section_1.id, true, {
                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                    lineNumber: 331,
                                    columnNumber: 18
                                }, this);
                            }),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                anchorEl: menuAnchorEl,
                                open: Boolean(menuAnchorEl),
                                onClose: handleMenuClose,
                                children: (()=>{
                                    const menuSection = sections?.find((s_2)=>s_2?.id === menuSectionId);
                                    if (!menuSection) return null;
                                    const isArchived = menuSection.status === "ARCHIVED";
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                        onClick: ()=>handleArchiveToggle(menuSection),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                                children: isArchived ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Unarchive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    fontSize: "small"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                                    lineNumber: 438,
                                                    columnNumber: 35
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Archive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    fontSize: "small"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[locale]/sections/page.jsx",
                                                    lineNumber: 438,
                                                    columnNumber: 72
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/[locale]/sections/page.jsx",
                                                lineNumber: 437,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                                children: isArchived ? t("sections.unarchive") : t("sections.archive")
                                            }, void 0, false, {
                                                fileName: "[project]/app/[locale]/sections/page.jsx",
                                                lineNumber: 440,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/[locale]/sections/page.jsx",
                                        lineNumber: 436,
                                        columnNumber: 20
                                    }, this);
                                })()
                            }, void 0, false, {
                                fileName: "[project]/app/[locale]/sections/page.jsx",
                                lineNumber: 431,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/[locale]/sections/page.jsx",
                        lineNumber: 245,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/[locale]/sections/page.jsx",
                lineNumber: 199,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
                open: snackbar.open,
                autoHideDuration: 6000,
                onClose: ()=>setSnackbar({
                        ...snackbar,
                        open: false
                    }),
                anchorOrigin: {
                    vertical: "bottom",
                    horizontal: "center"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                    onClose: ()=>setSnackbar({
                            ...snackbar,
                            open: false
                        }),
                    severity: snackbar.severity,
                    sx: {
                        width: "100%"
                    },
                    variant: "filled",
                    children: snackbar.message
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/sections/page.jsx",
                    lineNumber: 457,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/[locale]/sections/page.jsx",
                lineNumber: 450,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(Sections, "VpDj6Jcj+TV4N4uL1HQp7iSQQ1c=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppShell"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPageContext"]
    ];
});
_c = Sections;
function WrappedPage() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "4e2a9dd68a4f523649d993936220dacd81aa44fd80d17ef29fee46acaea78271") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4e2a9dd68a4f523649d993936220dacd81aa44fd80d17ef29fee46acaea78271";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionProvider"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Sections, {}, void 0, false, {
                    fileName: "[project]/app/[locale]/sections/page.jsx",
                    lineNumber: 478,
                    columnNumber: 27
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$CollaborativeChatWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CollaborativeChatWrapper"], {}, void 0, false, {
                    fileName: "[project]/app/[locale]/sections/page.jsx",
                    lineNumber: 478,
                    columnNumber: 39
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/sections/page.jsx",
            lineNumber: 478,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c1 = WrappedPage;
const __TURBOPACK__default__export__ = WrappedPage;
var _c, _c1;
__turbopack_context__.k.register(_c, "Sections");
__turbopack_context__.k.register(_c1, "WrappedPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_0es.6a_._.js.map