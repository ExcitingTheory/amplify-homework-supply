(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/utils/debug/discordWebhook.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Discord Webhook Integration for Debug Diagnostics
 * 
 * Sends diagnostic snapshots to a Discord channel via webhook.
 * Useful for support teams to automatically receive user diagnostics.
 * 
 * Setup:
 * 1. Create a Discord webhook in your support channel
 * 2. Set NEXT_PUBLIC_DISCORD_WEBHOOK_URL in .env.local
 * 3. Users can opt-in to send diagnostics when exporting
 */ __turbopack_context__.s([
    "getDiscordWebhookUrl",
    ()=>getDiscordWebhookUrl,
    "isDiscordWebhookConfigured",
    ()=>isDiscordWebhookConfigured,
    "sendToDiscord",
    ()=>sendToDiscord,
    "testDiscordWebhook",
    ()=>testDiscordWebhook
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * Sanitize sensitive data before sending to Discord
 */ function sanitizeSnapshot(snapshot) {
    const sanitized = {
        ...snapshot
    };
    // Redact sensitive fields from contexts (may contain auth info)
    if (sanitized.contexts) {
        sanitized.contexts = Object.fromEntries(Object.entries(sanitized.contexts).map(([key, value])=>{
            // Redact authentication tokens if present
            if (key.toLowerCase().includes('auth') && typeof value === 'object' && value !== null) {
                return [
                    key,
                    {
                        ...value,
                        session: '[REDACTED]',
                        tokens: '[REDACTED]',
                        credentials: '[REDACTED]'
                    }
                ];
            }
            return [
                key,
                value
            ];
        }));
    }
    // Redact sensitive localStorage/sessionStorage
    const redactKeys = [
        'token',
        'auth',
        'credential',
        'password',
        'secret'
    ];
    if (sanitized.localStorage) {
        sanitized.localStorage = Object.fromEntries(Object.entries(sanitized.localStorage).map(([key, value])=>[
                key,
                redactKeys.some((k)=>key.toLowerCase().includes(k)) ? '[REDACTED]' : value
            ]));
    }
    if (sanitized.sessionStorage) {
        sanitized.sessionStorage = Object.fromEntries(Object.entries(sanitized.sessionStorage).map(([key, value])=>[
                key,
                redactKeys.some((k)=>key.toLowerCase().includes(k)) ? '[REDACTED]' : value
            ]));
    }
    return sanitized;
}
/**
 * Format snapshot data for Discord (limited to 2000 chars per field)
 */ function formatForDiscord(snapshot) {
    const info = [
        `**Timestamp:** ${new Date(snapshot.timestamp).toLocaleString()}`,
        `**Version:** ${snapshot.version}`,
        `**URL:** ${snapshot.environment.url}`,
        `**Browser:** ${snapshot.environment.userAgent.substring(0, 100)}`,
        `**Platform:** ${snapshot.environment.platform}`,
        `**Screen:** ${snapshot.environment.screenSize.width}x${snapshot.environment.screenSize.height}`
    ];
    if (snapshot.errors?.length > 0) {
        info.push(`**Errors:** ${snapshot.errors.length} error(s) detected`);
    }
    // Add data store summary if available
    if (snapshot.dataStore) {
        const modelCounts = Object.entries(snapshot.dataStore).filter(([key])=>Array.isArray(snapshot.dataStore[key])).map(([key, value])=>`${key}:${value.length}`).join(', ');
        if (modelCounts) {
            info.push(`**Data:** ${modelCounts}`);
        }
    }
    return info.join('\n');
}
/**
 * Create Discord embed for diagnostic report
 */ function createEmbed(report, sanitized) {
    const hasErrors = sanitized.errors && sanitized.errors.length > 0;
    return {
        title: '🐛 Support Diagnostic Report',
        description: report.description || 'User submitted diagnostic report',
        color: hasErrors ? 0xff0000 : 0x00ff00,
        fields: [
            {
                name: '📊 System Information',
                value: formatForDiscord(sanitized),
                inline: false
            },
            ...report.userContact ? [
                {
                    name: '👤 User Contact',
                    value: report.userContact,
                    inline: true
                }
            ] : [],
            ...hasErrors ? [
                {
                    name: '❌ Recent Errors',
                    value: sanitized.errors.slice(0, 3).map((err, i)=>`${i + 1}. ${err.message?.substring(0, 100)}...`).join('\n') || 'See attached file',
                    inline: false
                }
            ] : [],
            ...report.artifactUrl ? [
                {
                    name: '📎 Full Diagnostic Artifact (S3)',
                    value: `[Download JSON (30-day link)](${report.artifactUrl})`,
                    inline: false
                }
            ] : []
        ],
        timestamp: new Date(sanitized.timestamp).toISOString(),
        footer: {
            text: 'Homework Supply Debug System'
        }
    };
}
async function sendToDiscord(report, config) {
    try {
        // Sanitize sensitive data
        const sanitized = sanitizeSnapshot(report.snapshot);
        // Create embed
        const embed = createEmbed(report, sanitized);
        // Create Discord message payload
        const payload = {
            username: config.username || 'Support Bot',
            avatar_url: config.avatarUrl,
            embeds: [
                embed
            ]
        };
        // Send to Discord
        const response = await fetch(config.webhookUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });
        if (!response.ok) {
            const errorText = await response.text();
            console.error('[Discord Webhook] Failed to send:', response.status, errorText);
            return {
                success: false,
                error: `HTTP ${response.status}: ${errorText}`
            };
        }
        // Optionally send full snapshot as file attachment
        // (Discord webhooks support file uploads via multipart/form-data)
        if (sanitized.logs && sanitized.logs.length > 1000 || sanitized.errors && sanitized.errors.length > 0) {
            await sendFullSnapshot(sanitized, config.webhookUrl);
        }
        console.log('[Discord Webhook] Diagnostic report sent successfully');
        return {
            success: true
        };
    } catch (error) {
        console.error('[Discord Webhook] Error sending diagnostic:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error'
        };
    }
}
/**
 * Send full snapshot as file attachment (for detailed diagnostics)
 */ async function sendFullSnapshot(snapshot, webhookUrl) {
    try {
        const formData = new FormData();
        // Create JSON file
        const json = JSON.stringify(snapshot, null, 2);
        const blob = new Blob([
            json
        ], {
            type: 'application/json'
        });
        const filename = `diagnostic-${snapshot.timestamp}.json`;
        formData.append('files[0]', blob, filename);
        formData.append('payload_json', JSON.stringify({
            content: '📎 Full diagnostic snapshot attached'
        }));
        const response = await fetch(webhookUrl, {
            method: 'POST',
            body: formData
        });
        if (!response.ok) {
            console.error('[Discord Webhook] Failed to send file attachment:', response.status);
        }
    } catch (error) {
        console.error('[Discord Webhook] Error sending file attachment:', error);
    }
}
function getDiscordWebhookUrl() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    // Check environment variable
    const envUrl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_DISCORD_WEBHOOK_URL;
    if (envUrl && envUrl.startsWith('https://discord.com/api/webhooks/')) {
        return envUrl;
    }
    // Check localStorage override (for testing)
    const localUrl = localStorage.getItem('discord-webhook-url');
    if (localUrl && localUrl.startsWith('https://discord.com/api/webhooks/')) {
        return localUrl;
    }
    return null;
}
function isDiscordWebhookConfigured() {
    return getDiscordWebhookUrl() !== null;
}
async function testDiscordWebhook(webhookUrl) {
    const url = webhookUrl || getDiscordWebhookUrl();
    if (!url) return false;
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                content: '✅ Discord webhook test successful! Integration is working.',
                username: 'Support Bot Test'
            })
        });
        return response.ok;
    } catch (error) {
        console.error('[Discord Webhook] Test failed:', error);
        return false;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/debug/uploadDebugArtifact.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isDebugArtifactUploadEnabled",
    ()=>isDebugArtifactUploadEnabled,
    "uploadDebugArtifact",
    ()=>uploadDebugArtifact
]);
/**
 * Upload debug artifact to S3 for support analysis
 * 
 * Uploads diagnostic snapshots to a public S3 path and generates
 * a signed URL with 30-day expiration for support team access.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/client/apis/uploadData.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$getUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/getUrl.mjs [app-client] (ecmascript)");
;
async function uploadDebugArtifact(snapshot) {
    try {
        // Create filename with timestamp
        const timestamp = snapshot.timestamp;
        const filename = `diagnostic-${timestamp}.json`;
        const key = `debug/${filename}`;
        // Convert snapshot to JSON blob
        const json = JSON.stringify(snapshot, null, 2);
        const blob = new Blob([
            json
        ], {
            type: 'application/json'
        });
        console.log('[DebugArtifact] Uploading to S3:', key);
        // Upload to S3 public path
        const uploadOperation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
            key,
            data: blob,
            options: {
                contentType: 'application/json',
                accessLevel: 'guest'
            }
        });
        // Wait for upload to complete
        const result = await uploadOperation.result;
        console.log('[DebugArtifact] Upload completed:', result);
        // Generate signed URL with 30-day expiration
        const THIRTY_DAYS_IN_SECONDS = 30 * 24 * 60 * 60; // 2,592,000 seconds
        const urlResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$getUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUrl"])({
            key,
            options: {
                accessLevel: 'guest',
                expiresIn: THIRTY_DAYS_IN_SECONDS
            }
        });
        const signedUrl = urlResult.url.href;
        console.log('[DebugArtifact] Generated signed URL (30-day expiration)');
        return {
            key,
            url: signedUrl
        };
    } catch (error) {
        console.error('[DebugArtifact] Upload failed:', error);
        throw new Error(error instanceof Error ? `Failed to upload debug artifact: ${error.message}` : 'Failed to upload debug artifact: Unknown error');
    }
}
function isDebugArtifactUploadEnabled() {
    return ("TURBOPACK compile-time value", "object") !== 'undefined';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAmplifyClient",
    ()=>getAmplifyClient,
    "resetAmplifyClient",
    ()=>resetAmplifyClient
]);
/**
 * Amplify Gen 2 Client Singleton
 * 
 * Provides a centralized GraphQL client for all data operations.
 * Replaces Gen 1 DataStore across the application.
 * 
 * Usage:
 * ```typescript
 * import { getAmplifyClient } from '@/utils/amplifyClient';
 * 
 * const client = getAmplifyClient();
 * const { data, errors } = await client.models.Unit.list();
 * ```
 * 
 * @see https://docs.amplify.aws/gen2/build-a-backend/data/connect-to-API/
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$api$2f$dist$2f$esm$2f$API$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/api/dist/esm/API.mjs [app-client] (ecmascript)");
;
// Singleton client instance - created once and reused
let client = null;
const getAmplifyClient = ()=>{
    if (!client) {
        client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$api$2f$dist$2f$esm$2f$API$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateClient"])({
            authMode: 'userPool'
        });
    }
    return client;
};
const resetAmplifyClient = ()=>{
    client = null;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/sanitizeHtml.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sanitizeInlineHtml",
    ()=>sanitizeInlineHtml,
    "sanitizeRichHtml",
    ()=>sanitizeRichHtml,
    "sanitizeSvg",
    ()=>sanitizeSvg
]);
/**
 * Centralized HTML/SVG sanitization for untrusted markup.
 *
 * Uses DOMPurify with a strict SVG-oriented allowlist. All user-influenced
 * markup (crest SVGs, ruby tags, editor previews) must pass through one of
 * these helpers before being rendered via dangerouslySetInnerHTML.
 *
 * @module utils/sanitizeHtml
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dompurify/dist/purify.es.mjs [app-client] (ecmascript)");
;
function sanitizeSvg(dirty) {
    if (!dirty) return "";
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].sanitize(dirty, {
        USE_PROFILES: {
            svg: true,
            svgFilters: true
        },
        ADD_TAGS: [
            "use"
        ],
        ADD_ATTR: [
            "xlink:href",
            "href",
            "clip-path",
            "mask"
        ],
        FORBID_TAGS: [
            "script",
            "foreignObject",
            "iframe",
            "embed",
            "object"
        ],
        FORBID_ATTR: [
            "onload",
            "onerror",
            "onclick",
            "onmouseover",
            "onfocus",
            "onblur",
            "onanimationend",
            "onbegin"
        ]
    });
}
function sanitizeInlineHtml(dirty) {
    if (!dirty) return "";
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].sanitize(dirty, {
        ALLOWED_TAGS: [
            "ruby",
            "rt",
            "rp",
            "rb",
            "span",
            "em",
            "strong",
            "br",
            "sup",
            "sub"
        ],
        ALLOWED_ATTR: [
            "class",
            "lang",
            "dir"
        ],
        ALLOW_DATA_ATTR: false
    });
}
function sanitizeRichHtml(dirty) {
    if (!dirty) return "";
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].sanitize(dirty, {
        ALLOWED_TAGS: [
            "p",
            "br",
            "span",
            "em",
            "strong",
            "b",
            "i",
            "u",
            "a",
            "ul",
            "ol",
            "li",
            "h1",
            "h2",
            "h3",
            "h4",
            "h5",
            "h6",
            "blockquote",
            "code",
            "pre",
            "img",
            "figure",
            "figcaption",
            "table",
            "thead",
            "tbody",
            "tr",
            "th",
            "td",
            "ruby",
            "rt",
            "rp",
            "rb",
            "sup",
            "sub"
        ],
        FORBID_TAGS: [
            "script",
            "style",
            "iframe",
            "embed",
            "object",
            "applet",
            "form",
            "input",
            "select",
            "textarea",
            "button",
            "svg",
            "math"
        ],
        ALLOWED_ATTR: [
            "class",
            "href",
            "target",
            "rel",
            "src",
            "alt",
            "width",
            "height",
            "lang",
            "dir"
        ],
        ALLOW_DATA_ATTR: false
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/xpCalculation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * XP (Experience Points) calculation utilities for the gamification system.
 *
 * XP is derived from an append-only log of StudentXPLog entries.
 * Total XP is never stored as a mutable field — it is always calculated from the log.
 *
 * @module xpCalculation
 */ // ============================================================================
// Types
// ============================================================================
__turbopack_context__.s([
    "LEVEL_DEFAULTS",
    ()=>LEVEL_DEFAULTS,
    "XPReason",
    ()=>XPReason,
    "calculateLevel",
    ()=>calculateLevel,
    "calculateMultipliedXP",
    ()=>calculateMultipliedXP,
    "calculateTotalXP",
    ()=>calculateTotalXP,
    "generateLevelThresholds",
    ()=>generateLevelThresholds,
    "getLevelInfo",
    ()=>getLevelInfo,
    "getLevelInfoWithThresholds",
    ()=>getLevelInfoWithThresholds,
    "getLevelThresholds",
    ()=>getLevelThresholds,
    "getXPForAction",
    ()=>getXPForAction,
    "getXPForActionWithConfig",
    ()=>getXPForActionWithConfig
]);
var XPReason = /*#__PURE__*/ function(XPReason) {
    XPReason["HOMEWORK_SUBMITTED"] = "HOMEWORK_SUBMITTED";
    XPReason["AI_FEEDBACK_REVISED"] = "AI_FEEDBACK_REVISED";
    XPReason["ALL_BLOCKS_COMPLETED"] = "ALL_BLOCKS_COMPLETED";
    XPReason["PEER_REVIEW_GIVEN"] = "PEER_REVIEW_GIVEN";
    XPReason["PEER_REVIEW_HOSTED"] = "PEER_REVIEW_HOSTED";
    XPReason["PEER_REVIEW_TOP_REVIEWER"] = "PEER_REVIEW_TOP_REVIEWER";
    XPReason["NAILED_IT"] = "NAILED_IT";
    XPReason["ON_TIME_SUBMISSION"] = "ON_TIME_SUBMISSION";
    XPReason["STREAK_3DAY"] = "STREAK_3DAY";
    XPReason["STREAK_7DAY"] = "STREAK_7DAY";
    XPReason["STREAK_14DAY"] = "STREAK_14DAY";
    XPReason["STREAK_30DAY"] = "STREAK_30DAY";
    XPReason["PERFECT_SCORE"] = "PERFECT_SCORE";
    XPReason["COMEBACK"] = "COMEBACK";
    XPReason["PERSONAL_BEST"] = "PERSONAL_BEST";
    XPReason["EASTER_EGG"] = "EASTER_EGG";
    XPReason["SQUAD_CHALLENGE_BONUS"] = "SQUAD_CHALLENGE_BONUS";
    XPReason["PRACTICE_DRILL_COMPLETED"] = "PRACTICE_DRILL_COMPLETED";
    XPReason["PRACTICE_DRILL_ACCURACY_BONUS"] = "PRACTICE_DRILL_ACCURACY_BONUS";
    return XPReason;
}({});
const LEVEL_DEFAULTS = {
    maxLevel: 6,
    xpPerLevel: 150,
    levelScaling: 1.6
};
// ============================================================================
// Constants
// ============================================================================
const XP_AMOUNTS = {
    ["HOMEWORK_SUBMITTED"]: 50,
    ["AI_FEEDBACK_REVISED"]: 25,
    ["ALL_BLOCKS_COMPLETED"]: 75,
    ["PEER_REVIEW_GIVEN"]: 40,
    ["PEER_REVIEW_HOSTED"]: 30,
    ["PEER_REVIEW_TOP_REVIEWER"]: 50,
    ["NAILED_IT"]: 20,
    ["ON_TIME_SUBMISSION"]: 15,
    ["STREAK_3DAY"]: 30,
    ["STREAK_7DAY"]: 75,
    ["STREAK_14DAY"]: 150,
    ["STREAK_30DAY"]: 300,
    ["PERFECT_SCORE"]: 100,
    ["COMEBACK"]: 50,
    ["PERSONAL_BEST"]: 25,
    ["EASTER_EGG"]: 30,
    ["SQUAD_CHALLENGE_BONUS"]: 100,
    ["PRACTICE_DRILL_COMPLETED"]: 30,
    ["PRACTICE_DRILL_ACCURACY_BONUS"]: 15
};
const LEVEL_THRESHOLDS = [
    {
        level: 1,
        xpRequired: 0,
        label: "Beginner"
    },
    {
        level: 2,
        xpRequired: 150,
        label: "Explorer"
    },
    {
        level: 3,
        xpRequired: 400,
        label: "Practitioner"
    },
    {
        level: 4,
        xpRequired: 800,
        label: "Contributor"
    },
    {
        level: 5,
        xpRequired: 1500,
        label: "Expert"
    },
    {
        level: 6,
        xpRequired: 2500,
        label: "Master"
    }
];
/** Labels assigned by progress fraction through the level range */ const LEVEL_LABEL_TIERS = [
    {
        fraction: 0,
        label: "Beginner"
    },
    {
        fraction: 0.1,
        label: "Novice"
    },
    {
        fraction: 0.2,
        label: "Explorer"
    },
    {
        fraction: 0.35,
        label: "Practitioner"
    },
    {
        fraction: 0.5,
        label: "Journeyman"
    },
    {
        fraction: 0.65,
        label: "Contributor"
    },
    {
        fraction: 0.8,
        label: "Expert"
    },
    {
        fraction: 0.9,
        label: "Master"
    },
    {
        fraction: 1.0,
        label: "Legend"
    }
];
function generateLevelThresholds(config) {
    const max = Math.min(99, Math.max(1, config?.maxLevel ?? LEVEL_DEFAULTS.maxLevel));
    const base = Math.max(1, config?.xpPerLevel ?? LEVEL_DEFAULTS.xpPerLevel);
    const scaling = Math.max(1, config?.levelScaling ?? LEVEL_DEFAULTS.levelScaling);
    const thresholds = [];
    let cumulative = 0;
    for(let lvl = 1; lvl <= max; lvl++){
        const fraction = max <= 1 ? 0 : (lvl - 1) / (max - 1);
        // Find the highest label tier that this level qualifies for
        let label = "Beginner";
        for (const tier of LEVEL_LABEL_TIERS){
            if (fraction >= tier.fraction) label = tier.label;
        }
        thresholds.push({
            level: lvl,
            xpRequired: Math.round(cumulative),
            label
        });
        if (lvl < max) {
            // Gap from this level to next
            const gap = base * Math.pow(scaling, lvl - 1);
            cumulative += gap;
        }
    }
    return thresholds;
}
function calculateTotalXP(logs) {
    return logs.reduce((sum, log)=>sum + log.xpAmount, 0);
}
function getXPForAction(reason) {
    return XP_AMOUNTS[reason] ?? 0;
}
function getXPForActionWithConfig(reason, config) {
    if (config?.enabled === false) return 0;
    let amount = XP_AMOUNTS[reason] ?? 0;
    if (config?.multipliers?.[reason] !== undefined) {
        amount = Math.round(amount * config.multipliers[reason]);
    }
    return Math.max(0, amount);
}
function calculateLevel(totalXP, levelConfig) {
    const thresholds = levelConfig ? generateLevelThresholds(levelConfig) : LEVEL_THRESHOLDS;
    let level = 1;
    for (const threshold of thresholds){
        if (totalXP >= threshold.xpRequired) {
            level = threshold.level;
        } else {
            break;
        }
    }
    return level;
}
function getLevelInfo(totalXP, levelConfig) {
    const thresholds = levelConfig ? generateLevelThresholds(levelConfig) : LEVEL_THRESHOLDS;
    const level = calculateLevel(totalXP, levelConfig);
    const currentThreshold = thresholds.find((t)=>t.level === level);
    const nextThreshold = thresholds.find((t)=>t.level === level + 1);
    let progress = 100;
    if (nextThreshold) {
        const xpIntoLevel = totalXP - currentThreshold.xpRequired;
        const xpNeeded = nextThreshold.xpRequired - currentThreshold.xpRequired;
        progress = Math.min(100, Math.round(xpIntoLevel / xpNeeded * 100));
    }
    return {
        level,
        label: currentThreshold.label,
        xpRequired: currentThreshold.xpRequired,
        xpForNextLevel: nextThreshold?.xpRequired ?? null,
        progress
    };
}
function getLevelThresholds(levelConfig) {
    return levelConfig ? generateLevelThresholds(levelConfig) : [
        ...LEVEL_THRESHOLDS
    ];
}
function getLevelInfoWithThresholds(totalXP, dbThresholds) {
    if (!dbThresholds || dbThresholds.length === 0) {
        return getLevelInfo(totalXP);
    }
    const sorted = [
        ...dbThresholds
    ].sort((a, b)=>a.level - b.level);
    // Map DB format to internal format
    const thresholds = sorted.map((t)=>({
            level: t.level,
            xpRequired: t.xpRequired,
            label: t.title || `Level ${t.level}`
        }));
    let level = 1;
    for (const threshold of thresholds){
        if (totalXP >= threshold.xpRequired) {
            level = threshold.level;
        } else {
            break;
        }
    }
    const currentThreshold = thresholds.find((t)=>t.level === level) || thresholds[0];
    const nextThreshold = thresholds.find((t)=>t.level === level + 1);
    let progress = 100;
    if (nextThreshold) {
        const xpIntoLevel = totalXP - currentThreshold.xpRequired;
        const xpNeeded = nextThreshold.xpRequired - currentThreshold.xpRequired;
        progress = xpNeeded > 0 ? Math.min(100, Math.round(xpIntoLevel / xpNeeded * 100)) : 100;
    }
    return {
        level,
        label: currentThreshold.label,
        xpRequired: currentThreshold.xpRequired,
        xpForNextLevel: nextThreshold?.xpRequired ?? null,
        progress
    };
}
function calculateMultipliedXP(logs, multipliers) {
    if (!multipliers || Object.keys(multipliers).length === 0) {
        return calculateTotalXP(logs);
    }
    return logs.reduce((sum, log)=>{
        const mult = log.reason && multipliers[log.reason] !== undefined ? multipliers[log.reason] : 1;
        return sum + Math.round(log.xpAmount * mult);
    }, 0);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/chatSearchIndex.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildChatSearchIndex",
    ()=>buildChatSearchIndex,
    "createChatIndexCacheKey",
    ()=>createChatIndexCacheKey,
    "loadPersistedChatSearchIndex",
    ()=>loadPersistedChatSearchIndex,
    "persistChatSearchIndex",
    ()=>persistChatSearchIndex,
    "searchChatIndex",
    ()=>searchChatIndex
]);
/**
 * Lightweight client-side chat search index.
 *
 * Uses an inverted index + BM25-lite scoring for fast local retrieval.
 */ function normalizeText(text) {
    return (text || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").trim();
}
function tokenize(text) {
    return normalizeText(text).split(/\s+/).filter((token)=>token.length >= 2);
}
function messageText(message) {
    if (!message) return "";
    if (Array.isArray(message.parts)) {
        return message.parts.filter((part)=>part?.type === "text" && typeof part?.text === "string").map((part)=>part.text).join(" ").trim();
    }
    if (typeof message.content === "string") return message.content;
    return "";
}
const CHAT_SEARCH_DB_NAME = "chat-search-index";
const CHAT_SEARCH_STORE = "indices";
const CHAT_SEARCH_DB_VERSION = 1;
function openChatSearchDB() {
    return new Promise((resolve, reject)=>{
        const request = indexedDB.open(CHAT_SEARCH_DB_NAME, CHAT_SEARCH_DB_VERSION);
        request.onupgradeneeded = ()=>{
            request.result.createObjectStore(CHAT_SEARCH_STORE);
        };
        request.onsuccess = ()=>resolve(request.result);
        request.onerror = ()=>reject(request.error);
    });
}
function serializeIndex(index) {
    return {
        docs: Array.from(index.docs.entries()),
        postings: Array.from(index.postings.entries()),
        docFreq: Array.from(index.docFreq.entries()),
        avgDocLen: index.avgDocLen || 0
    };
}
function deserializeIndex(payload) {
    if (!payload) return null;
    return {
        docs: new Map(payload.docs || []),
        postings: new Map(payload.postings || []),
        docFreq: new Map(payload.docFreq || []),
        avgDocLen: payload.avgDocLen || 0
    };
}
function createChatIndexCacheKey(chatId, messages = []) {
    const safeChatId = chatId || "global";
    const len = messages.length;
    const last = len > 0 ? messages[len - 1] : null;
    const lastMarker = last?.id || last?.createdAt || last?.updatedAt || "none";
    return `${safeChatId}:${len}:${lastMarker}`;
}
async function persistChatSearchIndex(key, index) {
    if (typeof indexedDB === "undefined" || !key || !index) return;
    try {
        const db = await openChatSearchDB();
        const tx = db.transaction(CHAT_SEARCH_STORE, "readwrite");
        tx.objectStore(CHAT_SEARCH_STORE).put({
            savedAt: Date.now(),
            payload: serializeIndex(index)
        }, key);
    } catch  {
    // Non-fatal; cache persistence is best effort.
    }
}
async function loadPersistedChatSearchIndex(key) {
    if (typeof indexedDB === "undefined" || !key) return null;
    try {
        const db = await openChatSearchDB();
        return await new Promise((resolve)=>{
            const tx = db.transaction(CHAT_SEARCH_STORE, "readonly");
            const req = tx.objectStore(CHAT_SEARCH_STORE).get(key);
            req.onsuccess = ()=>{
                const value = req.result?.payload;
                resolve(deserializeIndex(value));
            };
            req.onerror = ()=>resolve(null);
        });
    } catch  {
        return null;
    }
}
function buildChatSearchIndex(messages = []) {
    const postings = new Map();
    const docFreq = new Map();
    const docs = new Map();
    let totalDocLen = 0;
    for (const msg of messages){
        const text = messageText(msg);
        if (!text) continue;
        const id = msg.id || `chat-msg-${Math.random().toString(36).slice(2)}`;
        const tokens = tokenize(text);
        if (tokens.length === 0) continue;
        totalDocLen += tokens.length;
        const tf = new Map();
        for (const token of tokens){
            tf.set(token, (tf.get(token) || 0) + 1);
        }
        const uniqueTokens = new Set(tokens);
        for (const token of uniqueTokens){
            docFreq.set(token, (docFreq.get(token) || 0) + 1);
            if (!postings.has(token)) postings.set(token, []);
            postings.get(token).push({
                id,
                tf: tf.get(token) || 0
            });
        }
        docs.set(id, {
            id,
            text,
            role: msg.role || "unknown",
            author: msg.author || msg.username || msg.userName || msg.name || msg.user || null,
            createdAt: msg.createdAt || msg.updatedAt || null,
            length: tokens.length,
            message: msg
        });
    }
    return {
        docs,
        postings,
        docFreq,
        avgDocLen: docs.size > 0 ? totalDocLen / docs.size : 0
    };
}
function searchChatIndex(index, query, options = {}) {
    const { limit = 20, role, author } = options;
    const queryTokens = tokenize(query);
    if (!index || queryTokens.length === 0) return [];
    const candidateIds = new Set();
    for (const token of queryTokens){
        const list = index.postings.get(token) || [];
        for (const posting of list)candidateIds.add(posting.id);
    }
    if (candidateIds.size === 0) return [];
    const k1 = 1.2;
    const b = 0.75;
    const N = Math.max(1, index.docs.size);
    const avgdl = Math.max(1, index.avgDocLen || 0);
    const q = normalizeText(query);
    const now = Date.now();
    const results = [];
    for (const id of candidateIds){
        const doc = index.docs.get(id);
        if (!doc) continue;
        if (role && doc.role !== role) continue;
        if (author && !normalizeText(String(doc.author || "")).includes(normalizeText(author))) {
            continue;
        }
        let score = 0;
        const textTokens = tokenize(doc.text);
        const tfMap = new Map();
        for (const token of textTokens){
            tfMap.set(token, (tfMap.get(token) || 0) + 1);
        }
        for (const token of queryTokens){
            const tf = tfMap.get(token) || 0;
            if (tf === 0) continue;
            const df = index.docFreq.get(token) || 0;
            const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));
            const denom = tf + k1 * (1 - b + b * doc.length / avgdl);
            score += idf * (tf * (k1 + 1) / denom);
        }
        const normalizedDocText = normalizeText(doc.text);
        if (q && normalizedDocText.includes(q)) {
            score += 0.2;
        }
        if (doc.createdAt) {
            const ageMs = Math.max(0, now - new Date(doc.createdAt).getTime());
            const ageDays = ageMs / (1000 * 60 * 60 * 24);
            const recencyBoost = Math.max(0, 0.15 - ageDays * 0.0025);
            score += recencyBoost;
        }
        if (score <= 0) continue;
        const text = doc.text;
        const firstToken = queryTokens[0];
        const idx = normalizeText(text).indexOf(firstToken);
        const snippet = idx >= 0 ? text.slice(Math.max(0, idx - 40), Math.min(text.length, idx + 120)).trim() : text.slice(0, 140).trim();
        results.push({
            id: doc.id,
            role: doc.role,
            author: doc.author,
            score,
            snippet,
            createdAt: doc.createdAt,
            message: doc.message
        });
    }
    results.sort((a, b)=>b.score - a.score);
    return results.slice(0, limit);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/chatSearchWorkerManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createChatSearchWorkerManager",
    ()=>createChatSearchWorkerManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/chatSearchIndex.js [app-client] (ecmascript)");
const __TURBOPACK__import$2e$meta__ = {
    get url () {
        return `file://${__turbopack_context__.P("src/utils/chatSearchWorkerManager.js")}`;
    },
    get turbopackHot () {
        return __turbopack_context__.m.hot;
    }
};
;
let reqId = 0;
function createChatSearchWorkerManager(indexRef) {
    const hasWorker = ("TURBOPACK compile-time value", "object") !== "undefined" && typeof Worker !== "undefined";
    let worker = null;
    const pending = new Map();
    function initWorker() {
        if (!hasWorker || worker) return;
        worker = __turbopack_context__.r("[project]/src/workers/chatSearchWorker.js [app-client] (ecmascript, worker loader)")(Worker);
        worker.onmessage = (event)=>{
            const { id, ok, payload, error } = event.data || {};
            const resolver = pending.get(id);
            if (!resolver) return;
            pending.delete(id);
            if (ok) resolver.resolve(payload);
            else resolver.reject(new Error(error || "Chat search worker error"));
        };
        worker.onerror = (err)=>{
            // Reject all in-flight requests and allow sync fallback
            for (const [, resolver] of pending){
                resolver.reject(err);
            }
            pending.clear();
            try {
                worker?.terminate();
            } catch  {
            // Ignore terminate failures
            }
            worker = null;
        };
    }
    function callWorker(action, payload) {
        initWorker();
        if (!worker) {
            return Promise.reject(new Error("Worker unavailable"));
        }
        const id = ++reqId;
        return new Promise((resolve, reject)=>{
            pending.set(id, {
                resolve,
                reject
            });
            worker.postMessage({
                id,
                action,
                payload
            });
        });
    }
    async function build(messages) {
        if (!Array.isArray(messages)) return;
        try {
            await callWorker("BUILD", {
                messages
            });
        } catch  {
        // Silent fallback: sync search remains available.
        }
    }
    async function search(query, options = {}) {
        try {
            const response = await callWorker("SEARCH", {
                query,
                options
            });
            return response?.results || [];
        } catch  {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchChatIndex"])(indexRef.current, query, options);
        }
    }
    function dispose() {
        if (!worker) return;
        try {
            worker.terminate();
        } catch  {
        // Ignore terminate failures
        }
        worker = null;
        pending.clear();
    }
    return {
        build,
        search,
        dispose
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/searchBundles.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadInstructorBundle",
    ()=>loadInstructorBundle,
    "loadPlatformBundle",
    ()=>loadPlatformBundle,
    "loadSharedBundles",
    ()=>loadSharedBundles,
    "loadUnitBundle",
    ()=>loadUnitBundle,
    "search",
    ()=>search
]);
/**
 * Client-side search bundle loader and IVF search utility.
 *
 * Loads pre-built search bundles from S3, caches in IndexedDB,
 * and performs ANN (approximate nearest neighbor) search using
 * the IVF index built by the rebuildSearchBundle Lambda.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/downloadData.mjs [app-client] (ecmascript)");
;
const DEFAULT_HYBRID_CONFIG = {
    semanticWeight: 0.65,
    lexicalWeight: 0.35,
    titleExactBoost: 0.2,
    phraseBoost: 0.1
};
// --- IndexedDB Cache ---
const DB_NAME = "search-bundles";
const STORE_NAME = "bundles";
const DB_VERSION = 1;
function openDB() {
    return new Promise((resolve, reject)=>{
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = ()=>{
            request.result.createObjectStore(STORE_NAME);
        };
        request.onsuccess = ()=>resolve(request.result);
        request.onerror = ()=>reject(request.error);
    });
}
async function getCached(key) {
    try {
        const db = await openDB();
        return new Promise((resolve)=>{
            const tx = db.transaction(STORE_NAME, "readonly");
            const store = tx.objectStore(STORE_NAME);
            const req = store.get(key);
            req.onsuccess = ()=>resolve(req.result || null);
            req.onerror = ()=>resolve(null);
        });
    } catch  {
        return null;
    }
}
async function setCache(key, bundle) {
    try {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME, "readwrite");
        tx.objectStore(STORE_NAME).put(bundle, key);
    } catch  {
    // Cache write failure is non-fatal
    }
}
async function loadUnitBundle(identityId, unitId) {
    const cacheKey = `unit:${unitId}`;
    const cached = await getCached(cacheKey);
    const path = `protected/${identityId}/search-index/unit/${unitId}.json`;
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"])({
            path
        }).result;
        const text = await result.body.text();
        const bundle = JSON.parse(text);
        // Only use cache if version matches
        if (cached && cached.version >= bundle.version) {
            return cached;
        }
        await setCache(cacheKey, bundle);
        return bundle;
    } catch  {
        // Fall back to cache if S3 unavailable
        return cached;
    }
}
async function loadInstructorBundle(identityId) {
    const cacheKey = `instructor:${identityId}`;
    const cached = await getCached(cacheKey);
    const path = `private/${identityId}/search-index/instructor.json`;
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"])({
            path
        }).result;
        const text = await result.body.text();
        const bundle = JSON.parse(text);
        if (cached && cached.version >= bundle.version) {
            return cached;
        }
        await setCache(cacheKey, bundle);
        return bundle;
    } catch  {
        return cached;
    }
}
async function loadPlatformBundle() {
    const cacheKey = "platform:admin";
    const cached = await getCached(cacheKey);
    const path = "private/unit/search-index/platform.json";
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"])({
            path
        }).result;
        const text = await result.body.text();
        const bundle = JSON.parse(text);
        if (cached && cached.version >= bundle.version) {
            return cached;
        }
        await setCache(cacheKey, bundle);
        return bundle;
    } catch  {
        return cached;
    }
}
async function loadSharedBundles(sharedUnits) {
    if (!sharedUnits || sharedUnits.length === 0) return null;
    const allItems = [];
    for (const unit of sharedUnits){
        if (!unit.identityId || !unit.id) continue;
        try {
            const bundle = await loadUnitBundle(unit.identityId, unit.id);
            if (bundle?.items) {
                allItems.push(...bundle.items);
            }
        } catch  {
        // Skip units whose bundles don't exist
        }
    }
    if (allItems.length === 0) return null;
    // Build a merged linear bundle for shared content
    return {
        version: Date.now(),
        dimensions: allItems[0]?.embedding?.length || 384,
        model: "Xenova/all-MiniLM-L6-v2",
        index: {
            strategy: "linear"
        },
        items: allItems
    };
}
// --- Search ---
function dotProduct(a, b) {
    let sum = 0;
    for(let i = 0; i < a.length; i++){
        sum += a[i] * b[i];
    }
    return sum;
}
function l2Normalize(v) {
    let norm = 0;
    for(let i = 0; i < v.length; i++)norm += v[i] * v[i];
    norm = Math.sqrt(norm);
    if (norm === 0) return v;
    return v.map((x)=>x / norm);
}
function tokenize(text) {
    if (!text) return [];
    return text.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((t)=>t.length >= 2);
}
function getSearchText(item) {
    return `${item.title || ""} ${item.meta?.preview || ""}`.trim();
}
function buildTokenStats(items, queryTokens) {
    const df = new Map();
    const uniqueQueryTokens = Array.from(new Set(queryTokens));
    let totalLen = 0;
    for (const item of items){
        const docTokens = tokenize(getSearchText(item));
        totalLen += docTokens.length;
        if (uniqueQueryTokens.length === 0) continue;
        const tokenSet = new Set(docTokens);
        for (const token of uniqueQueryTokens){
            if (tokenSet.has(token)) {
                df.set(token, (df.get(token) || 0) + 1);
            }
        }
    }
    return {
        df,
        avgDocLen: items.length > 0 ? totalLen / items.length : 0
    };
}
function lexicalScore(item, queryText, queryTokens, df, corpusSize, avgDocLen, config) {
    if (queryTokens.length === 0 || corpusSize === 0) return 0;
    const title = (item.title || "").toLowerCase();
    const docText = getSearchText(item).toLowerCase();
    const docTokens = tokenize(docText);
    const tf = new Map();
    for (const token of docTokens){
        tf.set(token, (tf.get(token) || 0) + 1);
    }
    const k1 = 1.2;
    const b = 0.75;
    const docLen = Math.max(1, docTokens.length);
    const avgLen = Math.max(1, avgDocLen);
    let score = 0;
    for (const token of queryTokens){
        const termFreq = tf.get(token) || 0;
        if (termFreq === 0) continue;
        const docFreq = df.get(token) || 0;
        const idf = Math.log(1 + (corpusSize - docFreq + 0.5) / (docFreq + 0.5));
        const denom = termFreq + k1 * (1 - b + b * docLen / avgLen);
        score += idf * (termFreq * (k1 + 1) / denom);
    }
    const normalizedQuery = queryText.trim().toLowerCase();
    if (normalizedQuery && title.includes(normalizedQuery)) {
        score += config.titleExactBoost;
    }
    if (normalizedQuery && docText.includes(normalizedQuery)) {
        score += config.phraseBoost;
    }
    return score;
}
function combineScores(semantic, lexical, maxLexical, config) {
    const normalizedLexical = maxLexical > 0 ? lexical / maxLexical : 0;
    return config.semanticWeight * Math.max(0, semantic) + config.lexicalWeight * normalizedLexical;
}
function hybridRank(query, candidates, topK, semanticThreshold, queryText) {
    const config = DEFAULT_HYBRID_CONFIG;
    const queryTokens = tokenize(queryText);
    const { df, avgDocLen } = buildTokenStats(candidates, queryTokens);
    const scored = candidates.map((item)=>{
        const semantic = dotProduct(query, item.embedding);
        const lexical = lexicalScore(item, queryText, queryTokens, df, candidates.length, avgDocLen, config);
        return {
            item,
            semantic,
            lexical
        };
    });
    const maxLexical = scored.reduce((max, s)=>s.lexical > max ? s.lexical : max, 0);
    const results = scored.filter((s)=>s.semantic >= semanticThreshold || s.lexical > 0).map((s)=>({
            item: s.item,
            score: combineScores(s.semantic, s.lexical, maxLexical, config)
        })).sort((a, b)=>b.score - a.score).slice(0, topK);
    return results;
}
function linearSearch(query, bundle, topK, threshold, queryText) {
    return hybridRank(query, bundle.items, topK, threshold, queryText);
}
function ivfSearch(query, bundle, topK, threshold, queryText) {
    const index = bundle.index;
    // Find top nProbe clusters by centroid similarity
    const centroidScores = index.centroids.map((centroid, i)=>({
            cluster: i,
            score: dotProduct(query, centroid)
        }));
    centroidScores.sort((a, b)=>b.score - a.score);
    const probeClusters = new Set(centroidScores.slice(0, index.nProbe).map((c)=>c.cluster));
    // Search only items in selected clusters
    const candidates = [];
    for(let i = 0; i < bundle.items.length; i++){
        if (!probeClusters.has(index.assignments[i])) continue;
        candidates.push(bundle.items[i]);
    }
    return hybridRank(query, candidates, topK, threshold, queryText);
}
function search(query, bundle, topK = 10, threshold = 0.3, queryText = "") {
    const normalizedQuery = l2Normalize(query);
    if (!bundle.index || bundle.index.strategy === "linear") {
        return linearSearch(normalizedQuery, bundle, topK, threshold, queryText);
    }
    return ivfSearch(normalizedQuery, bundle, topK, threshold, queryText);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/embeddingWorkerManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateSimilarities",
    ()=>calculateSimilarities,
    "cosineSimilarity",
    ()=>cosineSimilarity,
    "initWorker",
    ()=>initWorker,
    "keywordSearch",
    ()=>keywordSearch,
    "sortAndLimit",
    ()=>sortAndLimit,
    "terminateWorker",
    ()=>terminateWorker
]);
const __TURBOPACK__import$2e$meta__ = {
    get url () {
        return `file://${__turbopack_context__.P("src/utils/embeddingWorkerManager.js")}`;
    },
    get turbopackHot () {
        return __turbopack_context__.m.hot;
    }
};
/**
 * Embedding Worker Manager
 * Manages web worker for embedding calculations
 */ let worker = null;
let messageId = 0;
let pendingMessages = new Map();
let isReady = false;
let readyCallbacks = [];
function initWorker() {
    if (worker) return worker;
    try {
        worker = __turbopack_context__.r("[project]/src/workers/embeddingWorker.js [app-client] (ecmascript, worker loader)")(Worker);
        worker.onmessage = (e)=>{
            const { id, type, success, result, error } = e.data;
            // Handle ready message
            if (type === 'ready') {
                isReady = true;
                readyCallbacks.forEach((cb)=>cb());
                readyCallbacks = [];
                return;
            }
            // Handle response messages
            const pending = pendingMessages.get(id);
            if (pending) {
                pendingMessages.delete(id);
                if (success) {
                    pending.resolve(result);
                } else {
                    pending.reject(new Error(error));
                }
            }
        };
        worker.onerror = (error)=>{
            console.error('[EmbeddingWorker] Error:', error);
            // Reject all pending messages
            pendingMessages.forEach(({ reject })=>{
                reject(new Error('Worker error'));
            });
            pendingMessages.clear();
        };
        return worker;
    } catch (error) {
        console.error('[EmbeddingWorker] Failed to initialize:', error);
        return null;
    }
}
/**
 * Wait for worker to be ready
 */ function waitForReady() {
    return new Promise((resolve)=>{
        if (isReady) {
            resolve();
        } else {
            readyCallbacks.push(resolve);
        }
    });
}
/**
 * Send message to worker and await response
 */ function sendMessage(type, data) {
    if (!worker) {
        initWorker();
    }
    return new Promise(async (resolve, reject)=>{
        await waitForReady();
        const id = messageId++;
        pendingMessages.set(id, {
            resolve,
            reject
        });
        // Timeout after 30 seconds
        setTimeout(()=>{
            if (pendingMessages.has(id)) {
                pendingMessages.delete(id);
                reject(new Error('Worker timeout'));
            }
        }, 30000);
        worker.postMessage({
            id,
            type,
            data
        });
    });
}
function cosineSimilarity(vecA, vecB) {
    return sendMessage('cosineSimilarity', {
        vecA,
        vecB
    });
}
function calculateSimilarities(queryEmbedding, items, type) {
    return sendMessage('calculateSimilarities', {
        queryEmbedding,
        items,
        type
    });
}
function keywordSearch(query, items, type) {
    return sendMessage('keywordSearch', {
        query,
        items,
        type
    });
}
function sortAndLimit(results, limit) {
    return sendMessage('sortAndLimit', {
        results,
        limit
    });
}
function terminateWorker() {
    if (worker) {
        worker.terminate();
        worker = null;
        isReady = false;
        messageId = 0;
        pendingMessages.clear();
        readyCallbacks = [];
    }
}
// Auto-initialize on import
if ("TURBOPACK compile-time truthy", 1) {
    initWorker();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/chatTools.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "executeAddTimerToUnit",
    ()=>executeAddTimerToUnit,
    "executeCopyGamificationSettings",
    ()=>executeCopyGamificationSettings,
    "executeCreateAssignment",
    ()=>executeCreateAssignment,
    "executeCreateQuestion",
    ()=>executeCreateQuestion,
    "executeCreateSection",
    ()=>executeCreateSection,
    "executeCreateUnit",
    ()=>executeCreateUnit,
    "executeCreateVocabularyWord",
    ()=>executeCreateVocabularyWord,
    "executeDeleteAssignment",
    ()=>executeDeleteAssignment,
    "executeGetEditorButtons",
    ()=>executeGetEditorButtons,
    "executeGetTourInfo",
    ()=>executeGetTourInfo,
    "executeGetUnitDetails",
    ()=>executeGetUnitDetails,
    "executeInsertAnswerBlock",
    ()=>executeInsertAnswerBlock,
    "executeInsertCustomAnswer",
    ()=>executeInsertCustomAnswer,
    "executeInsertMeaningAssociation",
    ()=>executeInsertMeaningAssociation,
    "executeInsertQuiz",
    ()=>executeInsertQuiz,
    "executeListSections",
    ()=>executeListSections,
    "executeListTours",
    ()=>executeListTours,
    "executeListUnits",
    ()=>executeListUnits,
    "executeNavigateToEditorTab",
    ()=>executeNavigateToEditorTab,
    "executePublishUnit",
    ()=>executePublishUnit,
    "executeSearchContent",
    ()=>executeSearchContent,
    "executeStartTour",
    ()=>executeStartTour,
    "executeStopTour",
    ()=>executeStopTour,
    "executeTool",
    ()=>executeTool,
    "executeUpdateUnit",
    ()=>executeUpdateUnit,
    "setPracticeDrillCallback",
    ()=>setPracticeDrillCallback,
    "setTourTasksData",
    ()=>setTourTasksData,
    "setVectorStoreSearch",
    ()=>setVectorStoreSearch,
    "toolDefinitions",
    ()=>toolDefinitions
]);
/**
 * Chat Tool Definitions and Execution
 * Defines available tools for the AI chatbot to call
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$f001e6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:f001e6 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$0bcb75__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:0bcb75 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$b5e562__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:b5e562 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$37d4c4__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:37d4c4 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$embeddingWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/embeddingWorkerManager.js [app-client] (ecmascript)");
;
;
;
;
// Vector store instance - will be set from context
let vectorStoreSearchFunction = null;
function setVectorStoreSearch(searchFn) {
    vectorStoreSearchFunction = searchFn;
    console.log('[chatTools] Vector store search function registered:', !!searchFn);
}
const toolDefinitions = [
    {
        type: 'function',
        function: {
            name: 'list_tours',
            description: 'List available guided tours to help users learn the platform. Tours cover instructor workflows, learner workflows, and developer documentation. Each tour has tutorial mode (step-by-step guidance) and quiz mode (test knowledge).',
            parameters: {
                type: 'object',
                properties: {
                    persona: {
                        type: 'string',
                        enum: [
                            'instructor',
                            'learner',
                            'developer'
                        ],
                        description: 'Filter tours by user role'
                    },
                    category: {
                        type: 'string',
                        description: 'Filter tours by category (e.g., "Getting Started", "Content Creation")'
                    }
                },
                required: []
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'start_tour',
            description: 'Start a guided interactive tour that highlights UI elements and walks users through tasks. The tour will open automatically and guide users step-by-step.',
            parameters: {
                type: 'object',
                properties: {
                    tourId: {
                        type: 'string',
                        description: 'ID of the tour to start (from list_tours)'
                    },
                    mode: {
                        type: 'string',
                        enum: [
                            'tutorial',
                            'quiz'
                        ],
                        description: 'Tutorial mode provides detailed guidance, quiz mode tests knowledge with minimal hints',
                        default: 'tutorial'
                    }
                },
                required: [
                    'tourId'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'get_tour_info',
            description: 'Get detailed information about a specific tour including steps, estimated time, and instructions.',
            parameters: {
                type: 'object',
                properties: {
                    tourId: {
                        type: 'string',
                        description: 'ID of the tour'
                    }
                },
                required: [
                    'tourId'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'stop_tour',
            description: 'Stop and close the currently active guided tour.',
            parameters: {
                type: 'object',
                properties: {},
                required: []
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'search_content',
            description: 'Search through files, vocabulary words, questions, and units using semantic similarity. Returns the most relevant results based on the query.',
            parameters: {
                type: 'object',
                properties: {
                    query: {
                        type: 'string',
                        description: 'The search query text'
                    },
                    type: {
                        type: 'string',
                        enum: [
                            'all',
                            'files',
                            'words',
                            'questions',
                            'units',
                            'sections'
                        ],
                        description: 'Type of content to search. "all" searches everything.'
                    },
                    limit: {
                        type: 'number',
                        description: 'Maximum number of results to return',
                        default: 10
                    }
                },
                required: [
                    'query'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'create_section',
            description: 'Create a new class section (group of students). This automatically creates Cognito groups and generates a join code for students.',
            parameters: {
                type: 'object',
                properties: {
                    name: {
                        type: 'string',
                        description: 'Name of the section'
                    },
                    description: {
                        type: 'string',
                        description: 'Description of the section'
                    }
                },
                required: [
                    'name'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'create_unit',
            description: 'Create a new learning unit',
            parameters: {
                type: 'object',
                properties: {
                    name: {
                        type: 'string',
                        description: 'Name of the unit'
                    },
                    description: {
                        type: 'string',
                        description: 'Description of the unit'
                    },
                    timeLimitSeconds: {
                        type: 'number',
                        description: 'Optional time limit in seconds for completing the unit'
                    }
                },
                required: [
                    'name'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'create_assignment',
            description: 'Assign a unit to a section with a due date',
            parameters: {
                type: 'object',
                properties: {
                    unitId: {
                        type: 'string',
                        description: 'ID of the unit to assign'
                    },
                    sectionId: {
                        type: 'string',
                        description: 'ID of the section to assign to'
                    },
                    dueDate: {
                        type: 'string',
                        description: 'Due date in ISO 8601 format (e.g., "2024-12-31T23:59:59Z")'
                    },
                    learner: {
                        type: 'string',
                        description: 'Learner identifier for the section'
                    }
                },
                required: [
                    'unitId',
                    'sectionId',
                    'dueDate'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'add_timer_to_unit',
            description: 'Add or update a timer (time limit) for a unit',
            parameters: {
                type: 'object',
                properties: {
                    unitId: {
                        type: 'string',
                        description: 'ID of the unit'
                    },
                    seconds: {
                        type: 'number',
                        description: 'Time limit in seconds'
                    }
                },
                required: [
                    'unitId',
                    'seconds'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'create_vocabulary_word',
            description: 'Create a new vocabulary word in the dictionary',
            parameters: {
                type: 'object',
                properties: {
                    phrase: {
                        type: 'string',
                        description: 'The word or phrase'
                    },
                    phonetic: {
                        type: 'string',
                        description: 'Phonetic spelling or pronunciation'
                    },
                    definition: {
                        type: 'string',
                        description: 'Definition of the word'
                    },
                    unitId: {
                        type: 'string',
                        description: 'Optional unit ID to associate with'
                    }
                },
                required: [
                    'phrase',
                    'definition'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'create_question',
            description: 'Create a new practice question',
            parameters: {
                type: 'object',
                properties: {
                    prompt: {
                        type: 'string',
                        description: 'The question prompt'
                    },
                    answer: {
                        type: 'string',
                        description: 'The correct answer'
                    },
                    unitId: {
                        type: 'string',
                        description: 'Optional unit ID to associate with'
                    }
                },
                required: [
                    'prompt',
                    'answer'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'list_sections',
            description: 'List all class sections',
            parameters: {
                type: 'object',
                properties: {},
                required: []
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'list_units',
            description: 'List all learning units',
            parameters: {
                type: 'object',
                properties: {
                    limit: {
                        type: 'number',
                        description: 'Maximum number of units to return'
                    }
                },
                required: []
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'get_unit_details',
            description: 'Get detailed information about a specific unit',
            parameters: {
                type: 'object',
                properties: {
                    unitId: {
                        type: 'string',
                        description: 'ID of the unit'
                    }
                },
                required: [
                    'unitId'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'update_unit',
            description: 'Update properties of an existing unit',
            parameters: {
                type: 'object',
                properties: {
                    unitId: {
                        type: 'string',
                        description: 'ID of the unit to update'
                    },
                    name: {
                        type: 'string',
                        description: 'New name for the unit'
                    },
                    description: {
                        type: 'string',
                        description: 'New description for the unit'
                    },
                    timeLimitSeconds: {
                        type: 'number',
                        description: 'New time limit in seconds'
                    }
                },
                required: [
                    'unitId'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'delete_assignment',
            description: 'Delete an assignment (unassign a unit from a section)',
            parameters: {
                type: 'object',
                properties: {
                    assignmentId: {
                        type: 'string',
                        description: 'ID of the assignment to delete'
                    }
                },
                required: [
                    'assignmentId'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'insert_quiz',
            description: 'Insert a quiz block into the current unit. Quizzes are interactive graded assessment blocks with multiple questions.',
            parameters: {
                type: 'object',
                properties: {
                    questions: {
                        type: 'array',
                        description: 'Array of quiz questions',
                        items: {
                            type: 'object',
                            properties: {
                                prompt: {
                                    type: 'string',
                                    description: 'The question text'
                                },
                                type: {
                                    type: 'string',
                                    enum: [
                                        'multiple-choice',
                                        'short-answer',
                                        'true-false'
                                    ],
                                    description: 'Type of question'
                                },
                                options: {
                                    type: 'array',
                                    items: {
                                        type: 'string'
                                    },
                                    description: 'Answer options (for multiple-choice)'
                                },
                                correctAnswer: {
                                    type: 'string',
                                    description: 'The correct answer'
                                },
                                points: {
                                    type: 'number',
                                    description: 'Points for this question',
                                    default: 1
                                }
                            },
                            required: [
                                'prompt',
                                'type',
                                'correctAnswer'
                            ]
                        }
                    },
                    title: {
                        type: 'string',
                        description: 'Title for the quiz'
                    }
                },
                required: [
                    'questions'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'insert_answer_block',
            description: 'Insert an answer block where students provide translations or definitions of vocabulary words.',
            parameters: {
                type: 'object',
                properties: {
                    wordIds: {
                        type: 'array',
                        items: {
                            type: 'string'
                        },
                        description: 'IDs of vocabulary words to test'
                    },
                    requestDefinition: {
                        type: 'boolean',
                        description: 'Whether to request the definition (true) or the phrase (false)',
                        default: false
                    },
                    allowedInput: {
                        type: 'object',
                        description: 'Allowed input methods (keyboard, speech, handwriting)',
                        properties: {
                            keyboard: {
                                type: 'boolean',
                                default: true
                            },
                            speech: {
                                type: 'boolean',
                                default: false
                            },
                            handwriting: {
                                type: 'boolean',
                                default: false
                            }
                        }
                    }
                },
                required: [
                    'wordIds'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'insert_meaning_association',
            description: 'Insert a meaning association block - a drag-and-drop matching exercise connecting terms with definitions.',
            parameters: {
                type: 'object',
                properties: {
                    wordIds: {
                        type: 'array',
                        items: {
                            type: 'string'
                        },
                        description: 'IDs of vocabulary words to match'
                    },
                    instructions: {
                        type: 'string',
                        description: 'Instructions for the exercise',
                        default: 'Match each term with its definition'
                    }
                },
                required: [
                    'wordIds'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'insert_custom_answer',
            description: 'Insert a custom answer block with flexible prompt and validation.',
            parameters: {
                type: 'object',
                properties: {
                    prompt: {
                        type: 'string',
                        description: 'The prompt or question to display'
                    },
                    acceptedAnswers: {
                        type: 'array',
                        items: {
                            type: 'string'
                        },
                        description: 'Array of accepted correct answers'
                    },
                    caseSensitive: {
                        type: 'boolean',
                        description: 'Whether answer matching is case-sensitive',
                        default: false
                    },
                    allowMultipleAttempts: {
                        type: 'boolean',
                        description: 'Allow students multiple attempts',
                        default: true
                    }
                },
                required: [
                    'prompt',
                    'acceptedAnswers'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'publish_unit',
            description: 'Publish a unit to make it available to students. This generates embeddings and changes the unit status to PUBLISHED.',
            parameters: {
                type: 'object',
                properties: {
                    unitId: {
                        type: 'string',
                        description: 'ID of the unit to publish'
                    },
                    generateEmbeddings: {
                        type: 'boolean',
                        description: 'Whether to generate embeddings for semantic search (recommended)',
                        default: true
                    }
                },
                required: [
                    'unitId'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'navigate_to_editor_tab',
            description: 'Open a specific tab in the editor left sidebar (dictionary, questions, files, etc.). Helps users discover and access editor features.',
            parameters: {
                type: 'object',
                properties: {
                    tab: {
                        type: 'string',
                        enum: [
                            'assignments',
                            'toc',
                            'dictionary',
                            'questions',
                            'files',
                            'configuration'
                        ],
                        description: 'Which tab to open: assignments (assignment settings), toc (table of contents), dictionary (vocabulary), questions (question bank), files (media files), configuration (unit settings)'
                    }
                },
                required: [
                    'tab'
                ]
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'get_editor_buttons',
            description: 'List all available editor controls, buttons, and features to help users discover what they can do.',
            parameters: {
                type: 'object',
                properties: {},
                required: []
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'start_practice_drill',
            description: 'Start an AI practice drill for the current unit. Generates varied practice questions from unit vocabulary, questions, documents, and text content. Students practice in a read-only workbook popup.',
            parameters: {
                type: 'object',
                properties: {
                    drillType: {
                        type: 'string',
                        enum: [
                            'mixed',
                            'vocabulary',
                            'comprehension',
                            'review'
                        ],
                        description: 'Type of practice drill. mixed = balanced across all block types, vocabulary = focus on word definitions/matching, comprehension = document-derived questions, review = prioritizes previously incorrect answers',
                        default: 'mixed'
                    },
                    count: {
                        type: 'number',
                        description: 'Number of practice questions to generate (5-20)',
                        default: 10
                    },
                    sources: {
                        type: 'object',
                        description: 'Which content sources to include in the drill',
                        properties: {
                            vocabulary: {
                                type: 'boolean',
                                description: 'Include vocabulary words',
                                default: true
                            },
                            questions: {
                                type: 'boolean',
                                description: 'Include question bank',
                                default: true
                            },
                            text: {
                                type: 'boolean',
                                description: 'Include lesson text content',
                                default: true
                            },
                            documents: {
                                type: 'boolean',
                                description: 'Include uploaded documents',
                                default: true
                            }
                        }
                    }
                },
                required: []
            }
        }
    }
];
/**
 * Tool Execution Functions
 */ /**
 * Normalized keyword score using TF-IDF-inspired matching.
 * Returns a score between 0 and 0.75 (below vector match scores).
 */ function keywordScore(query, text) {
    const terms = query.toLowerCase().split(/\s+/).filter((t)=>t.length > 2);
    if (terms.length === 0) return text.toLowerCase().includes(query.toLowerCase()) ? 0.5 : 0;
    const matched = terms.filter((term)=>text.toLowerCase().includes(term));
    return matched.length / terms.length * 0.75;
}
/**
 * Paginate through all records for a model to avoid the 100-record silent limit.
 */ async function listAll(client, modelName) {
    const items = [];
    let nextToken = undefined;
    do {
        const response = await client.models[modelName].list({
            nextToken
        });
        items.push(...response.data || []);
        nextToken = response.nextToken;
    }while (nextToken)
    return items;
}
async function executeSearchContent({ query, type = 'all', limit = 10 }) {
    try {
        console.log(`[executeSearchContent] Starting search: query="${query}", type="${type}", limit=${limit}`);
        // If vector store search is available, use it for files/documents
        if (vectorStoreSearchFunction && (type === 'all' || type === 'files')) {
            console.log('[executeSearchContent] Using vector store for semantic search');
            const vectorResults = await vectorStoreSearchFunction(query, {
                topK: limit,
                includeText: true
            });
            if (vectorResults.success && vectorResults.results.length > 0) {
                console.log(`[executeSearchContent] Vector store returned ${vectorResults.results.length} results`);
                // Map vector store results to search format
                const mappedResults = vectorResults.results.map((r)=>({
                        type: 'file',
                        id: r.fileId || r.documentId,
                        name: r.fileName || `Page ${r.page}`,
                        description: r.text ? r.text.substring(0, 200) + '...' : '',
                        similarity: r.similarity,
                        page: r.page,
                        documentId: r.documentId,
                        metadata: r.metadata
                    }));
                // If only searching files, return vector results
                if (type === 'files') {
                    return {
                        success: true,
                        query,
                        method: 'vector_store',
                        results: mappedResults
                    };
                }
                // For 'all', combine with word/question search
                const results = [
                    ...mappedResults
                ];
                // Add word search
                const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const { data: words } = await client.models.Word.list();
                console.log(`[executeSearchContent] Found ${words.length} total words`);
                let keywordMatches = 0;
                words.forEach((word)=>{
                    const text = `${word.phrase} ${word.pronunciation || ''} ${word.definition}`.toLowerCase();
                    const score = keywordScore(query, text);
                    if (score > 0) {
                        keywordMatches++;
                        results.push({
                            type: 'word',
                            id: word.id,
                            phrase: word.phrase,
                            pronunciation: word.pronunciation,
                            definition: word.definition,
                            similarity: score
                        });
                    }
                });
                console.log(`[executeSearchContent] Words keyword matches: ${keywordMatches}`);
                // Add question search
                const { data: questions } = await client.models.Question.list();
                console.log(`[executeSearchContent] Found ${questions.length} total questions`);
                keywordMatches = 0;
                questions.forEach((question)=>{
                    const text = `${question.prompt} ${question.answer || ''}`.toLowerCase();
                    const score = keywordScore(query, text);
                    if (score > 0) {
                        keywordMatches++;
                        results.push({
                            type: 'question',
                            id: question.id,
                            prompt: question.prompt,
                            answer: question.answer,
                            similarity: score
                        });
                    }
                });
                console.log(`[executeSearchContent] Questions keyword matches: ${keywordMatches}`);
                // Sort by similarity and limit
                const topResults = results.sort((a, b)=>b.similarity - a.similarity).slice(0, limit);
                console.log(`[executeSearchContent] Returning ${topResults.length} combined results`);
                return {
                    success: true,
                    query,
                    method: 'vector_store_hybrid',
                    results: topResults
                };
            }
        }
        // Fallback to original DataStore embedding search
        console.log('[executeSearchContent] Using DataStore embedding search (fallback)');
        // Generate embedding for the query
        console.log('[executeSearchContent] Calling generateEmbedding...');
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$f001e6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateEmbedding"])({
            content: query
        });
        const queryEmbedding = result.embedding;
        console.log(`[executeSearchContent] Query embedding generated: ${queryEmbedding.length} dimensions`);
        const results = [];
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        // Search Files
        if (type === 'all' || type === 'files') {
            console.log('[executeSearchContent] Searching files...');
            const files = await listAll(client, 'File');
            console.log(`[executeSearchContent] Found ${files.length} total files`);
            const filesWithEmbeddings = files.filter((f)=>f.embedding);
            console.log(`[executeSearchContent] Files with embeddings: ${filesWithEmbeddings.length}/${files.length}`);
            if (filesWithEmbeddings.length > 0) {
                const fileResults = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$embeddingWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateSimilarities"](queryEmbedding, filesWithEmbeddings, 'file');
                results.push(...fileResults);
                console.log(`[executeSearchContent] Calculated ${fileResults.length} file similarities`);
            }
        }
        // Search Words
        if (type === 'all' || type === 'words') {
            console.log('[executeSearchContent] Searching words...');
            const words = await listAll(client, 'Word');
            console.log(`[executeSearchContent] Found ${words.length} total words`);
            const wordsWithEmbeddings = words.filter((w)=>w.embedding);
            const wordsWithoutEmbeddings = words.filter((w)=>!w.embedding);
            // Calculate similarities for words with embeddings
            if (wordsWithEmbeddings.length > 0) {
                const wordResults = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$embeddingWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateSimilarities"](queryEmbedding, wordsWithEmbeddings, 'word');
                results.push(...wordResults);
            }
            // Keyword search for words without embeddings
            if (wordsWithoutEmbeddings.length > 0) {
                const keywordResults = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$embeddingWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["keywordSearch"](query, wordsWithoutEmbeddings, 'word');
                results.push(...keywordResults);
            }
            console.log(`[executeSearchContent] Words with embeddings: ${wordsWithEmbeddings.length}/${words.length}, keyword matches: ${results.filter((r)=>r.type === 'word' && r.similarity === 0.7).length}`);
        }
        // Search Questions
        if (type === 'all' || type === 'questions') {
            console.log('[executeSearchContent] Searching questions...');
            const questions = await listAll(client, 'Question');
            console.log(`[executeSearchContent] Found ${questions.length} total questions`);
            const questionsWithEmbeddings = questions.filter((q)=>q.embedding);
            const questionsWithoutEmbeddings = questions.filter((q)=>!q.embedding);
            // Calculate similarities for questions with embeddings
            if (questionsWithEmbeddings.length > 0) {
                const questionResults = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$embeddingWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateSimilarities"](queryEmbedding, questionsWithEmbeddings, 'question');
                results.push(...questionResults);
            }
            // Keyword search for questions without embeddings
            if (questionsWithoutEmbeddings.length > 0) {
                const keywordResults = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$embeddingWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["keywordSearch"](query, questionsWithoutEmbeddings, 'question');
                results.push(...keywordResults);
            }
            console.log(`[executeSearchContent] Questions with embeddings: ${questionsWithEmbeddings.length}/${questions.length}, keyword matches: ${results.filter((r)=>r.type === 'question' && r.similarity === 0.7).length}`);
        }
        // Search Units
        if (type === 'all' || type === 'units') {
            console.log('[executeSearchContent] Searching units...');
            const units = await listAll(client, 'Unit');
            console.log(`[executeSearchContent] Found ${units.length} total units`);
            units.forEach((unit)=>{
                const text = `${unit.name || ''} ${unit.description || ''}`.toLowerCase();
                const score = keywordScore(query, text);
                if (score > 0) {
                    results.push({
                        type: 'unit',
                        id: unit.id,
                        name: unit.name,
                        description: unit.description,
                        similarity: score
                    });
                }
            });
            console.log(`[executeSearchContent] Unit keyword matches: ${results.filter((r)=>r.type === 'unit').length}`);
        }
        // Sort by similarity and limit (using worker for large result sets)
        const topResults = results.length > 100 ? await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$embeddingWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortAndLimit"](results, limit) : results.sort((a, b)=>b.similarity - a.similarity).slice(0, limit);
        console.log(`[executeSearchContent] Returning ${topResults.length} results (from ${results.length} total matches)`);
        topResults.slice(0, 3).forEach((r, i)=>{
            console.log(`  ${i + 1}. ${r.type} - similarity: ${r.similarity.toFixed(4)}`);
        });
        return {
            success: true,
            query,
            results: topResults.map((r)=>({
                    type: r.type,
                    id: r.id,
                    similarity: r.similarity,
                    ...r.type === 'file' && {
                        name: r.name,
                        description: r.description,
                        mimeType: r.mimeType
                    },
                    ...r.type === 'word' && {
                        phrase: r.phrase,
                        phonetic: r.phonetic,
                        definition: r.definition
                    },
                    ...r.type === 'question' && {
                        prompt: r.prompt,
                        answer: r.answer
                    }
                }))
        };
    } catch (error) {
        console.error('[executeSearchContent] Error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeCreateSection({ name, description, copySettingsFromSectionId }) {
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$b5e562__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["createSection"])(name, description || '', copySettingsFromSectionId);
        if (!result.success) {
            throw new Error(result.error || 'Section creation failed');
        }
        return {
            success: true,
            section: {
                id: result.sectionId,
                name,
                code: result.code,
                message: copySettingsFromSectionId ? `Section "${name}" created with gamification settings copied from another section` : `Section "${name}" created successfully`
            }
        };
    } catch (error) {
        console.error('[executeCreateSection] Error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeCopyGamificationSettings({ sourceSectionId, targetSectionId }) {
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$37d4c4__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["copyGamificationSettings"])(sourceSectionId, targetSectionId);
        if (!result.success) {
            throw new Error(result.error || 'Failed to copy settings');
        }
        return {
            success: true,
            message: `Gamification settings copied from section ${sourceSectionId} to ${targetSectionId}`
        };
    } catch (error) {
        console.error('[executeCopyGamificationSettings] Error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeCreateUnit({ name, description, timeLimitSeconds }) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: newUnit } = await client.models.Unit.create({
            name,
            description: description || '',
            timeLimitSeconds: timeLimitSeconds || null,
            data: JSON.stringify({
                root: {
                    children: [],
                    direction: null,
                    format: '',
                    indent: 0,
                    type: 'root',
                    version: 1
                }
            })
        });
        return {
            success: true,
            unit: {
                id: newUnit.id,
                name: newUnit.name,
                description: newUnit.description,
                timeLimitSeconds: newUnit.timeLimitSeconds
            }
        };
    } catch (error) {
        console.error('Create unit error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeCreateAssignment({ unitId, sectionId, dueDate, learner }) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        // Validate unit and section exist
        const { data: unit } = await client.models.Unit.get({
            id: unitId
        });
        const { data: section } = await client.models.Section.get({
            id: sectionId
        });
        if (!unit) {
            return {
                success: false,
                error: 'Unit not found'
            };
        }
        if (!section) {
            return {
                success: false,
                error: 'Section not found'
            };
        }
        const { data: newAssignment } = await client.models.Assignment.create({
            unitID: unitId,
            sectionID: sectionId,
            dueDate,
            learner: learner || section.learner,
            status: 'PUBLISHED'
        });
        // Add learner to unit's dynamic group if not already present
        const learners = unit.learners || [];
        if (!learners.includes(section.learner)) {
            learners.push(section.learner);
            await client.models.Unit.update({
                id: unit.id,
                learners: learners
            });
        }
        return {
            success: true,
            assignment: {
                id: newAssignment.id,
                unitID: newAssignment.unitID,
                sectionID: newAssignment.sectionID,
                dueDate: newAssignment.dueDate,
                learner: newAssignment.learner
            }
        };
    } catch (error) {
        console.error('Create assignment error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeAddTimerToUnit({ unitId, seconds }) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: unit } = await client.models.Unit.get({
            id: unitId
        });
        if (!unit) {
            return {
                success: false,
                error: 'Unit not found'
            };
        }
        await client.models.Unit.update({
            id: unit.id,
            timeLimitSeconds: seconds
        });
        return {
            success: true,
            unitId,
            timeLimitSeconds: seconds
        };
    } catch (error) {
        console.error('Add timer error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeCreateVocabularyWord({ phrase, phonetic, definition, unitId }) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: newWord } = await client.models.Word.create({
            phrase,
            phonetic: phonetic || '',
            definition,
            unitID: unitId || null
        });
        return {
            success: true,
            word: {
                id: newWord.id,
                phrase: newWord.phrase,
                phonetic: newWord.phonetic,
                definition: newWord.definition
            }
        };
    } catch (error) {
        console.error('Create word error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeCreateQuestion({ prompt, answer, unitId }) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: newQuestion } = await client.models.Question.create({
            prompt,
            answer,
            unitID: unitId || null
        });
        return {
            success: true,
            question: {
                id: newQuestion.id,
                prompt: newQuestion.prompt,
                answer: newQuestion.answer
            }
        };
    } catch (error) {
        console.error('Create question error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeListSections() {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: sections } = await client.models.Section.list();
        // Filter out null items that can occur in subscription updates
        const validSections = sections.filter((s)=>s != null && s.id != null);
        return {
            success: true,
            count: validSections.length,
            sections: validSections.map((s)=>({
                    id: s.id,
                    name: s.name,
                    description: s.description,
                    learner: s.learner,
                    joinCode: s.joinCode
                }))
        };
    } catch (error) {
        console.error('List sections error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeListUnits({ limit }) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: units } = await client.models.Unit.list();
        const activeUnits = (units || []).filter((u)=>u != null && u.deletedAt == null);
        const result = limit ? activeUnits.slice(0, limit) : activeUnits;
        return {
            success: true,
            count: result.length,
            total: activeUnits.length,
            units: result.map((u)=>({
                    id: u.id,
                    name: u.name,
                    description: u.description,
                    timeLimitSeconds: u.timeLimitSeconds,
                    status: u.status
                }))
        };
    } catch (error) {
        console.error('List units error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeGetUnitDetails({ unitId }) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: unit } = await client.models.Unit.get({
            id: unitId
        });
        if (!unit) {
            return {
                success: false,
                error: 'Unit not found'
            };
        }
        // Get assignments for this unit
        const { data: assignments } = await client.models.Assignment.list({
            filter: {
                unitID: {
                    eq: unitId
                }
            }
        });
        // Get associated words via UnitWord join table
        const { data: unitWords } = await client.models.UnitWord.list({
            filter: {
                unitID: {
                    eq: unitId
                }
            }
        });
        // Get associated questions via QuestionUnit join table
        const { data: unitQuestions } = await client.models.QuestionUnit.list({
            filter: {
                unitID: {
                    eq: unitId
                }
            }
        });
        return {
            success: true,
            unit: {
                id: unit.id,
                name: unit.name,
                description: unit.description,
                timeLimitSeconds: unit.timeLimitSeconds,
                status: unit.status,
                assignments: assignments.length,
                vocabularyCount: unitWords.length,
                questionCount: unitQuestions.length,
                learners: unit.learners || []
            }
        };
    } catch (error) {
        console.error('Get unit details error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeUpdateUnit({ unitId, name, description, timeLimitSeconds }) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: unit } = await client.models.Unit.get({
            id: unitId
        });
        if (!unit) {
            return {
                success: false,
                error: 'Unit not found'
            };
        }
        const updates = {
            id: unitId
        };
        if (name !== undefined) updates.name = name;
        if (description !== undefined) updates.description = description;
        if (timeLimitSeconds !== undefined) updates.timeLimitSeconds = timeLimitSeconds;
        await client.models.Unit.update(updates);
        return {
            success: true,
            unitId,
            updated: {
                name,
                description,
                timeLimitSeconds
            }
        };
    } catch (error) {
        console.error('Update unit error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeDeleteAssignment({ assignmentId }) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: assignment } = await client.models.Assignment.get({
            id: assignmentId
        });
        if (!assignment) {
            return {
                success: false,
                error: 'Assignment not found'
            };
        }
        await client.models.Assignment.delete({
            id: assignmentId
        });
        return {
            success: true,
            assignmentId,
            deleted: true
        };
    } catch (error) {
        console.error('Delete assignment error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeInsertQuiz({ questions, title }) {
    try {
        // Create Lexical QuizNode data structure
        const quizData = {
            title: title || 'Quiz',
            questions: questions.map((q, index)=>({
                    id: `q-${Date.now()}-${index}`,
                    prompt: q.prompt,
                    type: q.type || 'multiple-choice',
                    options: q.options || [],
                    correctAnswer: q.correctAnswer,
                    points: q.points || 1
                }))
        };
        return {
            success: true,
            action: 'insert_editor_block',
            blockType: 'quiz',
            blockData: quizData,
            preview: {
                title: quizData.title,
                questionCount: questions.length,
                totalPoints: questions.reduce((sum, q)=>sum + (q.points || 1), 0),
                questions: questions.map((q)=>({
                        prompt: q.prompt,
                        type: q.type
                    }))
            },
            message: `Quiz block ready: "${title || 'Quiz'}" with ${questions.length} questions`
        };
    } catch (error) {
        console.error('Insert quiz error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeInsertAnswerBlock({ wordIds, requestDefinition = false, allowedInput = {} }) {
    try {
        const defaultAllowedInput = {
            keyboard: true,
            speech: false,
            handwriting: false,
            ...allowedInput
        };
        const blockData = {
            wordIDs: wordIds,
            requestDefinition,
            allowedInput: defaultAllowedInput,
            promptMethod: []
        };
        return {
            success: true,
            action: 'insert_editor_block',
            blockType: 'answer',
            blockData,
            preview: {
                wordCount: wordIds.length,
                mode: requestDefinition ? 'Request Definition' : 'Request Translation',
                inputMethods: Object.entries(defaultAllowedInput).filter(([k, v])=>v).map(([k])=>k)
            },
            message: `Answer block ready for ${wordIds.length} word(s)`
        };
    } catch (error) {
        console.error('Insert answer block error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeInsertMeaningAssociation({ wordIds, instructions }) {
    try {
        const blockData = {
            wordIDs: wordIds,
            instructions: instructions || 'Match each term with its definition'
        };
        return {
            success: true,
            action: 'insert_editor_block',
            blockType: 'meaning-association',
            blockData,
            preview: {
                wordCount: wordIds.length,
                instructions: blockData.instructions
            },
            message: `Meaning association block ready for ${wordIds.length} word(s)`
        };
    } catch (error) {
        console.error('Insert meaning association error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeInsertCustomAnswer({ prompt, acceptedAnswers, caseSensitive = false, allowMultipleAttempts = true }) {
    try {
        const blockData = {
            prompt,
            acceptedAnswers,
            caseSensitive,
            allowMultipleAttempts,
            id: `ca-${Date.now()}`
        };
        return {
            success: true,
            action: 'insert_editor_block',
            blockType: 'custom-answer',
            blockData,
            preview: {
                prompt,
                answerCount: acceptedAnswers.length,
                caseSensitive,
                allowMultipleAttempts
            },
            message: `Custom answer block ready: "${prompt}"`
        };
    } catch (error) {
        console.error('Insert custom answer error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executePublishUnit({ unitId, generateEmbeddings = true }) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: unit } = await client.models.Unit.get({
            id: unitId
        });
        if (!unit) {
            return {
                success: false,
                error: 'Unit not found'
            };
        }
        // Update unit status to PUBLISHED
        await client.models.Unit.update({
            id: unitId,
            status: 'PUBLISHED',
            publishedAt: new Date().toISOString()
        });
        // Generate embeddings if requested
        let embeddingResult = null;
        if (generateEmbeddings) {
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$0bcb75__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateUnitEmbeddings"])(unitId);
                if (result.success) {
                    embeddingResult = {
                        success: true,
                        message: 'Embeddings generated successfully'
                    };
                }
            } catch (embeddingError) {
                console.warn('Embedding generation failed:', embeddingError);
                embeddingResult = {
                    success: false,
                    message: 'Unit published but embedding generation failed'
                };
            }
        }
        return {
            success: true,
            unitId,
            status: 'PUBLISHED',
            embeddings: embeddingResult,
            message: `Unit "${unit.name}" published successfully${generateEmbeddings ? ' with embeddings' : ''}`
        };
    } catch (error) {
        console.error('Publish unit error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeNavigateToEditorTab({ tab }) {
    try {
        const tabDescriptions = {
            'assignments': 'Assignment settings - manage where this unit is assigned',
            'toc': 'Table of Contents - see unit structure and navigate between sections',
            'dictionary': 'Dictionary Editor - manage vocabulary words for this unit',
            'questions': 'Question Bank - manage practice questions',
            'files': 'File Manager - upload and manage images, audio, video, and PDFs',
            'configuration': 'Unit Configuration - settings like time limits, publishing status, etc.'
        };
        if (!tabDescriptions[tab]) {
            return {
                success: false,
                error: `Unknown tab: ${tab}. Valid tabs are: ${Object.keys(tabDescriptions).join(', ')}`
            };
        }
        return {
            success: true,
            action: 'navigate_to_tab',
            tab,
            description: tabDescriptions[tab],
            message: `Opening ${tab} tab...`
        };
    } catch (error) {
        console.error('Navigate to editor tab error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeGetEditorButtons() {
    try {
        const editorFeatures = {
            toolbar: [
                {
                    name: 'Bold',
                    description: 'Make text bold',
                    shortcut: 'Cmd+B / Ctrl+B'
                },
                {
                    name: 'Italic',
                    description: 'Make text italic',
                    shortcut: 'Cmd+I / Ctrl+I'
                },
                {
                    name: 'Underline',
                    description: 'Underline text',
                    shortcut: 'Cmd+U / Ctrl+U'
                },
                {
                    name: 'Code',
                    description: 'Format as code',
                    shortcut: 'Cmd+E / Ctrl+E'
                },
                {
                    name: 'Link',
                    description: 'Insert hyperlink',
                    shortcut: 'Cmd+K / Ctrl+K'
                },
                {
                    name: 'Headings',
                    description: 'Format as H1, H2, H3 headings',
                    shortcut: 'Type # ## or ###'
                },
                {
                    name: 'Lists',
                    description: 'Create bullet or numbered lists',
                    shortcut: 'Type - or 1.'
                },
                {
                    name: 'Quote',
                    description: 'Insert block quote',
                    shortcut: 'Type >'
                },
                {
                    name: 'Code Block',
                    description: 'Insert code block',
                    shortcut: 'Type ```'
                }
            ],
            blocks: [
                {
                    name: 'Quiz',
                    description: 'Interactive quiz with multiple choice, true/false, or short answer',
                    command: '/'
                },
                {
                    name: 'Answer Block',
                    description: 'Graded vocabulary translation/definition block',
                    command: '/'
                },
                {
                    name: 'Meaning Association',
                    description: 'Drag-and-drop matching exercise',
                    command: '/'
                },
                {
                    name: 'Custom Answer',
                    description: 'Custom graded question with flexible answers',
                    command: '/'
                },
                {
                    name: 'Image',
                    description: 'Insert image from files or URL',
                    command: '/'
                },
                {
                    name: 'Video',
                    description: 'Embed video from files or URL',
                    command: '/'
                },
                {
                    name: 'Audio',
                    description: 'Insert audio player',
                    command: '/'
                },
                {
                    name: 'PDF',
                    description: 'Embed PDF viewer',
                    command: '/'
                },
                {
                    name: 'Divider',
                    description: 'Horizontal line separator',
                    command: '/'
                }
            ],
            leftSidebar: [
                {
                    name: 'Assignments',
                    description: 'View and manage assignments for this unit'
                },
                {
                    name: 'Table of Contents',
                    description: 'Navigate unit structure'
                },
                {
                    name: 'Dictionary',
                    description: 'Add and edit vocabulary words'
                },
                {
                    name: 'Questions',
                    description: 'Manage question bank'
                },
                {
                    name: 'Files',
                    description: 'Upload and manage media files'
                },
                {
                    name: 'Configuration',
                    description: 'Unit settings and publishing'
                }
            ],
            topBar: [
                {
                    name: 'Publish',
                    description: 'Publish unit to make it available to students'
                },
                {
                    name: 'Save',
                    description: 'Save current changes'
                },
                {
                    name: 'Preview',
                    description: 'Preview how students will see the unit'
                },
                {
                    name: 'Settings',
                    description: 'Unit configuration'
                }
            ],
            chatAssistant: [
                {
                    name: 'Search Content',
                    description: 'Search files, vocabulary, and questions'
                },
                {
                    name: 'Insert Blocks',
                    description: 'Ask AI to create quiz, answer, or other blocks'
                },
                {
                    name: 'Generate Content',
                    description: 'AI-powered content generation'
                },
                {
                    name: 'Get Help',
                    description: 'Ask questions about how to use features'
                }
            ]
        };
        return {
            success: true,
            features: editorFeatures,
            summary: {
                totalFeatures: Object.values(editorFeatures).reduce((sum, arr)=>sum + arr.length, 0),
                categories: Object.keys(editorFeatures)
            },
            message: 'Editor features and controls listed'
        };
    } catch (error) {
        console.error('Get editor buttons error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
/**
 * Tour Control Functions
 * Note: These return instructions to the UI layer to trigger tours.
 * The ChatSidebar or TourContext will handle the actual tour activation.
 */ // This will be populated by TourContext on app load
let tourTasksData = null;
function setTourTasksData(tasks) {
    tourTasksData = tasks;
    console.log('[chatTools] Tour tasks data registered:', tasks?.length || 0, 'tasks');
}
async function executeListTours({ persona, category }) {
    try {
        if (!tourTasksData) {
            return {
                success: false,
                error: 'Tour system not initialized. Tours are only available in Storybook or when TourContext is loaded.'
            };
        }
        let filteredTours = tourTasksData;
        // Filter by persona
        if (persona) {
            filteredTours = filteredTours.filter((t)=>t.persona === persona || t.persona === 'all');
        }
        // Filter by category
        if (category) {
            filteredTours = filteredTours.filter((t)=>t.category.toLowerCase().includes(category.toLowerCase()));
        }
        // Sort by order
        filteredTours = filteredTours.sort((a, b)=>a.order - b.order);
        return {
            success: true,
            count: filteredTours.length,
            total: tourTasksData.length,
            tours: filteredTours.map((t)=>({
                    id: t.id,
                    title: t.title,
                    description: t.description,
                    persona: t.persona,
                    category: t.category,
                    estimatedTime: t.estimatedTime,
                    hasTutorial: !!t.completionCriteria?.tutorialStoryId || !!t.completionCriteria?.storyId,
                    hasQuiz: !!t.completionCriteria?.quizStoryId || !!t.completionCriteria?.storyId
                }))
        };
    } catch (error) {
        console.error('List tours error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeStartTour({ tourId, mode = 'tutorial' }) {
    try {
        if (!tourTasksData) {
            return {
                success: false,
                error: 'Tour system not initialized.'
            };
        }
        const tour = tourTasksData.find((t)=>t.id === tourId);
        if (!tour) {
            return {
                success: false,
                error: `Tour not found: ${tourId}. Use list_tours to see available tours.`
            };
        }
        // Return action for ChatSidebar to handle
        return {
            success: true,
            action: 'start_tour',
            tourId: tour.id,
            mode,
            tour: {
                title: tour.title,
                description: tour.description,
                estimatedTime: tour.estimatedTime,
                instructions: tour.instructions
            },
            message: `Starting "${tour.title}" in ${mode} mode...`
        };
    } catch (error) {
        console.error('Start tour error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeGetTourInfo({ tourId }) {
    try {
        if (!tourTasksData) {
            return {
                success: false,
                error: 'Tour system not initialized.'
            };
        }
        const tour = tourTasksData.find((t)=>t.id === tourId);
        if (!tour) {
            return {
                success: false,
                error: `Tour not found: ${tourId}`
            };
        }
        return {
            success: true,
            tour: {
                id: tour.id,
                title: tour.title,
                description: tour.description,
                instructions: tour.instructions || [],
                persona: tour.persona,
                category: tour.category,
                estimatedTime: tour.estimatedTime,
                order: tour.order,
                hasTutorial: !!tour.completionCriteria?.tutorialStoryId || !!tour.completionCriteria?.storyId,
                hasQuiz: !!tour.completionCriteria?.quizStoryId || !!tour.completionCriteria?.storyId
            }
        };
    } catch (error) {
        console.error('Get tour info error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeStopTour() {
    try {
        return {
            success: true,
            action: 'stop_tour',
            message: 'Stopping current tour...'
        };
    } catch (error) {
        console.error('Stop tour error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function executeTool(toolName, args) {
    const toolMap = {
        list_tours: executeListTours,
        start_tour: executeStartTour,
        get_tour_info: executeGetTourInfo,
        stop_tour: executeStopTour,
        search_content: executeSearchContent,
        create_section: executeCreateSection,
        copy_gamification_settings: executeCopyGamificationSettings,
        create_unit: executeCreateUnit,
        create_assignment: executeCreateAssignment,
        add_timer_to_unit: executeAddTimerToUnit,
        create_vocabulary_word: executeCreateVocabularyWord,
        create_question: executeCreateQuestion,
        list_sections: executeListSections,
        list_units: executeListUnits,
        get_unit_details: executeGetUnitDetails,
        update_unit: executeUpdateUnit,
        delete_assignment: executeDeleteAssignment,
        insert_quiz: executeInsertQuiz,
        insert_answer_block: executeInsertAnswerBlock,
        insert_meaning_association: executeInsertMeaningAssociation,
        insert_custom_answer: executeInsertCustomAnswer,
        publish_unit: executePublishUnit,
        navigate_to_editor_tab: executeNavigateToEditorTab,
        get_editor_buttons: executeGetEditorButtons,
        start_practice_drill: executeStartPracticeDrill
    };
    const executor = toolMap[toolName];
    if (!executor) {
        return {
            success: false,
            error: `Unknown tool: ${toolName}`
        };
    }
    try {
        return await executor(args);
    } catch (error) {
        console.error(`Tool execution error (${toolName}):`, error);
        return {
            success: false,
            error: error.message
        };
    }
}
// ============================================================================
// Practice Drill Tool — callback-based (UI managed by ChatSidebar)
// ============================================================================
let practiceDrillCallback = null;
function setPracticeDrillCallback(fn) {
    practiceDrillCallback = fn;
    console.log('[chatTools] Practice drill callback registered:', !!fn);
}
async function executeStartPracticeDrill({ drillType = 'mixed', count = 10, sources } = {}) {
    const config = {
        drillType,
        count: Math.min(20, Math.max(5, count)),
        sources: sources || {
            vocabulary: true,
            questions: true,
            text: true,
            documents: true
        }
    };
    if (practiceDrillCallback) {
        practiceDrillCallback(config);
        return {
            success: true,
            message: `Starting a ${config.drillType} practice drill with ${config.count} questions.`
        };
    }
    return {
        success: false,
        error: 'Practice drill is not available on this page. Navigate to a unit workbook or the units list first.'
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/moderateContent.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Content Moderation Utility
 *
 * Provides automatic content moderation using OpenAI's Moderation API.
 * All user-generated content is flagged but NOT blocked - instructors
 * handle flagged content according to their school policies.
 *
 * Primary path: Server Action (app/actions/moderate.ts)
 * Fallback: Lambda via GraphQL mutation
 */ __turbopack_context__.s([
    "buildModerationFields",
    ()=>buildModerationFields,
    "getModerationStatus",
    ()=>getModerationStatus,
    "moderateAndSave",
    ()=>moderateAndSave,
    "moderateContent",
    ()=>moderateContent,
    "shouldShowModerationWarning",
    ()=>shouldShowModerationWarning
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$395605__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:395605 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$e5fd85__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:e5fd85 [app-client] (ecmascript) <text/javascript>");
;
;
;
/**
 * Extract text content from various data structures for moderation
 * @param {Object} data - Data to extract text from (Unit.data, Grade.data, etc.)
 * @returns {string} - Combined text content
 */ function extractTextContent(data) {
    const texts = [];
    if (!data) return "";
    // Handle JSON string
    if (typeof data === "string") {
        try {
            data = JSON.parse(data);
        } catch (e) {
            return data; // Return as-is if not JSON
        }
    }
    // Handle Lexical editor state
    if (data.root && data.root.children) {
        const extractFromNode = (node)=>{
            if (node.text) {
                texts.push(node.text);
            }
            if (node.children) {
                node.children.forEach(extractFromNode);
            }
            // Extract from custom block types
            if (node.prompt) texts.push(node.prompt);
            if (node.answer) texts.push(node.answer);
            if (node.phrase) texts.push(node.phrase);
            if (node.definition) texts.push(node.definition);
        };
        data.root.children.forEach(extractFromNode);
    }
    // Handle Grade data (question responses)
    if (typeof data === "object") {
        Object.values(data).forEach((item)=>{
            if (item.userAnswer) texts.push(item.userAnswer);
            if (item.response) texts.push(item.response);
        });
    }
    return texts.join(" ").trim();
}
async function moderateContent(content, options = {}) {
    try {
        // Extract text if content is an object
        const textToModerate = typeof content === "string" ? content : extractTextContent(content);
        if (!textToModerate || textToModerate.length === 0 || textToModerate === "null" || textToModerate === "undefined") {
            return {
                flagged: false,
                categories: {},
                categoryScores: {},
                model: "omni-moderation-latest",
                error: null
            };
        }
        // Primary path: Server Action (no Lambda cold start)
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$395605__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["moderateContent"])({
            content: textToModerate
        });
        // Dispatch notification to instructors/admins if flagged
        if (result.flagged && options.modelName && options.recordId) {
            const flaggedCategories = Object.entries(result.categories || {}).filter(([, v])=>v === true).map(([k])=>k);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$e5fd85__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["notifyModerationFlagged"])({
                modelName: options.modelName,
                recordId: options.recordId,
                sectionId: options.sectionId,
                ownerId: options.ownerId,
                flaggedCategories
            }).catch((err)=>console.warn("[moderation] Notification dispatch failed:", err));
        }
        return {
            ...result,
            error: null
        };
    } catch (error) {
        console.error("Error moderating content:", error);
        // Return non-flagged result on error - don't block saves
        return {
            flagged: false,
            categories: {},
            categoryScores: {},
            model: "omni-moderation-latest",
            error: error.message
        };
    }
}
function buildModerationFields(moderationResult) {
    if (!moderationResult) return {};
    return {
        moderationStatus: moderationResult.flagged ? "flagged" : "approved",
        moderationFlags: moderationResult.flagged ? JSON.stringify({
            categories: moderationResult.categories,
            categoryScores: moderationResult.categoryScores,
            model: moderationResult.model
        }) : null,
        moderationCheckedAt: new Date().toISOString()
    };
}
async function moderateAndSave(modelName, item, content, context = {}) {
    const result = await moderateContent(content, {
        modelName,
        recordId: item.id
    });
    if (result.flagged) {
        console.warn("Content flagged by moderation:", {
            categories: result.categories,
            itemId: item.id,
            modelName
        });
        // Notify instructors and admins asynchronously (non-blocking)
        const flaggedCategories = Object.entries(result.categories || {}).filter(([, v])=>v === true).map(([k])=>k);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$e5fd85__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["notifyModerationFlagged"])({
            modelName,
            recordId: item.id,
            sectionId: context.sectionId,
            ownerId: context.ownerId || item.owner,
            flaggedCategories
        }).catch((err)=>console.warn("[moderation] Notification dispatch failed:", err));
    }
    return result;
}
function getModerationStatus(item) {
    if (!item.moderationCheckedAt) {
        return "Not checked";
    }
    if (item.moderationStatus === "flagged") {
        try {
            const flags = JSON.parse(item.moderationFlags || "{}");
            const flaggedCategories = Object.entries(flags.categories || {}).filter(([_, value])=>value === true).map(([key])=>key);
            if (flaggedCategories.length > 0) {
                return `Flagged: ${flaggedCategories.join(", ")}`;
            }
        } catch (e) {
            console.warn("Error parsing moderation flags:", e);
        }
        return "Flagged for review";
    }
    return "Approved";
}
function shouldShowModerationWarning(item) {
    return item.moderationStatus === "flagged";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/extractTextFromLexical.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Extract plain text from Lexical editor JSON structure.
 *
 * Shared utility used by:
 * - unitContentStorage.ts (write plain.txt on publish)
 * - rebuildSearchBundle Lambda (generate embeddings from plain text)
 * - gamification engine (skill tree generation)
 */ __turbopack_context__.s([
    "extractTextFromLexical",
    ()=>extractTextFromLexical
]);
function extractTextFromLexical(data) {
    if (!data) return "";
    let parsed;
    if (typeof data === "string") {
        try {
            parsed = JSON.parse(data);
        } catch  {
            return "";
        }
    } else {
        parsed = data;
    }
    if (!parsed?.root?.children) return "";
    const parts = [];
    function walk(node) {
        if (!node) return;
        if (node.text) parts.push(node.text);
        if (node.prompt) parts.push(node.prompt);
        if (node.answer) parts.push(node.answer);
        if (node.phrase) parts.push(node.phrase);
        if (node.definition) parts.push(node.definition);
        if (Array.isArray(node.children)) {
            for (const child of node.children)walk(child);
        }
    }
    walk(parsed.root);
    return parts.join(" ").replace(/\s+/g, " ").trim();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/unitContentStorage.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "draftKey",
    ()=>draftKey,
    "historyKey",
    ()=>historyKey,
    "listVersionHistory",
    ()=>listVersionHistory,
    "loadContent",
    ()=>loadContent,
    "loadHistoryVersion",
    ()=>loadHistoryVersion,
    "loadModelYjsSnapshot",
    ()=>loadModelYjsSnapshot,
    "loadYjsSnapshot",
    ()=>loadYjsSnapshot,
    "publishContent",
    ()=>publishContent,
    "publishedKey",
    ()=>publishedKey,
    "restoreVersion",
    ()=>restoreVersion,
    "saveDraftContent",
    ()=>saveDraftContent,
    "saveModelYjsSnapshot",
    ()=>saveModelYjsSnapshot,
    "saveThumbnail",
    ()=>saveThumbnail,
    "saveYjsSnapshot",
    ()=>saveYjsSnapshot,
    "yjsSnapshotKey",
    ()=>yjsSnapshotKey
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/client/apis/uploadData.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/downloadData.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/list.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$extractTextFromLexical$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/extractTextFromLexical.ts [app-client] (ecmascript)");
;
;
/** S3 key helpers — require identityId (from Unit.identityId) */ function draftKey(identityId, unitId) {
    return `private/${identityId}/units/${unitId}/draft.json`;
}
/**
 * Phase 6: published content lives under the type-scoped CDN path.
 * identityId is intentionally excluded — the publishUnit Lambda writes here
 * using its IAM execution role (no Cognito identity needed).
 */ function publishedKey(unitId) {
    return `protected/units/${unitId}/published.json`;
}
function yjsSnapshotKey(identityId, unitId) {
    return `private/${identityId}/units/${unitId}/yjs-snapshot.bin`;
}
function historyKey(identityId, unitId, version) {
    return `private/${identityId}/units/${unitId}/history/v${version}.json`;
}
function plainTextKey(identityId, unitId) {
    return `protected/${identityId}/units/${unitId}/plain.txt`;
}
async function saveDraftContent(identityId, unitId, content) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
        path: draftKey(identityId, unitId),
        data: content,
        options: {
            contentType: "application/json"
        }
    }).result;
}
async function saveYjsSnapshot(identityId, unitId, snapshot) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
        path: yjsSnapshotKey(identityId, unitId),
        data: new Blob([
            new Uint8Array(snapshot)
        ]),
        options: {
            contentType: "application/octet-stream"
        }
    }).result;
}
async function loadYjsSnapshot(identityId, unitId) {
    try {
        const path = yjsSnapshotKey(identityId, unitId);
        // Check if the file exists first to avoid 404 console errors
        const { items } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["list"])({
            path
        });
        if (!items || items.length === 0) return null;
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"])({
            path
        }).result;
        const blob = await result.body.blob();
        const buffer = await blob.arrayBuffer();
        return new Uint8Array(buffer);
    } catch  {
        return null; // File doesn't exist yet or download failed
    }
}
async function publishContent(identityId, unitId, contentVersion) {
    // Read current draft (owner reads from private/)
    const draftResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"])({
        path: draftKey(identityId, unitId)
    }).result;
    const draftContent = await draftResult.body.text();
    // Only write history snapshot — published.json is written by the publishUnit Lambda
    try {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
            path: historyKey(identityId, unitId, contentVersion),
            data: draftContent,
            options: {
                contentType: "application/json"
            }
        }).result;
    } catch (err) {
        console.error("[unitContentStorage] History snapshot failed:", err);
    }
    // Write plain text for embedding generation and full-text search
    try {
        const plainText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$extractTextFromLexical$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractTextFromLexical"])(draftContent);
        if (plainText) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
                path: plainTextKey(identityId, unitId),
                data: plainText,
                options: {
                    contentType: "text/plain"
                }
            }).result;
        }
    } catch (err) {
        console.error("[unitContentStorage] Plain text write failed:", err);
    }
}
async function loadContent(identityId, unitId, variant) {
    if (variant === "draft") {
        try {
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"])({
                path: draftKey(identityId, unitId)
            }).result;
            return await result.body.text();
        } catch  {
            return null;
        }
    }
    // Phase 6: published content is fetched from CloudFront.
    // The browser automatically sends the CloudFront-Policy / CloudFront-Signature /
    // CloudFront-Key-Pair-Id cookies set by app/providers.tsx at login.
    const cdnDomain = ("TURBOPACK compile-time value", "");
    if ("TURBOPACK compile-time truthy", 1) {
        // Fallback: read via Amplify Storage (no CDN available, e.g. local dev)
        try {
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"])({
                path: publishedKey(unitId)
            }).result;
            return await result.body.text();
        } catch  {
            return null;
        }
    }
    try {
        const url = `https://${cdnDomain}/${publishedKey(unitId)}`;
        const res = await fetch(url, {
            credentials: "include"
        });
        if (!res.ok) return null;
        return await res.text();
    } catch  {
        return null;
    }
}
async function loadHistoryVersion(identityId, unitId, version) {
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"])({
            path: historyKey(identityId, unitId, version)
        }).result;
        return await result.body.text();
    } catch  {
        return null;
    }
}
async function restoreVersion(identityId, unitId, version) {
    const content = await loadHistoryVersion(identityId, unitId, version);
    if (!content) return false;
    await saveDraftContent(identityId, unitId, content);
    return true;
}
async function listVersionHistory(identityId, unitId) {
    try {
        const prefix = `private/${identityId}/units/${unitId}/history/`;
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["list"])({
            path: prefix
        });
        const versions = result.items.map((item)=>{
            const match = item.path.match(/\/v(\d+)\.json$/);
            return match ? parseInt(match[1], 10) : null;
        }).filter((v)=>v != null).sort((a, b)=>b - a);
        return versions;
    } catch  {
        return [];
    }
}
;
function modelSnapshotKey(identityId, modelType, modelId) {
    return `private/${identityId}/${modelType}/${modelId}/yjs-snapshot.bin`;
}
async function saveModelYjsSnapshot(identityId, modelType, modelId, snapshot) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
        path: modelSnapshotKey(identityId, modelType, modelId),
        data: new Blob([
            new Uint8Array(snapshot)
        ]),
        options: {
            contentType: "application/octet-stream"
        }
    }).result;
}
async function loadModelYjsSnapshot(identityId, modelType, modelId) {
    try {
        const path = modelSnapshotKey(identityId, modelType, modelId);
        const { items } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["list"])({
            path
        });
        if (!items || items.length === 0) return null;
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"])({
            path
        }).result;
        const blob = await result.body.blob();
        const buffer = await blob.arrayBuffer();
        return new Uint8Array(buffer);
    } catch  {
        return null;
    }
}
/** S3 key for unit thumbnail image */ function thumbnailKey(unitId) {
    return `protected/units/${unitId}/thumbnail.png`;
}
async function saveThumbnail(unitId, blob) {
    const key = thumbnailKey(unitId);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
        path: key,
        data: blob,
        options: {
            contentType: "image/png"
        }
    }).result;
    return key;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/serializeLexicalToSparseText.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Converts Lexical editor JSON into a sparse text representation
 * suitable for sending to the chat Lambda without exceeding
 * API Gateway payload limits.
 *
 * - Preserves all text, headings, lists, quotes, links, and tables
 * - Replaces images with [image: altText] references
 * - Replaces audio/video/playlists with file names and descriptions
 * - Replaces YouTube embeds with [youtube: videoID]
 * - Describes interactive exercises with their full content inline
 * - Strips base64 data, S3 URLs, and embedded editor states
 *
 * @param {string} dataJson - The JSON string from unit.data
 * @param {Object} [lookups] - Optional lookup maps for resolving IDs to content
 * @param {Object} [lookups.words] - Word map keyed by ID: { [id]: { phrase, definition, pronunciation } }
 * @param {Object} [lookups.questions] - Question map keyed by ID: { [id]: { prompt, answer, hint, choices } }
 * @param {Object} [lookups.files] - File map keyed by ID: { [id]: { name, description, mimeType } }
 * @param {Object} [lookups.gradeData] - Parsed grade.data keyed by block node key
 * @returns {string} Plain-ish text representation
 */ __turbopack_context__.s([
    "default",
    ()=>serializeLexicalToSparseText
]);
function serializeLexicalToSparseText(dataJson, lookups = {}) {
    if (!dataJson) return '';
    let parsed;
    try {
        parsed = typeof dataJson === 'string' ? JSON.parse(dataJson) : dataJson;
    } catch  {
        return '';
    }
    const root = parsed?.root;
    if (!root || !root.children) return '';
    const ctx = {
        words: lookups.words || {},
        questions: lookups.questions || {},
        files: lookups.files || {},
        gradeData: lookups.gradeData || {},
        blockIndex: 0
    };
    return serializeChildren(root.children, ctx).trim();
}
function serializeChildren(children, ctx) {
    if (!Array.isArray(children)) return '';
    return children.map((child)=>serializeNode(child, ctx)).filter(Boolean).join('\n');
}
function lookupWord(id, ctx) {
    const w = ctx.words[id];
    if (!w) return id;
    let s = w.phrase || id;
    if (w.pronunciation) s += ` (${w.pronunciation})`;
    if (w.definition) s += ` — ${w.definition}`;
    return s;
}
function lookupQuestion(id, ctx) {
    const q = ctx.questions[id];
    if (!q) return id;
    let s = `Q: ${q.prompt}`;
    if (q.choices && Array.isArray(q.choices)) {
        q.choices.forEach((c)=>{
            s += `\n  ${c.correct ? '✓' : '○'} ${c.choice}`;
        });
    }
    if (q.answer) s += `\n  Answer: ${q.answer}`;
    if (q.hint) s += `\n  Hint: ${q.hint}`;
    return s;
}
function lookupFile(id, ctx) {
    const f = ctx.files[id];
    if (!f) return id;
    let s = f.name || id;
    if (f.description) s += ` — ${f.description}`;
    if (f.mimeType) s += ` (${f.mimeType})`;
    return s;
}
function formatGradeStatus(nodeKey, ctx) {
    const g = ctx.gradeData[nodeKey];
    if (!g) return '';
    const parts = [];
    if (g.complete) parts.push('✓ completed');
    else parts.push('… in progress');
    if (g.accuracy != null) parts.push(`accuracy: ${g.accuracy}%`);
    if (g.userAnswer) parts.push(`student answered: "${g.userAnswer}"`);
    return parts.length ? `  [Student progress: ${parts.join(', ')}]` : '';
}
function serializeNode(node, ctx) {
    if (!node) return '';
    switch(node.type){
        // ── Text ──
        case 'text':
            return node.text || '';
        case 'linebreak':
            return '\n';
        // ── Block containers ──
        case 'root':
            return serializeChildren(node.children, ctx);
        case 'paragraph':
            return serializeChildren(node.children, ctx);
        case 'heading':
            {
                const level = node.tag ? node.tag.replace('h', '') : '1';
                const prefix = '#'.repeat(Number(level));
                return `${prefix} ${serializeChildren(node.children, ctx)}`;
            }
        case 'quote':
            return `> ${serializeChildren(node.children, ctx)}`;
        case 'list':
            return serializeList(node, ctx);
        case 'listitem':
            return serializeChildren(node.children, ctx);
        // ── Links ──
        case 'link':
        case 'autolink':
            return `[${serializeChildren(node.children, ctx)}](${node.url || ''})`;
        // ── Code ──
        case 'code':
            return `\`\`\`\n${serializeChildren(node.children, ctx)}\n\`\`\``;
        case 'code-highlight':
            return node.text || '';
        // ── Horizontal rule ──
        case 'horizontalrule':
            return '---';
        // ── Tables ──
        case 'table':
            return serializeTable(node, ctx);
        case 'tablerow':
            return serializeChildren(node.children, ctx);
        case 'tablecell':
            return serializeChildren(node.children, ctx);
        // ── Layout ──
        case 'layout-container':
            return serializeChildren(node.children, ctx);
        case 'layout-item':
            return serializeChildren(node.children, ctx);
        // ── Media — include descriptions and file metadata ──
        case 'image':
            {
                const parts = [
                    '[Image'
                ];
                if (node.altText) parts.push(`alt="${node.altText}"`);
                if (node.path) parts.push(`file=${node.path}`);
                return parts.join(', ') + ']';
            }
        case 'pdf-viewer':
            return `[PDF: ${node.filename || node.path || 'document'}]`;
        case 'youtube':
            return `[YouTube video: ${node.videoID || 'unknown'}]`;
        case 'playlist':
            {
                const fileDescs = (node.fileIDs || []).map((id)=>lookupFile(id, ctx));
                return `[Playlist — ${fileDescs.length} files:\n${fileDescs.map((f)=>`  - ${f}`).join('\n')}\n]`;
            }
        // ── Vocabulary block — show full word content ──
        case 'word-block':
            {
                const desc = lookupWord(node.wordID, ctx);
                return `[Vocabulary: ${desc}]`;
            }
        // ── Interactive exercises — described with full content ──
        case 'answer':
            {
                ctx.blockIndex++;
                const blockKey = node.__key || `answer-${ctx.blockIndex}`;
                const mode = node.requestDefinition === 'translation' ? 'translate the phrase' : node.requestDefinition || 'provide answer';
                const inputMethods = Array.isArray(node.allowedInput) ? node.allowedInput.join(', ') : 'text';
                const wordDescs = (node.wordIDs || []).map((id)=>lookupWord(id, ctx));
                let s = `[Answer Exercise (${mode}, input: ${inputMethods}):\n`;
                wordDescs.forEach((desc, i)=>{
                    s += `  ${i + 1}. ${desc}\n`;
                });
                const grade = formatGradeStatus(blockKey, ctx);
                if (grade) s += grade + '\n';
                s += ']';
                return s;
            }
        case 'meaning-association':
            {
                ctx.blockIndex++;
                const blockKey = node.__key || `ma-${ctx.blockIndex}`;
                const modes = Array.isArray(node.enabledModes) ? node.enabledModes.join(', ') : 'learn, easy, hard';
                const wordDescs = (node.wordIDs || []).map((id)=>lookupWord(id, ctx));
                let s = `[Matching Exercise (modes: ${modes}) — match terms to definitions:\n`;
                wordDescs.forEach((desc, i)=>{
                    s += `  ${i + 1}. ${desc}\n`;
                });
                const grade = formatGradeStatus(blockKey, ctx);
                if (grade) s += grade + '\n';
                s += ']';
                return s;
            }
        case 'custom-answer':
            {
                ctx.blockIndex++;
                const blockKey = node.__key || `ca-${ctx.blockIndex}`;
                const ids = node.ids || node.data?.wordIDs || node.data?.questionIDs || [];
                const items = Array.isArray(ids) ? ids.map((id)=>{
                    // Try word first, then question
                    const w = ctx.words[id];
                    if (w) return `Word: ${lookupWord(id, ctx)}`;
                    const q = ctx.questions[id];
                    if (q) return lookupQuestion(id, ctx);
                    return id;
                }) : [
                    String(ids)
                ];
                let s = '[Custom Answer Exercise:\n';
                items.forEach((desc, i)=>{
                    s += `  ${i + 1}. ${desc}\n`;
                });
                const grade = formatGradeStatus(blockKey, ctx);
                if (grade) s += grade + '\n';
                s += ']';
                return s;
            }
        case 'quiz':
            {
                ctx.blockIndex++;
                const blockKey = node.__key || `quiz-${ctx.blockIndex}`;
                const questionIds = Array.isArray(node.data) ? node.data : [];
                let s = `[Quiz — ${questionIds.length} question(s):\n`;
                questionIds.forEach((id, i)=>{
                    const desc = typeof id === 'string' ? lookupQuestion(id, ctx) : `Question ${i + 1}`;
                    s += `  ${i + 1}. ${desc}\n`;
                });
                const grade = formatGradeStatus(blockKey, ctx);
                if (grade) s += grade + '\n';
                s += ']';
                return s;
            }
        // ── Special nodes ──
        case 'file-metadata':
            {
                const f = node.file;
                let s = `[File: ${f?.name || 'file'}`;
                if (f?.description) s += ` — ${f.description}`;
                if (f?.mimeType) s += ` (${f.mimeType})`;
                s += ']';
                return s;
            }
        case 'excalidraw':
            return '[Drawing/diagram]';
        case 'armor-editor':
            return '[Armor editor block]';
        case 'hashtag':
            return node.text || '';
        // ── Ephemeral (skip) ──
        case 'ai-content-suggestion':
        case 'autocomplete':
            return '';
        default:
            // Unknown node — try to extract children or text
            if (node.children) return serializeChildren(node.children, ctx);
            if (node.text) return node.text;
            return '';
    }
}
function serializeList(node, ctx) {
    if (!node.children) return '';
    const ordered = node.listType === 'number';
    return node.children.map((item, i)=>{
        const prefix = ordered ? `${i + 1}.` : '-';
        const text = serializeNode(item, ctx);
        return `${prefix} ${text}`;
    }).join('\n');
}
function serializeTable(node, ctx) {
    if (!node.children) return '';
    const rows = node.children.map((row)=>{
        if (!row.children) return '';
        const cells = row.children.map((cell)=>serializeChildren(cell.children, ctx));
        return `| ${cells.join(' | ')} |`;
    });
    // Insert header separator after first row
    if (rows.length > 0) {
        const firstRow = node.children[0];
        const colCount = firstRow?.children?.length || 1;
        const separator = `| ${Array(colCount).fill('---').join(' | ')} |`;
        rows.splice(1, 0, separator);
    }
    return rows.join('\n');
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/vectorStoreDB.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearAllEmbeddings",
    ()=>clearAllEmbeddings,
    "deleteEmbeddings",
    ()=>deleteEmbeddings,
    "getEmbeddingsTimestamp",
    ()=>getEmbeddingsTimestamp,
    "getStats",
    ()=>getStats,
    "loadAllEmbeddings",
    ()=>loadAllEmbeddings,
    "loadEmbeddingsByDocument",
    ()=>loadEmbeddingsByDocument,
    "loadEmbeddingsFromS3",
    ()=>loadEmbeddingsFromS3,
    "saveEmbeddings",
    ()=>saveEmbeddings
]);
/**
 * IndexedDB wrapper for vector embeddings storage
 * Provides persistent caching of document embeddings for semantic search
 * 
 * Note: This module is browser-only (uses IndexedDB)
 */ // Lazy-load browser-only dependencies via dynamic import (compatible with Vite/Storybook ESM)
let openDB, downloadData, pako;
let _depsLoaded = false;
async function loadDeps() {
    if (_depsLoaded || ("TURBOPACK compile-time value", "object") === 'undefined') return;
    ({ openDB } = await __turbopack_context__.A("[project]/node_modules/idb/build/index.js [app-client] (ecmascript, async loader)"));
    ({ downloadData } = await __turbopack_context__.A("[project]/node_modules/aws-amplify/dist/esm/storage/index.mjs [app-client] (ecmascript, async loader)"));
    pako = (await __turbopack_context__.A("[project]/node_modules/pako/dist/pako.esm.mjs [app-client] (ecmascript, async loader)")).default || await __turbopack_context__.A("[project]/node_modules/pako/dist/pako.esm.mjs [app-client] (ecmascript, async loader)");
    _depsLoaded = true;
}
const DB_NAME = 'VectorStoreDB';
const DB_VERSION = 1;
const STORE_NAME = 'embeddings';
/**
 * Initialize IndexedDB database
 * @returns {Promise<IDBDatabase>}
 */ async function getDB() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    await loadDeps();
    return openDB(DB_NAME, DB_VERSION, {
        upgrade (db) {
            // Create object store for embeddings if it doesn't exist
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                const store = db.createObjectStore(STORE_NAME, {
                    keyPath: 'id'
                });
                // Index by documentId for faster queries
                store.createIndex('documentId', 'metadata.documentId', {
                    unique: false
                });
                store.createIndex('fileId', 'metadata.fileId', {
                    unique: false
                });
                store.createIndex('updatedAt', 'updatedAt', {
                    unique: false
                });
            }
        }
    });
}
async function saveEmbeddings(documentId, embeddings, metadata = {}) {
    const db = await getDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    // First, delete existing embeddings for this document
    const index = store.index('documentId');
    const existingKeys = await index.getAllKeys(documentId);
    for (const key of existingKeys){
        await store.delete(key);
    }
    // Save new embeddings
    const timestamp = new Date().toISOString();
    let count = 0;
    for (const emb of embeddings){
        const id = `${documentId}-page-${emb.page}`;
        await store.put({
            id,
            documentId,
            page: emb.page,
            vector: emb.embedding,
            text: emb.text || '',
            metadata: {
                ...metadata,
                documentId,
                page: emb.page
            },
            updatedAt: timestamp
        });
        count++;
    }
    await tx.done;
    console.log(`[VectorStoreDB] Saved ${count} embeddings for document ${documentId}`);
    return count;
}
async function loadEmbeddingsByDocument(documentId) {
    const db = await getDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const index = store.index('documentId');
    const embeddings = await index.getAll(documentId);
    await tx.done;
    console.log(`[VectorStoreDB] Loaded ${embeddings.length} embeddings for document ${documentId}`);
    return embeddings;
}
async function loadAllEmbeddings() {
    const db = await getDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const embeddings = await store.getAll();
    await tx.done;
    console.log(`[VectorStoreDB] Loaded ${embeddings.length} total embeddings from IndexedDB`);
    return embeddings;
}
async function deleteEmbeddings(documentId) {
    const db = await getDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const index = store.index('documentId');
    const keys = await index.getAllKeys(documentId);
    for (const key of keys){
        await store.delete(key);
    }
    await tx.done;
    console.log(`[VectorStoreDB] Deleted ${keys.length} embeddings for document ${documentId}`);
    return keys.length;
}
async function clearAllEmbeddings() {
    const db = await getDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    await store.clear();
    await tx.done;
    console.log('[VectorStoreDB] Cleared all embeddings');
}
async function getStats() {
    const db = await getDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const allEmbeddings = await store.getAll();
    const documentIds = new Set(allEmbeddings.map((e)=>e.documentId));
    await tx.done;
    return {
        totalEmbeddings: allEmbeddings.length,
        totalDocuments: documentIds.size,
        avgEmbeddingsPerDoc: allEmbeddings.length / documentIds.size || 0
    };
}
async function getEmbeddingsTimestamp(documentId) {
    const db = await getDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const index = store.index('documentId');
    const embeddings = await index.getAll(documentId);
    await tx.done;
    if (embeddings.length === 0) return null;
    // Return the most recent timestamp
    return embeddings[0].updatedAt;
}
async function loadEmbeddingsFromS3(s3Key, documentId, metadata = {}) {
    await loadDeps();
    try {
        console.log(`[VectorStoreDB] Loading embeddings from S3: ${s3Key}`);
        // Parse S3 key to extract access level and actual key
        // Format: "protected/us-east-1:identity-id/files/filename.embeddings.json"
        // or "public/files/filename.embeddings.json"
        let accessLevel = 'public';
        let key = s3Key;
        let targetIdentityId;
        if (s3Key.startsWith('protected/')) {
            accessLevel = 'protected';
            // Extract identity ID and key: "protected/us-east-1:xxxx/files/..."
            const parts = s3Key.substring('protected/'.length).split('/');
            targetIdentityId = parts[0]; // "us-east-1:xxxx"
            key = parts.slice(1).join('/'); // "files/filename.embeddings.json"
        } else if (s3Key.startsWith('private/')) {
            accessLevel = 'private';
            const parts = s3Key.substring('private/'.length).split('/');
            targetIdentityId = parts[0];
            key = parts.slice(1).join('/');
        } else if (s3Key.startsWith('public/')) {
            accessLevel = 'public';
            key = s3Key.substring('public/'.length); // Remove "public/" prefix
        }
        console.log(`[VectorStoreDB] Parsed S3 key: accessLevel=${accessLevel}, key=${key}, targetIdentityId=${targetIdentityId}`);
        // Download from S3
        const downloadOptions = {
            key,
            options: {
                accessLevel
            }
        };
        // Add targetIdentityId for protected/private files
        if (targetIdentityId) {
            downloadOptions.options.targetIdentityId = targetIdentityId;
        }
        const downloadResult = await downloadData(downloadOptions).result;
        // Get the blob and convert to ArrayBuffer
        const blob = await downloadResult.body.blob();
        const arrayBuffer = await blob.arrayBuffer();
        const buffer = new Uint8Array(arrayBuffer);
        let embeddingsData;
        // Try to detect if it's Brotli compressed by attempting decompression
        // Brotli files typically start with specific magic bytes
        try {
            // Attempt Brotli decompression
            const decompressed = pako.inflate(buffer, {
                to: 'string'
            });
            embeddingsData = JSON.parse(decompressed);
            console.log('[VectorStoreDB] Successfully decompressed Brotli data');
        } catch (decompressError) {
            // Not compressed or not Brotli, try parsing as JSON directly
            const textDecoder = new TextDecoder('utf-8');
            const jsonString = textDecoder.decode(buffer);
            embeddingsData = JSON.parse(jsonString);
            console.log('[VectorStoreDB] Loaded uncompressed JSON data');
        }
        // Validate embeddings format
        if (!Array.isArray(embeddingsData)) {
            throw new Error('Invalid embeddings format: expected array');
        }
        // Save to IndexedDB
        const count = await saveEmbeddings(documentId, embeddingsData, metadata);
        console.log(`[VectorStoreDB] Loaded ${count} embeddings from S3 and saved to IndexedDB`);
        return count;
    } catch (error) {
        console.error('[VectorStoreDB] Failed to load embeddings from S3:', error);
        throw error;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Cache$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Cache/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$getUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/getUrl.mjs [app-client] (ecmascript)");
;
;
const getCachedUrl = async (filePath)=>{
    if (!filePath) {
        return null;
    }
    // If it's already a data URL or HTTP(S) URL, return it directly
    if (filePath.startsWith('data:') || filePath.startsWith('http://') || filePath.startsWith('https://')) {
        return filePath;
    }
    // Public paths are served directly from CloudFront — no presigning needed.
    // The CDN URL is stable (no expiry), so we skip the Amplify Cache layer too.
    const cdnDomain = ("TURBOPACK compile-time value", "");
    if (cdnDomain && filePath.startsWith('public/')) //TURBOPACK unreachable
    ;
    const cachePath = 'getCachedUrl_' + filePath;
    const cachedFile = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Cache$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Cache"].getItem(cachePath);
    if (cachedFile) {
        return cachedFile;
    } else {
        const expires = new Date().getTime() + 3540000; // 60 minutes
        const _file = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$getUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUrl"])({
            path: filePath
        });
        const _href = _file?.url?.href;
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Cache$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Cache"].setItem(cachePath, _href, {
            expires
        });
        return _href;
    }
};
const __TURBOPACK__default__export__ = getCachedUrl;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/getResponsiveImageUrls.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getImageVariantPath",
    ()=>getImageVariantPath,
    "getResponsiveImageUrls",
    ()=>getResponsiveImageUrls
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
;
/**
 * Image variant sizes generated by the imageProcess Lambda.
 * Maps variant name to pixel width for srcSet descriptors.
 */ const IMAGE_VARIANTS = {
    small: 320,
    medium: 640,
    large: 1280
};
async function getResponsiveImageUrls(fileId, identityId) {
    if (!fileId || !identityId) return null;
    const variantPaths = Object.entries(IMAGE_VARIANTS).map(([name, width])=>({
            name,
            width,
            path: `protected/${identityId}/${fileId}/${name}.webp`
        }));
    try {
        const results = await Promise.allSettled(variantPaths.map(async ({ name, width, path })=>{
            const url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(path);
            return {
                name,
                width,
                url
            };
        }));
        const resolved = results.filter((r)=>r.status === "fulfilled" && r.value.url).map((r)=>r.value);
        if (resolved.length === 0) return null;
        const srcSet = resolved.map((v)=>`${v.url} ${v.width}w`).join(", ");
        // Use largest available as fallback src
        const fallbackSrc = resolved[resolved.length - 1].url;
        const sizes = "(max-width: 320px) 320px, (max-width: 640px) 640px, 1280px";
        return {
            srcSet,
            sizes,
            fallbackSrc
        };
    } catch  {
        return null;
    }
}
function getImageVariantPath(fileId, identityId, variant) {
    return `protected/${identityId}/${fileId}/${variant}.webp`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/hexToRgb.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hexToRgb",
    ()=>hexToRgb
]);
function hexToRgb(hex) {
    const r = parseInt(hex.substring(1, 3), 16);
    const g = parseInt(hex.substring(3, 5), 16);
    const b = parseInt(hex.substring(5, 7), 16);
    return {
        r,
        g,
        b
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/calculateWaveformData.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Calculate waveform amplitude data from an audio blob or buffer.
 * Returns normalized amplitude data that can be stored in the database.
 * 
 * DO NOT MODIFY the algorithm or normalization without testing visual output
 * across different audio sources (recordings, uploaded files, silence).
 *
 * ALGORITHM:
 *   1. Decode audio via AudioContext.decodeAudioData (first channel only).
 *   2. Divide PCM samples into `samples` equal blocks.
 *   3. For each block compute RMS amplitude: sqrt(mean(sample²)).
 *   4. Apply min-max normalization → output in [0, 1].
 *
 * RMS amplitude reflects perceived loudness. Min-max normalization stretches
 * the data to fill the full 0-1 range, producing visible waveform variation
 * even for AGC-compressed microphone recordings where absolute amplitude
 * is nearly constant across blocks.
 *
 * @param {Blob|ArrayBuffer} audioSource - Audio blob or array buffer
 * @param {number} samples - Number of data points to generate (default: 600)
 * @returns {Promise<number[]>} Array of normalized amplitude values (0-1)
 */ __turbopack_context__.s([
    "calculateWaveformData",
    ()=>calculateWaveformData,
    "calculateWaveformDataWithDuration",
    ()=>calculateWaveformDataWithDuration
]);
async function calculateWaveformData(audioSource, samples = 600) {
    try {
        // Convert blob to array buffer if needed
        let arrayBuffer;
        if (audioSource instanceof Blob) {
            arrayBuffer = await audioSource.arrayBuffer();
        } else {
            arrayBuffer = audioSource;
        }
        // Create audio context and decode
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
        // Get the raw audio data (use first channel if stereo)
        const rawData = audioBuffer.getChannelData(0);
        const blockSize = Math.floor(rawData.length / samples);
        const filteredData = [];
        // Downsample using RMS amplitude per block
        // RMS produces visible variation even when AGC keeps peak levels flat
        for(let i = 0; i < samples; i++){
            const blockStart = blockSize * i;
            let sumSq = 0;
            for(let j = 0; j < blockSize; j++){
                const val = rawData[blockStart + j];
                sumSq += val * val;
            }
            filteredData.push(Math.sqrt(sumSq / blockSize));
        }
        // Min-max normalization to 0-1 range
        // This stretches the data to fill the full visual range, so even
        // AGC-compressed recordings with narrow absolute amplitude show
        // meaningful waveform shape
        const minAmplitude = Math.min(...filteredData);
        const maxAmplitude = Math.max(...filteredData);
        const range = maxAmplitude - minAmplitude;
        let normalizedData;
        if (range > 0) {
            normalizedData = filteredData.map((n)=>(n - minAmplitude) / range);
        } else if (maxAmplitude > 0) {
            // All values identical but non-zero — show flat at 0.5
            normalizedData = filteredData.map(()=>0.5);
        } else {
            // All silence
            normalizedData = filteredData;
        }
        // Clean up
        audioContext.close();
        return normalizedData;
    } catch (error) {
        console.error('Error calculating waveform data:', error);
        throw error;
    }
}
async function calculateWaveformDataWithDuration(audioSource, samples = 600) {
    let arrayBuffer;
    if (audioSource instanceof Blob) {
        arrayBuffer = await audioSource.arrayBuffer();
    } else {
        arrayBuffer = audioSource;
    }
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
    const duration = audioBuffer.duration;
    const rawData = audioBuffer.getChannelData(0);
    const blockSize = Math.floor(rawData.length / samples);
    const filteredData = [];
    for(let i = 0; i < samples; i++){
        const blockStart = blockSize * i;
        let sumSq = 0;
        for(let j = 0; j < blockSize; j++){
            const val = rawData[blockStart + j];
            sumSq += val * val;
        }
        filteredData.push(Math.sqrt(sumSq / blockSize));
    }
    const minAmplitude = Math.min(...filteredData);
    const maxAmplitude = Math.max(...filteredData);
    const range = maxAmplitude - minAmplitude;
    let normalizedData;
    if (range > 0) {
        normalizedData = filteredData.map((n)=>(n - minAmplitude) / range);
    } else if (maxAmplitude > 0) {
        normalizedData = filteredData.map(()=>0.5);
    } else {
        normalizedData = filteredData;
    }
    audioContext.close();
    return {
        waveformData: normalizedData,
        duration
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/audioLevelMonitor.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Audio level monitoring utility for detecting microphone input levels.
 *
 * Provides RMS and peak level calculation from an AnalyserNode,
 * with configurable thresholds for "too low" detection.
 *
 * Usage:
 *   const monitor = createAudioLevelMonitor(analyserNode, { onLevel });
 *   monitor.start();
 *   // later...
 *   monitor.stop();
 */ /**
 * @typedef {Object} AudioLevelData
 * @property {number} rms - Root mean square level (0–1, where 1 = max amplitude)
 * @property {number} peak - Peak sample value (0–1)
 * @property {number} db - RMS level in decibels (approx –100 to 0)
 * @property {boolean} tooLow - True when the level is below the configured threshold
 * @property {boolean} silent - True when effectively no signal is detected
 */ /**
 * @typedef {Object} AudioLevelMonitorOptions
 * @property {number} [lowThresholdDb=-50] - dB level below which audio is "too low"
 * @property {number} [silenceThresholdDb=-70] - dB level below which audio is "silent"
 * @property {number} [intervalMs=100] - How often to sample levels (ms)
 * @property {(data: AudioLevelData) => void} onLevel - Callback fired each interval
 */ /**
 * Create an audio level monitor attached to an existing AnalyserNode.
 *
 * @param {AnalyserNode} analyser - Web Audio AnalyserNode already connected to a source.
 * @param {AudioLevelMonitorOptions} options
 * @returns {{ start: () => void, stop: () => void, getLevel: () => AudioLevelData }}
 */ __turbopack_context__.s([
    "createAudioLevelMonitor",
    ()=>createAudioLevelMonitor,
    "rmsToPercent",
    ()=>rmsToPercent
]);
function createAudioLevelMonitor(analyser, options = {}) {
    const { lowThresholdDb = -50, silenceThresholdDb = -70, intervalMs = 100, onLevel } = options;
    let rafId = null;
    let lastSample = 0;
    let running = false;
    // Use time-domain data for accurate RMS calculation
    const bufferLength = analyser.fftSize;
    const dataArray = new Float32Array(bufferLength);
    /** Calculate current level from the analyser */ function sampleLevel() {
        analyser.getFloatTimeDomainData(dataArray);
        let sumSquares = 0;
        let peak = 0;
        for(let i = 0; i < bufferLength; i++){
            const sample = dataArray[i];
            sumSquares += sample * sample;
            const abs = Math.abs(sample);
            if (abs > peak) peak = abs;
        }
        const rms = Math.sqrt(sumSquares / bufferLength);
        // Convert to dB (avoid log(0))
        const db = rms > 0 ? 20 * Math.log10(rms) : -100;
        return {
            rms,
            peak,
            db,
            tooLow: db < lowThresholdDb,
            silent: db < silenceThresholdDb
        };
    }
    /** Animation-frame loop throttled to intervalMs */ function tick(timestamp) {
        if (!running) return;
        if (timestamp - lastSample >= intervalMs) {
            lastSample = timestamp;
            const level = sampleLevel();
            if (onLevel) onLevel(level);
        }
        rafId = requestAnimationFrame(tick);
    }
    function start() {
        if (running) return;
        running = true;
        lastSample = 0;
        rafId = requestAnimationFrame(tick);
    }
    function stop() {
        running = false;
        if (rafId !== null) {
            cancelAnimationFrame(rafId);
            rafId = null;
        }
    }
    return {
        start,
        stop,
        getLevel: sampleLevel
    };
}
function rmsToPercent(rms, floor = -60) {
    if (rms <= 0) return 0;
    const db = 20 * Math.log10(rms);
    if (db <= floor) return 0;
    // Linear mapping from floor..0 dB → 0..100 %
    return Math.min(100, (db - floor) / -floor * 100);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/userSubmissionStorage.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildSubmissionKey",
    ()=>buildSubmissionKey,
    "deleteStudentSubmission",
    ()=>deleteStudentSubmission,
    "getGradeSubmissionsPrefix",
    ()=>getGradeSubmissionsPrefix,
    "getQuestionSubmissionsPrefix",
    ()=>getQuestionSubmissionsPrefix,
    "parseSubmissionKey",
    ()=>parseSubmissionKey,
    "uploadStudentSubmission",
    ()=>uploadStudentSubmission,
    "validateSubmissionOwnership",
    ()=>validateSubmissionOwnership
]);
/**
 * User Submission Storage Utility (Amplify Gen 2)
 * 
 * Handles storage of student-submitted content (audio recordings, drawings, etc.)
 * with strict privacy controls and cost tracking separation.
 * 
 * Key Features:
 * - Uses PRIVATE access level (only owner can access directly)
 * - Gen 2 pattern: private/{userId}/user-submissions/{gradeId}/{nodeKey}/{filename}
 * - Separate from other File storage for cost tracking
 * - Teachers access via special backend endpoint that validates permissions
 * 
 * Gen 2 Notes:
 * - Uses `path` parameter with full S3 path including protection level prefix
 * - No `accessLevel` or `identityId` options needed (encoded in path)
 * - Returns result.path (not result.key) for uploaded files
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/client/apis/uploadData.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/remove.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$getCurrentUser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/auth/dist/esm/providers/cognito/apis/getCurrentUser.mjs [app-client] (ecmascript)");
;
;
async function uploadStudentSubmission({ file, gradeId, nodeKey, fileType, metadata = {} }) {
    try {
        const timestamp = Date.now();
        const filename = `${gradeId}_${nodeKey}_${timestamp}.${fileType}`;
        // Get current user for metadata and path
        const { userId, username } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$getCurrentUser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCurrentUser"])();
        // Gen 2 API: private files use private/{identityId}/* pattern
        // Note: identityId is automatically added by Amplify when accessing private storage
        const s3Path = `private/${userId}/user-submissions/${gradeId}/${nodeKey}/${filename}`;
        console.log(`[UserSubmission] Uploading to: ${s3Path}`);
        // Upload with Gen 2 API (no accessLevel option needed - it's in the path)
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
            path: s3Path,
            data: file,
            options: {
                contentType: file.type
            }
        }).result;
        console.log(`[UserSubmission] Upload successful: ${result.path}`);
        return {
            path: result.path,
            filename,
            gradeId,
            nodeKey,
            uploadedAt: timestamp,
            metadata: {
                userId,
                username,
                uploadedBy: username,
                uploadedAt: new Date().toISOString(),
                ...metadata
            }
        };
    } catch (error) {
        console.error('[UserSubmission] Upload failed:', error);
        throw new Error(`Failed to upload student submission: ${error.message}`);
    }
}
async function deleteStudentSubmission(path) {
    try {
        console.log(`[UserSubmission] Deleting: ${path}`);
        // Gen 2 API: use path directly, no accessLevel option
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["remove"])({
            path
        });
        console.log(`[UserSubmission] Delete successful: ${path}`);
    } catch (error) {
        console.error('[UserSubmission] Delete failed:', error);
        throw new Error(`Failed to delete student submission: ${error.message}`);
    }
}
function parseSubmissionKey(key) {
    const parts = key.split('/');
    if (parts[0] !== 'user-submissions' || parts.length !== 4) {
        throw new Error('Invalid submission key format');
    }
    const [, gradeId, nodeKey, filename] = parts;
    const filenameParts = filename.split('_');
    const timestamp = parseInt(filenameParts[2]?.split('.')[0]);
    const extension = filename.split('.').pop();
    return {
        gradeId,
        nodeKey,
        filename,
        timestamp,
        extension,
        isValid: gradeId && nodeKey && !isNaN(timestamp)
    };
}
function buildSubmissionKey({ gradeId, nodeKey, filename }) {
    return `user-submissions/${gradeId}/${nodeKey}/${filename}`;
}
function getGradeSubmissionsPrefix(gradeId) {
    return `user-submissions/${gradeId}/`;
}
function getQuestionSubmissionsPrefix(gradeId, nodeKey) {
    return `user-submissions/${gradeId}/${nodeKey}/`;
}
async function validateSubmissionOwnership(identityId) {
    try {
        const { userId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$getCurrentUser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCurrentUser"])();
        return userId === identityId;
    } catch (error) {
        console.error('[UserSubmission] Ownership validation failed:', error);
        return false;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/applyAudioFilters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @fileoverview Core audio filter chain utility for RecordingStudio3
 *
 * Applies a set of named audio filters to an AudioBuffer using an
 * OfflineAudioContext. Used by both the filter panel (listen-side) and
 * pre-submission cleanup (record-side).
 *
 * Chain order: highpass (de-rumble) → highpass (pop) → RNNoise worklet
 * (noise cancel) → compressor → peaking EQ (presence) → normalize → destination
 */ __turbopack_context__.s([
    "applyAudioFilters",
    ()=>applyAudioFilters
]);
async function applyAudioFilters(buffer, activeFilters) {
    if (activeFilters.size === 0) return buffer;
    const { numberOfChannels, length, sampleRate } = buffer;
    const offlineCtx = new OfflineAudioContext(numberOfChannels, length, sampleRate);
    // Source node
    const source = offlineCtx.createBufferSource();
    source.buffer = buffer;
    // Build the node chain
    let currentNode = source;
    // 1. De-rumble — highpass @ 80 Hz
    if (activeFilters.has('derumble')) {
        const hp = offlineCtx.createBiquadFilter();
        hp.type = 'highpass';
        hp.frequency.value = 80;
        hp.Q.value = 0.7;
        currentNode.connect(hp);
        currentNode = hp;
    }
    // 2. Pop filter — highpass @ 120 Hz + fast compressor
    if (activeFilters.has('pop')) {
        const hp = offlineCtx.createBiquadFilter();
        hp.type = 'highpass';
        hp.frequency.value = 120;
        hp.Q.value = 1.2;
        currentNode.connect(hp);
        currentNode = hp;
        const comp = offlineCtx.createDynamicsCompressor();
        comp.threshold.value = -30;
        comp.ratio.value = 8;
        comp.attack.value = 0.003;
        comp.release.value = 0.1;
        currentNode.connect(comp);
        currentNode = comp;
    }
    // 3. Noise cancel — RNNoise via AudioWorklet
    if (activeFilters.has('noisecancel')) {
        try {
            await offlineCtx.audioWorklet.addModule('/workers/rnnoise-worklet.js');
            const rnnoiseNode = new AudioWorkletNode(offlineCtx, 'rnnoise-processor');
            currentNode.connect(rnnoiseNode);
            currentNode = rnnoiseNode;
        } catch (err) {
            // Fallback: skip RNNoise if AudioWorklet is unavailable or WASM fails to load
            console.warn('[applyAudioFilters] RNNoise unavailable, skipping noise cancel:', err);
        }
    }
    // 4. Compress — dynamics compressor
    if (activeFilters.has('compress')) {
        const comp = offlineCtx.createDynamicsCompressor();
        comp.threshold.value = -24;
        comp.knee.value = 10;
        comp.ratio.value = 4;
        comp.attack.value = 0.005;
        comp.release.value = 0.1;
        currentNode.connect(comp);
        currentNode = comp;
    }
    // 5. Presence — peaking EQ @ 3 kHz
    if (activeFilters.has('presence')) {
        const eq = offlineCtx.createBiquadFilter();
        eq.type = 'peaking';
        eq.frequency.value = 3000;
        eq.Q.value = 1.5;
        eq.gain.value = 3;
        currentNode.connect(eq);
        currentNode = eq;
    }
    // Connect final node to destination
    currentNode.connect(offlineCtx.destination);
    // Render
    source.start(0);
    const renderedBuffer = await offlineCtx.startRendering();
    // 6. Normalize to -3 dBFS peak (post-render, in-place)
    if (activeFilters.has('normalize')) {
        return normalizeBuffer(renderedBuffer, -3);
    }
    return renderedBuffer;
}
/**
 * Normalize an AudioBuffer to a target peak level in dBFS.
 * Modifies channel data in-place and returns the same buffer.
 */ function normalizeBuffer(buffer, targetDbfs) {
    const targetAmplitude = Math.pow(10, targetDbfs / 20);
    // Find current peak across all channels
    let peak = 0;
    for(let ch = 0; ch < buffer.numberOfChannels; ch++){
        const data = buffer.getChannelData(ch);
        for(let i = 0; i < data.length; i++){
            const abs = Math.abs(data[i]);
            if (abs > peak) peak = abs;
        }
    }
    if (peak === 0) return buffer; // Silent audio — nothing to normalize
    const gain = targetAmplitude / peak;
    // Apply gain to all channels
    for(let ch = 0; ch < buffer.numberOfChannels; ch++){
        const data = buffer.getChannelData(ch);
        for(let i = 0; i < data.length; i++){
            data[i] *= gain;
        }
    }
    return buffer;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/audioBufferToBlob.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @fileoverview WAV encoder utility for RecordingStudio3
 *
 * Converts an AudioBuffer to a WAV Blob. WAV is trivially encodable
 * (no external dependencies) and lossless. The resulting blob is typically
 * re-encoded downstream by MediaConvert or the browser's MediaRecorder.
 */ /**
 * Encode an AudioBuffer as a WAV or WebM Blob.
 *
 * For 'audio/wav': Writes raw PCM into a WAV container (lossless, no deps).
 * For 'audio/webm': Uses MediaRecorder on an AudioContext to encode (lossy).
 *
 * @param buffer - The AudioBuffer to encode
 * @param mimeType - Target MIME type
 * @returns Encoded Blob
 */ __turbopack_context__.s([
    "audioBufferToBlob",
    ()=>audioBufferToBlob
]);
async function audioBufferToBlob(buffer, mimeType = 'audio/wav') {
    if (mimeType === 'audio/wav') {
        return encodeWav(buffer);
    }
    // WebM via MediaRecorder
    return encodeViaMediaRecorder(buffer, mimeType);
}
/**
 * Encode AudioBuffer as WAV (PCM 16-bit).
 * Pure function — no browser APIs other than ArrayBuffer/DataView.
 */ function encodeWav(buffer) {
    const numChannels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    const bitsPerSample = 16;
    const bytesPerSample = bitsPerSample / 8;
    const blockAlign = numChannels * bytesPerSample;
    const numFrames = buffer.length;
    const dataSize = numFrames * blockAlign;
    // WAV header is 44 bytes
    const headerSize = 44;
    const arrayBuffer = new ArrayBuffer(headerSize + dataSize);
    const view = new DataView(arrayBuffer);
    // RIFF header
    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + dataSize, true); // file size - 8
    writeString(view, 8, 'WAVE');
    // fmt sub-chunk
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true); // sub-chunk size (PCM = 16)
    view.setUint16(20, 1, true); // audio format (PCM = 1)
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * blockAlign, true); // byte rate
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitsPerSample, true);
    // data sub-chunk
    writeString(view, 36, 'data');
    view.setUint32(40, dataSize, true);
    // Interleave channels and write 16-bit PCM samples
    const channels = [];
    for(let ch = 0; ch < numChannels; ch++){
        channels.push(buffer.getChannelData(ch));
    }
    let offset = headerSize;
    for(let i = 0; i < numFrames; i++){
        for(let ch = 0; ch < numChannels; ch++){
            // Clamp to [-1, 1] and convert to 16-bit integer
            const sample = Math.max(-1, Math.min(1, channels[ch][i]));
            const int16 = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
            view.setInt16(offset, int16, true);
            offset += 2;
        }
    }
    return new Blob([
        arrayBuffer
    ], {
        type: 'audio/wav'
    });
}
/** Write an ASCII string into a DataView at the given offset. */ function writeString(view, offset, str) {
    for(let i = 0; i < str.length; i++){
        view.setUint8(offset + i, str.charCodeAt(i));
    }
}
/**
 * Encode AudioBuffer via MediaRecorder (for WebM or other supported formats).
 * Creates a temporary AudioContext, plays the buffer through it, and records.
 */ async function encodeViaMediaRecorder(buffer, mimeType) {
    const ctx = new AudioContext({
        sampleRate: buffer.sampleRate
    });
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    const dest = ctx.createMediaStreamDestination();
    source.connect(dest);
    const recorder = new MediaRecorder(dest.stream, {
        mimeType
    });
    const chunks = [];
    return new Promise((resolve, reject)=>{
        recorder.ondataavailable = (e)=>{
            if (e.data.size > 0) chunks.push(e.data);
        };
        recorder.onstop = ()=>{
            ctx.close();
            resolve(new Blob(chunks, {
                type: mimeType
            }));
        };
        recorder.onerror = (e)=>{
            ctx.close();
            reject(e);
        };
        recorder.start();
        source.start(0);
        // Stop recording after buffer duration + small margin
        const durationMs = buffer.length / buffer.sampleRate * 1000 + 100;
        setTimeout(()=>{
            recorder.stop();
            source.stop();
        }, durationMs);
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/vocabularyImportUtils.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createWord",
    ()=>createWord,
    "findExistingWord",
    ()=>findExistingWord,
    "getVocabularyImportStatus",
    ()=>getVocabularyImportStatus,
    "importVocabularyToUnit",
    ()=>importVocabularyToUnit,
    "linkWordToUnit",
    ()=>linkWordToUnit,
    "updateVocabularyItem",
    ()=>updateVocabularyItem
]);
/**
 * @fileoverview Utilities for importing vocabulary from ParsedContent to Word dictionary
 * Handles duplicate detection, Word creation, and Unit linking
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
;
async function findExistingWord(phrase, owner) {
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
    const normalizedPhrase = phrase.trim().toLowerCase();
    const { data: existingWords } = await client.models.Word.list({
        filter: {
            phrase: {
                eq: phrase
            }
        }
    });
    // Filter by owner or find closest match
    const exactMatch = existingWords?.find((w)=>w.phrase.trim().toLowerCase() === normalizedPhrase);
    return exactMatch || null;
}
async function createWord(vocabularyItem, owner, identityId) {
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
    const { word, definition, context, page } = vocabularyItem;
    const { data: newWord } = await client.models.Word.create({
        phrase: word,
        definition: definition,
        owner: owner,
        identityId: identityId
    });
    return newWord;
}
async function linkWordToUnit(wordId, unitId, owner) {
    // Check if relationship already exists
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
    // Check if relationship already exists
    const { data: existing } = await client.models.UnitWord.list({
        filter: {
            and: [
                {
                    wordID: {
                        eq: wordId
                    }
                },
                {
                    unitID: {
                        eq: unitId
                    }
                }
            ]
        }
    });
    if (existing && existing.length > 0) {
        console.log(`Word ${wordId} already linked to Unit ${unitId}`);
        return existing[0];
    }
    const { data: unitWord } = await client.models.UnitWord.create({
        wordID: wordId,
        unitID: unitId,
        owner: owner
    });
    return unitWord;
}
async function importVocabularyToUnit(parsedContentId, unitId, selectedIndices = null, owner, identityId, onProgress = null) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        // Fetch the ParsedContent record
        const { data: parsedContent } = await client.models.ParsedContent.get({
            id: parsedContentId
        });
        if (!parsedContent) {
            throw new Error(`ParsedContent not found: ${parsedContentId}`);
        }
        // Parse the vocabularyJSON
        const vocabularyItems = parsedContent.vocabularyJSON ? JSON.parse(parsedContent.vocabularyJSON) : [];
        if (vocabularyItems.length === 0) {
            return {
                success: true,
                imported: 0,
                skipped: 0,
                errors: 0,
                message: 'No vocabulary items to import'
            };
        }
        // Filter items if specific indices are selected
        const itemsToImport = selectedIndices ? vocabularyItems.filter((_, index)=>selectedIndices.includes(index)) : vocabularyItems;
        const results = {
            success: true,
            imported: 0,
            skipped: 0,
            errors: 0,
            errorDetails: [],
            importedWords: []
        };
        const total = itemsToImport.length;
        // Process each vocabulary item
        for(let i = 0; i < itemsToImport.length; i++){
            const item = itemsToImport[i];
            if (onProgress) {
                onProgress(i + 1, total, `Processing: ${item.word}`);
            }
            try {
                // Check for existing word
                const existingWord = await findExistingWord(item.word, owner);
                let wordToLink;
                if (existingWord) {
                    // Word already exists, just link to unit
                    wordToLink = existingWord;
                    console.log(`Word already exists: ${item.word}`);
                    results.skipped++;
                } else {
                    // Create new word
                    wordToLink = await createWord(item, owner, identityId);
                    console.log(`Created new word: ${item.word}`);
                    results.imported++;
                }
                // Link word to unit
                if (unitId) {
                    await linkWordToUnit(wordToLink.id, unitId, owner);
                }
                results.importedWords.push({
                    wordId: wordToLink.id,
                    phrase: wordToLink.phrase,
                    isNew: !existingWord
                });
            } catch (error) {
                console.error(`Error importing word "${item.word}":`, error);
                results.errors++;
                results.errorDetails.push({
                    word: item.word,
                    error: error.message
                });
            }
        }
        // Mark ParsedContent as imported
        if (parsedContent) {
            await client.models.ParsedContent.update({
                id: parsedContent.id,
                approved: true,
                importedAt: new Date().toISOString()
            });
        }
        if (onProgress) {
            onProgress(total, total, `Import complete: ${results.imported} new, ${results.skipped} existing, ${results.errors} errors`);
        }
        return results;
    } catch (error) {
        console.error('Error in importVocabularyToUnit:', error);
        return {
            success: false,
            imported: 0,
            skipped: 0,
            errors: 1,
            errorDetails: [
                {
                    error: error.message
                }
            ],
            message: `Import failed: ${error.message}`
        };
    }
}
async function getVocabularyImportStatus(parsedContentId) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: parsedContent } = await client.models.ParsedContent.get({
            id: parsedContentId
        });
        if (!parsedContent) {
            return {
                found: false,
                imported: false,
                itemCount: 0
            };
        }
        const vocabularyItems = parsedContent.vocabularyJSON ? JSON.parse(parsedContent.vocabularyJSON) : [];
        return {
            found: true,
            imported: !!parsedContent.importedAt,
            approved: !!parsedContent.approved,
            importedAt: parsedContent.importedAt,
            itemCount: vocabularyItems.length,
            vocabularyItems: vocabularyItems
        };
    } catch (error) {
        console.error('Error getting import status:', error);
        return {
            found: false,
            error: error.message
        };
    }
}
async function updateVocabularyItem(parsedContentId, itemIndex, updates) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: parsedContent } = await client.models.ParsedContent.get({
            id: parsedContentId
        });
        if (!parsedContent) {
            throw new Error(`ParsedContent not found: ${parsedContentId}`);
        }
        const vocabularyItems = parsedContent.vocabularyJSON ? JSON.parse(parsedContent.vocabularyJSON) : [];
        if (itemIndex < 0 || itemIndex >= vocabularyItems.length) {
            throw new Error(`Invalid item index: ${itemIndex}`);
        }
        // Update the item
        vocabularyItems[itemIndex] = {
            ...vocabularyItems[itemIndex],
            ...updates
        };
        // Save updated ParsedContent
        await client.models.ParsedContent.update({
            id: parsedContent.id,
            vocabularyJSON: JSON.stringify(vocabularyItems)
        });
        return true;
    } catch (error) {
        console.error('Error updating vocabulary item:', error);
        return false;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/questionImportUtils.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createQuestion",
    ()=>createQuestion,
    "findExistingQuestion",
    ()=>findExistingQuestion,
    "importQuestionsToUnit",
    ()=>importQuestionsToUnit,
    "linkQuestionToDocument",
    ()=>linkQuestionToDocument,
    "linkQuestionToUnit",
    ()=>linkQuestionToUnit,
    "updateQuestionItem",
    ()=>updateQuestionItem
]);
/**
 * @fileoverview Utilities for importing questions from ParsedContent to Question bank
 * Handles duplicate detection, Question creation, and Unit/Document linking
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
;
async function findExistingQuestion(prompt, owner) {
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
    const normalizedPrompt = prompt.trim().toLowerCase();
    // Search by prompt text (exact match)
    const { data: existingQuestions } = await client.models.Question.list({
        filter: {
            prompt: {
                eq: prompt.trim()
            }
        }
    });
    const exactMatch = existingQuestions?.find((q)=>q.prompt?.trim().toLowerCase() === normalizedPrompt);
    return exactMatch || null;
}
async function createQuestion(questionItem, owner, identityId) {
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
    const { prompt, question, answer, expectedAnswer, hint, options, questionType, type, difficulty } = questionItem;
    // Normalize field names (ParsedContent uses different names than Question model)
    const questionPrompt = prompt || question || "";
    const questionAnswer = answer || expectedAnswer || "";
    const questionHint = hint || undefined;
    const resolvedDifficulty = difficulty || "medium";
    // Build choices array if options exist
    let choices = null;
    if (options && Array.isArray(options) && options.length > 0) {
        choices = options.map((opt)=>({
                choice: typeof opt === "string" ? opt : opt.text || opt.choice || String(opt),
                correct: typeof opt === "string" ? opt.toLowerCase() === questionAnswer.toLowerCase() : opt.correct || false
            }));
    }
    const { data: newQuestion } = await client.models.Question.create({
        prompt: questionPrompt,
        answer: questionAnswer,
        hint: questionHint,
        choices: choices ? JSON.stringify(choices) : null,
        difficulty: resolvedDifficulty,
        generated: true,
        importedAt: new Date().toISOString(),
        owner: owner,
        identityId: identityId
    });
    return newQuestion;
}
async function linkQuestionToUnit(questionId, unitId, owner) {
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
    // Check if relationship already exists
    const { data: existing } = await client.models.QuestionUnit.list({
        filter: {
            and: [
                {
                    questionID: {
                        eq: questionId
                    }
                },
                {
                    unitID: {
                        eq: unitId
                    }
                }
            ]
        }
    });
    if (existing && existing.length > 0) {
        console.log(`Question ${questionId} already linked to Unit ${unitId}`);
        return existing[0];
    }
    const { data: questionUnit } = await client.models.QuestionUnit.create({
        questionID: questionId,
        unitID: unitId,
        owner: owner
    });
    return questionUnit;
}
async function linkQuestionToDocument(questionId, documentId, owner) {
    if (!documentId) return null;
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
    const { data: existing } = await client.models.DocumentQuestion.list({
        filter: {
            and: [
                {
                    questionID: {
                        eq: questionId
                    }
                },
                {
                    documentID: {
                        eq: documentId
                    }
                }
            ]
        }
    });
    if (existing && existing.length > 0) {
        return existing[0];
    }
    const { data: docQuestion } = await client.models.DocumentQuestion.create({
        questionID: questionId,
        documentID: documentId,
        owner: owner
    });
    return docQuestion;
}
async function importQuestionsToUnit(parsedContentId, unitId, selectedIndices = null, owner, identityId, onProgress = null) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        // Fetch the ParsedContent record
        const { data: parsedContent } = await client.models.ParsedContent.get({
            id: parsedContentId
        });
        if (!parsedContent) {
            throw new Error(`ParsedContent not found: ${parsedContentId}`);
        }
        // Parse the questionsJSON
        const questionItems = parsedContent.questionsJSON ? typeof parsedContent.questionsJSON === "string" ? JSON.parse(parsedContent.questionsJSON) : parsedContent.questionsJSON : [];
        if (questionItems.length === 0) {
            return {
                success: true,
                imported: 0,
                skipped: 0,
                errors: 0,
                message: "No questions to import"
            };
        }
        // Filter items if specific indices are selected
        const itemsToImport = selectedIndices ? questionItems.filter((_, index)=>selectedIndices.includes(index)) : questionItems;
        const results = {
            success: true,
            imported: 0,
            skipped: 0,
            errors: 0,
            errorDetails: [],
            importedQuestions: []
        };
        const total = itemsToImport.length;
        // Get associated documentID if available
        const documentId = parsedContent.documentID || null;
        // Process each question item
        for(let i = 0; i < itemsToImport.length; i++){
            const item = itemsToImport[i];
            const promptText = item.prompt || item.question || "";
            if (onProgress) {
                onProgress(i + 1, total, `Processing: ${promptText.slice(0, 50)}...`);
            }
            if (!promptText) {
                results.errors++;
                results.errorDetails.push({
                    question: `(index ${i})`,
                    error: "Empty prompt"
                });
                continue;
            }
            try {
                // Check for existing question
                const existingQuestion = await findExistingQuestion(promptText, owner);
                let questionToLink;
                if (existingQuestion) {
                    // Question already exists, just link to unit
                    questionToLink = existingQuestion;
                    console.log(`Question already exists: ${promptText.slice(0, 40)}...`);
                    results.skipped++;
                } else {
                    // Create new question
                    questionToLink = await createQuestion(item, owner, identityId);
                    console.log(`Created new question: ${promptText.slice(0, 40)}...`);
                    results.imported++;
                }
                // Link question to unit
                if (unitId && questionToLink) {
                    await linkQuestionToUnit(questionToLink.id, unitId, owner);
                }
                // Link question to source document
                if (documentId && questionToLink) {
                    await linkQuestionToDocument(questionToLink.id, documentId, owner);
                }
                results.importedQuestions.push({
                    questionId: questionToLink.id,
                    prompt: questionToLink.prompt,
                    isNew: !existingQuestion
                });
            } catch (error) {
                console.error(`Error importing question "${promptText.slice(0, 40)}":`, error);
                results.errors++;
                results.errorDetails.push({
                    question: promptText.slice(0, 60),
                    error: error.message
                });
            }
        }
        // Mark ParsedContent questions as imported
        if (parsedContent) {
            await client.models.ParsedContent.update({
                id: parsedContent.id,
                importedAt: new Date().toISOString(),
                _version: parsedContent._version
            });
        }
        if (onProgress) {
            onProgress(total, total, `Import complete: ${results.imported} new, ${results.skipped} existing, ${results.errors} errors`);
        }
        return results;
    } catch (error) {
        console.error("Error in importQuestionsToUnit:", error);
        return {
            success: false,
            imported: 0,
            skipped: 0,
            errors: 1,
            errorDetails: [
                {
                    error: error.message
                }
            ],
            message: `Import failed: ${error.message}`
        };
    }
}
async function updateQuestionItem(parsedContentId, itemIndex, updates) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: parsedContent } = await client.models.ParsedContent.get({
            id: parsedContentId
        });
        if (!parsedContent) {
            throw new Error(`ParsedContent not found: ${parsedContentId}`);
        }
        const questionItems = parsedContent.questionsJSON ? typeof parsedContent.questionsJSON === "string" ? JSON.parse(parsedContent.questionsJSON) : parsedContent.questionsJSON : [];
        if (itemIndex < 0 || itemIndex >= questionItems.length) {
            throw new Error(`Invalid item index: ${itemIndex}`);
        }
        // Update the item
        questionItems[itemIndex] = {
            ...questionItems[itemIndex],
            ...updates
        };
        // Save updated ParsedContent
        await client.models.ParsedContent.update({
            id: parsedContent.id,
            questionsJSON: JSON.stringify(questionItems),
            _version: parsedContent._version
        });
        return true;
    } catch (error) {
        console.error("Error updating question item:", error);
        return false;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/takeVersioning.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildVersionedKey",
    ()=>buildVersionedKey,
    "listTakeVersions",
    ()=>listTakeVersions,
    "parseVersionFromKey",
    ()=>parseVersionFromKey
]);
/**
 * @fileoverview Take versioning utilities for RecordingStudio3
 *
 * Helpers for building versioned S3 keys, parsing version numbers from keys,
 * and listing all versions of a take slot via Amplify Storage.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/list.mjs [app-client] (ecmascript)");
;
function buildVersionedKey(identityId, dialogueId, slotId, version, ext) {
    return `protected/${identityId}/takes/${dialogueId}-${slotId}_${version}.${ext}`;
}
function parseVersionFromKey(key) {
    const filename = key.split('/').pop();
    if (!filename) return null;
    // Match `_{digits}.{ext}` at the end
    const match = filename.match(/_(\d+)\.[^.]+$/);
    if (!match) return null;
    const version = parseInt(match[1], 10);
    return isNaN(version) ? null : version;
}
async function listTakeVersions(identityId, dialogueId, slotId) {
    const prefix = `protected/${identityId}/takes/${dialogueId}-${slotId}_`;
    const { items } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["list"])({
        path: prefix,
        options: {
            listAll: true
        }
    });
    const versions = [];
    for (const item of items){
        const version = parseVersionFromKey(item.path);
        if (version !== null) {
            versions.push({
                version,
                key: item.path,
                lastModified: item.lastModified,
                size: item.size
            });
        }
    }
    // Sort ascending by version number
    versions.sort((a, b)=>a.version - b.version);
    return versions;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/processAndUploadTake.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getProcessedPath",
    ()=>getProcessedPath,
    "processAndUploadTake",
    ()=>processAndUploadTake
]);
/**
 * @fileoverview Non-destructive audio processing for RecordingStudio3
 *
 * Applies audio filters to a raw recording and uploads the processed result
 * alongside the original. The raw file is never modified — only a processed
 * sibling is created/overwritten. This allows re-encoding with different
 * settings at any time.
 *
 * S3 path convention:
 *   Raw:       protected/{identityId}/takes/{dialogueId}-{slotId}_{version}.webm
 *   Processed: protected/{identityId}/takes/{dialogueId}-{slotId}_{version}_processed.wav
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/client/apis/uploadData.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$getUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/getUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$applyAudioFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/applyAudioFilters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$audioBufferToBlob$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/audioBufferToBlob.ts [app-client] (ecmascript)");
;
;
;
function getProcessedPath(rawPath) {
    // Remove extension and append _processed.wav
    const lastDot = rawPath.lastIndexOf(".");
    if (lastDot === -1) return `${rawPath}_processed.wav`;
    return `${rawPath.slice(0, lastDot)}_processed.wav`;
}
async function processAndUploadTake(rawPath, filters, options = {}) {
    const filterSet = filters instanceof Set ? filters : new Set(filters);
    // If no filters, there's nothing to process
    if (filterSet.size === 0) {
        return {
            processedPath: null,
            size: 0
        };
    }
    // Fetch the raw audio from S3
    const { url } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$getUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUrl"])({
        path: rawPath
    });
    const response = await fetch(url.toString());
    if (!response.ok) {
        throw new Error(`Failed to fetch raw audio: ${response.status}`);
    }
    const arrayBuffer = await response.arrayBuffer();
    // Decode to AudioBuffer
    const audioCtx = new OfflineAudioContext(1, 1, 44100);
    const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
    // Apply filters
    const processedBuffer = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$applyAudioFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyAudioFilters"])(audioBuffer, filterSet);
    // Encode to WAV blob
    const processedBlob = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$audioBufferToBlob$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["audioBufferToBlob"])(processedBuffer, "audio/wav");
    // Upload processed file alongside raw
    const outputPath = options.processedPath || getProcessedPath(rawPath);
    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
        path: outputPath,
        data: processedBlob,
        options: {
            contentType: "audio/wav"
        }
    }).result;
    return {
        processedPath: result.path,
        size: processedBlob.size
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/recordingStudioPresets.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createConversationPreset",
    ()=>createConversationPreset,
    "createQuestionPreset",
    ()=>createQuestionPreset,
    "createWordPreset",
    ()=>createWordPreset
]);
/**
 * @fileoverview Preset factories for RecordingStudio3
 *
 * Each factory returns { scriptData, lockedTracks } matching RecordingStudio3 prop shapes.
 * Used by RecordingStudio3Modal in Dictionary, Editor, and Question workflows.
 */ /**
 * Creates a dialogue entry with the required shape for RecordingStudio3.
 * @param {Object} params
 * @param {number} params.id
 * @param {string} params.speaker - Speaker key
 * @param {string} params.text
 * @param {{ start: number, end: number }} [params.timing]
 * @param {string} [params.direction]
 * @param {string} [params.emotion]
 * @returns {Object} Dialogue line
 */ function createDialogueLine({ id, speaker, text, timing, direction = '', emotion = 'neutral' }) {
    return {
        id,
        speaker,
        text: text || '',
        timing: timing || {
            start: 0,
            end: 0
        },
        direction,
        emotion,
        takes: [],
        activeTakeIndex: null
    };
}
function createWordPreset(word) {
    const phrase = word?.phrase || '';
    const pronunciation = word?.pronunciation || phrase;
    const definition = word?.definition || '';
    const scriptData = {
        metadata: {
            title: phrase ? `${phrase} — Vocabulary` : 'Vocabulary',
            scene: 'Vocabulary Practice',
            date: new Date().toISOString().split('T')[0],
            version: '1.0'
        },
        speakers: {
            phrase_track: {
                name: `Phrase (${phrase || 'untitled'})`,
                voice: 'shimmer',
                description: 'Pronunciation'
            },
            definition_track: {
                name: 'Definition',
                voice: 'alloy',
                description: 'English explanation'
            }
        },
        dialogue: [
            createDialogueLine({
                id: 1,
                speaker: 'phrase_track',
                text: pronunciation,
                timing: {
                    start: 0.0,
                    end: 2.0
                },
                direction: 'clear pronunciation'
            }),
            createDialogueLine({
                id: 2,
                speaker: 'definition_track',
                text: definition,
                timing: {
                    start: 2.5,
                    end: 4.5
                },
                direction: 'clear enunciation'
            })
        ]
    };
    return {
        scriptData,
        lockedTracks: [
            'phrase_track',
            'definition_track'
        ]
    };
}
function createConversationPreset(title, speakers) {
    const speakersMap = {};
    if (Array.isArray(speakers)) {
        speakers.forEach((s)=>{
            speakersMap[s.id] = {
                name: s.name,
                voice: s.voice || 'alloy',
                description: ''
            };
        });
    }
    const scriptData = {
        metadata: {
            title: title || 'New Conversation',
            scene: '',
            date: new Date().toISOString().split('T')[0],
            version: '1.0'
        },
        speakers: speakersMap,
        dialogue: []
    };
    return {
        scriptData,
        lockedTracks: []
    };
}
function createQuestionPreset(question) {
    const prompt = question?.prompt || '';
    const correctAnswer = question?.correctAnswer || '';
    const scriptData = {
        metadata: {
            title: prompt ? `${prompt.slice(0, 40)}${prompt.length > 40 ? '…' : ''} — Question` : 'Question',
            scene: 'Quiz Practice',
            date: new Date().toISOString().split('T')[0],
            version: '1.0'
        },
        speakers: {
            prompt_track: {
                name: 'Question Prompt',
                voice: 'fable',
                description: 'Quiz host voice'
            },
            answer_track: {
                name: 'Answer',
                voice: 'nova',
                description: 'Response voice'
            }
        },
        dialogue: [
            createDialogueLine({
                id: 1,
                speaker: 'prompt_track',
                text: prompt,
                timing: {
                    start: 0.0,
                    end: 2.5
                },
                direction: 'questioning tone',
                emotion: 'inquisitive'
            }),
            createDialogueLine({
                id: 2,
                speaker: 'answer_track',
                text: correctAnswer,
                timing: {
                    start: 3.0,
                    end: 4.0
                },
                direction: 'confident',
                emotion: 'assured'
            })
        ]
    };
    return {
        scriptData,
        lockedTracks: [
            'prompt_track',
            'answer_track'
        ]
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/fileUploadUtils.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "analyzePDF",
    ()=>analyzePDF,
    "cancelPDFAnalysis",
    ()=>cancelPDFAnalysis,
    "detectMimeType",
    ()=>detectMimeType,
    "generateEmbeddings",
    ()=>generateEmbeddings,
    "isAnalyzableDocument",
    ()=>isAnalyzableDocument,
    "uploadAndAnalyzePDF",
    ()=>uploadAndAnalyzePDF,
    "uploadFile",
    ()=>uploadFile
]);
/**
 * @fileoverview Shared utilities for file upload and PDF processing
 * Used by both FileManager and ChatSidebar
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/client/apis/uploadData.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$getCurrentUser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/auth/dist/esm/providers/cognito/apis/getCurrentUser.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$86b953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:86b953 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$abf184__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:abf184 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$fe17da__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:fe17da [app-client] (ecmascript) <text/javascript>");
// Type import removed - not needed in runtime JS
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Hub$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Hub/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$DragDropPastePlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/DragDropPastePlugin.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
function isAnalyzableDocument(mimeType) {
    if (!mimeType) return false;
    const analyzableTypes = [
        "application/pdf",
        "text/plain",
        "text/markdown",
        "text/csv",
        "text/x-gift",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "application/vnd.oasis.opendocument.text",
        "application/vnd.oasis.opendocument.spreadsheet",
        "application/vnd.oasis.opendocument.presentation",
        "application/epub+zip",
        "application/x-imscc+zip",
        "application/x-qti+xml",
        "application/zip"
    ];
    return analyzableTypes.includes(mimeType);
}
function detectMimeType(file) {
    const ext = file.name.split(".").pop()?.toLowerCase();
    const overrides = {
        imscc: "application/x-imscc+zip",
        epub: "application/epub+zip",
        gift: "text/x-gift",
        qti: "application/x-qti+xml",
        odt: "application/vnd.oasis.opendocument.text",
        ods: "application/vnd.oasis.opendocument.spreadsheet",
        odp: "application/vnd.oasis.opendocument.presentation"
    };
    return overrides[ext] || file.type;
}
async function generateEmbeddings(fileID) {
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$86b953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateFileEmbeddings"])(fileID);
        if (!result.success) {
            throw new Error(result.message || "Embeddings generation failed");
        }
        console.log("Embeddings generation started:", result);
        return result;
    } catch (error) {
        console.error("Error in generateEmbeddings:", error);
        throw new Error(error.message || "Failed to generate embeddings - unknown error");
    }
}
async function triggerEmbeddingGeneration(fileID) {
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$86b953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateFileEmbeddings"])(fileID);
        if (!result.success) {
            console.warn("[Embedding] Failed to start:", result.message);
        } else {
            console.log("[Embedding] Started background processing for file:", fileID);
        }
    } catch (error) {
        console.error("[Embedding] Error starting generation:", error);
        throw error;
    }
}
/**
 * Trigger image/thumbnail processing for a file via the processFileImage mutation.
 * The Lambda generates WebP thumbnails and size variants, then updates File.thumbnail.
 * @param {string} fileID - The ID of the file to process
 */ async function triggerImageProcessing(fileID) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data, errors } = await client.mutations.processFileImage({
            fileID
        });
        if (errors?.length) {
            console.warn("[ImageProcess] Mutation errors:", errors);
        } else {
            console.log("[ImageProcess] Processing started for file:", fileID, data);
        }
    } catch (error) {
        console.error("[ImageProcess] Error triggering processing:", error);
        throw error;
    }
}
/**
 * Internal helper: Trigger document thumbnail generation via Lambda (LibreOffice pipeline).
 * Converts office documents to a first-page WebP thumbnail.
 * @param {string} fileID - The ID of the file to process
 */ async function triggerDocumentThumbnail(fileID) {
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data, errors } = await client.mutations.processDocumentThumbnail({
            fileID
        });
        if (errors?.length) {
            console.warn("[DocumentThumbnail] Mutation errors:", errors);
        } else {
            console.log("[DocumentThumbnail] Processing started for file:", fileID, data);
        }
    } catch (error) {
        console.error("[DocumentThumbnail] Error triggering processing:", error);
        throw error;
    }
}
/**
 * Internal helper: Generate embeddings for a file (non-blocking, handled by Lambda async re-invoke)
 * @param {string} fileID - The ID of the file to generate embeddings for
 * @returns {Promise<void>}
 */ async function triggerEmbeddingsGeneration(fileID) {
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$86b953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateFileEmbeddings"])(fileID);
        if (!result.success) {
            console.warn("[Embeddings] Failed to start:", result.message);
        } else {
            console.log("[Embeddings] Started background processing for file:", fileID);
        }
    } catch (error) {
        console.error("[Embeddings] Error starting generation:", error);
        throw error;
    }
}
async function uploadFile(file, identityId, unitId = null, onProgress = null) {
    let subfolder;
    // Correct MIME type from filename for formats browsers can't detect
    const correctedMimeType = detectMimeType(file);
    // Get current user for owner field
    const { username: owner } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$getCurrentUser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCurrentUser"])();
    // Determine the folder based on file type
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isMimeType"])(file, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$DragDropPastePlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ACCEPTABLE_IMAGE_TYPES"])) {
        subfolder = "images";
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isMimeType"])(file, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$DragDropPastePlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ACCEPTABLE_AUDIO_TYPES"])) {
        subfolder = "audio";
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isMimeType"])(file, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$DragDropPastePlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ACCEPTABLE_FILE_TYPES"])) {
        subfolder = "files";
    } else {
        throw new Error(`Unsupported file type: ${correctedMimeType}`);
    }
    // Gen 2 API requires full path with protection level prefix
    const s3Path = `protected/${identityId}/${subfolder}/${file.name}`;
    console.log("Uploading file to:", s3Path);
    // Upload to S3 using Gen 2 API
    const uploadOperation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
        path: s3Path,
        data: file,
        options: {
            contentType: correctedMimeType,
            onProgress (progress) {
                console.log(`Uploaded: ${progress.transferredBytes}/${progress.totalBytes}`);
                if (onProgress) {
                    onProgress(progress.transferredBytes, progress.totalBytes);
                }
            }
        }
    });
    console.log("Upload operation created");
    // Wait for upload to complete and get the result
    const uploadResult = await uploadOperation.result;
    console.log("Upload completed successfully, S3 path:", uploadResult.path);
    // Create File model entry with the full S3 path from upload result
    const fileData = {
        path: uploadResult.path,
        owner,
        identityId,
        name: file.name,
        size: file.size,
        mimeType: correctedMimeType,
        level: "PROTECTED"
    };
    // If analyzable document type, create Document record first (so we have an ID for the File)
    let documentModel = null;
    if (isAnalyzableDocument(correctedMimeType)) {
        const amplifyClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        // Create document without unit relationship first
        const documentData = {
            filename: file.name,
            s3Key: uploadResult.path,
            status: "uploaded",
            mimeType: correctedMimeType,
            fileSize: file.size,
            owner,
            identityId,
            uploadedAt: new Date().toISOString()
        };
        const { data: newDocument, errors: documentErrors } = await amplifyClient.models.Document.create(documentData);
        if (documentErrors && documentErrors.length > 0 || !newDocument) {
            console.error("Error creating Document record:", documentErrors);
            throw new Error(documentErrors?.[0]?.message || "Failed to create Document record");
        }
        documentModel = newDocument;
        console.log("Created Document record for", correctedMimeType, ":", documentModel);
    }
    // Create File record, linking to Document if PDF
    const amplifyClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
    if (documentModel) {
        fileData.documentID = documentModel.id;
    }
    const { data: newFile, errors: fileErrors } = await amplifyClient.models.File.create(fileData);
    if (fileErrors && fileErrors.length > 0 || !newFile) {
        console.error("Error creating File record:", fileErrors);
        throw new Error(fileErrors?.[0]?.message || "Failed to create File record");
    }
    const fileModel = newFile;
    console.log("Created File record:", fileModel);
    // Generate embedding for the uploaded file (async via Lambda re-invoke pattern)
    const embedding = await triggerEmbeddingGeneration(fileModel.id).catch((error)=>{
        // Silently fail - embeddings are not critical for upload success
        console.warn("Embedding generation failed to start:", error.message);
    });
    // Image/thumbnail processing is handled automatically via EventBridge.
    // S3 Object Created events route to imageProcess (images/PDFs) and
    // documentThumbnail (office docs) Lambdas based on file extension.
    // No explicit mutation call needed here — avoids duplicate processing.
    // add metadata to fileModel different for image/audio/pdf
    // If unitId provided, link document to unit using many-to-many relationship
    if (documentModel && unitId) {
        try {
            const amplifyClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const { data: unit, errors: unitErrors } = await amplifyClient.models.Unit.get({
                id: unitId
            });
            if (unitErrors && unitErrors.length > 0 || !unit) {
                console.warn(`Failed to fetch unit ${unitId}:`, unitErrors);
            } else if (unit.id) {
                // Create the join table entry to link Document and Unit
                const { data: unitDoc, errors: unitDocErrors } = await amplifyClient.models.UnitDocument.create({
                    documentID: documentModel.id,
                    unitID: unit.id
                });
                if (unitDocErrors && unitDocErrors.length > 0 || !unitDoc) {
                    console.warn("Error creating UnitDocument relationship:", unitDocErrors);
                } else {
                    console.log("Linked Document to Unit:", unit.id);
                }
            }
        } catch (error) {
            console.warn("Error linking Document to Unit:", error);
        // Don't throw - document was created successfully
        }
    }
    return {
        fileModel,
        documentModel
    };
}
/**
 * Wait for a Document to sync to the backend
 * @param {string} documentId - Document ID to wait for
 * @returns {Promise<void>}
 */ async function waitForDocumentSync(documentId) {
    return new Promise((resolve, reject)=>{
        const timeout = setTimeout(()=>{
            unsubscribe();
            reject(new Error(`Document sync timeout after 10 seconds for document: ${documentId}`));
        }, 10000);
        const unsubscribe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Hub$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hub"].listen("datastore", ({ payload })=>{
            if (payload.event === "outboxMutationProcessed" && payload.data?.element?.model === "Document" && payload.data?.element?.id === documentId) {
                console.log("[FileUpload] Document synced to backend:", documentId);
                clearTimeout(timeout);
                unsubscribe();
                resolve();
            }
        });
    });
}
async function analyzePDF(fileID) {
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$abf184__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["analyzeDocument"])(fileID);
        if (!result.success) {
            throw new Error(result.message || "Analysis failed");
        }
        console.log("Document analysis started:", result);
        return result;
    } catch (error) {
        console.error("Error in analyzePDF:", error);
        // Re-throw if it's already a user-friendly error
        if (error.message?.includes("currently being processed") || error.message?.includes("Server error") || error.message?.includes("Document is")) {
            throw error;
        }
        throw new Error(error.message || "Failed to analyze PDF - unknown error");
    }
}
async function cancelPDFAnalysis(fileId) {
    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$fe17da__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["cancelDocumentAnalysis"])(fileId);
    if (!result.success) {
        throw new Error(result.message || "Cancellation failed");
    }
    console.log("Document analysis cancelled:", result);
    return result;
}
async function uploadAndAnalyzePDF(file, identityId, unitId, autoAnalyze = true, onProgress = null) {
    const correctedType = detectMimeType(file);
    if (!isAnalyzableDocument(correctedType)) {
        throw new Error(`File type ${correctedType} is not analyzable. Supported types: PDF, Word, Excel, PowerPoint, text, markdown, CSV, ODF, EPUB, SCORM, IMS CC, QTI, GIFT`);
    }
    // Upload the file
    const { fileModel, documentModel } = await uploadFile(file, identityId, unitId, onProgress);
    // Document analysis is now auto-triggered via EventBridge on S3 upload.
    // The analyzeDocument mutation remains available as a manual retry via analyzePDF().
    return {
        fileModel,
        documentModel,
        analysisResult: null
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/nailedItParser.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Nailed It parser — extracts AI feedback envelope containing the nailedIt flag,
 * reason text, and XP award from AI responses.
 *
 * AI responses are expected in a JSON envelope format:
 * ```json
 * {
 *   "feedback": "Your analysis is excellent...",
 *   "nailedIt": true,
 *   "nailedItReason": "Exceptional depth of analysis on photosynthesis",
 *   "xpToAward": 20
 * }
 * ```
 *
 * @module nailedItParser
 */ // ============================================================================
// Types
// ============================================================================
__turbopack_context__.s([
    "isNailedIt",
    ()=>isNailedIt,
    "parseNailedItResponse",
    ()=>parseNailedItResponse
]);
// ============================================================================
// Constants
// ============================================================================
const NAILED_IT_XP = 20;
function parseNailedItResponse(response) {
    const fallback = {
        feedback: response,
        nailedIt: false,
        nailedItReason: null,
        xpToAward: 0
    };
    if (!response || response.trim() === '') {
        return {
            ...fallback,
            feedback: ''
        };
    }
    const trimmed = response.trim();
    // Format 2: Code-fenced block — ```nailed-it ... ```
    const fenceMatch = trimmed.match(/```nailed-it\s*\n([\s\S]*?)\n\s*```/);
    if (fenceMatch) {
        try {
            const parsed = JSON.parse(fenceMatch[1].trim());
            const nailedIt = parsed.nailedIt === true;
            // Extract the text before the code fence as feedback
            const feedbackText = trimmed.slice(0, trimmed.indexOf('```nailed-it')).trim();
            return {
                feedback: feedbackText || response,
                nailedIt,
                nailedItReason: nailedIt && typeof parsed.nailedItReason === 'string' ? parsed.nailedItReason : null,
                xpToAward: nailedIt ? NAILED_IT_XP : 0
            };
        } catch  {
            // Invalid JSON in fence — treat as plain text
            return fallback;
        }
    }
    // Format 1: Full JSON envelope
    if (trimmed.startsWith('{')) {
        try {
            const parsed = JSON.parse(trimmed);
            if (typeof parsed.feedback !== 'string') {
                return fallback;
            }
            const nailedIt = parsed.nailedIt === true;
            return {
                feedback: parsed.feedback,
                nailedIt,
                nailedItReason: nailedIt && typeof parsed.nailedItReason === 'string' ? parsed.nailedItReason : null,
                xpToAward: nailedIt ? NAILED_IT_XP : 0
            };
        } catch  {
            // Invalid JSON — treat as plain text
            return fallback;
        }
    }
    // Not JSON — plain text feedback
    return fallback;
}
function isNailedIt(result) {
    return result.nailedIt === true;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/buildContentContext.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildContentContext",
    ()=>buildContentContext
]);
/**
 * Builds a content context string for AI feedback personalization.
 * Summarizes uploaded documents and unit content so the AI can reference
 * specific pages, sections, or documents in its feedback.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
;
/**
 * Load first N chars of extracted text from S3 for a document.
 */ async function loadExtractedTextPreview(identityId, documentId, maxChars = 300) {
    try {
        const s3Path = `private/${identityId}/documents/${documentId}/extracted-text.txt`;
        const url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(s3Path);
        if (!url) return null;
        const response = await fetch(url, {
            headers: {
                Range: `bytes=0-${maxChars * 4}`
            }
        });
        if (!response.ok) return null;
        const text = await response.text();
        return text.slice(0, maxChars);
    } catch  {
        return null;
    }
}
async function buildContentContext(options) {
    const { unit, files, documents } = options;
    const parts = [];
    // Unit info
    if (unit?.name) {
        parts.push(`Unit: "${unit.name}"${unit.description ? ` — ${unit.description}` : ""}`);
    }
    // Uploaded documents with extracted text summaries (loaded from S3)
    if (documents && Array.isArray(documents)) {
        const completedDocs = documents.filter((d)=>(d?.textExtractedAt || d?.extractedText) && d.status === "completed");
        const docPreviews = await Promise.all(completedDocs.slice(0, 5).map(async (doc)=>{
            let entry = `Document: "${doc.name || "Untitled"}"`;
            if (doc.pageCount) entry += ` (${doc.pageCount} pages)`;
            // Try S3 first, fall back to inline extractedText
            let preview = null;
            if (doc.identityId && doc.id) {
                preview = await loadExtractedTextPreview(doc.identityId, doc.id);
            }
            if (!preview && doc.extractedText) {
                preview = doc.extractedText.slice(0, 300).replace(/\n+/g, " ").trim();
            }
            if (preview) {
                entry += `\n  Summary: ${preview}...`;
            }
            return entry;
        }));
        parts.push(...docPreviews);
    }
    // File listing (PDFs, images, audio that may contain relevant content)
    if (files) {
        const fileList = Array.isArray(files) ? files : Object.values(files);
        const contentFiles = fileList.filter((f)=>f?.name && (f.mimeType?.includes("pdf") || f.mimeType?.includes("image")));
        if (contentFiles.length > 0 && !documents?.length) {
            const names = contentFiles.slice(0, 10).map((f)=>`"${f.name}"`).join(", ");
            parts.push(`Available files: ${names}`);
        }
    }
    if (parts.length === 0) return undefined;
    return parts.join("\n\n");
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/practiceXPCalculator.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateAccuracyBonus",
    ()=>calculateAccuracyBonus,
    "calculateDrillXP",
    ()=>calculateDrillXP,
    "previewXP",
    ()=>previewXP
]);
/**
 * @fileoverview practiceXPCalculator — Diminishing returns XP calculation
 * for practice drill sessions. Shared between Lambda (gamification handler)
 * and UI (preview in drill dialog).
 */ // ============================================================================
// Constants
// ============================================================================
const BASE_XP = 30;
const DIMINISH_FACTOR = 0.5;
const FLOOR_XP = 5;
const ACCURACY_BONUSES = [
    {
        threshold: 90,
        bonus: 15
    },
    {
        threshold: 80,
        bonus: 10
    },
    {
        threshold: 70,
        bonus: 5
    }
];
function calculateDrillXP(sessionsCompletedToday) {
    return Math.max(FLOOR_XP, Math.floor(BASE_XP * Math.pow(DIMINISH_FACTOR, sessionsCompletedToday)));
}
function calculateAccuracyBonus(accuracy, bonusSessionsToday = 0) {
    const bonus = ACCURACY_BONUSES.find((b)=>accuracy >= b.threshold);
    if (!bonus) return 0;
    return Math.max(FLOOR_XP, Math.floor(bonus.bonus * Math.pow(DIMINISH_FACTOR, bonusSessionsToday)));
}
function previewXP(sessionsCompletedToday, estimatedAccuracy = 0) {
    const drillXP = calculateDrillXP(sessionsCompletedToday);
    const accuracyBonus = calculateAccuracyBonus(estimatedAccuracy, sessionsCompletedToday);
    return {
        drillXP,
        accuracyBonus,
        total: drillXP + accuracyBonus
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/analytics.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnalyticsEvents",
    ()=>AnalyticsEvents,
    "flush",
    ()=>flush,
    "identifyAnalyticsUser",
    ()=>identifyAnalyticsUser,
    "initAnalytics",
    ()=>initAnalytics,
    "trackChatBlockInserted",
    ()=>trackChatBlockInserted,
    "trackChatFileUploaded",
    ()=>trackChatFileUploaded,
    "trackChatMessageSent",
    ()=>trackChatMessageSent,
    "trackChatRegenerated",
    ()=>trackChatRegenerated,
    "trackChatResponseReceived",
    ()=>trackChatResponseReceived,
    "trackChatSessionStarted",
    ()=>trackChatSessionStarted,
    "trackChatToolUsed",
    ()=>trackChatToolUsed,
    "trackEngagedTime",
    ()=>trackEngagedTime,
    "trackEvent",
    ()=>trackEvent,
    "trackGuildViewed",
    ()=>trackGuildViewed,
    "trackPageView",
    ()=>trackPageView,
    "trackSectionEngagedTime",
    ()=>trackSectionEngagedTime,
    "trackSectionWorkbookCompleted",
    ()=>trackSectionWorkbookCompleted,
    "trackSectionWorkbookStarted",
    ()=>trackSectionWorkbookStarted,
    "trackSquadEdited",
    ()=>trackSquadEdited,
    "trackSquadJoined",
    ()=>trackSquadJoined,
    "trackSquadLeaderboardModeChanged",
    ()=>trackSquadLeaderboardModeChanged,
    "trackSquadLeaderboardViewed",
    ()=>trackSquadLeaderboardViewed,
    "trackSquadLeft",
    ()=>trackSquadLeft,
    "trackSquadPostCreated",
    ()=>trackSquadPostCreated,
    "trackSquadPostDeleted",
    ()=>trackSquadPostDeleted,
    "trackSquadViewed",
    ()=>trackSquadViewed,
    "trackWorkbookCompleted",
    ()=>trackWorkbookCompleted
]);
"use client";
const AnalyticsEvents = {
    // Navigation
    PAGE_VIEW: "pageView",
    // Workbook engagement
    WORKBOOK_STARTED: "workbookStarted",
    WORKBOOK_COMPLETED: "workbookCompleted",
    ENGAGED_TIME_UPDATE: "engagedTimeUpdate",
    // Grading
    GRADE_SUBMITTED: "gradeSubmitted",
    GRADE_RETRY: "gradeRetry",
    // Content interaction
    AUDIO_PLAYED: "audioPlayed",
    VIDEO_PLAYED: "videoPlayed",
    FILE_DOWNLOADED: "fileDownloaded",
    // AI Chat engagement
    CHAT_MESSAGE_SENT: "chatMessageSent",
    CHAT_RESPONSE_RECEIVED: "chatResponseReceived",
    CHAT_TOOL_USED: "chatToolUsed",
    CHAT_FILE_UPLOADED: "chatFileUploaded",
    CHAT_SESSION_STARTED: "chatSessionStarted",
    CHAT_BLOCK_INSERTED: "chatBlockInserted",
    CHAT_REGENERATED: "chatRegenerated",
    DOCUMENT_ANALYZED: "documentAnalyzed",
    // Social
    PEER_REVIEW_SUBMITTED: "peerReviewSubmitted",
    PRACTICE_DRILL_STARTED: "practiceDrillStarted",
    PRACTICE_DRILL_COMPLETED: "practiceDrillCompleted",
    // Gamification
    BADGE_EARNED: "badgeEarned",
    LEVEL_UP: "levelUp",
    // Squad engagement
    SQUAD_VIEWED: "squadViewed",
    SQUAD_JOINED: "squadJoined",
    SQUAD_LEFT: "squadLeft",
    SQUAD_POST_CREATED: "squadPostCreated",
    SQUAD_POST_DELETED: "squadPostDeleted",
    SQUAD_EDITED: "squadEdited",
    SQUAD_LEADERBOARD_VIEWED: "squadLeaderboardViewed",
    SQUAD_LEADERBOARD_MODE_CHANGED: "squadLeaderboardModeChanged",
    // Section activity
    GUILD_VIEWED: "guildViewed",
    SECTION_WORKBOOK_STARTED: "sectionWorkbookStarted"
};
const buffer = [];
let flushTimer = null;
let currentSessionId = null;
let currentUserId;
let currentUserRole;
function getSessionId() {
    if (currentSessionId) return currentSessionId;
    // Generate a session ID per browser tab
    currentSessionId = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : typeof crypto !== "undefined" && crypto.getRandomValues ? `${Date.now()}-${Array.from(crypto.getRandomValues(new Uint8Array(8))).map((b)=>b.toString(16).padStart(2, "0")).join("")}` : `${Date.now()}`;
    return currentSessionId;
}
function flush() {
    if (buffer.length === 0) return;
    const events = buffer.splice(0, buffer.length);
    try {
        const payload = JSON.stringify(events);
        if (typeof navigator !== "undefined" && navigator.sendBeacon) {
            navigator.sendBeacon("/api/analytics", payload);
        } else {
            // Fallback for environments without sendBeacon (SSR guard)
            fetch("/api/analytics", {
                method: "POST",
                body: payload,
                headers: {
                    "Content-Type": "application/json"
                },
                keepalive: true
            }).catch(()=>{
            // Silently fail — analytics should never block UX
            });
        }
    } catch  {
    // Analytics should never crash the app
    }
}
// Auto-flush setup (client-side only)
if (typeof document !== "undefined") {
    // Flush on page hide (reliable even on tab close)
    document.addEventListener("visibilitychange", ()=>{
        if (document.visibilityState === "hidden") flush();
    });
    // Flush every 30s
    flushTimer = setInterval(flush, 30_000);
}
function trackEvent(name, attributes, metrics) {
    try {
        buffer.push({
            name,
            timestamp: new Date().toISOString(),
            sessionId: getSessionId(),
            userId: currentUserId,
            userRole: currentUserRole,
            path: ("TURBOPACK compile-time truthy", 1) ? window.location.pathname : "TURBOPACK unreachable",
            attributes,
            metrics
        });
        // Auto-flush when buffer reaches 20 events
        if (buffer.length >= 20) flush();
    } catch  {
    // Analytics should never crash the app
    }
}
function trackPageView(path, attributes) {
    trackEvent(AnalyticsEvents.PAGE_VIEW, {
        path,
        ...attributes
    });
}
function trackEngagedTime(unitId, gradeId, engagedTimeMs) {
    trackEvent(AnalyticsEvents.ENGAGED_TIME_UPDATE, {
        unitId,
        gradeId
    }, {
        engagedTimeMs
    });
}
function trackWorkbookCompleted(unitId, gradeId, accuracy, engagedTimeMs) {
    trackEvent(AnalyticsEvents.WORKBOOK_COMPLETED, {
        unitId,
        gradeId
    }, {
        accuracy,
        engagedTimeMs
    });
}
function initAnalytics(options) {
    if (options?.userId) currentUserId = options.userId;
    if (options?.userRole) currentUserRole = options.userRole;
}
function identifyAnalyticsUser(options) {
    currentUserId = options.userId;
    if (options.userRole) {
        currentUserRole = options.userRole;
    }
}
function trackSectionWorkbookStarted(unitId, sectionId, assignmentId) {
    trackEvent(AnalyticsEvents.SECTION_WORKBOOK_STARTED, {
        unitId,
        sectionId,
        ...assignmentId && {
            assignmentId
        }
    });
}
function trackSectionWorkbookCompleted(unitId, gradeId, sectionId, accuracy, engagedTimeMs) {
    trackEvent(AnalyticsEvents.WORKBOOK_COMPLETED, {
        unitId,
        gradeId,
        sectionId
    }, {
        accuracy,
        engagedTimeMs
    });
}
function trackSectionEngagedTime(unitId, gradeId, sectionId, engagedTimeMs) {
    trackEvent(AnalyticsEvents.ENGAGED_TIME_UPDATE, {
        unitId,
        gradeId,
        sectionId
    }, {
        engagedTimeMs
    });
}
function trackGuildViewed(sectionId, guildType) {
    trackEvent(AnalyticsEvents.GUILD_VIEWED, {
        sectionId,
        ...guildType && {
            guildType
        }
    });
}
function trackChatMessageSent(chatId, sectionId, messageLength) {
    trackEvent(AnalyticsEvents.CHAT_MESSAGE_SENT, {
        chatId,
        ...sectionId && {
            sectionId
        }
    }, messageLength != null ? {
        messageLength
    } : undefined);
}
function trackChatResponseReceived(chatId, toolsUsed) {
    trackEvent(AnalyticsEvents.CHAT_RESPONSE_RECEIVED, {
        chatId,
        ...toolsUsed && toolsUsed.length > 0 && {
            toolsUsed: toolsUsed.join(",")
        }
    });
}
function trackChatToolUsed(chatId, toolName, sectionId) {
    trackEvent(AnalyticsEvents.CHAT_TOOL_USED, {
        chatId,
        toolName,
        ...sectionId && {
            sectionId
        }
    });
}
function trackChatFileUploaded(chatId, fileType) {
    trackEvent(AnalyticsEvents.CHAT_FILE_UPLOADED, {
        chatId,
        fileType
    });
}
function trackChatSessionStarted(sectionId) {
    trackEvent(AnalyticsEvents.CHAT_SESSION_STARTED, {
        ...sectionId && {
            sectionId
        }
    });
}
function trackChatBlockInserted(chatId, blockType) {
    trackEvent(AnalyticsEvents.CHAT_BLOCK_INSERTED, {
        chatId,
        blockType
    });
}
function trackChatRegenerated(chatId) {
    trackEvent(AnalyticsEvents.CHAT_REGENERATED, {
        chatId
    });
}
function trackSquadViewed(squadId, sectionId) {
    trackEvent(AnalyticsEvents.SQUAD_VIEWED, {
        squadId,
        sectionId
    });
}
function trackSquadJoined(squadId, sectionId) {
    trackEvent(AnalyticsEvents.SQUAD_JOINED, {
        squadId,
        sectionId
    });
}
function trackSquadLeft(squadId, sectionId) {
    trackEvent(AnalyticsEvents.SQUAD_LEFT, {
        squadId,
        sectionId
    });
}
function trackSquadPostCreated(squadId, sectionId) {
    trackEvent(AnalyticsEvents.SQUAD_POST_CREATED, {
        squadId,
        sectionId
    });
}
function trackSquadPostDeleted(squadId, sectionId) {
    trackEvent(AnalyticsEvents.SQUAD_POST_DELETED, {
        squadId,
        sectionId
    });
}
function trackSquadEdited(squadId, field) {
    trackEvent(AnalyticsEvents.SQUAD_EDITED, {
        squadId,
        field
    });
}
function trackSquadLeaderboardViewed(sectionId) {
    trackEvent(AnalyticsEvents.SQUAD_LEADERBOARD_VIEWED, {
        sectionId
    });
}
function trackSquadLeaderboardModeChanged(sectionId, mode) {
    trackEvent(AnalyticsEvents.SQUAD_LEADERBOARD_MODE_CHANGED, {
        sectionId,
        mode
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/chunkedCookieStorage.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChunkedCookieStorage",
    ()=>ChunkedCookieStorage
]);
/**
 * ChunkedCookieStorage
 *
 * A KeyValueStorageInterface implementation that splits large values
 * across multiple cookies to stay under the ~4096 byte browser limit.
 *
 * Cookie naming scheme:
 *   - Metadata: `{key}.chunks` = number of chunks (e.g., "3")
 *   - Chunks:   `{key}.chunk.0`, `{key}.chunk.1`, `{key}.chunk.2`
 *   - If value fits in one cookie: stored directly as `{key}` (no chunking)
 *
 * This solves the Cognito idToken cookie being silently dropped when users
 * have many groups (section-{id}-instructors/learners).
 */ // @ts-ignore — js-cookie has no type declarations in this project
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-client] (ecmascript)");
;
// Safe cookie value size (leaving room for key name, attributes, encoding)
const MAX_CHUNK_SIZE = 3500;
class ChunkedCookieStorage {
    path;
    domain;
    expires;
    sameSite;
    secure;
    constructor(options = {}){
        this.path = options.path || "/";
        this.domain = options.domain;
        this.expires = options.expires ?? 365;
        this.secure = options.secure ?? true;
        this.sameSite = options.sameSite || "lax";
    }
    getCookieOptions() {
        return {
            path: this.path,
            domain: this.domain,
            expires: this.expires,
            secure: this.secure,
            sameSite: this.sameSite
        };
    }
    async setItem(key, value) {
        // First, remove any existing chunks for this key
        await this.removeItem(key);
        const opts = this.getCookieOptions();
        if (value.length <= MAX_CHUNK_SIZE) {
            // Fits in a single cookie — store directly
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].set(key, value, opts);
        } else {
            // Split into chunks
            const chunks = [];
            for(let i = 0; i < value.length; i += MAX_CHUNK_SIZE){
                chunks.push(value.slice(i, i + MAX_CHUNK_SIZE));
            }
            // Store chunk count metadata
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].set(`${key}.chunks`, String(chunks.length), opts);
            // Store each chunk
            for(let i = 0; i < chunks.length; i++){
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].set(`${key}.chunk.${i}`, chunks[i], opts);
            }
        }
    }
    async getItem(key) {
        // Check if there are chunks
        const chunkCountStr = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${key}.chunks`);
        if (chunkCountStr) {
            // Reassemble from chunks
            const chunkCount = parseInt(chunkCountStr, 10);
            const parts = [];
            for(let i = 0; i < chunkCount; i++){
                const chunk = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${key}.chunk.${i}`);
                if (chunk === undefined) {
                    // Missing chunk — data is corrupted, treat as not found
                    console.warn(`[ChunkedCookieStorage] Missing chunk ${i} of ${chunkCount} for key: ${key}`);
                    return null;
                }
                parts.push(chunk);
            }
            return parts.join("");
        }
        // No chunks — try direct read
        const value = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(key);
        return value ?? null;
    }
    async removeItem(key) {
        const opts = this.getCookieOptions();
        // Remove direct cookie
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].remove(key, opts);
        // Remove any chunks
        const chunkCountStr = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${key}.chunks`);
        if (chunkCountStr) {
            const chunkCount = parseInt(chunkCountStr, 10);
            for(let i = 0; i < chunkCount; i++){
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].remove(`${key}.chunk.${i}`, opts);
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].remove(`${key}.chunks`, opts);
        }
    }
    async clear() {
        const allCookies = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get();
        const opts = this.getCookieOptions();
        for (const key of Object.keys(allCookies)){
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].remove(key, opts);
        }
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_utils_0guo2-p._.js.map