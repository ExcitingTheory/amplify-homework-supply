(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1az44_g._.js","static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jm.js","static/chunks/node_modules_next_dist_compiled_react-dom_096_9a-._.js","static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-6._.js","static/chunks/node_modules_next_dist_compiled_1utqc4q._.js","static/chunks/node_modules_next_dist_client_0r5nbpw._.js","static/chunks/node_modules_next_dist_server_0kuwv9x._.js","static/chunks/node_modules_next_dist_0wczimo._.js","static/chunks/node_modules_08dy-hi._.js","static/chunks/instrumentation-client_ts_06kj-ai._.js"],
    source: "entry"
});
