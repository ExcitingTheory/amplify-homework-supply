(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/context/authContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$fetchUserAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/auth/dist/esm/providers/cognito/apis/fetchUserAttributes.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/apis/fetchAuthSession.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$signOut$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/auth/dist/esm/providers/cognito/apis/signOut.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Hub$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Hub/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
// NOTE: The AuthGate component in _app.jsx gates data-dependent providers
// behind auth resolution, so by the time other contexts mount and call
// list()/subscribe(), the SDK's internal credential cache is already warm.
const AuthContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext({
    error: undefined,
    isLoading: true,
    user: undefined,
    session: undefined
});
const AuthProvider = ({ children })=>{
    _s();
    const [result, setResult] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        error: undefined,
        isLoading: true,
        user: undefined,
        session: undefined
    });
    const fetchCurrentUserAttributes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "AuthProvider.useCallback[fetchCurrentUserAttributes]": async ()=>{
            setResult({
                "AuthProvider.useCallback[fetchCurrentUserAttributes]": (prevResult)=>({
                        ...prevResult,
                        isLoading: true
                    })
            }["AuthProvider.useCallback[fetchCurrentUserAttributes]"]);
            try {
                // Add timeout to prevent hanging indefinitely
                const timeoutPromise = new Promise({
                    "AuthProvider.useCallback[fetchCurrentUserAttributes]": (_, reject)=>setTimeout({
                            "AuthProvider.useCallback[fetchCurrentUserAttributes]": ()=>reject(new Error('Authentication timeout'))
                        }["AuthProvider.useCallback[fetchCurrentUserAttributes]"], 15000)
                }["AuthProvider.useCallback[fetchCurrentUserAttributes]"]);
                // Call fetchAuthSession FIRST to warm the credential provider cache.
                // fetchUserAttributes() internally calls fetchAuthSession() again, but
                // at that point the cache is populated so no additional IAM HTTP calls.
                // AuthGate in _app.jsx ensures this completes before data contexts mount.
                const sessionPromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAuthSession"])();
                const session = await Promise.race([
                    sessionPromise,
                    timeoutPromise
                ]);
                const { identityId, tokens } = session || {};
                if (!tokens) {
                    // No tokens = user not authenticated (expected on login page)
                    console.log('[AuthContext] User not authenticated - no tokens available');
                    setResult({
                        user: undefined,
                        session: undefined,
                        isLoading: false,
                        error: undefined
                    });
                    return;
                }
                const { idToken, accessToken } = tokens;
                const attributesPromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$fetchUserAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchUserAttributes"])();
                const attributes = await Promise.race([
                    attributesPromise,
                    timeoutPromise
                ]);
                // Extract user groups from token payload
                const groups = accessToken?.payload['cognito:groups'] || [];
                setResult({
                    user: {
                        attributes
                    },
                    session: {
                        identityId,
                        idToken,
                        groups
                    },
                    isLoading: false
                });
            } catch (error) {
                // Handle timeout errors - treat as if user is not authenticated
                if (error.message === 'Authentication timeout') {
                    console.warn('[AuthContext] Authentication request timed out - treating as not authenticated');
                    setResult({
                        user: undefined,
                        session: undefined,
                        isLoading: false,
                        error: undefined
                    });
                    return;
                }
                // Handle expired/invalid token - sign out and redirect to login
                if (error.name === 'NotAuthorizedException' || error.message?.includes('Invalid login token') || error.message?.includes('expired')) {
                    console.log('[AuthContext] Token expired or invalid - signing out and redirecting to login');
                    try {
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$signOut$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signOut"])();
                    } catch (signOutError) {
                        console.warn('[AuthContext] Error during signOut:', signOutError);
                    }
                    setResult({
                        user: undefined,
                        session: undefined,
                        isLoading: false,
                        error: undefined
                    });
                    // Store current URL for redirect after login
                    if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.location.pathname !== '/') {
                        const returnUrl = window.location.pathname + window.location.search;
                        sessionStorage.setItem('returnUrl', returnUrl);
                        console.log('[AuthContext] Token expired - stored return URL:', returnUrl);
                    }
                    // Redirect to home page (which has Authenticator component)
                    if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.location.pathname !== '/') {
                        window.location.href = '/';
                    }
                    return;
                }
                // Handle unauthenticated state gracefully - this is expected when user is not signed in
                if (error.name === 'UserUnAuthenticatedException' || error.message?.includes('not authenticated') || error.message?.includes('No current user') || error.message?.includes('NoSignedUser')) {
                    console.log('[AuthContext] User not authenticated');
                    // Store current URL for redirect after login (but not for the home page)
                    if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.location.pathname !== '/') {
                        const returnUrl_0 = window.location.pathname + window.location.search;
                        sessionStorage.setItem('returnUrl', returnUrl_0);
                        console.log('[AuthContext] Stored return URL:', returnUrl_0);
                    }
                    setResult({
                        user: undefined,
                        session: undefined,
                        isLoading: false,
                        error: undefined
                    });
                } else {
                    console.error('[AuthContext] Authentication error:', error);
                    setResult({
                        error,
                        isLoading: false,
                        user: undefined,
                        session: undefined
                    });
                }
            }
        }
    }["AuthProvider.useCallback[fetchCurrentUserAttributes]"], []);
    const handleAuth = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "AuthProvider.useCallback[handleAuth]": ({ payload })=>{
            switch(payload.event){
                case "signedIn":
                case "signUp":
                case "tokenRefresh":
                case "autoSignIn":
                    {
                        fetchCurrentUserAttributes();
                        break;
                    }
                case "signedOut":
                    {
                        setResult({
                            user: undefined,
                            isLoading: false
                        });
                        break;
                    }
                case "tokenRefresh_failure":
                case "signIn_failure":
                    {
                        setResult({
                            error: payload.data,
                            isLoading: false
                        });
                        break;
                    }
                case "autoSignIn_failure":
                    {
                        setResult({
                            error: new Error(payload.message),
                            isLoading: false
                        });
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }
    }["AuthProvider.useCallback[handleAuth]"], [
        fetchCurrentUserAttributes
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "AuthProvider.useEffect": ()=>{
            const unsubscribe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Hub$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hub"].listen("auth", handleAuth, "useAuth");
            fetchCurrentUserAttributes();
            return unsubscribe;
        }
    }["AuthProvider.useEffect"], [
        handleAuth,
        fetchCurrentUserAttributes
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            ...result
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/authContext.jsx",
        lineNumber: 191,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(AuthProvider, "qeTWhQhrkjfeS4hNy8XavBKbefc=");
_c = AuthProvider;
;
const __TURBOPACK__default__export__ = AuthContext;
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/reducers/settingsReducer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "actionTypes",
    ()=>actionTypes,
    "initialState",
    ()=>initialState,
    "settingsReducer",
    ()=>settingsReducer
]);
const initialState = {
    settings: null,
    isLoading: true
};
const actionTypes = {
    SET_SETTINGS: 'SET_SETTINGS',
    SET_LOADING: 'SET_LOADING',
    SETTINGS_LOADED: 'SETTINGS_LOADED',
    SETTINGS_LOAD_FAILED: 'SETTINGS_LOAD_FAILED'
};
function settingsReducer(state, action) {
    switch(action.type){
        case actionTypes.SET_SETTINGS:
            {
                const incoming = action.payload;
                if (state.settings && incoming?._version != null && incoming._version <= (state.settings._version || 0)) {
                    return state; // Not newer, skip re-render
                }
                return {
                    ...state,
                    settings: incoming
                };
            }
        case actionTypes.SET_LOADING:
            return {
                ...state,
                isLoading: action.payload
            };
        case actionTypes.SETTINGS_LOADED:
            {
                const incoming = action.payload;
                if (state.settings && incoming?._version != null && incoming._version <= (state.settings._version || 0)) {
                    return {
                        ...state,
                        isLoading: false
                    }; // Not newer, but mark loaded
                }
                // Merge with existing settings to preserve fields the subscription may omit
                const merged = state.settings ? {
                    ...state.settings,
                    ...incoming
                } : incoming;
                return {
                    settings: merged,
                    isLoading: false
                };
            }
        case actionTypes.SETTINGS_LOAD_FAILED:
            return {
                ...state,
                isLoading: false
            };
        default:
            return state;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/settingsContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SettingsProvider",
    ()=>SettingsProvider,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$settingsReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/reducers/settingsReducer.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const SettingsContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])();
const SettingsProvider = ({ children })=>{
    _s();
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$settingsReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["settingsReducer"], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$settingsReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"]);
    const settingsVersionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    // Get auth state from centralized context
    const authContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { user, isLoading: authLoading } = authContext || {
        user: undefined,
        isLoading: true
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "SettingsProvider.useEffect": ()=>{
            // Wait for auth to be ready
            if (authLoading || !user) {
                console.log("[SettingsContext] Waiting for auth...", {
                    authLoading,
                    hasUser: !!user
                });
                return;
            }
            console.log("[SettingsContext] Setting up Settings subscription for user:", user.attributes.sub);
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            let cancelled = false;
            let subscription = null;
            function handleError(label, error) {
                const msg = error?.message || error?.errors?.[0]?.message || error?.error?.errors?.[0]?.message || JSON.stringify(error);
                if (msg.includes("DuplicatedOperationError")) {
                    console.warn(`[SettingsContext] ${label}: transient DuplicatedOperationError (safe to ignore)`);
                    return;
                }
                console.error(`[SettingsContext] ${label} error:`, error);
            }
            async function initSettings() {
                try {
                    // Check if settings exist; if not, create defaults first
                    const { data: items } = await client.models.Settings.list();
                    if (cancelled) return;
                    const validItems = (items || []).filter({
                        "SettingsProvider.useEffect.initSettings.validItems": (item)=>item != null && item.id != null
                    }["SettingsProvider.useEffect.initSettings.validItems"]);
                    if (validItems.length === 0) {
                        // Create default settings with _version: 1 for optimistic concurrency
                        await client.models.Settings.create({
                            _version: 1,
                            autoAnalyzeDocuments: true,
                            documentAnalysisModel: "gpt-4",
                            editorTheme: "auto",
                            editorFontSize: 14,
                            defaultAIModel: "gpt-4",
                            assistantVoice: "shimmer",
                            emailNotifications: true,
                            webhookNotifications: false,
                            language: "en",
                            profileThemeId: "default",
                            audioCleanupStrength: "standard"
                        });
                        if (cancelled) return;
                    }
                } catch (error_0) {
                    console.error("[SettingsContext] initSettings error:", error_0);
                }
                // observeQuery handles initial fetch + real-time updates in one subscription
                subscription = client.models.Settings.observeQuery().subscribe({
                    next: {
                        "SettingsProvider.useEffect.initSettings": ({ items: items_0 })=>{
                            if (cancelled) return;
                            const validItems_0 = (items_0 || []).filter({
                                "SettingsProvider.useEffect.initSettings.validItems_0": (item_0)=>item_0 != null && item_0.id != null
                            }["SettingsProvider.useEffect.initSettings.validItems_0"]);
                            if (validItems_0.length === 0) return;
                            const settings = validItems_0[0];
                            // Version guard: only process if incoming version is strictly greater
                            if (settings._version != null && !(settings._version > settingsVersionRef.current)) {
                                return;
                            }
                            settingsVersionRef.current = settings._version || 0;
                            dispatch({
                                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$settingsReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SETTINGS_LOADED,
                                payload: settings
                            });
                        }
                    }["SettingsProvider.useEffect.initSettings"],
                    error: {
                        "SettingsProvider.useEffect.initSettings": (error_1)=>handleError("Settings observeQuery", error_1)
                    }["SettingsProvider.useEffect.initSettings"]
                });
            }
            initSettings();
            return ({
                "SettingsProvider.useEffect": ()=>{
                    cancelled = true;
                    subscription?.unsubscribe();
                }
            })["SettingsProvider.useEffect"];
        }
    }["SettingsProvider.useEffect"], [
        authLoading,
        user
    ]);
    // Sync avatar config from Settings.metadata → StudentProfile + Squad.members (denormalized for leaderboard/chat)
    async function syncAvatarToProfile(client_0, authUser, metadata) {
        if (!client_0?.models?.StudentProfile || !authUser) return;
        const studentId = authUser.username || authUser.userId;
        if (!studentId) return;
        // Find the user's StudentProfile(s) and update avatar fields
        const { data: profiles } = await client_0.models.StudentProfile.list({
            filter: {
                studentId: {
                    eq: studentId
                }
            }
        });
        const validProfiles = (profiles || []).filter((p)=>p != null && p.id != null);
        const avatarUpdate = {
            avatarStyle: metadata.avatarStyle || undefined,
            avatarOverrides: metadata.avatarOverrides ? JSON.stringify(metadata.avatarOverrides) : undefined,
            avatarSeed: metadata.avatarSeed || studentId
        };
        for (const profile of validProfiles){
            await client_0.models.StudentProfile.update({
                id: profile.id,
                _version: profile._version,
                ...avatarUpdate
            });
        }
        // Also update SectionProgress records
        if (client_0.models.SectionProgress) {
            const { data: sectionProgs } = await client_0.models.SectionProgress.list({
                filter: {
                    studentId: {
                        eq: studentId
                    }
                }
            });
            const validSP = (sectionProgs || []).filter((p_0)=>p_0 != null && p_0.id != null);
            for (const sp of validSP){
                await client_0.models.SectionProgress.update({
                    id: sp.id,
                    _version: sp._version,
                    ...avatarUpdate
                });
            }
        }
        // Update Squad.members with new avatar (denormalized for squad leaderboard)
        if (client_0.models.Squad) {
            try {
                const cohortId = validProfiles[0]?.cohortId;
                if (cohortId) {
                    const { data: squads } = await client_0.models.Squad.list({
                        filter: {
                            cohortId: {
                                eq: cohortId
                            }
                        }
                    });
                    const validSquads = (squads || []).filter((s)=>s != null && s.id != null);
                    for (const squad of validSquads){
                        const members = squad.members || [];
                        const memberIdx = members.findIndex((m)=>m?.studentId === studentId);
                        if (memberIdx === -1) continue;
                        const updatedMembers = [
                            ...members
                        ];
                        updatedMembers[memberIdx] = {
                            ...updatedMembers[memberIdx],
                            avatarStyle: metadata.avatarStyle || undefined,
                            avatarOverrides: metadata.avatarOverrides ? JSON.stringify(metadata.avatarOverrides) : undefined,
                            avatarSeed: metadata.avatarSeed || studentId
                        };
                        await client_0.models.Squad.update({
                            id: squad.id,
                            _version: squad._version,
                            members: updatedMembers
                        });
                    }
                }
            } catch (err) {
                console.warn("[SettingsContext] squad avatar sync failed:", err);
            }
        }
    }
    const updateSettings = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "SettingsProvider.useCallback[updateSettings]": async (updates)=>{
            if (!state.settings) return;
            // ── Theme level-gating enforcement ──────────────────────────────────
            // Prevent users from persisting a theme they haven't unlocked.
            if (updates.profileThemeId && updates.profileThemeId !== "default") {
                const THEME_MIN_LEVELS = {
                    midnight: 2,
                    forest: 3,
                    sunset: 4,
                    aurora: 5,
                    custom: 2
                };
                const requiredLevel = THEME_MIN_LEVELS[updates.profileThemeId];
                if (requiredLevel) {
                    try {
                        const client_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                        const { data: profiles_0 } = await client_1.models.StudentProfile.list({
                            filter: {
                                owner: {
                                    eq: user
                                }
                            },
                            selectionSet: [
                                "id",
                                "level"
                            ]
                        });
                        const userLevel = profiles_0?.[0]?.level || 1;
                        if (userLevel < requiredLevel) {
                            console.warn(`[SettingsContext] Theme "${updates.profileThemeId}" requires level ${requiredLevel}, user is level ${userLevel}. Blocked.`);
                            return;
                        }
                    } catch (err_0) {
                        console.warn("[SettingsContext] Could not verify theme level-gate, allowing update:", err_0);
                    // Fail open — don't block if the profile query fails
                    }
                }
            }
            // Optimistic version bump — blocks subscription echo
            const predictedNextVersion = (state.settings._version || 0) + 1;
            settingsVersionRef.current = predictedNextVersion;
            try {
                const client_2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const { data: updated, errors } = await client_2.models.Settings.update({
                    id: state.settings.id,
                    _version: predictedNextVersion,
                    ...updates
                });
                if (errors?.length) {
                    console.error("[SettingsContext] update errors:", errors);
                    settingsVersionRef.current = state.settings._version || 0;
                }
                if (updated) {
                    settingsVersionRef.current = updated._version || 0;
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$settingsReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SETTINGS,
                        payload: updated
                    });
                    // Sync avatar config to StudentProfile (denormalized for leaderboard/chat)
                    if (updates.metadata) {
                        const meta = typeof updates.metadata === "string" ? JSON.parse(updates.metadata) : updates.metadata;
                        if (meta.avatarStyle || meta.avatarOverrides) {
                            syncAvatarToProfile(client_2, user, meta).catch({
                                "SettingsProvider.useCallback[updateSettings]": (err_1)=>console.warn("[SettingsContext] avatar sync to profile failed:", err_1)
                            }["SettingsProvider.useCallback[updateSettings]"]);
                        }
                    }
                }
                return updated;
            } catch (error_2) {
                console.error("Error updating settings:", error_2);
                settingsVersionRef.current = state.settings._version || 0;
                throw error_2;
            }
        }
    }["SettingsProvider.useCallback[updateSettings]"], [
        state.settings,
        user
    ]);
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "SettingsProvider.useMemo[contextValue]": ()=>({
                settings: state.settings,
                isLoading: state.isLoading,
                updateSettings
            })
    }["SettingsProvider.useMemo[contextValue]"], [
        state.settings,
        state.isLoading,
        updateSettings
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SettingsContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/settingsContext.jsx",
        lineNumber: 276,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(SettingsProvider, "uqYhG+2j4JJSOE9SZryH0K4hR90=");
_c = SettingsProvider;
;
const __TURBOPACK__default__export__ = SettingsContext;
var _c;
__turbopack_context__.k.register(_c, "SettingsProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/reducers/gamificationReducer.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * gamificationReducer — Unified reducer for all gamification state:
 * Progress, Campaign, Squad, SkillTree, ContentLock.
 *
 * Each domain has its own action types and state slice, but they share
 * a single reducer so they can live in one context/provider.
 */ // ============================================================================
// Types (re-exported from the unified context)
// ============================================================================
__turbopack_context__.s([
    "actionTypes",
    ()=>actionTypes,
    "gamificationReducer",
    ()=>gamificationReducer,
    "initialState",
    ()=>initialState
]);
const initialState = {
    // Progress
    rawModules: [],
    rawPersonalBests: [],
    rawBadges: [],
    rawDebuffs: [],
    streak: null,
    progressLoading: true,
    // Campaign
    rawCampaigns: [],
    rawChallenges: [],
    campaignsLoading: true,
    challengesLoading: true,
    // Squad
    rawSquads: [],
    rawMemberships: [],
    squadsLoading: true,
    membershipsLoading: true,
    // SkillTree
    rawSkills: [],
    rawSkillProgress: [],
    skillsLoading: true,
    skillProgressLoading: true,
    selectedSkillId: null,
    // ContentLock
    rawLocks: [],
    locksLoading: true,
    // Linear Lock
    rawSections: [],
    rawAssignments: [],
    rawGrades: [],
    sectionsLoading: true,
    assignmentsLoading: true,
    gradesLoading: true,
    // XP
    xpLogs: [],
    xpLoading: true
};
const actionTypes = {
    // Progress
    SET_RAW_MODULES: "SET_RAW_MODULES",
    SET_RAW_PERSONAL_BESTS: "SET_RAW_PERSONAL_BESTS",
    SET_RAW_BADGES: "SET_RAW_BADGES",
    SET_RAW_DEBUFFS: "SET_RAW_DEBUFFS",
    SET_STREAK: "SET_STREAK",
    SET_PROGRESS_LOADING: "SET_PROGRESS_LOADING",
    // Campaign
    SET_RAW_CAMPAIGNS: "SET_RAW_CAMPAIGNS",
    SET_RAW_CHALLENGES: "SET_RAW_CHALLENGES",
    SET_CAMPAIGNS_LOADING: "SET_CAMPAIGNS_LOADING",
    SET_CHALLENGES_LOADING: "SET_CHALLENGES_LOADING",
    // Squad
    SET_RAW_SQUADS: "SET_RAW_SQUADS",
    SET_RAW_MEMBERSHIPS: "SET_RAW_MEMBERSHIPS",
    SET_SQUADS_LOADING: "SET_SQUADS_LOADING",
    SET_MEMBERSHIPS_LOADING: "SET_MEMBERSHIPS_LOADING",
    // SkillTree
    SET_RAW_SKILLS: "SET_RAW_SKILLS",
    SET_RAW_SKILL_PROGRESS: "SET_RAW_SKILL_PROGRESS",
    SET_SKILLS_LOADING: "SET_SKILLS_LOADING",
    SET_SKILL_PROGRESS_LOADING: "SET_SKILL_PROGRESS_LOADING",
    SET_SELECTED_SKILL_ID: "SET_SELECTED_SKILL_ID",
    // ContentLock
    SET_RAW_LOCKS: "SET_RAW_LOCKS",
    SET_LOCKS_LOADING: "SET_LOCKS_LOADING",
    // Linear Lock
    SET_RAW_SECTIONS: "SET_RAW_SECTIONS",
    SET_RAW_ASSIGNMENTS: "SET_RAW_ASSIGNMENTS",
    SET_RAW_GRADES: "SET_RAW_GRADES",
    SET_SECTIONS_LOADING: "SET_SECTIONS_LOADING",
    SET_ASSIGNMENTS_LOADING: "SET_ASSIGNMENTS_LOADING",
    SET_GRADES_LOADING: "SET_GRADES_LOADING",
    // XP
    SET_XP_LOGS: "SET_XP_LOGS",
    SET_XP_LOADING: "SET_XP_LOADING"
};
function gamificationReducer(state, action) {
    switch(action.type){
        // ── Progress ────────────────────────────────────────────────────
        case actionTypes.SET_RAW_MODULES:
            return {
                ...state,
                rawModules: action.payload,
                progressLoading: false
            };
        case actionTypes.SET_RAW_PERSONAL_BESTS:
            return {
                ...state,
                rawPersonalBests: action.payload
            };
        case actionTypes.SET_RAW_BADGES:
            return {
                ...state,
                rawBadges: action.payload
            };
        case actionTypes.SET_RAW_DEBUFFS:
            return {
                ...state,
                rawDebuffs: action.payload
            };
        case actionTypes.SET_STREAK:
            return {
                ...state,
                streak: action.payload
            };
        case actionTypes.SET_PROGRESS_LOADING:
            return {
                ...state,
                progressLoading: action.payload
            };
        // ── Campaign ────────────────────────────────────────────────────
        case actionTypes.SET_RAW_CAMPAIGNS:
            return {
                ...state,
                rawCampaigns: action.payload,
                campaignsLoading: false
            };
        case actionTypes.SET_RAW_CHALLENGES:
            return {
                ...state,
                rawChallenges: action.payload,
                challengesLoading: false
            };
        case actionTypes.SET_CAMPAIGNS_LOADING:
            return {
                ...state,
                campaignsLoading: action.payload
            };
        case actionTypes.SET_CHALLENGES_LOADING:
            return {
                ...state,
                challengesLoading: action.payload
            };
        // ── Squad ───────────────────────────────────────────────────────
        case actionTypes.SET_RAW_SQUADS:
            return {
                ...state,
                rawSquads: action.payload,
                squadsLoading: false
            };
        case actionTypes.SET_RAW_MEMBERSHIPS:
            return {
                ...state,
                rawMemberships: action.payload,
                membershipsLoading: false
            };
        case actionTypes.SET_SQUADS_LOADING:
            return {
                ...state,
                squadsLoading: action.payload
            };
        case actionTypes.SET_MEMBERSHIPS_LOADING:
            return {
                ...state,
                membershipsLoading: action.payload
            };
        // ── SkillTree ───────────────────────────────────────────────────
        case actionTypes.SET_RAW_SKILLS:
            return {
                ...state,
                rawSkills: action.payload,
                skillsLoading: false
            };
        case actionTypes.SET_RAW_SKILL_PROGRESS:
            return {
                ...state,
                rawSkillProgress: action.payload,
                skillProgressLoading: false
            };
        case actionTypes.SET_SKILLS_LOADING:
            return {
                ...state,
                skillsLoading: action.payload
            };
        case actionTypes.SET_SKILL_PROGRESS_LOADING:
            return {
                ...state,
                skillProgressLoading: action.payload
            };
        case actionTypes.SET_SELECTED_SKILL_ID:
            return {
                ...state,
                selectedSkillId: action.payload
            };
        // ── ContentLock ─────────────────────────────────────────────────
        case actionTypes.SET_RAW_LOCKS:
            return {
                ...state,
                rawLocks: action.payload,
                locksLoading: false
            };
        case actionTypes.SET_LOCKS_LOADING:
            return {
                ...state,
                locksLoading: action.payload
            };
        // ── Linear Lock ─────────────────────────────────────────────────
        case actionTypes.SET_RAW_SECTIONS:
            return {
                ...state,
                rawSections: action.payload,
                sectionsLoading: false
            };
        case actionTypes.SET_RAW_ASSIGNMENTS:
            return {
                ...state,
                rawAssignments: action.payload,
                assignmentsLoading: false
            };
        case actionTypes.SET_RAW_GRADES:
            return {
                ...state,
                rawGrades: action.payload,
                gradesLoading: false
            };
        case actionTypes.SET_SECTIONS_LOADING:
            return {
                ...state,
                sectionsLoading: action.payload
            };
        case actionTypes.SET_ASSIGNMENTS_LOADING:
            return {
                ...state,
                assignmentsLoading: action.payload
            };
        case actionTypes.SET_GRADES_LOADING:
            return {
                ...state,
                gradesLoading: action.payload
            };
        // ── XP ───────────────────────────────────────────────────────────
        case actionTypes.SET_XP_LOGS:
            return {
                ...state,
                xpLogs: action.payload,
                xpLoading: false
            };
        case actionTypes.SET_XP_LOADING:
            return {
                ...state,
                xpLoading: action.payload
            };
        default:
            return state;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GamificationProvider",
    ()=>GamificationProvider,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useBadges",
    ()=>useBadges,
    "useCampaign",
    ()=>useCampaign,
    "useContentLock",
    ()=>useContentLock,
    "useGamification",
    ()=>useGamification,
    "usePlatformSettings",
    ()=>usePlatformSettings,
    "useProgress",
    ()=>useProgress,
    "useSkillTree",
    ()=>useSkillTree,
    "useSquad",
    ()=>useSquad,
    "useXP",
    ()=>useXP
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * GamificationContext — Unified context for all gamification state:
 * XP, Progress, Campaign, Squad, SkillTree, and ContentLock.
 *
 * Consolidates 6 separate contexts into one provider with a single
 * useReducer + domain-specific useMemo selectors.
 *
 * @module GamificationContext
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$XPToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/XPToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ChapterUnlockCelebration$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/ChapterUnlockCelebration.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/xpCalculation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/reducers/gamificationReducer.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature(), _s9 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
// ============================================================================
// Context
// ============================================================================
const GamificationContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    // XP
    totalXP: 0,
    sectionXP: 0,
    level: {
        level: 1,
        label: 'Beginner',
        xpRequired: 0,
        xpForNextLevel: 100,
        progress: 0
    },
    sectionLevel: {
        level: 1,
        label: 'Beginner',
        xpRequired: 0,
        xpForNextLevel: 100,
        progress: 0
    },
    xpLogs: [],
    xpLoading: true,
    // Progress
    modules: [],
    personalBests: [],
    badges: [],
    activeDebuffs: [],
    hasActiveDebuff: ()=>false,
    streak: null,
    progressLoading: true,
    // Campaign
    campaign: null,
    activeChallenges: [],
    completedChallenges: [],
    campaignLoading: true,
    // Squad
    mySquad: null,
    myMembership: null,
    squadLeaderboard: [],
    squadMembers: [],
    squadLoading: true,
    // SkillTree
    skillNodes: [],
    skillTreeLoading: true,
    selectedSkillId: null,
    setSelectedSkillId: ()=>{},
    // ContentLock
    locks: [],
    isLocked: ()=>false,
    getLockStatus: ()=>undefined,
    contentLockLoading: true,
    // Global settings
    avatarUnlockConfig: null,
    platformSettings: null,
    autoAnalyzeDocuments: true,
    // Overall
    isLoading: true
});
function useGamification() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2";
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(GamificationContext);
}
_s(useGamification, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
function useProgress() {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2";
    }
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(GamificationContext);
    let t0;
    if ($[1] !== ctx.modules || $[2] !== ctx.personalBests || $[3] !== ctx.progressLoading || $[4] !== ctx.streak) {
        t0 = {
            modules: ctx.modules,
            personalBests: ctx.personalBests,
            streak: ctx.streak,
            isLoading: ctx.progressLoading
        };
        $[1] = ctx.modules;
        $[2] = ctx.personalBests;
        $[3] = ctx.progressLoading;
        $[4] = ctx.streak;
        $[5] = t0;
    } else {
        t0 = $[5];
    }
    return t0;
}
_s1(useProgress, "/dMy7t63NXD4eYACoT93CePwGrg=");
function useBadges() {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2";
    }
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(GamificationContext);
    let t0;
    if ($[1] !== ctx.badges || $[2] !== ctx.progressLoading) {
        t0 = {
            badges: ctx.badges,
            isLoading: ctx.progressLoading
        };
        $[1] = ctx.badges;
        $[2] = ctx.progressLoading;
        $[3] = t0;
    } else {
        t0 = $[3];
    }
    return t0;
}
_s2(useBadges, "/dMy7t63NXD4eYACoT93CePwGrg=");
function useCampaign() {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2";
    }
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(GamificationContext);
    let t0;
    if ($[1] !== ctx.activeChallenges || $[2] !== ctx.campaign || $[3] !== ctx.campaignLoading || $[4] !== ctx.completedChallenges) {
        t0 = {
            campaign: ctx.campaign,
            activeChallenges: ctx.activeChallenges,
            completedChallenges: ctx.completedChallenges,
            isLoading: ctx.campaignLoading
        };
        $[1] = ctx.activeChallenges;
        $[2] = ctx.campaign;
        $[3] = ctx.campaignLoading;
        $[4] = ctx.completedChallenges;
        $[5] = t0;
    } else {
        t0 = $[5];
    }
    return t0;
}
_s3(useCampaign, "/dMy7t63NXD4eYACoT93CePwGrg=");
function useSquad() {
    _s4();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2";
    }
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(GamificationContext);
    let t0;
    if ($[1] !== ctx.myMembership || $[2] !== ctx.mySquad || $[3] !== ctx.squadLeaderboard || $[4] !== ctx.squadLoading || $[5] !== ctx.squadMembers) {
        t0 = {
            mySquad: ctx.mySquad,
            myMembership: ctx.myMembership,
            squadLeaderboard: ctx.squadLeaderboard,
            squadMembers: ctx.squadMembers,
            isLoading: ctx.squadLoading
        };
        $[1] = ctx.myMembership;
        $[2] = ctx.mySquad;
        $[3] = ctx.squadLeaderboard;
        $[4] = ctx.squadLoading;
        $[5] = ctx.squadMembers;
        $[6] = t0;
    } else {
        t0 = $[6];
    }
    return t0;
}
_s4(useSquad, "/dMy7t63NXD4eYACoT93CePwGrg=");
function useSkillTree() {
    _s5();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2";
    }
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(GamificationContext);
    let t0;
    if ($[1] !== ctx.selectedSkillId || $[2] !== ctx.setSelectedSkillId || $[3] !== ctx.skillNodes || $[4] !== ctx.skillTreeLoading) {
        t0 = {
            skillNodes: ctx.skillNodes,
            isLoading: ctx.skillTreeLoading,
            selectedSkillId: ctx.selectedSkillId,
            setSelectedSkillId: ctx.setSelectedSkillId
        };
        $[1] = ctx.selectedSkillId;
        $[2] = ctx.setSelectedSkillId;
        $[3] = ctx.skillNodes;
        $[4] = ctx.skillTreeLoading;
        $[5] = t0;
    } else {
        t0 = $[5];
    }
    return t0;
}
_s5(useSkillTree, "/dMy7t63NXD4eYACoT93CePwGrg=");
function useContentLock() {
    _s6();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2";
    }
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(GamificationContext);
    let t0;
    if ($[1] !== ctx.contentLockLoading || $[2] !== ctx.getLockStatus || $[3] !== ctx.isLocked || $[4] !== ctx.locks) {
        t0 = {
            locks: ctx.locks,
            isLocked: ctx.isLocked,
            getLockStatus: ctx.getLockStatus,
            isLoading: ctx.contentLockLoading
        };
        $[1] = ctx.contentLockLoading;
        $[2] = ctx.getLockStatus;
        $[3] = ctx.isLocked;
        $[4] = ctx.locks;
        $[5] = t0;
    } else {
        t0 = $[5];
    }
    return t0;
}
_s6(useContentLock, "/dMy7t63NXD4eYACoT93CePwGrg=");
function useXP() {
    _s7();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2";
    }
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(GamificationContext);
    let t0;
    if ($[1] !== ctx.avatarUnlockConfig || $[2] !== ctx.level || $[3] !== ctx.sectionLevel || $[4] !== ctx.sectionXP || $[5] !== ctx.totalXP || $[6] !== ctx.xpLoading || $[7] !== ctx.xpLogs) {
        t0 = {
            totalXP: ctx.totalXP,
            sectionXP: ctx.sectionXP,
            level: ctx.level,
            sectionLevel: ctx.sectionLevel,
            xpLogs: ctx.xpLogs,
            isLoading: ctx.xpLoading,
            avatarUnlockConfig: ctx.avatarUnlockConfig
        };
        $[1] = ctx.avatarUnlockConfig;
        $[2] = ctx.level;
        $[3] = ctx.sectionLevel;
        $[4] = ctx.sectionXP;
        $[5] = ctx.totalXP;
        $[6] = ctx.xpLoading;
        $[7] = ctx.xpLogs;
        $[8] = t0;
    } else {
        t0 = $[8];
    }
    return t0;
}
_s7(useXP, "/dMy7t63NXD4eYACoT93CePwGrg=");
function usePlatformSettings() {
    _s8();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cb6a5f11d0eafe6afd480cde8a50d5e27278b0e3d73c21888917493557d817d2";
    }
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(GamificationContext);
    let t0;
    if ($[1] !== ctx.autoAnalyzeDocuments || $[2] !== ctx.avatarUnlockConfig || $[3] !== ctx.platformSettings) {
        t0 = {
            platformSettings: ctx.platformSettings,
            autoAnalyzeDocuments: ctx.autoAnalyzeDocuments,
            avatarUnlockConfig: ctx.avatarUnlockConfig
        };
        $[1] = ctx.autoAnalyzeDocuments;
        $[2] = ctx.avatarUnlockConfig;
        $[3] = ctx.platformSettings;
        $[4] = t0;
    } else {
        t0 = $[4];
    }
    return t0;
}
_s8(usePlatformSettings, "/dMy7t63NXD4eYACoT93CePwGrg=");
// ============================================================================
// XP Toast friendly labels
// ============================================================================
const REASON_LABELS = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].HOMEWORK_SUBMITTED]: 'Homework submitted',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].AI_FEEDBACK_REVISED]: 'Revised after AI feedback',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].ALL_BLOCKS_COMPLETED]: 'All blocks complete',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PEER_REVIEW_GIVEN]: 'Peer review (reviewer)',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PEER_REVIEW_HOSTED]: 'Peer review (host)',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].NAILED_IT]: 'Nailed It!',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].ON_TIME_SUBMISSION]: 'On-time submission',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].STREAK_3DAY]: '3-day streak',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].STREAK_7DAY]: '7-day streak',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].STREAK_14DAY]: '14-day streak',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].STREAK_30DAY]: '30-day streak',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PERFECT_SCORE]: 'Perfect score',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].COMEBACK]: 'Comeback!',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].PERSONAL_BEST]: 'New personal best!',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].EASTER_EGG]: 'Secret discovered!',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPReason"].SQUAD_CHALLENGE_BONUS]: 'Squad challenge bonus'
};
function GamificationProvider({ client, studentId, cohortId, cohortIds = [], moduleNames = {}, earnedBadgeTypes = new Set(), moduleCompletionMap = {}, sections: sectionsProp, assignments: assignmentsProp, children }) {
    _s9();
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gamificationReducer"], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"]);
    // XP toast queue (local state — not in reducer since it triggers UI side-effects)
    const [toastQueue, setToastQueue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [currentToast, setCurrentToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const knownXpIdsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Set());
    const xpInitialLoadRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(true);
    const profileVersionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const challengeVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    const squadVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    const skillVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    const xpLogVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    const unitLockVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    // Stabilize reference-identity of array/object/Set props whose default values
    // (= [], = {}, = new Set()) create new instances on every render, which would
    // cause useEffect/useMemo deps to always appear changed.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    const stableCohortIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[stableCohortIds]": ()=>cohortIds
    }["GamificationProvider.useMemo[stableCohortIds]"], [
        cohortIds.join(',')
    ]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    const stableModuleNames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[stableModuleNames]": ()=>moduleNames
    }["GamificationProvider.useMemo[stableModuleNames]"], [
        JSON.stringify(moduleNames)
    ]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    const stableEarnedBadgeTypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[stableEarnedBadgeTypes]": ()=>earnedBadgeTypes
    }["GamificationProvider.useMemo[stableEarnedBadgeTypes]"], [
        [
            ...earnedBadgeTypes
        ].sort().join(',')
    ]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    const stableModuleCompletionMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[stableModuleCompletionMap]": ()=>moduleCompletionMap
    }["GamificationProvider.useMemo[stableModuleCompletionMap]"], [
        JSON.stringify(moduleCompletionMap)
    ]);
    // Stable setter for selectedSkillId
    const setSelectedSkillId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "GamificationProvider.useCallback[setSelectedSkillId]": (id)=>dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SELECTED_SKILL_ID,
                payload: id
            })
    }["GamificationProvider.useCallback[setSelectedSkillId]"], []);
    // ── Safety timeout: if subscriptions never fire, unblock UI after 5s ──
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            const timer = setTimeout({
                "GamificationProvider.useEffect.timer": ()=>{
                    // Only force-clear if any loading states are still true
                    const stillLoading = state.progressLoading || state.campaignsLoading || state.challengesLoading || state.squadsLoading || state.membershipsLoading || state.skillsLoading || state.skillProgressLoading || state.locksLoading || state.xpLoading;
                    if (!stillLoading) return;
                    console.warn('[GamificationContext] Safety timeout: forcing loading states to false');
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_PROGRESS_LOADING,
                        payload: false
                    });
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_CAMPAIGNS_LOADING,
                        payload: false
                    });
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_CHALLENGES_LOADING,
                        payload: false
                    });
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SQUADS_LOADING,
                        payload: false
                    });
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_MEMBERSHIPS_LOADING,
                        payload: false
                    });
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SKILLS_LOADING,
                        payload: false
                    });
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SKILL_PROGRESS_LOADING,
                        payload: false
                    });
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_LOCKS_LOADING,
                        payload: false
                    });
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_XP_LOADING,
                        payload: false
                    });
                }
            }["GamificationProvider.useEffect.timer"], 5000);
            return ({
                "GamificationProvider.useEffect": ()=>clearTimeout(timer)
            })["GamificationProvider.useEffect"];
        }
    }["GamificationProvider.useEffect"], []);
    // ── StudentProfile subscription (replaces 7 individual model subs) ──
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            if (!client?.models?.StudentProfile || !studentId) {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_PROGRESS_LOADING,
                    payload: false
                });
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SKILL_PROGRESS_LOADING,
                    payload: false
                });
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_LOCKS_LOADING,
                    payload: false
                });
                return;
            }
            const filter = {
                studentId: {
                    eq: studentId
                }
            };
            const processProfile = {
                "GamificationProvider.useEffect.processProfile": (data)=>{
                    const valid = (data || []).filter({
                        "GamificationProvider.useEffect.processProfile.valid": (i)=>i != null && i.id != null
                    }["GamificationProvider.useEffect.processProfile.valid"]);
                    const profile = valid[0];
                    if (!profile) {
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_PROGRESS_LOADING,
                            payload: false
                        });
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SKILL_PROGRESS_LOADING,
                            payload: false
                        });
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_LOCKS_LOADING,
                            payload: false
                        });
                        return;
                    }
                    // Version guard: only rerender if incoming version is greater than expected
                    if (profile._version != null && !(profile._version > profileVersionRef.current)) {
                        return;
                    }
                    profileVersionRef.current = profile._version || 0;
                    // Progress (was StudentProgress)
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_MODULES,
                        payload: profile.moduleProgress || []
                    });
                    // Badges (was StudentBadge)
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_BADGES,
                        payload: profile.badges || []
                    });
                    // Active debuffs from anti-badges
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_DEBUFFS,
                        payload: profile.activeDebuffs || []
                    });
                    // Personal bests (was StudentPersonalBest)
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_PERSONAL_BESTS,
                        payload: (profile.personalBests || []).map({
                            "GamificationProvider.useEffect.processProfile": (pb)=>({
                                    ...pb,
                                    id: pb.unitID
                                })
                        }["GamificationProvider.useEffect.processProfile"])
                    });
                    // Streak (was StudentStreak)
                    if (profile.currentStreak != null) {
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_STREAK,
                            payload: {
                                currentStreak: profile.currentStreak || 0,
                                longestStreak: profile.longestStreak || 0,
                                lastActivityDate: profile.lastActivityDate || '',
                                freezesRemaining: profile.freezesRemaining || 0,
                                freezesUsed: profile.freezesUsed || 0
                            }
                        });
                    }
                    // Skill progress (was StudentSkillProgress)
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_SKILL_PROGRESS,
                        payload: (profile.skillProgress || []).map({
                            "GamificationProvider.useEffect.processProfile": (sp)=>({
                                    ...sp,
                                    id: sp.skillId
                                })
                        }["GamificationProvider.useEffect.processProfile"])
                    });
                // Content locks are derived from Unit model fields (requiredXP, requiredBadgeId,
                // requiredModuleCompletion) — see Unit subscription below. Not stored on profile.
                }
            }["GamificationProvider.useEffect.processProfile"];
            // Single observeQuery replaces list() + onCreate + onUpdate
            const subscription = client.models.StudentProfile.observeQuery({
                filter
            }).subscribe({
                next: {
                    "GamificationProvider.useEffect.subscription": ({ items })=>{
                        processProfile(items);
                    }
                }["GamificationProvider.useEffect.subscription"],
                error: {
                    "GamificationProvider.useEffect.subscription": (err)=>{
                        const msg = err?.message || err?.errors?.[0]?.message || String(err);
                        if (!msg.includes('DuplicatedOperationError')) console.error('[GamificationContext] StudentProfile error:', err);
                    }
                }["GamificationProvider.useEffect.subscription"]
            });
            return ({
                "GamificationProvider.useEffect": ()=>subscription.unsubscribe()
            })["GamificationProvider.useEffect"];
        }
    }["GamificationProvider.useEffect"], [
        client,
        studentId
    ]);
    // ── GroupChallenge subscription (includes campaign + contributions) ──
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            if (!client?.models?.GroupChallenge) {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_CAMPAIGNS_LOADING,
                    payload: false
                });
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_CHALLENGES_LOADING,
                    payload: false
                });
                return;
            }
            const normalizedCohortIds = Array.from(new Set((stableCohortIds || []).filter(Boolean)));
            const primaryCohortId = cohortId || normalizedCohortIds[0];
            if (!primaryCohortId && normalizedCohortIds.length === 0) {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_CAMPAIGNS_LOADING,
                    payload: false
                });
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_CHALLENGES_LOADING,
                    payload: false
                });
                return;
            }
            const cohortSet = new Set(normalizedCohortIds.length > 0 ? normalizedCohortIds : [
                primaryCohortId
            ]);
            const filter = cohortSet.size === 1 ? {
                cohortId: {
                    eq: Array.from(cohortSet)[0]
                }
            } : undefined;
            const processData = {
                "GamificationProvider.useEffect.processData": (data)=>{
                    const valid = (data || []).filter({
                        "GamificationProvider.useEffect.processData.valid": (i)=>i != null && i.id != null
                    }["GamificationProvider.useEffect.processData.valid"]).filter({
                        "GamificationProvider.useEffect.processData.valid": (i)=>cohortSet.has(i.cohortId)
                    }["GamificationProvider.useEffect.processData.valid"]);
                    // Version map guard
                    const hasChanges = valid.some({
                        "GamificationProvider.useEffect.processData.hasChanges": (item)=>{
                            const tracked = challengeVersionMapRef.current[item.id];
                            return tracked == null || item._version > tracked;
                        }
                    }["GamificationProvider.useEffect.processData.hasChanges"]);
                    if (!hasChanges && Object.keys(challengeVersionMapRef.current).length > 0) return;
                    challengeVersionMapRef.current = {};
                    valid.forEach({
                        "GamificationProvider.useEffect.processData": (item)=>{
                            challengeVersionMapRef.current[item.id] = item._version;
                        }
                    }["GamificationProvider.useEffect.processData"]);
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_CHALLENGES,
                        payload: valid
                    });
                    // Extract campaign info deterministically from ordered chapter data.
                    // Prefer the active chapter with the smallest chapterOrder.
                    // Fallback to the smallest chapterOrder overall, then first available.
                    const challengeWithNarrative = valid.filter({
                        "GamificationProvider.useEffect.processData.challengeWithNarrative": (c)=>c.setting || c.stakes
                    }["GamificationProvider.useEffect.processData.challengeWithNarrative"]);
                    const orderedNarrative = [
                        ...challengeWithNarrative
                    ].sort({
                        "GamificationProvider.useEffect.processData.orderedNarrative": (a, b)=>{
                            const aOrder = a.chapterOrder ?? Number.MAX_SAFE_INTEGER;
                            const bOrder = b.chapterOrder ?? Number.MAX_SAFE_INTEGER;
                            return aOrder - bOrder;
                        }
                    }["GamificationProvider.useEffect.processData.orderedNarrative"]);
                    const campaignChallenge = orderedNarrative.find({
                        "GamificationProvider.useEffect.processData": (c)=>c.active !== false
                    }["GamificationProvider.useEffect.processData"]) || orderedNarrative[0] || valid[0];
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_CAMPAIGNS,
                        payload: campaignChallenge ? [
                            campaignChallenge
                        ] : []
                    });
                }
            }["GamificationProvider.useEffect.processData"];
            const subscription = client.models.GroupChallenge.observeQuery(filter ? {
                filter
            } : undefined).subscribe({
                next: {
                    "GamificationProvider.useEffect.subscription": ({ items })=>{
                        processData(items);
                    }
                }["GamificationProvider.useEffect.subscription"],
                error: {
                    "GamificationProvider.useEffect.subscription": (err)=>{
                        const msg = err?.message || err?.errors?.[0]?.message || String(err);
                        if (!msg.includes('DuplicatedOperationError')) console.error('[GamificationContext] GroupChallenge error:', err);
                    }
                }["GamificationProvider.useEffect.subscription"]
            });
            return ({
                "GamificationProvider.useEffect": ()=>subscription.unsubscribe()
            })["GamificationProvider.useEffect"];
        }
    }["GamificationProvider.useEffect"], [
        client,
        cohortId,
        stableCohortIds
    ]);
    // ── Squad subscription (includes members) ───────────────────────
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            if (!client?.models?.Squad) {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SQUADS_LOADING,
                    payload: false
                });
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_MEMBERSHIPS_LOADING,
                    payload: false
                });
                return;
            }
            const filter = cohortId ? {
                cohortId: {
                    eq: cohortId
                }
            } : undefined;
            const processSquads = {
                "GamificationProvider.useEffect.processSquads": (data)=>{
                    const valid = (data || []).filter({
                        "GamificationProvider.useEffect.processSquads.valid": (i)=>i != null && i.id != null
                    }["GamificationProvider.useEffect.processSquads.valid"]);
                    // Version map guard
                    const hasChanges = valid.some({
                        "GamificationProvider.useEffect.processSquads.hasChanges": (item)=>{
                            const tracked = squadVersionMapRef.current[item.id];
                            return tracked == null || item._version > tracked;
                        }
                    }["GamificationProvider.useEffect.processSquads.hasChanges"]);
                    if (!hasChanges && Object.keys(squadVersionMapRef.current).length > 0) return;
                    squadVersionMapRef.current = {};
                    valid.forEach({
                        "GamificationProvider.useEffect.processSquads": (item)=>{
                            squadVersionMapRef.current[item.id] = item._version;
                        }
                    }["GamificationProvider.useEffect.processSquads"]);
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_SQUADS,
                        payload: valid
                    });
                    // Extract memberships from Squad.members arrays
                    const allMemberships = [];
                    for (const squad of valid){
                        for (const member of squad.members || []){
                            allMemberships.push({
                                ...member,
                                id: `${squad.id}-${member.studentId}`,
                                squadId: squad.id
                            });
                        }
                    }
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_MEMBERSHIPS,
                        payload: allMemberships
                    });
                }
            }["GamificationProvider.useEffect.processSquads"];
            const subscription = client.models.Squad.observeQuery(filter ? {
                filter
            } : undefined).subscribe({
                next: {
                    "GamificationProvider.useEffect.subscription": ({ items })=>{
                        processSquads(items);
                    }
                }["GamificationProvider.useEffect.subscription"],
                error: {
                    "GamificationProvider.useEffect.subscription": (err)=>{
                        const msg = err?.message || err?.errors?.[0]?.message || String(err);
                        if (!msg.includes('DuplicatedOperationError')) console.error('[GamificationContext] Squad error:', err);
                    }
                }["GamificationProvider.useEffect.subscription"]
            });
            return ({
                "GamificationProvider.useEffect": ()=>subscription.unsubscribe()
            })["GamificationProvider.useEffect"];
        }
    }["GamificationProvider.useEffect"], [
        client,
        cohortId
    ]);
    // ── Skill definitions subscription ─────────────────────────────
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            if (!client?.models?.Skill) {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SKILLS_LOADING,
                    payload: false
                });
                return;
            }
            const filter = cohortId ? {
                cohortId: {
                    eq: cohortId
                }
            } : undefined;
            const subscription = client.models.Skill.observeQuery(filter ? {
                filter
            } : undefined).subscribe({
                next: {
                    "GamificationProvider.useEffect.subscription": ({ items })=>{
                        const valid = (items || []).filter({
                            "GamificationProvider.useEffect.subscription.valid": (i)=>i != null && i.id != null
                        }["GamificationProvider.useEffect.subscription.valid"]);
                        // Version map guard
                        const hasChanges = valid.some({
                            "GamificationProvider.useEffect.subscription.hasChanges": (item)=>{
                                const tracked = skillVersionMapRef.current[item.id];
                                return tracked == null || item._version > tracked;
                            }
                        }["GamificationProvider.useEffect.subscription.hasChanges"]);
                        if (!hasChanges && Object.keys(skillVersionMapRef.current).length > 0) return;
                        skillVersionMapRef.current = {};
                        valid.forEach({
                            "GamificationProvider.useEffect.subscription": (item)=>{
                                skillVersionMapRef.current[item.id] = item._version;
                            }
                        }["GamificationProvider.useEffect.subscription"]);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_SKILLS,
                            payload: valid
                        });
                    }
                }["GamificationProvider.useEffect.subscription"],
                error: {
                    "GamificationProvider.useEffect.subscription": (err)=>{
                        const msg = err?.message || err?.errors?.[0]?.message || String(err);
                        if (!msg.includes('DuplicatedOperationError')) console.error('[GamificationContext] Skill error:', err);
                    }
                }["GamificationProvider.useEffect.subscription"]
            });
            return ({
                "GamificationProvider.useEffect": ()=>subscription.unsubscribe()
            })["GamificationProvider.useEffect"];
        }
    }["GamificationProvider.useEffect"], [
        client,
        cohortId
    ]);
    // ── Unit subscription (content lock fields) ─────────────────────
    // Reads requiredXP, requiredBadgeId, requiredModuleCompletion from
    // published units to derive content locks. This is the source of truth
    // for XP/badge/completion gates — NOT StudentProfile.contentLocks.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            if (!client?.models?.Unit) {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_LOCKS_LOADING,
                    payload: false
                });
                return;
            }
            const subscription = client.models.Unit.observeQuery({
                filter: {
                    status: {
                        eq: 'PUBLISHED'
                    }
                }
            }).subscribe({
                next: {
                    "GamificationProvider.useEffect.subscription": ({ items })=>{
                        const valid = (items || []).filter({
                            "GamificationProvider.useEffect.subscription.valid": (u)=>u != null && u.id != null && u.deletedAt == null
                        }["GamificationProvider.useEffect.subscription.valid"]);
                        // Version map guard
                        const hasChanges = valid.some({
                            "GamificationProvider.useEffect.subscription.hasChanges": (item)=>{
                                const tracked = unitLockVersionMapRef.current[item.id];
                                return tracked == null || item._version > tracked;
                            }
                        }["GamificationProvider.useEffect.subscription.hasChanges"]);
                        if (!hasChanges && Object.keys(unitLockVersionMapRef.current).length > 0) return;
                        unitLockVersionMapRef.current = {};
                        valid.forEach({
                            "GamificationProvider.useEffect.subscription": (item)=>{
                                unitLockVersionMapRef.current[item.id] = item._version;
                            }
                        }["GamificationProvider.useEffect.subscription"]);
                        // Extract units that have at least one lock requirement set
                        const lockData = valid.filter({
                            "GamificationProvider.useEffect.subscription.lockData": (u)=>u.requiredXP != null && u.requiredXP > 0 || u.requiredBadgeId || u.requiredModuleCompletion != null && u.requiredModuleCompletion > 0
                        }["GamificationProvider.useEffect.subscription.lockData"]).map({
                            "GamificationProvider.useEffect.subscription.lockData": (u)=>({
                                    contentId: u.id,
                                    requiredXP: u.requiredXP || undefined,
                                    requiredBadgeId: u.requiredBadgeId || undefined,
                                    requiredModuleCompletion: u.requiredModuleCompletion || undefined
                                })
                        }["GamificationProvider.useEffect.subscription.lockData"]);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_LOCKS,
                            payload: lockData
                        });
                    }
                }["GamificationProvider.useEffect.subscription"],
                error: {
                    "GamificationProvider.useEffect.subscription": (err)=>{
                        const msg = err?.message || err?.errors?.[0]?.message || String(err);
                        if (!msg.includes('DuplicatedOperationError')) console.error('[GamificationContext] Unit lock error:', err);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_LOCKS_LOADING,
                            payload: false
                        });
                    }
                }["GamificationProvider.useEffect.subscription"]
            });
            return ({
                "GamificationProvider.useEffect": ()=>subscription.unsubscribe()
            })["GamificationProvider.useEffect"];
        }
    }["GamificationProvider.useEffect"], [
        client
    ]);
    // ── PlatformSettings subscription (global singleton) ────────
    // One record for the whole platform: XP multipliers, level thresholds,
    // avatar unlock config, badge toggles, caps, AI settings. Admin-only write.
    const [globalSettings, setGlobalSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            if (!client?.models?.PlatformSettings) return;
            const subscription = client.models.PlatformSettings.observeQuery().subscribe({
                next: {
                    "GamificationProvider.useEffect.subscription": ({ items })=>{
                        const valid = (items || []).filter({
                            "GamificationProvider.useEffect.subscription.valid": (item)=>item != null && item.id != null
                        }["GamificationProvider.useEffect.subscription.valid"]);
                        // Take the first (and only) record
                        setGlobalSettings(valid[0] || null);
                    }
                }["GamificationProvider.useEffect.subscription"],
                error: {
                    "GamificationProvider.useEffect.subscription": (err)=>{
                        const msg = err?.message || err?.errors?.[0]?.message || err?.error?.errors?.[0]?.message || String(err);
                        if (!msg.includes('DuplicatedOperationError')) {
                            console.warn('[GamificationContext] PlatformSettings error:', msg);
                        }
                    }
                }["GamificationProvider.useEffect.subscription"]
            });
            return ({
                "GamificationProvider.useEffect": ()=>subscription.unsubscribe()
            })["GamificationProvider.useEffect"];
        }
    }["GamificationProvider.useEffect"], [
        client
    ]);
    // ── Linear Lock data (Sections, Assignments, Grades) ───────────
    // Sections and Assignments are accepted from parent contexts via props —
    // zero additional API calls for those models.
    // Grades are fetched only when a section actually has linearLockEnabled,
    // since no existing context provides all grades across all units.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            if (sectionsProp !== undefined) {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_SECTIONS,
                    payload: sectionsProp
                });
            } else {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SECTIONS_LOADING,
                    payload: false
                });
            }
        }
    }["GamificationProvider.useEffect"], [
        sectionsProp
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            if (assignmentsProp !== undefined) {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_ASSIGNMENTS,
                    payload: assignmentsProp
                });
            } else {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_ASSIGNMENTS_LOADING,
                    payload: false
                });
            }
        }
    }["GamificationProvider.useEffect"], [
        assignmentsProp
    ]);
    // Grades: fetch only when linear lock is enabled on at least one section
    const gradesFetchedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            const hasLinearLock = (sectionsProp || []).some({
                "GamificationProvider.useEffect.hasLinearLock": (s)=>s?.linearLockEnabled
            }["GamificationProvider.useEffect.hasLinearLock"]);
            if (!hasLinearLock || !client?.models?.Grade || !studentId || gradesFetchedRef.current) {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_GRADES_LOADING,
                    payload: false
                });
                return;
            }
            gradesFetchedRef.current = true;
            client.models.Grade.list().then({
                "GamificationProvider.useEffect": ({ data })=>{
                    const valid = (data || []).filter({
                        "GamificationProvider.useEffect.valid": (g)=>g != null && g.id != null
                    }["GamificationProvider.useEffect.valid"]);
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_RAW_GRADES,
                        payload: valid
                    });
                }
            }["GamificationProvider.useEffect"]).catch({
                "GamificationProvider.useEffect": (err)=>{
                    console.error('[GamificationContext] Grade fetch for linear lock error:', err);
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_GRADES_LOADING,
                        payload: false
                    });
                }
            }["GamificationProvider.useEffect"]);
        }
    }["GamificationProvider.useEffect"], [
        sectionsProp,
        client,
        studentId
    ]);
    // ── XP subscription ─────────────────────────────────────────────
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            if (!client?.models?.StudentXPLog || !studentId) {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_XP_LOADING,
                    payload: false
                });
                return;
            }
            const filter = {
                studentId: {
                    eq: studentId
                }
            };
            const processXPLogs = {
                "GamificationProvider.useEffect.processXPLogs": (data)=>{
                    const valid = (data || []).filter({
                        "GamificationProvider.useEffect.processXPLogs.valid": (i)=>i != null && i.id != null
                    }["GamificationProvider.useEffect.processXPLogs.valid"]);
                    // Version map guard
                    const hasChanges = valid.some({
                        "GamificationProvider.useEffect.processXPLogs.hasChanges": (item)=>{
                            const tracked = xpLogVersionMapRef.current[item.id];
                            return tracked == null || item._version > tracked;
                        }
                    }["GamificationProvider.useEffect.processXPLogs.hasChanges"]);
                    if (!hasChanges && Object.keys(xpLogVersionMapRef.current).length > 0) return;
                    xpLogVersionMapRef.current = {};
                    valid.forEach({
                        "GamificationProvider.useEffect.processXPLogs": (item)=>{
                            xpLogVersionMapRef.current[item.id] = item._version;
                        }
                    }["GamificationProvider.useEffect.processXPLogs"]);
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$gamificationReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_XP_LOGS,
                        payload: valid
                    });
                    // Queue toasts for new entries (skip initial load)
                    if (!xpInitialLoadRef.current) {
                        const newEntries = valid.filter({
                            "GamificationProvider.useEffect.processXPLogs.newEntries": (item)=>!knownXpIdsRef.current.has(item.id)
                        }["GamificationProvider.useEffect.processXPLogs.newEntries"]);
                        for (const entry of newEntries){
                            setToastQueue({
                                "GamificationProvider.useEffect.processXPLogs": (prev)=>[
                                        ...prev,
                                        {
                                            id: entry.id,
                                            xpAmount: entry.xpAmount,
                                            xpReason: REASON_LABELS[entry.reason] || entry.reason
                                        }
                                    ]
                            }["GamificationProvider.useEffect.processXPLogs"]);
                        }
                    }
                    knownXpIdsRef.current = new Set(valid.map({
                        "GamificationProvider.useEffect.processXPLogs": (item)=>item.id
                    }["GamificationProvider.useEffect.processXPLogs"]));
                    xpInitialLoadRef.current = false;
                }
            }["GamificationProvider.useEffect.processXPLogs"];
            const subscription = client.models.StudentXPLog.observeQuery({
                filter
            }).subscribe({
                next: {
                    "GamificationProvider.useEffect.subscription": ({ items })=>{
                        processXPLogs(items);
                    }
                }["GamificationProvider.useEffect.subscription"],
                error: {
                    "GamificationProvider.useEffect.subscription": (err)=>{
                        const msg = err?.message || err?.errors?.[0]?.message || String(err);
                        if (!msg.includes('DuplicatedOperationError')) console.error('[GamificationContext] XPLog error:', err);
                    }
                }["GamificationProvider.useEffect.subscription"]
            });
            return ({
                "GamificationProvider.useEffect": ()=>subscription.unsubscribe()
            })["GamificationProvider.useEffect"];
        }
    }["GamificationProvider.useEffect"], [
        client,
        studentId
    ]);
    // ── XP toast queue — show one at a time ─────────────────────────
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            if (currentToast || toastQueue.length === 0) return;
            const [next, ...rest] = toastQueue;
            setCurrentToast(next);
            setToastQueue(rest);
        }
    }["GamificationProvider.useEffect"], [
        toastQueue,
        currentToast
    ]);
    const handleToastClose = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "GamificationProvider.useCallback[handleToastClose]": ()=>setCurrentToast(null)
    }["GamificationProvider.useCallback[handleToastClose]"], []);
    // ── Derived: XP ─────────────────────────────────────────────────
    // Parse multipliers and level thresholds from global settings
    const xpMultipliers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[xpMultipliers]": ()=>{
            if (!globalSettings?.xpMultipliers) return null;
            try {
                return typeof globalSettings.xpMultipliers === 'string' ? JSON.parse(globalSettings.xpMultipliers) : globalSettings.xpMultipliers;
            } catch  {
                return null;
            }
        }
    }["GamificationProvider.useMemo[xpMultipliers]"], [
        globalSettings?.xpMultipliers
    ]);
    const dbLevelThresholds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[dbLevelThresholds]": ()=>{
            if (!globalSettings?.levelThresholds) return null;
            try {
                const parsed = typeof globalSettings.levelThresholds === 'string' ? JSON.parse(globalSettings.levelThresholds) : globalSettings.levelThresholds;
                return Array.isArray(parsed) && parsed.length > 0 ? parsed : null;
            } catch  {
                return null;
            }
        }
    }["GamificationProvider.useMemo[dbLevelThresholds]"], [
        globalSettings?.levelThresholds
    ]);
    // Total XP applies multipliers globally (all logs)
    const computedTotalXP = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[computedTotalXP]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateMultipliedXP"])(state.xpLogs, xpMultipliers)
    }["GamificationProvider.useMemo[computedTotalXP]"], [
        state.xpLogs,
        xpMultipliers
    ]);
    // Level uses DB thresholds when configured, otherwise hardcoded defaults
    const level = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[level]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLevelInfoWithThresholds"])(computedTotalXP, dbLevelThresholds)
    }["GamificationProvider.useMemo[level]"], [
        computedTotalXP,
        dbLevelThresholds
    ]);
    // Section-scoped XP: only XP logs matching the current cohortId
    const computedSectionXP = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[computedSectionXP]": ()=>{
            if (!cohortId) return 0;
            const sectionLogs = state.xpLogs.filter({
                "GamificationProvider.useMemo[computedSectionXP].sectionLogs": (log)=>log.cohortId === cohortId
            }["GamificationProvider.useMemo[computedSectionXP].sectionLogs"]);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateMultipliedXP"])(sectionLogs, xpMultipliers);
        }
    }["GamificationProvider.useMemo[computedSectionXP]"], [
        state.xpLogs,
        cohortId,
        xpMultipliers
    ]);
    const sectionLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[sectionLevel]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLevelInfoWithThresholds"])(computedSectionXP, dbLevelThresholds)
    }["GamificationProvider.useMemo[sectionLevel]"], [
        computedSectionXP,
        dbLevelThresholds
    ]);
    // Avatar unlock config from global settings
    const avatarUnlockConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[avatarUnlockConfig]": ()=>{
            if (!globalSettings?.avatarUnlockConfig) return null;
            try {
                const parsed = typeof globalSettings.avatarUnlockConfig === 'string' ? JSON.parse(globalSettings.avatarUnlockConfig) : globalSettings.avatarUnlockConfig;
                return parsed?.unlocks?.length ? parsed : null;
            } catch  {
                return null;
            }
        }
    }["GamificationProvider.useMemo[avatarUnlockConfig]"], [
        globalSettings?.avatarUnlockConfig
    ]);
    // ── Derived: Progress ───────────────────────────────────────────
    const modules = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[modules]": ()=>state.rawModules.map({
                "GamificationProvider.useMemo[modules]": (m)=>({
                        moduleId: m.moduleId,
                        moduleName: stableModuleNames[m.moduleId] || m.moduleId,
                        completionPercent: m.completionPercent || 0,
                        totalWorkbooks: m.totalWorkbooks || 0,
                        completedWorkbooks: m.completedWorkbooks || 0
                    })
            }["GamificationProvider.useMemo[modules]"])
    }["GamificationProvider.useMemo[modules]"], [
        state.rawModules,
        stableModuleNames
    ]);
    const personalBests = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[personalBests]": ()=>state.rawPersonalBests.map({
                "GamificationProvider.useMemo[personalBests]": (pb)=>({
                        id: pb.id,
                        unitID: pb.unitID,
                        bestScore: pb.bestScore,
                        previousBest: pb.previousBest ?? null,
                        achievedAt: pb.achievedAt || ''
                    })
            }["GamificationProvider.useMemo[personalBests]"])
    }["GamificationProvider.useMemo[personalBests]"], [
        state.rawPersonalBests
    ]);
    const badges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[badges]": ()=>(state.rawBadges || []).map({
                "GamificationProvider.useMemo[badges]": (b)=>({
                        badgeType: b.badgeType,
                        sourceId: b.sourceId || null,
                        awardedAt: b.awardedAt || null,
                        cohortId: b.cohortId || null,
                        unitID: b.unitID || null,
                        isAnti: b.isAnti || false,
                        count: b.count || 1
                    })
            }["GamificationProvider.useMemo[badges]"])
    }["GamificationProvider.useMemo[badges]"], [
        state.rawBadges
    ]);
    const activeDebuffs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[activeDebuffs]": ()=>{
            try {
                const raw = typeof state.rawDebuffs === 'string' ? JSON.parse(state.rawDebuffs || '[]') : state.rawDebuffs || [];
                const now = Date.now();
                return raw.filter({
                    "GamificationProvider.useMemo[activeDebuffs]": (d)=>d && d.expiresAt && new Date(d.expiresAt).getTime() > now
                }["GamificationProvider.useMemo[activeDebuffs]"]);
            } catch  {
                return [];
            }
        }
    }["GamificationProvider.useMemo[activeDebuffs]"], [
        state.rawDebuffs
    ]);
    const hasActiveDebuff = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "GamificationProvider.useCallback[hasActiveDebuff]": (badgeType)=>activeDebuffs.some({
                "GamificationProvider.useCallback[hasActiveDebuff]": (d)=>d.badgeType === badgeType
            }["GamificationProvider.useCallback[hasActiveDebuff]"])
    }["GamificationProvider.useCallback[hasActiveDebuff]"], [
        activeDebuffs
    ]);
    // ── Derived: Campaign ───────────────────────────────────────────
    const campaign = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[campaign]": ()=>{
            if (state.rawCampaigns.length === 0) return null;
            const c = state.rawCampaigns[0];
            return {
                id: c.id,
                cohortId: c.cohortId,
                title: c.title,
                setting: c.setting,
                stakes: c.stakes,
                systemPromptSeed: c.systemPromptSeed
            };
        }
    }["GamificationProvider.useMemo[campaign]"], [
        state.rawCampaigns
    ]);
    const { activeChallenges, completedChallenges } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo": ()=>{
            const active = [];
            const completed = [];
            state.rawChallenges.forEach({
                "GamificationProvider.useMemo": (ch)=>{
                    const info = {
                        id: ch.id,
                        cohortId: ch.cohortId,
                        title: ch.title,
                        targetXP: ch.targetXP,
                        currentXP: ch.currentXP || 0,
                        deadline: ch.deadline,
                        active: ch.active !== false,
                        bonusMultiplier: ch.bonusMultiplier || 1.5,
                        chapterOrder: ch.chapterOrder,
                        setting: ch.setting,
                        stakes: ch.stakes,
                        linkedUnitIds: ch.linkedUnitIds || [],
                        contributions: ch.contributions || [],
                        progressPercent: ch.targetXP > 0 ? Math.min(100, Math.round((ch.currentXP || 0) / ch.targetXP * 100)) : 0
                    };
                    if (info.active) active.push(info);
                    else completed.push(info);
                }
            }["GamificationProvider.useMemo"]);
            return {
                activeChallenges: active,
                completedChallenges: completed
            };
        }
    }["GamificationProvider.useMemo"], [
        state.rawChallenges
    ]);
    // ── Chapter-unlock celebration detection ────────────────────────
    const prevCompletedIdsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Set());
    const [chapterCelebration, setChapterCelebration] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        open: false,
        title: '',
        order: null,
        nextTitle: null
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamificationProvider.useEffect": ()=>{
            if (completedChallenges.length === 0) return;
            const currentIds = new Set(completedChallenges.map({
                "GamificationProvider.useEffect": (c)=>c.id
            }["GamificationProvider.useEffect"]));
            const prevIds = prevCompletedIdsRef.current;
            // Skip first mount — just record baseline
            if (prevIds.size === 0) {
                prevCompletedIdsRef.current = currentIds;
                return;
            }
            // Find newly completed challenges
            for (const ch of completedChallenges){
                if (!prevIds.has(ch.id)) {
                    // Find next chapter in sequence
                    const allSorted = [
                        ...activeChallenges,
                        ...completedChallenges
                    ].sort({
                        "GamificationProvider.useEffect.allSorted": (a, b)=>(a.chapterOrder || 0) - (b.chapterOrder || 0)
                    }["GamificationProvider.useEffect.allSorted"]);
                    const idx = allSorted.findIndex({
                        "GamificationProvider.useEffect.idx": (c)=>c.id === ch.id
                    }["GamificationProvider.useEffect.idx"]);
                    const next = idx >= 0 && idx < allSorted.length - 1 ? allSorted[idx + 1] : null;
                    setChapterCelebration({
                        open: true,
                        title: ch.title,
                        order: ch.chapterOrder ?? null,
                        nextTitle: next?.title ?? null
                    });
                    break; // One celebration at a time
                }
            }
            prevCompletedIdsRef.current = currentIds;
        }
    }["GamificationProvider.useEffect"], [
        completedChallenges,
        activeChallenges
    ]);
    // ── Derived: Squad ──────────────────────────────────────────────
    const myMembership = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[myMembership]": ()=>{
            const found = state.rawMemberships.find({
                "GamificationProvider.useMemo[myMembership].found": (m)=>m.studentId === studentId
            }["GamificationProvider.useMemo[myMembership].found"]);
            if (!found) return null;
            return {
                id: found.id,
                squadId: found.squadId,
                studentId: found.studentId,
                role: found.role || 'MEMBER',
                joinedAt: found.joinedAt
            };
        }
    }["GamificationProvider.useMemo[myMembership]"], [
        state.rawMemberships,
        studentId
    ]);
    const memberCountMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[memberCountMap]": ()=>{
            const counts = new Map();
            state.rawMemberships.forEach({
                "GamificationProvider.useMemo[memberCountMap]": (m)=>{
                    counts.set(m.squadId, (counts.get(m.squadId) || 0) + 1);
                }
            }["GamificationProvider.useMemo[memberCountMap]"]);
            return counts;
        }
    }["GamificationProvider.useMemo[memberCountMap]"], [
        state.rawMemberships
    ]);
    const squadLeaderboard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[squadLeaderboard]": ()=>state.rawSquads.map({
                "GamificationProvider.useMemo[squadLeaderboard]": (g)=>({
                        id: g.id,
                        name: g.name,
                        cohortId: g.cohortId,
                        totalXP: g.totalXP || 0,
                        crestSvg: g.crestSvg || null,
                        description: g.description,
                        memberCount: memberCountMap.get(g.id) || 0,
                        members: (g.members || []).map({
                            "GamificationProvider.useMemo[squadLeaderboard]": (m)=>({
                                    studentId: m.studentId,
                                    role: m.role,
                                    avatarStyle: m.avatarStyle,
                                    avatarOverrides: typeof m.avatarOverrides === 'string' ? JSON.parse(m.avatarOverrides) : m.avatarOverrides,
                                    avatarSeed: m.avatarSeed || m.studentId
                                })
                        }["GamificationProvider.useMemo[squadLeaderboard]"]),
                        posts: g.posts || []
                    })
            }["GamificationProvider.useMemo[squadLeaderboard]"]).sort({
                "GamificationProvider.useMemo[squadLeaderboard]": (a, b)=>b.totalXP - a.totalXP
            }["GamificationProvider.useMemo[squadLeaderboard]"])
    }["GamificationProvider.useMemo[squadLeaderboard]"], [
        state.rawSquads,
        memberCountMap
    ]);
    const mySquad = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[mySquad]": ()=>{
            if (!myMembership) return null;
            return squadLeaderboard.find({
                "GamificationProvider.useMemo[mySquad]": (g)=>g.id === myMembership.squadId
            }["GamificationProvider.useMemo[mySquad]"]) || null;
        }
    }["GamificationProvider.useMemo[mySquad]"], [
        myMembership,
        squadLeaderboard
    ]);
    const squadMembers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[squadMembers]": ()=>{
            if (!myMembership) return [];
            return state.rawMemberships.filter({
                "GamificationProvider.useMemo[squadMembers]": (m)=>m.squadId === myMembership.squadId
            }["GamificationProvider.useMemo[squadMembers]"]).map({
                "GamificationProvider.useMemo[squadMembers]": (m)=>({
                        id: m.id,
                        squadId: m.squadId,
                        studentId: m.studentId,
                        role: m.role || 'MEMBER',
                        joinedAt: m.joinedAt
                    })
            }["GamificationProvider.useMemo[squadMembers]"]);
        }
    }["GamificationProvider.useMemo[squadMembers]"], [
        state.rawMemberships,
        myMembership
    ]);
    // ── Derived: SkillTree ──────────────────────────────────────────
    const skillNodes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[skillNodes]": ()=>{
            const progressBySkill = new Map(state.rawSkillProgress.map({
                "GamificationProvider.useMemo[skillNodes]": (p)=>[
                        p.skillId,
                        p.status
                    ]
            }["GamificationProvider.useMemo[skillNodes]"]));
            return state.rawSkills.map({
                "GamificationProvider.useMemo[skillNodes]": (skill)=>{
                    const status = progressBySkill.get(skill.id) || 'LOCKED';
                    let prerequisites = [];
                    if (skill.prerequisites) {
                        try {
                            const parsed = typeof skill.prerequisites === 'string' ? JSON.parse(skill.prerequisites) : skill.prerequisites;
                            if (Array.isArray(parsed)) prerequisites = parsed;
                        } catch  {
                        // ignore malformed
                        }
                    }
                    return {
                        skillId: skill.id,
                        title: skill.title,
                        description: skill.description || undefined,
                        status,
                        xpReward: skill.xpReward ?? undefined,
                        prerequisites,
                        cohortId: skill.cohortId || undefined
                    };
                }
            }["GamificationProvider.useMemo[skillNodes]"]);
        }
    }["GamificationProvider.useMemo[skillNodes]"], [
        state.rawSkills,
        state.rawSkillProgress
    ]);
    // ── Derived: ContentLock ────────────────────────────────────────
    const locks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[locks]": ()=>{
            return state.rawLocks.map({
                "GamificationProvider.useMemo[locks]": (lock)=>{
                    let isLockedVal = false;
                    const status = {
                        contentId: lock.contentId,
                        isLocked: false
                    };
                    if (lock.requiredXP != null && lock.requiredXP > 0) {
                        status.requiredXP = lock.requiredXP;
                        status.currentXP = computedTotalXP;
                        if (computedTotalXP < lock.requiredXP) isLockedVal = true;
                    }
                    if (lock.requiredBadgeId) {
                        status.requiredBadge = lock.requiredBadgeId;
                        status.hasBadge = stableEarnedBadgeTypes.has(lock.requiredBadgeId);
                        if (!status.hasBadge) isLockedVal = true;
                    }
                    if (lock.requiredModuleCompletion != null && lock.requiredModuleCompletion > 0) {
                        const requiredPercent = Math.round(lock.requiredModuleCompletion * 100);
                        const currentPercent = stableModuleCompletionMap[lock.contentId] || 0;
                        status.requiredCompletion = requiredPercent;
                        status.currentCompletion = currentPercent;
                        if (currentPercent < requiredPercent) isLockedVal = true;
                    }
                    status.isLocked = isLockedVal;
                    return status;
                }
            }["GamificationProvider.useMemo[locks]"]);
        }
    }["GamificationProvider.useMemo[locks]"], [
        state.rawLocks,
        computedTotalXP,
        stableEarnedBadgeTypes,
        stableModuleCompletionMap
    ]);
    // ── Derived: Linear Lock (sequential by due date) ───────────────
    const linearLocks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[linearLocks]": ()=>{
            // Find sections with linearLockEnabled
            const linearSections = state.rawSections.filter({
                "GamificationProvider.useMemo[linearLocks].linearSections": (s)=>s.linearLockEnabled
            }["GamificationProvider.useMemo[linearLocks].linearSections"]);
            if (linearSections.length === 0) return [];
            const completedUnitIds = new Set(state.rawGrades.filter({
                "GamificationProvider.useMemo[linearLocks]": (g)=>g.complete
            }["GamificationProvider.useMemo[linearLocks]"]).map({
                "GamificationProvider.useMemo[linearLocks]": (g)=>g.unitID
            }["GamificationProvider.useMemo[linearLocks]"]));
            const now = new Date();
            const result = [];
            for (const section of linearSections){
                // Get assignments for this section, sorted by dueDate ascending
                const sectionAssignments = state.rawAssignments.filter({
                    "GamificationProvider.useMemo[linearLocks].sectionAssignments": (a)=>a.sectionID === section.id && a.dueDate
                }["GamificationProvider.useMemo[linearLocks].sectionAssignments"]).sort({
                    "GamificationProvider.useMemo[linearLocks].sectionAssignments": (a, b)=>new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
                }["GamificationProvider.useMemo[linearLocks].sectionAssignments"]);
                if (sectionAssignments.length < 2) continue;
                // First assignment is always unlocked; subsequent ones require prior completion
                // OR their unlockDate has passed
                let blocked = false;
                for(let i = 1; i < sectionAssignments.length; i++){
                    const prevAssignment = sectionAssignments[i - 1];
                    const currentAssignment = sectionAssignments[i];
                    if (!blocked && !completedUnitIds.has(prevAssignment.unitID)) {
                        blocked = true;
                    }
                    if (blocked) {
                        // Check if date-based unlock overrides the linear lock
                        const unlockDate = currentAssignment.unlockDate;
                        const unlockedByDate = unlockDate && new Date(unlockDate) <= now;
                        if (!unlockedByDate) {
                            result.push({
                                contentId: currentAssignment.unitID,
                                isLocked: true,
                                requiredPriorUnitId: prevAssignment.unitID,
                                unlockDate: unlockDate || undefined
                            });
                        }
                    }
                }
                // Also apply linear lock to challenges (chapters) in this section
                const sectionChallenges = state.rawChallenges.filter({
                    "GamificationProvider.useMemo[linearLocks].sectionChallenges": (c)=>c.cohortId === section.id && c.chapterOrder != null
                }["GamificationProvider.useMemo[linearLocks].sectionChallenges"]).sort({
                    "GamificationProvider.useMemo[linearLocks].sectionChallenges": (a, b)=>(a.chapterOrder || 0) - (b.chapterOrder || 0)
                }["GamificationProvider.useMemo[linearLocks].sectionChallenges"]);
                if (sectionChallenges.length >= 2) {
                    let challengeBlocked = false;
                    for(let i = 1; i < sectionChallenges.length; i++){
                        const prevChallenge = sectionChallenges[i - 1];
                        const currentChallenge = sectionChallenges[i];
                        // A challenge chapter is "complete" when currentXP >= targetXP or active === false
                        const prevComplete = !prevChallenge.active || (prevChallenge.currentXP || 0) >= prevChallenge.targetXP;
                        if (!challengeBlocked && !prevComplete) {
                            challengeBlocked = true;
                        }
                        if (challengeBlocked) {
                            const unlockDate = currentChallenge.unlockDate;
                            const unlockedByDate = unlockDate && new Date(unlockDate) <= now;
                            if (!unlockedByDate) {
                                result.push({
                                    contentId: currentChallenge.id,
                                    isLocked: true,
                                    requiredPriorUnitId: prevChallenge.id,
                                    requiredPriorUnitName: prevChallenge.title,
                                    unlockDate: unlockDate || undefined
                                });
                            }
                        }
                    }
                }
            }
            return result;
        }
    }["GamificationProvider.useMemo[linearLocks]"], [
        state.rawSections,
        state.rawAssignments,
        state.rawGrades,
        state.rawChallenges
    ]);
    // ── Combined lock map (ContentLock + Linear Lock) ───────────────
    const lockMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[lockMap]": ()=>{
            const map = new Map(locks.map({
                "GamificationProvider.useMemo[lockMap]": (l)=>[
                        l.contentId,
                        l
                    ]
            }["GamificationProvider.useMemo[lockMap]"]));
            // Merge linear locks — if already locked by ContentLock, keep that; otherwise add linear lock
            for (const ll of linearLocks){
                const existing = map.get(ll.contentId);
                if (existing) {
                    // Already locked by ContentLock — add linear lock info
                    if (!existing.isLocked) {
                        map.set(ll.contentId, {
                            ...existing,
                            ...ll
                        });
                    } else {
                        // Both locked — merge the linear fields into existing
                        map.set(ll.contentId, {
                            ...existing,
                            requiredPriorUnitId: ll.requiredPriorUnitId
                        });
                    }
                } else {
                    map.set(ll.contentId, ll);
                }
            }
            return map;
        }
    }["GamificationProvider.useMemo[lockMap]"], [
        locks,
        linearLocks
    ]);
    const isLockedFn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "GamificationProvider.useCallback[isLockedFn]": (contentId)=>lockMap.get(contentId)?.isLocked ?? false
    }["GamificationProvider.useCallback[isLockedFn]"], [
        lockMap
    ]);
    const getLockStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "GamificationProvider.useCallback[getLockStatus]": (contentId)=>lockMap.get(contentId)
    }["GamificationProvider.useCallback[getLockStatus]"], [
        lockMap
    ]);
    // ── Loading flags ───────────────────────────────────────────────
    const campaignLoading = state.campaignsLoading || state.challengesLoading;
    const squadLoading = state.squadsLoading || state.membershipsLoading;
    const skillTreeLoading = state.skillsLoading || state.skillProgressLoading;
    const isLoading = state.xpLoading || state.progressLoading || campaignLoading || squadLoading || skillTreeLoading || state.locksLoading;
    // ── Context value ───────────────────────────────────────────────
    const contextValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamificationProvider.useMemo[contextValue]": ()=>({
                // XP
                totalXP: computedTotalXP,
                sectionXP: computedSectionXP,
                level,
                sectionLevel,
                xpLogs: state.xpLogs,
                xpLoading: state.xpLoading,
                // Progress
                modules,
                personalBests,
                badges,
                activeDebuffs,
                hasActiveDebuff,
                streak: state.streak,
                progressLoading: state.progressLoading,
                // Campaign
                campaign,
                activeChallenges,
                completedChallenges,
                campaignLoading,
                // Squad
                mySquad,
                myMembership,
                squadLeaderboard,
                squadMembers,
                squadLoading,
                // SkillTree
                skillNodes,
                skillTreeLoading,
                selectedSkillId: state.selectedSkillId,
                setSelectedSkillId,
                // ContentLock
                locks,
                isLocked: isLockedFn,
                getLockStatus,
                contentLockLoading: state.locksLoading,
                // Global settings
                avatarUnlockConfig,
                platformSettings: globalSettings,
                autoAnalyzeDocuments: globalSettings?.autoAnalyzeDocuments !== false,
                // Overall
                isLoading
            })
    }["GamificationProvider.useMemo[contextValue]"], [
        computedTotalXP,
        computedSectionXP,
        level,
        sectionLevel,
        state.xpLogs,
        state.xpLoading,
        modules,
        personalBests,
        badges,
        activeDebuffs,
        hasActiveDebuff,
        state.streak,
        state.progressLoading,
        campaign,
        activeChallenges,
        completedChallenges,
        campaignLoading,
        mySquad,
        myMembership,
        squadLeaderboard,
        squadMembers,
        squadLoading,
        skillNodes,
        skillTreeLoading,
        state.selectedSkillId,
        setSelectedSkillId,
        locks,
        isLockedFn,
        getLockStatus,
        state.locksLoading,
        avatarUnlockConfig,
        globalSettings,
        isLoading
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(GamificationContext.Provider, {
        value: contextValue,
        children: [
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$XPToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XPToast"], {
                open: currentToast != null,
                xpAmount: currentToast?.xpAmount || 0,
                xpReason: currentToast?.xpReason || '',
                onClose: handleToastClose
            }, void 0, false, {
                fileName: "[project]/src/context/gamificationContext.tsx",
                lineNumber: 1507,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ChapterUnlockCelebration$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChapterUnlockCelebration"], {
                open: chapterCelebration.open,
                chapterTitle: chapterCelebration.title,
                chapterOrder: chapterCelebration.order,
                nextChapterTitle: chapterCelebration.nextTitle,
                onClose: ()=>setChapterCelebration((prev)=>({
                            ...prev,
                            open: false
                        }))
            }, void 0, false, {
                fileName: "[project]/src/context/gamificationContext.tsx",
                lineNumber: 1508,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/context/gamificationContext.tsx",
        lineNumber: 1505,
        columnNumber: 10
    }, this);
}
_s9(GamificationProvider, "T9YQywUGzQiMziD+In01qssBFqs=");
_c = GamificationProvider;
const __TURBOPACK__default__export__ = GamificationContext;
var _c;
__turbopack_context__.k.register(_c, "GamificationProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/notificationContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NotificationProvider",
    ()=>NotificationProvider,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useNotifications",
    ()=>useNotifications,
    "useUnseenCount",
    ()=>useUnseenCount
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * NotificationContext — Real-time notification feed for the current user.
 *
 * Uses AppSync `observeQuery()` filtered by `recipientId` to deliver
 * notifications in real-time. Computes unseen counts per category for
 * badge display on navigation items.
 *
 * @module NotificationContext
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
// ============================================================================
// Types
// ============================================================================
/**
 * @typedef {'ASSIGNMENT' | 'COLLABORATION' | 'GAMIFICATION' | 'SQUAD' | 'CHAT' | 'SYSTEM'} NotificationCategory
 */ /**
 * @typedef {Object} Notification
 * @property {string} id
 * @property {string} recipientId
 * @property {string} type
 * @property {string} category
 * @property {string} title
 * @property {string} [body]
 * @property {string} [linkPath]
 * @property {string} [linkLabel]
 * @property {string} [referenceId]
 * @property {string} [referenceType]
 * @property {string} [senderName]
 * @property {boolean} seen
 * @property {boolean} interacted
 * @property {string} [expiresAt]
 * @property {object} [metadata]
 * @property {string} createdAt
 * @property {string} updatedAt
 * @property {number} [_version]
 */ // ============================================================================
// Reducer
// ============================================================================
const actionTypes = {
    SET_NOTIFICATIONS: "SET_NOTIFICATIONS",
    SET_LOADING: "SET_LOADING",
    MARK_SEEN: "MARK_SEEN",
    MARK_INTERACTED: "MARK_INTERACTED",
    MARK_ALL_SEEN: "MARK_ALL_SEEN"
};
const initialState = {
    notifications: [],
    loading: true
};
function notificationReducer(state, action) {
    switch(action.type){
        case actionTypes.SET_NOTIFICATIONS:
            return {
                ...state,
                notifications: action.payload,
                loading: false
            };
        case actionTypes.SET_LOADING:
            return {
                ...state,
                loading: action.payload
            };
        case actionTypes.MARK_SEEN:
            return {
                ...state,
                notifications: state.notifications.map((n)=>n.id === action.payload ? {
                        ...n,
                        seen: true
                    } : n)
            };
        case actionTypes.MARK_INTERACTED:
            return {
                ...state,
                notifications: state.notifications.map((n)=>n.id === action.payload ? {
                        ...n,
                        seen: true,
                        interacted: true
                    } : n)
            };
        case actionTypes.MARK_ALL_SEEN:
            return {
                ...state,
                notifications: state.notifications.map((n)=>n.seen ? n : {
                        ...n,
                        seen: true
                    })
            };
        default:
            return state;
    }
}
// ============================================================================
// Context
// ============================================================================
const NotificationContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    notifications: [],
    unseenCount: 0,
    unseenByCategory: {},
    loading: true,
    markSeen: async ()=>{},
    markInteracted: async ()=>{},
    markAllSeen: async ()=>{},
    deleteNotification: async ()=>{}
});
// ============================================================================
// Provider
// ============================================================================
function NotificationProvider({ children }) {
    _s();
    const { user, isLoading: authLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(notificationReducer, initialState);
    const versionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    // Subscribe to notifications for the current user
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NotificationProvider.useEffect": ()=>{
            if (authLoading || !user) return;
            const recipientId = user?.attributes?.sub || user?.userId;
            if (!recipientId) return;
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            // Do NOT filter by recipientId — Amplify Gen 2 auto-filters by owner
            // (ownerDefinedIn("recipientId")). Adding a manual filter causes
            // "subscription filter uses same fieldName multiple time" error.
            const subscription = client.models.Notification.observeQuery().subscribe({
                next: {
                    "NotificationProvider.useEffect.subscription": ({ items })=>{
                        const baseItems = items || [];
                        const validItems = baseItems.filter({
                            "NotificationProvider.useEffect.subscription.validItems": (item)=>item != null && item.id != null
                        }["NotificationProvider.useEffect.subscription.validItems"]).map({
                            "NotificationProvider.useEffect.subscription.validItems": (item_0)=>({
                                    ...item_0,
                                    type: item_0.type ?? "SYSTEM_ANNOUNCEMENT",
                                    category: item_0.category ?? "SYSTEM"
                                })
                        }["NotificationProvider.useEffect.subscription.validItems"]);
                        // Version guard: skip if no item has a newer _version
                        const hasChanges = validItems.some({
                            "NotificationProvider.useEffect.subscription.hasChanges": (item_1)=>{
                                const tracked = versionMapRef.current[item_1.id];
                                const incomingVersion = item_1._version ?? 0;
                                return tracked == null || incomingVersion > tracked;
                            }
                        }["NotificationProvider.useEffect.subscription.hasChanges"]);
                        if (!hasChanges && Object.keys(versionMapRef.current).length > 0) {
                            return;
                        }
                        // Update version map
                        validItems.forEach({
                            "NotificationProvider.useEffect.subscription": (item_2)=>{
                                versionMapRef.current[item_2.id] = item_2._version ?? 0;
                            }
                        }["NotificationProvider.useEffect.subscription"]);
                        // Sort newest first
                        const sorted = [
                            ...validItems
                        ].sort({
                            "NotificationProvider.useEffect.subscription.sorted": (a, b)=>new Date(b.createdAt ?? 0).getTime() - new Date(a.createdAt ?? 0).getTime()
                        }["NotificationProvider.useEffect.subscription.sorted"]);
                        dispatch({
                            type: actionTypes.SET_NOTIFICATIONS,
                            payload: sorted
                        });
                    }
                }["NotificationProvider.useEffect.subscription"],
                error: {
                    "NotificationProvider.useEffect.subscription": (err)=>{
                        const msg = err?.message || err?.errors?.[0]?.message || JSON.stringify(err);
                        if (msg.includes("DuplicatedOperationError")) {
                            console.warn("[NotificationContext] DuplicatedOperationError (safe to ignore)");
                            return;
                        }
                        if (msg === "{}" || msg === "undefined" || msg.includes("exceeds maximum value limit") || msg.includes("Not Authorized")) {
                            console.warn("[NotificationContext] Transient subscription error (safe to ignore):", msg);
                            return;
                        }
                        console.error("[NotificationContext] Subscription error:", err);
                    }
                }["NotificationProvider.useEffect.subscription"]
            });
            return ({
                "NotificationProvider.useEffect": ()=>subscription.unsubscribe()
            })["NotificationProvider.useEffect"];
        }
    }["NotificationProvider.useEffect"], [
        authLoading,
        user
    ]);
    // Compute unseen counts
    const unseenCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NotificationProvider.useMemo[unseenCount]": ()=>state.notifications.filter({
                "NotificationProvider.useMemo[unseenCount]": (n)=>!n.seen
            }["NotificationProvider.useMemo[unseenCount]"]).length
    }["NotificationProvider.useMemo[unseenCount]"], [
        state.notifications
    ]);
    const unseenByCategory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NotificationProvider.useMemo[unseenByCategory]": ()=>{
            const counts = {};
            state.notifications.forEach({
                "NotificationProvider.useMemo[unseenByCategory]": (n_0)=>{
                    if (!n_0.seen && n_0.category) {
                        counts[n_0.category] = (counts[n_0.category] || 0) + 1;
                    }
                }
            }["NotificationProvider.useMemo[unseenByCategory]"]);
            return counts;
        }
    }["NotificationProvider.useMemo[unseenByCategory]"], [
        state.notifications
    ]);
    // Actions
    const markSeen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "NotificationProvider.useCallback[markSeen]": async (notificationId)=>{
            dispatch({
                type: actionTypes.MARK_SEEN,
                payload: notificationId
            });
            try {
                const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const item_3 = state.notifications.find({
                    "NotificationProvider.useCallback[markSeen].item_3": (n_1)=>n_1.id === notificationId
                }["NotificationProvider.useCallback[markSeen].item_3"]);
                if (item_3 && !item_3.seen) {
                    await client_0.models.Notification.update({
                        id: notificationId,
                        seen: true,
                        _version: item_3._version ?? 0
                    });
                }
            } catch (err_0) {
                console.error("[NotificationContext] Error marking seen:", err_0);
            }
        }
    }["NotificationProvider.useCallback[markSeen]"], [
        state.notifications
    ]);
    const markInteracted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "NotificationProvider.useCallback[markInteracted]": async (notificationId_0)=>{
            dispatch({
                type: actionTypes.MARK_INTERACTED,
                payload: notificationId_0
            });
            try {
                const client_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const item_4 = state.notifications.find({
                    "NotificationProvider.useCallback[markInteracted].item_4": (n_2)=>n_2.id === notificationId_0
                }["NotificationProvider.useCallback[markInteracted].item_4"]);
                if (item_4) {
                    await client_1.models.Notification.update({
                        id: notificationId_0,
                        seen: true,
                        interacted: true,
                        _version: item_4._version ?? 0
                    });
                }
            } catch (err_1) {
                console.error("[NotificationContext] Error marking interacted:", err_1);
            }
        }
    }["NotificationProvider.useCallback[markInteracted]"], [
        state.notifications
    ]);
    const markAllSeen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "NotificationProvider.useCallback[markAllSeen]": async ()=>{
            dispatch({
                type: actionTypes.MARK_ALL_SEEN
            });
            try {
                const client_2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const unseen = state.notifications.filter({
                    "NotificationProvider.useCallback[markAllSeen].unseen": (n_3)=>!n_3.seen
                }["NotificationProvider.useCallback[markAllSeen].unseen"]);
                const results = await Promise.allSettled(unseen.map({
                    "NotificationProvider.useCallback[markAllSeen]": (n_4)=>client_2.models.Notification.update({
                            id: n_4.id,
                            seen: true,
                            _version: n_4._version ?? 0
                        })
                }["NotificationProvider.useCallback[markAllSeen]"]));
                const failures = results.filter({
                    "NotificationProvider.useCallback[markAllSeen].failures": (r)=>r.status === 'rejected'
                }["NotificationProvider.useCallback[markAllSeen].failures"]);
                if (failures.length > 0) {
                    console.warn(`[NotificationContext] ${failures.length} notification(s) failed to mark seen`);
                }
            } catch (err_2) {
                console.error("[NotificationContext] Error marking all seen:", err_2);
            }
        }
    }["NotificationProvider.useCallback[markAllSeen]"], [
        state.notifications
    ]);
    const deleteNotification = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "NotificationProvider.useCallback[deleteNotification]": async (notificationId_1)=>{
            try {
                const client_3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                await client_3.models.Notification.delete({
                    id: notificationId_1
                });
            } catch (err_3) {
                console.error("[NotificationContext] Error deleting notification:", err_3);
            }
        }
    }["NotificationProvider.useCallback[deleteNotification]"], []);
    const contextValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NotificationProvider.useMemo[contextValue]": ()=>({
                notifications: state.notifications,
                unseenCount,
                unseenByCategory,
                loading: state.loading,
                markSeen,
                markInteracted,
                markAllSeen,
                deleteNotification
            })
    }["NotificationProvider.useMemo[contextValue]"], [
        state.notifications,
        state.loading,
        unseenCount,
        unseenByCategory,
        markSeen,
        markInteracted,
        markAllSeen,
        deleteNotification
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NotificationContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/notificationContext.tsx",
        lineNumber: 329,
        columnNumber: 10
    }, this);
}
_s(NotificationProvider, "QAcDfOcMfTxkMwsypSJRksgW3Os=");
_c = NotificationProvider;
// ============================================================================
// Hooks
// ============================================================================
function useNotifications() {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "545b020c2738c3cf7c2395085deee165e3e5d19bd5419d5bf597928e4ab34705") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "545b020c2738c3cf7c2395085deee165e3e5d19bd5419d5bf597928e4ab34705";
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(NotificationContext);
}
_s1(useNotifications, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
function useUnseenCount(category) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "545b020c2738c3cf7c2395085deee165e3e5d19bd5419d5bf597928e4ab34705") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "545b020c2738c3cf7c2395085deee165e3e5d19bd5419d5bf597928e4ab34705";
    }
    const { unseenByCategory, unseenCount } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(NotificationContext);
    if (category) {
        return unseenByCategory[category] || 0;
    }
    return unseenCount;
}
_s2(useUnseenCount, "1PgmBq8mW995AXN6ZKQ4mVBqaDk=");
const __TURBOPACK__default__export__ = NotificationContext;
;
var _c;
__turbopack_context__.k.register(_c, "NotificationProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/reducers/sectionReducer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "actionTypes",
    ()=>actionTypes,
    "initialState",
    ()=>initialState,
    "sectionReducer",
    ()=>sectionReducer
]);
const initialState = {
    sections: [],
    sectionMap: {},
    assignments: []
};
const actionTypes = {
    SET_SECTIONS: 'SET_SECTIONS',
    ADD_SECTION: 'ADD_SECTION',
    UPDATE_SECTION: 'UPDATE_SECTION',
    DELETE_SECTION: 'DELETE_SECTION',
    SET_ASSIGNMENTS: 'SET_ASSIGNMENTS',
    ADD_ASSIGNMENT: 'ADD_ASSIGNMENT',
    UPDATE_ASSIGNMENT: 'UPDATE_ASSIGNMENT',
    DELETE_ASSIGNMENT: 'DELETE_ASSIGNMENT'
};
function sectionReducer(state, action) {
    switch(action.type){
        case actionTypes.SET_SECTIONS:
            {
                const incoming = action.payload;
                // Skip if same count and no version changes
                if (incoming.length === state.sections.length && incoming.length > 0) {
                    const anyNewer = incoming.some((item)=>{
                        const existing = state.sectionMap[item.id];
                        return !existing || (item._version || 0) > (existing._version || 0);
                    });
                    if (!anyNewer) return state; // No changes, skip re-render
                }
                const sectionMap = {};
                incoming.forEach((item)=>{
                    sectionMap[item.id] = item;
                });
                return {
                    ...state,
                    sections: incoming,
                    sectionMap
                };
            }
        case actionTypes.ADD_SECTION:
            {
                const section = action.payload;
                if (state.sections.some((s)=>s.id === section.id)) return state;
                const sections = [
                    ...state.sections,
                    section
                ];
                return {
                    ...state,
                    sections,
                    sectionMap: {
                        ...state.sectionMap,
                        [section.id]: section
                    }
                };
            }
        case actionTypes.UPDATE_SECTION:
            {
                const section = action.payload;
                const existing = state.sectionMap[section.id];
                if (existing && section._version != null && section._version <= (existing._version || 0)) {
                    return state; // Not newer, skip re-render
                }
                return {
                    ...state,
                    sections: state.sections.map((s)=>s.id === section.id ? section : s),
                    sectionMap: {
                        ...state.sectionMap,
                        [section.id]: section
                    }
                };
            }
        case actionTypes.DELETE_SECTION:
            {
                const id = action.payload;
                const sectionMap = {
                    ...state.sectionMap
                };
                delete sectionMap[id];
                return {
                    ...state,
                    sections: state.sections.filter((s)=>s.id !== id),
                    sectionMap
                };
            }
        case actionTypes.SET_ASSIGNMENTS:
            {
                const incoming = action.payload;
                // Skip if same count and no version changes
                if (incoming.length === state.assignments.length && incoming.length > 0) {
                    const anyNewer = incoming.some((item)=>{
                        const existing = state.assignments.find((a)=>a.id === item.id);
                        return !existing || (item._version || 0) > (existing._version || 0);
                    });
                    if (!anyNewer) return state; // No changes, skip re-render
                }
                return {
                    ...state,
                    assignments: incoming
                };
            }
        case actionTypes.ADD_ASSIGNMENT:
            {
                const assignment = action.payload;
                if (state.assignments.some((a)=>a.id === assignment.id)) return state;
                return {
                    ...state,
                    assignments: [
                        ...state.assignments,
                        assignment
                    ]
                };
            }
        case actionTypes.UPDATE_ASSIGNMENT:
            {
                const assignment = action.payload;
                const existing = state.assignments.find((a)=>a.id === assignment.id);
                if (existing && assignment._version != null && assignment._version <= (existing._version || 0)) {
                    return state; // Not newer, skip re-render
                }
                return {
                    ...state,
                    assignments: state.assignments.map((a)=>a.id === assignment.id ? assignment : a)
                };
            }
        case actionTypes.DELETE_ASSIGNMENT:
            {
                const id = action.payload;
                return {
                    ...state,
                    assignments: state.assignments.filter((a)=>a.id !== id)
                };
            }
        default:
            return state;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/sectionContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SectionProvider",
    ()=>SectionProvider,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$sectionReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/reducers/sectionReducer.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const SectionContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext({
    sections: [],
    sectionMap: {},
    assignments: []
});
/**
 * Check if a subscription error is transient (safe to ignore).
 * DuplicatedOperationError occurs during rapid mount/unmount cycles
 * (React StrictMode, navigation) and resolves on its own.
 */ function isTransientSubscriptionError(error) {
    const msg = error?.message || error?.errors?.[0]?.message || JSON.stringify(error);
    return msg.includes("DuplicatedOperationError");
}
function handleSubscriptionError(label, error) {
    if (isTransientSubscriptionError(error)) {
        console.warn(`[SectionContext] ${label}: transient DuplicatedOperationError (safe to ignore)`);
        return;
    }
    // Empty error objects are transient auth-timing issues (credentials not yet propagated)
    const msg = error?.message || error?.errors?.[0]?.message || JSON.stringify(error);
    if (!msg || msg === "{}" || msg === "{}") {
        console.warn(`[SectionContext] ${label}: transient empty error (safe to ignore)`);
        return;
    }
    console.error(`[SectionContext] ${label}:`, error);
}
const SectionProvider = ({ children, unitId, initialSections = [] })=>{
    _s();
    // Get auth state from centralized context
    const { user, isLoading: authLoading } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$sectionReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sectionReducer"], initialSections.length > 0 ? {
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$sectionReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"],
        sections: initialSections,
        sectionMap: Object.fromEntries(initialSections.map({
            "SectionProvider.useReducer": (s)=>[
                    s.id,
                    s
                ]
        }["SectionProvider.useReducer"]))
    } : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$sectionReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"]);
    const sectionVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    const assignmentVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    // Show deleted toggle state
    const [showDeleted, setShowDeleted] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [deletedSections, setDeletedSections] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    // Gate: don't subscribe until auth is fully resolved
    const authReady = !authLoading && !!user;
    // Seed from IndexedDB cache when offline so pages render immediately
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "SectionProvider.useEffect": ()=>{
            if (typeof navigator === "undefined" || navigator.onLine) return;
            let mounted = true;
            ({
                "SectionProvider.useEffect": async ()=>{
                    try {
                        const { getAllCachedSections, getAllCachedAssignments } = await __turbopack_context__.A("[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript, async loader)");
                        const [cachedSections, cachedAssignments] = await Promise.all([
                            getAllCachedSections(),
                            getAllCachedAssignments()
                        ]);
                        if (!mounted) return;
                        if (cachedSections.length > 0) {
                            dispatch({
                                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$sectionReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SECTIONS,
                                payload: cachedSections
                            });
                        }
                        if (cachedAssignments.length > 0) {
                            dispatch({
                                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$sectionReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_ASSIGNMENTS,
                                payload: cachedAssignments
                            });
                        }
                    } catch  {
                    // IndexedDB not available — noop
                    }
                }
            })["SectionProvider.useEffect"]();
            return ({
                "SectionProvider.useEffect": ()=>{
                    mounted = false;
                }
            })["SectionProvider.useEffect"];
        }
    }["SectionProvider.useEffect"], []);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "SectionProvider.useEffect": ()=>{
            if (!authReady) return;
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            let cancelled = false;
            // Single observeQuery replaces list() + 3 manual subscriptions
            const subscription = client.models.Section.observeQuery().subscribe({
                next: {
                    "SectionProvider.useEffect.subscription": ({ items })=>{
                        if (cancelled) return;
                        const allValid = (items || []).filter({
                            "SectionProvider.useEffect.subscription.allValid": (item)=>item != null && item.id != null
                        }["SectionProvider.useEffect.subscription.allValid"]);
                        const validItems = allValid.filter({
                            "SectionProvider.useEffect.subscription.validItems": (item_0)=>item_0.deletedAt == null
                        }["SectionProvider.useEffect.subscription.validItems"]);
                        const deleted = allValid.filter({
                            "SectionProvider.useEffect.subscription.deleted": (item_1)=>item_1.deletedAt != null
                        }["SectionProvider.useEffect.subscription.deleted"]);
                        setDeletedSections(deleted);
                        // Version map guard: skip if no item has a newer _version
                        const hasChanges = validItems.some({
                            "SectionProvider.useEffect.subscription.hasChanges": (item_2)=>{
                                const tracked = sectionVersionMapRef.current[item_2.id];
                                return tracked == null || item_2._version > tracked;
                            }
                        }["SectionProvider.useEffect.subscription.hasChanges"]);
                        if (!hasChanges && Object.keys(sectionVersionMapRef.current).length > 0) {
                            return; // All items same or older version — skip dispatch
                        }
                        // Update version map
                        sectionVersionMapRef.current = {};
                        validItems.forEach({
                            "SectionProvider.useEffect.subscription": (item_3)=>{
                                sectionVersionMapRef.current[item_3.id] = item_3._version;
                            }
                        }["SectionProvider.useEffect.subscription"]);
                        console.log("[SectionContext] Section observeQuery update:", validItems.length);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$sectionReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SECTIONS,
                            payload: validItems
                        });
                    }
                }["SectionProvider.useEffect.subscription"],
                error: {
                    "SectionProvider.useEffect.subscription": (error)=>handleSubscriptionError("Section observeQuery", error)
                }["SectionProvider.useEffect.subscription"]
            });
            return ({
                "SectionProvider.useEffect": ()=>{
                    cancelled = true;
                    subscription.unsubscribe();
                }
            })["SectionProvider.useEffect"];
        }
    }["SectionProvider.useEffect"], [
        authReady
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "SectionProvider.useEffect": ()=>{
            if (!authReady || !unitId) return;
            const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            let cancelled_0 = false;
            // Single observeQuery with filter replaces list() + 3 manual subscriptions
            const subscription_0 = client_0.models.Assignment.observeQuery({
                filter: {
                    unitID: {
                        eq: unitId
                    }
                }
            }).subscribe({
                next: {
                    "SectionProvider.useEffect.subscription_0": ({ items: items_0 })=>{
                        if (cancelled_0) return;
                        const validItems_0 = (items_0 || []).filter({
                            "SectionProvider.useEffect.subscription_0.validItems_0": (item_4)=>item_4 != null && item_4.id != null
                        }["SectionProvider.useEffect.subscription_0.validItems_0"]);
                        // Version map guard: skip if no item has a newer _version
                        const hasChanges_0 = validItems_0.some({
                            "SectionProvider.useEffect.subscription_0.hasChanges_0": (item_5)=>{
                                const tracked_0 = assignmentVersionMapRef.current[item_5.id];
                                return tracked_0 == null || item_5._version > tracked_0;
                            }
                        }["SectionProvider.useEffect.subscription_0.hasChanges_0"]);
                        if (!hasChanges_0 && Object.keys(assignmentVersionMapRef.current).length > 0) {
                            return; // All items same or older version — skip dispatch
                        }
                        // Update version map
                        assignmentVersionMapRef.current = {};
                        validItems_0.forEach({
                            "SectionProvider.useEffect.subscription_0": (item_6)=>{
                                assignmentVersionMapRef.current[item_6.id] = item_6._version;
                            }
                        }["SectionProvider.useEffect.subscription_0"]);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$sectionReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_ASSIGNMENTS,
                            payload: validItems_0
                        });
                    }
                }["SectionProvider.useEffect.subscription_0"],
                error: {
                    "SectionProvider.useEffect.subscription_0": (error_0)=>handleSubscriptionError("Assignment observeQuery", error_0)
                }["SectionProvider.useEffect.subscription_0"]
            });
            return ({
                "SectionProvider.useEffect": ()=>{
                    cancelled_0 = true;
                    subscription_0.unsubscribe();
                }
            })["SectionProvider.useEffect"];
        }
    }["SectionProvider.useEffect"], [
        authReady,
        unitId
    ]);
    // Refetch sections - can be called after create/update operations
    const refetchSections = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "SectionProvider.useCallback[refetchSections]": async ()=>{
            console.log("[SectionContext] Manual refetch triggered");
            const client_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            try {
                const { data: fetchedSections, errors } = await client_1.models.Section.list();
                if (errors) {
                    console.error("[SectionContext] Refetch errors:", errors);
                }
                const validItems_1 = (fetchedSections || []).filter({
                    "SectionProvider.useCallback[refetchSections].validItems_1": (item_7)=>item_7 != null && item_7.id != null
                }["SectionProvider.useCallback[refetchSections].validItems_1"]);
                console.log("[SectionContext] Refetch complete, sections:", validItems_1.length);
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$sectionReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SECTIONS,
                    payload: validItems_1
                });
            } catch (error_1) {
                console.error("[SectionContext] Refetch error:", error_1);
            }
        }
    }["SectionProvider.useCallback[refetchSections]"], []);
    // Optimistic version bump helpers — call before save to block subscription echo
    const bumpSectionVersion = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "SectionProvider.useCallback[bumpSectionVersion]": (id, currentVersion)=>{
            const previousVersion = sectionVersionMapRef.current[id] || currentVersion;
            sectionVersionMapRef.current[id] = currentVersion + 1;
            return {
                confirm: ({
                    "SectionProvider.useCallback[bumpSectionVersion]": (actualVersion)=>{
                        sectionVersionMapRef.current[id] = actualVersion;
                    }
                })["SectionProvider.useCallback[bumpSectionVersion]"],
                rollback: ({
                    "SectionProvider.useCallback[bumpSectionVersion]": ()=>{
                        sectionVersionMapRef.current[id] = previousVersion;
                    }
                })["SectionProvider.useCallback[bumpSectionVersion]"]
            };
        }
    }["SectionProvider.useCallback[bumpSectionVersion]"], []);
    const bumpAssignmentVersion = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "SectionProvider.useCallback[bumpAssignmentVersion]": (id_0, currentVersion_0)=>{
            const previousVersion_0 = assignmentVersionMapRef.current[id_0] || currentVersion_0;
            assignmentVersionMapRef.current[id_0] = currentVersion_0 + 1;
            return {
                confirm: ({
                    "SectionProvider.useCallback[bumpAssignmentVersion]": (actualVersion_0)=>{
                        assignmentVersionMapRef.current[id_0] = actualVersion_0;
                    }
                })["SectionProvider.useCallback[bumpAssignmentVersion]"],
                rollback: ({
                    "SectionProvider.useCallback[bumpAssignmentVersion]": ()=>{
                        assignmentVersionMapRef.current[id_0] = previousVersion_0;
                    }
                })["SectionProvider.useCallback[bumpAssignmentVersion]"]
            };
        }
    }["SectionProvider.useCallback[bumpAssignmentVersion]"], []);
    // Memoize context value to prevent unnecessary rerenders
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "SectionProvider.useMemo[contextValue]": ()=>({
                sections: state.sections,
                sectionMap: state.sectionMap,
                assignments: state.assignments,
                refetchSections,
                bumpSectionVersion,
                bumpAssignmentVersion,
                showDeleted,
                setShowDeleted,
                deletedSections
            })
    }["SectionProvider.useMemo[contextValue]"], [
        state.sections,
        state.sectionMap,
        state.assignments,
        refetchSections,
        bumpSectionVersion,
        bumpAssignmentVersion,
        showDeleted,
        deletedSections
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/sectionContext.jsx",
        lineNumber: 242,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(SectionProvider, "sy0Rum+Q2vILg/c/bcxygeTr4SE=");
_c = SectionProvider;
;
const __TURBOPACK__default__export__ = SectionContext;
var _c;
__turbopack_context__.k.register(_c, "SectionProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/reducers/chatReducer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "actionTypes",
    ()=>actionTypes,
    "chatReducer",
    ()=>chatReducer,
    "initialState",
    ()=>initialState
]);
const initialState = {
    assistantChat: null,
    chatHistories: [],
    isLoadingChat: false,
    chatCreationError: null,
    subscriptionReady: false,
    isChatOpen: false,
    pageContext: {
        unit: null,
        files: [],
        dictionary: [],
        questions: [],
        sections: [],
        editorRef: null,
        vectorStoreSearch: null
    },
    messages: []
};
const actionTypes = {
    SET_ASSISTANT_CHAT: 'SET_ASSISTANT_CHAT',
    SET_CHAT_HISTORIES: 'SET_CHAT_HISTORIES',
    SET_LOADING_CHAT: 'SET_LOADING_CHAT',
    SET_CHAT_CREATION_ERROR: 'SET_CHAT_CREATION_ERROR',
    SET_SUBSCRIPTION_READY: 'SET_SUBSCRIPTION_READY',
    SET_CHAT_OPEN: 'SET_CHAT_OPEN',
    SET_PAGE_CONTEXT: 'SET_PAGE_CONTEXT',
    SET_MESSAGES: 'SET_MESSAGES',
    CHAT_CREATION_STARTED: 'CHAT_CREATION_STARTED',
    CHAT_CREATION_SUCCEEDED: 'CHAT_CREATION_SUCCEEDED',
    CHAT_CREATION_FAILED: 'CHAT_CREATION_FAILED',
    SUBSCRIPTION_SYNCED: 'SUBSCRIPTION_SYNCED'
};
function chatReducer(state, action) {
    switch(action.type){
        case actionTypes.SET_ASSISTANT_CHAT:
            {
                const incoming = action.payload;
                // Skip if same chat and not a newer version
                if (state.assistantChat && incoming && incoming.id === state.assistantChat.id && incoming._version != null && incoming._version <= (state.assistantChat._version || 0)) {
                    return state; // Not newer, skip re-render
                }
                return {
                    ...state,
                    assistantChat: incoming
                };
            }
        case actionTypes.SET_CHAT_HISTORIES:
            {
                const incoming = action.payload;
                // Skip if same length and no version changes
                if (state.chatHistories.length === incoming.length && incoming.length > 0) {
                    const anyNewer = incoming.some((item)=>{
                        const existing = state.chatHistories.find((e)=>e.id === item.id);
                        return !existing || (item._version || 0) > (existing._version || 0);
                    });
                    if (!anyNewer) return state; // No changes, skip re-render
                }
                return {
                    ...state,
                    chatHistories: incoming
                };
            }
        case actionTypes.SET_LOADING_CHAT:
            return {
                ...state,
                isLoadingChat: action.payload
            };
        case actionTypes.SET_CHAT_CREATION_ERROR:
            return {
                ...state,
                chatCreationError: action.payload
            };
        case actionTypes.SET_SUBSCRIPTION_READY:
            return {
                ...state,
                subscriptionReady: action.payload
            };
        case actionTypes.SET_CHAT_OPEN:
            return {
                ...state,
                isChatOpen: action.payload
            };
        case actionTypes.SET_PAGE_CONTEXT:
            return {
                ...state,
                pageContext: action.payload
            };
        case actionTypes.SET_MESSAGES:
            return {
                ...state,
                messages: action.payload
            };
        case actionTypes.CHAT_CREATION_STARTED:
            return {
                ...state,
                isLoadingChat: true,
                chatCreationError: null
            };
        case actionTypes.CHAT_CREATION_SUCCEEDED:
            return {
                ...state,
                isLoadingChat: false
            };
        case actionTypes.CHAT_CREATION_FAILED:
            return {
                ...state,
                isLoadingChat: false,
                chatCreationError: action.payload
            };
        case actionTypes.SUBSCRIPTION_SYNCED:
            return {
                ...state,
                subscriptionReady: true,
                chatHistories: action.payload
            };
        default:
            return state;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/chatContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChatContextProvider",
    ()=>ChatContextProvider,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useChatContext",
    ()=>useChatContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * ChatContext - Global chat state management
 *
 * Manages AI assistant chat functionality across the entire application.
 * Provides chat session persistence, message history, and page-specific context.
 *
 * @see docs/GLOBAL_CHAT_INTEGRATION_PLAN.md
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/reducers/chatReducer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/chatSearchIndex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/chatSearchWorkerManager.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
/**
 * Chat Context interface
 */ const ChatContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    // Current chat session
    assistantChat: null,
    // All chat sessions (sorted by createdAt DESC)
    chatHistories: [],
    // Chat loading states
    isLoadingChat: false,
    chatCreationError: null,
    // Chat selection
    setCurrentChat: ()=>{},
    // Global chat UI state
    isChatOpen: false,
    setIsChatOpen: ()=>{},
    // Page context - dynamically provided by current page
    pageContext: {
        unit: null,
        files: [],
        dictionary: [],
        questions: [],
        sections: [],
        editorRef: null,
        vectorStoreSearch: null
    },
    // Register page context
    setPageContext: ()=>{},
    // Chat messages (managed by useChat hook, but stored here for persistence)
    messages: [],
    setMessages: ()=>{},
    // Fast local chat search over indexed messages
    searchChatMessages: ()=>[],
    searchChatMessagesAsync: async ()=>[],
    chatSearchStats: {
        indexedMessages: 0
    }
});
function useChatContext() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "a76fe1d8270b83466a989bcb76a73c9e9c88ba505a8a854396bd05d6f8e16c93") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a76fe1d8270b83466a989bcb76a73c9e9c88ba505a8a854396bd05d6f8e16c93";
    }
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ChatContext);
    if (!context) {
        console.warn("[useChatContext] Used outside of ChatContextProvider, returning default values");
    }
    return context;
}
_s(useChatContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
function ChatContextProvider({ children }) {
    _s1();
    // Get auth state
    const { user, isLoading: authLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    // Lazy client initialization - must be inside component to ensure Amplify.configure() has run
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ChatContextProvider.useMemo[client]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])()
    }["ChatContextProvider.useMemo[client]"], []);
    // All chat state managed by reducer
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chatReducer"], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"]);
    const chatVersionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null); // Track _version to detect changes and prevent rerenders
    const subscriptionInitializedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    // Show deleted toggle state
    const [showDeleted, setShowDeleted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [deletedChats, setDeletedChats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const chatSearchIndexRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildChatSearchIndex"])(state.messages || []));
    const chatSearchKeyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const chatSearchWorkerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Use a ref to access current assistantChat inside subscription without causing re-subscribe
    const assistantChatRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(state.assistantChat);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatContextProvider.useEffect": ()=>{
            assistantChatRef.current = state.assistantChat;
        }
    }["ChatContextProvider.useEffect"], [
        state.assistantChat
    ]);
    // Observe AssistantChat - single observeQuery replaces list() + 3 manual subscriptions
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatContextProvider.useEffect": ()=>{
            // Wait for auth to be ready
            if (authLoading || !user) {
                console.log("[ChatContext] Waiting for auth...");
                return;
            }
            console.log("[ChatContext] Setting up AssistantChat observeQuery");
            let cancelled = false;
            function processChats(validItems) {
                // Sort by createdAt descending (most recent first)
                validItems.sort({
                    "ChatContextProvider.useEffect.processChats": (a, b)=>{
                        const aTime = a.createdAt ? new Date(a.createdAt).getTime() : 0;
                        const bTime = b.createdAt ? new Date(b.createdAt).getTime() : 0;
                        return bTime - aTime;
                    }
                }["ChatContextProvider.useEffect.processChats"]);
                // Update chat histories list
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_CHAT_HISTORIES,
                    payload: validItems
                });
                // Read current chat from ref (not from closure) to avoid stale state
                const prevCurrent = assistantChatRef.current;
                let newChat = prevCurrent;
                if (validItems.length > 0) {
                    const nonArchivedChats = validItems.filter({
                        "ChatContextProvider.useEffect.processChats.nonArchivedChats": (item)=>!item.archived
                    }["ChatContextProvider.useEffect.processChats.nonArchivedChats"]);
                    const mostRecentChat = nonArchivedChats[0];
                    if (!prevCurrent) {
                        if (mostRecentChat) {
                            chatVersionRef.current = mostRecentChat._version;
                            console.log("[ChatContext] Setting initial chat:", mostRecentChat.id);
                            newChat = mostRecentChat;
                        } else {
                            newChat = null;
                        }
                    } else if (prevCurrent.archived) {
                        if (mostRecentChat) {
                            chatVersionRef.current = mostRecentChat._version;
                            console.log("[ChatContext] Current chat archived, switching to:", mostRecentChat.id);
                            newChat = mostRecentChat;
                        } else {
                            chatVersionRef.current = null;
                            newChat = null;
                        }
                    } else {
                        const updatedCurrent = validItems.find({
                            "ChatContextProvider.useEffect.processChats.updatedCurrent": (item_0)=>item_0.id === prevCurrent.id
                        }["ChatContextProvider.useEffect.processChats.updatedCurrent"]);
                        if (!updatedCurrent || updatedCurrent._version == null || !(updatedCurrent._version > chatVersionRef.current)) {
                            // Echo, stale, or missing — skip
                            return;
                        }
                        chatVersionRef.current = updatedCurrent._version;
                        newChat = updatedCurrent;
                    }
                } else {
                    chatVersionRef.current = null;
                    newChat = null;
                }
                if (newChat !== prevCurrent) {
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_ASSISTANT_CHAT,
                        payload: newChat
                    });
                }
            }
            function handleError(label, error) {
                const msg = error?.message || error?.errors?.[0]?.message || JSON.stringify(error);
                if (msg.includes("DuplicatedOperationError") || msg.includes("Not Authorized") || msg === "{}" || msg === "undefined") {
                    console.warn(`[ChatContext] ${label}: transient subscription error (safe to ignore)`);
                    return;
                }
                console.error(`[ChatContext] ${label} error:`, error);
            }
            const subscription = client.models.AssistantChat.observeQuery().subscribe({
                next: {
                    "ChatContextProvider.useEffect.subscription": ({ items })=>{
                        if (cancelled) return;
                        const allValid = (items || []).filter({
                            "ChatContextProvider.useEffect.subscription.allValid": (item_1)=>item_1 != null && item_1.id != null
                        }["ChatContextProvider.useEffect.subscription.allValid"]);
                        const validItems_0 = allValid.filter({
                            "ChatContextProvider.useEffect.subscription.validItems_0": (item_2)=>item_2.deletedAt == null
                        }["ChatContextProvider.useEffect.subscription.validItems_0"]);
                        const deleted = allValid.filter({
                            "ChatContextProvider.useEffect.subscription.deleted": (item_3)=>item_3.deletedAt != null
                        }["ChatContextProvider.useEffect.subscription.deleted"]);
                        setDeletedChats(deleted);
                        // Mark subscription as initialized on first emission
                        if (!subscriptionInitializedRef.current) {
                            subscriptionInitializedRef.current = true;
                            dispatch({
                                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SUBSCRIPTION_READY,
                                payload: true
                            });
                            console.log("[ChatContext] AssistantChat initialized with", validItems_0.length, "chats");
                        }
                        processChats(validItems_0);
                    }
                }["ChatContextProvider.useEffect.subscription"],
                error: {
                    "ChatContextProvider.useEffect.subscription": (error_0)=>handleError("AssistantChat observeQuery", error_0)
                }["ChatContextProvider.useEffect.subscription"]
            });
            return ({
                "ChatContextProvider.useEffect": ()=>{
                    console.log("[ChatContext] Cleaning up subscriptions");
                    cancelled = true;
                    subscription.unsubscribe();
                }
            })["ChatContextProvider.useEffect"];
        }
    }["ChatContextProvider.useEffect"], [
        user,
        authLoading
    ]);
    // Create AssistantChat if needed
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatContextProvider.useEffect": ()=>{
            // Don't create anything until subscription has initialized
            if (!subscriptionInitializedRef.current) {
                console.log("[ChatContext] Waiting for subscription to initialize");
                return;
            }
            // Wait for auth to be fully ready
            if (!user || authLoading) {
                console.log("[ChatContext] Waiting for auth to be ready before creating chat");
                return;
            }
            // Check if we have a non-archived chat
            if (state.assistantChat?.id && !state.assistantChat.archived) {
                console.log("[ChatContext] Chat exists and not archived, skipping creation");
                return;
            }
            // If there are existing non-archived chats, use them instead of creating
            const nonArchivedChats_0 = state.chatHistories.filter({
                "ChatContextProvider.useEffect.nonArchivedChats_0": (chat)=>!chat.archived
            }["ChatContextProvider.useEffect.nonArchivedChats_0"]);
            if (nonArchivedChats_0.length > 0) {
                console.log("[ChatContext] Found", nonArchivedChats_0.length, "non-archived chats, subscription will handle selection");
                return;
            }
            // If current chat is archived or doesn't exist, we need a new one
            if (state.assistantChat?.archived) {
                console.log("[ChatContext] Current chat is archived, will create new chat");
            } else if (!state.assistantChat?.id) {
                console.log("[ChatContext] No current chat available, will create one");
            }
            // Create new AssistantChat
            async function createChat() {
                console.log("[ChatContext] Creating AssistantChat with user:", user?.username);
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].CHAT_CREATION_STARTED
                });
                try {
                    // Gen 2 API
                    const result = await client.models.AssistantChat.create({
                        model: "gpt-4",
                        archived: false
                    });
                    console.log("[ChatContext] Create result:", {
                        hasData: !!result.data,
                        hasErrors: !!result.errors,
                        data: result.data,
                        errors: result.errors
                    });
                    // Check for GraphQL errors
                    if (result.errors && result.errors.length > 0) {
                        console.error("[ChatContext] GraphQL errors creating chat:", result.errors);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].CHAT_CREATION_FAILED,
                            payload: result.errors[0].message || "Failed to create chat"
                        });
                        return;
                    }
                    if (!result.data) {
                        console.error("[ChatContext] No data returned from create operation. Full result:", result);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].CHAT_CREATION_FAILED,
                            payload: "Failed to create chat - no data returned"
                        });
                        return;
                    }
                    console.log("[ChatContext] Created AssistantChat:", result.data.id, "at:", result.data.createdAt);
                    // Optimistic version bump — subscription echo will have _version 1
                    chatVersionRef.current = (result.data._version || 0) + 1;
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].CHAT_CREATION_SUCCEEDED
                    });
                } catch (error_1) {
                    console.error("[ChatContext] Error creating chat:", error_1);
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].CHAT_CREATION_FAILED,
                        payload: error_1.message || "Failed to create chat"
                    });
                }
            }
            createChat();
        }
    }["ChatContextProvider.useEffect"], [
        state.subscriptionReady,
        state.assistantChat?.id,
        state.assistantChat?.archived,
        state.chatHistories.length,
        user,
        authLoading
    ]);
    // Stable dispatch-based setters for consumers
    const setCurrentChat = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatContextProvider.useCallback[setCurrentChat]": (chat_0)=>dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_ASSISTANT_CHAT,
                payload: chat_0
            })
    }["ChatContextProvider.useCallback[setCurrentChat]"], []);
    const setIsChatOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatContextProvider.useCallback[setIsChatOpen]": (open)=>dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_CHAT_OPEN,
                payload: open
            })
    }["ChatContextProvider.useCallback[setIsChatOpen]"], []);
    const setPageContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatContextProvider.useCallback[setPageContext]": (ctx)=>dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_PAGE_CONTEXT,
                payload: ctx
            })
    }["ChatContextProvider.useCallback[setPageContext]"], []);
    const setMessages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatContextProvider.useCallback[setMessages]": (msgs)=>dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$chatReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_MESSAGES,
                payload: msgs
            })
    }["ChatContextProvider.useCallback[setMessages]"], []);
    // Initialize worker manager once.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatContextProvider.useEffect": ()=>{
            chatSearchWorkerRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChatSearchWorkerManager"])(chatSearchIndexRef);
            return ({
                "ChatContextProvider.useEffect": ()=>{
                    chatSearchWorkerRef.current?.dispose();
                    chatSearchWorkerRef.current = null;
                }
            })["ChatContextProvider.useEffect"];
        }
    }["ChatContextProvider.useEffect"], []);
    // Rebuild/persist chat search index when chat or messages change.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatContextProvider.useEffect": ()=>{
            let cancelled_0 = false;
            async function syncIndex() {
                const cacheKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChatIndexCacheKey"])(state.assistantChat?.id, state.messages || []);
                if (chatSearchKeyRef.current === cacheKey) return;
                const persisted = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadPersistedChatSearchIndex"])(cacheKey);
                if (cancelled_0) return;
                if (persisted) {
                    chatSearchIndexRef.current = persisted;
                } else {
                    const rebuilt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildChatSearchIndex"])(state.messages || []);
                    chatSearchIndexRef.current = rebuilt;
                    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persistChatSearchIndex"])(cacheKey, rebuilt);
                }
                chatSearchKeyRef.current = cacheKey;
                void chatSearchWorkerRef.current?.build(state.messages || []);
            }
            syncIndex();
            return ({
                "ChatContextProvider.useEffect": ()=>{
                    cancelled_0 = true;
                }
            })["ChatContextProvider.useEffect"];
        }
    }["ChatContextProvider.useEffect"], [
        state.assistantChat?.id,
        state.messages
    ]);
    const searchChatMessages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatContextProvider.useCallback[searchChatMessages]": (query, options = {})=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchChatIndex"])(chatSearchIndexRef.current, query, options);
        }
    }["ChatContextProvider.useCallback[searchChatMessages]"], []);
    const searchChatMessagesAsync = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatContextProvider.useCallback[searchChatMessagesAsync]": async (query_0, options_0 = {})=>{
            return await chatSearchWorkerRef.current?.search(query_0, options_0) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatSearchIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchChatIndex"])(chatSearchIndexRef.current, query_0, options_0);
        }
    }["ChatContextProvider.useCallback[searchChatMessagesAsync]"], []);
    // Memoize context value to prevent unnecessary re-renders
    const contextValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ChatContextProvider.useMemo[contextValue]": ()=>({
                // Chat session
                assistantChat: state.assistantChat,
                chatHistories: state.chatHistories,
                isLoadingChat: state.isLoadingChat,
                chatCreationError: state.chatCreationError,
                setCurrentChat,
                chatVersionRef,
                // Global chat UI
                isChatOpen: state.isChatOpen,
                setIsChatOpen,
                // Page context
                pageContext: state.pageContext,
                setPageContext,
                // Messages
                messages: state.messages,
                setMessages,
                searchChatMessages,
                searchChatMessagesAsync,
                chatSearchStats: {
                    indexedMessages: chatSearchIndexRef.current.docs.size
                },
                // Show deleted
                showDeleted,
                setShowDeleted,
                deletedChats
            })
    }["ChatContextProvider.useMemo[contextValue]"], [
        state.assistantChat?.id,
        state.assistantChat?._version,
        state.assistantChat?.archived,
        state.chatHistories?.length,
        state.isLoadingChat,
        state.chatCreationError,
        state.isChatOpen,
        state.pageContext,
        state.messages?.length,
        setCurrentChat,
        setIsChatOpen,
        setPageContext,
        setMessages,
        searchChatMessages,
        searchChatMessagesAsync,
        showDeleted,
        deletedChats
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ChatContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/chatContext.jsx",
        lineNumber: 386,
        columnNumber: 10
    }, this);
}
_s1(ChatContextProvider, "6TWGq7Pbq+vwhxYfNa4seRC+qk8=");
_c = ChatContextProvider;
const __TURBOPACK__default__export__ = ChatContext;
var _c;
__turbopack_context__.k.register(_c, "ChatContextProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/searchContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SearchProvider",
    ()=>SearchProvider,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useLoadSearchBundle",
    ()=>useLoadSearchBundle,
    "useSearch",
    ()=>useSearch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$offline$2f$LocalEmbeddingModel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/offline/LocalEmbeddingModel.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/chatContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$searchBundles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/searchBundles.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
const TYPE_ALIASES = {
    file: "file",
    files: "file",
    unit: "unit",
    units: "unit",
    word: "word",
    words: "word",
    question: "question",
    questions: "question",
    section: "section",
    sections: "section",
    chat: "chat",
    chats: "chat"
};
function parseSearchQuery(raw) {
    const tokens = raw.trim().split(/\s+/).filter(Boolean);
    let type;
    let role;
    let author;
    const retained = [];
    for (const token of tokens){
        const lower = token.toLowerCase();
        if (lower.startsWith("type:")) {
            const candidate = lower.slice(5);
            type = TYPE_ALIASES[candidate] || type;
            continue;
        }
        const fieldAliasMatch = lower.match(/^(@|\/)?(file|files|unit|units|word|words|question|questions|section|sections|chat|chats):?(.*)$/);
        if (fieldAliasMatch) {
            const alias = fieldAliasMatch[2];
            const trailing = fieldAliasMatch[3];
            type = TYPE_ALIASES[alias] || type;
            if (trailing) retained.push(trailing);
            continue;
        }
        if (lower.startsWith("from:")) {
            const candidate = token.slice(5).trim();
            const candidateLower = candidate.toLowerCase();
            if (candidateLower === "user" || candidateLower === "assistant") {
                role = candidateLower;
            } else if (candidate.length > 0) {
                author = candidate;
            }
            continue;
        }
        retained.push(token);
    }
    return {
        query: retained.join(" ").trim(),
        type,
        role,
        author
    };
}
function normalizeText(value) {
    return (value || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").trim();
}
function tokenize(value) {
    return normalizeText(value).split(/\s+/).filter((token)=>token.length >= 2);
}
function lexicalScore(text, query) {
    const q = tokenize(query);
    if (q.length === 0) return 0;
    const docTokens = tokenize(text);
    if (docTokens.length === 0) return 0;
    const tf = new Map();
    for (const token of docTokens){
        tf.set(token, (tf.get(token) || 0) + 1);
    }
    let score = 0;
    for (const token of q){
        const freq = tf.get(token) || 0;
        if (freq > 0) {
            score += 1 + Math.log(1 + freq);
        }
    }
    const normalizedDoc = normalizeText(text);
    const normalizedQuery = normalizeText(query);
    if (normalizedQuery && normalizedDoc.includes(normalizedQuery)) {
        score += 1.5;
    }
    return score;
}
function searchLearnerScope(scope, query, type) {
    const includeUnits = type == null || type === "unit";
    const includeSections = type == null || type === "section";
    const includeFiles = type == null || type === "file";
    const pool = [];
    if (includeUnits) pool.push(...scope.units);
    if (includeSections) pool.push(...scope.sections);
    if (includeFiles) pool.push(...scope.files);
    const scored = pool.map((item)=>{
        const haystack = `${item.title} ${item.description || ""}`;
        const score = lexicalScore(haystack, query);
        return {
            item,
            score
        };
    }).filter((candidate)=>candidate.score > 0).sort((a, b)=>b.score - a.score).slice(0, 15);
    const maxScore = scored.reduce((max, candidate)=>candidate.score > max ? candidate.score : max, 0);
    return scored.map(({ item, score })=>({
            type: item.type,
            id: item.id,
            title: item.title,
            description: item.description,
            score: maxScore > 0 ? score / maxScore : score,
            highlightTerm: query
        }));
}
const SearchContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext({
    query: "",
    results: [],
    searching: false,
    open: false,
    setQuery: ()=>{},
    executeSearch: async ()=>{},
    clearSearch: ()=>{},
    setOpen: ()=>{}
});
function SearchProvider({ children }) {
    _s();
    const [state, setState] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        query: "",
        results: [],
        searching: false,
        open: false
    });
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const { session } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { searchChatMessagesAsync } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const debounceRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const bundleRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const loadingBundleRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const learnerScopeRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef({
        sections: [],
        units: [],
        files: []
    });
    const loadingLearnerScopeRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const currentUnitId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "SearchProvider.useMemo[currentUnitId]": ()=>{
            const unitMatch = pathname?.match(/\/unit\/([^/?#]+)/);
            if (unitMatch) return unitMatch[1];
            const workbookMatch = pathname?.match(/\/workbook\/([^/?#]+)/);
            if (workbookMatch) return workbookMatch[1];
            return null;
        }
    }["SearchProvider.useMemo[currentUnitId]"], [
        pathname
    ]);
    const groups = session?.groups || [];
    const isPrivileged = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "SearchProvider.useMemo[isPrivileged]": ()=>groups.some({
                "SearchProvider.useMemo[isPrivileged]": (g)=>[
                        "Admins",
                        "Moderators",
                        "Instructors"
                    ].includes(g)
            }["SearchProvider.useMemo[isPrivileged]"])
    }["SearchProvider.useMemo[isPrivileged]"], [
        groups
    ]);
    const loadLearnerScope = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "SearchProvider.useCallback[loadLearnerScope]": async ()=>{
            if (loadingLearnerScopeRef.current) {
                return loadingLearnerScopeRef.current;
            }
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            loadingLearnerScopeRef.current = ({
                "SearchProvider.useCallback[loadLearnerScope]": async ()=>{
                    const [assignmentsResult, sectionsResult] = await Promise.all([
                        client.models.Assignment.list(),
                        client.models.Section.list()
                    ]);
                    const assignments = (assignmentsResult?.data || []).filter({
                        "SearchProvider.useCallback[loadLearnerScope].assignments": (item)=>item != null && item.id != null && item.deletedAt == null
                    }["SearchProvider.useCallback[loadLearnerScope].assignments"]);
                    const sections = (sectionsResult?.data || []).filter({
                        "SearchProvider.useCallback[loadLearnerScope].sections": (item_0)=>item_0 != null && item_0.id != null && item_0.deletedAt == null
                    }["SearchProvider.useCallback[loadLearnerScope].sections"]);
                    const sectionById = new Map();
                    sections.forEach({
                        "SearchProvider.useCallback[loadLearnerScope]": (section)=>sectionById.set(section.id, section)
                    }["SearchProvider.useCallback[loadLearnerScope]"]);
                    const unitIds = new Set();
                    const sectionIds = new Set();
                    assignments.forEach({
                        "SearchProvider.useCallback[loadLearnerScope]": (assignment)=>{
                            if (assignment.unitID) unitIds.add(assignment.unitID);
                            if (assignment.sectionID) sectionIds.add(assignment.sectionID);
                        }
                    }["SearchProvider.useCallback[loadLearnerScope]"]);
                    const units = await Promise.all(Array.from(unitIds).map({
                        "SearchProvider.useCallback[loadLearnerScope]": async (unitId)=>{
                            try {
                                const response = await client.models.Unit.get({
                                    id: unitId
                                });
                                return response?.data || null;
                            } catch  {
                                return null;
                            }
                        }
                    }["SearchProvider.useCallback[loadLearnerScope]"]));
                    const unitFileResult = await client.models.UnitFile.list();
                    const unitFiles = (unitFileResult?.data || []).filter({
                        "SearchProvider.useCallback[loadLearnerScope].unitFiles": (item_1)=>item_1 != null && item_1.id != null && item_1.deletedAt == null && item_1.unitID != null && unitIds.has(item_1.unitID) && item_1.fileID != null
                    }["SearchProvider.useCallback[loadLearnerScope].unitFiles"]);
                    const fileIds = Array.from(new Set(unitFiles.map({
                        "SearchProvider.useCallback[loadLearnerScope].fileIds": (item_2)=>item_2.fileID
                    }["SearchProvider.useCallback[loadLearnerScope].fileIds"])));
                    const files = await Promise.all(fileIds.map({
                        "SearchProvider.useCallback[loadLearnerScope]": async (fileId)=>{
                            try {
                                const response_0 = await client.models.File.get({
                                    id: fileId
                                });
                                return response_0?.data || null;
                            } catch  {
                                return null;
                            }
                        }
                    }["SearchProvider.useCallback[loadLearnerScope]"]));
                    const sectionItems = Array.from(sectionIds).map({
                        "SearchProvider.useCallback[loadLearnerScope].sectionItems": (sectionId)=>sectionById.get(sectionId)
                    }["SearchProvider.useCallback[loadLearnerScope].sectionItems"]).filter({
                        "SearchProvider.useCallback[loadLearnerScope].sectionItems": (section_0)=>section_0 != null
                    }["SearchProvider.useCallback[loadLearnerScope].sectionItems"]).map({
                        "SearchProvider.useCallback[loadLearnerScope].sectionItems": (section_1)=>({
                                type: "section",
                                id: section_1.id,
                                title: section_1.name || "Section",
                                description: section_1.description || section_1.code
                            })
                    }["SearchProvider.useCallback[loadLearnerScope].sectionItems"]);
                    const unitItems = units.filter({
                        "SearchProvider.useCallback[loadLearnerScope].unitItems": (unit)=>unit != null && unit.deletedAt == null
                    }["SearchProvider.useCallback[loadLearnerScope].unitItems"]).map({
                        "SearchProvider.useCallback[loadLearnerScope].unitItems": (unit_0)=>({
                                type: "unit",
                                id: unit_0.id,
                                title: unit_0.name || "Unit",
                                description: unit_0.description || undefined
                            })
                    }["SearchProvider.useCallback[loadLearnerScope].unitItems"]);
                    const fileItems = files.filter({
                        "SearchProvider.useCallback[loadLearnerScope].fileItems": (file)=>file != null && file.deletedAt == null
                    }["SearchProvider.useCallback[loadLearnerScope].fileItems"]).map({
                        "SearchProvider.useCallback[loadLearnerScope].fileItems": (file_0)=>({
                                type: "file",
                                id: file_0.id,
                                title: file_0.name || "File",
                                description: file_0.description || file_0.mimeType || file_0.path || undefined
                            })
                    }["SearchProvider.useCallback[loadLearnerScope].fileItems"]);
                    return {
                        sections: sectionItems,
                        units: unitItems,
                        files: fileItems
                    };
                }
            })["SearchProvider.useCallback[loadLearnerScope]"]();
            try {
                const scope = await loadingLearnerScopeRef.current;
                learnerScopeRef.current = scope;
                return scope;
            } finally{
                loadingLearnerScopeRef.current = null;
            }
        }
    }["SearchProvider.useCallback[loadLearnerScope]"], []);
    const loadBestBundle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "SearchProvider.useCallback[loadBestBundle]": async ()=>{
            const identityId = session?.identityId;
            if (!identityId) return null;
            if (!isPrivileged) {
                bundleRef.current = null;
                return null;
            }
            if (loadingBundleRef.current) {
                return loadingBundleRef.current;
            }
            loadingBundleRef.current = ({
                "SearchProvider.useCallback[loadBestBundle]": async ()=>{
                    // Privileged users get full content search bundle.
                    const instructorBundle = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$searchBundles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadInstructorBundle"])(identityId);
                    if (instructorBundle) return instructorBundle;
                    // Safety fallback for privileged users currently in a unit route.
                    if (currentUnitId) {
                        const unitBundle = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$searchBundles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadUnitBundle"])(identityId, currentUnitId);
                        if (unitBundle) return unitBundle;
                    }
                    return null;
                }
            })["SearchProvider.useCallback[loadBestBundle]"]();
            try {
                const bundle = await loadingBundleRef.current;
                bundleRef.current = bundle;
                return bundle;
            } finally{
                loadingBundleRef.current = null;
            }
        }
    }["SearchProvider.useCallback[loadBestBundle]"], [
        session?.identityId,
        currentUnitId,
        isPrivileged
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "SearchProvider.useEffect": ()=>{
            let cancelled = false;
            async function preloadData() {
                if (isPrivileged) {
                    const bundle = await loadBestBundle();
                    if (!cancelled) {
                        bundleRef.current = bundle;
                    }
                    return;
                }
                const scope = await loadLearnerScope();
                if (!cancelled) {
                    learnerScopeRef.current = scope;
                }
            }
            preloadData();
            return ({
                "SearchProvider.useEffect": ()=>{
                    cancelled = true;
                }
            })["SearchProvider.useEffect"];
        }
    }["SearchProvider.useEffect"], [
        loadBestBundle,
        loadLearnerScope,
        isPrivileged
    ]);
    // Read initial query from URL
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "SearchProvider.useEffect": ()=>{
            const q = searchParams.get("q");
            if (q && q !== state.query) {
                setState({
                    "SearchProvider.useEffect": (prev)=>({
                            ...prev,
                            query: q
                        })
                }["SearchProvider.useEffect"]);
                executeSearch(q);
            }
        }
    }["SearchProvider.useEffect"], []);
    const setQuery = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "SearchProvider.useCallback[setQuery]": (query)=>{
            setState({
                "SearchProvider.useCallback[setQuery]": (prev_0)=>({
                        ...prev_0,
                        query,
                        open: true
                    })
            }["SearchProvider.useCallback[setQuery]"]);
            // Debounce search execution
            if (debounceRef.current) clearTimeout(debounceRef.current);
            debounceRef.current = setTimeout({
                "SearchProvider.useCallback[setQuery]": ()=>{
                    if (query.trim().length >= 2) {
                        executeSearch(query);
                    } else {
                        setState({
                            "SearchProvider.useCallback[setQuery]": (prev_1)=>({
                                    ...prev_1,
                                    results: [],
                                    searching: false
                                })
                        }["SearchProvider.useCallback[setQuery]"]);
                    }
                }
            }["SearchProvider.useCallback[setQuery]"], 300);
        }
    }["SearchProvider.useCallback[setQuery]"], []);
    const executeSearch = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "SearchProvider.useCallback[executeSearch]": async (query_0)=>{
            if (!query_0.trim()) return;
            setState({
                "SearchProvider.useCallback[executeSearch]": (prev_2)=>({
                        ...prev_2,
                        searching: true
                    })
            }["SearchProvider.useCallback[executeSearch]"]);
            try {
                const parsed = parseSearchQuery(query_0);
                const cleanQuery = parsed.query;
                if (!cleanQuery) {
                    setState({
                        "SearchProvider.useCallback[executeSearch]": (prev_4)=>({
                                ...prev_4,
                                results: [],
                                searching: false
                            })
                    }["SearchProvider.useCallback[executeSearch]"]);
                    return;
                }
                const results = [];
                const includeBundle = isPrivileged && (parsed.type == null || parsed.type !== "chat");
                const includeLearnerScope = !isPrivileged && (parsed.type == null || parsed.type === "unit" || parsed.type === "section" || parsed.type === "file");
                const includeChat = parsed.type == null || parsed.type === "chat";
                if (includeBundle) {
                    let bundle_0 = bundleRef.current;
                    if (!bundle_0) {
                        bundle_0 = await loadBestBundle();
                    }
                    if (bundle_0) {
                        const { embedding } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$offline$2f$LocalEmbeddingModel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["embed"])(cleanQuery);
                        const bundleResults = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$searchBundles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["search"])(embedding, bundle_0, 10, 0.3, cleanQuery);
                        const mappedBundle = bundleResults.map({
                            "SearchProvider.useCallback[executeSearch].mappedBundle": (r)=>({
                                    type: r.item.type,
                                    id: r.item.id,
                                    title: r.item.title,
                                    description: r.item.meta.preview,
                                    score: r.score,
                                    page: r.item.meta.page,
                                    highlightTerm: cleanQuery
                                })
                        }["SearchProvider.useCallback[executeSearch].mappedBundle"]).filter({
                            "SearchProvider.useCallback[executeSearch].mappedBundle": (r_0)=>parsed.type ? r_0.type === parsed.type : true
                        }["SearchProvider.useCallback[executeSearch].mappedBundle"]);
                        results.push(...mappedBundle);
                    }
                }
                if (includeLearnerScope) {
                    let scope_0 = learnerScopeRef.current;
                    if (scope_0.sections.length === 0 && scope_0.units.length === 0 && scope_0.files.length === 0) {
                        scope_0 = await loadLearnerScope();
                    }
                    const scopedResults = searchLearnerScope(scope_0, cleanQuery, parsed.type);
                    results.push(...scopedResults);
                }
                if (includeChat) {
                    const chatMatches = await searchChatMessagesAsync(cleanQuery, {
                        limit: 10,
                        role: parsed.role,
                        author: parsed.author
                    });
                    const mappedChat = (chatMatches || []).map({
                        "SearchProvider.useCallback[executeSearch].mappedChat": (m)=>({
                                type: "chat",
                                id: m.id,
                                title: m.role === "assistant" ? "Assistant message" : "Your message",
                                description: m.snippet,
                                score: m.score,
                                highlightTerm: cleanQuery,
                                role: m.role || "unknown"
                            })
                    }["SearchProvider.useCallback[executeSearch].mappedChat"]);
                    results.push(...mappedChat);
                }
                results.sort({
                    "SearchProvider.useCallback[executeSearch]": (a, b)=>b.score - a.score
                }["SearchProvider.useCallback[executeSearch]"]);
                setState({
                    "SearchProvider.useCallback[executeSearch]": (prev_5)=>({
                            ...prev_5,
                            results,
                            searching: false
                        })
                }["SearchProvider.useCallback[executeSearch]"]);
            } catch (err) {
                console.error("[SearchContext] Search failed:", err);
                setState({
                    "SearchProvider.useCallback[executeSearch]": (prev_3)=>({
                            ...prev_3,
                            results: [],
                            searching: false
                        })
                }["SearchProvider.useCallback[executeSearch]"]);
            }
        }
    }["SearchProvider.useCallback[executeSearch]"], [
        searchChatMessagesAsync,
        loadBestBundle,
        loadLearnerScope,
        isPrivileged
    ]);
    const clearSearch = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "SearchProvider.useCallback[clearSearch]": ()=>{
            setState({
                query: "",
                results: [],
                searching: false,
                open: false
            });
            // Remove ?q= from URL
            const params = new URLSearchParams(searchParams.toString());
            params.delete("q");
            const newUrl = params.toString() ? `${window.location.pathname}?${params.toString()}` : window.location.pathname;
            router.replace(newUrl);
        }
    }["SearchProvider.useCallback[clearSearch]"], [
        searchParams,
        router
    ]);
    const setOpen = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "SearchProvider.useCallback[setOpen]": (open)=>{
            setState({
                "SearchProvider.useCallback[setOpen]": (prev_6)=>({
                        ...prev_6,
                        open
                    })
            }["SearchProvider.useCallback[setOpen]"]);
        }
    }["SearchProvider.useCallback[setOpen]"], []);
    const value = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "SearchProvider.useMemo[value]": ()=>({
                ...state,
                setQuery,
                executeSearch,
                clearSearch,
                setOpen
            })
    }["SearchProvider.useMemo[value]"], [
        state,
        setQuery,
        executeSearch,
        clearSearch,
        setOpen
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SearchContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/searchContext.tsx",
        lineNumber: 484,
        columnNumber: 10
    }, this);
}
_s(SearchProvider, "JOQc0QQSrCyzWIfC9i2sv5lucHs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = SearchProvider;
function useSearch() {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "b652281bc30194f4ba77d9d6eaf660d7dffc72a58a72bb23855b517c14e4d271") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b652281bc30194f4ba77d9d6eaf660d7dffc72a58a72bb23855b517c14e4d271";
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(SearchContext);
}
_s1(useSearch, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
function useLoadSearchBundle() {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "b652281bc30194f4ba77d9d6eaf660d7dffc72a58a72bb23855b517c14e4d271") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b652281bc30194f4ba77d9d6eaf660d7dffc72a58a72bb23855b517c14e4d271";
    }
    const bundleRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = ({
            "useLoadSearchBundle[loadForUnit]": async (identityId, unitId)=>{
                const bundle = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$searchBundles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadUnitBundle"])(identityId, unitId);
                bundleRef.current = bundle;
            }
        })["useLoadSearchBundle[loadForUnit]"];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const loadForUnit = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "useLoadSearchBundle[loadForInstructor]": async (identityId_0)=>{
                const bundle_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$searchBundles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadInstructorBundle"])(identityId_0);
                bundleRef.current = bundle_0;
            }
        })["useLoadSearchBundle[loadForInstructor]"];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const loadForInstructor = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            loadForUnit,
            loadForInstructor
        };
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_s2(useLoadSearchBundle, "8ULv5HIOQD7IGdBxRSl2yxMYNzo=");
const __TURBOPACK__default__export__ = SearchContext;
var _c;
__turbopack_context__.k.register(_c, "SearchProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/tourContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TourProvider",
    ()=>TourProvider,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useTour",
    ()=>useTour,
    "useTourSafe",
    ()=>useTourSafe
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * Tour Context
 * 
 * Provides tour/onboarding functionality throughout the main application.
 * Exposes the same tour system available in Storybook's OnboardingPanel
 * to the chatbot and other components.
 * 
 * Features:
 * - Start/stop guided tours
 * - Track tour progress
 * - Integrate with SpotlightOverlay
 * - Expose tours to chatbot tools
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatTools$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/chatTools.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
;
// Import tour tasks and configurations from Storybook code
// Note: These are TypeScript files but can be imported in JS/TS with proper config
const ONBOARDING_TASKS = [
    // We'll populate this from a static import or API
    // For now, define a minimal set that covers the most important tours
    {
        id: 'instructor-setup-class',
        title: 'Set Up Your First Class',
        description: 'Create a new class section for your students',
        instructions: [
            'Navigate to the Sections page',
            'Click "Create Section" button',
            'Enter a class name',
            'Save your section',
            'Share the join code with students'
        ],
        persona: 'instructor',
        category: 'Getting Started',
        order: 1,
        estimatedTime: 300
    },
    {
        id: 'instructor-create-unit',
        title: 'Create Your First Unit',
        description: 'Build interactive learning content',
        instructions: [
            'Go to the Units page',
            'Click "Create New Unit"',
            'Enter a title',
            'Use the Editor to add content',
            'Save your unit'
        ],
        persona: 'instructor',
        category: 'Content Creation',
        order: 2,
        estimatedTime: 600
    },
    {
        id: 'instructor-add-quiz',
        title: 'Add a Quiz Block',
        description: 'Create assessment questions in your unit',
        instructions: [
            'Open your unit in the Editor',
            'Click the "+ Insert" button in the toolbar',
            'Select "Multiple Choice Quiz" from the dropdown menu',
            'Enter your question text',
            'Add 2-4 answer choices',
            'Mark the correct answer',
            'Save the unit'
        ],
        persona: 'instructor',
        category: 'Content Creation',
        order: 3,
        estimatedTime: 300
    },
    {
        id: 'instructor-create-vocabulary',
        title: 'Add Vocabulary Words',
        description: 'Build your class dictionary',
        instructions: [
            'Navigate to Dictionary Editor in left sidebar',
            'Click "Add Word" button',
            'Enter word and definition',
            'Save to dictionary'
        ],
        persona: 'instructor',
        category: 'Content Management',
        order: 4,
        estimatedTime: 360
    },
    {
        id: 'instructor-create-assignment',
        title: 'Assign Work to Students',
        description: 'Set up assignments with due dates',
        instructions: [
            'Go to your Section',
            'Click "Create Assignment"',
            'Select a unit to assign',
            'Set a due date',
            'Assign to your section'
        ],
        persona: 'instructor',
        category: 'Assignments',
        order: 5,
        estimatedTime: 240
    },
    {
        id: 'instructor-use-ai-assistant',
        title: 'Use AI to Generate Content',
        description: 'Leverage AI assistance for content creation',
        instructions: [
            'Open the ChatSidebar',
            'Ask AI to help create content',
            'Review and refine AI suggestions',
            'Insert content into your unit'
        ],
        persona: 'instructor',
        category: 'AI Tools',
        order: 7,
        estimatedTime: 420
    },
    {
        id: 'learner-join-class',
        title: 'Join Your First Class',
        description: 'Use a join code to enroll in a class',
        instructions: [
            'Go to Sections page',
            'Click "Join Section"',
            'Enter the join code from your instructor',
            'Confirm enrollment'
        ],
        persona: 'learner',
        category: 'Getting Started',
        order: 1,
        estimatedTime: 180
    },
    {
        id: 'learner-complete-assignment',
        title: 'Complete an Assignment',
        description: 'Work through unit content and submit',
        instructions: [
            'Go to your Assignments',
            'Click on an assignment',
            'Read through the content',
            'Answer quiz questions',
            'Complete all sections'
        ],
        persona: 'learner',
        category: 'Coursework',
        order: 3,
        estimatedTime: 720
    },
    {
        id: 'learner-use-chat-help',
        title: 'Get Help from AI Assistant',
        description: 'Use the AI chatbot for learning support',
        instructions: [
            'Open the ChatSidebar',
            'Ask questions about content',
            'Request explanations',
            'Get practice suggestions'
        ],
        persona: 'learner',
        category: 'Learning Support',
        order: 6,
        estimatedTime: 300
    }
];
const TourContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
const TourProvider = (t0)=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "7cdaf2696f169b69f77ceb7f54cf70d3b7d2661e0adf681c1952301348093b15") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7cdaf2696f169b69f77ceb7f54cf70d3b7d2661e0adf681c1952301348093b15";
    }
    const { children } = t0;
    const [currentTour, setCurrentTour] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentMode, setCurrentMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isActive, setIsActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = (tourId, t2)=>{
            const mode = t2 === undefined ? "tutorial" : t2;
            console.log("[TourContext] Starting tour:", tourId, "mode:", mode);
            const tour = ONBOARDING_TASKS.find((t)=>t.id === tourId);
            if (!tour) {
                console.error("[TourContext] Tour not found:", tourId);
                return;
            }
            setCurrentTour(tourId);
            setCurrentMode(mode);
            setIsActive(true);
            window.dispatchEvent(new CustomEvent("tour:start", {
                detail: {
                    tourId,
                    mode,
                    tour
                }
            }));
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const startTour = t1;
    let t2;
    if ($[2] !== currentTour) {
        t2 = ()=>{
            console.log("[TourContext] Stopping tour:", currentTour);
            setCurrentTour(null);
            setCurrentMode(null);
            setIsActive(false);
            window.dispatchEvent(new CustomEvent("tour:stop"));
        };
        $[2] = currentTour;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const stopTour = t2;
    const getAvailableTours = _temp;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [];
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(_temp2, t3);
    let t4;
    let t5;
    if ($[5] !== stopTour) {
        t4 = ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                console.log("[TourContext] Exposing tour methods to window for testing");
                window.startTour = startTour;
                window.stopTour = stopTour;
                window.getAvailableTours = getAvailableTours;
                return _temp3;
            }
        };
        t5 = [
            startTour,
            stopTour,
            getAvailableTours
        ];
        $[5] = stopTour;
        $[6] = t4;
        $[7] = t5;
    } else {
        t4 = $[6];
        t5 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t4, t5);
    let t6;
    if ($[8] !== currentMode || $[9] !== currentTour || $[10] !== isActive || $[11] !== stopTour) {
        t6 = {
            startTour,
            stopTour,
            currentTour,
            currentMode,
            isActive,
            getAvailableTours
        };
        $[8] = currentMode;
        $[9] = currentTour;
        $[10] = isActive;
        $[11] = stopTour;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    const value = t6;
    let t7;
    if ($[13] !== children || $[14] !== value) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TourContext.Provider, {
            value: value,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/context/tourContext.tsx",
            lineNumber: 234,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[13] = children;
        $[14] = value;
        $[15] = t7;
    } else {
        t7 = $[15];
    }
    return t7;
};
_s(TourProvider, "gMfIUJL7OJXDnazr+tpYS9w1BoA=");
_c = TourProvider;
const useTour = ()=>{
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "7cdaf2696f169b69f77ceb7f54cf70d3b7d2661e0adf681c1952301348093b15") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7cdaf2696f169b69f77ceb7f54cf70d3b7d2661e0adf681c1952301348093b15";
    }
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(TourContext);
    if (!context) {
        throw new Error("useTour must be used within a TourProvider");
    }
    return context;
};
_s1(useTour, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
const useTourSafe = ()=>{
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "7cdaf2696f169b69f77ceb7f54cf70d3b7d2661e0adf681c1952301348093b15") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7cdaf2696f169b69f77ceb7f54cf70d3b7d2661e0adf681c1952301348093b15";
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(TourContext);
};
_s2(useTourSafe, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
const __TURBOPACK__default__export__ = TourContext;
function _temp() {
    return ONBOARDING_TASKS;
}
function _temp2() {
    console.log("[TourContext] Initializing tour system with", ONBOARDING_TASKS.length, "tasks");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatTools$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setTourTasksData"])(ONBOARDING_TASKS);
}
function _temp3() {
    delete window.startTour;
    delete window.stopTour;
    delete window.getAvailableTours;
}
var _c;
__turbopack_context__.k.register(_c, "TourProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/reducers/unitReducer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "actionTypes",
    ()=>actionTypes,
    "initialState",
    ()=>initialState,
    "unitReducer",
    ()=>unitReducer
]);
const initialState = {
    unit: {},
    dictionary: {},
    questionBank: {},
    files: {},
    rubric: [],
    finishedQuestions: 0,
    showUnitComplete: false,
    personalBestResult: null,
    playlistUrls: {},
    username: null,
    permissionError: null,
    isSaving: false,
    grade: {},
    recentGrades: [],
    practiceSessions: []
};
const actionTypes = {
    SET_UNIT: 'SET_UNIT',
    SET_DICTIONARY: 'SET_DICTIONARY',
    SET_QUESTION_BANK: 'SET_QUESTION_BANK',
    SET_FILES: 'SET_FILES',
    SET_RUBRIC: 'SET_RUBRIC',
    SET_FINISHED_QUESTIONS: 'SET_FINISHED_QUESTIONS',
    SET_SHOW_UNIT_COMPLETE: 'SET_SHOW_UNIT_COMPLETE',
    SET_PERSONAL_BEST_RESULT: 'SET_PERSONAL_BEST_RESULT',
    SET_PLAYLIST_URLS: 'SET_PLAYLIST_URLS',
    SET_USERNAME: 'SET_USERNAME',
    SET_PERMISSION_ERROR: 'SET_PERMISSION_ERROR',
    SET_IS_SAVING: 'SET_IS_SAVING',
    SET_GRADE: 'SET_GRADE',
    SET_RECENT_GRADES: 'SET_RECENT_GRADES',
    SET_PRACTICE_SESSIONS: 'SET_PRACTICE_SESSIONS',
    UNIT_LOADED: 'UNIT_LOADED',
    UNIT_CLEARED: 'UNIT_CLEARED',
    GRADE_SUBSCRIPTION_UPDATE: 'GRADE_SUBSCRIPTION_UPDATE'
};
function unitReducer(state, action) {
    switch(action.type){
        case actionTypes.SET_UNIT:
            return {
                ...state,
                unit: action.payload
            };
        case actionTypes.SET_DICTIONARY:
            return {
                ...state,
                dictionary: action.payload
            };
        case actionTypes.SET_QUESTION_BANK:
            return {
                ...state,
                questionBank: action.payload
            };
        case actionTypes.SET_FILES:
            return {
                ...state,
                files: action.payload
            };
        case actionTypes.SET_RUBRIC:
            return {
                ...state,
                rubric: action.payload
            };
        case actionTypes.SET_FINISHED_QUESTIONS:
            return {
                ...state,
                finishedQuestions: action.payload
            };
        case actionTypes.SET_SHOW_UNIT_COMPLETE:
            return {
                ...state,
                showUnitComplete: action.payload
            };
        case actionTypes.SET_PERSONAL_BEST_RESULT:
            return {
                ...state,
                personalBestResult: action.payload
            };
        case actionTypes.SET_PLAYLIST_URLS:
            return {
                ...state,
                playlistUrls: action.payload
            };
        case actionTypes.SET_USERNAME:
            return {
                ...state,
                username: action.payload
            };
        case actionTypes.SET_PERMISSION_ERROR:
            return {
                ...state,
                permissionError: action.payload
            };
        case actionTypes.SET_IS_SAVING:
            return {
                ...state,
                isSaving: action.payload
            };
        case actionTypes.SET_GRADE:
            return {
                ...state,
                grade: action.payload
            };
        case actionTypes.SET_RECENT_GRADES:
            return {
                ...state,
                recentGrades: action.payload
            };
        case actionTypes.SET_PRACTICE_SESSIONS:
            {
                const sessions = action.payload;
                // Skip if same count and no version changes
                if (state.practiceSessions.length === sessions.length && sessions.length > 0) {
                    const anyNewer = sessions.some((s)=>{
                        const existing = state.practiceSessions.find((e)=>e.id === s.id);
                        return !existing || (s._version || 0) > (existing._version || 0);
                    });
                    if (!anyNewer) return state; // No changes, skip re-render
                }
                return {
                    ...state,
                    practiceSessions: sessions
                };
            }
        case actionTypes.UNIT_LOADED:
            return {
                ...state,
                unit: action.payload.unit,
                dictionary: action.payload.dictionary,
                files: action.payload.files,
                playlistUrls: action.payload.playlistUrls,
                questionBank: action.payload.questionBank,
                rubric: action.payload.rubric,
                permissionError: null
            };
        case actionTypes.UNIT_CLEARED:
            return {
                ...state,
                unit: {},
                permissionError: null
            };
        case actionTypes.GRADE_SUBSCRIPTION_UPDATE:
            {
                const { grade, username, showUnitComplete, finishedQuestions, recentGrades } = action.payload;
                // Skip if current grade hasn't changed version
                if (state.grade?.id && grade?.id === state.grade.id && grade?._version != null && grade._version <= (state.grade._version || 0) && state.recentGrades.length === recentGrades.length) {
                    return state; // Not newer, skip re-render
                }
                return {
                    ...state,
                    grade,
                    username,
                    showUnitComplete,
                    finishedQuestions,
                    recentGrades
                };
            }
        default:
            return state;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/unitContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UnitProvider",
    ()=>UnitProvider,
    "default",
    ()=>__TURBOPACK__default__export__,
    "gradedBlockTypes",
    ()=>gradedBlockTypes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$yaml$2f$dist$2f$js$2d$yaml$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/js-yaml/dist/js-yaml.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$moderateContent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/moderateContent.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$unitContentStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/unitContentStorage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$offline$2f$saveGradeOffline$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/offline/saveGradeOffline.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$180649__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:180649 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$7e23cc__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:7e23cc [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$8a8fb6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:8a8fb6 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$a6e649__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:a6e649 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/workbookHooks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/reducers/unitReducer.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
// Provider and Consumer are connected through their "parent" context
/** @type {import('react').Context<Record<string, any>>} */ const UnitContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({});
const gradedBlockTypes = [
    "quiz",
    "meaning-association",
    "answer",
    "custom-answer",
    "custom-ai"
];
const UnitProvider = ({ children, id })=>{
    _s();
    // Get auth state from centralized context
    const { user, session: authSession, isLoading: authLoading } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unitReducer"], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"]);
    const [sectionId, setSectionId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](undefined);
    const savingCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const versionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0); // Store _version to detect changes and prevent rerenders
    const practiceSessionVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    const gradeVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    const editorStateRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    const editorSelectionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    const editorRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const unitRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    const usernameRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const workbookCollaborationRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null); // Ref to access workbook collaboration from saveGrade
    // Memoize derived values to prevent recalculation on every render
    const name = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "UnitProvider.useMemo[name]": ()=>state.unit?.name
    }["UnitProvider.useMemo[name]"], [
        state.unit?.name
    ]);
    const description = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "UnitProvider.useMemo[description]": ()=>state.unit?.description
    }["UnitProvider.useMemo[description]"], [
        state.unit?.description
    ]);
    const timeLimitSeconds = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "UnitProvider.useMemo[timeLimitSeconds]": ()=>state.unit?.timeLimitSeconds
    }["UnitProvider.useMemo[timeLimitSeconds]"], [
        state.unit?.timeLimitSeconds
    ]);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    // const [featuredImageUrl, setFeaturedImageUrl] = React.useState(null);
    // Memoize derived values to prevent recalculation on every render
    const rubricLength = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "UnitProvider.useMemo[rubricLength]": ()=>state.rubric.length || 0
    }["UnitProvider.useMemo[rubricLength]"], [
        state.rubric.length
    ]);
    const unitVersion = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "UnitProvider.useMemo[unitVersion]": ()=>state.unit?._version || 0
    }["UnitProvider.useMemo[unitVersion]"], [
        state.unit?._version
    ]);
    const unitOwner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "UnitProvider.useMemo[unitOwner]": ()=>state.unit?.owner || ""
    }["UnitProvider.useMemo[unitOwner]"], [
        state.unit?.owner
    ]);
    /**
   * Check if the current user has permission to EDIT the unit (strict check)
   * Returns true if:
   * - User is the owner of the unit
   * - User is in Instructors, Moderators, or Admins group
   * - Unit status is PUBLISHED (public access for viewing)
   */ const checkUnitEditPermission = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[checkUnitEditPermission]": (unit, currentUser, userGroups)=>{
            if (!unit || !unit.id) {
                return {
                    hasAccess: false,
                    reason: null
                }; // Unit not loaded yet
            }
            // If unit is published, anyone can view it (learners can read published units)
            if (unit.status === "PUBLISHED") {
                return {
                    hasAccess: true,
                    reason: null
                };
            }
            // Check if user is authenticated
            if (!currentUser) {
                return {
                    hasAccess: false,
                    reason: "You must be signed in to access this content."
                };
            }
            const userId = currentUser?.attributes?.sub;
            const groups = userGroups || [];
            // Check if user is owner
            if (unit.owner === userId) {
                return {
                    hasAccess: true,
                    reason: null
                };
            }
            // Check if user is in privileged groups
            const hasInstructorAccess = groups.some({
                "UnitProvider.useCallback[checkUnitEditPermission].hasInstructorAccess": (group)=>[
                        "Instructors",
                        "Moderators",
                        "Admins"
                    ].includes(group)
            }["UnitProvider.useCallback[checkUnitEditPermission].hasInstructorAccess"]);
            if (hasInstructorAccess) {
                return {
                    hasAccess: true,
                    reason: null
                };
            }
            // No access to edit
            return {
                hasAccess: false,
                reason: "You do not have permission to edit this unit. Only the owner or instructors can edit unpublished units."
            };
        }
    }["UnitProvider.useCallback[checkUnitEditPermission]"], []);
    /**
   * Check if the current user has permission to VIEW the unit in workbook (permissive check)
   * Workbook is for completing assignments, so it's more accessible than the editor.
   * Returns true if:
   * - User is authenticated (learners can work on any published or assigned units)
   * - Unit is published (anyone can access)
   * - User is owner or instructor (can access any unit)
   */ const checkUnitViewPermission = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[checkUnitViewPermission]": (unit_0, currentUser_0, userGroups_0)=>{
            if (!unit_0 || !unit_0.id) {
                return {
                    hasAccess: false,
                    reason: null
                }; // Unit not loaded yet
            }
            // If unit is published, anyone can view it
            if (unit_0.status === "PUBLISHED") {
                return {
                    hasAccess: true,
                    reason: null
                };
            }
            // Check if user is authenticated
            if (!currentUser_0) {
                return {
                    hasAccess: false,
                    reason: "You must be signed in to access this content."
                };
            }
            const userId_0 = currentUser_0?.attributes?.sub;
            const groups_0 = userGroups_0 || [];
            // Check if user is owner
            if (unit_0.owner === userId_0) {
                return {
                    hasAccess: true,
                    reason: null
                };
            }
            // Check if user is in privileged groups (instructors can view all units)
            const hasInstructorAccess_0 = groups_0.some({
                "UnitProvider.useCallback[checkUnitViewPermission].hasInstructorAccess_0": (group_0)=>[
                        "Instructors",
                        "Moderators",
                        "Admins"
                    ].includes(group_0)
            }["UnitProvider.useCallback[checkUnitViewPermission].hasInstructorAccess_0"]);
            if (hasInstructorAccess_0) {
                return {
                    hasAccess: true,
                    reason: null
                };
            }
            // For workbook/viewing: Allow authenticated learners to access
            // The backend (Grade creation, Assignment checks) will enforce actual access control
            // This allows students to view units they have assignments for
            return {
                hasAccess: true,
                reason: null
            };
        }
    }["UnitProvider.useCallback[checkUnitViewPermission]"], []);
    // NOTE: Authentication is now handled by centralized AuthContext
    // Update usernameRef when user changes
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "UnitProvider.useEffect": ()=>{
            if (user?.attributes?.sub) {
                usernameRef.current = user.attributes.sub;
            } else {
                usernameRef.current = null;
            }
        }
    }["UnitProvider.useEffect"], [
        user
    ]);
    // Derive sectionId from Assignment record (server-authoritative, not URL)
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "UnitProvider.useEffect": ()=>{
            if (!id || authLoading || !user) return;
            let cancelled = false;
            const client1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            async function lookupAssignment() {
                try {
                    const { data: assignments } = await client1.models.Assignment.list({
                        filter: {
                            unitID: {
                                eq: id
                            }
                        }
                    });
                    if (cancelled) return;
                    // Use the first assignment that matches this unit for the current user
                    const assignment = (assignments || []).find({
                        "UnitProvider.useEffect.lookupAssignment.assignment": (a)=>a != null && a.sectionID
                    }["UnitProvider.useEffect.lookupAssignment.assignment"]);
                    if (assignment?.sectionID) {
                        setSectionId(assignment.sectionID);
                    }
                } catch (err) {
                    if (!cancelled) {
                        console.warn("[UnitContext] Failed to look up Assignment for sectionId:", err);
                    }
                }
            }
            lookupAssignment();
            return ({
                "UnitProvider.useEffect": ()=>{
                    cancelled = true;
                }
            })["UnitProvider.useEffect"];
        }
    }["UnitProvider.useEffect"], [
        id,
        user,
        authLoading
    ]);
    const verifyAccuracy = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[verifyAccuracy]": (data)=>{
            let total = 0;
            let accuracy = 0;
            if (data) {
                Object.entries(data).forEach({
                    "UnitProvider.useCallback[verifyAccuracy]": (g)=>{
                        if (g[1]?.complete === true && g[1]?.accuracy) {
                            let _accuracy = parseInt(g[1]?.accuracy);
                            if (_accuracy > 1) {
                                _accuracy = _accuracy / 100;
                            }
                            total++;
                            accuracy += _accuracy;
                        }
                        if (g[1]?.learn?.accuracy) {
                            total++;
                            accuracy += parseInt(g[1]?.learn?.accuracy);
                        }
                        if (g[1]?.easy?.accuracy) {
                            total++;
                            accuracy += parseInt(g[1]?.easy?.accuracy);
                        }
                        if (g[1]?.hard?.accuracy) {
                            total++;
                            accuracy += parseInt(g[1]?.hard?.accuracy);
                        }
                    }
                }["UnitProvider.useCallback[verifyAccuracy]"]);
            }
            accuracy = accuracy / total;
            return accuracy * 100;
        }
    }["UnitProvider.useCallback[verifyAccuracy]"], []);
    const createGrade = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[createGrade]": async (unitAccuracy, unitIsComplete)=>{
            // Ensure we have authentication before creating grade
            // Check both the ref (for production) and direct user (for tests where useEffect may not have run)
            const currentUsername = usernameRef.current || user?.attributes?.sub;
            if (!currentUsername) {
                throw new Error("User not authenticated - cannot create grade");
            }
            const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const currentUnit = unitRef.current;
            const { data: _grade, errors } = await client_0.models.Grade.create({
                unitID: id,
                sectionID: sectionId || undefined,
                // use the unit owner as the instructor
                instructor: currentUnit?.owner || "",
                // Owner will be auto-populated by Amplify based on auth
                unitVersion: currentUnit?._version || 1,
                complete: unitIsComplete,
                accuracy: unitAccuracy,
                timerStarted: currentUnit?.timeLimitSeconds > 0 ? true : null
            });
            if (errors) {
                console.error("[createGrade] Error creating grade:", errors);
                throw new Error("Failed to create grade");
            }
            dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_GRADE,
                payload: _grade
            });
            // Award XP for submitting homework (first time only — dedup by gradeId)
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$180649__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["awardXP"])(currentUsername, "HOMEWORK_SUBMITTED", _grade.id, sectionId || undefined, id);
            return _grade;
        }
    }["UnitProvider.useCallback[createGrade]"], [
        id,
        sectionId,
        user
    ]);
    /**
   * Calls GPT-4o-mini to produce an overall feedback summary for the completed grade.
   * Sends assignment (unit name, description, rubric) and grade data as YAML.
   * Stores result in Grade.feedback.
   */ const summarizeGradeFeedback = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[summarizeGradeFeedback]": async (gradeData, gradeId)=>{
            const client_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            // Build assignment context as YAML
            const assignmentYaml = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$yaml$2f$dist$2f$js$2d$yaml$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dump({
                name: name || "",
                description: description || "",
                rubric_blocks: state.rubric
            });
            // Build grade data as YAML (per-block results)
            const blocks = {};
            if (gradeData) {
                Object.entries(gradeData).forEach({
                    "UnitProvider.useCallback[summarizeGradeFeedback]": ([blockId, block])=>{
                        blocks[blockId] = {
                            complete: !!block?.complete,
                            accuracy: block?.accuracy ?? null,
                            ...block?.userAnswer && {
                                userAnswer: String(block.userAnswer).slice(0, 200)
                            },
                            ...block?.feedback && {
                                aiFeedback: String(block.feedback).slice(0, 200)
                            }
                        };
                    }
                }["UnitProvider.useCallback[summarizeGradeFeedback]"]);
            }
            const gradeYaml = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$yaml$2f$dist$2f$js$2d$yaml$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dump({
                blocks
            });
            let feedbackJson;
            try {
                feedbackJson = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$a6e649__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["summarizeFeedback"])({
                    assignmentData: assignmentYaml,
                    gradeData: gradeYaml
                });
            } catch (err_0) {
                console.error("[unitContext] summarizeFeedback failed:", err_0?.message);
                return;
            }
            if (!feedbackJson) {
                console.error("[unitContext] summarizeFeedback returned empty");
                return;
            }
            // Parse and store in Grade.feedback
            try {
                const feedback = JSON.parse(feedbackJson);
                await client_1.models.Grade.update({
                    id: gradeId,
                    feedback: JSON.stringify(feedback)
                });
            } catch (parseErr) {
                // If the model didn't return valid JSON, store as plain overall text
                await client_1.models.Grade.update({
                    id: gradeId,
                    feedback: JSON.stringify({
                        overall: feedbackJson
                    })
                });
            }
        }
    }["UnitProvider.useCallback[summarizeGradeFeedback]"], [
        name,
        description,
        state.rubric
    ]);
    const saveGrade = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[saveGrade]": async (data_0)=>{
            // let _grade = grade
            // Count the total number of expected questions to later compare to the number expected in the unit
            let _finishedQuestions = 0;
            if (data_0) {
                Object.entries(data_0).forEach({
                    "UnitProvider.useCallback[saveGrade]": (g_0)=>{
                        if (g_0[1]?.complete === true) {
                            _finishedQuestions++;
                        }
                    }
                }["UnitProvider.useCallback[saveGrade]"]);
            }
            let unitIsComplete_0 = false;
            let unitAccuracy_0 = null;
            if (_finishedQuestions === rubricLength) {
                unitIsComplete_0 = true;
                unitAccuracy_0 = verifyAccuracy(data_0);
            }
            dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_FINISHED_QUESTIONS,
                payload: _finishedQuestions
            });
            // Sync block-level updates to Yjs for real-time collaboration with tutors
            if (data_0 && workbookCollaborationRef.current?.provider) {
                Object.entries(data_0).forEach({
                    "UnitProvider.useCallback[saveGrade]": ([blockId_0, blockData])=>{
                        workbookCollaborationRef.current.updateBlock(blockId_0, blockData);
                    }
                }["UnitProvider.useCallback[saveGrade]"]);
            }
            try {
                // Save grade first, then kick off moderation (backend persists to record)
                let gradeId_0 = state.grade?.id;
                // Helper: persist grade via offline-aware path
                const persistGrade = {
                    "UnitProvider.useCallback[saveGrade].persistGrade": async (id_0)=>{
                        const gradeParams = {
                            gradeId: id_0,
                            unitId: state.unit?.id || "",
                            sectionId,
                            data: data_0,
                            accuracy: unitAccuracy_0,
                            complete: unitIsComplete_0,
                            version: state.grade?._version
                        };
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$offline$2f$saveGradeOffline$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveGradeOfflineAware"])(gradeParams, {
                            "UnitProvider.useCallback[saveGrade].persistGrade": async (params)=>{
                                const client_2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                                await client_2.models.Grade.update({
                                    id: params.gradeId,
                                    data: JSON.stringify(params.data),
                                    accuracy: params.accuracy,
                                    complete: params.complete
                                });
                            }
                        }["UnitProvider.useCallback[saveGrade].persistGrade"]);
                    }
                }["UnitProvider.useCallback[saveGrade].persistGrade"];
                if (!state.grade) {
                    const newGrade = await createGrade(unitAccuracy_0, unitIsComplete_0);
                    if (newGrade && newGrade.id) {
                        gradeId_0 = newGrade.id;
                        await persistGrade(newGrade.id);
                    }
                } else if (state.grade && state.grade.id) {
                    await persistGrade(state.grade.id);
                } else {
                    console.error("Invalid grade object:", state.grade);
                    const newGrade_0 = await createGrade(unitAccuracy_0, unitIsComplete_0);
                    if (newGrade_0 && newGrade_0.id) {
                        gradeId_0 = newGrade_0.id;
                        await persistGrade(newGrade_0.id);
                    }
                }
                // Moderate async — backend fetches _version and writes to Grade.moderation
                if (gradeId_0) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$moderateContent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["moderateContent"])(data_0, {
                        modelName: "Grade",
                        recordId: gradeId_0,
                        sectionId,
                        ownerId: user?.attributes?.sub
                    }).then({
                        "UnitProvider.useCallback[saveGrade]": (result)=>{
                            if (result.flagged) {
                                console.warn("[UnitContext] Student submission flagged by moderation, saving for instructor review", {
                                    categories: result.categories,
                                    username: user?.attributes?.sub
                                });
                            }
                        }
                    }["UnitProvider.useCallback[saveGrade]"]);
                }
                if (unitIsComplete_0 && !timeLimitSeconds) {
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SHOW_UNIT_COMPLETE,
                        payload: true
                    });
                    // Award XP + badges + streak + personal best via batched Server Action
                    const currentUsername_0 = usernameRef.current || user?.attributes?.sub;
                    if (currentUsername_0 && state.grade?.id) {
                        // Primary: Server Action batches XP, badges, streak, personal best, easter eggs
                        ({
                            "UnitProvider.useCallback[saveGrade]": async ()=>{
                                try {
                                    const result_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$7e23cc__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["recordGradeCompletion"])(currentUsername_0, id, unitAccuracy_0, state.grade.id, undefined, sectionId || undefined);
                                    // Show personal best banner if applicable
                                    if (result_0?.personalBest?.isNewBest) {
                                        dispatch({
                                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_PERSONAL_BEST_RESULT,
                                            payload: result_0.personalBest
                                        });
                                    }
                                } catch (err_1) {
                                    console.error("[unitContext] recordGradeCompletion failed:", err_1?.message);
                                }
                            }
                        })["UnitProvider.useCallback[saveGrade]"]();
                        // Summarize feedback via GPT-4o-mini (fire-and-forget)
                        summarizeGradeFeedback(data_0, state.grade.id).catch({
                            "UnitProvider.useCallback[saveGrade]": (err_2)=>console.error("[unitContext] summarizeGradeFeedback error:", err_2)
                        }["UnitProvider.useCallback[saveGrade]"]);
                        // Evaluate skills linked to this unit (fire-and-forget)
                        client.mutations.evaluateSkillsForUnit({
                            studentId: currentUsername_0,
                            unitId: id,
                            cohortId: sectionId || undefined
                        }).catch({
                            "UnitProvider.useCallback[saveGrade]": (err_3)=>console.warn("[unitContext] Skill evaluation:", err_3)
                        }["UnitProvider.useCallback[saveGrade]"]);
                        // Update per-unit learning memory with block-level accuracy data
                        const weakAreas = [];
                        const strongAreas = [];
                        if (data_0) {
                            Object.entries(data_0).forEach({
                                "UnitProvider.useCallback[saveGrade]": ([blockKey, blockData_0])=>{
                                    if (blockData_0?.complete && blockData_0?.accuracy != null) {
                                        const acc = parseInt(blockData_0.accuracy);
                                        const label = blockKey.slice(0, 60);
                                        if (acc < 70) weakAreas.push(label);
                                        else if (acc >= 90) strongAreas.push(label);
                                    }
                                }
                            }["UnitProvider.useCallback[saveGrade]"]);
                        }
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$8a8fb6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["updateLearningMemory"])(currentUsername_0, id, unitAccuracy_0, weakAreas, strongAreas, {
                            sourceType: "workbook"
                        }).catch({
                            "UnitProvider.useCallback[saveGrade]": (err_4)=>console.error("[unitContext] updateLearningMemory error:", err_4)
                        }["UnitProvider.useCallback[saveGrade]"]);
                    }
                }
            } catch (error) {
                console.error("Error saving grade:", error);
                console.error("Error details:", {
                    message: error.message,
                    stack: error.stack,
                    name: error.name,
                    cause: error.cause
                });
                // If it's an authentication error, try to refresh auth
                if (error.message?.includes("auth") || error.message?.includes("Auth")) {
                    console.log("Authentication error detected, attempting to fetch user...");
                    try {
                        await fetchCurrentUsername();
                    } catch (authError) {
                        console.error("Failed to refresh authentication:", authError);
                    }
                }
                // Re-throw to let calling code handle it
                throw error;
            }
        }
    }["UnitProvider.useCallback[saveGrade]"], [
        rubricLength,
        state.grade,
        createGrade,
        timeLimitSeconds
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "UnitProvider.useEffect": ()=>{
            // Wait for auth to be ready
            if (authLoading || !user) {
                return;
            }
            // Validate required fields before subscribing
            if (!id) {
                return;
            }
            const username = user.attributes.sub;
            // Validate username
            if (!username) {
                console.warn("[UnitContext] No username available, skipping Grade subscription");
                return;
            }
            const client_3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            let cancelled_0 = false;
            function processGrades(validItems) {
                // Filter client-side
                const incompleteGrades = validItems.filter({
                    "UnitProvider.useEffect.processGrades.incompleteGrades": (grade)=>!grade.complete
                }["UnitProvider.useEffect.processGrades.incompleteGrades"]);
                const completedGrades = validItems.filter({
                    "UnitProvider.useEffect.processGrades.completedGrades": (grade_0)=>grade_0.complete
                }["UnitProvider.useEffect.processGrades.completedGrades"]);
                // Handle current grade (most recent incomplete)
                const currentGrade = incompleteGrades[0];
                // Parse grade.data from JSON string to object so all consumers get an object
                if (currentGrade?.data && typeof currentGrade.data === "string") {
                    try {
                        currentGrade.data = JSON.parse(currentGrade.data);
                    } catch (e) {
                        console.error("[UnitContext] Failed to parse grade.data:", e);
                        currentGrade.data = {};
                    }
                }
                // If there are completed grades but no current incomplete grade,
                // show the completion screen (persists across navigation)
                const showComplete = !currentGrade && completedGrades.length > 0;
                // Calculate finished questions from the current grade data
                let _finishedQuestions_0 = 0;
                if (currentGrade?.data) {
                    const gradeData_0 = currentGrade.data;
                    Object.entries(gradeData_0).forEach({
                        "UnitProvider.useEffect.processGrades": ([key, value])=>{
                            if (value?.complete === true) {
                                _finishedQuestions_0++;
                            }
                        }
                    }["UnitProvider.useEffect.processGrades"]);
                }
                // Handle recent grades (top 5 completed, sorted by accuracy then date)
                const sortedCompletedGrades = completedGrades.sort({
                    "UnitProvider.useEffect.processGrades.sortedCompletedGrades": (a_0, b)=>{
                        if (b.accuracy !== a_0.accuracy) {
                            return (b.accuracy || 0) - (a_0.accuracy || 0);
                        }
                        return new Date(b.createdAt).getTime() - new Date(a_0.createdAt).getTime();
                    }
                }["UnitProvider.useEffect.processGrades.sortedCompletedGrades"]).slice(0, 5);
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].GRADE_SUBSCRIPTION_UPDATE,
                    payload: {
                        grade: currentGrade,
                        username,
                        showUnitComplete: showComplete,
                        finishedQuestions: _finishedQuestions_0,
                        recentGrades: sortedCompletedGrades
                    }
                });
            }
            function handleGradeError(label_0, error_0) {
                const errorMessage = error_0?.error?.errors?.[0]?.message || error_0?.message || "";
                if (errorMessage.includes("DuplicatedOperationError")) {
                    console.warn(`[UnitContext] ${label_0}: transient DuplicatedOperationError (safe to ignore)`);
                    return;
                }
                if (errorMessage.includes("exceeds maximum value limit") || errorMessage.includes("operator `in`")) {
                    console.warn("[UnitContext] Subscription filter limit exceeded, using client-side filtering only");
                    return;
                }
                console.error(`[UnitContext] ${label_0} error:`, error_0);
            }
            // Single observeQuery replaces list() + 3 manual subscriptions
            // observeQuery handles create/update/delete internally with built-in dedup
            const subscription = client_3.models.Grade.observeQuery({
                filter: {
                    unitID: {
                        eq: id
                    }
                }
            }).subscribe({
                next: {
                    "UnitProvider.useEffect.subscription": ({ items })=>{
                        if (cancelled_0) return;
                        const validItems_0 = (items || []).filter({
                            "UnitProvider.useEffect.subscription.validItems_0": (item)=>item != null && item.id != null
                        }["UnitProvider.useEffect.subscription.validItems_0"]);
                        // Version map guard: skip dispatch if no item has a newer _version
                        const hasChanges = validItems_0.some({
                            "UnitProvider.useEffect.subscription.hasChanges": (item_0)=>{
                                const tracked = gradeVersionMapRef.current[item_0.id];
                                return tracked == null || item_0._version > tracked;
                            }
                        }["UnitProvider.useEffect.subscription.hasChanges"]);
                        if (!hasChanges && Object.keys(gradeVersionMapRef.current).length > 0) {
                            return;
                        }
                        // Update version map
                        gradeVersionMapRef.current = {};
                        validItems_0.forEach({
                            "UnitProvider.useEffect.subscription": (item_1)=>{
                                gradeVersionMapRef.current[item_1.id] = item_1._version;
                            }
                        }["UnitProvider.useEffect.subscription"]);
                        processGrades(validItems_0);
                    }
                }["UnitProvider.useEffect.subscription"],
                error: {
                    "UnitProvider.useEffect.subscription": (error_1)=>handleGradeError("Grade observeQuery", error_1)
                }["UnitProvider.useEffect.subscription"]
            });
            return ({
                "UnitProvider.useEffect": ()=>{
                    cancelled_0 = true;
                    subscription.unsubscribe();
                }
            })["UnitProvider.useEffect"];
        }
    }["UnitProvider.useEffect"], [
        id,
        user,
        authLoading
    ]);
    // ============================================================================
    // Practice Sessions subscription + CRUD
    // ============================================================================
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "UnitProvider.useEffect": ()=>{
            if (authLoading || !user || !id) return;
            const client_4 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            let cancelled_1 = false;
            function handleError(label_1, error_2) {
                const msg = error_2?.message || error_2?.error?.errors?.[0]?.message || String(error_2);
                if (msg.includes("DuplicatedOperationError")) {
                    console.warn(`[UnitContext] ${label_1}: transient DuplicatedOperationError (safe to ignore)`);
                    return;
                }
                if (msg.includes("exceeds maximum value limit")) {
                    console.warn("[UnitContext] PracticeSession subscription filter limit — using client filtering");
                    return;
                }
                console.error(`[UnitContext] ${label_1} error:`, msg);
            }
            // Single observeQuery replaces list() + 3 manual subscriptions
            // Exclude heavy fields: generatedContent, data (loaded on-demand)
            const subscription_0 = client_4.models.PracticeSession.observeQuery({
                filter: {
                    unitID: {
                        eq: id
                    }
                },
                selectionSet: [
                    "id",
                    "unitID",
                    "drillType",
                    "accuracy",
                    "blockCount",
                    "blocksCompleted",
                    "complete",
                    "xpAwarded",
                    "sourcesEnabled.*",
                    "coverageSnapshot.*",
                    "collaborative",
                    "roomCode",
                    "maxParticipants",
                    "insightStudentId",
                    "weakAreas.*",
                    "strongAreas.*",
                    "sourcesUsedList.*",
                    "blockBreakdown.*",
                    "insightTimestamp",
                    "_version",
                    "_lastChangedAt",
                    "_deleted",
                    "createdAt",
                    "updatedAt"
                ]
            }).subscribe({
                next: {
                    "UnitProvider.useEffect.subscription_0": ({ items: items_0 })=>{
                        if (cancelled_1) return;
                        const validItems_1 = (items_0 || []).filter({
                            "UnitProvider.useEffect.subscription_0.validItems_1": (s)=>s != null && s.id != null
                        }["UnitProvider.useEffect.subscription_0.validItems_1"]);
                        // Version map guard: skip if no item has a newer _version
                        const hasChanges_0 = validItems_1.some({
                            "UnitProvider.useEffect.subscription_0.hasChanges_0": (item_2)=>{
                                const tracked_0 = practiceSessionVersionMapRef.current[item_2.id];
                                return tracked_0 == null || item_2._version > tracked_0;
                            }
                        }["UnitProvider.useEffect.subscription_0.hasChanges_0"]);
                        if (!hasChanges_0 && Object.keys(practiceSessionVersionMapRef.current).length > 0) {
                            return;
                        }
                        // Update version map
                        practiceSessionVersionMapRef.current = {};
                        validItems_1.forEach({
                            "UnitProvider.useEffect.subscription_0": (item_3)=>{
                                practiceSessionVersionMapRef.current[item_3.id] = item_3._version;
                            }
                        }["UnitProvider.useEffect.subscription_0"]);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_PRACTICE_SESSIONS,
                            payload: validItems_1
                        });
                    }
                }["UnitProvider.useEffect.subscription_0"],
                error: {
                    "UnitProvider.useEffect.subscription_0": (error_3)=>handleError("PracticeSession observeQuery", error_3)
                }["UnitProvider.useEffect.subscription_0"]
            });
            return ({
                "UnitProvider.useEffect": ()=>{
                    cancelled_1 = true;
                    subscription_0.unsubscribe();
                }
            })["UnitProvider.useEffect"];
        }
    }["UnitProvider.useEffect"], [
        id,
        user,
        authLoading
    ]);
    const createPracticeSession = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[createPracticeSession]": async (data_1)=>{
            const client_5 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const { data: record, errors: errors_0 } = await client_5.models.PracticeSession.create({
                unitID: id,
                ...data_1
            });
            if (errors_0?.length) console.error("[UnitContext] createPracticeSession errors:", errors_0);
            return record;
        }
    }["UnitProvider.useCallback[createPracticeSession]"], [
        id
    ]);
    const updatePracticeSession = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[updatePracticeSession]": async (sessionId, updates)=>{
            const client_6 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const { data: record_0, errors: errors_1 } = await client_6.models.PracticeSession.update({
                id: sessionId,
                ...updates
            });
            if (errors_1?.length) console.error("[UnitContext] updatePracticeSession errors:", errors_1);
            return record_0;
        }
    }["UnitProvider.useCallback[updatePracticeSession]"], []);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "UnitProvider.useEffect": ()=>{
            console.log("[UnitContext] useEffect triggered", {
                id,
                authLoading,
                hasUser: !!user,
                userSub: user?.attributes?.sub
            });
            // Wait for auth to be ready before fetching unit data
            if (authLoading || !user) {
                console.log("[UnitContext] Waiting for auth...", {
                    authLoading,
                    hasUser: !!user
                });
                return;
            }
            if (!id) {
                console.log("[UnitContext] No unit id provided");
                return;
            }
            // ── Offline fallback: load from IndexedDB if offline ──────────────
            if (typeof navigator !== "undefined" && !navigator.onLine) {
                console.log("[UnitContext] Offline — loading unit from IndexedDB cache");
                ({
                    "UnitProvider.useEffect": async ()=>{
                        try {
                            const { getCachedUnit, getCachedWordsForUnit, getCachedQuestionsForUnit, getCachedFilesForUnit, getCachedGrade } = await __turbopack_context__.A("[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript, async loader)");
                            const cachedUnit = await getCachedUnit(id);
                            if (cachedUnit) {
                                const unitData = typeof cachedUnit.data === "string" ? JSON.parse(cachedUnit.data) : cachedUnit.data;
                                const blocks_0 = unitData?.root?.children || [];
                                const _rubric = blocks_0.filter({
                                    "UnitProvider.useEffect._rubric": (b_0)=>gradedBlockTypes.includes(b_0.type)
                                }["UnitProvider.useEffect._rubric"]).map({
                                    "UnitProvider.useEffect._rubric": (b_1)=>b_1.key
                                }["UnitProvider.useEffect._rubric"]);
                                const cachedWords = await getCachedWordsForUnit(id);
                                const cachedQuestions = await getCachedQuestionsForUnit(id);
                                const cachedFiles = await getCachedFilesForUnit(id);
                                const _dictionary = {};
                                cachedWords.forEach({
                                    "UnitProvider.useEffect": (w)=>{
                                        _dictionary[w.id] = w;
                                    }
                                }["UnitProvider.useEffect"]);
                                const _questionBank = {};
                                cachedQuestions.forEach({
                                    "UnitProvider.useEffect": (q)=>{
                                        _questionBank[q.id] = q;
                                    }
                                }["UnitProvider.useEffect"]);
                                const _files = {};
                                cachedFiles.forEach({
                                    "UnitProvider.useEffect": (f)=>{
                                        _files[f.id] = f;
                                    }
                                }["UnitProvider.useEffect"]);
                                unitRef.current = {
                                    ...cachedUnit,
                                    data: unitData,
                                    _version: cachedUnit.version
                                };
                                dispatch({
                                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].UNIT_LOADED,
                                    payload: {
                                        unit: unitRef.current,
                                        dictionary: _dictionary,
                                        questionBank: _questionBank,
                                        files: _files,
                                        rubric: _rubric
                                    }
                                });
                                editorStateRef.current = unitData;
                                versionRef.current = cachedUnit.version;
                                console.log("[UnitContext] Loaded unit from offline cache");
                            }
                        } catch (err_5) {
                            console.warn("[UnitContext] Offline cache load failed:", err_5);
                        }
                    }
                })["UnitProvider.useEffect"]();
                // When we come back online, re-subscribe
                const handleOnline = {
                    "UnitProvider.useEffect.handleOnline": ()=>{
                        console.log("[UnitContext] Back online — will re-run subscription effect");
                    }
                }["UnitProvider.useEffect.handleOnline"];
                window.addEventListener("online", handleOnline, {
                    once: true
                });
                return ({
                    "UnitProvider.useEffect": ()=>window.removeEventListener("online", handleOnline)
                })["UnitProvider.useEffect"];
            }
            // ── End offline fallback ──────────────────────────────────────────
            console.log("[UnitContext] Fetching unit data for id:", id);
            const client_7 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const subscriptions = [];
            let cancelled_2 = false;
            // Helper to load a unit record and all its relations
            async function loadUnit(unitRecord) {
                if (!unitRecord) {
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_UNIT,
                        payload: {}
                    });
                    dispatch({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_PERMISSION_ERROR,
                        payload: null
                    });
                    return;
                }
                // Permission checking is handled by individual pages (editor vs workbook)
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_PERMISSION_ERROR,
                    payload: null
                });
                // Only process if incoming version is greater than what we're tracking
                if (unitRecord?._version != null && !(unitRecord._version > versionRef.current)) {
                    return;
                }
                // Detect contentVersion change — fetch content from S3
                const prevContentVersion = unitRef.current?.contentVersion || 0;
                if (unitRecord.identityId && (unitRecord.contentVersion || 0) > prevContentVersion) {
                    const isInstructor = authSession?.groups?.includes("Instructors") || authSession?.groups?.includes("Admins");
                    const variant = isInstructor ? "draft" : "published";
                    const s3Content = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$unitContentStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadContent"])(unitRecord.identityId, unitRecord.id, variant);
                    if (s3Content) {
                        unitRecord = {
                            ...unitRecord,
                            data: s3Content
                        };
                    }
                }
                const _files_0 = {};
                const _dictionary_0 = {};
                const _questionBank_0 = {};
                const _playlistUrls = {};
                // Load related words via join table
                const { data: _unitWords } = await client_7.models.UnitWord.list({
                    filter: {
                        unitID: {
                            eq: id
                        }
                    }
                });
                // Load related files via join table
                const { data: _unitFiles } = await client_7.models.UnitFile.list({
                    filter: {
                        unitID: {
                            eq: id
                        }
                    }
                });
                // Load related questions via join table
                const { data: _unitQuestions } = await client_7.models.QuestionUnit.list({
                    filter: {
                        unitID: {
                            eq: id
                        }
                    }
                });
                // Fetch full Word objects
                const _unitWordsWork = (_unitWords || []).filter({
                    "UnitProvider.useEffect.loadUnit._unitWordsWork": (uw)=>uw != null && uw.deletedAt == null
                }["UnitProvider.useEffect.loadUnit._unitWordsWork"]).map({
                    "UnitProvider.useEffect.loadUnit._unitWordsWork": async (uw_0)=>{
                        if (uw_0.wordID) {
                            const { data: data_2 } = await client_7.models.Word.get({
                                id: uw_0.wordID
                            });
                            return data_2;
                        }
                        return null;
                    }
                }["UnitProvider.useEffect.loadUnit._unitWordsWork"]);
                // Fetch full File objects
                const _unitFilesWork = (_unitFiles || []).filter({
                    "UnitProvider.useEffect.loadUnit._unitFilesWork": (uf)=>uf != null && uf.deletedAt == null
                }["UnitProvider.useEffect.loadUnit._unitFilesWork"]).map({
                    "UnitProvider.useEffect.loadUnit._unitFilesWork": async (uf_0)=>{
                        if (uf_0.fileID) {
                            const { data: data_3 } = await client_7.models.File.get({
                                id: uf_0.fileID
                            });
                            return data_3;
                        }
                        return null;
                    }
                }["UnitProvider.useEffect.loadUnit._unitFilesWork"]);
                // Fetch full Question objects
                const _unitQuestionsWork = (_unitQuestions || []).filter({
                    "UnitProvider.useEffect.loadUnit._unitQuestionsWork": (uq)=>uq != null && uq.deletedAt == null
                }["UnitProvider.useEffect.loadUnit._unitQuestionsWork"]).map({
                    "UnitProvider.useEffect.loadUnit._unitQuestionsWork": async (uq_0)=>{
                        if (uq_0.questionID) {
                            const { data: data_4 } = await client_7.models.Question.get({
                                id: uq_0.questionID
                            });
                            return data_4;
                        }
                        return null;
                    }
                }["UnitProvider.useEffect.loadUnit._unitQuestionsWork"]);
                const _words = await Promise.allSettled(_unitWordsWork);
                const _unitsFiles = await Promise.allSettled(_unitFilesWork);
                const _questions = await Promise.allSettled(_unitQuestionsWork);
                _words.forEach({
                    "UnitProvider.useEffect.loadUnit": (w_0)=>{
                        if (w_0.status === "fulfilled" && w_0.value) {
                            const _w = w_0.value;
                            _dictionary_0[_w.id] = _w;
                        }
                    }
                }["UnitProvider.useEffect.loadUnit"]);
                _unitsFiles.forEach({
                    "UnitProvider.useEffect.loadUnit": (f_0)=>{
                        if (f_0.status === "fulfilled" && f_0.value) {
                            const _f = f_0.value;
                            _files_0[_f.id] = _f;
                        }
                    }
                }["UnitProvider.useEffect.loadUnit"]);
                _questions.forEach({
                    "UnitProvider.useEffect.loadUnit": (q_0)=>{
                        if (q_0.status === "fulfilled" && q_0.value) {
                            const _q = q_0.value;
                            _questionBank_0[_q.id] = _q;
                        }
                    }
                }["UnitProvider.useEffect.loadUnit"]);
                // Parse unit data (Gen2 stores JSON as string)
                const unitData_0 = typeof unitRecord?.data === "string" ? JSON.parse(unitRecord.data) : unitRecord?.data;
                const blocks_1 = unitData_0?.root?.children || [];
                const _rubric_0 = [];
                if (blocks_1.length > 0) {
                    blocks_1.forEach({
                        "UnitProvider.useEffect.loadUnit": (block_0)=>{
                            if (gradedBlockTypes.includes(block_0["type"])) {
                                _rubric_0.push(block_0["key"]);
                            }
                        }
                    }["UnitProvider.useEffect.loadUnit"]);
                }
                if (cancelled_2) return;
                // Update all state - _version check ensures data has changed
                unitRef.current = unitRecord;
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].UNIT_LOADED,
                    payload: {
                        unit: unitRecord,
                        dictionary: _dictionary_0,
                        files: _files_0,
                        playlistUrls: _playlistUrls,
                        questionBank: _questionBank_0,
                        rubric: _rubric_0
                    }
                });
                editorStateRef.current = unitData_0;
                versionRef.current = unitRecord?._version;
            }
            function handleSubscriptionError(label_2, error_4) {
                const msg_0 = error_4?.message || error_4?.error?.errors?.[0]?.message || JSON.stringify(error_4);
                if (msg_0.includes("DuplicatedOperationError")) {
                    console.warn(`[UnitContext] ${label_2}: transient DuplicatedOperationError (safe to ignore)`);
                    return;
                }
                console.error(`[UnitContext] ${label_2} error:`, error_4);
            }
            // Initial fetch: single get() instead of observeQuery() table scan
            async function fetchUnit() {
                try {
                    const { data: unitRecord_0, errors: errors_2 } = await client_7.models.Unit.get({
                        id
                    });
                    if (cancelled_2) return;
                    if (errors_2?.length) {
                        console.error("[UnitContext] Unit.get errors:", errors_2);
                    }
                    await loadUnit(unitRecord_0);
                } catch (error_5) {
                    console.error("[UnitContext] Unit.get error:", error_5);
                }
                if (cancelled_2) return;
                // Subscribe to updates for this specific unit
                const updateSub = client_7.models.Unit.onUpdate({
                    filter: {
                        id: {
                            eq: id
                        }
                    }
                }).subscribe({
                    next: {
                        "UnitProvider.useEffect.fetchUnit.updateSub": async (response)=>{
                            const updatedUnit = response;
                            if (!updatedUnit || !updatedUnit.id) return;
                            // Skip if unit was soft-deleted
                            if (updatedUnit.deletedAt != null) return;
                            console.log("[UnitContext] Unit updated via subscription, _version:", updatedUnit._version);
                            await loadUnit(updatedUnit);
                        }
                    }["UnitProvider.useEffect.fetchUnit.updateSub"],
                    error: {
                        "UnitProvider.useEffect.fetchUnit.updateSub": (error_6)=>handleSubscriptionError("Unit onUpdate", error_6)
                    }["UnitProvider.useEffect.fetchUnit.updateSub"]
                });
                subscriptions.push(updateSub);
            }
            fetchUnit();
            return ({
                "UnitProvider.useEffect": ()=>{
                    cancelled_2 = true;
                    subscriptions.forEach({
                        "UnitProvider.useEffect": (sub)=>sub?.unsubscribe()
                    }["UnitProvider.useEffect"]);
                }
            })["UnitProvider.useEffect"];
        }
    }["UnitProvider.useEffect"], [
        id,
        user,
        authLoading
    ]);
    // Helpers to track concurrent saves and show spinner only while at least one is in-flight
    const beginSaving = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[beginSaving]": ()=>{
            savingCountRef.current += 1;
            dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_IS_SAVING,
                payload: true
            });
        }
    }["UnitProvider.useCallback[beginSaving]"], []);
    const endSaving = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[endSaving]": ()=>{
            savingCountRef.current = Math.max(0, savingCountRef.current - 1);
            if (savingCountRef.current === 0) dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_IS_SAVING,
                payload: false
            });
        }
    }["UnitProvider.useCallback[endSaving]"], []);
    const saveEditorContent = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[saveEditorContent]": async (editorContent)=>{
            const currentUnit_0 = unitRef.current;
            // Guard: Don't save if unit is not loaded or is invalid
            if (!currentUnit_0 || !currentUnit_0.id) {
                console.warn("[saveEditorContent] Cannot save - unit not loaded yet");
                return;
            }
            let _editorContent = editorContent ? editorContent : editorStateRef.current;
            // Guard: Don't save null/undefined content — prevents storing "null" string in DB
            if (_editorContent == null) {
                console.warn("[saveEditorContent] Cannot save - no editor content available");
                return;
            }
            const newContent = typeof _editorContent === "string" ? _editorContent : JSON.stringify(_editorContent);
            beginSaving();
            // Optimistic version bump — blocks subscription echo from re-rendering
            const predictedNextVersion = currentUnit_0._version + 1;
            versionRef.current = predictedNextVersion;
            try {
                // 1. Upload content to S3 (private — owner only)
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$unitContentStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveDraftContent"])(currentUnit_0.identityId, currentUnit_0.id, newContent);
                // 2. Bump contentVersion in DynamoDB (no content payload)
                const nextContentVersion = (currentUnit_0.contentVersion || 0) + 1;
                const client_8 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const { data: savedUnit, errors: errors_4 } = await client_8.models.Unit.update({
                    id: currentUnit_0.id,
                    contentVersion: nextContentVersion,
                    _version: currentUnit_0._version
                });
                if (errors_4?.length) {
                    console.error("[saveEditorContent] Save returned errors:", errors_4);
                    // Rollback optimistic version on error
                    versionRef.current = currentUnit_0._version;
                } else if (savedUnit) {
                    // Confirm with actual version from server
                    unitRef.current = {
                        ...unitRef.current,
                        _version: savedUnit._version,
                        contentVersion: nextContentVersion
                    };
                    versionRef.current = savedUnit._version;
                }
                // Moderate async — backend fetches _version and writes to Unit.moderation
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$moderateContent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["moderateContent"])(newContent, {
                    modelName: "Unit",
                    recordId: currentUnit_0.id,
                    sectionId,
                    ownerId: user?.attributes?.sub
                }).then({
                    "UnitProvider.useCallback[saveEditorContent]": (result_1)=>{
                        if (result_1.flagged) {
                            console.warn("[UnitContext] Content flagged by moderation, saved for instructor review", {
                                categories: result_1.categories
                            });
                        }
                    }
                }["UnitProvider.useCallback[saveEditorContent]"]);
            } catch (errors_3) {
                console.error("[saveEditorContent] Save failed:", errors_3);
                // Rollback optimistic version on exception
                versionRef.current = currentUnit_0._version;
            } finally{
                endSaving();
            }
        }
    }["UnitProvider.useCallback[saveEditorContent]"], [
        id,
        beginSaving,
        endSaving
    ]);
    const handleDelete = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[handleDelete]": async ()=>{
            /**
     * This deletes the unit from the database.
     * It is called from the Editor component.
     * It is passed to the Editor component through the unit context.
     */ const currentUnit_1 = unitRef.current;
            try {
                const client_9 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                await client_9.models.Unit.delete({
                    id: currentUnit_1.id
                });
                router.push(`/units`);
            } catch (errors_5) {
                console.error(errors_5);
            }
        }
    }["UnitProvider.useCallback[handleDelete]"], [
        router
    ]);
    const saveDescription = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[saveDescription]": async (description_0)=>{
            const currentUnit_2 = unitRef.current;
            beginSaving();
            // Optimistic version bump
            const predictedNextVersion_0 = currentUnit_2._version + 1;
            versionRef.current = predictedNextVersion_0;
            try {
                const client_10 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const { data: savedUnit_0, errors: errors_7 } = await client_10.models.Unit.update({
                    id: currentUnit_2.id,
                    description: description_0,
                    _version: currentUnit_2._version
                });
                if (errors_7?.length) {
                    console.error("[saveDescription] Update returned errors:", errors_7);
                    versionRef.current = currentUnit_2._version;
                } else if (savedUnit_0) {
                    unitRef.current = {
                        ...unitRef.current,
                        _version: savedUnit_0._version
                    };
                    versionRef.current = savedUnit_0._version;
                }
            } catch (errors_6) {
                console.error(errors_6);
                versionRef.current = currentUnit_2._version;
            } finally{
                endSaving();
            }
        }
    }["UnitProvider.useCallback[saveDescription]"], [
        beginSaving,
        endSaving
    ]);
    const saveName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[saveName]": async (name_0)=>{
            const currentUnit_3 = unitRef.current;
            beginSaving();
            // Optimistic version bump
            const predictedNextVersion_1 = currentUnit_3._version + 1;
            versionRef.current = predictedNextVersion_1;
            try {
                const client_11 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const { data: savedUnit_1, errors: errors_9 } = await client_11.models.Unit.update({
                    id: currentUnit_3.id,
                    name: name_0,
                    _version: currentUnit_3._version
                });
                if (errors_9?.length) {
                    console.error("[saveName] Update returned errors:", errors_9);
                    versionRef.current = currentUnit_3._version;
                } else if (savedUnit_1) {
                    unitRef.current = {
                        ...unitRef.current,
                        _version: savedUnit_1._version
                    };
                    versionRef.current = savedUnit_1._version;
                }
            } catch (errors_8) {
                console.error(errors_8);
                versionRef.current = currentUnit_3._version;
            } finally{
                endSaving();
            }
        }
    }["UnitProvider.useCallback[saveName]"], [
        beginSaving,
        endSaving
    ]);
    const handleBeforeUnload = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[handleBeforeUnload]": async (event)=>{
            // If content is different then save it
            const currentUnit_4 = unitRef.current;
            const content = JSON.stringify(editorStateRef.current);
            const unitData_1 = JSON.stringify(currentUnit_4?.data);
            console.log("unitData", unitData_1);
            if (content === unitData_1) {
                event.returnValue = null;
                console.log("content === unitData", content);
                console.log("!!!+=======", unitData_1);
            } else {
                console.log("content !== unitContent", content);
                console.log("!!!+=======", unitData_1);
                event.preventDefault();
                await saveEditorContent();
            }
        }
    }["UnitProvider.useCallback[handleBeforeUnload]"], [
        saveEditorContent
    ]);
    const handleStatusChange = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[handleStatusChange]": async (status)=>{
            const currentUnit_5 = unitRef.current;
            const currentName = currentUnit_5?.name;
            const currentDescription = currentUnit_5?.description;
            if (status === "PUBLISHED") {
                // check if the unit has a name and description
                if (!currentName || !currentDescription) {
                    alert("Please add a name and description to your unit before publishing.");
                    return;
                }
            }
            // Capture editor thumbnail before any state changes (must happen while editor is mounted)
            let thumbnailBlob = null;
            if (status === "PUBLISHED") {
                try {
                    const { captureEditorThumbnail } = await __turbopack_context__.A("[project]/src/utils/generateThumbnail.ts [app-client] (ecmascript, async loader)");
                    thumbnailBlob = await captureEditorThumbnail();
                } catch (err_6) {
                    console.warn("[handleStatusChange] Thumbnail capture failed:", err_6);
                }
            }
            beginSaving();
            // Optimistic version bump
            const predictedNextVersion_2 = currentUnit_5._version + 1;
            versionRef.current = predictedNextVersion_2;
            try {
                const client_12 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const { data: savedUnit_2, errors: errors_10 } = await client_12.models.Unit.update({
                    id: currentUnit_5.id,
                    status: status,
                    _version: currentUnit_5._version
                });
                if (errors_10?.length) {
                    console.error("[handleStatusChange] Update returned errors:", errors_10);
                    versionRef.current = currentUnit_5._version;
                } else if (savedUnit_2) {
                    unitRef.current = {
                        ...unitRef.current,
                        _version: savedUnit_2._version
                    };
                    versionRef.current = savedUnit_2._version;
                    // On publish: delegate to publishUnit Lambda which handles
                    // media path rewriting, S3 writes, and DynamoDB update atomically.
                    if (status === "PUBLISHED") {
                        await client_12.mutations.publishUnit({
                            unitId: currentUnit_5.id
                        });
                        // Upload thumbnail image to S3 and store the key on the Unit
                        if (thumbnailBlob) {
                            try {
                                const { saveThumbnail } = await __turbopack_context__.A("[project]/src/utils/unitContentStorage.ts [app-client] (ecmascript, async loader)");
                                const thumbnailKey = await saveThumbnail(currentUnit_5.id, thumbnailBlob);
                                // Re-fetch current version after publishUnit mutation may have bumped it
                                const { data: freshUnit } = await client_12.models.Unit.get({
                                    id: currentUnit_5.id
                                });
                                if (freshUnit) {
                                    await client_12.models.Unit.update({
                                        id: currentUnit_5.id,
                                        thumbnail: thumbnailKey,
                                        _version: freshUnit._version
                                    });
                                    unitRef.current = {
                                        ...unitRef.current,
                                        thumbnail: thumbnailKey,
                                        _version: freshUnit._version + 1
                                    };
                                    versionRef.current = freshUnit._version + 1;
                                }
                            } catch (err_7) {
                                console.warn("[handleStatusChange] Thumbnail upload failed:", err_7);
                            }
                        }
                    }
                }
            } catch (error_7) {
                console.log("error", error_7);
                versionRef.current = currentUnit_5._version;
            } finally{
                endSaving();
            }
        }
    }["UnitProvider.useCallback[handleStatusChange]"], []);
    // Create session object for backward compatibility with components expecting session.username
    const session = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "UnitProvider.useMemo[session]": ()=>({
                username: user?.attributes?.sub,
                error: authSession?.error
            })
    }["UnitProvider.useMemo[session]"], [
        user?.attributes?.sub,
        authSession?.error
    ]);
    // Initialize collaborative workbook when feature is enabled and grade exists
    const workbookEnabled = true; // Always enabled - uses mocks in Storybook
    const workbookCollaborationConfig = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "UnitProvider.useMemo[workbookCollaborationConfig]": ()=>{
            if (!workbookEnabled || !state.grade?.id) return null;
            return {
                gradeId: state.grade.id,
                user: {
                    username: user?.attributes?.sub || "",
                    role: authSession?.groups?.includes("Instructors") || authSession?.groups?.includes("Moderators") || authSession?.groups?.includes("Admins") ? "instructor" : "student",
                    displayName: user?.attributes?.name || user?.attributes?.email?.split("@")[0] || user?.attributes?.sub || "Anonymous",
                    color: authSession?.groups?.includes("Instructors") || authSession?.groups?.includes("Moderators") || authSession?.groups?.includes("Admins") ? "#f59e0b" : "#3b82f6"
                },
                initialData: state.grade.data,
                wsUrl: ("TURBOPACK compile-time value", "wss://4uzs3gpvla.execute-api.us-east-1.amazonaws.com/live") || "ws://localhost:3001",
                onTutorJoin: ({
                    "UnitProvider.useMemo[workbookCollaborationConfig]": (tutor)=>{
                        console.log(`[UnitContext] Tutor ${tutor.displayName} joined to help!`);
                    }
                })["UnitProvider.useMemo[workbookCollaborationConfig]"],
                onSyncToGrade: ({
                    "UnitProvider.useMemo[workbookCollaborationConfig]": async (data_5, feedback_0)=>{
                        if (!state.grade) return;
                        try {
                            const parsed = typeof data_5 === "string" ? JSON.parse(data_5) : data_5;
                            const blocks_2 = Object.values(parsed);
                            // Calculate metrics from workbook data
                            const completeBlocks = blocks_2.filter({
                                "UnitProvider.useMemo[workbookCollaborationConfig].completeBlocks": (b_2)=>b_2.complete
                            }["UnitProvider.useMemo[workbookCollaborationConfig].completeBlocks"]);
                            const complete = blocks_2.length > 0 && blocks_2.every({
                                "UnitProvider.useMemo[workbookCollaborationConfig]": (b_3)=>b_3.complete
                            }["UnitProvider.useMemo[workbookCollaborationConfig]"]);
                            const percentComplete = blocks_2.length > 0 ? Math.round(completeBlocks.length / blocks_2.length * 100) : 0;
                            const accuracy_0 = blocks_2.length > 0 ? Math.round(blocks_2.reduce({
                                "UnitProvider.useMemo[workbookCollaborationConfig]": (sum, b_4)=>sum + (b_4.accuracy || 0)
                            }["UnitProvider.useMemo[workbookCollaborationConfig]"], 0) / blocks_2.length) : 0;
                            // Save to DataStore
                            const client_13 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                            await client_13.models.Grade.update({
                                id: state.grade.id,
                                data: typeof data_5 === "string" ? data_5 : JSON.stringify(data_5),
                                feedback: feedback_0 ? JSON.stringify(feedback_0) : state.grade.feedback,
                                complete,
                                percentComplete,
                                accuracy: accuracy_0
                            });
                            // Moderate async — backend persists to Grade.moderation
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$moderateContent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["moderateContent"])(data_5, {
                                modelName: "Grade",
                                recordId: state.grade.id,
                                sectionId,
                                ownerId: user?.attributes?.sub
                            }).then({
                                "UnitProvider.useMemo[workbookCollaborationConfig]": (result_2)=>{
                                    if (result_2.flagged) {
                                        console.warn("[UnitContext] Workbook data flagged by moderation, saving for instructor review", {
                                            categories: result_2.categories,
                                            username: user?.attributes?.sub
                                        });
                                    }
                                }
                            }["UnitProvider.useMemo[workbookCollaborationConfig]"]);
                            console.log("[UnitContext] Synced workbook to Grade.data", {
                                complete,
                                percentComplete,
                                accuracy: accuracy_0
                            });
                        } catch (error_8) {
                            console.error("[UnitContext] Error syncing workbook:", error_8);
                        }
                    }
                })["UnitProvider.useMemo[workbookCollaborationConfig]"]
            };
        }
    }["UnitProvider.useMemo[workbookCollaborationConfig]"], [
        workbookEnabled,
        state.grade?.id,
        state.grade?.data,
        user?.attributes,
        authSession?.groups
    ]);
    // Use the workbook collaboration hook
    const workbookCollaboration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWorkbookCollaboration"])(workbookCollaborationConfig);
    // Keep ref in sync so saveGrade can access the provider without being in its dependency array
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "UnitProvider.useEffect": ()=>{
            workbookCollaborationRef.current = workbookCollaboration;
        }
    }["UnitProvider.useEffect"], [
        workbookCollaboration
    ]);
    // Calculate workbook stats from live Yjs workbook data
    const workbookStats = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "UnitProvider.useMemo[workbookStats]": ()=>{
            if (!workbookCollaboration?.provider) {
                return {
                    completion: 0,
                    accuracy: 0,
                    totalBlocks: 0,
                    completeBlocks: 0
                };
            }
            const completion = workbookCollaboration.getCompletionPercentage?.() || 0;
            const accuracy_1 = workbookCollaboration.getOverallAccuracy?.() || 0;
            const data_6 = workbookCollaboration.getWorkbookData?.() || {};
            const blocks_3 = Object.values(data_6);
            return {
                completion,
                accuracy: accuracy_1,
                totalBlocks: blocks_3.length,
                completeBlocks: blocks_3.filter({
                    "UnitProvider.useMemo[workbookStats]": (b_5)=>b_5.complete
                }["UnitProvider.useMemo[workbookStats]"]).length
            };
        }
    }["UnitProvider.useMemo[workbookStats]"], [
        workbookCollaboration
    ]);
    // Stable dispatch-based setters for consumers
    const setShowUnitComplete = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[setShowUnitComplete]": (val)=>dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SHOW_UNIT_COMPLETE,
                payload: val
            })
    }["UnitProvider.useCallback[setShowUnitComplete]"], []);
    const setFinishedQuestions = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[setFinishedQuestions]": (val_0)=>dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_FINISHED_QUESTIONS,
                payload: val_0
            })
    }["UnitProvider.useCallback[setFinishedQuestions]"], []);
    const setPersonalBestResult = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "UnitProvider.useCallback[setPersonalBestResult]": (val_1)=>dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$unitReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_PERSONAL_BEST_RESULT,
                payload: val_1
            })
    }["UnitProvider.useCallback[setPersonalBestResult]"], []);
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "UnitProvider.useMemo[contextValue]": ()=>({
                unit: state.unit,
                name,
                rubric: state.rubric,
                grade: state.grade,
                recentGrades: state.recentGrades,
                dictionary: state.dictionary,
                files: state.files,
                questionBank: state.questionBank,
                playlistUrls: state.playlistUrls,
                description,
                editorStateRef,
                editorSelectionRef,
                editorRef,
                versionRef,
                unitRef,
                unitVersion,
                finishedQuestions: state.finishedQuestions,
                showUnitComplete: state.showUnitComplete,
                personalBestResult: state.personalBestResult,
                setPersonalBestResult,
                permissionError: state.permissionError,
                handleBeforeUnload,
                setShowUnitComplete,
                setFinishedQuestions,
                saveName,
                saveDescription,
                handleDelete,
                handleStatusChange,
                saveEditorContent,
                saveGrade,
                checkUnitEditPermission,
                checkUnitViewPermission,
                createGrade,
                session,
                // Workbook collaboration features
                workbook: workbookCollaboration,
                workbookStats,
                workbookEnabled,
                // Practice drill features
                practiceSessions: state.practiceSessions,
                createPracticeSession,
                updatePracticeSession,
                // Save state
                isSaving: state.isSaving,
                beginSaving,
                endSaving,
                // Section context for chat
                sectionId
            })
    }["UnitProvider.useMemo[contextValue]"], [
        state.unit,
        name,
        state.rubric,
        state.grade,
        state.recentGrades,
        state.dictionary,
        state.files,
        state.questionBank,
        state.playlistUrls,
        description,
        state.finishedQuestions,
        checkUnitEditPermission,
        checkUnitViewPermission,
        state.showUnitComplete,
        state.personalBestResult,
        setPersonalBestResult,
        state.permissionError,
        session,
        handleBeforeUnload,
        saveName,
        saveDescription,
        handleDelete,
        handleStatusChange,
        saveEditorContent,
        saveGrade,
        createGrade,
        workbookCollaboration,
        workbookStats,
        workbookEnabled,
        state.practiceSessions,
        createPracticeSession,
        updatePracticeSession,
        state.isSaving,
        beginSaving,
        endSaving,
        sectionId
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UnitContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/unitContext.jsx",
        lineNumber: 1474,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(UnitProvider, "KG9TTDBKFUvP7dg+8Kdx9jn4EF8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWorkbookCollaboration"]
    ];
});
_c = UnitProvider;
;
const __TURBOPACK__default__export__ = UnitContext;
var _c;
__turbopack_context__.k.register(_c, "UnitProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/vectorStoreContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/**
 * Vector Store Context
 * Provides access to the semantic search vector store across the application
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const VectorStoreContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext({
    vectorStore: null,
    search: async (query, options)=>({
            results: []
        }),
    isReady: false
});
const __TURBOPACK__default__export__ = VectorStoreContext;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/tabContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TabProvider",
    ()=>TabProvider,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useTabContext",
    ()=>useTabContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
/**
 * Context for managing tab state across the editor
 * Provides tab indices, open states, and setters for left/right sidebars
 * 
 * Note: Chat state has been moved to ChatContext (see src/context/chatContext.jsx)
 */ const TabContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    // Left sidebar state
    leftTab: 4,
    // files
    leftOpen: false,
    leftWidth: 350,
    setLeftTab: ()=>{},
    setLeftOpen: ()=>{},
    setLeftWidth: ()=>{},
    // Right sidebar state
    rightTab: 1,
    // chat
    rightOpen: false,
    rightWidth: 350,
    setRightTab: ()=>{},
    setRightOpen: ()=>{},
    setRightWidth: ()=>{},
    // Batch update
    updateState: ()=>{},
    // Focus management
    focusItem: null,
    // { type, id, timestamp }
    setFocusItem: ()=>{},
    // Item refs for scrolling - { type: { id: ref } }
    itemRefs: {
        current: {}
    },
    registerItemRef: ()=>{},
    unregisterItemRef: ()=>{},
    scrollToItem: ()=>{}
});
function useTabContext() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "e0e02d438abdbe68f527ded197369ee50158686d4ab1e2cc929009798dd1a778") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e0e02d438abdbe68f527ded197369ee50158686d4ab1e2cc929009798dd1a778";
    }
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(TabContext);
    if (!context) {
        console.warn("[useTabContext] Used outside of TabProvider, returning default values");
    }
    return context;
}
_s(useTabContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
function TabProvider(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "e0e02d438abdbe68f527ded197369ee50158686d4ab1e2cc929009798dd1a778") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e0e02d438abdbe68f527ded197369ee50158686d4ab1e2cc929009798dd1a778";
    }
    const { children, value } = t0;
    let t1;
    if ($[1] !== children || $[2] !== value) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabContext.Provider, {
            value: value,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/context/tabContext.jsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[1] = children;
        $[2] = value;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    return t1;
}
_c = TabProvider;
const __TURBOPACK__default__export__ = TabContext;
var _c;
__turbopack_context__.k.register(_c, "TabProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/reducers/fileReducer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "actionTypes",
    ()=>actionTypes,
    "fileReducer",
    ()=>fileReducer,
    "initialState",
    ()=>initialState
]);
const initialState = {
    audioFiles: {},
    myFiles: [],
    myPlaylistFiles: {},
    myPlaylistUrls: {},
    myPdfs: {},
    documents: {},
    filesVersion: 0,
    vectorStoreReady: false
};
const actionTypes = {
    SET_AUDIO_FILES: 'SET_AUDIO_FILES',
    SET_MY_FILES: 'SET_MY_FILES',
    SET_PLAYLIST_FILES: 'SET_PLAYLIST_FILES',
    SET_PLAYLIST_URLS: 'SET_PLAYLIST_URLS',
    SET_PDFS: 'SET_PDFS',
    SET_DOCUMENTS: 'SET_DOCUMENTS',
    SET_FILES_VERSION: 'SET_FILES_VERSION',
    SET_VECTOR_STORE_READY: 'SET_VECTOR_STORE_READY',
    FILES_SUBSCRIPTION_UPDATE: 'FILES_SUBSCRIPTION_UPDATE',
    INCREMENT_FILES_VERSION: 'INCREMENT_FILES_VERSION'
};
function fileReducer(state, action) {
    switch(action.type){
        case actionTypes.SET_AUDIO_FILES:
            return {
                ...state,
                audioFiles: action.payload
            };
        case actionTypes.SET_MY_FILES:
            {
                const incoming = action.payload;
                // Skip if same count and no version changes
                if (state.myFiles.length === incoming.length && incoming.length > 0) {
                    const anyNewer = incoming.some((f)=>{
                        const existing = state.myFiles.find((e)=>e.id === f.id);
                        return !existing || (f._version || 0) > (existing._version || 0);
                    });
                    if (!anyNewer) return state; // No changes, skip re-render
                }
                return {
                    ...state,
                    myFiles: incoming
                };
            }
        case actionTypes.SET_PLAYLIST_FILES:
            return {
                ...state,
                myPlaylistFiles: action.payload
            };
        case actionTypes.SET_PLAYLIST_URLS:
            return {
                ...state,
                myPlaylistUrls: action.payload
            };
        case actionTypes.SET_PDFS:
            return {
                ...state,
                myPdfs: action.payload
            };
        case actionTypes.SET_DOCUMENTS:
            {
                const incoming = action.payload;
                // Skip if same count and no version changes
                const incomingKeys = Object.keys(incoming);
                const existingKeys = Object.keys(state.documents);
                if (incomingKeys.length === existingKeys.length && incomingKeys.length > 0) {
                    const anyNewer = incomingKeys.some((id)=>{
                        const existing = state.documents[id];
                        return !existing || (incoming[id]._version || 0) > (existing._version || 0);
                    });
                    if (!anyNewer) return state; // No changes, skip re-render
                }
                return {
                    ...state,
                    documents: incoming
                };
            }
        case actionTypes.SET_FILES_VERSION:
            return {
                ...state,
                filesVersion: action.payload
            };
        case actionTypes.SET_VECTOR_STORE_READY:
            return {
                ...state,
                vectorStoreReady: action.payload
            };
        case actionTypes.FILES_SUBSCRIPTION_UPDATE:
            return {
                ...state,
                myFiles: action.payload.myFiles,
                myPlaylistFiles: action.payload.myPlaylistFiles,
                myPdfs: action.payload.myPdfs,
                filesVersion: state.filesVersion + 1
            };
        case actionTypes.INCREMENT_FILES_VERSION:
            return {
                ...state,
                filesVersion: state.filesVersion + 1
            };
        default:
            return state;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/reducers/dictionaryReducer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "actionTypes",
    ()=>actionTypes,
    "dictionaryReducer",
    ()=>dictionaryReducer,
    "initialState",
    ()=>initialState
]);
const initialState = {
    words: {},
    filteredWords: {},
    wordMapId: {},
    wordMapPhrase: {},
    filter: '',
    wordRefs: {},
    jaroWinklerThreshold: 0.85,
    syntacticSimilarityThreshold: 0.6,
    searching: false,
    questionBank: []
};
const actionTypes = {
    SET_WORDS: 'SET_WORDS',
    SET_FILTERED_WORDS: 'SET_FILTERED_WORDS',
    SET_WORD_MAP_ID: 'SET_WORD_MAP_ID',
    SET_WORD_MAP_PHRASE: 'SET_WORD_MAP_PHRASE',
    SET_FILTER: 'SET_FILTER',
    SET_WORD_REFS: 'SET_WORD_REFS',
    SET_JARO_WINKLER_THRESHOLD: 'SET_JARO_WINKLER_THRESHOLD',
    SET_SYNTACTIC_SIMILARITY_THRESHOLD: 'SET_SYNTACTIC_SIMILARITY_THRESHOLD',
    SET_SEARCHING: 'SET_SEARCHING',
    SET_QUESTION_BANK: 'SET_QUESTION_BANK',
    WORDS_SUBSCRIPTION_UPDATE: 'WORDS_SUBSCRIPTION_UPDATE',
    FILTER_COMPLETE: 'FILTER_COMPLETE'
};
function dictionaryReducer(state, action) {
    switch(action.type){
        case actionTypes.SET_WORDS:
            return {
                ...state,
                words: action.payload
            };
        case actionTypes.SET_FILTERED_WORDS:
            return {
                ...state,
                filteredWords: action.payload
            };
        case actionTypes.SET_WORD_MAP_ID:
            return {
                ...state,
                wordMapId: action.payload
            };
        case actionTypes.SET_WORD_MAP_PHRASE:
            return {
                ...state,
                wordMapPhrase: action.payload
            };
        case actionTypes.SET_FILTER:
            return {
                ...state,
                filter: action.payload
            };
        case actionTypes.SET_WORD_REFS:
            return {
                ...state,
                wordRefs: action.payload
            };
        case actionTypes.SET_JARO_WINKLER_THRESHOLD:
            return {
                ...state,
                jaroWinklerThreshold: action.payload
            };
        case actionTypes.SET_SYNTACTIC_SIMILARITY_THRESHOLD:
            return {
                ...state,
                syntacticSimilarityThreshold: action.payload
            };
        case actionTypes.SET_SEARCHING:
            return {
                ...state,
                searching: action.payload
            };
        case actionTypes.SET_QUESTION_BANK:
            {
                const incoming = action.payload;
                // Skip if same count and no version changes
                const incomingKeys = Object.keys(incoming);
                const existingKeys = Object.keys(state.questionBank);
                if (incomingKeys.length === existingKeys.length && incomingKeys.length > 0) {
                    const anyNewer = incomingKeys.some((id)=>{
                        const existing = state.questionBank[id];
                        return !existing || (incoming[id]._version || 0) > (existing._version || 0);
                    });
                    if (!anyNewer) return state; // No changes, skip re-render
                }
                return {
                    ...state,
                    questionBank: incoming
                };
            }
        case actionTypes.WORDS_SUBSCRIPTION_UPDATE:
            {
                const { words, wordMapId } = action.payload;
                // Skip if same count and no version changes
                const incomingIds = Object.keys(wordMapId);
                const existingIds = Object.keys(state.wordMapId);
                if (incomingIds.length === existingIds.length && incomingIds.length > 0) {
                    const anyNewer = incomingIds.some((id)=>{
                        const existing = state.wordMapId[id];
                        return !existing || (wordMapId[id]._version || 0) > (existing._version || 0);
                    });
                    if (!anyNewer) return state; // No changes, skip re-render
                }
                return {
                    ...state,
                    words,
                    filteredWords: words,
                    wordMapId,
                    searching: false
                };
            }
        case actionTypes.FILTER_COMPLETE:
            return {
                ...state,
                filteredWords: action.payload,
                searching: false
            };
        default:
            return state;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DictionaryProvider",
    ()=>DictionaryProvider,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview DictionaryContext is a React Context object that provides
 * access to the dictionary of words and phrases.
 *
 * It is used by the Dictionary component to display a list of words and phrases.
 *
 * It is used by the Editor2 component to provide a list of words and phrases
 * for the autocomplete feature.
 *
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/reducers/dictionaryReducer.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
// Provider and Consumer are connected through their "parent" context
const DictionaryContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    dictionary: {},
    filteredDictionary: {},
    wordMapId: {},
    wordMapPhrase: {},
    wordRefs: {},
    questionBank: {},
    filter: "",
    setFilter: ()=>{},
    filterWords: ()=>{},
    searching: false,
    setSearching: ()=>{}
});
// Provider will be exported wrapped in ConfigProvider component.
const DictionaryProvider = ({ children })=>{
    _s();
    // TODO add a filter to the dictionary
    // TODO add a sort to the dictionary?
    // TODO add keep a map of refs to the words in the dictionary for scrolling to the word in the editor?
    const { user, isLoading: authLoading } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dictionaryReducer"], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"]);
    const wordVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    const questionVersionMapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    // Show deleted toggle state
    const [showDeleted, setShowDeleted] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [deletedWords, setDeletedWords] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    const [deletedQuestions, setDeletedQuestions] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    // search words for a new filter value for the wordblock list
    // React.useEffect(() => {
    //     console.log("DictionaryProvider.useEffect.filter", filter)
    //     // for each word in the dictionary, check if it matches the filter
    //     // determine if the filter is a phrase or a pronunciation
    //     // if the filter is a phrase, then check if the word's phrase matches the filter
    // }, [filterPhraseAndPronunciation])
    const filterWords = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "DictionaryProvider.useCallback[filterWords]": async ()=>{
            // Reduce logging frequency for performance
            if (("TURBOPACK compile-time value", "development") === "development" && Math.random() < 0.05) {
                console.log("filterWords", {
                    wordsCount: Object.keys(state.words || {}).length,
                    filter: state.filter
                });
            }
            if (!state.words) {
                return;
            }
            if (!state.filter || state.filter === "" || state.filter === " ") {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].FILTER_COMPLETE,
                    payload: state.words
                });
                return;
            }
            const _processingQueue = Object.keys(state.words).map({
                "DictionaryProvider.useCallback[filterWords]._processingQueue": async (value, key)=>{
                    let found = false;
                    const word = state.words[value];
                    if (word.phrase.toLowerCase().includes(state.filter.toLowerCase()) || word.definition.toLowerCase().includes(state.filter.toLowerCase()) || word.pronunciation.includes(state.filter.toLowerCase())) {
                        found = true;
                    }
                    // calculate jarowinkler distance
                    const jaroWinklerPhrase = jaroWinklerDistance(state.filter.toLowerCase(), word.phrase.toLowerCase());
                    const jaroWinklerDefinition = jaroWinklerDistance(state.filter.toLowerCase(), word.definition.toLowerCase());
                    const jaroWinklerPronunciation = jaroWinklerDistance(state.filter.toLowerCase(), word.pronunciation.toLowerCase());
                    const jaroWinkler = Math.max(jaroWinklerPhrase, jaroWinklerDefinition, jaroWinklerPronunciation);
                    if (jaroWinkler > state.jaroWinklerThreshold) {
                        found = true;
                    }
                    if (found) {
                        return word;
                    }
                }
            }["DictionaryProvider.useCallback[filterWords]._processingQueue"]);
            const _filteredWords = (await Promise.allSettled(_processingQueue)).filter({
                "DictionaryProvider.useCallback[filterWords]._filteredWords": (r)=>r.status === "fulfilled"
            }["DictionaryProvider.useCallback[filterWords]._filteredWords"]).map({
                "DictionaryProvider.useCallback[filterWords]._filteredWords": (r_0)=>r_0.value
            }["DictionaryProvider.useCallback[filterWords]._filteredWords"]);
            if (Object.keys(_filteredWords).length === 0) {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].FILTER_COMPLETE,
                    payload: state.words
                });
            } else {
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].FILTER_COMPLETE,
                    payload: _filteredWords
                });
            }
        }
    }["DictionaryProvider.useCallback[filterWords]"], [
        state.words,
        state.filter,
        state.jaroWinklerThreshold
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "DictionaryProvider.useEffect": ()=>{
            // Debounce filterWords to prevent excessive calls
            const timeoutId = setTimeout({
                "DictionaryProvider.useEffect.timeoutId": ()=>{
                    filterWords();
                }
            }["DictionaryProvider.useEffect.timeoutId"], 100);
            return ({
                "DictionaryProvider.useEffect": ()=>clearTimeout(timeoutId)
            })["DictionaryProvider.useEffect"];
        }
    }["DictionaryProvider.useEffect"], [
        state.filter,
        filterWords
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "DictionaryProvider.useEffect": ()=>{
            // Wait for auth to be ready
            if (authLoading || !user) {
                return;
            }
            // ── Offline fallback: load words from IndexedDB cache ─────────
            if (typeof navigator !== "undefined" && !navigator.onLine) {
                ({
                    "DictionaryProvider.useEffect": async ()=>{
                        try {
                            const { getAllRecords } = await __turbopack_context__.A("[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript, async loader)");
                            const cachedWords = await getAllRecords("words");
                            if (cachedWords.length > 0) {
                                const wordMap = {};
                                const _wordMapId = {};
                                cachedWords.forEach({
                                    "DictionaryProvider.useEffect": (item)=>{
                                        wordMap[item.phrase] = item;
                                        _wordMapId[item.id] = item;
                                    }
                                }["DictionaryProvider.useEffect"]);
                                dispatch({
                                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].WORDS_SUBSCRIPTION_UPDATE,
                                    payload: {
                                        words: wordMap,
                                        wordMapId: _wordMapId
                                    }
                                });
                                console.log("[DictionaryContext] Loaded", cachedWords.length, "words from offline cache");
                            }
                        } catch (err) {
                            console.warn("[DictionaryContext] Offline word cache load failed:", err);
                        }
                    }
                })["DictionaryProvider.useEffect"]();
                return;
            }
            // ── End offline fallback ──────────────────────────────────────
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            let cancelled = false;
            function handleError(label, error) {
                const msg = error?.message || error?.errors?.[0]?.message || error?.error?.errors?.[0]?.message || JSON.stringify(error);
                if (msg.includes("DuplicatedOperationError")) {
                    console.warn(`[DictionaryContext] ${label}: transient DuplicatedOperationError (safe to ignore)`);
                    return;
                }
                console.error(`[DictionaryContext] ${label} error:`, error);
            }
            function buildWordMaps(items) {
                const words = {};
                const wordMapId = {};
                items.forEach({
                    "DictionaryProvider.useEffect.buildWordMaps": (item_0)=>{
                        words[item_0.phrase] = item_0;
                        wordMapId[item_0.id] = item_0;
                    }
                }["DictionaryProvider.useEffect.buildWordMaps"]);
                return {
                    words,
                    wordMapId
                };
            }
            // Single observeQuery replaces list() + 3 manual subscriptions
            // Exclude heavy fields: yjsSnapshot
            const subscription = client.models.Word.observeQuery({
                selectionSet: [
                    "id",
                    "owner",
                    "identityId",
                    "phrase",
                    "pronunciation",
                    "definition",
                    "rubyTags",
                    "audio.*",
                    "definitionAudio.*",
                    "importedAt",
                    "embedding.*",
                    "moderation.*",
                    "_version",
                    "_lastChangedAt",
                    "_deleted",
                    "createdAt",
                    "updatedAt"
                ]
            }).subscribe({
                next: {
                    "DictionaryProvider.useEffect.subscription": ({ items: items_0 })=>{
                        if (cancelled) return;
                        const allValid = (items_0 || []).filter({
                            "DictionaryProvider.useEffect.subscription.allValid": (item_1)=>item_1 != null && item_1.id != null
                        }["DictionaryProvider.useEffect.subscription.allValid"]);
                        const validItems = allValid.filter({
                            "DictionaryProvider.useEffect.subscription.validItems": (item_2)=>item_2.deletedAt == null
                        }["DictionaryProvider.useEffect.subscription.validItems"]);
                        const deleted = allValid.filter({
                            "DictionaryProvider.useEffect.subscription.deleted": (item_3)=>item_3.deletedAt != null
                        }["DictionaryProvider.useEffect.subscription.deleted"]);
                        setDeletedWords(deleted);
                        // Version map guard: skip if no item has a newer _version
                        const hasChanges = validItems.some({
                            "DictionaryProvider.useEffect.subscription.hasChanges": (item_4)=>{
                                const tracked = wordVersionMapRef.current[item_4.id];
                                return tracked == null || item_4._version > tracked;
                            }
                        }["DictionaryProvider.useEffect.subscription.hasChanges"]);
                        if (!hasChanges && Object.keys(wordVersionMapRef.current).length > 0) {
                            return; // All items same or older version — skip dispatch
                        }
                        // Update version map
                        wordVersionMapRef.current = {};
                        validItems.forEach({
                            "DictionaryProvider.useEffect.subscription": (item_5)=>{
                                wordVersionMapRef.current[item_5.id] = item_5._version;
                            }
                        }["DictionaryProvider.useEffect.subscription"]);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].WORDS_SUBSCRIPTION_UPDATE,
                            payload: buildWordMaps(validItems)
                        });
                    }
                }["DictionaryProvider.useEffect.subscription"],
                error: {
                    "DictionaryProvider.useEffect.subscription": (error_0)=>handleError("Word observeQuery", error_0)
                }["DictionaryProvider.useEffect.subscription"]
            });
            return function cleanup() {
                cancelled = true;
                subscription.unsubscribe();
            };
        }
    }["DictionaryProvider.useEffect"], [
        user,
        authLoading
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "DictionaryProvider.useEffect": ()=>{
            // Wait for auth to be ready
            if (authLoading || !user) {
                return;
            }
            // ── Offline fallback: load questions from IndexedDB cache ─────
            if (typeof navigator !== "undefined" && !navigator.onLine) {
                ({
                    "DictionaryProvider.useEffect": async ()=>{
                        try {
                            const { getAllRecords: getAllRecords_0 } = await __turbopack_context__.A("[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript, async loader)");
                            const cachedQuestions = await getAllRecords_0("questions");
                            if (cachedQuestions.length > 0) {
                                dispatch({
                                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_QUESTION_BANK,
                                    payload: cachedQuestions
                                });
                                console.log("[DictionaryContext] Loaded", cachedQuestions.length, "questions from offline cache");
                            }
                        } catch (err_0) {
                            console.warn("[DictionaryContext] Offline question cache load failed:", err_0);
                        }
                    }
                })["DictionaryProvider.useEffect"]();
                return;
            }
            // ── End offline fallback ──────────────────────────────────────
            // Single observeQuery replaces list() + 3 manual subscriptions
            const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            let cancelled_0 = false;
            function handleError_0(label_0, error_1) {
                const msg_0 = error_1?.message || error_1?.errors?.[0]?.message || error_1?.error?.errors?.[0]?.message || JSON.stringify(error_1);
                if (msg_0.includes("DuplicatedOperationError")) {
                    console.warn(`[DictionaryContext] ${label_0}: transient DuplicatedOperationError (safe to ignore)`);
                    return;
                }
                console.error(`[DictionaryContext] ${label_0} error:`, error_1);
            }
            // Exclude heavy fields: yjsSnapshot
            const subscription_0 = client_0.models.Question.observeQuery({
                selectionSet: [
                    "id",
                    "owner",
                    "identityId",
                    "prompt",
                    "answer",
                    "choices",
                    "audio",
                    "answerAudio",
                    "thumbnail",
                    "difficulty",
                    "embedding.*",
                    "moderation.*",
                    "deletedAt",
                    "_version",
                    "_lastChangedAt",
                    "_deleted",
                    "createdAt",
                    "updatedAt"
                ]
            }).subscribe({
                next: {
                    "DictionaryProvider.useEffect.subscription_0": ({ items: items_1 })=>{
                        if (cancelled_0) return;
                        const allValid_0 = (items_1 || []).filter({
                            "DictionaryProvider.useEffect.subscription_0.allValid_0": (item_6)=>item_6 != null && item_6.id != null
                        }["DictionaryProvider.useEffect.subscription_0.allValid_0"]);
                        const validItems_0 = allValid_0.filter({
                            "DictionaryProvider.useEffect.subscription_0.validItems_0": (item_7)=>item_7.deletedAt == null
                        }["DictionaryProvider.useEffect.subscription_0.validItems_0"]);
                        const deletedQ = allValid_0.filter({
                            "DictionaryProvider.useEffect.subscription_0.deletedQ": (item_8)=>item_8.deletedAt != null
                        }["DictionaryProvider.useEffect.subscription_0.deletedQ"]);
                        setDeletedQuestions(deletedQ);
                        // Version map guard: skip if no item has a newer _version
                        const hasChanges_0 = validItems_0.some({
                            "DictionaryProvider.useEffect.subscription_0.hasChanges_0": (item_9)=>{
                                const tracked_0 = questionVersionMapRef.current[item_9.id];
                                return tracked_0 == null || item_9._version > tracked_0;
                            }
                        }["DictionaryProvider.useEffect.subscription_0.hasChanges_0"]);
                        if (!hasChanges_0 && Object.keys(questionVersionMapRef.current).length > 0) {
                            return; // All items same or older version — skip dispatch
                        }
                        // Update version map
                        questionVersionMapRef.current = {};
                        validItems_0.forEach({
                            "DictionaryProvider.useEffect.subscription_0": (item_10)=>{
                                questionVersionMapRef.current[item_10.id] = item_10._version;
                            }
                        }["DictionaryProvider.useEffect.subscription_0"]);
                        const questionBank = {};
                        validItems_0.forEach({
                            "DictionaryProvider.useEffect.subscription_0": (item_11)=>{
                                questionBank[item_11.id] = item_11;
                            }
                        }["DictionaryProvider.useEffect.subscription_0"]);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_QUESTION_BANK,
                            payload: questionBank
                        });
                    }
                }["DictionaryProvider.useEffect.subscription_0"],
                error: {
                    "DictionaryProvider.useEffect.subscription_0": (error_2)=>handleError_0("Question observeQuery", error_2)
                }["DictionaryProvider.useEffect.subscription_0"]
            });
            return function cleanup() {
                cancelled_0 = true;
                subscription_0.unsubscribe();
            };
        }
    }["DictionaryProvider.useEffect"], [
        user,
        authLoading
    ]);
    // Stable dispatch-based setters for consumers
    const setFilter = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "DictionaryProvider.useCallback[setFilter]": (val)=>dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_FILTER,
                payload: val
            })
    }["DictionaryProvider.useCallback[setFilter]"], []);
    const setSearching = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "DictionaryProvider.useCallback[setSearching]": (val_0)=>dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$dictionaryReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_SEARCHING,
                payload: val_0
            })
    }["DictionaryProvider.useCallback[setSearching]"], []);
    // Optimistic version bump helpers — call before save to block subscription echo
    const bumpWordVersion = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "DictionaryProvider.useCallback[bumpWordVersion]": (id, currentVersion)=>{
            const previousVersion = wordVersionMapRef.current[id] || currentVersion;
            wordVersionMapRef.current[id] = currentVersion + 1;
            return {
                confirm: ({
                    "DictionaryProvider.useCallback[bumpWordVersion]": (actualVersion)=>{
                        wordVersionMapRef.current[id] = actualVersion;
                    }
                })["DictionaryProvider.useCallback[bumpWordVersion]"],
                rollback: ({
                    "DictionaryProvider.useCallback[bumpWordVersion]": ()=>{
                        wordVersionMapRef.current[id] = previousVersion;
                    }
                })["DictionaryProvider.useCallback[bumpWordVersion]"]
            };
        }
    }["DictionaryProvider.useCallback[bumpWordVersion]"], []);
    const bumpQuestionVersion = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "DictionaryProvider.useCallback[bumpQuestionVersion]": (id_0, currentVersion_0)=>{
            const previousVersion_0 = questionVersionMapRef.current[id_0] || currentVersion_0;
            questionVersionMapRef.current[id_0] = currentVersion_0 + 1;
            return {
                confirm: ({
                    "DictionaryProvider.useCallback[bumpQuestionVersion]": (actualVersion_0)=>{
                        questionVersionMapRef.current[id_0] = actualVersion_0;
                    }
                })["DictionaryProvider.useCallback[bumpQuestionVersion]"],
                rollback: ({
                    "DictionaryProvider.useCallback[bumpQuestionVersion]": ()=>{
                        questionVersionMapRef.current[id_0] = previousVersion_0;
                    }
                })["DictionaryProvider.useCallback[bumpQuestionVersion]"]
            };
        }
    }["DictionaryProvider.useCallback[bumpQuestionVersion]"], []);
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "DictionaryProvider.useMemo[contextValue]": ()=>({
                dictionary: state.words,
                filteredDictionary: state.filteredWords,
                wordMapId: state.wordMapId,
                wordMapPhrase: state.wordMapPhrase,
                wordRefs: state.wordRefs,
                questionBank: state.questionBank,
                filter: state.filter,
                setFilter,
                filterWords,
                searching: state.searching,
                setSearching,
                bumpWordVersion,
                bumpQuestionVersion,
                showDeleted,
                setShowDeleted,
                deletedWords,
                deletedQuestions
            })
    }["DictionaryProvider.useMemo[contextValue]"], [
        state.words,
        state.filteredWords,
        state.wordMapId,
        state.wordMapPhrase,
        state.wordRefs,
        state.questionBank,
        state.filter,
        setFilter,
        filterWords,
        state.searching,
        setSearching,
        bumpWordVersion,
        bumpQuestionVersion,
        showDeleted,
        deletedWords,
        deletedQuestions
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DictionaryContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/dictionaryContext.jsx",
        lineNumber: 360,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(DictionaryProvider, "7/SfqVTZ3z644HIy4lDnsCNczP8=");
_c = DictionaryProvider;
;
const __TURBOPACK__default__export__ = DictionaryContext;
var _c;
__turbopack_context__.k.register(_c, "DictionaryProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/fileContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ACCEPTABLE_PLAYLIST_TYPES",
    ()=>ACCEPTABLE_PLAYLIST_TYPES,
    "FilesProvider",
    ()=>FilesProvider,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/list.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/reducers/fileReducer.js [app-client] (ecmascript)");
// Import vector store for early initialization
// In Storybook: Vite aliases automatically resolve these to mocks in .storybook/__mocks__/
// In Next.js: Tree-shaking and conditional usage prevent SSR issues
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$FileManager2$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/FileManager2.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vectorStoreDB$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/vectorStoreDB.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
// Provider and Consumer are connected through their "parent" context
const FilesContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    audioFiles: {},
    refreshAudioFiles: ()=>{},
    files: [],
    myFiles: [],
    myPlaylistFiles: [],
    myPlaylistUrls: [],
    myPdfs: [],
    documents: [],
    session: {
        identityId: undefined,
        idToken: undefined,
        error: undefined
    },
    filesVersion: 0,
    vectorStore: null,
    // Will be null during SSR, initialized in browser
    vectorStoreReady: false
});
const ACCEPTABLE_PLAYLIST_TYPES = [
    "audio/mp3",
    "audio/mpeg",
    "audio/wav",
    "audio/ogg",
    "audio/m4a",
    "audio/aac",
    "audio/webm",
    "audio/flac"
];
// Provider will be exported wrapped in ConfigProvider component.
const FilesProvider = ({ children })=>{
    _s();
    // Get auth state from centralized context
    const authContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { user, session, isLoading: authLoading } = authContext || {
        user: undefined,
        session: undefined,
        isLoading: true
    };
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fileReducer"], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"]);
    const filesFetchedRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(false);
    const subscriptionRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const documentSubscriptionRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const fileVersionMapRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef({});
    const documentVersionMapRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef({});
    // Show deleted toggle state
    const [showDeleted, setShowDeleted] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [deletedFiles, setDeletedFiles] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    const [deletedDocuments, setDeletedDocuments] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    // Create vector store instance - shared across entire app (browser-only)
    const vectorStore = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(("TURBOPACK compile-time value", "object") !== "undefined" && __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$FileManager2$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CourseVectorStore"] ? new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$FileManager2$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CourseVectorStore"]() : null).current;
    const loadedVersions = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(new Map()); // Track loaded document versions
    // Early vector store initialization - load from IndexedDB on mount
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FilesProvider.useEffect": ()=>{
            if (!vectorStore) {
                // SSR or vector store not available
                dispatch({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_VECTOR_STORE_READY,
                    payload: false
                });
                return;
            }
            console.log("[FilesContext] Initializing vector store from IndexedDB");
            if (!vectorStore.loaded) {
                vectorStore.loadFromIndexedDB().then({
                    "FilesProvider.useEffect": (count)=>{
                        if (count > 0) {
                            console.log(`[FilesContext] Loaded ${count} cached embeddings from IndexedDB`);
                            dispatch({
                                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_VECTOR_STORE_READY,
                                payload: true
                            });
                        } else {
                            console.log("[FilesContext] No cached embeddings found in IndexedDB");
                            dispatch({
                                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_VECTOR_STORE_READY,
                                payload: true
                            });
                        }
                    }
                }["FilesProvider.useEffect"]).catch({
                    "FilesProvider.useEffect": (error)=>{
                        console.error("[FilesContext] Failed to load from IndexedDB:", error);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_VECTOR_STORE_READY,
                            payload: true
                        });
                    }
                }["FilesProvider.useEffect"]);
            }
        }
    }["FilesProvider.useEffect"], [
        vectorStore
    ]);
    // Populate vector store from files and documents
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FilesProvider.useEffect": ()=>{
            if (!vectorStore) return; // Guard for SSR
            if (state.myFiles.length === 0) return;
            const isInitialLoad = loadedVersions.current.size === 0;
            const processingDocuments = new Set();
            console.log(`[FilesContext] Vector store population triggered`, {
                isInitialLoad,
                filesCount: state.myFiles.length,
                currentVectorStoreSize: vectorStore.items.length,
                documentsCount: Object.keys(state.documents).length
            });
            state.myFiles.forEach({
                "FilesProvider.useEffect": async (file)=>{
                    const docStatus = state.documents[file.documentID];
                    const pageEmbeddings = docStatus?.pageEmbeddings;
                    const embeddingsS3Key = docStatus?.embeddingsS3Key;
                    const currentVersion = docStatus?._version || file._version;
                    const loadedVersion = loadedVersions.current.get(file.id);
                    // Skip if already loaded and version unchanged
                    if (!isInitialLoad && loadedVersion === currentVersion) {
                        return;
                    }
                    // Skip if already processing this document
                    if (file.documentID && processingDocuments.has(file.documentID)) {
                        return;
                    }
                    if (file.documentID) {
                        processingDocuments.add(file.documentID);
                    }
                    // Remove old entries for this file if updating
                    if (!isInitialLoad) {
                        vectorStore.items = vectorStore.items.filter({
                            "FilesProvider.useEffect": (item)=>item.metadata?.fileId !== file.id
                        }["FilesProvider.useEffect"]);
                    }
                    // Load from S3 if needed
                    if (!pageEmbeddings && embeddingsS3Key && file.documentID) {
                        const existingInMemory = vectorStore.items.filter({
                            "FilesProvider.useEffect.existingInMemory": (item_0)=>item_0.documentId === file.documentID || item_0.metadata?.documentId === file.documentID
                        }["FilesProvider.useEffect.existingInMemory"]);
                        if (existingInMemory.length > 0) {
                            console.log(`[FilesContext] Skipping S3 - ${existingInMemory.length} embeddings in memory for ${file.documentID}`);
                            loadedVersions.current.set(file.id, currentVersion);
                            return;
                        }
                        try {
                            const cachedInIndexedDB = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vectorStoreDB$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadEmbeddingsByDocument"])(file.documentID);
                            if (cachedInIndexedDB && cachedInIndexedDB.length > 0) {
                                console.log(`[FilesContext] Loading ${cachedInIndexedDB.length} embeddings from IndexedDB for ${file.name}`);
                                cachedInIndexedDB.forEach({
                                    "FilesProvider.useEffect": (emb)=>vectorStore.add(emb)
                                }["FilesProvider.useEffect"]);
                                loadedVersions.current.set(file.id, currentVersion);
                                return;
                            }
                        } catch (error_0) {
                            console.warn(`[FilesContext] IndexedDB check failed for ${file.documentID}:`, error_0);
                        }
                        try {
                            console.log(`[FilesContext] Downloading embeddings from S3 for ${file.name}`);
                            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vectorStoreDB$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadEmbeddingsFromS3"])(embeddingsS3Key, file.documentID, {
                                fileId: file.id,
                                fileName: file.name,
                                mimeType: file.mimeType
                            });
                            const cachedEmbeddings = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vectorStoreDB$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadEmbeddingsByDocument"])(file.documentID);
                            cachedEmbeddings.forEach({
                                "FilesProvider.useEffect": (emb_0)=>vectorStore.add(emb_0)
                            }["FilesProvider.useEffect"]);
                            console.log(`[FilesContext] Loaded ${cachedEmbeddings.length} embeddings from S3 for ${file.name}`);
                            loadedVersions.current.set(file.id, currentVersion);
                            return;
                        } catch (error_1) {
                            console.error(`[FilesContext] S3 load failed for ${file.documentID}:`, error_1);
                        }
                    }
                    // Add page embeddings from DynamoDB
                    if (pageEmbeddings && Array.isArray(pageEmbeddings) && file.documentID) {
                        console.log(`[FilesContext] Adding ${pageEmbeddings.length} page embeddings for ${file.name}`);
                        pageEmbeddings.forEach({
                            "FilesProvider.useEffect": (pageData)=>{
                                if (pageData.embedding) {
                                    vectorStore.add({
                                        id: `${file.id}-page-${pageData.page}`,
                                        documentId: file.documentID,
                                        page: pageData.page,
                                        text: pageData.text || "",
                                        vector: pageData.embedding,
                                        metadata: {
                                            fileId: file.id,
                                            documentId: file.documentID,
                                            page: pageData.page,
                                            fileName: file.name,
                                            mimeType: file.mimeType
                                        }
                                    });
                                }
                            }
                        }["FilesProvider.useEffect"]);
                        // Save to IndexedDB
                        if (!isInitialLoad || !vectorStore.loaded) {
                            vectorStore.saveToIndexedDB(file.documentID, pageEmbeddings, {
                                fileId: file.id,
                                fileName: file.name,
                                mimeType: file.mimeType
                            }).catch({
                                "FilesProvider.useEffect": (error_2)=>{
                                    console.error("[FilesContext] IndexedDB save failed:", error_2);
                                }
                            }["FilesProvider.useEffect"]);
                        }
                    }
                    // Add file-level embedding from S3 (metadata-only in DynamoDB now)
                    if (file.embedding?.version && !pageEmbeddings) {
                        try {
                            const { loadEmbedding } = await __turbopack_context__.A("[project]/src/utils/embeddingStorage.ts [app-client] (ecmascript, async loader)");
                            const embeddingFile = await loadEmbedding(file.identityId || file.owner, "file", file.id);
                            if (embeddingFile?.pages?.length > 0) {
                                embeddingFile.pages.forEach({
                                    "FilesProvider.useEffect": (pageData_0)=>{
                                        vectorStore.add({
                                            id: `${file.id}-page-${pageData_0.page}`,
                                            documentId: file.documentID || file.id,
                                            page: pageData_0.page,
                                            text: pageData_0.text || file.description || file.name,
                                            vector: pageData_0.embedding,
                                            metadata: {
                                                fileId: file.id,
                                                documentId: file.documentID,
                                                page: pageData_0.page,
                                                fileName: file.name,
                                                mimeType: file.mimeType
                                            }
                                        });
                                    }
                                }["FilesProvider.useEffect"]);
                            }
                        } catch (error_3) {
                            console.warn(`[FilesContext] Failed to load embedding from S3 for ${file.name}:`, error_3);
                        }
                    }
                    if (currentVersion) {
                        loadedVersions.current.set(file.id, currentVersion);
                    }
                }
            }["FilesProvider.useEffect"]);
            console.log(`[FilesContext] Vector store population complete - ${vectorStore.items.length} total embeddings`);
        }
    }["FilesProvider.useEffect"], [
        state.myFiles,
        state.documents,
        vectorStore
    ]);
    // reload the current user attributes when the auth event is triggered
    // NOTE: This is now handled by the centralized AuthContext
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FilesProvider.useEffect": ()=>{
            // Wait for auth to be ready
            if (authLoading || !user || !session) {
                return;
            }
            // Prevent duplicate subscriptions
            if (filesFetchedRef.current) {
                console.log("[FilesContext] fetchFiles already called, skipping");
                return;
            }
            // ── Offline fallback: load files from IndexedDB cache ─────────────
            if (typeof navigator !== "undefined" && !navigator.onLine) {
                filesFetchedRef.current = true;
                ({
                    "FilesProvider.useEffect": async ()=>{
                        try {
                            const { getAllRecords } = await __turbopack_context__.A("[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript, async loader)");
                            const cachedFiles = await getAllRecords("files");
                            if (cachedFiles.length > 0) {
                                const _playlistFiltered = {};
                                const _pdfsFiltered = {};
                                cachedFiles.forEach({
                                    "FilesProvider.useEffect": (f)=>{
                                        if (f.contentType && ACCEPTABLE_PLAYLIST_TYPES.includes(f.contentType)) {
                                            _playlistFiltered[f.id] = f;
                                        }
                                        if (f.contentType === "application/pdf") {
                                            _pdfsFiltered[f.id] = f;
                                        }
                                    }
                                }["FilesProvider.useEffect"]);
                                dispatch({
                                    type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].FILES_SUBSCRIPTION_UPDATE,
                                    payload: {
                                        myFiles: cachedFiles,
                                        myPlaylistFiles: _playlistFiltered,
                                        myPdfs: _pdfsFiltered
                                    }
                                });
                                console.log("[FilesContext] Loaded", cachedFiles.length, "files from offline cache");
                            }
                        } catch (err) {
                            console.warn("[FilesContext] Offline file cache load failed:", err);
                        }
                    }
                })["FilesProvider.useEffect"]();
                return;
            }
            // ── End offline fallback ──────────────────────────────────────────
            async function fetchFiles() {
                console.log("[FilesContext] fetchFiles called");
                try {
                    console.log("[FilesContext] User authenticated:", user.attributes.sub);
                    console.log("[FilesContext] Identity ID:", session.identityId);
                    const myUserId = user.attributes.sub;
                    if (!myUserId) {
                        console.log("[FilesContext] No myUserId, returning");
                        return;
                    }
                    // Mark as fetched before subscribing
                    filesFetchedRef.current = true;
                    console.log("[FilesContext] About to set up File observeQuery");
                    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                    function processFiles(validItems) {
                        const _playlistFiltered_0 = {};
                        const _pdfsFiltered_0 = {};
                        validItems.forEach({
                            "FilesProvider.useEffect.fetchFiles.processFiles": (item_1)=>{
                                if (item_1.mimeType && item_1.mimeType.startsWith("audio/")) {
                                    _playlistFiltered_0[item_1.id] = item_1;
                                }
                                if (item_1.mimeType === "application/pdf") {
                                    _pdfsFiltered_0[item_1.id] = item_1;
                                }
                            }
                        }["FilesProvider.useEffect.fetchFiles.processFiles"]);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_PLAYLIST_FILES,
                            payload: _playlistFiltered_0
                        });
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_PDFS,
                            payload: _pdfsFiltered_0
                        });
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_MY_FILES,
                            payload: validItems
                        });
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].INCREMENT_FILES_VERSION
                        });
                    }
                    function handleError(label, error_5) {
                        const msg = error_5?.message || error_5?.errors?.[0]?.message || error_5?.error?.errors?.[0]?.message || JSON.stringify(error_5);
                        if (msg.includes("DuplicatedOperationError")) {
                            console.warn(`[FilesContext] ${label}: transient DuplicatedOperationError (safe to ignore)`);
                            return;
                        }
                        console.error(`[FilesContext] ${label} error:`, error_5);
                    }
                    // Single observeQuery replaces list() + 3 manual subscriptions
                    // Exclude heavy fields: yjsSnapshot
                    const subscription = client.models.File.observeQuery({
                        selectionSet: [
                            "id",
                            "owner",
                            "identityId",
                            "name",
                            "description",
                            "prompt",
                            "model",
                            "variant",
                            "mimeType",
                            "level",
                            "path",
                            "size",
                            "duration",
                            "generated",
                            "hex",
                            "byHex",
                            "thumbnail",
                            "documentID",
                            "embedding.*",
                            "hlsUrl",
                            "transcodeStatus",
                            "mediaConvertJobId",
                            "_version",
                            "_lastChangedAt",
                            "_deleted",
                            "createdAt",
                            "updatedAt"
                        ]
                    }).subscribe({
                        next: {
                            "FilesProvider.useEffect.fetchFiles.subscription": ({ items })=>{
                                const allValid = (items || []).filter({
                                    "FilesProvider.useEffect.fetchFiles.subscription.allValid": (item_2)=>item_2 != null && item_2.id != null
                                }["FilesProvider.useEffect.fetchFiles.subscription.allValid"]);
                                const validItems_0 = allValid.filter({
                                    "FilesProvider.useEffect.fetchFiles.subscription.validItems_0": (item_3)=>item_3.deletedAt == null
                                }["FilesProvider.useEffect.fetchFiles.subscription.validItems_0"]);
                                const deleted = allValid.filter({
                                    "FilesProvider.useEffect.fetchFiles.subscription.deleted": (item_4)=>item_4.deletedAt != null
                                }["FilesProvider.useEffect.fetchFiles.subscription.deleted"]);
                                setDeletedFiles(deleted);
                                // Version map guard: skip if no item has a newer _version
                                const hasChanges = validItems_0.some({
                                    "FilesProvider.useEffect.fetchFiles.subscription.hasChanges": (item_5)=>{
                                        const tracked = fileVersionMapRef.current[item_5.id];
                                        return tracked == null || item_5._version > tracked;
                                    }
                                }["FilesProvider.useEffect.fetchFiles.subscription.hasChanges"]);
                                if (!hasChanges && Object.keys(fileVersionMapRef.current).length > 0) {
                                    return; // All items same or older version — skip dispatch
                                }
                                // Update version map
                                fileVersionMapRef.current = {};
                                validItems_0.forEach({
                                    "FilesProvider.useEffect.fetchFiles.subscription": (item_6)=>{
                                        fileVersionMapRef.current[item_6.id] = item_6._version;
                                    }
                                }["FilesProvider.useEffect.fetchFiles.subscription"]);
                                console.log("[FilesContext] File observeQuery update:", validItems_0.length, "files");
                                processFiles(validItems_0);
                            }
                        }["FilesProvider.useEffect.fetchFiles.subscription"],
                        error: {
                            "FilesProvider.useEffect.fetchFiles.subscription": (error_6)=>handleError("File observeQuery", error_6)
                        }["FilesProvider.useEffect.fetchFiles.subscription"]
                    });
                    subscriptionRef.current = subscription;
                } catch (error_4) {
                    // Handle authentication errors gracefully
                    if (error_4.name === "UserUnAuthenticatedException" || error_4.message?.includes("authenticated")) {
                        return;
                    }
                    console.error("Error fetching files:", error_4);
                }
            }
            fetchFiles();
            return ({
                "FilesProvider.useEffect": ()=>{
                    if (subscriptionRef.current) {
                        subscriptionRef.current.unsubscribe();
                    }
                    filesFetchedRef.current = false;
                }
            })["FilesProvider.useEffect"];
        }
    }["FilesProvider.useEffect"], [
        user,
        authLoading,
        session?.identityId
    ]);
    // Subscribe to Document status changes
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FilesProvider.useEffect": ()=>{
            const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            let cancelled = false;
            function parseDoc(doc) {
                const pageEmbeddings_0 = typeof doc.pageEmbeddings === "string" ? JSON.parse(doc.pageEmbeddings) : doc.pageEmbeddings;
                return {
                    id: doc.id,
                    s3Key: doc.s3Key,
                    status: doc.status,
                    pageCount: doc.pageCount,
                    pageEmbeddings: pageEmbeddings_0,
                    embeddingsS3Key: doc.embeddingsS3Key,
                    updatedAt: doc.updatedAt,
                    _version: doc._version
                };
            }
            function handleError_0(label_0, error_7) {
                const msg_0 = error_7?.message || error_7?.errors?.[0]?.message || error_7?.error?.errors?.[0]?.message || JSON.stringify(error_7);
                if (msg_0.includes("DuplicatedOperationError")) {
                    console.warn(`[FilesContext] ${label_0}: transient DuplicatedOperationError (safe to ignore)`);
                    return;
                }
                console.error(`[FilesContext] ${label_0} error:`, error_7);
            }
            // Single observeQuery replaces list() + 3 manual subscriptions
            // Exclude heavy fields: metadata, yjsSnapshot (extractedText moved to S3)
            const subscription_0 = client_0.models.Document.observeQuery({
                selectionSet: [
                    "id",
                    "owner",
                    "identityId",
                    "learner",
                    "sectionID",
                    "readableGroups.*",
                    "writableGroups.*",
                    "filename",
                    "s3Key",
                    "status",
                    "textExtractedAt",
                    "pageCount",
                    "fileSize",
                    "mimeType",
                    "sourceFormat",
                    "uploadedAt",
                    "resumeState.*",
                    "_version",
                    "_lastChangedAt",
                    "_deleted",
                    "createdAt",
                    "updatedAt"
                ]
            }).subscribe({
                next: {
                    "FilesProvider.useEffect.subscription_0": ({ items: items_0 })=>{
                        if (cancelled) return;
                        const allValid_0 = (items_0 || []).filter({
                            "FilesProvider.useEffect.subscription_0.allValid_0": (item_7)=>item_7 != null && item_7.id != null
                        }["FilesProvider.useEffect.subscription_0.allValid_0"]);
                        const validItems_1 = allValid_0.filter({
                            "FilesProvider.useEffect.subscription_0.validItems_1": (item_8)=>item_8.deletedAt == null
                        }["FilesProvider.useEffect.subscription_0.validItems_1"]);
                        const deletedDocs = allValid_0.filter({
                            "FilesProvider.useEffect.subscription_0.deletedDocs": (item_9)=>item_9.deletedAt != null
                        }["FilesProvider.useEffect.subscription_0.deletedDocs"]);
                        setDeletedDocuments(deletedDocs);
                        // Version map guard: skip if no item has a newer _version
                        const hasChanges_0 = validItems_1.some({
                            "FilesProvider.useEffect.subscription_0.hasChanges_0": (item_10)=>{
                                const tracked_0 = documentVersionMapRef.current[item_10.id];
                                return tracked_0 == null || item_10._version > tracked_0;
                            }
                        }["FilesProvider.useEffect.subscription_0.hasChanges_0"]);
                        if (!hasChanges_0 && Object.keys(documentVersionMapRef.current).length > 0) {
                            return; // All items same or older version — skip dispatch
                        }
                        // Update version map
                        documentVersionMapRef.current = {};
                        validItems_1.forEach({
                            "FilesProvider.useEffect.subscription_0": (item_11)=>{
                                documentVersionMapRef.current[item_11.id] = item_11._version;
                            }
                        }["FilesProvider.useEffect.subscription_0"]);
                        const docsMap = {};
                        validItems_1.forEach({
                            "FilesProvider.useEffect.subscription_0": (doc_0)=>{
                                docsMap[doc_0.id] = parseDoc(doc_0);
                            }
                        }["FilesProvider.useEffect.subscription_0"]);
                        dispatch({
                            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_DOCUMENTS,
                            payload: docsMap
                        });
                    }
                }["FilesProvider.useEffect.subscription_0"],
                error: {
                    "FilesProvider.useEffect.subscription_0": (error_8)=>handleError_0("Document observeQuery", error_8)
                }["FilesProvider.useEffect.subscription_0"]
            });
            documentSubscriptionRef.current = subscription_0;
            return ({
                "FilesProvider.useEffect": ()=>{
                    cancelled = true;
                    if (documentSubscriptionRef.current) {
                        documentSubscriptionRef.current.unsubscribe();
                    }
                }
            })["FilesProvider.useEffect"];
        }
    }["FilesProvider.useEffect"], []);
    const refreshAudioFiles = async ()=>{
        const results = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["list"])("audio/", {
            cacheControl: "no-cache"
        });
        if (results?.results?.length > 0) {
            const fileMap = {};
            results.results.forEach((item_12)=>{
                fileMap[item_12.key] = item_12;
            });
            dispatch({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$reducers$2f$fileReducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actionTypes"].SET_AUDIO_FILES,
                payload: fileMap
            });
        }
    };
    // Optimistic version bump helpers — call before save to block subscription echo
    const bumpFileVersion = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "FilesProvider.useCallback[bumpFileVersion]": (id, currentVersion_0)=>{
            const previousVersion = fileVersionMapRef.current[id] || currentVersion_0;
            fileVersionMapRef.current[id] = currentVersion_0 + 1;
            return {
                confirm: ({
                    "FilesProvider.useCallback[bumpFileVersion]": (actualVersion)=>{
                        fileVersionMapRef.current[id] = actualVersion;
                    }
                })["FilesProvider.useCallback[bumpFileVersion]"],
                rollback: ({
                    "FilesProvider.useCallback[bumpFileVersion]": ()=>{
                        fileVersionMapRef.current[id] = previousVersion;
                    }
                })["FilesProvider.useCallback[bumpFileVersion]"]
            };
        }
    }["FilesProvider.useCallback[bumpFileVersion]"], []);
    const bumpDocumentVersion = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "FilesProvider.useCallback[bumpDocumentVersion]": (id_0, currentVersion_1)=>{
            const previousVersion_0 = documentVersionMapRef.current[id_0] || currentVersion_1;
            documentVersionMapRef.current[id_0] = currentVersion_1 + 1;
            return {
                confirm: ({
                    "FilesProvider.useCallback[bumpDocumentVersion]": (actualVersion_0)=>{
                        documentVersionMapRef.current[id_0] = actualVersion_0;
                    }
                })["FilesProvider.useCallback[bumpDocumentVersion]"],
                rollback: ({
                    "FilesProvider.useCallback[bumpDocumentVersion]": ()=>{
                        documentVersionMapRef.current[id_0] = previousVersion_0;
                    }
                })["FilesProvider.useCallback[bumpDocumentVersion]"]
            };
        }
    }["FilesProvider.useCallback[bumpDocumentVersion]"], []);
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "FilesProvider.useMemo[contextValue]": ()=>({
                audioFiles: state.audioFiles,
                refreshAudioFiles,
                files: state.myFiles,
                myFiles: state.myFiles,
                myPlaylistFiles: state.myPlaylistFiles,
                myPlaylistUrls: state.myPlaylistUrls,
                myPdfs: state.myPdfs,
                documents: state.documents,
                session: session || {
                    identityId: undefined,
                    idToken: undefined
                },
                // Provide safe default
                filesVersion: state.filesVersion,
                vectorStore,
                // Stable ref, doesn't cause re-renders
                vectorStoreReady: state.vectorStoreReady,
                bumpFileVersion,
                bumpDocumentVersion,
                showDeleted,
                setShowDeleted,
                deletedFiles,
                deletedDocuments
            })
    }["FilesProvider.useMemo[contextValue]"], [
        state.audioFiles,
        state.myFiles,
        state.myPlaylistFiles,
        state.myPlaylistUrls,
        state.myPdfs,
        state.documents,
        session,
        state.filesVersion,
        // vectorStore is intentionally excluded - it's a ref and never changes
        state.vectorStoreReady,
        bumpFileVersion,
        bumpDocumentVersion,
        showDeleted,
        deletedFiles,
        deletedDocuments
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FilesContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/fileContext.jsx",
        lineNumber: 542,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(FilesProvider, "Q1p68545gyYrqOEM93gZJN7DbiA=");
_c = FilesProvider;
;
const __TURBOPACK__default__export__ = FilesContext;
var _c;
__turbopack_context__.k.register(_c, "FilesProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_context_1i-rlu4._.js.map