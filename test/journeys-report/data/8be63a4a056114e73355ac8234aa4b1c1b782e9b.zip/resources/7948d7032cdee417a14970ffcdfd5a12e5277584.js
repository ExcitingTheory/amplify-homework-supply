(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Editor3/components/ImageNode.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createImageNode",
    ()=>$createImageNode,
    "$isImageNode",
    ()=>$isImageNode,
    "ImageNode",
    ()=>ImageNode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
;
const ImageComponent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"](// @ts-ignore
()=>__turbopack_context__.A("[project]/src/components/Editor3/components/ImageComponent.jsx [app-client] (ecmascript, async loader)"));
_c = ImageComponent;
function convertImageElement(domNode) {
    if (domNode instanceof HTMLImageElement) {
        const { alt: altText, path, src, width, height } = domNode;
        const node = $createImageNode({
            altText,
            height,
            src,
            path,
            width,
            identityId
        });
        return {
            node
        };
    }
    return null;
}
class ImageNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __path;
    __identityId;
    __fileId;
    __src;
    __altText;
    __width;
    __height;
    __maxWidth;
    __showCaption;
    __caption;
    __captionsEnabled;
    static getType() {
        return "image";
    }
    static clone(node) {
        return new ImageNode(node.__path, node.__identityId, node.__src, node.__altText, node.__maxWidth, node.__width, node.__height, node.__showCaption, node.__caption, node.__captionsEnabled, node.__key, node.__fileId);
    }
    static importJSON(serializedNode) {
        const { altText, height, width, maxWidth, caption, src, path, showCaption, identityId: identityId1, fileId } = serializedNode;
        const node = $createImageNode({
            altText,
            height,
            maxWidth,
            showCaption,
            src,
            path,
            width,
            identityId: identityId1,
            fileId
        });
        const nestedEditor = node.__caption;
        const editorState = nestedEditor.parseEditorState(caption.editorState);
        if (!editorState.isEmpty()) {
            nestedEditor.setEditorState(editorState);
        }
        return node;
    }
    exportDOM() {
        const element = document.createElement("img");
        element.setAttribute("src", this.__src);
        element.setAttribute("x-data-lexical-image", this.__path);
        element.setAttribute("x-data-lexical-identity-id", this.__identityId);
        element.setAttribute("alt", this.__altText);
        element.setAttribute("width", this.__width.toString());
        element.setAttribute("height", this.__height.toString());
        return {
            element
        };
    }
    static importDOM() {
        return {
            img: (node)=>({
                    conversion: convertImageElement,
                    priority: 0
                })
        };
    }
    constructor(path, identityId1, src, altText, maxWidth, width = "100%", height = "auto", showCaption = false, caption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEditor"])(), captionsEnabled, key, fileId){
        super(key);
        this.__path = path;
        this.__identityId = identityId1;
        this.__fileId = fileId || null;
        this.__src = src;
        this.__altText = altText;
        this.__maxWidth = maxWidth;
        this.__width = width;
        this.__height = height;
        this.__showCaption = showCaption;
        this.__caption = caption;
        this.__captionsEnabled = captionsEnabled || captionsEnabled === undefined;
    }
    exportJSON() {
        return {
            altText: this.getAltText(),
            caption: this.__caption.toJSON(),
            height: this.__height,
            maxWidth: this.__maxWidth,
            showCaption: this.__showCaption,
            src: this.getSrc(),
            path: this.__path,
            identityId: this.__identityId,
            fileId: this.__fileId,
            type: "image",
            version: 1,
            width: this.__width
        };
    }
    setWidthAndHeight(width, height) {
        const writable = this.getWritable();
        writable.__width = width;
        writable.__height = height;
    }
    setShowCaption(showCaption) {
        const writable = this.getWritable();
        writable.__showCaption = showCaption;
    }
    createDOM(config) {
        const span = document.createElement("span");
        const theme = config.theme;
        const className = theme.image;
        if (className !== undefined) {
            span.className = className;
        }
        return span;
    }
    updateDOM() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
    canBeEmpty() {
        return true;
    }
    getSrc() {
        return this.__src;
    }
    getAltText() {
        return this.__altText;
    }
    decorate() {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: null,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    id: "23d41aa1ec74084a",
                    children: ".ImageNode__contentEditable{resize:none;cursor:text;caret-color:#050505;-webkit-user-select:text;user-select:text;white-space:pre-wrap;word-break:break-word;border:0;outline:0;width:calc(100% - 20px);min-height:20px;padding:10px;font-size:12px;display:block;position:relative}.ImageNode__placeholder{color:var(--mui-palette-text-disabled,#888);text-overflow:ellipsis;-webkit-user-select:none;user-select:none;white-space:nowrap;pointer-events:none;font-size:12px;display:inline-block;position:absolute;top:10px;left:10px;overflow:hidden}.image-control-wrapper--resizing{touch-action:none}"
                }, void 0, false, void 0, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ImageComponent, {
                    src: this.__src,
                    path: this.__path,
                    identityId: this.__identityId,
                    fileId: this.__fileId,
                    altText: this.__altText,
                    width: this.__width,
                    height: this.__height,
                    maxWidth: this.__maxWidth,
                    nodeKey: this.getKey(),
                    showCaption: this.__showCaption,
                    caption: this.__caption,
                    captionsEnabled: this.__captionsEnabled,
                    resizable: true
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/ImageNode.jsx",
                    lineNumber: 237,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/ImageNode.jsx",
            lineNumber: 200,
            columnNumber: 7
        }, this);
    }
}
function $createImageNode({ altText, height, maxWidth = 800, captionsEnabled, src, path, width, showCaption, caption, key, identityId: identityId1, fileId }) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new ImageNode(path, identityId1, src, altText, maxWidth, width, height, showCaption, caption, captionsEnabled, key, fileId));
}
function $isImageNode(node) {
    return node instanceof ImageNode;
}
var _c;
__turbopack_context__.k.register(_c, "ImageComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/FileManagerContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FileManagerProvider",
    ()=>FileManagerProvider,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useFileManager",
    ()=>useFileManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
const FileManagerContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext(null);
const FileManagerProvider = (t0)=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "0d3c36f82a13e88513f46cfebe2cfa513968604039184eff52c59274a1c80b4c") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0d3c36f82a13e88513f46cfebe2cfa513968604039184eff52c59274a1c80b4c";
    }
    const { children, value } = t0;
    let t1;
    if ($[1] !== children || $[2] !== value) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FileManagerContext.Provider, {
            value: value,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManagerContext.jsx",
            lineNumber: 18,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[1] = children;
        $[2] = value;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    return t1;
};
_c = FileManagerProvider;
const useFileManager = ()=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "0d3c36f82a13e88513f46cfebe2cfa513968604039184eff52c59274a1c80b4c") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0d3c36f82a13e88513f46cfebe2cfa513968604039184eff52c59274a1c80b4c";
    }
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(FileManagerContext);
    if (!context) {
        throw new Error("useFileManager must be used within FileManagerProvider");
    }
    return context;
};
_s(useFileManager, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
const __TURBOPACK__default__export__ = FileManagerContext;
var _c;
__turbopack_context__.k.register(_c, "FileManagerProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/StaticWaveform.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StaticWaveform
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/ThemeProviderWithVars.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$hexToRgb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/hexToRgb.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calculateWaveformData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/calculateWaveformData.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
function StaticWaveform({ file, waveformData: propWaveformData, width = 600, height = 100, backgroundColor, showLoading = true }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.shared");
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { mode } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StaticWaveform.useEffect": ()=>{
            if (!file && !propWaveformData) return;
            // Read CSS variables for canvas (which can't use var())
            const resolvedBg = backgroundColor || (typeof document !== "undefined" ? getComputedStyle(document.documentElement).getPropertyValue("--mui-palette-background-paper").trim() : "") || "#ffffff";
            const mainColor = (typeof document !== "undefined" ? getComputedStyle(document.documentElement).getPropertyValue("--mui-palette-primary-main").trim() : "") || "#556cd6";
            const rgbColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$hexToRgb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(mainColor);
            const drawWaveform = {
                "StaticWaveform.useEffect.drawWaveform": async ()=>{
                    try {
                        setLoading(true);
                        setError(null);
                        let normalizedData;
                        // Use pre-calculated data if available
                        if (propWaveformData) {
                            normalizedData = propWaveformData;
                        } else if (file) {
                            // Calculate from audio file
                            const audioUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(file.path || file.key);
                            if (!audioUrl) {
                                throw new Error("Could not resolve audio URL from file");
                            }
                            const response = await fetch(audioUrl);
                            const arrayBuffer = await response.arrayBuffer();
                            normalizedData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calculateWaveformData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateWaveformData"])(arrayBuffer, width);
                        } else {
                            throw new Error("No waveform data or file provided");
                        }
                        // Draw the waveform
                        const canvas_0 = canvasRef.current;
                        if (!canvas_0) return;
                        canvas_0.width = width;
                        canvas_0.height = height;
                        const ctx_0 = canvas_0.getContext("2d");
                        // Clear canvas
                        ctx_0.fillStyle = resolvedBg;
                        ctx_0.fillRect(0, 0, width, height);
                        // Draw waveform
                        const middle_0 = height / 2;
                        const samples = normalizedData.length;
                        const barWidth_0 = width / samples;
                        // Check data quality
                        const minVal = Math.min(...normalizedData);
                        const maxVal = Math.max(...normalizedData);
                        const range = maxVal - minVal;
                        console.warn("🔊 WAVEFORM DEBUG:", {
                            dataLength: normalizedData.length,
                            barWidth: barWidth_0,
                            firstValues: normalizedData.slice(0, 5),
                            minValue: minVal,
                            maxValue: maxVal,
                            range,
                            width,
                            height,
                            note: range < 0.2 ? "⚠️ LOW VARIANCE (AGC/compression) - stretching for visibility" : "✅ Good variance"
                        });
                        // Re-normalize if variance is too low (typical of browser microphone recordings with AGC)
                        // This stretches the visible waveform without changing the actual audio
                        let displayData = normalizedData;
                        if (range > 0 && range < 0.2) {
                            displayData = normalizedData.map({
                                "StaticWaveform.useEffect.drawWaveform": (val)=>(val - minVal) / range
                            }["StaticWaveform.useEffect.drawWaveform"]);
                        } else if (range === 0 && maxVal > 0) {
                            // All values identical (e.g. all 1.0) — show flat at half height
                            displayData = normalizedData.map({
                                "StaticWaveform.useEffect.drawWaveform": ()=>0.5
                            }["StaticWaveform.useEffect.drawWaveform"]);
                        }
                        for(let i_0 = 0; i_0 < displayData.length; i_0++){
                            const barHeight_0 = displayData[i_0] * middle_0;
                            const x_0 = i_0 * barWidth_0;
                            // Create gradient for visual appeal
                            const intensity = Math.floor(displayData[i_0] * 155) + 100;
                            ctx_0.fillStyle = `rgb(${intensity}, ${rgbColor.g}, ${rgbColor.b})`;
                            // Draw from middle outward (symmetric)
                            ctx_0.fillRect(x_0, middle_0 - barHeight_0, barWidth_0 - 0.5, barHeight_0 * 2);
                        }
                        setLoading(false);
                    } catch (err) {
                        console.error("Error drawing waveform:", err);
                        // Don't show error for encoding issues in development/storybook
                        if (err.name === "EncodingError") {
                            // Draw a placeholder waveform
                            const canvas = canvasRef.current;
                            if (canvas) {
                                canvas.width = width;
                                canvas.height = height;
                                const ctx = canvas.getContext("2d");
                                ctx.fillStyle = resolvedBg;
                                ctx.fillRect(0, 0, width, height);
                                // Draw simple placeholder bars
                                const middle = height / 2;
                                const bars = 50;
                                const barWidth = width / bars;
                                for(let i = 0; i < bars; i++){
                                    const barHeight = Math.random() * middle * 0.7;
                                    const x = i * barWidth;
                                    ctx.fillStyle = `rgb(${rgbColor.r}, ${rgbColor.g}, ${rgbColor.b})`;
                                    ctx.fillRect(x, middle - barHeight, barWidth - 1, barHeight * 2);
                                }
                            }
                        } else {
                            setError(err.message);
                        }
                        setLoading(false);
                    }
                }
            }["StaticWaveform.useEffect.drawWaveform"];
            drawWaveform();
        }
    }["StaticWaveform.useEffect"], [
        file,
        propWaveformData,
        width,
        height,
        backgroundColor,
        mode
    ]);
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                width,
                height,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                border: "1px solid #ccc",
                borderRadius: 1,
                color: "error.main"
            },
            children: t("staticWaveform.errorLoading")
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/StaticWaveform.jsx",
            lineNumber: 167,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            position: "relative",
            width,
            height
        },
        children: [
            loading && showLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: "var(--mui-palette-background-paper)",
                    opacity: 0.8,
                    zIndex: 1
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                    variant: "rectangular",
                    width: "100%",
                    height: 30,
                    sx: {
                        borderRadius: 1
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/StaticWaveform.jsx",
                    lineNumber: 198,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/StaticWaveform.jsx",
                lineNumber: 185,
                columnNumber: 34
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                ref: canvasRef,
                style: {
                    display: "block",
                    border: "1px solid var(--mui-palette-divider)",
                    borderRadius: "4px"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/StaticWaveform.jsx",
                lineNumber: 202,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/StaticWaveform.jsx",
        lineNumber: 180,
        columnNumber: 10
    }, this);
}
_s(StaticWaveform, "EIn7s0PKBbpr2fPRlVZlo+eu9rQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"]
    ];
});
_c = StaticWaveform;
var _c;
__turbopack_context__.k.register(_c, "StaticWaveform");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/MicLevelIndicator.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MicLevelIndicator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Mic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Mic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MicOff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MicOff.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$WarningAmber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/WarningAmber.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$audioLevelMonitor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/audioLevelMonitor.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
function MicLevelIndicator(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(32);
    if ($[0] !== "58ec6a77e096639431d1a695c4dd06aa1476b8db70deb4b4f9967e5f64d8b1b7") {
        for(let $i = 0; $i < 32; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "58ec6a77e096639431d1a695c4dd06aa1476b8db70deb4b4f9967e5f64d8b1b7";
    }
    const { analyser, lowThresholdDb: t1, silenceThresholdDb: t2, warningDelaySec: t3, width } = t0;
    const lowThresholdDb = t1 === undefined ? -50 : t1;
    const silenceThresholdDb = t2 === undefined ? -70 : t2;
    const warningDelaySec = t3 === undefined ? 3 : t3;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.shared");
    const [level, setLevel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("ok");
    const [showWarning, setShowWarning] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const lowSinceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t4;
    if ($[1] !== warningDelaySec) {
        t4 = ({
            "MicLevelIndicator[handleLevel]": (data)=>{
                setLevel((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$audioLevelMonitor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rmsToPercent"])(data.rms));
                if (data.silent) {
                    setStatus("silent");
                } else {
                    if (data.tooLow) {
                        setStatus("low");
                    } else {
                        setStatus("ok");
                        lowSinceRef.current = null;
                        setShowWarning(false);
                    }
                }
                if (data.tooLow || data.silent) {
                    if (!lowSinceRef.current) {
                        lowSinceRef.current = Date.now();
                    } else {
                        if (Date.now() - lowSinceRef.current > warningDelaySec * 1000) {
                            setShowWarning(true);
                        }
                    }
                }
            }
        })["MicLevelIndicator[handleLevel]"];
        $[1] = warningDelaySec;
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    const handleLevel = t4;
    let t5;
    let t6;
    if ($[3] !== analyser || $[4] !== handleLevel || $[5] !== lowThresholdDb || $[6] !== silenceThresholdDb) {
        t5 = ({
            "MicLevelIndicator[useEffect()]": ()=>{
                if (!analyser) {
                    setLevel(0);
                    setStatus("ok");
                    setShowWarning(false);
                    lowSinceRef.current = null;
                    return;
                }
                const monitor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$audioLevelMonitor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAudioLevelMonitor"])(analyser, {
                    lowThresholdDb,
                    silenceThresholdDb,
                    intervalMs: 80,
                    onLevel: handleLevel
                });
                monitor.start();
                return ()=>monitor.stop();
            }
        })["MicLevelIndicator[useEffect()]"];
        t6 = [
            analyser,
            lowThresholdDb,
            silenceThresholdDb,
            handleLevel
        ];
        $[3] = analyser;
        $[4] = handleLevel;
        $[5] = lowThresholdDb;
        $[6] = silenceThresholdDb;
        $[7] = t5;
        $[8] = t6;
    } else {
        t5 = $[7];
        t6 = $[8];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    const barColor = status === "silent" ? "error.main" : status === "low" ? "warning.main" : "success.main";
    const iconColor = status === "silent" ? "error" : status === "low" ? "warning" : "success";
    if (!analyser) {
        return null;
    }
    const t7 = width || "100%";
    let t8;
    if ($[9] !== t7) {
        t8 = {
            display: "flex",
            alignItems: "center",
            gap: 0.5,
            width: t7
        };
        $[9] = t7;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] !== iconColor || $[12] !== status) {
        t9 = status === "silent" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MicOff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            color: iconColor,
            sx: {
                fontSize: 18
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MicLevelIndicator.jsx",
            lineNumber: 135,
            columnNumber: 32
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Mic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            color: iconColor,
            sx: {
                fontSize: 18
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MicLevelIndicator.jsx",
            lineNumber: 137,
            columnNumber: 13
        }, this);
        $[11] = iconColor;
        $[12] = status;
        $[13] = t9;
    } else {
        t9 = $[13];
    }
    let t10;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            flexGrow: 1,
            height: 6,
            borderRadius: 3,
            bgcolor: "action.hover",
            overflow: "hidden",
            position: "relative"
        };
        $[14] = t10;
    } else {
        t10 = $[14];
    }
    const t11 = `${level}%`;
    let t12;
    if ($[15] !== barColor || $[16] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t10,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    height: "100%",
                    width: t11,
                    bgcolor: barColor,
                    borderRadius: 3,
                    transition: "width 80ms linear, background-color 200ms ease"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/MicLevelIndicator.jsx",
                lineNumber: 163,
                columnNumber: 25
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MicLevelIndicator.jsx",
            lineNumber: 163,
            columnNumber: 11
        }, this);
        $[15] = barColor;
        $[16] = t11;
        $[17] = t12;
    } else {
        t12 = $[17];
    }
    let t13;
    if ($[18] !== showWarning || $[19] !== status || $[20] !== t) {
        t13 = showWarning && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: status === "silent" ? t("micLevelIndicator.noSignal") : t("micLevelIndicator.tooLow"),
            open: true,
            arrow: true,
            placement: "top",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$WarningAmber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                color: "warning",
                sx: {
                    fontSize: 18
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/MicLevelIndicator.jsx",
                lineNumber: 178,
                columnNumber: 170
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MicLevelIndicator.jsx",
            lineNumber: 178,
            columnNumber: 26
        }, this);
        $[18] = showWarning;
        $[19] = status;
        $[20] = t;
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    let t14;
    if ($[22] !== showWarning || $[23] !== status || $[24] !== t) {
        t14 = showWarning && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: status === "silent" ? "error" : "warning.main",
            sx: {
                whiteSpace: "nowrap",
                fontWeight: 500
            },
            children: status === "silent" ? t("micLevelIndicator.noSignalShort") : t("micLevelIndicator.tooLowShort")
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MicLevelIndicator.jsx",
            lineNumber: 190,
            columnNumber: 26
        }, this);
        $[22] = showWarning;
        $[23] = status;
        $[24] = t;
        $[25] = t14;
    } else {
        t14 = $[25];
    }
    let t15;
    if ($[26] !== t12 || $[27] !== t13 || $[28] !== t14 || $[29] !== t8 || $[30] !== t9) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t8,
            children: [
                t9,
                t12,
                t13,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/MicLevelIndicator.jsx",
            lineNumber: 203,
            columnNumber: 11
        }, this);
        $[26] = t12;
        $[27] = t13;
        $[28] = t14;
        $[29] = t8;
        $[30] = t9;
        $[31] = t15;
    } else {
        t15 = $[31];
    }
    return t15;
}
_s(MicLevelIndicator, "vEO9NH88zbbwVmU0BHmo1ac6Fic=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = MicLevelIndicator;
var _c;
__turbopack_context__.k.register(_c, "MicLevelIndicator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AudioWaveformPlayer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Slider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Slider/Slider.js [app-client] (ecmascript) <export default as Slider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PlayArrow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PlayArrow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Pause$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Pause.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Stop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Stop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$KeyboardVoice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/KeyboardVoice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$StaticWaveform$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/StaticWaveform.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$MicLevelIndicator$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/MicLevelIndicator.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$AudioPlayerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/context/AudioPlayerContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calculateWaveformData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/calculateWaveformData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$userSubmissionStorage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/userSubmissionStorage.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$applyAudioFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/applyAudioFilters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$audioBufferToBlob$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/audioBufferToBlob.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/ThemeProviderWithVars.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$hexToRgb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/hexToRgb.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/fileContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$RecordingSettings$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudio3/RecordingSettings.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Module-level cache: avoids redundant fetch+decode when the same URL
// is rendered by multiple players or across remounts.
const waveformCache = new Map();
function AudioWaveformPlayer({ audioUrl, file, width = 600, height = 80, title, showDuration = true, enableRecording = false, gradeId, nodeKey, metadata = {}, onRecordingComplete, audioFilters = [], cleanupStrength = "standard" }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.shared");
    const tEditor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor");
    const { mode } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"])();
    // Resolve CSS variables for canvas drawing (canvas API can't use var())
    // Re-computed when color mode changes (light <-> dark)
    const canvasBg = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "AudioWaveformPlayer.useMemo[canvasBg]": ()=>{
            if (typeof document === "undefined") return "#ffffff";
            return getComputedStyle(document.documentElement).getPropertyValue("--mui-palette-background-paper").trim() || "#ffffff";
        }
    }["AudioWaveformPlayer.useMemo[canvasBg]"], [
        mode
    ]);
    const { mainColor, _r, _g, _b } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "AudioWaveformPlayer.useMemo": ()=>{
            if (typeof document === "undefined") return {
                mainColor: "#556cd6",
                _r: 85,
                _g: 108,
                _b: 214
            };
            const mc = getComputedStyle(document.documentElement).getPropertyValue("--mui-palette-primary-main").trim() || "#556cd6";
            const rgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$hexToRgb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(mc);
            return {
                mainColor: mc,
                _r: rgb.r,
                _g: rgb.g,
                _b: rgb.b
            };
        }
    }["AudioWaveformPlayer.useMemo"], [
        mode
    ]);
    const audioPlayer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$AudioPlayerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAudioPlayer"])();
    // Playback state
    const [localTime, setLocalTime] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [localDuration, setLocalDuration] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [localProgress, setLocalProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isReady, setIsReady] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [blobUrl, setBlobUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isSeeking, setIsSeeking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Recording state
    const [recording, setRecording] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [mediaRecorder, setMediaRecorder] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [audioBlob, setAudioBlob] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [recordedWaveformData, setRecordedWaveformData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [computedWaveformData, setComputedWaveformData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [pendingRecordingStart, setPendingRecordingStart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Filtered playback cache: keyed by `${url}::${sortedFilters}`
    const filteredBlobCacheRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    const [filteredBlobUrl, setFilteredBlobUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Cleanup filtered blob URLs on unmount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            return ({
                "AudioWaveformPlayer.useEffect": ()=>{
                    for (const url of filteredBlobCacheRef.current.values()){
                        URL.revokeObjectURL(url);
                    }
                    filteredBlobCacheRef.current.clear();
                }
            })["AudioWaveformPlayer.useEffect"];
        }
    }["AudioWaveformPlayer.useEffect"], []);
    // Mic preview state (hover to show room noise)
    const [previewing, setPreviewing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const previewStreamRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const previewAudioCtxRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const previewAnalyserRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const previewRafRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Shared analyser ref for MicLevelIndicator (points to whichever is active)
    const [activeAnalyser, setActiveAnalyser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Refs
    const loadedSourceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const currentTimeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const displayTimeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const lastFrameTimeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(performance.now());
    const recordingCanvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mediaStreamRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const durationRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0); // Always-current duration for RAF callbacks
    // Context
    const filesContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const identityId = filesContext?.session?.identityId;
    // Keep durationRef in sync with localDuration state for RAF callbacks
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            durationRef.current = localDuration;
        }
    }["AudioWaveformPlayer.useEffect"], [
        localDuration
    ]);
    // Create blob URL only once from file
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            if (file && !audioUrl) {
                // Guard: file must be a Blob/File to create an object URL
                if (!(file instanceof Blob)) return;
                const url_0 = URL.createObjectURL(file);
                setBlobUrl(url_0);
                return ({
                    "AudioWaveformPlayer.useEffect": ()=>{
                        URL.revokeObjectURL(url_0);
                        setBlobUrl(null);
                    }
                })["AudioWaveformPlayer.useEffect"];
            }
        }
    }["AudioWaveformPlayer.useEffect"], [
        file,
        audioUrl
    ]);
    // Create blob URL for recorded audio
    const [recordedBlobUrl, setRecordedBlobUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            if (audioBlob) {
                const url_1 = URL.createObjectURL(audioBlob);
                setRecordedBlobUrl(url_1);
                return ({
                    "AudioWaveformPlayer.useEffect": ()=>{
                        URL.revokeObjectURL(url_1);
                        setRecordedBlobUrl(null);
                    }
                })["AudioWaveformPlayer.useEffect"];
            }
        }
    }["AudioWaveformPlayer.useEffect"], [
        audioBlob
    ]);
    // Local audio element for recording playback (bypasses shared context)
    const localAudioRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [localIsPlaying, setLocalIsPlaying] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            if (!recordedBlobUrl) {
                localAudioRef.current = null;
                return;
            }
            const audio = new Audio(recordedBlobUrl);
            localAudioRef.current = audio;
            // For WebM blobs from MediaRecorder, audio.duration is often Infinity.
            // We already have the correct duration from decodeAudioData (set in recording
            // stop handler via setLocalDuration). So we just need basic event listeners
            // and rely on durationRef for progress calculation in the RAF loop.
            const onMeta = {
                "AudioWaveformPlayer.useEffect.onMeta": ()=>{
                    const dur = audio.duration;
                    if (!isNaN(dur) && isFinite(dur) && dur > 0) {
                        setLocalDuration(dur);
                        setIsReady(true);
                    } else {
                        // Duration is Infinity/NaN (WebM) — rely on decodeAudioData value
                        // which was already set in the recording stop handler
                        setIsReady(true);
                    }
                }
            }["AudioWaveformPlayer.useEffect.onMeta"];
            const onEnded = {
                "AudioWaveformPlayer.useEffect.onEnded": ()=>{
                    setLocalIsPlaying(false);
                    setLocalTime(0);
                    setLocalProgress(0);
                    currentTimeRef.current = 0;
                    displayTimeRef.current = 0;
                }
            }["AudioWaveformPlayer.useEffect.onEnded"];
            const onPlay = {
                "AudioWaveformPlayer.useEffect.onPlay": ()=>setLocalIsPlaying(true)
            }["AudioWaveformPlayer.useEffect.onPlay"];
            const onPause = {
                "AudioWaveformPlayer.useEffect.onPause": ()=>setLocalIsPlaying(false)
            }["AudioWaveformPlayer.useEffect.onPause"];
            audio.addEventListener("loadedmetadata", onMeta);
            audio.addEventListener("ended", onEnded);
            audio.addEventListener("play", onPlay);
            audio.addEventListener("pause", onPause);
            return ({
                "AudioWaveformPlayer.useEffect": ()=>{
                    audio.removeEventListener("loadedmetadata", onMeta);
                    audio.removeEventListener("ended", onEnded);
                    audio.removeEventListener("play", onPlay);
                    audio.removeEventListener("pause", onPause);
                    audio.pause();
                    audio.src = "";
                    localAudioRef.current = null;
                    setLocalIsPlaying(false);
                }
            })["AudioWaveformPlayer.useEffect"];
        }
    }["AudioWaveformPlayer.useEffect"], [
        recordedBlobUrl
    ]);
    // Use audioUrl if provided, otherwise use blob URL, otherwise use recorded blob URL
    const sourceUrl = audioUrl || blobUrl || recordedBlobUrl;
    const useLocalAudio = !!recordedBlobUrl;
    // Compute waveform from audioUrl when no file is provided
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            if (!audioUrl || file) return;
            const cacheKey = `${audioUrl}:${width}`;
            const cached = waveformCache.get(cacheKey);
            if (cached) {
                setComputedWaveformData(cached);
                return;
            }
            let cancelled = false;
            ({
                "AudioWaveformPlayer.useEffect": async ()=>{
                    try {
                        const response = await fetch(audioUrl);
                        const arrayBuffer = await response.arrayBuffer();
                        const waveform = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calculateWaveformData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateWaveformData"])(arrayBuffer, width);
                        waveformCache.set(cacheKey, waveform);
                        if (!cancelled) setComputedWaveformData(waveform);
                    } catch (err) {
                        console.warn("[AudioWaveformPlayer] Failed to compute waveform:", err);
                    }
                }
            })["AudioWaveformPlayer.useEffect"]();
            return ({
                "AudioWaveformPlayer.useEffect": ()=>{
                    cancelled = true;
                }
            })["AudioWaveformPlayer.useEffect"];
        }
    }["AudioWaveformPlayer.useEffect"], [
        audioUrl,
        file,
        width
    ]);
    // Check if this player is currently active
    const isActive = useLocalAudio ? !!localAudioRef.current : audioPlayer.currentSource === sourceUrl;
    const isPlaying = useLocalAudio ? localIsPlaying : isActive && audioPlayer.isPlaying;
    // Subscribe to shared audio player events (only for non-recording sources)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            if (!sourceUrl || useLocalAudio) return;
            const listener = {
                onTimeUpdate: {
                    "AudioWaveformPlayer.useEffect": (time)=>{
                        if (isActive && !isSeeking) {
                            currentTimeRef.current = time;
                        }
                    }
                }["AudioWaveformPlayer.useEffect"],
                onDurationChange: {
                    "AudioWaveformPlayer.useEffect": (dur_0)=>{
                        if (isActive) {
                            setLocalDuration(dur_0);
                        }
                    }
                }["AudioWaveformPlayer.useEffect"],
                onEnded: {
                    "AudioWaveformPlayer.useEffect": ()=>{
                        if (isActive) {
                            setLocalTime(0);
                            setLocalProgress(0);
                            currentTimeRef.current = 0;
                            displayTimeRef.current = 0;
                        }
                    }
                }["AudioWaveformPlayer.useEffect"],
                onCanPlay: {
                    "AudioWaveformPlayer.useEffect": ()=>{
                        if (isActive) {
                            setIsReady(true);
                        }
                    }
                }["AudioWaveformPlayer.useEffect"],
                onError: {
                    "AudioWaveformPlayer.useEffect": ()=>{
                        if (isActive) {
                            setIsReady(false);
                        }
                    }
                }["AudioWaveformPlayer.useEffect"]
            };
            return audioPlayer.subscribe(listener);
        }
    }["AudioWaveformPlayer.useEffect"], [
        sourceUrl,
        isActive,
        useLocalAudio,
        audioPlayer,
        isSeeking
    ]);
    // Continuous animation loop for smooth progress updates
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            // Don't update if we're seeking - let the slider control the state
            if (!isActive || !isPlaying || isSeeking) {
                return;
            }
            const audioElement = useLocalAudio ? localAudioRef.current : audioPlayer.audioElement;
            if (!audioElement) return;
            let rafId;
            let lastUpdate = 0;
            const UPDATE_INTERVAL = 33; // ~30fps — smooth enough for progress, halves re-renders
            const updateProgress = {
                "AudioWaveformPlayer.useEffect.updateProgress": (timestamp)=>{
                    // Throttle React state updates to reduce re-renders
                    if (timestamp - lastUpdate >= UPDATE_INTERVAL) {
                        lastUpdate = timestamp;
                        const time_0 = audioElement.currentTime;
                        // Always use durationRef (synced with localDuration) — same source
                        // as the time display. For recordings, this comes from decodeAudioData
                        // which is accurate, unlike audioElement.duration (Infinity for WebM).
                        const dur_1 = durationRef.current;
                        displayTimeRef.current = time_0;
                        currentTimeRef.current = time_0;
                        setLocalTime(time_0);
                        if (dur_1 > 0) {
                            const newProgress = Math.min(time_0 / dur_1 * 100, 100);
                            setLocalProgress(newProgress);
                        }
                    }
                    rafId = requestAnimationFrame(updateProgress);
                }
            }["AudioWaveformPlayer.useEffect.updateProgress"];
            rafId = requestAnimationFrame(updateProgress);
            return ({
                "AudioWaveformPlayer.useEffect": ()=>{
                    if (rafId) {
                        cancelAnimationFrame(rafId);
                    }
                }
            })["AudioWaveformPlayer.useEffect"];
        }
    }["AudioWaveformPlayer.useEffect"], [
        isActive,
        isPlaying,
        isSeeking,
        useLocalAudio
    ]);
    // Load source into shared audio context (only for non-recording sources)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            if (useLocalAudio) return; // Recording uses its own Audio element
            if (sourceUrl && loadedSourceRef.current !== sourceUrl) {
                loadedSourceRef.current = sourceUrl;
                setIsReady(false);
                audioPlayer.loadSource(sourceUrl);
            }
        }
    }["AudioWaveformPlayer.useEffect"], [
        sourceUrl,
        useLocalAudio,
        audioPlayer
    ]);
    const togglePlayPause = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioWaveformPlayer.useCallback[togglePlayPause]": async ()=>{
            // Normalize audioFilters to a Set
            const filtersSet = audioFilters instanceof Set ? audioFilters : Array.isArray(audioFilters) ? new Set(audioFilters) : new Set();
            // Use local audio for recording playback
            if (useLocalAudio && localAudioRef.current) {
                if (localIsPlaying) {
                    localAudioRef.current.pause();
                } else {
                    try {
                        await localAudioRef.current.play();
                    } catch (err_0) {
                        console.error("[AudioWaveformPlayer] Error playing recording:", err_0);
                    }
                }
                return;
            }
            if (!sourceUrl) return;
            // If filters are active, process through OfflineAudioContext
            if (filtersSet.size > 0) {
                const cacheKey_0 = `${sourceUrl}::${[
                    ...filtersSet
                ].sort().join(",")}`;
                let processedUrl = filteredBlobCacheRef.current.get(cacheKey_0);
                if (!processedUrl) {
                    try {
                        const response_0 = await fetch(sourceUrl);
                        const arrayBuffer_0 = await response_0.arrayBuffer();
                        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                        const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer_0);
                        audioCtx.close();
                        const processedBuffer = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$applyAudioFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyAudioFilters"])(audioBuffer, filtersSet);
                        const processedBlob = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$audioBufferToBlob$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["audioBufferToBlob"])(processedBuffer, "audio/wav");
                        processedUrl = URL.createObjectURL(processedBlob);
                        filteredBlobCacheRef.current.set(cacheKey_0, processedUrl);
                        setFilteredBlobUrl(processedUrl);
                    } catch (err_1) {
                        console.warn("[AudioWaveformPlayer] Filter processing failed, playing raw:", err_1);
                        // Fallback to raw playback
                        if (isPlaying) {
                            audioPlayer.pause();
                        } else {
                            await audioPlayer.play(sourceUrl);
                        }
                        return;
                    }
                }
                // Play the filtered version
                if (isPlaying) {
                    audioPlayer.pause();
                } else {
                    await audioPlayer.play(processedUrl);
                }
                return;
            }
            if (isPlaying) {
                audioPlayer.pause();
            } else {
                await audioPlayer.play(sourceUrl);
            }
        }
    }["AudioWaveformPlayer.useCallback[togglePlayPause]"], [
        sourceUrl,
        isPlaying,
        localIsPlaying,
        useLocalAudio,
        audioPlayer,
        audioFilters
    ]);
    const handleSliderChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioWaveformPlayer.useCallback[handleSliderChange]": (event, newValue)=>{
            // Mark that we're seeking to prevent animation loop from updating
            if (!isSeeking) {
                setIsSeeking(true);
            }
            // Update progress while dragging without seeking
            setLocalProgress(newValue);
            // Read duration from audio element, fall back to durationRef
            const audioElement_0 = useLocalAudio ? localAudioRef.current : audioPlayer.audioElement;
            const dur_2 = audioElement_0?.duration;
            const effectiveDuration = dur_2 && isFinite(dur_2) && dur_2 > 0 ? dur_2 : durationRef.current;
            const newTime = effectiveDuration > 0 ? newValue / 100 * effectiveDuration : 0;
            setLocalTime(newTime);
            displayTimeRef.current = newTime;
        }
    }["AudioWaveformPlayer.useCallback[handleSliderChange]"], [
        isSeeking,
        useLocalAudio,
        audioPlayer
    ]);
    const handleSeek = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioWaveformPlayer.useCallback[handleSeek]": (event_0, newValue_0)=>{
            // Prevent event propagation to other sliders
            event_0.stopPropagation();
            // Read duration from audio element, fall back to durationRef
            const audioElement_1 = useLocalAudio ? localAudioRef.current : audioPlayer.audioElement;
            const dur_3 = audioElement_1?.duration;
            const effectiveDuration_0 = dur_3 && isFinite(dur_3) && dur_3 > 0 ? dur_3 : durationRef.current;
            const newTime_0 = effectiveDuration_0 > 0 ? newValue_0 / 100 * effectiveDuration_0 : 0;
            if (useLocalAudio && localAudioRef.current && effectiveDuration_0 > 0) {
                localAudioRef.current.currentTime = newTime_0;
            } else if (isActive && effectiveDuration_0 > 0) {
                audioPlayer.seek(newTime_0);
            }
            setLocalProgress(newValue_0);
            setLocalTime(newTime_0);
            currentTimeRef.current = newTime_0;
            displayTimeRef.current = newTime_0;
            setIsSeeking(false);
        }
    }["AudioWaveformPlayer.useCallback[handleSeek]"], [
        isActive,
        useLocalAudio,
        audioPlayer
    ]);
    const formatTime = (seconds)=>{
        if (!seconds || isNaN(seconds)) return "0:00";
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, "0")}`;
    };
    // Stop mic preview helper
    const stopPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioWaveformPlayer.useCallback[stopPreview]": ()=>{
            if (previewRafRef.current) {
                cancelAnimationFrame(previewRafRef.current);
                previewRafRef.current = null;
            }
            if (previewAudioCtxRef.current) {
                previewAudioCtxRef.current.close();
                previewAudioCtxRef.current = null;
            }
            previewAnalyserRef.current = null;
            if (!recording) setActiveAnalyser(null);
            // Only stop tracks if we're not handing off to recording
            if (previewStreamRef.current && !recording) {
                previewStreamRef.current.getTracks().forEach({
                    "AudioWaveformPlayer.useCallback[stopPreview]": (track)=>track.stop()
                }["AudioWaveformPlayer.useCallback[stopPreview]"]);
                previewStreamRef.current = null;
            }
            setPreviewing(false);
        }
    }["AudioWaveformPlayer.useCallback[stopPreview]"], [
        recording
    ]);
    // Hover: start mic preview to show room noise
    const handleMouseEnter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioWaveformPlayer.useCallback[handleMouseEnter]": async ()=>{
            // Only preview when in recording mode with no content and not already active
            if (!enableRecording || recording || audioBlob || sourceUrl || computedWaveformData || file || previewing) return;
            // Guard: getUserMedia may not be available in headless/test environments
            if (!navigator.mediaDevices?.getUserMedia) return;
            try {
                const stream = await navigator.mediaDevices.getUserMedia({
                    audio: true
                });
                previewStreamRef.current = stream;
                const audioCtx_0 = new AudioContext();
                previewAudioCtxRef.current = audioCtx_0;
                const src = audioCtx_0.createMediaStreamSource(stream);
                const analyser = audioCtx_0.createAnalyser();
                analyser.fftSize = 2048;
                analyser.smoothingTimeConstant = 0.8;
                src.connect(analyser);
                previewAnalyserRef.current = analyser;
                setActiveAnalyser(analyser);
                setPreviewing(true);
            } catch (err_2) {
                console.warn("[AudioWaveformPlayer] Mic preview denied:", err_2);
            }
        }
    }["AudioWaveformPlayer.useCallback[handleMouseEnter]"], [
        enableRecording,
        recording,
        audioBlob,
        sourceUrl,
        computedWaveformData,
        file,
        previewing
    ]);
    const handleMouseLeave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioWaveformPlayer.useCallback[handleMouseLeave]": ()=>{
            if (recording || !previewing) return;
            stopPreview();
        }
    }["AudioWaveformPlayer.useCallback[handleMouseLeave]"], [
        recording,
        previewing,
        stopPreview
    ]);
    // Draw live mic preview on canvas
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            const canvas = recordingCanvasRef.current;
            const analyser_0 = previewAnalyserRef.current;
            if (!canvas || !previewing || !analyser_0 || recording) return;
            const canvasCtx = canvas.getContext("2d");
            const bufferLength = analyser_0.frequencyBinCount;
            const dataArray = new Uint8Array(bufferLength);
            let active = true;
            const drawPreview = {
                "AudioWaveformPlayer.useEffect.drawPreview": ()=>{
                    if (!active) return;
                    previewRafRef.current = requestAnimationFrame(drawPreview);
                    analyser_0.getByteFrequencyData(dataArray);
                    canvasCtx.fillStyle = canvasBg;
                    canvasCtx.fillRect(0, 0, canvas.width, canvas.height);
                    const targetSamples = canvas.width;
                    const barWidth = canvas.width / targetSamples;
                    const middle = canvas.height / 2;
                    const max = Math.max(...dataArray) || 1;
                    const binSize = Math.floor(bufferLength / targetSamples);
                    for(let i = 0; i < targetSamples; i++){
                        let sum = 0;
                        const start = i * binSize;
                        for(let j = start; j < start + binSize && j < bufferLength; j++){
                            sum += dataArray[j];
                        }
                        const amplitude = sum / binSize / max;
                        const barHeight = amplitude * middle;
                        const x = i * barWidth;
                        const intensity = Math.floor(amplitude * 155) + 100;
                        canvasCtx.fillStyle = `rgb(${intensity},${_g},${_b})`;
                        canvasCtx.fillRect(x, middle - barHeight, barWidth - 0.5, barHeight * 2);
                    }
                }
            }["AudioWaveformPlayer.useEffect.drawPreview"];
            drawPreview();
            return ({
                "AudioWaveformPlayer.useEffect": ()=>{
                    active = false;
                    if (previewRafRef.current) {
                        cancelAnimationFrame(previewRafRef.current);
                        previewRafRef.current = null;
                    }
                }
            })["AudioWaveformPlayer.useEffect"];
        }
    }["AudioWaveformPlayer.useEffect"], [
        previewing,
        recording,
        _g,
        _b
    ]);
    // Recording functions
    const startRecording = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioWaveformPlayer.useCallback[startRecording]": async ()=>{
            try {
                let stream_0;
                // Reuse preview stream if available, otherwise request new one
                if (previewStreamRef.current && previewStreamRef.current.active) {
                    stream_0 = previewStreamRef.current;
                    // Stop preview drawing but keep the stream
                    if (previewRafRef.current) {
                        cancelAnimationFrame(previewRafRef.current);
                        previewRafRef.current = null;
                    }
                    if (previewAudioCtxRef.current) {
                        previewAudioCtxRef.current.close();
                        previewAudioCtxRef.current = null;
                    }
                    previewAnalyserRef.current = null;
                    setPreviewing(false);
                } else {
                    stream_0 = await navigator.mediaDevices.getUserMedia({
                        audio: true
                    });
                }
                mediaStreamRef.current = stream_0;
                setPendingRecordingStart(true);
                setRecording(true);
            } catch (error) {
                console.error("[AudioWaveformPlayer] Error starting recording:", error);
            }
        }
    }["AudioWaveformPlayer.useCallback[startRecording]"], []);
    // Idle state: draw a flat center line (canvas looks "off")
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            const canvas_0 = recordingCanvasRef.current;
            if (!canvas_0 || recording || audioBlob || sourceUrl || computedWaveformData || file || previewing) {
                return;
            }
            if (!enableRecording) {
                return;
            }
            const canvasCtx_0 = canvas_0.getContext("2d");
            // Theme-aware background
            canvasCtx_0.fillStyle = canvasBg;
            canvasCtx_0.fillRect(0, 0, canvas_0.width, canvas_0.height);
            // Single flat line at center using theme color
            const middle_0 = canvas_0.height / 2;
            canvasCtx_0.fillStyle = `rgb(${_r}, ${_g}, ${_b})`;
            canvasCtx_0.fillRect(0, middle_0, canvas_0.width, 1);
        }
    }["AudioWaveformPlayer.useEffect"], [
        recording,
        audioBlob,
        sourceUrl,
        computedWaveformData,
        file,
        enableRecording,
        previewing,
        _r,
        _g,
        _b
    ]);
    // Effect to handle recording setup once canvas is available
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioWaveformPlayer.useEffect": ()=>{
            if (!pendingRecordingStart || !recording || !recordingCanvasRef.current || !mediaStreamRef.current) {
                return;
            }
            setPendingRecordingStart(false);
            const stream_1 = mediaStreamRef.current;
            const recorder = new MediaRecorder(stream_1);
            setMediaRecorder(recorder);
            recorder.start();
            const audioChunks = [];
            // Setup real-time waveform visualization
            const audioContext = new AudioContext();
            const source = audioContext.createMediaStreamSource(stream_1);
            const analyser_1 = audioContext.createAnalyser();
            source.connect(analyser_1);
            analyser_1.fftSize = 2048;
            analyser_1.smoothingTimeConstant = 0.8;
            setActiveAnalyser(analyser_1);
            const canvas_1 = recordingCanvasRef.current;
            const canvasCtx_1 = canvas_1.getContext("2d");
            const bufferLength_0 = analyser_1.frequencyBinCount;
            const dataArray_0 = new Uint8Array(bufferLength_0);
            // Track if we should keep drawing
            let isRecording = true;
            recorder.addEventListener("dataavailable", {
                "AudioWaveformPlayer.useEffect": (event_1)=>{
                    audioChunks.push(event_1.data);
                }
            }["AudioWaveformPlayer.useEffect"]);
            recorder.addEventListener("stop", {
                "AudioWaveformPlayer.useEffect": async ()=>{
                    isRecording = false;
                    setActiveAnalyser(null);
                    audioContext.close();
                    // Use the recorder's actual mimeType so decodeAudioData gets a valid container
                    const actualMimeType = recorder.mimeType || "audio/webm";
                    let blob = new Blob(audioChunks, {
                        type: actualMimeType
                    });
                    // Decode audio to get accurate duration (WebM blobs report Infinity via Audio element)
                    try {
                        const decodeCtx = new (window.AudioContext || window.webkitAudioContext)();
                        const arrayBuffer_1 = await blob.arrayBuffer();
                        const audioBuffer_0 = await decodeCtx.decodeAudioData(arrayBuffer_1);
                        const realDuration = audioBuffer_0.duration;
                        console.log("[AudioWaveformPlayer] Decoded duration:", realDuration);
                        if (isFinite(realDuration) && realDuration > 0) {
                            setLocalDuration(realDuration);
                        }
                        decodeCtx.close();
                        // Pre-submission cleanup: apply filters based on cleanupStrength setting
                        // Per-file settings override the user-level default (from RecordingStudio3)
                        // TTS recordings are already clean — skip for type==='tts' (checked by parent)
                        const effectiveStrength = file?.settings?.audioCleanupStrength || cleanupStrength;
                        if (enableRecording && effectiveStrength !== "off") {
                            try {
                                const cleanupFilters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$RecordingSettings$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCleanupFilters"])(effectiveStrength);
                                const processedBuffer_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$applyAudioFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyAudioFilters"])(audioBuffer_0, cleanupFilters);
                                const processedBlob_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$audioBufferToBlob$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["audioBufferToBlob"])(processedBuffer_0, "audio/wav");
                                blob = processedBlob_0;
                                console.log("[AudioWaveformPlayer] Pre-submission cleanup applied");
                            } catch (cleanupErr) {
                                console.warn("[AudioWaveformPlayer] Cleanup failed, using raw recording:", cleanupErr);
                            }
                        }
                    } catch (decodeErr) {
                        console.warn("[AudioWaveformPlayer] Duration decode failed:", decodeErr);
                    }
                    setAudioBlob(blob);
                    // Calculate waveform data (non-blocking — failures don't prevent upload/callback)
                    let waveform_0 = null;
                    try {
                        waveform_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calculateWaveformData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateWaveformData"])(blob, width);
                        setRecordedWaveformData(waveform_0);
                        console.log("[AudioWaveformPlayer] Calculated waveform for recording");
                    } catch (waveformError) {
                        console.warn("[AudioWaveformPlayer] Waveform calculation failed (continuing):", waveformError);
                    }
                    let savedFile = null;
                    let uploadResult = null;
                    // Upload if gradeId and nodeKey are provided
                    if (gradeId && nodeKey) {
                        try {
                            console.log("[AudioWaveformPlayer] Uploading recording...");
                            uploadResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$userSubmissionStorage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadStudentSubmission"])({
                                file: blob,
                                gradeId: gradeId,
                                nodeKey: nodeKey,
                                fileType: "mp3",
                                metadata: {
                                    ...metadata
                                }
                            });
                            console.log("[AudioWaveformPlayer] Upload successful:", uploadResult);
                            // Save file metadata using Gen2 client
                            const { getAmplifyClient } = await __turbopack_context__.A("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript, async loader)");
                            const { getCurrentUser } = await __turbopack_context__.A("[project]/node_modules/aws-amplify/dist/esm/auth/index.mjs [app-client] (ecmascript, async loader)");
                            const client = getAmplifyClient();
                            // Get current user for owner field
                            const { username: owner } = await getCurrentUser();
                            const { data: newFile, errors: fileErrors } = await client.models.File.create({
                                path: uploadResult.path,
                                owner,
                                identityId,
                                name: uploadResult.filename,
                                size: blob.size,
                                mimeType: actualMimeType,
                                level: "PRIVATE"
                            });
                            if (fileErrors?.length > 0 || !newFile) {
                                console.error("[AudioWaveformPlayer] Error creating File record:", fileErrors);
                            } else {
                                savedFile = newFile;
                                console.log("[AudioWaveformPlayer] Saved file metadata:", newFile);
                            }
                        } catch (uploadError) {
                            console.error("[AudioWaveformPlayer] Upload/save error (continuing):", uploadError);
                        }
                    }
                    // Always call onRecordingComplete so the story/UI gets feedback
                    if (onRecordingComplete) {
                        onRecordingComplete(savedFile || {
                            path: URL.createObjectURL(blob)
                        }, uploadResult);
                    }
                }
            }["AudioWaveformPlayer.useEffect"]);
            // Real-time waveform drawing - use local variable instead of state
            const draw = {
                "AudioWaveformPlayer.useEffect.draw": ()=>{
                    if (!isRecording) return;
                    requestAnimationFrame(draw);
                    analyser_1.getByteFrequencyData(dataArray_0);
                    canvasCtx_1.fillStyle = canvasBg;
                    canvasCtx_1.fillRect(0, 0, canvas_1.width, canvas_1.height);
                    // Match StaticWaveform: downsample analyser data to canvas.width bins,
                    // use barWidth - 0.5 actual width, symmetric drawing from center
                    const targetSamples_0 = canvas_1.width;
                    const barWidth_0 = canvas_1.width / targetSamples_0;
                    const middle_1 = canvas_1.height / 2;
                    // Prevent division by zero when analyser returns silence (all zeros)
                    const max_0 = Math.max(...dataArray_0) || 1;
                    // Downsample frequency data to targetSamples bins
                    const binSize_0 = Math.floor(bufferLength_0 / targetSamples_0);
                    for(let i_0 = 0; i_0 < targetSamples_0; i_0++){
                        // Average the frequency bins for this sample
                        let sum_0 = 0;
                        const start_0 = i_0 * binSize_0;
                        for(let j_0 = start_0; j_0 < start_0 + binSize_0 && j_0 < bufferLength_0; j_0++){
                            sum_0 += dataArray_0[j_0];
                        }
                        const amplitude_0 = sum_0 / binSize_0 / max_0;
                        const barHeight_0 = amplitude_0 * middle_1;
                        const x_0 = i_0 * barWidth_0;
                        // Match StaticWaveform color: intensity varies red channel
                        const intensity_0 = Math.floor(amplitude_0 * 155) + 100;
                        canvasCtx_1.fillStyle = `rgb(${intensity_0},${_g},${_b})`;
                        // Draw from middle outward (symmetric) - matches StaticWaveform exactly
                        canvasCtx_1.fillRect(x_0, middle_1 - barHeight_0, barWidth_0 - 0.5, barHeight_0 * 2);
                    }
                }
            }["AudioWaveformPlayer.useEffect.draw"];
            console.log("[AudioWaveformPlayer] Starting real-time waveform visualization");
            draw();
        }
    }["AudioWaveformPlayer.useEffect"], [
        pendingRecordingStart,
        recording,
        width,
        _g,
        _b,
        gradeId,
        nodeKey,
        metadata,
        identityId,
        onRecordingComplete
    ]);
    const stopRecording = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioWaveformPlayer.useCallback[stopRecording]": ()=>{
            if (mediaRecorder) {
                mediaRecorder.stop();
                mediaRecorder.stream.getTracks().forEach({
                    "AudioWaveformPlayer.useCallback[stopRecording]": (track_0)=>track_0.stop()
                }["AudioWaveformPlayer.useCallback[stopRecording]"]);
                setRecording(false);
                setMediaRecorder(null);
            }
            if (mediaStreamRef.current) {
                mediaStreamRef.current.getTracks().forEach({
                    "AudioWaveformPlayer.useCallback[stopRecording]": (track_1)=>track_1.stop()
                }["AudioWaveformPlayer.useCallback[stopRecording]"]);
                mediaStreamRef.current = null;
            }
            // Also clean up any leftover preview resources
            if (previewStreamRef.current) {
                previewStreamRef.current.getTracks().forEach({
                    "AudioWaveformPlayer.useCallback[stopRecording]": (track_2)=>track_2.stop()
                }["AudioWaveformPlayer.useCallback[stopRecording]"]);
                previewStreamRef.current = null;
            }
        }
    }["AudioWaveformPlayer.useCallback[stopRecording]"], [
        mediaRecorder
    ]);
    if (!sourceUrl && !file && !enableRecording) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                p: 2,
                textAlign: "center",
                color: "text.secondary"
            },
            children: t("audioWaveformPlayer.noAudioSource")
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
            lineNumber: 829,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        onMouseEnter: handleMouseEnter,
        onMouseLeave: handleMouseLeave,
        sx: {
            display: "flex",
            flexDirection: "column",
            gap: 1,
            p: 2,
            border: "1px solid",
            borderColor: "divider",
            borderRadius: 2,
            backgroundColor: "background.paper",
            width: "100%",
            maxWidth: "max-content"
        },
        children: [
            title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "subtitle2",
                color: "text.secondary",
                children: title
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                lineNumber: 850,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    position: "relative",
                    borderRadius: 1,
                    width: "100%"
                },
                children: [
                    !recording && (computedWaveformData || file) && !audioBlob && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            position: "relative",
                            width: `${width}px`,
                            height: `${height}px`
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$StaticWaveform$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                file: file,
                                waveformData: computedWaveformData,
                                width: width,
                                height: height,
                                showLoading: false
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                lineNumber: 866,
                                columnNumber: 13
                            }, this),
                            localDuration > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-testid": "waveform-overlay",
                                style: {
                                    position: "absolute",
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0,
                                    backgroundColor: "var(--mui-palette-primary-main)",
                                    opacity: 0.2,
                                    pointerEvents: "none",
                                    transformOrigin: "left",
                                    transform: `scaleX(${Math.min(localProgress / 100, 1)})`,
                                    willChange: "transform"
                                },
                                children: "\u200B"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                lineNumber: 870,
                                columnNumber: 35
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                        lineNumber: 861,
                        columnNumber: 72
                    }, this),
                    enableRecording && !computedWaveformData && !file && !audioBlob && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                        ref: recordingCanvasRef,
                        width: width,
                        height: height,
                        style: {
                            backgroundColor: "var(--mui-palette-background-paper)",
                            border: "1px solid var(--mui-palette-divider, #e0e0e0)",
                            borderRadius: "4px",
                            width: `${width}px`,
                            height: `${height}px`,
                            display: "block",
                            boxSizing: "border-box"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                        lineNumber: 888,
                        columnNumber: 77
                    }, this),
                    audioBlob && recordedWaveformData && !recording && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            position: "relative",
                            width: `${width}px`,
                            height: `${height}px`
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$StaticWaveform$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                waveformData: recordedWaveformData,
                                width: width,
                                height: height,
                                showLoading: false
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                lineNumber: 904,
                                columnNumber: 13
                            }, this),
                            localDuration > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-testid": "waveform-overlay",
                                style: {
                                    position: "absolute",
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0,
                                    backgroundColor: "var(--mui-palette-primary-main)",
                                    opacity: 0.2,
                                    pointerEvents: "none",
                                    transformOrigin: "left",
                                    transform: `scaleX(${Math.min(localProgress / 100, 1)})`,
                                    willChange: "transform"
                                },
                                children: "\u200B"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                lineNumber: 907,
                                columnNumber: 35
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                        lineNumber: 899,
                        columnNumber: 61
                    }, this),
                    audioBlob && !recordedWaveformData && !recording && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                        ref: recordingCanvasRef,
                        width: width,
                        height: height,
                        style: {
                            backgroundColor: "var(--mui-palette-background-paper)",
                            border: "1px solid var(--mui-palette-divider, #e0e0e0)",
                            borderRadius: "4px",
                            width: `${width}px`,
                            height: `${height}px`,
                            display: "block",
                            boxSizing: "border-box"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                        lineNumber: 925,
                        columnNumber: 62
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                lineNumber: 855,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    alignItems: "center",
                    gap: 2,
                    minHeight: 40
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            minWidth: 40,
                            display: "flex",
                            justifyContent: "center"
                        },
                        children: [
                            enableRecording && !audioBlob && !sourceUrl && !recording && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                onClick: startRecording,
                                color: "primary",
                                size: "small",
                                title: "Start recording",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$KeyboardVoice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                    lineNumber: 950,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                lineNumber: 949,
                                columnNumber: 73
                            }, this),
                            recording && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                onClick: stopRecording,
                                color: "error",
                                size: "small",
                                title: "Stop recording",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Stop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                    lineNumber: 954,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                lineNumber: 953,
                                columnNumber: 25
                            }, this),
                            (sourceUrl || audioBlob) && !recording && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                onClick: togglePlayPause,
                                color: "primary",
                                disabled: !sourceUrl && !audioBlob,
                                size: "small",
                                children: isPlaying ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Pause$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                    lineNumber: 959,
                                    columnNumber: 28
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PlayArrow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                    lineNumber: 959,
                                    columnNumber: 44
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                lineNumber: 958,
                                columnNumber: 54
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                        lineNumber: 944,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            flexGrow: 1,
                            display: "flex",
                            alignItems: "center",
                            minHeight: 20
                        },
                        children: [
                            !recording && (sourceUrl || audioBlob) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Slider$3e$__["Slider"], {
                                value: isNaN(localProgress) || !isFinite(localProgress) ? 0 : localProgress,
                                min: 0,
                                max: 100,
                                step: 0.1,
                                onChange: handleSliderChange,
                                onChangeCommitted: handleSeek,
                                "aria-label": tEditor("answerComponent.inputMethods.audio"),
                                disabled: false,
                                track: "normal",
                                size: "small",
                                sx: {
                                    width: "100%",
                                    // Disable CSS transitions during playback so the thumb
                                    // tracks the RAF-driven value instantly instead of lagging
                                    ...!isSeeking && isPlaying ? {
                                        "& .MuiSlider-thumb": {
                                            transition: "none"
                                        },
                                        "& .MuiSlider-track": {
                                            transition: "none"
                                        }
                                    } : {}
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                lineNumber: 970,
                                columnNumber: 54
                            }, this),
                            recording && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    flexDirection: "column",
                                    gap: 0.5,
                                    flexGrow: 1
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "caption",
                                        color: "error",
                                        sx: {
                                            fontWeight: "bold"
                                        },
                                        children: "● Recording..."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                        lineNumber: 990,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$MicLevelIndicator$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        analyser: activeAnalyser
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                        lineNumber: 995,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                lineNumber: 984,
                                columnNumber: 25
                            }, this),
                            !recording && !sourceUrl && !audioBlob && previewing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$MicLevelIndicator$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                analyser: activeAnalyser
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                lineNumber: 999,
                                columnNumber: 68
                            }, this),
                            !recording && !sourceUrl && !audioBlob && !previewing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    width: "100%"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                                lineNumber: 1002,
                                columnNumber: 69
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                        lineNumber: 964,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            minWidth: 80,
                            textAlign: "right"
                        },
                        children: showDuration && !recording && (sourceUrl || audioBlob) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "caption",
                            color: "text.secondary",
                            children: [
                                formatTime(localTime),
                                " / ",
                                formatTime(localDuration)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                            lineNumber: 1012,
                            columnNumber: 70
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                        lineNumber: 1008,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
                lineNumber: 937,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx",
        lineNumber: 837,
        columnNumber: 10
    }, this);
}
_s(AudioWaveformPlayer, "ZenuYTuKpNNz3Ed7REymoed4e6U=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$AudioPlayerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAudioPlayer"]
    ];
});
_c = AudioWaveformPlayer;
var _c;
__turbopack_context__.k.register(_c, "AudioWaveformPlayer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/FileThumbnail.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AudioFile$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AudioFile.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PictureAsPdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PictureAsPdf.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Article$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Article.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Description.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TheaterComedy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TheaterComedy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
/**
 * FileThumbnail — Displays a file's thumbnail image from S3 if available,
 * falling back to a Material icon based on file type.
 *
 * Thumbnails are generated server-side by the imageProcess Lambda and stored at:
 *   protected/{identityId}/{fileId}/thumbnail.webp
 *
 * The File.thumbnail field contains the S3 path once processing is complete.
 */ const FileThumbnail = /*#__PURE__*/ _s(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(_c = _s(function FileThumbnail(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(26);
    if ($[0] !== "27d322cfdff7b8a0c38e66d75900f1cd669e82f5797a5921d681cbb706b53716") {
        for(let $i = 0; $i < 26; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "27d322cfdff7b8a0c38e66d75900f1cd669e82f5797a5921d681cbb706b53716";
    }
    const { file, fileType, size: t1, isSelected: t2 } = t0;
    const size = t1 === undefined ? 32 : t1;
    const isSelected = t2 === undefined ? false : t2;
    const [thumbnailUrl, setThumbnailUrl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [loadFailed, setLoadFailed] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [isLoading, setIsLoading] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    let t3;
    let t4;
    if ($[1] !== file.thumbnail) {
        t3 = ({
            "FileThumbnail[useEffect()]": ()=>{
                let cancelled = false;
                if (!file.thumbnail) {
                    setThumbnailUrl(null);
                    setLoadFailed(false);
                    setIsLoading(false);
                    return;
                }
                setIsLoading(true);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(file.thumbnail).then({
                    "FileThumbnail[useEffect() > (anonymous)()]": (url)=>{
                        if (!cancelled) {
                            setThumbnailUrl(url);
                            setIsLoading(false);
                        }
                    }
                }["FileThumbnail[useEffect() > (anonymous)()]"]).catch({
                    "FileThumbnail[useEffect() > (anonymous)()]": ()=>{
                        if (!cancelled) {
                            setLoadFailed(true);
                            setIsLoading(false);
                        }
                    }
                }["FileThumbnail[useEffect() > (anonymous)()]"]);
                return ()=>{
                    cancelled = true;
                };
            }
        })["FileThumbnail[useEffect()]"];
        t4 = [
            file.thumbnail
        ];
        $[1] = file.thumbnail;
        $[2] = t3;
        $[3] = t4;
    } else {
        t3 = $[2];
        t4 = $[3];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t3, t4);
    if (thumbnailUrl && !loadFailed) {
        let t5;
        if ($[4] !== size) {
            t5 = {
                width: size,
                height: size,
                borderRadius: 0.5,
                overflow: "hidden",
                flexShrink: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                bgcolor: "action.hover"
            };
            $[4] = size;
            $[5] = t5;
        } else {
            t5 = $[5];
        }
        const t6 = file.name || "";
        let t7;
        let t8;
        if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = ({
                "FileThumbnail[<img>.onError]": ()=>setLoadFailed(true)
            })["FileThumbnail[<img>.onError]"];
            t8 = {
                width: "100%",
                height: "100%",
                objectFit: "cover"
            };
            $[6] = t7;
            $[7] = t8;
        } else {
            t7 = $[6];
            t8 = $[7];
        }
        let t9;
        if ($[8] !== t6 || $[9] !== thumbnailUrl) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: thumbnailUrl,
                alt: t6,
                loading: "lazy",
                onError: t7,
                style: t8
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileThumbnail.jsx",
                lineNumber: 121,
                columnNumber: 12
            }, this);
            $[8] = t6;
            $[9] = thumbnailUrl;
            $[10] = t9;
        } else {
            t9 = $[10];
        }
        let t10;
        if ($[11] !== t5 || $[12] !== t9) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t5,
                children: t9
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileThumbnail.jsx",
                lineNumber: 130,
                columnNumber: 13
            }, this);
            $[11] = t5;
            $[12] = t9;
            $[13] = t10;
        } else {
            t10 = $[13];
        }
        return t10;
    }
    if (isLoading) {
        let t5;
        if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = {
                flexShrink: 0
            };
            $[14] = t5;
        } else {
            t5 = $[14];
        }
        let t6;
        if ($[15] !== size) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                variant: "rounded",
                width: size,
                height: size,
                sx: t5
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileThumbnail.jsx",
                lineNumber: 151,
                columnNumber: 12
            }, this);
            $[15] = size;
            $[16] = t6;
        } else {
            t6 = $[16];
        }
        return t6;
    }
    const t5 = size * 0.75;
    const t6 = isSelected ? "primary.main" : "inherit";
    let t7;
    if ($[17] !== fileType || $[18] !== t5 || $[19] !== t6) {
        const iconSx = {
            fontSize: t5,
            color: t6,
            transition: "color 0.2s"
        };
        t7 = getIconForFileType(fileType, iconSx);
        $[17] = fileType;
        $[18] = t5;
        $[19] = t6;
        $[20] = t7;
    } else {
        t7 = $[20];
    }
    const icon = t7;
    let t8;
    if ($[21] !== size) {
        t8 = {
            width: size,
            height: size,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0
        };
        $[21] = size;
        $[22] = t8;
    } else {
        t8 = $[22];
    }
    let t9;
    if ($[23] !== icon || $[24] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t8,
            children: icon
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileThumbnail.jsx",
            lineNumber: 194,
            columnNumber: 10
        }, this);
        $[23] = icon;
        $[24] = t8;
        $[25] = t9;
    } else {
        t9 = $[25];
    }
    return t9;
}, "x+PsgReARDeuk9w/oauyobx140Q=")), "x+PsgReARDeuk9w/oauyobx140Q=");
_c1 = FileThumbnail;
function getIconForFileType(fileType, sx) {
    switch(fileType){
        case "images":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: sx
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileThumbnail.jsx",
                lineNumber: 206,
                columnNumber: 14
            }, this);
        case "audio":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AudioFile$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: sx
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileThumbnail.jsx",
                lineNumber: 208,
                columnNumber: 14
            }, this);
        case "documents":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PictureAsPdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: sx
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileThumbnail.jsx",
                lineNumber: 210,
                columnNumber: 14
            }, this);
        case "video":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Article$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: sx
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileThumbnail.jsx",
                lineNumber: 212,
                columnNumber: 14
            }, this);
        case "scripts":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TheaterComedy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: sx
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileThumbnail.jsx",
                lineNumber: 214,
                columnNumber: 14
            }, this);
        default:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: sx
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileThumbnail.jsx",
                lineNumber: 216,
                columnNumber: 14
            }, this);
    }
}
const __TURBOPACK__default__export__ = FileThumbnail;
var _c, _c1;
__turbopack_context__.k.register(_c, "FileThumbnail$React.memo");
__turbopack_context__.k.register(_c1, "FileThumbnail");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>UnifiedGenerateModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Edit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Refresh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Refresh.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
function UnifiedGenerateModal(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(75);
    if ($[0] !== "f166d83ea0a3c20306956e6b93f7b796d18d4c18f9a522cb7b8fbd52c79f182e") {
        for(let $i = 0; $i < 75; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f166d83ea0a3c20306956e6b93f7b796d18d4c18f9a522cb7b8fbd52c79f182e";
    }
    const { open, onClose, onGenerate, onRegenerate, title: t1, inputPlaceholder: t2, type: t3, children } = t0;
    const title = t1 === undefined ? "Generate Content" : t1;
    const inputPlaceholder = t2 === undefined ? "Enter description..." : t2;
    const type = t3 === undefined ? "image" : t3;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.ai");
    const [mode, setMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("input");
    const [prompt, setPrompt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [generatedContent, setGeneratedContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t4;
    if ($[1] !== onGenerate || $[2] !== prompt) {
        t4 = ({
            "UnifiedGenerateModal[handleGenerate]": async ()=>{
                if (!prompt.trim()) {
                    setError("Please enter a description");
                    return;
                }
                setMode("generating");
                setError(null);
                ;
                try {
                    const result = await onGenerate(prompt);
                    setGeneratedContent(result);
                    setMode("preview");
                } catch (t5) {
                    const err = t5;
                    console.error("Generation error:", err);
                    setError(err.message || "Failed to generate content");
                    setMode("input");
                }
            }
        })["UnifiedGenerateModal[handleGenerate]"];
        $[1] = onGenerate;
        $[2] = prompt;
        $[3] = t4;
    } else {
        t4 = $[3];
    }
    const handleGenerate = t4;
    let t5;
    if ($[4] !== generatedContent || $[5] !== onRegenerate || $[6] !== prompt) {
        t5 = ({
            "UnifiedGenerateModal[handleRegenerate]": async (t6)=>{
                const maskData = t6 === undefined ? null : t6;
                setMode("generating");
                setError(null);
                ;
                try {
                    const result_0 = await onRegenerate(prompt, generatedContent, maskData);
                    setGeneratedContent(result_0);
                    setMode("preview");
                } catch (t7) {
                    const err_0 = t7;
                    console.error("Regeneration error:", err_0);
                    setError(err_0.message || "Failed to regenerate content");
                    setMode("preview");
                }
            }
        })["UnifiedGenerateModal[handleRegenerate]"];
        $[4] = generatedContent;
        $[5] = onRegenerate;
        $[6] = prompt;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    const handleRegenerate = t5;
    let t6;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "UnifiedGenerateModal[handleEditPrompt]": ()=>{
                setMode("input");
            }
        })["UnifiedGenerateModal[handleEditPrompt]"];
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    const handleEditPrompt = t6;
    let handleClose;
    let handleConfirmCancel;
    let resetAndClose;
    let t7;
    if ($[9] !== mode || $[10] !== onClose) {
        handleClose = ({
            "UnifiedGenerateModal[handleClose]": ()=>{
                if (mode === "preview" || mode === "generating") {
                    setMode("confirming-cancel");
                } else {
                    if (mode === "confirming-cancel") {
                        setMode("preview");
                    } else {
                        resetAndClose();
                    }
                }
            }
        })["UnifiedGenerateModal[handleClose]"];
        handleConfirmCancel = ({
            "UnifiedGenerateModal[handleConfirmCancel]": ()=>{
                resetAndClose();
            }
        })["UnifiedGenerateModal[handleConfirmCancel]"];
        resetAndClose = ({
            "UnifiedGenerateModal[resetAndClose]": ()=>{
                setMode("input");
                setPrompt("");
                setGeneratedContent(null);
                setError(null);
                onClose();
            }
        })["UnifiedGenerateModal[resetAndClose]"];
        t7 = ({
            "UnifiedGenerateModal[handleSave]": ()=>{
                resetAndClose();
            }
        })["UnifiedGenerateModal[handleSave]"];
        $[9] = mode;
        $[10] = onClose;
        $[11] = handleClose;
        $[12] = handleConfirmCancel;
        $[13] = resetAndClose;
        $[14] = t7;
    } else {
        handleClose = $[11];
        handleConfirmCancel = $[12];
        resetAndClose = $[13];
        t7 = $[14];
    }
    const handleSave = t7;
    const t8 = mode === "generating";
    let t9;
    if ($[15] !== title) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h6",
            children: title
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
            lineNumber: 165,
            columnNumber: 10
        }, this);
        $[15] = title;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    const t10 = mode === "generating";
    let t11;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
            lineNumber: 174,
            columnNumber: 11
        }, this);
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    if ($[18] !== handleClose || $[19] !== t10) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            onClick: handleClose,
            disabled: t10,
            size: "small",
            children: t11
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
            lineNumber: 181,
            columnNumber: 11
        }, this);
        $[18] = handleClose;
        $[19] = t10;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] !== t12 || $[22] !== t9) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                children: [
                    t9,
                    t12
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                lineNumber: 190,
                columnNumber: 24
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
            lineNumber: 190,
            columnNumber: 11
        }, this);
        $[21] = t12;
        $[22] = t9;
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    let t14;
    if ($[24] !== children || $[25] !== error || $[26] !== inputPlaceholder || $[27] !== mode || $[28] !== prompt) {
        t14 = mode === "input" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                    fullWidth: true,
                    multiline: true,
                    rows: 4,
                    value: prompt,
                    onChange: {
                        "UnifiedGenerateModal[<TextField>.onChange]": (e)=>setPrompt(e.target.value)
                    }["UnifiedGenerateModal[<TextField>.onChange]"],
                    placeholder: inputPlaceholder,
                    variant: "outlined",
                    error: !!error,
                    helperText: error,
                    autoFocus: true,
                    sx: {
                        mb: 2
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 199,
                    columnNumber: 36
                }, this),
                children
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
            lineNumber: 199,
            columnNumber: 31
        }, this);
        $[24] = children;
        $[25] = error;
        $[26] = inputPlaceholder;
        $[27] = mode;
        $[28] = prompt;
        $[29] = t14;
    } else {
        t14 = $[29];
    }
    let t15;
    if ($[30] !== mode) {
        t15 = mode === "generating" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            minHeight: "200px",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                    variant: "circular",
                    width: 60,
                    height: 60,
                    sx: {
                        mb: 2
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 215,
                    columnNumber: 141
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                    variant: "text",
                    width: 200,
                    height: 24
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 217,
                    columnNumber: 12
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                    variant: "text",
                    width: 160,
                    height: 16,
                    sx: {
                        mt: 1
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 217,
                    columnNumber: 63
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
            lineNumber: 215,
            columnNumber: 36
        }, this);
        $[30] = mode;
        $[31] = t15;
    } else {
        t15 = $[31];
    }
    let t16;
    if ($[32] !== generatedContent || $[33] !== handleRegenerate || $[34] !== mode || $[35] !== onRegenerate || $[36] !== prompt || $[37] !== t) {
        t16 = mode === "preview" && generatedContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    mb: 2,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "subtitle2",
                            color: "text.secondary",
                            children: t("unifiedGenerateModal.preview")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                            lineNumber: 227,
                            columnNumber: 136
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "small",
                                    onClick: handleEditPrompt,
                                    title: "Edit prompt",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                                        lineNumber: 227,
                                        columnNumber: 316
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                                    lineNumber: 227,
                                    columnNumber: 244
                                }, this),
                                onRegenerate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "small",
                                    onClick: {
                                        "UnifiedGenerateModal[<IconButton>.onClick]": ()=>handleRegenerate()
                                    }["UnifiedGenerateModal[<IconButton>.onClick]"],
                                    title: "Regenerate",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Refresh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                                        lineNumber: 229,
                                        columnNumber: 79
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                                    lineNumber: 227,
                                    columnNumber: 358
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                            lineNumber: 227,
                            columnNumber: 239
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 227,
                    columnNumber: 58
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "body2",
                    sx: {
                        mb: 2,
                        p: 1,
                        bgcolor: "action.hover",
                        borderRadius: 1,
                        fontStyle: "italic"
                    },
                    children: [
                        '"',
                        prompt,
                        '"'
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 229,
                    columnNumber: 120
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        border: 1,
                        borderColor: "divider",
                        borderRadius: 1,
                        overflow: "hidden"
                    },
                    children: generatedContent.preview
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 235,
                    columnNumber: 33
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
            lineNumber: 227,
            columnNumber: 53
        }, this);
        $[32] = generatedContent;
        $[33] = handleRegenerate;
        $[34] = mode;
        $[35] = onRegenerate;
        $[36] = prompt;
        $[37] = t;
        $[38] = t16;
    } else {
        t16 = $[38];
    }
    let t17;
    if ($[39] !== mode || $[40] !== t || $[41] !== type) {
        t17 = mode === "confirming-cancel" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            textAlign: "center",
            py: 3,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "h6",
                    gutterBottom: true,
                    children: t("unifiedGenerateModal.discardChanges")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 253,
                    columnNumber: 74
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "body2",
                    color: "text.secondary",
                    children: t("unifiedGenerateModal.lostWarning", {
                        type
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 253,
                    columnNumber: 174
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
            lineNumber: 253,
            columnNumber: 43
        }, this);
        $[39] = mode;
        $[40] = t;
        $[41] = type;
        $[42] = t17;
    } else {
        t17 = $[42];
    }
    let t18;
    if ($[43] !== t14 || $[44] !== t15 || $[45] !== t16 || $[46] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
            children: [
                t14,
                t15,
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
            lineNumber: 265,
            columnNumber: 11
        }, this);
        $[43] = t14;
        $[44] = t15;
        $[45] = t16;
        $[46] = t17;
        $[47] = t18;
    } else {
        t18 = $[47];
    }
    let t19;
    if ($[48] !== handleGenerate || $[49] !== mode || $[50] !== prompt || $[51] !== resetAndClose || $[52] !== t) {
        t19 = mode === "input" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    onClick: resetAndClose,
                    color: "inherit",
                    children: t("unifiedGenerateModal.cancel")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 276,
                    columnNumber: 33
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    onClick: handleGenerate,
                    variant: "contained",
                    disabled: !prompt.trim(),
                    children: t("unifiedGenerateModal.generate")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 276,
                    columnNumber: 124
                }, this)
            ]
        }, void 0, true);
        $[48] = handleGenerate;
        $[49] = mode;
        $[50] = prompt;
        $[51] = resetAndClose;
        $[52] = t;
        $[53] = t19;
    } else {
        t19 = $[53];
    }
    const t20 = mode === "generating" && null;
    let t21;
    if ($[54] !== handleClose || $[55] !== handleSave || $[56] !== mode || $[57] !== t) {
        t21 = mode === "preview" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    onClick: handleClose,
                    color: "inherit",
                    children: t("unifiedGenerateModal.cancel")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 289,
                    columnNumber: 35
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    onClick: handleSave,
                    variant: "contained",
                    children: t("unifiedGenerateModal.saveClose")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 289,
                    columnNumber: 124
                }, this)
            ]
        }, void 0, true);
        $[54] = handleClose;
        $[55] = handleSave;
        $[56] = mode;
        $[57] = t;
        $[58] = t21;
    } else {
        t21 = $[58];
    }
    let t22;
    if ($[59] !== handleConfirmCancel || $[60] !== mode || $[61] !== t) {
        t22 = mode === "confirming-cancel" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    onClick: {
                        "UnifiedGenerateModal[<Button>.onClick]": ()=>setMode("preview")
                    }["UnifiedGenerateModal[<Button>.onClick]"],
                    color: "inherit",
                    children: t("unifiedGenerateModal.keepEditing")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 300,
                    columnNumber: 45
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    onClick: handleConfirmCancel,
                    color: "error",
                    variant: "contained",
                    children: t("unifiedGenerateModal.discard")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
                    lineNumber: 302,
                    columnNumber: 116
                }, this)
            ]
        }, void 0, true);
        $[59] = handleConfirmCancel;
        $[60] = mode;
        $[61] = t;
        $[62] = t22;
    } else {
        t22 = $[62];
    }
    let t23;
    if ($[63] !== t19 || $[64] !== t20 || $[65] !== t21 || $[66] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
            children: [
                t19,
                t20,
                t21,
                t22
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
            lineNumber: 312,
            columnNumber: 11
        }, this);
        $[63] = t19;
        $[64] = t20;
        $[65] = t21;
        $[66] = t22;
        $[67] = t23;
    } else {
        t23 = $[67];
    }
    let t24;
    if ($[68] !== handleClose || $[69] !== open || $[70] !== t13 || $[71] !== t18 || $[72] !== t23 || $[73] !== t8) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
            open: open,
            onClose: handleClose,
            maxWidth: "md",
            fullWidth: true,
            disableEscapeKeyDown: t8,
            children: [
                t13,
                t18,
                t23
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx",
            lineNumber: 323,
            columnNumber: 11
        }, this);
        $[68] = handleClose;
        $[69] = open;
        $[70] = t13;
        $[71] = t18;
        $[72] = t23;
        $[73] = t8;
        $[74] = t24;
    } else {
        t24 = $[74];
    }
    return t24;
}
_s(UnifiedGenerateModal, "MZtWpz6GwLNCFO6G+6Pkf/Zfvkk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = UnifiedGenerateModal;
var _c;
__turbopack_context__.k.register(_c, "UnifiedGenerateModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/ImageMaskEditor.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ImageMaskEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Toolbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Toolbar/Toolbar.js [app-client] (ecmascript) <export default as Toolbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Slider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Slider/Slider.js [app-client] (ecmascript) <export default as Slider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButtonGroup$2f$ToggleButtonGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButtonGroup$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ToggleButtonGroup/ToggleButtonGroup.js [app-client] (ecmascript) <export default as ToggleButtonGroup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ToggleButton/ToggleButton.js [app-client] (ecmascript) <export default as ToggleButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Brush$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Brush.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Undo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Undo.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Redo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Redo.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Clear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Clear.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ZoomIn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ZoomIn.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ZoomOut$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ZoomOut.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
function ImageMaskEditor({ imageUrl, onMaskComplete, onCancel, width = 800, height = 600 }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('editor.shared');
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const maskCanvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isDrawing, setIsDrawing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [brushSize, setBrushSize] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(20);
    const [tool, setTool] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('brush'); // 'brush' or 'eraser'
    const [history, setHistory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [historyIndex, setHistoryIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const [zoom, setZoom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [panOffset, setPanOffset] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    });
    const [isPanning, setIsPanning] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [lastPanPoint, setLastPanPoint] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ImageMaskEditor.useEffect": ()=>{
            const canvas = canvasRef.current;
            const maskCanvas = maskCanvasRef.current;
            if (!canvas || !maskCanvas || !imageUrl) return;
            const ctx = canvas.getContext('2d');
            const maskCtx = maskCanvas.getContext('2d');
            // Load and draw the image
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = ({
                "ImageMaskEditor.useEffect": ()=>{
                    canvas.width = img.width;
                    canvas.height = img.height;
                    maskCanvas.width = img.width;
                    maskCanvas.height = img.height;
                    ctx.drawImage(img, 0, 0);
                    // Initialize mask canvas with transparent background
                    maskCtx.clearRect(0, 0, maskCanvas.width, maskCanvas.height);
                    // Save initial state
                    saveToHistory();
                }
            })["ImageMaskEditor.useEffect"];
            img.src = imageUrl;
        }
    }["ImageMaskEditor.useEffect"], [
        imageUrl
    ]);
    const saveToHistory = ()=>{
        const maskCanvas_0 = maskCanvasRef.current;
        if (!maskCanvas_0) return;
        const imageData = maskCanvas_0.toDataURL();
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(imageData);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
    };
    const undo = ()=>{
        if (historyIndex <= 0) return;
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        const maskCanvas_1 = maskCanvasRef.current;
        const maskCtx_0 = maskCanvas_1.getContext('2d');
        const img_0 = new Image();
        img_0.onload = ()=>{
            maskCtx_0.clearRect(0, 0, maskCanvas_1.width, maskCanvas_1.height);
            maskCtx_0.drawImage(img_0, 0, 0);
        };
        img_0.src = history[newIndex];
    };
    const redo = ()=>{
        if (historyIndex >= history.length - 1) return;
        const newIndex_0 = historyIndex + 1;
        setHistoryIndex(newIndex_0);
        const maskCanvas_2 = maskCanvasRef.current;
        const maskCtx_1 = maskCanvas_2.getContext('2d');
        const img_1 = new Image();
        img_1.onload = ()=>{
            maskCtx_1.clearRect(0, 0, maskCanvas_2.width, maskCanvas_2.height);
            maskCtx_1.drawImage(img_1, 0, 0);
        };
        img_1.src = history[newIndex_0];
    };
    const clearMask = ()=>{
        const maskCanvas_3 = maskCanvasRef.current;
        const maskCtx_2 = maskCanvas_3.getContext('2d');
        maskCtx_2.clearRect(0, 0, maskCanvas_3.width, maskCanvas_3.height);
        saveToHistory();
    };
    const getCanvasPoint = (e)=>{
        const canvas_0 = maskCanvasRef.current;
        const rect = canvas_0.getBoundingClientRect();
        // Account for zoom and pan
        const x = (e.clientX - rect.left - panOffset.x) / zoom;
        const y = (e.clientY - rect.top - panOffset.y) / zoom;
        return {
            x,
            y
        };
    };
    const startDrawing = (e_0)=>{
        if (e_0.shiftKey) {
            // Shift key for panning
            setIsPanning(true);
            setLastPanPoint({
                x: e_0.clientX,
                y: e_0.clientY
            });
            return;
        }
        setIsDrawing(true);
        const point = getCanvasPoint(e_0);
        draw(point.x, point.y, false);
    };
    const stopDrawing = ()=>{
        if (isDrawing) {
            setIsDrawing(false);
            saveToHistory();
        }
        setIsPanning(false);
    };
    const handleMouseMove = (e_1)=>{
        if (isPanning) {
            const dx = e_1.clientX - lastPanPoint.x;
            const dy = e_1.clientY - lastPanPoint.y;
            setPanOffset({
                x: panOffset.x + dx,
                y: panOffset.y + dy
            });
            setLastPanPoint({
                x: e_1.clientX,
                y: e_1.clientY
            });
            return;
        }
        if (!isDrawing) return;
        const point_0 = getCanvasPoint(e_1);
        draw(point_0.x, point_0.y, true);
    };
    const draw = (x_0, y_0, continuous)=>{
        const maskCanvas_4 = maskCanvasRef.current;
        const maskCtx_3 = maskCanvas_4.getContext('2d');
        maskCtx_3.globalCompositeOperation = tool === 'brush' ? 'source-over' : 'destination-out';
        maskCtx_3.fillStyle = 'rgba(255, 0, 0, 0.5)'; // Semi-transparent red for mask
        if (continuous) {
            maskCtx_3.lineTo(x_0, y_0);
            maskCtx_3.stroke();
        } else {
            maskCtx_3.beginPath();
            maskCtx_3.arc(x_0, y_0, brushSize / 2, 0, Math.PI * 2);
            maskCtx_3.fill();
            maskCtx_3.beginPath();
            maskCtx_3.moveTo(x_0, y_0);
            maskCtx_3.lineWidth = brushSize;
            maskCtx_3.lineCap = 'round';
            maskCtx_3.lineJoin = 'round';
        }
    };
    const handleZoomIn = ()=>{
        setZoom(Math.min(zoom * 1.2, 5));
    };
    const handleZoomOut = ()=>{
        setZoom(Math.max(zoom / 1.2, 0.2));
    };
    const handleComplete = ()=>{
        const maskCanvas_5 = maskCanvasRef.current;
        // Convert mask to image data
        const maskData = maskCanvas_5.toDataURL('image/png');
        // Also provide the original canvas for context
        const imageCanvas = canvasRef.current;
        const imageData_0 = imageCanvas.toDataURL('image/png');
        onMaskComplete({
            mask: maskData,
            image: imageData_0
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            width: '100%',
            height: '100%',
            display: 'flex',
            flexDirection: 'column'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Toolbar$3e$__["Toolbar"], {
                sx: {
                    gap: 2,
                    flexWrap: 'wrap',
                    bgcolor: 'background.paper'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButtonGroup$2f$ToggleButtonGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButtonGroup$3e$__["ToggleButtonGroup"], {
                        value: tool,
                        exclusive: true,
                        onChange: (e_2, value)=>value && setTool(value),
                        size: "small",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButton$3e$__["ToggleButton"], {
                                value: "brush",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Brush$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                    lineNumber: 212,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                lineNumber: 211,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButton$3e$__["ToggleButton"], {
                                value: "eraser",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Clear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                    lineNumber: 215,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                lineNumber: 214,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                        lineNumber: 210,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            width: 200
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "caption",
                                gutterBottom: true,
                                children: t('imageMaskEditor.brushSize', {
                                    size: brushSize
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                lineNumber: 222,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Slider$3e$__["Slider"], {
                                value: brushSize,
                                onChange: (e_3, value_0)=>setBrushSize(value_0),
                                min: 5,
                                max: 100,
                                size: "small"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                lineNumber: 227,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                        lineNumber: 219,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: "Undo",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                onClick: undo,
                                disabled: historyIndex <= 0,
                                size: "small",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Undo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                    lineNumber: 233,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                lineNumber: 232,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                            lineNumber: 231,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                        lineNumber: 230,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: "Redo",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                onClick: redo,
                                disabled: historyIndex >= history.length - 1,
                                size: "small",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Redo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                    lineNumber: 241,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                lineNumber: 240,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                            lineNumber: 239,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                        lineNumber: 238,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: "Clear mask",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                            onClick: clearMask,
                            size: "small",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Clear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                lineNumber: 248,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                            lineNumber: 247,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                        lineNumber: 246,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: "Zoom in",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                            onClick: handleZoomIn,
                            size: "small",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ZoomIn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                lineNumber: 254,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                            lineNumber: 253,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                        lineNumber: 252,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: "Zoom out",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                            onClick: handleZoomOut,
                            size: "small",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ZoomOut$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                                lineNumber: 260,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                            lineNumber: 259,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                        lineNumber: 258,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        sx: {
                            ml: 'auto'
                        },
                        children: t('imageMaskEditor.zoomInfo', {
                            level: (zoom * 100).toFixed(0)
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                        lineNumber: 264,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                lineNumber: 205,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    flexGrow: 1,
                    overflow: 'auto',
                    position: 'relative',
                    bgcolor: 'grey.100',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        position: 'relative',
                        cursor: isPanning ? 'grabbing' : tool === 'brush' ? 'crosshair' : 'pointer',
                        transform: `scale(${zoom}) translate(${panOffset.x}px, ${panOffset.y}px)`,
                        transformOrigin: 'center'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                            ref: canvasRef,
                            style: {
                                position: 'absolute',
                                top: 0,
                                left: 0,
                                maxWidth: width,
                                maxHeight: height
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                            lineNumber: 290,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                            ref: maskCanvasRef,
                            onMouseDown: startDrawing,
                            onMouseMove: handleMouseMove,
                            onMouseUp: stopDrawing,
                            onMouseLeave: stopDrawing,
                            style: {
                                position: 'absolute',
                                top: 0,
                                left: 0,
                                maxWidth: width,
                                maxHeight: height
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                            lineNumber: 299,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                    lineNumber: 283,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                lineNumber: 274,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    p: 2,
                    display: 'flex',
                    gap: 2,
                    justifyContent: 'flex-end',
                    bgcolor: 'background.paper'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        onClick: onCancel,
                        variant: "outlined",
                        children: t('imageMaskEditor.cancel')
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                        lineNumber: 317,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        onClick: handleComplete,
                        variant: "contained",
                        children: t('imageMaskEditor.applyMask')
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                        lineNumber: 320,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                lineNumber: 310,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    p: 2,
                    bgcolor: 'info.light'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "caption",
                    children: t('imageMaskEditor.instructions')
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                    lineNumber: 330,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
                lineNumber: 326,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/ImageMaskEditor.jsx",
        lineNumber: 198,
        columnNumber: 10
    }, this);
}
_s(ImageMaskEditor, "P5/X89deKbwixTmMfz6vfUYeK4s=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = ImageMaskEditor;
var _c;
__turbopack_context__.k.register(_c, "ImageMaskEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/EnhancedGenerators.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AudioGeneratorButton",
    ()=>AudioGeneratorButton,
    "EnhancedAudioGenerator",
    ()=>EnhancedAudioGenerator,
    "EnhancedImageGenerator",
    ()=>EnhancedImageGenerator,
    "ImageGeneratorButton",
    ()=>ImageGeneratorButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$274953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:274953 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$7d3f15__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:7d3f15 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$UnifiedGenerateModal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/UnifiedGenerateModal.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$ImageMaskEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/ImageMaskEditor.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
function EnhancedImageGenerator(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23);
    if ($[0] !== "9f41ccf20cd8ee68b07d064f6a11fdfc8bf97abad104ee5f27b1c7a40114385b") {
        for(let $i = 0; $i < 23; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9f41ccf20cd8ee68b07d064f6a11fdfc8bf97abad104ee5f27b1c7a40114385b";
    }
    const { open, onClose } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.ai");
    const [showMaskEditor, setShowMaskEditor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentImage, setCurrentImage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t1;
    if ($[1] !== t) {
        t1 = ({
            "EnhancedImageGenerator[handleGenerate]": async (prompt)=>{
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$7d3f15__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateImage"])({
                    phrase: prompt,
                    model: "dall-e-3"
                });
                const path = result.path;
                const presignedUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(path);
                const imageData = {
                    path,
                    url: presignedUrl,
                    preview: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: presignedUrl,
                                alt: "Generated",
                                style: {
                                    width: "100%",
                                    maxHeight: "600px",
                                    objectFit: "contain"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
                                lineNumber: 41,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "outlined",
                                fullWidth: true,
                                sx: {
                                    mt: 2
                                },
                                onClick: {
                                    "EnhancedImageGenerator[handleGenerate > <Button>.onClick]": ()=>{
                                        setCurrentImage({
                                            url: presignedUrl,
                                            path
                                        });
                                        setShowMaskEditor(true);
                                    }
                                }["EnhancedImageGenerator[handleGenerate > <Button>.onClick]"],
                                children: t("enhancedGenerators.editWithMask")
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
                                lineNumber: 45,
                                columnNumber: 18
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
                        lineNumber: 41,
                        columnNumber: 20
                    }, this)
                };
                setCurrentImage(imageData);
                return imageData;
            }
        })["EnhancedImageGenerator[handleGenerate]"];
        $[1] = t;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const handleGenerate = t1;
    let t2;
    if ($[3] !== t) {
        t2 = ({
            "EnhancedImageGenerator[handleRegenerate]": async (prompt_0, previousImage, maskData)=>{
                const result_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$7d3f15__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateImage"])({
                    phrase: prompt_0,
                    model: "dall-e-3"
                });
                const path_0 = result_0.path;
                const presignedUrl_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(path_0);
                return {
                    path: path_0,
                    url: presignedUrl_0,
                    preview: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: presignedUrl_0,
                                alt: "Regenerated",
                                style: {
                                    width: "100%",
                                    maxHeight: "600px",
                                    objectFit: "contain"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
                                lineNumber: 80,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "outlined",
                                fullWidth: true,
                                sx: {
                                    mt: 2
                                },
                                onClick: {
                                    "EnhancedImageGenerator[handleRegenerate > <Button>.onClick]": ()=>{
                                        setCurrentImage({
                                            url: presignedUrl_0,
                                            path: path_0
                                        });
                                        setShowMaskEditor(true);
                                    }
                                }["EnhancedImageGenerator[handleRegenerate > <Button>.onClick]"],
                                children: t("enhancedGenerators.editWithMask")
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
                                lineNumber: 84,
                                columnNumber: 18
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
                        lineNumber: 80,
                        columnNumber: 20
                    }, this)
                };
            }
        })["EnhancedImageGenerator[handleRegenerate]"];
        $[3] = t;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const handleRegenerate = t2;
    let t3;
    if ($[5] !== currentImage || $[6] !== handleRegenerate) {
        t3 = ({
            "EnhancedImageGenerator[handleMaskComplete]": async (maskData_0)=>{
                setShowMaskEditor(false);
                await handleRegenerate("Regenerate masked area", currentImage, maskData_0);
            }
        })["EnhancedImageGenerator[handleMaskComplete]"];
        $[5] = currentImage;
        $[6] = handleRegenerate;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    const handleMaskComplete = t3;
    if (showMaskEditor && currentImage) {
        let t4;
        if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = ({
                "EnhancedImageGenerator[<ImageMaskEditor>.onCancel]": ()=>setShowMaskEditor(false)
            })["EnhancedImageGenerator[<ImageMaskEditor>.onCancel]"];
            $[8] = t4;
        } else {
            t4 = $[8];
        }
        let t5;
        if ($[9] !== currentImage.url || $[10] !== handleMaskComplete) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$ImageMaskEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                imageUrl: currentImage.url,
                onMaskComplete: handleMaskComplete,
                onCancel: t4
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
                lineNumber: 131,
                columnNumber: 12
            }, this);
            $[9] = currentImage.url;
            $[10] = handleMaskComplete;
            $[11] = t5;
        } else {
            t5 = $[11];
        }
        return t5;
    }
    let t4;
    if ($[12] !== t) {
        t4 = t("enhancedGenerators.generateImage");
        $[12] = t;
        $[13] = t4;
    } else {
        t4 = $[13];
    }
    let t5;
    if ($[14] !== t) {
        t5 = t("enhancedGenerators.imagePromptPlaceholder");
        $[14] = t;
        $[15] = t5;
    } else {
        t5 = $[15];
    }
    let t6;
    if ($[16] !== handleGenerate || $[17] !== handleRegenerate || $[18] !== onClose || $[19] !== open || $[20] !== t4 || $[21] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$UnifiedGenerateModal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            onClose: onClose,
            onGenerate: handleGenerate,
            onRegenerate: handleRegenerate,
            title: t4,
            inputPlaceholder: t5,
            type: "image"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
            lineNumber: 158,
            columnNumber: 10
        }, this);
        $[16] = handleGenerate;
        $[17] = handleRegenerate;
        $[18] = onClose;
        $[19] = open;
        $[20] = t4;
        $[21] = t5;
        $[22] = t6;
    } else {
        t6 = $[22];
    }
    return t6;
}
_s(EnhancedImageGenerator, "oLMP6dWjBZryiF06PEQZMXHbvvk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = EnhancedImageGenerator;
function EnhancedAudioGenerator(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    if ($[0] !== "9f41ccf20cd8ee68b07d064f6a11fdfc8bf97abad104ee5f27b1c7a40114385b") {
        for(let $i = 0; $i < 11; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9f41ccf20cd8ee68b07d064f6a11fdfc8bf97abad104ee5f27b1c7a40114385b";
    }
    const { open, onClose } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.ai");
    const handleGenerate = _EnhancedAudioGeneratorHandleGenerate;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "EnhancedAudioGenerator[handleRegenerate]": async (prompt_0)=>handleGenerate(prompt_0)
        })["EnhancedAudioGenerator[handleRegenerate]"];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const handleRegenerate = t1;
    let t2;
    if ($[2] !== t) {
        t2 = t("enhancedGenerators.generateAudio");
        $[2] = t;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] !== t) {
        t3 = t("enhancedGenerators.audioPromptPlaceholder");
        $[4] = t;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== onClose || $[7] !== open || $[8] !== t2 || $[9] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$UnifiedGenerateModal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            onClose: onClose,
            onGenerate: handleGenerate,
            onRegenerate: handleRegenerate,
            title: t2,
            inputPlaceholder: t3,
            type: "audio"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
            lineNumber: 219,
            columnNumber: 10
        }, this);
        $[6] = onClose;
        $[7] = open;
        $[8] = t2;
        $[9] = t3;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    return t4;
}
_s1(EnhancedAudioGenerator, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c1 = EnhancedAudioGenerator;
/**
 * Button component for image generation that can be embedded in FileManager
 */ async function _EnhancedAudioGeneratorHandleGenerate(prompt) {
    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$274953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateSpeech"])({
        phrase: prompt,
        voice: "alloy",
        model: "tts-1"
    });
    const path = result.path;
    const presignedUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(path);
    return {
        path,
        url: presignedUrl,
        preview: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("audio", {
                controls: true,
                src: presignedUrl,
                style: {
                    width: "100%"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
                lineNumber: 245,
                columnNumber: 19
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
            lineNumber: 245,
            columnNumber: 14
        }, this)
    };
}
function ImageGeneratorButton(t0) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "9f41ccf20cd8ee68b07d064f6a11fdfc8bf97abad104ee5f27b1c7a40114385b") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9f41ccf20cd8ee68b07d064f6a11fdfc8bf97abad104ee5f27b1c7a40114385b";
    }
    const { open, onSuccess } = t0;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.ai");
    const [modalOpen, setModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    let t2;
    if ($[1] !== open) {
        t1 = ({
            "ImageGeneratorButton[useEffect()]": ()=>{
                if (open) {
                    setModalOpen(true);
                }
            }
        })["ImageGeneratorButton[useEffect()]"];
        t2 = [
            open
        ];
        $[1] = open;
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t1, t2);
    const handleGenerate = _ImageGeneratorButtonHandleGenerate;
    let t3;
    if ($[4] !== onSuccess) {
        t3 = ({
            "ImageGeneratorButton[handleClose]": ()=>{
                setModalOpen(false);
                if (onSuccess) {
                    onSuccess();
                }
            }
        })["ImageGeneratorButton[handleClose]"];
        $[4] = onSuccess;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const handleClose = t3;
    let t4;
    if ($[6] !== handleClose || $[7] !== modalOpen) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$UnifiedGenerateModal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: modalOpen,
            onClose: handleClose,
            onGenerate: handleGenerate,
            onRegenerate: handleGenerate,
            title: "Generate Image",
            inputPlaceholder: "Describe the image you want to generate...",
            type: "image"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
            lineNumber: 302,
            columnNumber: 10
        }, this);
        $[6] = handleClose;
        $[7] = modalOpen;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    return t4;
}
_s2(ImageGeneratorButton, "knnwmlPLK1lu3esuzqayE2Q8yyw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c2 = ImageGeneratorButton;
/**
 * Button component for audio generation that can be embedded in FileManager
 */ async function _ImageGeneratorButtonHandleGenerate(prompt) {
    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$7d3f15__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateImage"])({
        phrase: prompt,
        model: "dall-e-3"
    });
    const path = result.path;
    const presignedUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(path);
    const imageData = {
        path,
        url: presignedUrl,
        preview: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: presignedUrl,
                alt: "Generated",
                style: {
                    width: "100%",
                    maxHeight: "600px",
                    objectFit: "contain"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
                lineNumber: 325,
                columnNumber: 19
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
            lineNumber: 325,
            columnNumber: 14
        }, this)
    };
    return imageData;
}
function AudioGeneratorButton(t0) {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "9f41ccf20cd8ee68b07d064f6a11fdfc8bf97abad104ee5f27b1c7a40114385b") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9f41ccf20cd8ee68b07d064f6a11fdfc8bf97abad104ee5f27b1c7a40114385b";
    }
    const { open, onSuccess } = t0;
    const [modalOpen, setModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    let t2;
    if ($[1] !== open) {
        t1 = ({
            "AudioGeneratorButton[useEffect()]": ()=>{
                if (open) {
                    setModalOpen(true);
                }
            }
        })["AudioGeneratorButton[useEffect()]"];
        t2 = [
            open
        ];
        $[1] = open;
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t1, t2);
    const handleGenerate = _AudioGeneratorButtonHandleGenerate;
    let t3;
    if ($[4] !== onSuccess) {
        t3 = ({
            "AudioGeneratorButton[handleClose]": ()=>{
                setModalOpen(false);
                if (onSuccess) {
                    onSuccess();
                }
            }
        })["AudioGeneratorButton[handleClose]"];
        $[4] = onSuccess;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const handleClose = t3;
    let t4;
    if ($[6] !== handleClose || $[7] !== modalOpen) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$UnifiedGenerateModal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: modalOpen,
            onClose: handleClose,
            onGenerate: handleGenerate,
            onRegenerate: handleGenerate,
            title: "Generate Audio",
            inputPlaceholder: "Enter text to convert to speech...",
            type: "audio"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
            lineNumber: 384,
            columnNumber: 10
        }, this);
        $[6] = handleClose;
        $[7] = modalOpen;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    return t4;
}
_s3(AudioGeneratorButton, "n/uSAQp/7kvSf7bwDf6NDTOBEAo=");
_c3 = AudioGeneratorButton;
async function _AudioGeneratorButtonHandleGenerate(prompt) {
    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$274953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateSpeech"])({
        phrase: prompt,
        voice: "alloy",
        model: "tts-1"
    });
    const path = result.path;
    const presignedUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(path);
    return {
        path,
        url: presignedUrl,
        preview: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("audio", {
                controls: true,
                src: presignedUrl,
                style: {
                    width: "100%"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
                lineNumber: 404,
                columnNumber: 19
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/EnhancedGenerators.jsx",
            lineNumber: 404,
            columnNumber: 14
        }, this)
    };
}
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "EnhancedImageGenerator");
__turbopack_context__.k.register(_c1, "EnhancedAudioGenerator");
__turbopack_context__.k.register(_c2, "ImageGeneratorButton");
__turbopack_context__.k.register(_c3, "AudioGeneratorButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/SuggestedContent.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SuggestedQuestions",
    ()=>SuggestedQuestions,
    "SuggestedVocabulary",
    ()=>SuggestedVocabulary
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * SuggestedContent - Wrappers for VocabularyReview2 and QuestionsReview2
 * 
 * These components are used in FileManager2 to display suggested vocabulary
 * and questions from parsed PDF content.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VocabularyReview2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/VocabularyReview2.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$QuestionsReview2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/QuestionsReview2.tsx [app-client] (ecmascript)");
;
;
;
;
;
const SuggestedVocabulary = (t0)=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "361ed96bfc6a7181906cb1afd5dd0de501214eecb5186f5d82ec9bea21b9e033") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "361ed96bfc6a7181906cb1afd5dd0de501214eecb5186f5d82ec9bea21b9e033";
    }
    const { documentId, unitId, enableInlineEditing: t1, onImport } = t0;
    t1 === undefined ? true : t1;
    let t2;
    if ($[1] !== onImport) {
        t2 = (result)=>{
            if (onImport && result.imported) {
                onImport(result.imported);
            }
        };
        $[1] = onImport;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const handleImportComplete = t2;
    let t3;
    if ($[3] !== documentId || $[4] !== handleImportComplete || $[5] !== unitId) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VocabularyReview2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            documentId: documentId,
            unitId: unitId,
            owner: "current-user",
            identityId: "current-identity",
            onImportComplete: handleImportComplete,
            searchTerm: ""
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/SuggestedContent.jsx",
            lineNumber: 53,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[3] = documentId;
        $[4] = handleImportComplete;
        $[5] = unitId;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    return t3;
};
_c = SuggestedVocabulary;
const SuggestedQuestions = (t0)=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "361ed96bfc6a7181906cb1afd5dd0de501214eecb5186f5d82ec9bea21b9e033") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "361ed96bfc6a7181906cb1afd5dd0de501214eecb5186f5d82ec9bea21b9e033";
    }
    const { documentId, unitId, enableInlineEditing: t1, onImport } = t0;
    t1 === undefined ? true : t1;
    let t2;
    if ($[1] !== onImport) {
        t2 = (result)=>{
            if (onImport && result.imported) {
                onImport(result.imported);
            }
        };
        $[1] = onImport;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const handleImportComplete = t2;
    let t3;
    if ($[3] !== documentId || $[4] !== handleImportComplete || $[5] !== unitId) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$QuestionsReview2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            documentId: documentId,
            unitId: unitId,
            owner: "current-user",
            identityId: "current-identity",
            onImportComplete: handleImportComplete,
            searchTerm: ""
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/SuggestedContent.jsx",
            lineNumber: 104,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[3] = documentId;
        $[4] = handleImportComplete;
        $[5] = unitId;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    return t3;
};
_c1 = SuggestedQuestions;
var _c, _c1;
__turbopack_context__.k.register(_c, "SuggestedVocabulary");
__turbopack_context__.k.register(_c1, "SuggestedQuestions");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/PlaylistEditor.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ActionsMenu",
    ()=>ActionsMenu,
    "default",
    ()=>PlaylistEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$DataGrid$2f$DataGrid$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/DataGrid/DataGrid.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Menu/Menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Autocomplete/Autocomplete.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useAutocomplete$2f$useAutocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/useAutocomplete/useAutocomplete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/useLexicalNodeSelection.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MoreVert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/fileContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const filter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useAutocomplete$2f$useAutocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createFilterOptions"])();
const columns = [
    {
        field: 'title',
        headerName: 'Title',
        flex: 1,
        minWidth: 100
    },
    {
        field: 'size',
        headerName: 'Size',
        flex: 1,
        minWidth: 100
    }
];
function ActionsMenu(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(21);
    if ($[0] !== "fd0dd67cef1d2da0a4ad09ddcbe3b732fcce35ca775c665d7ba2c165b4c4762f") {
        for(let $i = 0; $i < 21; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "fd0dd67cef1d2da0a4ad09ddcbe3b732fcce35ca775c665d7ba2c165b4c4762f";
    }
    const { ids, removeFileIDs } = t0;
    const [anchorEl, setAnchorEl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const open = Boolean(anchorEl);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "ActionsMenu[handleClick]": (event)=>{
                setAnchorEl(event.currentTarget);
            }
        })["ActionsMenu[handleClick]"];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const handleClick = t1;
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "ActionsMenu[handleClose]": ()=>{
                setAnchorEl(null);
            }
        })["ActionsMenu[handleClose]"];
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const handleClose = t2;
    let t3;
    if ($[3] !== ids || $[4] !== removeFileIDs) {
        t3 = ({
            "ActionsMenu[removeFromPlaylist]": ()=>{
                console.log("removeFrom", ids);
                removeFileIDs(ids);
                setAnchorEl(null);
            }
        })["ActionsMenu[removeFromPlaylist]"];
        $[3] = ids;
        $[4] = removeFileIDs;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const removeFromPlaylist = t3;
    const t4 = open ? "playlist-edit-menu" : undefined;
    const t5 = open ? "true" : undefined;
    let t6;
    let t7;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            minWidth: "3rem",
            margin: "0 0 0 0.5rem"
        };
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
            lineNumber: 93,
            columnNumber: 10
        }, this);
        $[6] = t6;
        $[7] = t7;
    } else {
        t6 = $[6];
        t7 = $[7];
    }
    let t8;
    if ($[8] !== t4 || $[9] !== t5) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            id: "playlist-edit-button",
            color: "inherit",
            "aria-controls": t4,
            "aria-haspopup": "true",
            "aria-expanded": t5,
            onClick: handleClick,
            sx: t6,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
            lineNumber: 102,
            columnNumber: 10
        }, this);
        $[8] = t4;
        $[9] = t5;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            "aria-labelledby": "playlist-edit-button"
        };
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    let t10;
    if ($[12] !== removeFromPlaylist) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            onClick: removeFromPlaylist,
            children: "Remove from Playlist"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
            lineNumber: 120,
            columnNumber: 11
        }, this);
        $[12] = removeFromPlaylist;
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] !== anchorEl || $[15] !== open || $[16] !== t10) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
            id: "playlist-edit-menu",
            anchorEl: anchorEl,
            open: open,
            onClose: handleClose,
            MenuListProps: t9,
            children: t10
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
            lineNumber: 128,
            columnNumber: 11
        }, this);
        $[14] = anchorEl;
        $[15] = open;
        $[16] = t10;
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    if ($[18] !== t11 || $[19] !== t8) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t8,
                t11
            ]
        }, void 0, true);
        $[18] = t11;
        $[19] = t8;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    return t12;
}
_s(ActionsMenu, "+aMDa7FPcESUyQDF1vq0RSMn4/k=");
_c = ActionsMenu;
function PlaylistEditor({ className, format, nodeKey, // setFileIDs,
fileIDs }) {
    _s1();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('editor.shared');
    const [value, setValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const [open, toggleOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    // const [rows, setRows] = React.useState([]);
    const [gridSelection, setGridSelection] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [dialogValue, setDialogValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        phrase: '',
        definition: '',
        pronunciation: ''
    });
    // const [anchorEl, setAnchorEl] = React.useState(null);
    // const [openMore, setOpenMore] = React.useState(false);
    // Record previous FileIDs
    const prevFileIDs = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](fileIDs);
    const playlistRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const [isSelected, setSelected, clearSelection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"])(nodeKey);
    const { unit } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { myPlaylistFiles } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const _fileOptions = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "PlaylistEditor.useMemo[_fileOptions]": ()=>{
            return Object.values(myPlaylistFiles);
        }
    }["PlaylistEditor.useMemo[_fileOptions]"], [
        myPlaylistFiles
    ]);
    const rows = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "PlaylistEditor.useMemo[rows]": ()=>{
            const _rows = [];
            if (fileIDs) {
                fileIDs.forEach({
                    "PlaylistEditor.useMemo[rows]": (id)=>{
                        const file = myPlaylistFiles[id];
                        if (file) {
                            _rows.push({
                                id: file.id,
                                title: file.name,
                                size: (file.size / 100000).toFixed(2) + ' MB'
                            });
                        }
                    }
                }["PlaylistEditor.useMemo[rows]"]);
            }
            return _rows;
        }
    }["PlaylistEditor.useMemo[rows]"], [
        fileIDs,
        myPlaylistFiles
    ]);
    const onDelete = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "PlaylistEditor.useCallback[onDelete]": async (payload)=>{
            if (isSelected && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])())) {
                const event = payload;
                event.preventDefault();
                const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isPlaylistNode"])(node)) {
                    node.remove();
                    // Remove relationship to file
                    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                    const _operations = [];
                    fileIDs.forEach({
                        "PlaylistEditor.useCallback[onDelete]": (id_0)=>{
                            _operations.push(client.models.UnitFile.delete({
                                id: id_0
                            }));
                        }
                    }["PlaylistEditor.useCallback[onDelete]"]);
                    await Promise.allSettled(_operations);
                }
            }
            return false;
        }
    }["PlaylistEditor.useCallback[onDelete]"], [
        nodeKey
    ]);
    const addFileID = (id_1)=>{
        editor.update(async ()=>{
            const node_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isPlaylistNode"])(node_0)) {
                node_0.appendId(id_1);
                // Add relationship to file
                console.log('addFileID', id_1);
                const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const { data: file_0 } = await client_0.models.File.get({
                    id: id_1
                });
                if (file_0) {
                    await client_0.models.UnitFile.create({
                        unitID: unit.id,
                        fileID: file_0.id
                    });
                }
            }
        });
    };
    const removeFileIDs = (ids)=>{
        editor.update(async ()=>{
            const node_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isPlaylistNode"])(node_1)) {
                node_1.removeIntersection(ids);
                // Remove relationship to file
                const client_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const _operations_0 = [];
                ids.forEach((id_2)=>{
                    _operations_0.push(client_1.models.UnitFile.delete({
                        id: id_2
                    }));
                });
                await Promise.allSettled(_operations_0);
            }
        });
    };
    // React.useEffect(() => {
    //     if (fileIDs.length === 0) return;
    //     prevFileIDs.current = fileIDs;
    //     let _rows = []
    //     fileIDs.forEach((id) => {
    //         const file = myPlaylistFiles[id];
    //         if (file) {
    //             _rows.push({
    //                 id: file.id,
    //                 title: file.name,
    //                 size: (file.size/100000).toFixed(2) + ' MB' ,
    //             });
    //         }
    //     });
    //     setRows(_rows);
    // }, [fileIDs]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "PlaylistEditor.useEffect": ()=>{
            let isMounted = true;
            const unregister = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CLICK_COMMAND"], {
                "PlaylistEditor.useEffect.unregister": (payload_0)=>{
                    const event_0 = payload_0;
                    if (playlistRef.current && (event_0.target === playlistRef.current || playlistRef.current.contains(event_0.target))) {
                        if (event_0.shiftKey) {
                            setSelected({
                                "PlaylistEditor.useEffect.unregister": (prev)=>!prev
                            }["PlaylistEditor.useEffect.unregister"]);
                        } else {
                            // Only clear selection if we're not already selected
                            setSelected({
                                "PlaylistEditor.useEffect.unregister": (prev_0)=>{
                                    if (!prev_0) {
                                        clearSelection();
                                    }
                                    return true;
                                }
                            }["PlaylistEditor.useEffect.unregister"]);
                        }
                        return true;
                    }
                    return false;
                }
            }["PlaylistEditor.useEffect.unregister"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_DELETE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_BACKSPACE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]));
            return ({
                "PlaylistEditor.useEffect": ()=>{
                    isMounted = false;
                    unregister();
                }
            })["PlaylistEditor.useEffect"];
        }
    }["PlaylistEditor.useEffect"], [
        editor,
        nodeKey,
        onDelete
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: playlistRef,
        style: {
            maxHeight: '32rem',
            maxWidth: '72rem',
            padding: '8px'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"], {
                        value: value,
                        onChange: (event_1, newValue)=>{
                            if (typeof newValue === 'string') {
                                // timeout to avoid instant validation of the dialog's form.
                                setTimeout(()=>{
                                    // toggleOpen(true);
                                    setDialogValue({
                                        phrase: newValue,
                                        pronunciation: '',
                                        definition: ''
                                    });
                                });
                            } else if (newValue && newValue.inputValue) {
                                // toggleOpen(true);
                                setDialogValue({
                                    phrase: newValue.inputValue,
                                    pronunciation: '',
                                    definition: ''
                                });
                            } else {
                                console.log('Autocomplete.newValue', newValue);
                                // Append wordID to FileIDs
                                const newFileID = newValue?.id;
                                if (newFileID) {
                                    addFileID(newFileID);
                                    setValue(null);
                                    setDialogValue({
                                        phrase: '',
                                        pronunciation: '',
                                        definition: ''
                                    });
                                }
                            }
                        },
                        filterOptions: (options, params)=>{
                            const filtered = filter(options, params);
                            return filtered;
                        },
                        sx: {
                            flexGrow: 1
                        },
                        id: "add-new-word",
                        options: _fileOptions,
                        getOptionLabel: (option)=>{
                            // e.g value selected with enter, right from the input
                            if (typeof option === 'string') {
                                return option;
                            }
                            if (option.inputValue) {
                                return option.inputValue;
                            }
                            return option.name;
                        },
                        selectOnFocus: true,
                        clearOnBlur: true,
                        handleHomeEndKeys: true,
                        renderOption: (props, option_0)=>{
                            const { key, ...otherProps } = props;
                            let phrase = option_0.name;
                            if (option_0?.name && option_0?.mimeType) {
                                phrase = `${option_0.name} (${option_0.mimeType})`;
                            }
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                ...otherProps,
                                children: phrase
                            }, key, false, {
                                fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
                                lineNumber: 376,
                                columnNumber: 16
                            }, this);
                        },
                        // sx={{ width: 300 }}
                        freeSolo: true,
                        renderInput: (params_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                ...params_0,
                                label: "Add file to playlist"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
                                lineNumber: 379,
                                columnNumber: 41
                            }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
                        lineNumber: 321,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ActionsMenu, {
                        removeFileIDs: removeFileIDs,
                        ids: gridSelection
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
                        lineNumber: 380,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
                lineNumber: 315,
                columnNumber: 13
            }, this),
            rows.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    marginTop: '0.5'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: t('playlistEditor.noFilesMessage')
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
                    lineNumber: 387,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
                lineNumber: 384,
                columnNumber: 35
            }, this),
            rows.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$DataGrid$2f$DataGrid$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DataGrid"], {
                sx: {
                    marginTop: '0.5rem'
                },
                rows: rows,
                columns: columns,
                initialState: {
                    pagination: {
                        paginationModel: {
                            page: 0,
                            pageSize: 10
                        }
                    }
                },
                pageSizeOptions: [
                    5,
                    10,
                    100
                ],
                checkboxSelection: true,
                rowSelectionModel: gridSelection,
                onRowSelectionModelChange: (e)=>{
                    console.log('onRowSelectionModelChange', e);
                    setGridSelection(e);
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
                lineNumber: 391,
                columnNumber: 33
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/PlaylistEditor.jsx",
        lineNumber: 309,
        columnNumber: 10
    }, this);
}
_s1(PlaylistEditor, "GwARa6XD64d2buCYk+NPORmXJDo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"]
    ];
});
_c1 = PlaylistEditor;
var _c, _c1;
__turbopack_context__.k.register(_c, "ActionsMenu");
__turbopack_context__.k.register(_c1, "PlaylistEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/GradeHistory.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GradeHistory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview GradeHistory - Displays previous attempt statistics for workbook assignments
 * @module GradeHistory
 * 
 * Shows a list of previous grade attempts with accuracy scores and timestamps.
 * Used in the workbook sidebar to give students visibility into their progress.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TrendingUp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TrendingDown.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingFlat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TrendingFlat.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
function GradeHistory() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(30);
    if ($[0] !== "e2d4bc16578d021fb1a0c9675f9b4909520036050bb9a5fd8d6fd33162341f1d") {
        for(let $i = 0; $i < 30; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e2d4bc16578d021fb1a0c9675f9b4909520036050bb9a5fd8d6fd33162341f1d";
    }
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("workbook");
    const { grade, recentGrades } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const hasGrades = recentGrades && recentGrades.length > 0;
    const currentAccuracy = grade?.accuracy || 0;
    Math.round(currentAccuracy * 100);
    let t0;
    if ($[1] !== hasGrades || $[2] !== recentGrades) {
        t0 = hasGrades ? recentGrades.reduce(_GradeHistoryRecentGradesReduce, 0) / recentGrades.length : 0;
        $[1] = hasGrades;
        $[2] = recentGrades;
        $[3] = t0;
    } else {
        t0 = $[3];
    }
    const averageAccuracy = t0;
    const roundedAverage = Math.round(averageAccuracy * 100) / 100;
    let t1;
    if ($[4] !== hasGrades || $[5] !== recentGrades) {
        t1 = hasGrades ? Math.max(...recentGrades.map(_GradeHistoryRecentGradesMap)) : 0;
        $[4] = hasGrades;
        $[5] = recentGrades;
        $[6] = t1;
    } else {
        t1 = $[6];
    }
    const bestAccuracy = t1;
    const roundedBest = Math.round(bestAccuracy * 100) / 100;
    const attemptCount = recentGrades.length;
    let trend = "flat";
    if (recentGrades.length >= 2) {
        const lastTwo = recentGrades.slice(0, 2);
        const diff = lastTwo[0].accuracy - lastTwo[1].accuracy;
        if (diff > 0.5) {
            trend = "up";
        } else {
            if (diff < -0.5) {
                trend = "down";
            }
        }
    }
    const TrendIcon = trend === "up" ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] : trend === "down" ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingFlat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
    const trendColor = trend === "up" ? "success" : trend === "down" ? "error" : "default";
    let t2;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            display: "flex",
            flexDirection: "column",
            padding: "1rem",
            width: "100%",
            maxWidth: "100%",
            boxSizing: "border-box",
            overflowX: "hidden"
        };
        $[7] = t2;
    } else {
        t2 = $[7];
    }
    let t3;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            mb: 2
        };
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== t) {
        t4 = t("gradeHistory.title");
        $[9] = t;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h6",
            sx: t3,
            children: t4
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
            lineNumber: 104,
            columnNumber: 10
        }, this);
        $[11] = t4;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    let t6;
    if ($[13] !== hasGrades || $[14] !== t) {
        t6 = !hasGrades && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                textAlign: "center",
                py: 4
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "body1",
                    color: "text.secondary",
                    children: t("gradeHistory.noAttempts")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                    lineNumber: 115,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "body2",
                    color: "text.secondary",
                    sx: {
                        mt: 1
                    },
                    children: t("gradeHistory.completeFirstAttempt")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                    lineNumber: 115,
                    columnNumber: 102
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
            lineNumber: 112,
            columnNumber: 24
        }, this);
        $[13] = hasGrades;
        $[14] = t;
        $[15] = t6;
    } else {
        t6 = $[15];
    }
    let t7;
    if ($[16] !== TrendIcon || $[17] !== attemptCount || $[18] !== hasGrades || $[19] !== recentGrades || $[20] !== roundedAverage || $[21] !== roundedBest || $[22] !== t || $[23] !== trend || $[24] !== trendColor) {
        t7 = hasGrades && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        mb: 3
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                            direction: "row",
                            spacing: 1,
                            sx: {
                                mb: 2,
                                flexWrap: "wrap",
                                gap: 1
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                    label: `${attemptCount} ${t("gradeHistory.attempts")}`,
                                    size: "small"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                    lineNumber: 132,
                                    columnNumber: 12
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TrendIcon, {
                                        className: "jsx-8e6da6118a04111"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                        lineNumber: 132,
                                        columnNumber: 101
                                    }, this),
                                    label: t(`gradeHistory.trend.${trend}`),
                                    size: "small",
                                    color: trendColor
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                    lineNumber: 132,
                                    columnNumber: 89
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                            lineNumber: 128,
                            columnNumber: 10
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                mb: 2
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    color: "text.secondary",
                                    children: t("gradeHistory.bestScore")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                    lineNumber: 134,
                                    columnNumber: 12
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "h5",
                                    sx: {
                                        fontWeight: "bold",
                                        color: "success.main"
                                    },
                                    children: [
                                        roundedBest,
                                        "%"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                    lineNumber: 134,
                                    columnNumber: 105
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                            lineNumber: 132,
                            columnNumber: 199
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                mb: 2
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    color: "text.secondary",
                                    children: t("gradeHistory.averageScore")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                    lineNumber: 139,
                                    columnNumber: 12
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "h6",
                                    children: [
                                        roundedAverage,
                                        "%"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                    lineNumber: 139,
                                    columnNumber: 108
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                            lineNumber: 137,
                            columnNumber: 47
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                    lineNumber: 126,
                    columnNumber: 25
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
                    sx: {
                        my: 2
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                    lineNumber: 139,
                    columnNumber: 175
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "subtitle1",
                    sx: {
                        mb: 1,
                        fontWeight: "bold"
                    },
                    children: t("gradeHistory.recentAttempts")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                    lineNumber: 141,
                    columnNumber: 12
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    id: "8e6da6118a04111",
                    children: "ol.recent-grades{counter-reset:my-counter;margin:0;padding:0;list-style-type:none}ol.recent-grades li:before{content:counter(my-counter);counter-increment:my-counter;text-align:center;width:2rem;color:var(--mui-palette-text-secondary,#666);font-size:1.2em;font-weight:700;position:absolute;top:50%;left:0;transform:translateY(-50%)}"
                }, void 0, false, void 0, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    "data-tour": "correct-answers",
                    className: "jsx-8e6da6118a04111" + " " + "recent-grades",
                    children: recentGrades.map({
                        "GradeHistory[recentGrades.map()]": (attemptGrade, index)=>{
                            const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
                            const localTime = new Date(attemptGrade?.createdAt).toLocaleString(undefined, {
                                timeZone,
                                dateStyle: "short",
                                timeStyle: "short"
                            });
                            const roundedAccuracy = Math.round(attemptGrade?.accuracy * 100) / 100;
                            const isBest = roundedAccuracy === roundedBest;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                "data-tour": "grade-detail",
                                style: {
                                    position: "relative",
                                    paddingLeft: "2.5rem",
                                    marginBottom: "1rem",
                                    paddingBottom: "1rem",
                                    borderBottom: index < recentGrades.length - 1 ? "1px solid #e0e0e0" : "none"
                                },
                                className: "jsx-8e6da6118a04111",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "space-between"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            sx: {
                                                flex: 1
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    variant: "body2",
                                                    color: "text.secondary",
                                                    children: localTime
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                                    lineNumber: 166,
                                                    columnNumber: 20
                                                }, this),
                                                attemptGrade.percentComplete !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    variant: "caption",
                                                    color: "text.secondary",
                                                    children: [
                                                        Math.round(attemptGrade.percentComplete),
                                                        "% ",
                                                        t("gradeHistory.complete")
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                                    lineNumber: 166,
                                                    columnNumber: 142
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                            lineNumber: 164,
                                            columnNumber: 18
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            sx: {
                                                display: "flex",
                                                alignItems: "center",
                                                gap: 1
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    variant: "h6",
                                                    sx: {
                                                        fontWeight: isBest ? "bold" : "normal",
                                                        color: isBest ? "success.main" : "text.primary"
                                                    },
                                                    children: [
                                                        roundedAccuracy,
                                                        "%"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                                    lineNumber: 170,
                                                    columnNumber: 20
                                                }, this),
                                                isBest && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                                    label: t("gradeHistory.best"),
                                                    size: "small",
                                                    color: "success",
                                                    sx: {
                                                        height: "20px",
                                                        fontSize: "0.7rem"
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                                    lineNumber: 173,
                                                    columnNumber: 64
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                            lineNumber: 166,
                                            columnNumber: 287
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                    lineNumber: 160,
                                    columnNumber: 16
                                }, this)
                            }, attemptGrade.id || index, false, {
                                fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                                lineNumber: 154,
                                columnNumber: 20
                            }, this);
                        }
                    }["GradeHistory[recentGrades.map()]"])
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
                    lineNumber: 144,
                    columnNumber: 777
                }, this)
            ]
        }, void 0, true);
        $[16] = TrendIcon;
        $[17] = attemptCount;
        $[18] = hasGrades;
        $[19] = recentGrades;
        $[20] = roundedAverage;
        $[21] = roundedBest;
        $[22] = t;
        $[23] = trend;
        $[24] = trendColor;
        $[25] = t7;
    } else {
        t7 = $[25];
    }
    let t8;
    if ($[26] !== t5 || $[27] !== t6 || $[28] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            "data-tour": "grades-list",
            sx: t2,
            children: [
                t5,
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/GradeHistory.jsx",
            lineNumber: 194,
            columnNumber: 10
        }, this);
        $[26] = t5;
        $[27] = t6;
        $[28] = t7;
        $[29] = t8;
    } else {
        t8 = $[29];
    }
    return t8;
}
_s(GradeHistory, "hJAj3hkbKTA5rXrfxks9DHW4O+g=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = GradeHistory;
function _GradeHistoryRecentGradesMap(g_0) {
    return g_0.accuracy || 0;
}
function _GradeHistoryRecentGradesReduce(sum, g) {
    return sum + (g.accuracy || 0);
}
var _c;
__turbopack_context__.k.register(_c, "GradeHistory");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/WorkbookSettings.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WorkbookSettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview WorkbookSettings - Student-facing settings for workbook view
 * @module WorkbookSettings
 * 
 * Provides settings relevant to students completing workbooks, such as
 * accessibility preferences and display options. Excludes authoring features.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Switch/Switch.js [app-client] (ecmascript) <export default as Switch>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-client] (ecmascript) <export default as FormControlLabel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/settingsContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function WorkbookSettings() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(97);
    if ($[0] !== "cad59fe7f4517f3c6e174ac262692323c4707688bf8b9a34cc2181f104751a92") {
        for(let $i = 0; $i < 97; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cad59fe7f4517f3c6e174ac262692323c4707688bf8b9a34cc2181f104751a92";
    }
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("workbook");
    const settingsContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const settings = settingsContext?.settings || null;
    const loadingSettings = settingsContext?.isLoading || false;
    const updateSettings = settingsContext?.updateSettings;
    let t0;
    if ($[1] !== updateSettings) {
        t0 = ({
            "WorkbookSettings[handleSettingChange]": async (field, value)=>{
                if (!updateSettings) {
                    return;
                }
                ;
                try {
                    await updateSettings({
                        [field]: value
                    });
                } catch (t1) {
                    const error = t1;
                    console.error("Error updating settings:", error);
                }
            }
        })["WorkbookSettings[handleSettingChange]"];
        $[1] = updateSettings;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const handleSettingChange = t0;
    let t1;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            display: "flex",
            flexDirection: "column",
            padding: "1rem",
            width: "100%",
            maxWidth: "100%",
            boxSizing: "border-box",
            overflowX: "hidden"
        };
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    let t2;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            mb: 2
        };
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] !== t) {
        t3 = t("workbookSettings.title");
        $[5] = t;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h6",
            sx: t2,
            children: t3
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 85,
            columnNumber: 10
        }, this);
        $[7] = t3;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            mb: 1,
            fontWeight: "bold",
            color: "text.secondary"
        };
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] !== t) {
        t6 = t("workbookSettings.displayPreferences");
        $[10] = t;
        $[11] = t6;
    } else {
        t6 = $[11];
    }
    let t7;
    if ($[12] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "subtitle2",
            sx: t5,
            children: t6
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 112,
            columnNumber: 10
        }, this);
        $[12] = t6;
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            mb: 3
        };
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    let t9;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            mb: 1
        };
        $[15] = t9;
    } else {
        t9 = $[15];
    }
    let t10;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t8,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                color: "text.secondary",
                sx: t9,
                children: [
                    "Accessibility settings (reduced motion, high contrast) have moved to your",
                    " ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        href: "/settings",
                        style: {
                            color: "inherit",
                            fontWeight: 600
                        },
                        children: "global Settings page"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
                        lineNumber: 138,
                        columnNumber: 161
                    }, this),
                    "."
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
                lineNumber: 138,
                columnNumber: 24
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 138,
            columnNumber: 11
        }, this);
        $[16] = t10;
    } else {
        t10 = $[16];
    }
    let t11;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
            sx: {
                my: 2
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 148,
            columnNumber: 11
        }, this);
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            mb: 1,
            fontWeight: "bold",
            color: "text.secondary"
        };
        $[18] = t12;
    } else {
        t12 = $[18];
    }
    let t13;
    if ($[19] !== t) {
        t13 = t("workbookSettings.audioPreferences");
        $[19] = t;
        $[20] = t13;
    } else {
        t13 = $[20];
    }
    let t14;
    if ($[21] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "subtitle2",
            sx: t12,
            children: t13
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 176,
            columnNumber: 11
        }, this);
        $[21] = t13;
        $[22] = t14;
    } else {
        t14 = $[22];
    }
    let t15;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            mb: 3
        };
        $[23] = t15;
    } else {
        t15 = $[23];
    }
    let t16;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            maxWidth: "100%",
            wordWrap: "break-word",
            "& .MuiFormControlLabel-label": {
                whiteSpace: "normal",
                wordWrap: "break-word",
                overflowWrap: "break-word"
            }
        };
        $[24] = t16;
    } else {
        t16 = $[24];
    }
    const t17 = settings?.autoPlayAudio ?? true;
    let t18;
    if ($[25] !== handleSettingChange) {
        t18 = ({
            "WorkbookSettings[<Switch>.onChange]": (e)=>handleSettingChange("autoPlayAudio", e.target.checked)
        })["WorkbookSettings[<Switch>.onChange]"];
        $[25] = handleSettingChange;
        $[26] = t18;
    } else {
        t18 = $[26];
    }
    let t19;
    if ($[27] !== loadingSettings || $[28] !== t17 || $[29] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
            checked: t17,
            onChange: t18,
            disabled: loadingSettings
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 219,
            columnNumber: 11
        }, this);
        $[27] = loadingSettings;
        $[28] = t17;
        $[29] = t18;
        $[30] = t19;
    } else {
        t19 = $[30];
    }
    let t20;
    if ($[31] !== t) {
        t20 = t("workbookSettings.autoPlayAudio");
        $[31] = t;
        $[32] = t20;
    } else {
        t20 = $[32];
    }
    let t21;
    if ($[33] !== t19 || $[34] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__["FormControlLabel"], {
            sx: t16,
            control: t19,
            label: t20
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 237,
            columnNumber: 11
        }, this);
        $[33] = t19;
        $[34] = t20;
        $[35] = t21;
    } else {
        t21 = $[35];
    }
    let t22;
    if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = {
            ml: 4,
            mb: 2
        };
        $[36] = t22;
    } else {
        t22 = $[36];
    }
    let t23;
    if ($[37] !== t) {
        t23 = t("workbookSettings.autoPlayAudioDescription");
        $[37] = t;
        $[38] = t23;
    } else {
        t23 = $[38];
    }
    let t24;
    if ($[39] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            display: "block",
            color: "text.secondary",
            sx: t22,
            children: t23
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 264,
            columnNumber: 11
        }, this);
        $[39] = t23;
        $[40] = t24;
    } else {
        t24 = $[40];
    }
    let t25;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = {
            maxWidth: "100%",
            wordWrap: "break-word",
            "& .MuiFormControlLabel-label": {
                whiteSpace: "normal",
                wordWrap: "break-word",
                overflowWrap: "break-word"
            }
        };
        $[41] = t25;
    } else {
        t25 = $[41];
    }
    const t26 = settings?.showWaveforms ?? true;
    let t27;
    if ($[42] !== handleSettingChange) {
        t27 = ({
            "WorkbookSettings[<Switch>.onChange]": (e_0)=>handleSettingChange("showWaveforms", e_0.target.checked)
        })["WorkbookSettings[<Switch>.onChange]"];
        $[42] = handleSettingChange;
        $[43] = t27;
    } else {
        t27 = $[43];
    }
    let t28;
    if ($[44] !== loadingSettings || $[45] !== t26 || $[46] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
            checked: t26,
            onChange: t27,
            disabled: loadingSettings
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 298,
            columnNumber: 11
        }, this);
        $[44] = loadingSettings;
        $[45] = t26;
        $[46] = t27;
        $[47] = t28;
    } else {
        t28 = $[47];
    }
    let t29;
    if ($[48] !== t) {
        t29 = t("workbookSettings.showWaveforms");
        $[48] = t;
        $[49] = t29;
    } else {
        t29 = $[49];
    }
    let t30;
    if ($[50] !== t28 || $[51] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__["FormControlLabel"], {
            sx: t25,
            control: t28,
            label: t29
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 316,
            columnNumber: 11
        }, this);
        $[50] = t28;
        $[51] = t29;
        $[52] = t30;
    } else {
        t30 = $[52];
    }
    let t31;
    if ($[53] === Symbol.for("react.memo_cache_sentinel")) {
        t31 = {
            ml: 4
        };
        $[53] = t31;
    } else {
        t31 = $[53];
    }
    let t32;
    if ($[54] !== t) {
        t32 = t("workbookSettings.showWaveformsDescription");
        $[54] = t;
        $[55] = t32;
    } else {
        t32 = $[55];
    }
    let t33;
    if ($[56] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            display: "block",
            color: "text.secondary",
            sx: t31,
            children: t32
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 342,
            columnNumber: 11
        }, this);
        $[56] = t32;
        $[57] = t33;
    } else {
        t33 = $[57];
    }
    let t34;
    if ($[58] !== t21 || $[59] !== t24 || $[60] !== t30 || $[61] !== t33) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t15,
            children: [
                t21,
                t24,
                t30,
                t33
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 350,
            columnNumber: 11
        }, this);
        $[58] = t21;
        $[59] = t24;
        $[60] = t30;
        $[61] = t33;
        $[62] = t34;
    } else {
        t34 = $[62];
    }
    let t35;
    if ($[63] === Symbol.for("react.memo_cache_sentinel")) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
            sx: {
                my: 2
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 361,
            columnNumber: 11
        }, this);
        $[63] = t35;
    } else {
        t35 = $[63];
    }
    let t36;
    if ($[64] === Symbol.for("react.memo_cache_sentinel")) {
        t36 = {
            mb: 1,
            fontWeight: "bold",
            color: "text.secondary"
        };
        $[64] = t36;
    } else {
        t36 = $[64];
    }
    let t37;
    if ($[65] !== t) {
        t37 = t("workbookSettings.feedbackPreferences");
        $[65] = t;
        $[66] = t37;
    } else {
        t37 = $[66];
    }
    let t38;
    if ($[67] !== t37) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "subtitle2",
            sx: t36,
            children: t37
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 389,
            columnNumber: 11
        }, this);
        $[67] = t37;
        $[68] = t38;
    } else {
        t38 = $[68];
    }
    let t39;
    if ($[69] === Symbol.for("react.memo_cache_sentinel")) {
        t39 = {
            mb: 3
        };
        $[69] = t39;
    } else {
        t39 = $[69];
    }
    let t40;
    if ($[70] === Symbol.for("react.memo_cache_sentinel")) {
        t40 = {
            maxWidth: "100%",
            wordWrap: "break-word",
            "& .MuiFormControlLabel-label": {
                whiteSpace: "normal",
                wordWrap: "break-word",
                overflowWrap: "break-word"
            }
        };
        $[70] = t40;
    } else {
        t40 = $[70];
    }
    const t41 = settings?.immediateWorkbookFeedback ?? true;
    let t42;
    if ($[71] !== handleSettingChange) {
        t42 = ({
            "WorkbookSettings[<Switch>.onChange]": (e_1)=>handleSettingChange("immediateWorkbookFeedback", e_1.target.checked)
        })["WorkbookSettings[<Switch>.onChange]"];
        $[71] = handleSettingChange;
        $[72] = t42;
    } else {
        t42 = $[72];
    }
    let t43;
    if ($[73] !== loadingSettings || $[74] !== t41 || $[75] !== t42) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
            checked: t41,
            onChange: t42,
            disabled: loadingSettings
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 432,
            columnNumber: 11
        }, this);
        $[73] = loadingSettings;
        $[74] = t41;
        $[75] = t42;
        $[76] = t43;
    } else {
        t43 = $[76];
    }
    let t44;
    if ($[77] !== t) {
        t44 = t("workbookSettings.immediateFeedback");
        $[77] = t;
        $[78] = t44;
    } else {
        t44 = $[78];
    }
    let t45;
    if ($[79] !== t43 || $[80] !== t44) {
        t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__["FormControlLabel"], {
            sx: t40,
            control: t43,
            label: t44
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 450,
            columnNumber: 11
        }, this);
        $[79] = t43;
        $[80] = t44;
        $[81] = t45;
    } else {
        t45 = $[81];
    }
    let t46;
    if ($[82] === Symbol.for("react.memo_cache_sentinel")) {
        t46 = {
            ml: 4
        };
        $[82] = t46;
    } else {
        t46 = $[82];
    }
    let t47;
    if ($[83] !== t) {
        t47 = t("workbookSettings.immediateFeedbackDescription");
        $[83] = t;
        $[84] = t47;
    } else {
        t47 = $[84];
    }
    let t48;
    if ($[85] !== t47) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            display: "block",
            color: "text.secondary",
            sx: t46,
            children: t47
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 476,
            columnNumber: 11
        }, this);
        $[85] = t47;
        $[86] = t48;
    } else {
        t48 = $[86];
    }
    let t49;
    if ($[87] !== t45 || $[88] !== t48) {
        t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t39,
            children: [
                t45,
                t48
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 484,
            columnNumber: 11
        }, this);
        $[87] = t45;
        $[88] = t48;
        $[89] = t49;
    } else {
        t49 = $[89];
    }
    let t50;
    if ($[90] !== t14 || $[91] !== t34 || $[92] !== t38 || $[93] !== t4 || $[94] !== t49 || $[95] !== t7) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t1,
            children: [
                t4,
                t7,
                t10,
                t11,
                t14,
                t34,
                t35,
                t38,
                t49
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/WorkbookSettings.jsx",
            lineNumber: 493,
            columnNumber: 11
        }, this);
        $[90] = t14;
        $[91] = t34;
        $[92] = t38;
        $[93] = t4;
        $[94] = t49;
        $[95] = t7;
        $[96] = t50;
    } else {
        t50 = $[96];
    }
    return t50;
}
_s(WorkbookSettings, "r/XsblFYv716gNdRmvHWik1wCCM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = WorkbookSettings;
var _c;
__turbopack_context__.k.register(_c, "WorkbookSettings");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/TableOfContents.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TableOfContents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview TableOfContents - Displays a navigable table of contents from editor headings
 * @module TableOfContents
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/rich-text/LexicalRichText.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemButton/ListItemButton.js [app-client] (ecmascript) <export default as ListItemButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
/**
 * Extracts heading nodes from the editor state
 */ function getHeadings(editor) {
    const headings = [];
    editor.getEditorState().read(()=>{
        const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
        const children = root.getChildren();
        children.forEach((node)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isHeadingNode"])(node)) {
                headings.push({
                    key: node.getKey(),
                    text: node.getTextContent(),
                    tag: node.getTag(),
                    level: parseInt(node.getTag().replace('h', ''), 10)
                });
            }
        });
    });
    return headings;
}
/**
 * Scrolls to a specific node in the editor
 */ function scrollToNode(editor, key) {
    editor.getEditorState().read(()=>{
        const element = editor.getElementByKey(key);
        if (element) {
            element.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
}
function TableOfContents() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(26);
    if ($[0] !== "c82595ab32c487c9516e78c6ac1687f5dcec4ca05d4811e9c9aac5a2f26d092c") {
        for(let $i = 0; $i < 26; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c82595ab32c487c9516e78c6ac1687f5dcec4ca05d4811e9c9aac5a2f26d092c";
    }
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.shared");
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [headings, setHeadings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== editor) {
        t1 = ({
            "TableOfContents[useEffect()]": ()=>{
                setHeadings(getHeadings(editor));
                return editor.registerUpdateListener({
                    "TableOfContents[useEffect() > editor.registerUpdateListener()]": (t3)=>{
                        setHeadings(getHeadings(editor));
                    }
                }["TableOfContents[useEffect() > editor.registerUpdateListener()]"]);
            }
        })["TableOfContents[useEffect()]"];
        t2 = [
            editor
        ];
        $[2] = editor;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    if (headings.length === 0) {
        let t3;
        if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = {
                p: 2,
                textAlign: "center"
            };
            $[5] = t3;
        } else {
            t3 = $[5];
        }
        let t4;
        if ($[6] !== t) {
            t4 = t("tableOfContents.emptyState");
            $[6] = t;
            $[7] = t4;
        } else {
            t4 = $[7];
        }
        let t5;
        if ($[8] !== t4) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t3,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    children: t4
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/TableOfContents.jsx",
                    lineNumber: 112,
                    columnNumber: 25
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/TableOfContents.jsx",
                lineNumber: 112,
                columnNumber: 12
            }, this);
            $[8] = t4;
            $[9] = t5;
        } else {
            t5 = $[9];
        }
        return t5;
    }
    let t3;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            width: "100%"
        };
        $[10] = t3;
    } else {
        t3 = $[10];
    }
    let t4;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            p: 2,
            pb: 1
        };
        $[11] = t4;
    } else {
        t4 = $[11];
    }
    let t5;
    if ($[12] !== t) {
        t5 = t("tableOfContents.title");
        $[12] = t;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    let t6;
    if ($[14] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h6",
            sx: t4,
            children: t5
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/TableOfContents.jsx",
            lineNumber: 149,
            columnNumber: 10
        }, this);
        $[14] = t5;
        $[15] = t6;
    } else {
        t6 = $[15];
    }
    let t7;
    if ($[16] !== editor || $[17] !== headings) {
        let t8;
        if ($[19] !== editor) {
            t8 = ({
                "TableOfContents[headings.map()]": (heading)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                        disablePadding: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__["ListItemButton"], {
                            onClick: {
                                "TableOfContents[headings.map() > <ListItemButton>.onClick]": ()=>scrollToNode(editor, heading.key)
                            }["TableOfContents[headings.map() > <ListItemButton>.onClick]"],
                            sx: {
                                pl: heading.level * 2
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                primary: heading.text || "(Empty heading)",
                                primaryTypographyProps: {
                                    variant: heading.level === 1 ? "body1" : "body2",
                                    fontWeight: heading.level === 1 ? 600 : 400,
                                    sx: {
                                        whiteSpace: "normal",
                                        wordBreak: "break-word"
                                    }
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/TableOfContents.jsx",
                                lineNumber: 164,
                                columnNumber: 14
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/TableOfContents.jsx",
                            lineNumber: 160,
                            columnNumber: 105
                        }, this)
                    }, heading.key, false, {
                        fileName: "[project]/src/components/Editor3/components/TableOfContents.jsx",
                        lineNumber: 160,
                        columnNumber: 55
                    }, this)
            })["TableOfContents[headings.map()]"];
            $[19] = editor;
            $[20] = t8;
        } else {
            t8 = $[20];
        }
        t7 = headings.map(t8);
        $[16] = editor;
        $[17] = headings;
        $[18] = t7;
    } else {
        t7 = $[18];
    }
    let t8;
    if ($[21] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
            dense: true,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/TableOfContents.jsx",
            lineNumber: 187,
            columnNumber: 10
        }, this);
        $[21] = t7;
        $[22] = t8;
    } else {
        t8 = $[22];
    }
    let t9;
    if ($[23] !== t6 || $[24] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t3,
            children: [
                t6,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/TableOfContents.jsx",
            lineNumber: 195,
            columnNumber: 10
        }, this);
        $[23] = t6;
        $[24] = t8;
        $[25] = t9;
    } else {
        t9 = $[25];
    }
    return t9;
}
_s(TableOfContents, "fFwkkyvDzJ7OidrQ9XIvRu4PbIo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = TableOfContents;
var _c;
__turbopack_context__.k.register(_c, "TableOfContents");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/VerticalTabsRo.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VerticalTabsRo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tabs/Tabs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tab/Tab.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ChatSidebar.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Chat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Chat.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Settings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Settings.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$History$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/History.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Toc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Toc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$GradeHistory$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/GradeHistory.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$WorkbookSettings$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/WorkbookSettings.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$TableOfContents$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/TableOfContents.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function TabPanel(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "1bc002f507530d364765874ceb488bb5083256ca4398e9db5c268c0c38bbe9fa") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "1bc002f507530d364765874ceb488bb5083256ca4398e9db5c268c0c38bbe9fa";
    }
    let children;
    let index;
    let other;
    let overflowY;
    let value;
    if ($[1] !== props) {
        ({ children, value, index, overflowY, ...other } = props);
        $[1] = props;
        $[2] = children;
        $[3] = index;
        $[4] = other;
        $[5] = overflowY;
        $[6] = value;
    } else {
        children = $[2];
        index = $[3];
        other = $[4];
        overflowY = $[5];
        value = $[6];
    }
    const t0 = value !== index;
    const t1 = `vertical-tabpanel-${index}`;
    const t2 = `vertical-tab-${index}`;
    const t3 = overflowY === "hidden" ? "hidden" : "auto";
    let t4;
    if ($[7] !== t3) {
        t4 = {
            width: "100%",
            minWidth: 0,
            height: "100%",
            overflow: t3
        };
        $[7] = t3;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    if ($[9] !== children || $[10] !== index || $[11] !== value) {
        t5 = value === index && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                height: "100%"
            },
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 69,
            columnNumber: 29
        }, this);
        $[9] = children;
        $[10] = index;
        $[11] = value;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    let t6;
    if ($[13] !== other || $[14] !== t0 || $[15] !== t1 || $[16] !== t2 || $[17] !== t4 || $[18] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            role: "tabpanel",
            hidden: t0,
            id: t1,
            "aria-labelledby": t2,
            style: t4,
            ...other,
            children: t5
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[13] = other;
        $[14] = t0;
        $[15] = t1;
        $[16] = t2;
        $[17] = t4;
        $[18] = t5;
        $[19] = t6;
    } else {
        t6 = $[19];
    }
    return t6;
}
_c = TabPanel;
function a11yProps(index) {
    return {
        id: `vertical-tab-${index}`,
        "aria-controls": `vertical-tabpanel-${index}`,
        "aria-label": index
    };
}
function VerticalTabsRo(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(88);
    if ($[0] !== "1bc002f507530d364765874ceb488bb5083256ca4398e9db5c268c0c38bbe9fa") {
        for(let $i = 0; $i < 88; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "1bc002f507530d364765874ceb488bb5083256ca4398e9db5c268c0c38bbe9fa";
    }
    const { setOpen, open, value, setValue, setDrawerWidth } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("workbook");
    const [isResizing, setIsResizing] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const startXRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](0);
    const startWidthRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](0);
    const wasClosedRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    let t1;
    if ($[1] !== open || $[2] !== setOpen || $[3] !== setValue || $[4] !== value) {
        t1 = ({
            "VerticalTabsRo[handleTabClick]": (newValue)=>{
                if (value === newValue && open) {
                    setOpen(false);
                } else {
                    setOpen(true);
                    setValue(newValue);
                }
            }
        })["VerticalTabsRo[handleTabClick]"];
        $[1] = open;
        $[2] = setOpen;
        $[3] = setValue;
        $[4] = value;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    const handleTabClick = t1;
    let t2;
    if ($[6] !== open || $[7] !== setOpen) {
        t2 = ({
            "VerticalTabsRo[handleMouseDown]": (e)=>{
                setIsResizing(true);
                startXRef.current = e.clientX;
                wasClosedRef.current = !open;
                if (!open) {
                    setOpen(true);
                    startWidthRef.current = 350;
                } else {
                    const drawerElement = e.currentTarget.closest(".MuiDrawer-root");
                    if (drawerElement) {
                        startWidthRef.current = drawerElement.offsetWidth;
                    }
                }
                e.preventDefault();
            }
        })["VerticalTabsRo[handleMouseDown]"];
        $[6] = open;
        $[7] = setOpen;
        $[8] = t2;
    } else {
        t2 = $[8];
    }
    const handleMouseDown = t2;
    let t3;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "VerticalTabsRo[handleMouseUp]": ()=>{
                setIsResizing(false);
            }
        })["VerticalTabsRo[handleMouseUp]"];
        $[9] = t3;
    } else {
        t3 = $[9];
    }
    const handleMouseUp = t3;
    let t4;
    if ($[10] !== isResizing || $[11] !== setDrawerWidth || $[12] !== setOpen) {
        t4 = ({
            "VerticalTabsRo[handleMouseMove]": (e_0)=>{
                if (!isResizing) {
                    return;
                }
                const deltaX = e_0.clientX - startXRef.current;
                const newWidth = startWidthRef.current + deltaX;
                if (newWidth < 250) {
                    setOpen(false);
                    setIsResizing(false);
                } else {
                    if (newWidth <= 800 && setDrawerWidth) {
                        setDrawerWidth(newWidth);
                    }
                }
            }
        })["VerticalTabsRo[handleMouseMove]"];
        $[10] = isResizing;
        $[11] = setDrawerWidth;
        $[12] = setOpen;
        $[13] = t4;
    } else {
        t4 = $[13];
    }
    const handleMouseMove = t4;
    let t5;
    let t6;
    if ($[14] !== handleMouseMove || $[15] !== isResizing) {
        t5 = ({
            "VerticalTabsRo[useEffect()]": ()=>{
                if (isResizing) {
                    document.addEventListener("mousemove", handleMouseMove);
                    document.addEventListener("mouseup", handleMouseUp);
                    return ()=>{
                        document.removeEventListener("mousemove", handleMouseMove);
                        document.removeEventListener("mouseup", handleMouseUp);
                    };
                }
            }
        })["VerticalTabsRo[useEffect()]"];
        t6 = [
            isResizing,
            handleMouseMove
        ];
        $[14] = handleMouseMove;
        $[15] = isResizing;
        $[16] = t5;
        $[17] = t6;
    } else {
        t5 = $[16];
        t6 = $[17];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t5, t6);
    let t7;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            flexGrow: 1,
            bgcolor: "background.paper",
            display: "flex",
            flexDirection: "row",
            borderRight: 1,
            borderColor: "divider",
            position: "relative",
            overflow: "hidden"
        };
        $[18] = t7;
    } else {
        t7 = $[18];
    }
    const t8 = isResizing ? "var(--mui-palette-primary-main, #1976d2)" : "transparent";
    let t9;
    if ($[19] !== t8) {
        t9 = {
            position: "absolute",
            right: 0,
            top: 0,
            bottom: 0,
            width: "5px",
            cursor: "ew-resize",
            backgroundColor: t8,
            zIndex: 100,
            transition: "background-color 0.2s"
        };
        $[19] = t8;
        $[20] = t9;
    } else {
        t9 = $[20];
    }
    let t10;
    if ($[21] !== isResizing) {
        t10 = ({
            "VerticalTabsRo[<div>.onMouseLeave]": (e_2)=>!isResizing && (e_2.currentTarget.style.backgroundColor = "transparent")
        })["VerticalTabsRo[<div>.onMouseLeave]"];
        $[21] = isResizing;
        $[22] = t10;
    } else {
        t10 = $[22];
    }
    let t11;
    if ($[23] !== handleMouseDown || $[24] !== t10 || $[25] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            onMouseDown: handleMouseDown,
            style: t9,
            onMouseEnter: _VerticalTabsRoDivOnMouseEnter,
            onMouseLeave: t10
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 279,
            columnNumber: 11
        }, this);
        $[23] = handleMouseDown;
        $[24] = t10;
        $[25] = t9;
        $[26] = t11;
    } else {
        t11 = $[26];
    }
    let t12;
    if ($[27] !== t) {
        t12 = t("verticalTabsRo.settings");
        $[27] = t;
        $[28] = t12;
    } else {
        t12 = $[28];
    }
    let t13;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            overflow: "hidden",
            minWidth: "2.5rem",
            maxWidth: "2.5rem",
            "& .MuiTab-root": {
                minWidth: "2.5rem",
                maxWidth: "2.5rem",
                padding: "8px 4px",
                margin: 0
            },
            "& .MuiTabs-scroller": {
                borderRight: 1,
                borderColor: "divider",
                margin: 0,
                overflow: "hidden !important"
            },
            "& .MuiTabs-flexContainer": {
                overflow: "hidden"
            }
        };
        $[29] = t13;
    } else {
        t13 = $[29];
    }
    let t14;
    if ($[30] !== handleTabClick) {
        t14 = ({
            "VerticalTabsRo[<Tab>.onClick]": ()=>handleTabClick(0)
        })["VerticalTabsRo[<Tab>.onClick]"];
        $[30] = handleTabClick;
        $[31] = t14;
    } else {
        t14 = $[31];
    }
    let t15;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Toc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 333,
            columnNumber: 11
        }, this);
        $[32] = t15;
    } else {
        t15 = $[32];
    }
    let t16;
    if ($[33] !== t) {
        t16 = a11yProps(t("verticalTabsRo.tableOfContents"));
        $[33] = t;
        $[34] = t16;
    } else {
        t16 = $[34];
    }
    let t17;
    if ($[35] !== t14 || $[36] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: t14,
            label: t15,
            ...t16
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 348,
            columnNumber: 11
        }, this);
        $[35] = t14;
        $[36] = t16;
        $[37] = t17;
    } else {
        t17 = $[37];
    }
    let t18;
    if ($[38] !== handleTabClick) {
        t18 = ({
            "VerticalTabsRo[<Tab>.onClick]": ()=>handleTabClick(1)
        })["VerticalTabsRo[<Tab>.onClick]"];
        $[38] = handleTabClick;
        $[39] = t18;
    } else {
        t18 = $[39];
    }
    let t19;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$History$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 367,
            columnNumber: 11
        }, this);
        $[40] = t19;
    } else {
        t19 = $[40];
    }
    let t20;
    if ($[41] !== t) {
        t20 = a11yProps(t("verticalTabsRo.previousAttempts"));
        $[41] = t;
        $[42] = t20;
    } else {
        t20 = $[42];
    }
    let t21;
    if ($[43] !== t18 || $[44] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: t18,
            label: t19,
            ...t20
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 382,
            columnNumber: 11
        }, this);
        $[43] = t18;
        $[44] = t20;
        $[45] = t21;
    } else {
        t21 = $[45];
    }
    let t22;
    if ($[46] !== handleTabClick) {
        t22 = ({
            "VerticalTabsRo[<Tab>.onClick]": ()=>handleTabClick(2)
        })["VerticalTabsRo[<Tab>.onClick]"];
        $[46] = handleTabClick;
        $[47] = t22;
    } else {
        t22 = $[47];
    }
    let t23;
    if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Chat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 401,
            columnNumber: 11
        }, this);
        $[48] = t23;
    } else {
        t23 = $[48];
    }
    let t24;
    if ($[49] !== t) {
        t24 = a11yProps(t("verticalTabsRo.aiAssistant"));
        $[49] = t;
        $[50] = t24;
    } else {
        t24 = $[50];
    }
    let t25;
    if ($[51] !== t22 || $[52] !== t24) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: t22,
            label: t23,
            ...t24
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 416,
            columnNumber: 11
        }, this);
        $[51] = t22;
        $[52] = t24;
        $[53] = t25;
    } else {
        t25 = $[53];
    }
    let t26;
    if ($[54] !== handleTabClick) {
        t26 = ({
            "VerticalTabsRo[<Tab>.onClick]": ()=>handleTabClick(3)
        })["VerticalTabsRo[<Tab>.onClick]"];
        $[54] = handleTabClick;
        $[55] = t26;
    } else {
        t26 = $[55];
    }
    let t27;
    if ($[56] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Settings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 435,
            columnNumber: 11
        }, this);
        $[56] = t27;
    } else {
        t27 = $[56];
    }
    let t28;
    if ($[57] !== t) {
        t28 = a11yProps(t("verticalTabsRo.settings"));
        $[57] = t;
        $[58] = t28;
    } else {
        t28 = $[58];
    }
    let t29;
    if ($[59] !== t26 || $[60] !== t28) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: t26,
            label: t27,
            ...t28
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 450,
            columnNumber: 11
        }, this);
        $[59] = t26;
        $[60] = t28;
        $[61] = t29;
    } else {
        t29 = $[61];
    }
    let t30;
    if ($[62] !== t12 || $[63] !== t17 || $[64] !== t21 || $[65] !== t25 || $[66] !== t29 || $[67] !== value) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            orientation: "vertical",
            variant: "standard",
            value: value,
            "aria-label": t12,
            sx: t13,
            children: [
                t17,
                t21,
                t25,
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 459,
            columnNumber: 11
        }, this);
        $[62] = t12;
        $[63] = t17;
        $[64] = t21;
        $[65] = t25;
        $[66] = t29;
        $[67] = value;
        $[68] = t30;
    } else {
        t30 = $[68];
    }
    let t31;
    if ($[69] === Symbol.for("react.memo_cache_sentinel")) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$TableOfContents$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 472,
            columnNumber: 11
        }, this);
        $[69] = t31;
    } else {
        t31 = $[69];
    }
    let t32;
    if ($[70] !== value) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
            value: value,
            index: 0,
            overflowY: "auto",
            children: t31
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 479,
            columnNumber: 11
        }, this);
        $[70] = value;
        $[71] = t32;
    } else {
        t32 = $[71];
    }
    let t33;
    if ($[72] === Symbol.for("react.memo_cache_sentinel")) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$GradeHistory$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 487,
            columnNumber: 11
        }, this);
        $[72] = t33;
    } else {
        t33 = $[72];
    }
    let t34;
    if ($[73] !== value) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
            value: value,
            index: 1,
            overflowY: "auto",
            children: t33
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 494,
            columnNumber: 11
        }, this);
        $[73] = value;
        $[74] = t34;
    } else {
        t34 = $[74];
    }
    let t35;
    if ($[75] === Symbol.for("react.memo_cache_sentinel")) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                height: "100%",
                display: "flex",
                flexDirection: "column"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
                lineNumber: 506,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 502,
            columnNumber: 11
        }, this);
        $[75] = t35;
    } else {
        t35 = $[75];
    }
    let t36;
    if ($[76] !== value) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
            value: value,
            index: 2,
            overflowY: "hidden",
            children: t35
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 513,
            columnNumber: 11
        }, this);
        $[76] = value;
        $[77] = t36;
    } else {
        t36 = $[77];
    }
    let t37;
    if ($[78] === Symbol.for("react.memo_cache_sentinel")) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$WorkbookSettings$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 521,
            columnNumber: 11
        }, this);
        $[78] = t37;
    } else {
        t37 = $[78];
    }
    let t38;
    if ($[79] !== value) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
            value: value,
            index: 3,
            overflowY: "auto",
            children: t37
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 528,
            columnNumber: 11
        }, this);
        $[79] = value;
        $[80] = t38;
    } else {
        t38 = $[80];
    }
    let t39;
    if ($[81] !== t11 || $[82] !== t30 || $[83] !== t32 || $[84] !== t34 || $[85] !== t36 || $[86] !== t38) {
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t7,
            children: [
                t11,
                t30,
                t32,
                t34,
                t36,
                t38
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/VerticalTabsRo.jsx",
            lineNumber: 536,
            columnNumber: 11
        }, this);
        $[81] = t11;
        $[82] = t30;
        $[83] = t32;
        $[84] = t34;
        $[85] = t36;
        $[86] = t38;
        $[87] = t39;
    } else {
        t39 = $[87];
    }
    return t39;
}
_s(VerticalTabsRo, "yWPib2vxmzpcRqTrYQpaQ5Dp7dI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c1 = VerticalTabsRo;
function _VerticalTabsRoDivOnMouseEnter(e_1) {
    return e_1.currentTarget.style.backgroundColor = "var(--mui-palette-primary-main, #1976d2)";
}
var _c, _c1;
__turbopack_context__.k.register(_c, "TabPanel");
__turbopack_context__.k.register(_c1, "VerticalTabsRo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/QuizEditor.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormGroup$2f$FormGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormGroup/FormGroup.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Toolbar/Toolbar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$DragIndicator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/DragIndicator.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
// import { GutterContext } from '../context/gutterContext';
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SortableAnswers$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/SortableAnswers.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/QuizPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/useLexicalNodeSelection.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const QuizEditor = ({ className, nodeKey, data })=>{
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('editor.blocks');
    const [editMode, setEditMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLocked, setIsLocked] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [grade, setGrade] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0.0);
    const [attemptedAnswers, setAttemptedAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [correct, setCorrect] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    //   const questionValue = useRef(data);
    const [questionValue, _setQuestionValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(data);
    const [invalidQuestion, setInvalidQuestion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [verifiedAnswers, setVerifiedAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const quizRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { grade: contextGrade, saveGrade } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [isSelected, setSelected, clearSelection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"])(nodeKey);
    const onDelete = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "QuizEditor.useCallback[onDelete]": (payload)=>{
            if (isSelected && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])())) {
                const event = payload;
                event.preventDefault();
                const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isQuizNode"])(node)) {
                    node.remove();
                }
            }
            return false;
        }
    }["QuizEditor.useCallback[onDelete]"], [
        isSelected,
        nodeKey
    ]);
    const onEscape = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "QuizEditor.useCallback[onEscape]": (payload_0)=>{
            if (isSelected) {
                const event_0 = payload_0;
                event_0.preventDefault();
                clearSelection();
                return true;
            }
            return false;
        }
    }["QuizEditor.useCallback[onEscape]"], [
        isSelected,
        clearSelection
    ]);
    const setQuestionValue = (data_0)=>{
        editor.update(()=>{
            const node_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isQuizNode"])(node_0)) {
                node_0.saveData(data_0);
            }
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "QuizEditor.useEffect": ()=>{
            _setQuestionValue(data);
        }
    }["QuizEditor.useEffect"], [
        data
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "QuizEditor.useEffect": ()=>{
            const unregister = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CLICK_COMMAND"], {
                "QuizEditor.useEffect.unregister": (payload_1)=>{
                    const event_1 = payload_1;
                    if (quizRef.current && quizRef.current.contains(event_1.target)) {
                        // Let interactive form elements (Switch, Checkbox, Button, etc.) handle their own clicks.
                        // Use closest() to walk up the DOM — MUI Switch renders <span> elements
                        // (thumb, track) that don't have interactive tags/roles on the direct target.
                        if (event_1.target.closest('input, button, textarea, [role="checkbox"], [role="switch"], [role="button"], label')) {
                            return false;
                        }
                        event_1.preventDefault();
                        if (event_1.shiftKey) {
                            setSelected(!isSelected);
                        } else {
                            clearSelection();
                            setSelected(true);
                        }
                        return true;
                    }
                    return false;
                }
            }["QuizEditor.useEffect.unregister"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_DELETE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_BACKSPACE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_ESCAPE_COMMAND"], onEscape, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]));
            return ({
                "QuizEditor.useEffect": ()=>{
                    unregister();
                }
            })["QuizEditor.useEffect"];
        }
    }["QuizEditor.useEffect"], [
        clearSelection,
        editor,
        isSelected,
        nodeKey,
        onDelete,
        onEscape,
        setSelected
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "QuizEditor.useEffect": ()=>{
            // Restore progress from UnitContext if nodeKey is provided
            if (nodeKey && contextGrade) {
                const inProgress = contextGrade?.data?.[nodeKey] || {};
                if (inProgress.attemptedAnswers || inProgress.verifiedAnswers) {
                    setAttemptedAnswers(inProgress.attemptedAnswers || {});
                    setVerifiedAnswers(inProgress.verifiedAnswers || {});
                    setGrade(inProgress.accuracy || 0);
                    setIsLocked(inProgress.complete || false);
                }
            }
        }
    }["QuizEditor.useEffect"], [
        nodeKey,
        contextGrade
    ]);
    const onClick = ()=>{
        if (editMode) {
            return;
        }
        setEditMode(true);
        startEdit();
    };
    const onValueChange = (evt)=>{
        let value = evt.target.value;
        let invalid = false;
        setInvalidQuestion(invalid);
        _setQuestionValue(value);
        setQuestionValue(value);
    };
    const onCorrectChange = (evt_0, id)=>{
        let checked = evt_0.target.checked;
        let tmp = JSON.parse(JSON.stringify(questionValue));
        tmp[id].correct = checked;
        _setQuestionValue(tmp);
        setQuestionValue(tmp);
    };
    const onQuestionChange = (evt_1, id_0)=>{
        let value_0 = evt_1.target.value;
        let tmp_0 = JSON.parse(JSON.stringify(questionValue));
        tmp_0[id_0].answer = value_0;
        _setQuestionValue(tmp_0);
        setQuestionValue(tmp_0);
    };
    const gradeAnswer = async (e, thisKey, thisAnswer, questionContent)=>{
        e.preventDefault();
        e.stopPropagation();
        const { correct: isCorrect } = thisAnswer;
        const isChecked = e.target.checked;
        let _verifiedAnswers = {
            ...verifiedAnswers
        };
        let _attemptedAnswers = {
            ...attemptedAnswers
        };
        let _isLocked = isLocked;
        let _grade = grade;
        let _correct = {};
        if (!_verifiedAnswers) {
            _verifiedAnswers = {};
        }
        if (!_attemptedAnswers) {
            _attemptedAnswers = {};
        }
        questionContent.forEach((question, questionKey)=>{
            if (question.correct === true) {
                _correct[questionKey] = question;
            }
        });
        _attemptedAnswers[thisKey] = thisAnswer;
        if (isCorrect === true && isChecked === true) {
            _verifiedAnswers[thisKey] = thisAnswer;
        } else if (isCorrect === true && isChecked === false) {
            delete _verifiedAnswers[thisKey];
            delete _attemptedAnswers[thisKey];
        } else if (isCorrect === false && isChecked === false) {
            delete _attemptedAnswers[thisKey];
        }
        const correctArr = Object.entries(_correct);
        const verifiedArr = Object.entries(_verifiedAnswers);
        const attemptedArr = Object.entries(_attemptedAnswers);
        _grade = Math.floor(verifiedArr.length / correctArr.length * 100);
        let thisExerciseComplete = false;
        if (attemptedArr.length === correctArr.length) {
            _isLocked = true;
        }
        if (verifiedArr.length === correctArr.length) {
            _isLocked = true;
            thisExerciseComplete = true;
        }
        // Save completion tracking to UnitContext
        if (nodeKey && saveGrade) {
            try {
                let savedGradeCopy = JSON.parse(JSON.stringify(contextGrade?.data || {}));
                savedGradeCopy[nodeKey] = {
                    accuracy: _grade,
                    attemptedAnswers: _attemptedAnswers,
                    verifiedAnswers: _verifiedAnswers,
                    complete: thisExerciseComplete,
                    percentComplete: Math.floor(attemptedArr.length / correctArr.length * 100)
                };
                await saveGrade(savedGradeCopy);
            } catch (error) {
                console.error("Failed to save grade progress for QuizEditor:", error);
            // Continue with local state update even if save fails
            }
        }
        setAttemptedAnswers(_attemptedAnswers);
        setVerifiedAnswers(_verifiedAnswers);
        setIsLocked(_isLocked);
        setCorrect(_correct);
        setGrade(_grade);
    };
    const onQuestionReorder = (answers)=>{
        _setQuestionValue(answers);
        setQuestionValue(answers);
    };
    const onQuestionDelete = (id_1)=>{
        let tmp_1 = JSON.parse(JSON.stringify(questionValue));
        tmp_1.splice(id_1, 1);
        _setQuestionValue(tmp_1);
        setQuestionValue(tmp_1);
    };
    const onAddQuestion = (evt_2)=>{
        evt_2.preventDefault();
        evt_2.stopPropagation();
        let tmp_2 = JSON.parse(JSON.stringify(questionValue));
        const nextId = tmp_2.length + 1;
        tmp_2.push({
            id: `id-${nextId}`,
            answer: "",
            correct: false
        });
        setQuestionValue(tmp_2);
    };
    const save = ()=>{
        setQuestionValue(questionValue);
        setInvalidQuestion(false);
        setEditMode(false);
    };
    const reset = (e_0)=>{
        e_0.preventDefault();
        e_0.stopPropagation();
        setAttemptedAnswers({});
        setVerifiedAnswers({});
        setIsLocked(false);
        setGrade(0.0);
    };
    const remove = ()=>{
        console.log('remove');
    };
    const startEdit = ()=>{
        console.log('startEdit');
    };
    let checkboxes = [];
    if (questionValue && questionValue.length > 0) {
        checkboxes = questionValue.map((data_1, key)=>{
            let _attemptedAnswers_0 = attemptedAnswers || {};
            if (!_attemptedAnswers_0) {
                _attemptedAnswers_0 = {};
            }
            let checked_0 = false;
            if (_attemptedAnswers_0[key]) {
                checked_0 = true;
            }
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    checked: checked_0,
                    disabled: isLocked,
                    onClick: (e_1)=>{
                        gradeAnswer(e_1, key, data_1, questionValue);
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                    lineNumber: 266,
                    columnNumber: 51
                }, ("TURBOPACK compile-time value", void 0)),
                label: data_1.answer
            }, key, false, {
                fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                lineNumber: 266,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: quizRef,
        "data-tour": "quiz-block",
        contentEditable: false,
        readOnly: true,
        style: {
            display: 'flex',
            flexDirection: 'column',
            marginBottom: '2rem',
            border: isSelected ? '2px solid var(--mui-palette-primary-main, #1976d2)' : '1px solid transparent',
            borderRadius: '4px',
            padding: '8px',
            cursor: 'pointer'
        },
        className: "jsx-b525aed033b0f219" + " " + (className || ""),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "b525aed033b0f219",
                children: "figure[data-block=true]{margin:0}"
            }, void 0, false, void 0, ("TURBOPACK compile-time value", void 0)),
            !editMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        elevation: 2,
                        sx: {
                            flexGrow: 1,
                            width: '100%',
                            maxWidth: '900px'
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    size: "small",
                                    onClick: onClick,
                                    children: t('quizEditor.edit')
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                                    lineNumber: 292,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    sx: {
                                        flexGrow: 1
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                                    lineNumber: 295,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    size: "small",
                                    onClick: reset,
                                    children: t('quizEditor.reset')
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                                    lineNumber: 298,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    children: t('quizEditor.gradeDisplay', {
                                        score: grade
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                                    lineNumber: 301,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                            lineNumber: 291,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                        lineNumber: 286,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormGroup$2f$FormGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        children: checkboxes
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                        lineNumber: 308,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true),
            editMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        elevation: 3,
                        sx: {
                            flexGrow: 1,
                            marginBottom: '1rem'
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    size: "small",
                                    disabled: invalidQuestion,
                                    onClick: save,
                                    children: invalidQuestion ? t('quizEditor.invalid') : t('quizEditor.done')
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                                    lineNumber: 318,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    sx: {
                                        flexGrow: 1
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                                    lineNumber: 321,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                            lineNumber: 317,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                        lineNumber: 313,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SortableAnswers$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        answers: questionValue,
                        onQuestionChange: onQuestionChange,
                        onCorrectChange: onCorrectChange,
                        onQuestionDelete: onQuestionDelete,
                        onQuestionReorder: onQuestionReorder
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                        lineNumber: 332,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        direction: "row",
                        spacing: 2,
                        alignItems: "center",
                        border: "thin solid",
                        borderColor: "divider",
                        padding: "0.5rem",
                        margin: "0.5rem",
                        maxWidth: "40rem",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$DragIndicator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                                lineNumber: 334,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                placeholder: t('quizEditor.addAnswer'),
                                onClick: onAddQuestion,
                                fullWidth: true
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                                lineNumber: 335,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
                        lineNumber: 333,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/QuizEditor.jsx",
        lineNumber: 271,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(QuizEditor, "JWdNyLaulh39npFMz+EnaCfn+P8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"]
    ];
});
_c = QuizEditor;
const __TURBOPACK__default__export__ = QuizEditor;
var _c;
__turbopack_context__.k.register(_c, "QuizEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/QuizComponent.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>QuestionBlockRo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview QuestionBlockRo1.js - A React component for displaying a read-only
 * version of the QuestionBlock component.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormGroup$2f$FormGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormGroup/FormGroup.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Toolbar/Toolbar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Warning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use strict';
;
;
;
;
;
;
;
;
;
;
;
function QuestionBlockRo(props) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('workbook');
    const { nodeKey, data } = props;
    const { grade, saveGrade } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    console.log('QuestionBlockRo.grade', grade);
    const gradeData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "QuestionBlockRo.useMemo[gradeData]": ()=>{
            if (!grade?.data) return {};
            if (typeof grade.data === 'string') {
                try {
                    return JSON.parse(grade.data);
                } catch  {
                    return {};
                }
            }
            return grade.data;
        }
    }["QuestionBlockRo.useMemo[gradeData]"], [
        grade?.data
    ]);
    const inProgress = gradeData[nodeKey] || {};
    const content = data || [];
    // let questionContent = shuffle([...content]);
    let questionContent = [
        ...content
    ];
    const indexContent = {};
    const correct = {};
    content.forEach((q, qk)=>{
        console.log('......!q', q);
        indexContent[q.answer] = q;
        if (q.correct === true) {
            correct[qk] = q;
        }
    });
    console.log('QuestionBlock.nodeKey', nodeKey, 'type:', typeof nodeKey);
    console.log('QuestionBlock.questionContent', questionContent);
    console.log('QuestionBlock.grade.data keys:', gradeData ? Object.keys(gradeData) : 'no data');
    console.log('QuestionBlock.grade.data[nodeKey]:', gradeData[nodeKey]);
    console.log('QuestionBlockRo.inProgress', inProgress);
    const accuracy = inProgress?.accuracy || 0;
    const complete = inProgress?.complete || false;
    const percentComplete = inProgress?.percentComplete || 0;
    const attemptedAnswers = inProgress?.attemptedAnswers || [];
    const correctAnswers = inProgress?.correctAnswers || [];
    // Calculate if quiz should be locked
    const correctArrLen = Object.entries(correct).length || 0;
    const attemptedCount = Object.keys(attemptedAnswers).length;
    const isLocked = complete || attemptedCount >= correctArrLen;
    const gradeAnswer = async (e, thisKey, thisAnswer)=>{
        // e.preventDefault();
        // e.stopPropagation();
        // Don't allow changes if already locked
        if (isLocked) {
            e.preventDefault();
            return;
        }
        const { correct: isCorrect } = thisAnswer;
        const isChecked = e.target.checked;
        const correctArrLen_0 = Object.entries(correct).length || 0;
        console.log('meow: ?thisAnswer', thisAnswer);
        const savedGrade = gradeData;
        // let { saveGrade } = this.props;
        let thisExerciseDone = false;
        attemptedAnswers[thisKey] = thisAnswer?.answer;
        if (isCorrect === true && isChecked === true) {
            correctAnswers[thisKey] = thisAnswer?.answer;
        } else if (isCorrect === true && isChecked === false) {
            delete correctAnswers[thisKey];
            delete attemptedAnswers[thisKey];
        } else if (isCorrect === false && isChecked === false) {
            delete attemptedAnswers[thisKey];
        }
        const verifiedArr = Object.entries(correctAnswers);
        const attemptedArr = Object.entries(attemptedAnswers);
        let _grade = Math.floor(verifiedArr.length / correctArrLen_0 * 100);
        console.log('attemptedArr.length === correctArrLen', attemptedArr.length, correctArrLen_0);
        console.log('verifiedArr.length === correctArrLen', verifiedArr.length, correctArrLen_0);
        // Lock when number of attempts equals number of correct answers
        if (attemptedArr.length >= correctArrLen_0) {
            thisExerciseDone = true;
        }
        console.log('thisExerciseDone', thisExerciseDone);
        let savedGradeCopy = Object.assign({}, savedGrade);
        savedGradeCopy[nodeKey] = {
            accuracy: _grade,
            attemptedAnswers,
            complete: thisExerciseDone,
            correctAnswers,
            percentComplete: Math.floor(attemptedArr.length / correctArrLen_0 * 100)
        };
        console.log('savedGradeCopy', savedGradeCopy);
        await saveGrade(savedGradeCopy);
    };
    var className = 'Editor-question';
    let checkboxes;
    if (questionContent) {
        checkboxes = questionContent.map((data_0, key)=>{
            // Use != null to handle sparse arrays that become [null,null,...] after JSON round-trip
            const wasAttempted = attemptedAnswers[key] != null;
            const isCorrectAnswer = data_0.correct === true;
            const checked = wasAttempted;
            // Only highlight the answer the user actually selected
            const showCorrectFeedback = isLocked && wasAttempted && isCorrectAnswer;
            const showWrongFeedback = isLocked && wasAttempted && !isCorrectAnswer;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                "data-tour": "quiz-answers",
                control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    checked: checked,
                    disabled: isLocked,
                    onChange: async (e_0)=>{
                        gradeAnswer(e_0, key, data_0);
                    },
                    sx: isLocked && wasAttempted ? {
                        '&.Mui-disabled': {
                            color: showCorrectFeedback ? 'success.main' : 'warning.main'
                        }
                    } : undefined
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/QuizComponent.jsx",
                    lineNumber: 128,
                    columnNumber: 76
                }, this),
                label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        display: 'flex',
                        alignItems: 'center',
                        gap: 0.5
                    },
                    children: [
                        data_0.answer,
                        showCorrectFeedback && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                fontSize: 18,
                                color: 'success.main'
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/QuizComponent.jsx",
                            lineNumber: 140,
                            columnNumber: 39
                        }, this),
                        showWrongFeedback && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                fontSize: 18,
                                color: 'warning.main'
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/QuizComponent.jsx",
                            lineNumber: 144,
                            columnNumber: 37
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/QuizComponent.jsx",
                    lineNumber: 134,
                    columnNumber: 33
                }, this),
                sx: isLocked && wasAttempted ? {
                    color: showCorrectFeedback ? 'success.main' : 'warning.main'
                } : undefined
            }, key, false, {
                fileName: "[project]/src/components/Editor3/components/QuizComponent.jsx",
                lineNumber: 128,
                columnNumber: 14
            }, this);
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        "data-tour": "quiz-block",
        // Don't use contentEditable={false} as it blocks child interactions
        suppressContentEditableWarning: true,
        style: {
            userSelect: 'none'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                elevation: 2,
                sx: {
                    flexGrow: 1,
                    marginBottom: '1rem'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                flexGrow: 1
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/QuizComponent.jsx",
                            lineNumber: 163,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            children: t('quizComponent.gradeDisplay', {
                                score: accuracy
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/QuizComponent.jsx",
                            lineNumber: 167,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/QuizComponent.jsx",
                    lineNumber: 162,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/QuizComponent.jsx",
                lineNumber: 158,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormGroup$2f$FormGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: checkboxes
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/QuizComponent.jsx",
                lineNumber: 177,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/QuizComponent.jsx",
        lineNumber: 153,
        columnNumber: 10
    }, this);
// return (<QuestionBlockRo1
//   inProgressContent={indexContent}
//   questionContent={questionContent}
//   accuracy={accuracy}
//   complete={complete}
//   correct={correct}
//   percentComplete={percentComplete}
//   attemptedAnswers={attemptedAnswers}
//   correctAnswers={correctAnswers}
//   nodeKey={nodeKey}
//   grade={grade}
//   saveGrade={saveGrade}
// />)
}
_s(QuestionBlockRo, "EBNCufv5csOa19vdaqbcrHVx3ko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = QuestionBlockRo;
var _c;
__turbopack_context__.k.register(_c, "QuestionBlockRo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/PromptMethodSelector.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AllowedInputSelector",
    ()=>AllowedInputSelector,
    "PromptMethodSelector",
    ()=>PromptMethodSelector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Menu/Menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemIcon/ListItemIcon.js [app-client] (ecmascript) <export default as ListItemIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Check.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$VideoSettings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/VideoSettings.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Input.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
const AllowedInputSelector = /*#__PURE__*/ _s(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](_c = _s(({ ids, defaultAllowedInputs = [
    'text'
], allowedInput = [], setAllowedInput })=>{
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('editor.ai');
    const [anchorEl, setAnchorEl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const [_allowedInput, setAllowedInputLocal] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](allowedInput.length > 0 ? [
        allowedInput[0]
    ] : defaultAllowedInputs);
    const open = Boolean(anchorEl);
    // Sync external allowedInput prop with internal state
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "AllowedInputSelector.useEffect": ()=>{
            if (allowedInput && allowedInput.length > 0) {
                const selected = [
                    allowedInput[0]
                ];
                if (JSON.stringify(selected) !== JSON.stringify(_allowedInput)) {
                    setAllowedInputLocal(selected);
                }
            }
        }
    }["AllowedInputSelector.useEffect"], [
        allowedInput
    ]);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
        setAllowedInput(_allowedInput);
    };
    const handleSelect = (event)=>{
        const value = event.target.getAttribute('value');
        // Single-select: always set to just the clicked value
        setAllowedInputLocal([
            value
        ]);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "open-allowed-inputs-button",
                color: "inherit",
                "aria-controls": open ? 'allowed-inputs-menu' : undefined,
                "aria-haspopup": "true",
                "aria-expanded": open ? 'true' : undefined,
                onClick: open ? handleClose : handleClick,
                sx: {
                    minWidth: '3rem',
                    margin: '0 0 0 0.5rem'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 63,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    " ",
                    t('promptMethodSelector.inputButton')
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                lineNumber: 50,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                id: "allowed-inputs-menu",
                anchorEl: anchorEl,
                open: open,
                onClose: handleClose,
                MenuListProps: {
                    'aria-labelledby': 'open-allowed-inputs-button'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: handleSelect,
                        style: {
                            textAlign: 'right'
                        },
                        value: "text",
                        children: [
                            _allowedInput.includes('text') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                    lineNumber: 82,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                lineNumber: 81,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            t('promptMethodSelector.menuItems.text')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 74,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: handleSelect,
                        value: "audio",
                        children: [
                            _allowedInput.includes('audio') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                    lineNumber: 89,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                lineNumber: 88,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            t('promptMethodSelector.menuItems.audio')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 85,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: handleSelect,
                        value: "image",
                        children: [
                            _allowedInput.includes('image') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                    lineNumber: 96,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                lineNumber: 95,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            t('promptMethodSelector.menuItems.image')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 92,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: handleSelect,
                        value: "writing",
                        children: [
                            _allowedInput.includes('writing') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                    lineNumber: 103,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                lineNumber: 102,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            t('promptMethodSelector.menuItems.drawing')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 99,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: handleSelect,
                        value: "video",
                        style: {
                            textAlign: 'right'
                        },
                        children: [
                            _allowedInput.includes('video') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                    lineNumber: 114,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                lineNumber: 113,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            t('promptMethodSelector.menuItems.video')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 106,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                lineNumber: 65,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
}, "J17IrRthfexdlZ89Xf5MaOqiPsM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
})), "J17IrRthfexdlZ89Xf5MaOqiPsM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c1 = AllowedInputSelector;
const PromptMethodSelector = /*#__PURE__*/ _s1(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](_c2 = _s1(({ ids, defaultPromptMethods = [
    'text',
    'audio',
    'writing'
], promptMethod = [], setPromptMethod })=>{
    _s1();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('editor.ai');
    const [anchorEl, setAnchorEl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const [_promptMethods, setPromptMethods] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](promptMethod.length > 0 ? promptMethod : []);
    const open = Boolean(anchorEl);
    // Sync external promptMethod prop with internal state
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "PromptMethodSelector.useEffect": ()=>{
            if (promptMethod && promptMethod.length > 0) {
                const newMethodsStr = JSON.stringify(promptMethod);
                const currentMethodsStr = JSON.stringify(_promptMethods);
                if (newMethodsStr !== currentMethodsStr) {
                    setPromptMethods(promptMethod);
                }
            }
        }
    }["PromptMethodSelector.useEffect"], [
        promptMethod
    ]);
    // if the working methods change, update the promptMethod
    // React.useEffect(() => {
    //     console.log('useEffect._promptMethods', _promptMethods);
    //     setPromptMethod(_promptMethods);
    // }, [JSON.stringify(_promptMethods)]);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
        setPromptMethod(_promptMethods);
    };
    const handleSelect = (event)=>{
        const value = event.target.getAttribute('value');
        const mergeMethods = _promptMethods.includes(value) ? _promptMethods.filter((x)=>x !== value) : [
            ..._promptMethods,
            value
        ];
        setPromptMethods(mergeMethods);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "open-prompt-methods-button",
                color: "inherit",
                "aria-controls": open ? 'prompt-methods-menu' : undefined,
                "aria-haspopup": "true",
                "aria-expanded": open ? 'true' : undefined,
                onClick: open ? handleClose : handleClick,
                sx: {
                    minWidth: '3rem',
                    margin: '0 0 0 0.5rem'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$VideoSettings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 188,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    " ",
                    t('promptMethodSelector.outputButton')
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                lineNumber: 175,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                id: "prompt-methods-menu",
                anchorEl: anchorEl,
                open: open,
                onClose: handleClose,
                MenuListProps: {
                    'aria-labelledby': 'open-prompt-methods-button'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: handleSelect,
                        style: {
                            textAlign: 'right'
                        },
                        value: "text",
                        children: [
                            _promptMethods.includes('text') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                    lineNumber: 207,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                lineNumber: 206,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            t('promptMethodSelector.menuItems.text')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 199,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: handleSelect,
                        value: "audio",
                        children: [
                            _promptMethods.includes('audio') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                    lineNumber: 214,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                lineNumber: 213,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            t('promptMethodSelector.menuItems.audio')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 210,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: handleSelect,
                        value: "image",
                        children: [
                            _promptMethods.includes('image') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                    lineNumber: 221,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                lineNumber: 220,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            t('promptMethodSelector.menuItems.image')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 217,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: handleSelect,
                        value: "writing",
                        children: [
                            _promptMethods.includes('writing') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                    lineNumber: 228,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                lineNumber: 227,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            t('promptMethodSelector.menuItems.drawing')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 224,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: handleSelect,
                        value: "video",
                        style: {
                            textAlign: 'right'
                        },
                        children: [
                            _promptMethods.includes('video') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                    lineNumber: 239,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                                lineNumber: 238,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            t('promptMethodSelector.menuItems.video')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                        lineNumber: 231,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/PromptMethodSelector.jsx",
                lineNumber: 190,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
}, "bVs5uIywI3zbK/9M5Cy6P7J3Hp8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
})), "bVs5uIywI3zbK/9M5Cy6P7J3Hp8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c3 = PromptMethodSelector;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "AllowedInputSelector$React.memo");
__turbopack_context__.k.register(_c1, "AllowedInputSelector");
__turbopack_context__.k.register(_c2, "PromptMethodSelector$React.memo");
__turbopack_context__.k.register(_c3, "PromptMethodSelector");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/AnswerEditor.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ActionsMenu",
    ()=>ActionsMenu,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$DataGrid$2f$DataGrid$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/DataGrid/DataGrid.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Menu/Menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContentText$2f$DialogContentText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContentText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContentText/DialogContentText.js [app-client] (ecmascript) <export default as DialogContentText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextareaAutosize/TextareaAutosize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Autocomplete/Autocomplete.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useAutocomplete$2f$useAutocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/useAutocomplete/useAutocomplete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/useLexicalNodeSelection.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MoreVert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
// Type import removed - not needed in runtime JS
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/AnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PromptMethodSelector$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/PromptMethodSelector.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const filter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useAutocomplete$2f$useAutocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createFilterOptions"])();
const columns = [
    {
        field: 'phrase',
        headerName: 'Phrase',
        flex: 1,
        minWidth: 100
    },
    {
        field: 'pronunciation',
        headerName: 'Pronunciation',
        flex: 1,
        minWidth: 100
    },
    {
        field: 'definition',
        headerName: 'Definition',
        flex: 1,
        minWidth: 200
    }
];
function ActionsMenu(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(29);
    if ($[0] !== "c13a8207598bdb72c3cb211b1bada5d20781930f9c082bfe8f96d961455eabc6") {
        for(let $i = 0; $i < 29; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c13a8207598bdb72c3cb211b1bada5d20781930f9c082bfe8f96d961455eabc6";
    }
    const { ids, removeWordIDs, requestDefinition, setRequestDefinition } = t0;
    const [anchorEl, setAnchorEl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const open = Boolean(anchorEl);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "ActionsMenu[handleClick]": (event)=>{
                setAnchorEl(event.currentTarget);
            }
        })["ActionsMenu[handleClick]"];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const handleClick = t1;
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "ActionsMenu[handleClose]": ()=>{
                setAnchorEl(null);
            }
        })["ActionsMenu[handleClose]"];
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const handleClose = t2;
    let t3;
    if ($[3] !== ids || $[4] !== removeWordIDs) {
        t3 = ({
            "ActionsMenu[removeFromAssignment]": ()=>{
                console.log("removeFromAssignment", ids);
                removeWordIDs(ids);
                setAnchorEl(null);
            }
        })["ActionsMenu[removeFromAssignment]"];
        $[3] = ids;
        $[4] = removeWordIDs;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const removeFromAssignment = t3;
    const t4 = open ? "allowed-inputs-menu" : undefined;
    const t5 = open ? "true" : undefined;
    let t6;
    let t7;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            minWidth: "3rem",
            margin: "0 0 0 0.5rem"
        };
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 102,
            columnNumber: 10
        }, this);
        $[6] = t6;
        $[7] = t7;
    } else {
        t6 = $[6];
        t7 = $[7];
    }
    let t8;
    if ($[8] !== t4 || $[9] !== t5) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            id: "open-allowed-inputs-button",
            color: "inherit",
            "aria-controls": t4,
            "aria-haspopup": "true",
            "aria-expanded": t5,
            onClick: handleClick,
            sx: t6,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 111,
            columnNumber: 10
        }, this);
        $[8] = t4;
        $[9] = t5;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            "aria-labelledby": "open-allowed-inputs-button"
        };
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    let t10;
    if ($[12] !== removeFromAssignment) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            onClick: removeFromAssignment,
            children: "Remove from Exercise"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 129,
            columnNumber: 11
        }, this);
        $[12] = removeFromAssignment;
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] !== requestDefinition || $[15] !== setRequestDefinition) {
        t11 = !requestDefinition && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            onClick: {
                "ActionsMenu[<MenuItem>.onClick]": ()=>{
                    console.log("setRequestDefinition", true);
                    setRequestDefinition(true);
                }
            }["ActionsMenu[<MenuItem>.onClick]"],
            children: "Prompt for a definition"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 137,
            columnNumber: 33
        }, this);
        $[14] = requestDefinition;
        $[15] = setRequestDefinition;
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    let t12;
    if ($[17] !== requestDefinition || $[18] !== setRequestDefinition) {
        t12 = requestDefinition && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            onClick: {
                "ActionsMenu[<MenuItem>.onClick]": ()=>{
                    setRequestDefinition(false);
                }
            }["ActionsMenu[<MenuItem>.onClick]"],
            children: "Prompt for Word"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 151,
            columnNumber: 32
        }, this);
        $[17] = requestDefinition;
        $[18] = setRequestDefinition;
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    let t13;
    if ($[20] !== anchorEl || $[21] !== open || $[22] !== t10 || $[23] !== t11 || $[24] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
            id: "allowed-inputs-menu",
            anchorEl: anchorEl,
            open: open,
            onClose: handleClose,
            MenuListProps: t9,
            children: [
                t10,
                t11,
                t12
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 164,
            columnNumber: 11
        }, this);
        $[20] = anchorEl;
        $[21] = open;
        $[22] = t10;
        $[23] = t11;
        $[24] = t12;
        $[25] = t13;
    } else {
        t13 = $[25];
    }
    let t14;
    if ($[26] !== t13 || $[27] !== t8) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t8,
                t13
            ]
        }, void 0, true);
        $[26] = t13;
        $[27] = t8;
        $[28] = t14;
    } else {
        t14 = $[28];
    }
    return t14;
}
_s(ActionsMenu, "+aMDa7FPcESUyQDF1vq0RSMn4/k=");
_c = ActionsMenu;
const AnswerEditor = /*#__PURE__*/ _s1(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](_c1 = _s1(function AnswerEditor(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(158);
    if ($[0] !== "c13a8207598bdb72c3cb211b1bada5d20781930f9c082bfe8f96d961455eabc6") {
        for(let $i = 0; $i < 158; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c13a8207598bdb72c3cb211b1bada5d20781930f9c082bfe8f96d961455eabc6";
    }
    const { nodeKey, requestDefinition, wordIDs, allowedInput, promptMethod } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.blocks");
    const [value, setValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const [open, toggleOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const [gridSelection, setGridSelection] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](t1);
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            phrase: "",
            definition: "",
            pronunciation: ""
        };
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const [dialogValue, setDialogValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](t2);
    const [title, setTitle] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("Short Answer Exercise");
    let t3;
    let t4;
    if ($[3] !== requestDefinition) {
        t3 = ({
            "AnswerEditor[useEffect()]": ()=>{
                const titleSuffix = requestDefinition ? "Definition" : "Word";
                const _title = "Short Answer Exercise by " + titleSuffix;
                setTitle(_title);
            }
        })["AnswerEditor[useEffect()]"];
        t4 = [
            requestDefinition
        ];
        $[3] = requestDefinition;
        $[4] = t3;
        $[5] = t4;
    } else {
        t3 = $[4];
        t4 = $[5];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t3, t4);
    const { wordMapId } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { unit } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let rows;
    if ($[6] !== wordIDs || $[7] !== wordMapId) {
        rows = [];
        if (wordIDs) {
            wordIDs.forEach({
                "AnswerEditor[wordIDs.forEach()]": (id)=>{
                    const word = wordMapId[id];
                    if (word) {
                        rows.push({
                            id: word.id,
                            phrase: word.phrase,
                            pronunciation: word.pronunciation,
                            definition: word.definition
                        });
                    }
                }
            }["AnswerEditor[wordIDs.forEach()]"]);
        }
        $[6] = wordIDs;
        $[7] = wordMapId;
        $[8] = rows;
    } else {
        rows = $[8];
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const answerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [isSelected, setSelected, clearSelection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"])(nodeKey);
    let t5;
    if ($[9] !== wordMapId) {
        t5 = Object.values(wordMapId);
        $[9] = wordMapId;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    const _dictionary = t5;
    let t6;
    if ($[11] !== isSelected || $[12] !== nodeKey || $[13] !== wordIDs) {
        t6 = ({
            "AnswerEditor[onDelete]": async (payload)=>{
                if (isSelected && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])())) {
                    const event = payload;
                    event.preventDefault();
                    const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isAnswerNode"])(node)) {
                        node.remove();
                        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                        const _operations = [];
                        wordIDs.forEach({
                            "AnswerEditor[onDelete > wordIDs.forEach()]": (id_0)=>{
                                _operations.push(client.models.UnitWord.delete({
                                    id: id_0
                                }));
                            }
                        }["AnswerEditor[onDelete > wordIDs.forEach()]"]);
                        await Promise.allSettled(_operations);
                    }
                }
                return false;
            }
        })["AnswerEditor[onDelete]"];
        $[11] = isSelected;
        $[12] = nodeKey;
        $[13] = wordIDs;
        $[14] = t6;
    } else {
        t6 = $[14];
    }
    const onDelete = t6;
    let t7;
    if ($[15] !== isSelected) {
        t7 = ({
            "AnswerEditor[onEnter]": (payload_0)=>{
                if (isSelected && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])())) {
                    const event_0 = payload_0;
                    event_0.preventDefault();
                    const autocompleteInput = document.querySelector("#add-new-word input");
                    if (autocompleteInput) {
                        autocompleteInput.focus();
                    }
                    return true;
                }
                return false;
            }
        })["AnswerEditor[onEnter]"];
        $[15] = isSelected;
        $[16] = t7;
    } else {
        t7 = $[16];
    }
    const onEnter = t7;
    let t8;
    if ($[17] !== clearSelection || $[18] !== isSelected) {
        t8 = ({
            "AnswerEditor[onEscape]": (payload_1)=>{
                if (isSelected) {
                    const event_1 = payload_1;
                    event_1.preventDefault();
                    clearSelection();
                    return true;
                }
                return false;
            }
        })["AnswerEditor[onEscape]"];
        $[17] = clearSelection;
        $[18] = isSelected;
        $[19] = t8;
    } else {
        t8 = $[19];
    }
    const onEscape = t8;
    let t9;
    if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = ({
            "AnswerEditor[handleClose]": ()=>{
                setDialogValue({
                    phrase: "",
                    pronunciation: "",
                    definition: ""
                });
                toggleOpen(false);
            }
        })["AnswerEditor[handleClose]"];
        $[20] = t9;
    } else {
        t9 = $[20];
    }
    const handleClose = t9;
    let t10;
    if ($[21] !== editor || $[22] !== nodeKey || $[23] !== unit) {
        t10 = ({
            "AnswerEditor[addWordID]": (id_1)=>{
                editor.update({
                    "AnswerEditor[addWordID > editor.update()]": async ()=>{
                        const node_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isAnswerNode"])(node_0)) {
                            node_0.appendId(id_1);
                            const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                            const { data: word_0 } = await client_0.models.Word.get({
                                id: id_1
                            });
                            if (word_0) {
                                await client_0.models.UnitWord.create({
                                    unitID: unit.id,
                                    wordID: id_1
                                });
                            }
                        }
                    }
                }["AnswerEditor[addWordID > editor.update()]"]);
            }
        })["AnswerEditor[addWordID]"];
        $[21] = editor;
        $[22] = nodeKey;
        $[23] = unit;
        $[24] = t10;
    } else {
        t10 = $[24];
    }
    const addWordID = t10;
    let t11;
    if ($[25] !== editor || $[26] !== nodeKey) {
        t11 = ({
            "AnswerEditor[setRequestDefinition]": (payload_2)=>{
                editor.update({
                    "AnswerEditor[setRequestDefinition > editor.update()]": async ()=>{
                        const node_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isAnswerNode"])(node_1)) {
                            node_1.setRequestDefinition(payload_2);
                        }
                    }
                }["AnswerEditor[setRequestDefinition > editor.update()]"]);
            }
        })["AnswerEditor[setRequestDefinition]"];
        $[25] = editor;
        $[26] = nodeKey;
        $[27] = t11;
    } else {
        t11 = $[27];
    }
    const setRequestDefinition = t11;
    let t12;
    if ($[28] !== editor || $[29] !== nodeKey) {
        t12 = ({
            "AnswerEditor[setAllowedInput]": (payload_3)=>{
                editor.update({
                    "AnswerEditor[setAllowedInput > editor.update()]": async ()=>{
                        const node_2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isAnswerNode"])(node_2)) {
                            console.log("setAllowedInput", payload_3);
                            node_2.setAllowedInput(payload_3);
                        }
                    }
                }["AnswerEditor[setAllowedInput > editor.update()]"]);
            }
        })["AnswerEditor[setAllowedInput]"];
        $[28] = editor;
        $[29] = nodeKey;
        $[30] = t12;
    } else {
        t12 = $[30];
    }
    const setAllowedInput = t12;
    let t13;
    if ($[31] !== editor || $[32] !== nodeKey) {
        t13 = ({
            "AnswerEditor[setPromptMethod]": (payload_4)=>{
                editor.update({
                    "AnswerEditor[setPromptMethod > editor.update()]": async ()=>{
                        const node_3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isAnswerNode"])(node_3)) {
                            console.log("setPromptMethod", payload_4);
                            node_3.setPromptMethod(payload_4);
                        }
                    }
                }["AnswerEditor[setPromptMethod > editor.update()]"]);
            }
        })["AnswerEditor[setPromptMethod]"];
        $[31] = editor;
        $[32] = nodeKey;
        $[33] = t13;
    } else {
        t13 = $[33];
    }
    const setPromptMethod = t13;
    let t14;
    if ($[34] !== editor || $[35] !== nodeKey) {
        t14 = ({
            "AnswerEditor[removeWordIDs]": (ids)=>{
                editor.update({
                    "AnswerEditor[removeWordIDs > editor.update()]": async ()=>{
                        const node_4 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isAnswerNode"])(node_4)) {
                            node_4.removeIntersection(ids);
                            const client_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                            const _operations_0 = [];
                            ids.forEach({
                                "AnswerEditor[removeWordIDs > editor.update() > ids.forEach()]": (id_2)=>{
                                    _operations_0.push(client_1.models.UnitWord.delete({
                                        id: id_2
                                    }));
                                }
                            }["AnswerEditor[removeWordIDs > editor.update() > ids.forEach()]"]);
                            await Promise.allSettled(_operations_0);
                        }
                    }
                }["AnswerEditor[removeWordIDs > editor.update()]"]);
            }
        })["AnswerEditor[removeWordIDs]"];
        $[34] = editor;
        $[35] = nodeKey;
        $[36] = t14;
    } else {
        t14 = $[36];
    }
    const removeWordIDs = t14;
    let t15;
    if ($[37] !== dialogValue.phrase) {
        t15 = ({
            "AnswerEditor[handleSubmit]": (event_2)=>{
                event_2.preventDefault();
                setValue({
                    phrase: dialogValue.phrase
                });
                handleClose();
            }
        })["AnswerEditor[handleSubmit]"];
        $[37] = dialogValue.phrase;
        $[38] = t15;
    } else {
        t15 = $[38];
    }
    const handleSubmit = t15;
    let t16;
    if ($[39] !== clearSelection || $[40] !== editor || $[41] !== isSelected || $[42] !== onDelete || $[43] !== onEnter || $[44] !== onEscape || $[45] !== setSelected) {
        t16 = ({
            "AnswerEditor[useEffect()]": ()=>{
                let isMounted = true;
                const unregister = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CLICK_COMMAND"], {
                    "AnswerEditor[useEffect() > editor.registerCommand()]": (payload_5)=>{
                        const event_3 = payload_5;
                        if (answerRef.current && answerRef.current.contains(event_3.target)) {
                            event_3.preventDefault();
                            if (event_3.shiftKey) {
                                setSelected(!isSelected);
                            } else {
                                clearSelection();
                                setSelected(true);
                            }
                            return true;
                        }
                        return false;
                    }
                }["AnswerEditor[useEffect() > editor.registerCommand()]"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_DELETE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_BACKSPACE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_ENTER_COMMAND"], onEnter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_ESCAPE_COMMAND"], onEscape, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]));
                return ()=>{
                    isMounted = false;
                    unregister();
                };
            }
        })["AnswerEditor[useEffect()]"];
        $[39] = clearSelection;
        $[40] = editor;
        $[41] = isSelected;
        $[42] = onDelete;
        $[43] = onEnter;
        $[44] = onEscape;
        $[45] = setSelected;
        $[46] = t16;
    } else {
        t16 = $[46];
    }
    let t17;
    if ($[47] !== clearSelection || $[48] !== editor || $[49] !== isSelected || $[50] !== nodeKey || $[51] !== onDelete || $[52] !== onEnter || $[53] !== onEscape || $[54] !== setSelected) {
        t17 = [
            clearSelection,
            editor,
            isSelected,
            nodeKey,
            onDelete,
            onEnter,
            onEscape,
            setSelected
        ];
        $[47] = clearSelection;
        $[48] = editor;
        $[49] = isSelected;
        $[50] = nodeKey;
        $[51] = onDelete;
        $[52] = onEnter;
        $[53] = onEscape;
        $[54] = setSelected;
        $[55] = t17;
    } else {
        t17 = $[55];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t16, t17);
    const t18 = isSelected ? "2px solid #1976d2" : "1px solid transparent";
    let t19;
    if ($[56] !== t18) {
        t19 = {
            maxHeight: "32rem",
            maxWidth: "72rem",
            border: t18,
            borderRadius: "4px",
            padding: "8px",
            cursor: "pointer"
        };
        $[56] = t18;
        $[57] = t19;
    } else {
        t19 = $[57];
    }
    let t20;
    if ($[58] !== title) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h5",
            children: title
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 596,
            columnNumber: 11
        }, this);
        $[58] = title;
        $[59] = t20;
    } else {
        t20 = $[59];
    }
    let t21;
    if ($[60] !== t) {
        t21 = t("answerEditor.instructions");
        $[60] = t;
        $[61] = t21;
    } else {
        t21 = $[61];
    }
    let t22;
    if ($[62] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "p",
            children: t21
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 612,
            columnNumber: 11
        }, this);
        $[62] = t21;
        $[63] = t22;
    } else {
        t22 = $[63];
    }
    let t23;
    if ($[64] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = {
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between"
        };
        $[64] = t23;
    } else {
        t23 = $[64];
    }
    let t24;
    if ($[65] !== addWordID) {
        t24 = ({
            "AnswerEditor[<Autocomplete>.onChange]": (event_4, newValue)=>{
                if (typeof newValue === "string") {
                    setTimeout({
                        "AnswerEditor[<Autocomplete>.onChange > setTimeout()]": ()=>{
                            toggleOpen(true);
                            setDialogValue({
                                phrase: newValue,
                                pronunciation: "",
                                definition: ""
                            });
                        }
                    }["AnswerEditor[<Autocomplete>.onChange > setTimeout()]"]);
                } else {
                    if (newValue && newValue.inputValue) {
                        toggleOpen(true);
                        setDialogValue({
                            phrase: newValue.inputValue,
                            pronunciation: "",
                            definition: ""
                        });
                    } else {
                        console.log("Autocomplete.newValue", newValue);
                        const newWordID = newValue?.id;
                        if (newWordID) {
                            addWordID(newWordID);
                            setValue(null);
                            setDialogValue({
                                phrase: "",
                                pronunciation: "",
                                definition: ""
                            });
                        }
                    }
                }
            }
        })["AnswerEditor[<Autocomplete>.onChange]"];
        $[65] = addWordID;
        $[66] = t24;
    } else {
        t24 = $[66];
    }
    let t25;
    if ($[67] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = {
            flexGrow: 1
        };
        $[67] = t25;
    } else {
        t25 = $[67];
    }
    let t26;
    if ($[68] !== t) {
        t26 = ({
            "AnswerEditor[<Autocomplete>.renderInput]": (params_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                    ...params_0,
                    label: t("answerEditor.addWordLabel")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
                    lineNumber: 685,
                    columnNumber: 63
                }, this)
        })["AnswerEditor[<Autocomplete>.renderInput]"];
        $[68] = t;
        $[69] = t26;
    } else {
        t26 = $[69];
    }
    let t27;
    if ($[70] !== _dictionary || $[71] !== t24 || $[72] !== t26 || $[73] !== value) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"], {
            value: value,
            onChange: t24,
            filterOptions: _AnswerEditorAutocompleteFilterOptions,
            sx: t25,
            id: "add-new-word",
            options: _dictionary,
            getOptionLabel: _AnswerEditorAutocompleteGetOptionLabel,
            selectOnFocus: true,
            clearOnBlur: true,
            handleHomeEndKeys: true,
            renderOption: _AnswerEditorAutocompleteRenderOption,
            freeSolo: true,
            renderInput: t26
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 694,
            columnNumber: 11
        }, this);
        $[70] = _dictionary;
        $[71] = t24;
        $[72] = t26;
        $[73] = value;
        $[74] = t27;
    } else {
        t27 = $[74];
    }
    let t28;
    if ($[75] !== gridSelection || $[76] !== promptMethod || $[77] !== setPromptMethod || $[78] !== wordIDs) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PromptMethodSelector$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PromptMethodSelector"], {
            ids: gridSelection,
            wordIDs: wordIDs,
            promptMethod: promptMethod,
            setPromptMethod: setPromptMethod
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 705,
            columnNumber: 11
        }, this);
        $[75] = gridSelection;
        $[76] = promptMethod;
        $[77] = setPromptMethod;
        $[78] = wordIDs;
        $[79] = t28;
    } else {
        t28 = $[79];
    }
    let t29;
    if ($[80] !== allowedInput || $[81] !== gridSelection || $[82] !== setAllowedInput || $[83] !== wordIDs) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PromptMethodSelector$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AllowedInputSelector"], {
            ids: gridSelection,
            wordIDs: wordIDs,
            setAllowedInput: setAllowedInput,
            allowedInput: allowedInput
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 716,
            columnNumber: 11
        }, this);
        $[80] = allowedInput;
        $[81] = gridSelection;
        $[82] = setAllowedInput;
        $[83] = wordIDs;
        $[84] = t29;
    } else {
        t29 = $[84];
    }
    let t30;
    if ($[85] !== gridSelection || $[86] !== removeWordIDs || $[87] !== requestDefinition || $[88] !== setRequestDefinition) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ActionsMenu, {
            removeWordIDs: removeWordIDs,
            ids: gridSelection,
            requestDefinition: requestDefinition,
            setRequestDefinition: setRequestDefinition
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 727,
            columnNumber: 11
        }, this);
        $[85] = gridSelection;
        $[86] = removeWordIDs;
        $[87] = requestDefinition;
        $[88] = setRequestDefinition;
        $[89] = t30;
    } else {
        t30 = $[89];
    }
    let t31;
    if ($[90] !== t27 || $[91] !== t28 || $[92] !== t29 || $[93] !== t30) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: t23,
            children: [
                t27,
                t28,
                t29,
                t30
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 738,
            columnNumber: 11
        }, this);
        $[90] = t27;
        $[91] = t28;
        $[92] = t29;
        $[93] = t30;
        $[94] = t31;
    } else {
        t31 = $[94];
    }
    let t32;
    if ($[95] !== t) {
        t32 = t("answerEditor.dialogTitle");
        $[95] = t;
        $[96] = t32;
    } else {
        t32 = $[96];
    }
    let t33;
    if ($[97] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
            children: t32
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 757,
            columnNumber: 11
        }, this);
        $[97] = t32;
        $[98] = t33;
    } else {
        t33 = $[98];
    }
    let t34;
    if ($[99] === Symbol.for("react.memo_cache_sentinel")) {
        t34 = {
            display: "flex",
            flexDirection: "column",
            width: "fit-content"
        };
        $[99] = t34;
    } else {
        t34 = $[99];
    }
    let t35;
    if ($[100] !== t) {
        t35 = t("answerEditor.addWordToDict");
        $[100] = t;
        $[101] = t35;
    } else {
        t35 = $[101];
    }
    let t36;
    if ($[102] !== t35) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContentText$2f$DialogContentText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContentText$3e$__["DialogContentText"], {
            children: t35
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 784,
            columnNumber: 11
        }, this);
        $[102] = t35;
        $[103] = t36;
    } else {
        t36 = $[103];
    }
    let t37;
    if ($[104] !== dialogValue) {
        t37 = ({
            "AnswerEditor[<TextField>.onChange]": (event_5)=>setDialogValue({
                    ...dialogValue,
                    phrase: event_5.target.value
                })
        })["AnswerEditor[<TextField>.onChange]"];
        $[104] = dialogValue;
        $[105] = t37;
    } else {
        t37 = $[105];
    }
    let t38;
    if ($[106] !== dialogValue.phrase || $[107] !== t37) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
            autoFocus: true,
            margin: "dense",
            id: "name",
            value: dialogValue.phrase,
            onChange: t37,
            label: "phrase",
            type: "text",
            variant: "standard"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 805,
            columnNumber: 11
        }, this);
        $[106] = dialogValue.phrase;
        $[107] = t37;
        $[108] = t38;
    } else {
        t38 = $[108];
    }
    let t39;
    if ($[109] !== dialogValue) {
        t39 = ({
            "AnswerEditor[<TextField>.onChange]": (event_6)=>setDialogValue({
                    ...dialogValue,
                    pronunciation: event_6.target.value
                })
        })["AnswerEditor[<TextField>.onChange]"];
        $[109] = dialogValue;
        $[110] = t39;
    } else {
        t39 = $[110];
    }
    let t40;
    if ($[111] !== dialogValue.pronunciation || $[112] !== t39) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
            margin: "dense",
            id: "pronunciation",
            value: dialogValue.pronunciation,
            onChange: t39,
            label: "pronunciation",
            type: "text",
            variant: "standard"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 827,
            columnNumber: 11
        }, this);
        $[111] = dialogValue.pronunciation;
        $[112] = t39;
        $[113] = t40;
    } else {
        t40 = $[113];
    }
    let t41;
    if ($[114] === Symbol.for("react.memo_cache_sentinel")) {
        t41 = {
            width: "100%",
            marginTop: "1rem"
        };
        $[114] = t41;
    } else {
        t41 = $[114];
    }
    let t42;
    if ($[115] !== dialogValue) {
        t42 = ({
            "AnswerEditor[<TextareaAutosize>.onChange]": (event_7)=>setDialogValue({
                    ...dialogValue,
                    definition: event_7.target.value
                })
        })["AnswerEditor[<TextareaAutosize>.onChange]"];
        $[115] = dialogValue;
        $[116] = t42;
    } else {
        t42 = $[116];
    }
    let t43;
    if ($[117] !== dialogValue.definition || $[118] !== t42) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            minRows: 3,
            style: t41,
            id: "definition",
            value: dialogValue.definition,
            onChange: t42,
            "aria-label": "Definition",
            placeholder: "definition",
            type: "text",
            variant: "standard"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 859,
            columnNumber: 11
        }, this);
        $[117] = dialogValue.definition;
        $[118] = t42;
        $[119] = t43;
    } else {
        t43 = $[119];
    }
    let t44;
    if ($[120] !== t36 || $[121] !== t38 || $[122] !== t40 || $[123] !== t43) {
        t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
            sx: t34,
            children: [
                t36,
                t38,
                t40,
                t43
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 868,
            columnNumber: 11
        }, this);
        $[120] = t36;
        $[121] = t38;
        $[122] = t40;
        $[123] = t43;
        $[124] = t44;
    } else {
        t44 = $[124];
    }
    let t45;
    if ($[125] !== t) {
        t45 = t("answerEditor.cancel");
        $[125] = t;
        $[126] = t45;
    } else {
        t45 = $[126];
    }
    let t46;
    if ($[127] !== t45) {
        t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: handleClose,
            children: t45
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 887,
            columnNumber: 11
        }, this);
        $[127] = t45;
        $[128] = t46;
    } else {
        t46 = $[128];
    }
    let t47;
    if ($[129] !== t) {
        t47 = t("answerEditor.save");
        $[129] = t;
        $[130] = t47;
    } else {
        t47 = $[130];
    }
    let t48;
    if ($[131] !== t47) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            type: "submit",
            variant: "contained",
            color: "primary",
            children: t47
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 903,
            columnNumber: 11
        }, this);
        $[131] = t47;
        $[132] = t48;
    } else {
        t48 = $[132];
    }
    let t49;
    if ($[133] !== t46 || $[134] !== t48) {
        t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
            children: [
                t46,
                t48
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 911,
            columnNumber: 11
        }, this);
        $[133] = t46;
        $[134] = t48;
        $[135] = t49;
    } else {
        t49 = $[135];
    }
    let t50;
    if ($[136] !== handleSubmit || $[137] !== t33 || $[138] !== t44 || $[139] !== t49) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: handleSubmit,
            children: [
                t33,
                t44,
                t49
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 920,
            columnNumber: 11
        }, this);
        $[136] = handleSubmit;
        $[137] = t33;
        $[138] = t44;
        $[139] = t49;
        $[140] = t50;
    } else {
        t50 = $[140];
    }
    let t51;
    if ($[141] !== open || $[142] !== t50) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
            open: open,
            onClose: handleClose,
            children: t50
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 931,
            columnNumber: 11
        }, this);
        $[141] = open;
        $[142] = t50;
        $[143] = t51;
    } else {
        t51 = $[143];
    }
    let t52;
    if ($[144] !== rows.length || $[145] !== t) {
        t52 = rows.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                marginTop: "0.5"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: t("answerEditor.emptyState")
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
                lineNumber: 942,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 940,
            columnNumber: 32
        }, this);
        $[144] = rows.length;
        $[145] = t;
        $[146] = t52;
    } else {
        t52 = $[146];
    }
    let t53;
    if ($[147] !== gridSelection || $[148] !== rows) {
        t53 = rows.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$DataGrid$2f$DataGrid$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DataGrid"], {
            sx: {
                marginTop: "0.5rem"
            },
            rows: rows,
            columns: columns,
            initialState: {
                pagination: {
                    paginationModel: {
                        page: 0,
                        pageSize: 10
                    }
                }
            },
            pageSizeOptions: [
                5,
                10,
                100
            ],
            checkboxSelection: true,
            rowSelectionModel: gridSelection,
            onRowSelectionModelChange: {
                "AnswerEditor[<DataGrid>.onRowSelectionModelChange]": (e)=>{
                    console.log("onRowSelectionModelChange", e);
                    setGridSelection(e);
                }
            }["AnswerEditor[<DataGrid>.onRowSelectionModelChange]"]
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 951,
            columnNumber: 30
        }, this);
        $[147] = gridSelection;
        $[148] = rows;
        $[149] = t53;
    } else {
        t53 = $[149];
    }
    let t54;
    if ($[150] !== t19 || $[151] !== t20 || $[152] !== t22 || $[153] !== t31 || $[154] !== t51 || $[155] !== t52 || $[156] !== t53) {
        t54 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: answerRef,
            style: t19,
            children: [
                t20,
                t22,
                t31,
                t51,
                t52,
                t53
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
            lineNumber: 974,
            columnNumber: 11
        }, this);
        $[150] = t19;
        $[151] = t20;
        $[152] = t22;
        $[153] = t31;
        $[154] = t51;
        $[155] = t52;
        $[156] = t53;
        $[157] = t54;
    } else {
        t54 = $[157];
    }
    return t54;
}, "yclm8T79fMyQQr5sYyisgqythgE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"]
    ];
})), "yclm8T79fMyQQr5sYyisgqythgE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"]
    ];
});
_c2 = AnswerEditor;
const __TURBOPACK__default__export__ = AnswerEditor;
function _AnswerEditorAutocompleteFilterOptions(options, params) {
    const filtered = filter(options, params);
    if (params.inputValue !== "") {
        filtered.push({
            inputValue: params.inputValue,
            phrase: `Add "${params.inputValue}"`
        });
    }
    return filtered;
}
function _AnswerEditorAutocompleteGetOptionLabel(option) {
    if (typeof option === "string") {
        return option;
    }
    if (option.inputValue) {
        return option.inputValue;
    }
    return option.phrase;
}
function _AnswerEditorAutocompleteRenderOption(props, option_0, t0) {
    const { index } = t0;
    let phrase = option_0.phrase;
    if (option_0.phrase && option_0.pronunciation) {
        phrase = `${option_0.phrase} (${option_0.pronunciation})`;
    }
    const { key, ...otherProps } = props;
    const uniqueKey = option_0.id || `${option_0.phrase}-${index}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        ...otherProps,
        children: phrase
    }, uniqueKey, false, {
        fileName: "[project]/src/components/Editor3/components/AnswerEditor.jsx",
        lineNumber: 1021,
        columnNumber: 10
    }, this);
}
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ActionsMenu");
__turbopack_context__.k.register(_c1, "AnswerEditor$React.memo");
__turbopack_context__.k.register(_c2, "AnswerEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/SubmissionCountdown.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SubmissionCountdown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function SubmissionCountdown(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "7dda88f176dd88f6cabbd8b5ac1fe49bd49e277a804cc8056e42eb566e3ef439") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7dda88f176dd88f6cabbd8b5ac1fe49bd49e277a804cc8056e42eb566e3ef439";
    }
    const { countdown, onCancel, onSubmitNow } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.shared");
    if (countdown === null || countdown === undefined) {
        return null;
    }
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            p: 1,
            bgcolor: "warning.light",
            color: "warning.contrastText",
            borderRadius: 1,
            border: "1px solid",
            borderColor: "warning.main",
            boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 0.5
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            fontWeight: 500,
            textAlign: "center",
            lineHeight: 1.3,
            color: "inherit"
        };
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== countdown || $[4] !== t) {
        t3 = t("autoSubmit.submittingInSeconds", {
            countdown
        });
        $[3] = countdown;
        $[4] = t;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            sx: t2,
            children: t3
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/SubmissionCountdown.jsx",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[6] = t3;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] !== t) {
        t5 = t("autoSubmit.submitNow", "Submit Now");
        $[8] = t;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] !== onSubmitNow || $[11] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            variant: "contained",
            color: "warning",
            size: "small",
            onClick: onSubmitNow,
            children: t5
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/SubmissionCountdown.jsx",
            lineNumber: 87,
            columnNumber: 10
        }, this);
        $[10] = onSubmitNow;
        $[11] = t5;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    let t7;
    if ($[13] !== t) {
        t7 = t("autoSubmit.cancelSubmission");
        $[13] = t;
        $[14] = t7;
    } else {
        t7 = $[14];
    }
    let t8;
    if ($[15] !== onCancel || $[16] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            variant: "outlined",
            color: "warning",
            size: "small",
            onClick: onCancel,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/SubmissionCountdown.jsx",
            lineNumber: 104,
            columnNumber: 10
        }, this);
        $[15] = onCancel;
        $[16] = t7;
        $[17] = t8;
    } else {
        t8 = $[17];
    }
    let t9;
    if ($[18] !== t4 || $[19] !== t6 || $[20] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t1,
            children: [
                t4,
                t6,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/SubmissionCountdown.jsx",
            lineNumber: 113,
            columnNumber: 10
        }, this);
        $[18] = t4;
        $[19] = t6;
        $[20] = t8;
        $[21] = t9;
    } else {
        t9 = $[21];
    }
    return t9;
}
_s(SubmissionCountdown, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = SubmissionCountdown;
var _c;
__turbopack_context__.k.register(_c, "SubmissionCountdown");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PlainTextAnswerInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * PlainTextAnswerInput - Lexical plain text editor for student answer input.
 *
 * Features:
 * - Shared undo/redo stack via external history state
 * - Auto-submit on blur or idle (no typing for idleTimeout ms)
 * - Grace period countdown before submission (like SketchPad)
 * - Cancel button to abort pending submission
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposer.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalPlainTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalPlainTextPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalContentEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalErrorBoundary.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHistoryPlugin.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalOnChangePlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Send.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$SubmissionCountdown$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/SubmissionCountdown.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
/**
 * Plugin that fires onBlur with current text when the editor loses focus.
 */ function BlurPlugin({ onBlur }) {
    _s();
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const onBlurRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(onBlur);
    onBlurRef.current = onBlur;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BlurPlugin.useEffect": ()=>{
            return editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BLUR_COMMAND"], {
                "BlurPlugin.useEffect": ()=>{
                    editor.getEditorState().read({
                        "BlurPlugin.useEffect": ()=>{
                            const text = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().getTextContent();
                            onBlurRef.current?.(text);
                        }
                    }["BlurPlugin.useEffect"]);
                    return false;
                }
            }["BlurPlugin.useEffect"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]);
        }
    }["BlurPlugin.useEffect"], [
        editor
    ]);
    return null;
}
_s(BlurPlugin, "S8uYeNxsyvixs6PNn+SXafiIWGU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = BlurPlugin;
/**
 * Plugin that fires onFocus when the editor gains focus.
 */ function FocusPlugin({ onFocus }) {
    _s1();
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const onFocusRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(onFocus);
    onFocusRef.current = onFocus;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FocusPlugin.useEffect": ()=>{
            return editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FOCUS_COMMAND"], {
                "FocusPlugin.useEffect": ()=>{
                    onFocusRef.current?.();
                    return false;
                }
            }["FocusPlugin.useEffect"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]);
        }
    }["FocusPlugin.useEffect"], [
        editor
    ]);
    return null;
}
_s1(FocusPlugin, "BVncwb/NcxQjq8DRrycb17g3KEY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c1 = FocusPlugin;
/**
 * Plugin to dynamically toggle editor editability without remounting.
 */ function EditablePlugin(t0) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "52113071acc4d434c796dedc96f18bbf249f60867fe4286ecacbc06414435aea") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "52113071acc4d434c796dedc96f18bbf249f60867fe4286ecacbc06414435aea";
    }
    const { editable } = t0;
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t1;
    let t2;
    if ($[1] !== editable || $[2] !== editor) {
        t1 = ({
            "EditablePlugin[useEffect()]": ()=>{
                editor.setEditable(editable);
            }
        })["EditablePlugin[useEffect()]"];
        t2 = [
            editor,
            editable
        ];
        $[1] = editable;
        $[2] = editor;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return null;
}
_s2(EditablePlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c2 = EditablePlugin;
/**
 * Plugin to sync external value into the editor without polluting undo stack.
 */ function SyncValuePlugin(t0) {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "52113071acc4d434c796dedc96f18bbf249f60867fe4286ecacbc06414435aea") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "52113071acc4d434c796dedc96f18bbf249f60867fe4286ecacbc06414435aea";
    }
    const { value } = t0;
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const lastExternalValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(value);
    let t1;
    let t2;
    if ($[1] !== editor || $[2] !== value) {
        t1 = ({
            "SyncValuePlugin[useEffect()]": ()=>{
                if (value === lastExternalValue.current) {
                    return;
                }
                lastExternalValue.current = value;
                editor.update({
                    "SyncValuePlugin[useEffect() > editor.update()]": ()=>{
                        const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
                        const currentText = root.getTextContent();
                        if (currentText === value) {
                            return;
                        }
                        root.clear();
                        const paragraph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])();
                        if (value) {
                            paragraph.append((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(value));
                        }
                        root.append(paragraph);
                    }
                }["SyncValuePlugin[useEffect() > editor.update()]"], {
                    tag: "history-merge"
                });
            }
        })["SyncValuePlugin[useEffect()]"];
        t2 = [
            value,
            editor
        ];
        $[1] = editor;
        $[2] = value;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return null;
}
_s3(SyncValuePlugin, "azzZeUDNVAhvJrxBEAU2fUqqfkU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c3 = SyncValuePlugin;
function PlainTextAnswerInput({ value = '', onChange, onAutoSubmit, historyState, placeholder = '', ariaLabel = '', borderStyle = '1px solid #ccc', textColor = 'inherit', gracePeriod = 10, idleTimeout = 3000, style = {}, testId, wordId, questionId, disabled = false }) {
    _s4();
    const [countdown, setCountdown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const countdownTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const idleTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const currentValueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(value);
    const onAutoSubmitRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(onAutoSubmit);
    onAutoSubmitRef.current = onAutoSubmit;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PlainTextAnswerInput.useEffect": ()=>{
            currentValueRef.current = value;
        }
    }["PlainTextAnswerInput.useEffect"], [
        value
    ]);
    const cancelCountdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PlainTextAnswerInput.useCallback[cancelCountdown]": ()=>{
            if (countdownTimerRef.current) {
                clearInterval(countdownTimerRef.current);
                countdownTimerRef.current = null;
            }
            setCountdown(null);
        }
    }["PlainTextAnswerInput.useCallback[cancelCountdown]"], []);
    const startCountdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PlainTextAnswerInput.useCallback[startCountdown]": ()=>{
            cancelCountdown();
            const submitValue = currentValueRef.current;
            if (!submitValue || !submitValue.trim()) return;
            setCountdown(gracePeriod);
            countdownTimerRef.current = setInterval({
                "PlainTextAnswerInput.useCallback[startCountdown]": ()=>{
                    setCountdown({
                        "PlainTextAnswerInput.useCallback[startCountdown]": (prev)=>{
                            if (prev <= 1) {
                                clearInterval(countdownTimerRef.current);
                                countdownTimerRef.current = null;
                                onAutoSubmitRef.current?.(currentValueRef.current);
                                return null;
                            }
                            return prev - 1;
                        }
                    }["PlainTextAnswerInput.useCallback[startCountdown]"]);
                }
            }["PlainTextAnswerInput.useCallback[startCountdown]"], 1000);
        }
    }["PlainTextAnswerInput.useCallback[startCountdown]"], [
        gracePeriod,
        cancelCountdown
    ]);
    const handleChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PlainTextAnswerInput.useCallback[handleChange]": (editorState)=>{
            editorState.read({
                "PlainTextAnswerInput.useCallback[handleChange]": ()=>{
                    const text = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().getTextContent();
                    currentValueRef.current = text;
                    onChange?.(text);
                }
            }["PlainTextAnswerInput.useCallback[handleChange]"]);
            // Cancel any running countdown when user types
            cancelCountdown();
            // Reset idle timer
            if (idleTimerRef.current) {
                clearTimeout(idleTimerRef.current);
            }
            idleTimerRef.current = setTimeout({
                "PlainTextAnswerInput.useCallback[handleChange]": ()=>{
                    startCountdown();
                }
            }["PlainTextAnswerInput.useCallback[handleChange]"], idleTimeout);
        }
    }["PlainTextAnswerInput.useCallback[handleChange]"], [
        onChange,
        cancelCountdown,
        startCountdown,
        idleTimeout
    ]);
    const handleBlur = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PlainTextAnswerInput.useCallback[handleBlur]": (text_0)=>{
            if (idleTimerRef.current) {
                clearTimeout(idleTimerRef.current);
                idleTimerRef.current = null;
            }
            if (text_0 && text_0.trim()) {
                startCountdown();
            }
        }
    }["PlainTextAnswerInput.useCallback[handleBlur]"], [
        startCountdown
    ]);
    const handleFocus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PlainTextAnswerInput.useCallback[handleFocus]": ()=>{
            cancelCountdown();
            if (idleTimerRef.current) {
                clearTimeout(idleTimerRef.current);
                idleTimerRef.current = null;
            }
        }
    }["PlainTextAnswerInput.useCallback[handleFocus]"], [
        cancelCountdown
    ]);
    const handleManualSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PlainTextAnswerInput.useCallback[handleManualSubmit]": ()=>{
            cancelCountdown();
            if (idleTimerRef.current) {
                clearTimeout(idleTimerRef.current);
                idleTimerRef.current = null;
            }
            const text_1 = currentValueRef.current;
            if (text_1 && text_1.trim()) {
                onAutoSubmitRef.current?.(text_1);
            }
        }
    }["PlainTextAnswerInput.useCallback[handleManualSubmit]"], [
        cancelCountdown
    ]);
    // Cancel timers when disabled
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PlainTextAnswerInput.useEffect": ()=>{
            if (disabled) {
                cancelCountdown();
                if (idleTimerRef.current) {
                    clearTimeout(idleTimerRef.current);
                    idleTimerRef.current = null;
                }
            }
        }
    }["PlainTextAnswerInput.useEffect"], [
        disabled,
        cancelCountdown
    ]);
    // Cleanup
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PlainTextAnswerInput.useEffect": ()=>{
            return ({
                "PlainTextAnswerInput.useEffect": ()=>{
                    if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
                    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
                }
            })["PlainTextAnswerInput.useEffect"];
        }
    }["PlainTextAnswerInput.useEffect"], []);
    const initialConfig = {
        namespace: `PlainTextAnswer-${wordId || questionId || 'field'}`,
        theme: {},
        editable: !disabled,
        onError: (error)=>console.error('[PlainTextAnswerInput] Lexical error:', error),
        editorState: ()=>{
            const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
            root.clear();
            if (value) {
                const paragraph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])();
                paragraph.append((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(value));
                root.append(paragraph);
            }
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            display: 'flex',
            alignItems: 'flex-start',
            gap: 1,
            flexBasis: '80%',
            maxWidth: '50rem'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    flex: 1,
                    minWidth: 0
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalComposer"], {
                    initialConfig: initialConfig,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            position: 'relative'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalPlainTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlainTextPlugin"], {
                                ErrorBoundary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalErrorBoundary"],
                                contentEditable: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentEditable"], {
                                    "data-testid": testId,
                                    "data-word-id": wordId,
                                    "data-question-id": questionId,
                                    "aria-label": ariaLabel,
                                    style: {
                                        border: borderStyle,
                                        borderRadius: '12px',
                                        padding: '16px',
                                        fontSize: '16px',
                                        lineHeight: '1.5',
                                        fontFamily: 'inherit',
                                        resize: 'vertical',
                                        color: textColor,
                                        minHeight: '72px',
                                        overflow: 'auto',
                                        outline: 'none',
                                        width: '100%',
                                        boxSizing: 'border-box',
                                        backgroundColor: 'transparent',
                                        ...style
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                                    lineNumber: 299,
                                    columnNumber: 84
                                }, this),
                                placeholder: placeholder ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        position: 'absolute',
                                        top: '16px',
                                        left: '16px',
                                        color: 'inherit',
                                        opacity: 0.5,
                                        pointerEvents: 'none',
                                        fontSize: '16px',
                                        lineHeight: '1.5'
                                    },
                                    children: placeholder
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                                    lineNumber: 315,
                                    columnNumber: 45
                                }, this) : null
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                                lineNumber: 299,
                                columnNumber: 13
                            }, this),
                            historyState ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HistoryPlugin"], {
                                externalHistoryState: historyState
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                                lineNumber: 327,
                                columnNumber: 29
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HistoryPlugin"], {}, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                                lineNumber: 327,
                                columnNumber: 85
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OnChangePlugin"], {
                                onChange: handleChange,
                                ignoreSelectionChange: true
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                                lineNumber: 328,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BlurPlugin, {
                                onBlur: handleBlur
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                                lineNumber: 329,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FocusPlugin, {
                                onFocus: handleFocus
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                                lineNumber: 330,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SyncValuePlugin, {
                                value: value
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                                lineNumber: 331,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EditablePlugin, {
                                editable: !disabled
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                                lineNumber: 332,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                        lineNumber: 296,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                    lineNumber: 295,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                lineNumber: 291,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: 1,
                    pt: '8px',
                    minWidth: 'fit-content'
                },
                children: countdown === null || countdown === undefined ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    variant: "contained",
                    size: "small",
                    endIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                        lineNumber: 345,
                        columnNumber: 108
                    }, this),
                    onClick: handleManualSubmit,
                    disabled: disabled,
                    children: "Submit"
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                    lineNumber: 345,
                    columnNumber: 58
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$SubmissionCountdown$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    countdown: countdown,
                    onCancel: cancelCountdown,
                    onSubmitNow: handleManualSubmit
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                    lineNumber: 347,
                    columnNumber: 23
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
                lineNumber: 337,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx",
        lineNumber: 284,
        columnNumber: 10
    }, this);
}
_s4(PlainTextAnswerInput, "tRidCbP+eb1dGD5yUBhrIfSxNrs=");
_c4 = PlainTextAnswerInput;
var _c, _c1, _c2, _c3, _c4;
__turbopack_context__.k.register(_c, "BlurPlugin");
__turbopack_context__.k.register(_c1, "FocusPlugin");
__turbopack_context__.k.register(_c2, "EditablePlugin");
__turbopack_context__.k.register(_c3, "SyncValuePlugin");
__turbopack_context__.k.register(_c4, "PlainTextAnswerInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/AudioAutoSubmitWrapper.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AudioAutoSubmitWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * AudioAutoSubmitWrapper - Wraps audio recording components with a grace period
 * countdown before submission, matching the SketchPad pattern.
 *
 * Uses render prop pattern so it works with both AudioWaveformPlayer
 * and RecordingStudio2.
 *
 * For AudioWaveformPlayer: intercepts onRecordingComplete
 * For RecordingStudio2: intercepts setFeedback
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$SubmissionCountdown$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/SubmissionCountdown.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function AudioAutoSubmitWrapper(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "eb08ed3ae4f6bf9d170ac08086d5d17eedf31599bdbcb2c78295d9e473222041") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "eb08ed3ae4f6bf9d170ac08086d5d17eedf31599bdbcb2c78295d9e473222041";
    }
    const { children, gracePeriod: t1 } = t0;
    const gracePeriod = t1 === undefined ? 10 : t1;
    const [countdown, setCountdown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [, setPendingArgs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const countdownTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const onSubmitRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "AudioAutoSubmitWrapper[cancelCountdown]": ()=>{
                if (countdownTimerRef.current) {
                    clearInterval(countdownTimerRef.current);
                    countdownTimerRef.current = null;
                }
                setCountdown(null);
                setPendingArgs(null);
                onSubmitRef.current = null;
            }
        })["AudioAutoSubmitWrapper[cancelCountdown]"];
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    const cancelCountdown = t2;
    let t3;
    if ($[2] !== gracePeriod) {
        t3 = ({
            "AudioAutoSubmitWrapper[startCountdown]": (submitFn, args)=>{
                cancelCountdown();
                onSubmitRef.current = ()=>submitFn(...args);
                setPendingArgs(args);
                setCountdown(gracePeriod);
                countdownTimerRef.current = setInterval({
                    "AudioAutoSubmitWrapper[startCountdown > setInterval()]": ()=>{
                        setCountdown({
                            "AudioAutoSubmitWrapper[startCountdown > setInterval() > setCountdown()]": (prev)=>{
                                if (prev <= 1) {
                                    clearInterval(countdownTimerRef.current);
                                    countdownTimerRef.current = null;
                                    onSubmitRef.current?.();
                                    onSubmitRef.current = null;
                                    setPendingArgs(null);
                                    return null;
                                }
                                return prev - 1;
                            }
                        }["AudioAutoSubmitWrapper[startCountdown > setInterval() > setCountdown()]"]);
                    }
                }["AudioAutoSubmitWrapper[startCountdown > setInterval()]"], 1000);
            }
        })["AudioAutoSubmitWrapper[startCountdown]"];
        $[2] = gracePeriod;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const startCountdown = t3;
    let t4;
    let t5;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "AudioAutoSubmitWrapper[useEffect()]": ()=>()=>{
                    if (countdownTimerRef.current) {
                        clearInterval(countdownTimerRef.current);
                    }
                }
        })["AudioAutoSubmitWrapper[useEffect()]"];
        t5 = [];
        $[4] = t4;
        $[5] = t5;
    } else {
        t4 = $[4];
        t5 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t4, t5);
    let t6;
    if ($[6] !== startCountdown) {
        t6 = ({
            "AudioAutoSubmitWrapper[wrapOnRecordingComplete]": (originalCallback)=>(audioFile, uploadResult)=>{
                    startCountdown(originalCallback, [
                        audioFile,
                        uploadResult
                    ]);
                }
        })["AudioAutoSubmitWrapper[wrapOnRecordingComplete]"];
        $[6] = startCountdown;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    const wrapOnRecordingComplete = t6;
    let t7;
    if ($[8] !== startCountdown) {
        t7 = ({
            "AudioAutoSubmitWrapper[wrapSetFeedback]": (originalSetFeedback)=>(data)=>{
                    startCountdown(originalSetFeedback, [
                        data
                    ]);
                }
        })["AudioAutoSubmitWrapper[wrapSetFeedback]"];
        $[8] = startCountdown;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    const wrapSetFeedback = t7;
    let t8;
    if ($[10] !== children || $[11] !== wrapOnRecordingComplete || $[12] !== wrapSetFeedback) {
        t8 = children({
            wrapOnRecordingComplete,
            wrapSetFeedback
        });
        $[10] = children;
        $[11] = wrapOnRecordingComplete;
        $[12] = wrapSetFeedback;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] !== countdown) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$SubmissionCountdown$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            countdown: countdown,
            onCancel: cancelCountdown
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AudioAutoSubmitWrapper.jsx",
            lineNumber: 142,
            columnNumber: 10
        }, this);
        $[14] = countdown;
        $[15] = t9;
    } else {
        t9 = $[15];
    }
    let t10;
    if ($[16] !== t8 || $[17] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: [
                t8,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/AudioAutoSubmitWrapper.jsx",
            lineNumber: 150,
            columnNumber: 11
        }, this);
        $[16] = t8;
        $[17] = t9;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    return t10;
}
_s(AudioAutoSubmitWrapper, "Sg+4sCZ8rXgOn6+/Hp5wws/1akw=");
_c = AudioAutoSubmitWrapper;
var _c;
__turbopack_context__.k.register(_c, "AudioAutoSubmitWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/WorkbookBlockEnhancements.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WorkbookBlockEnhancements",
    ()=>WorkbookBlockEnhancements
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * WorkbookBlockEnhancements — Adds comment gutter, NailedIt badge,
 * and block history to any graded workbook block.
 *
 * Wraps around the existing block content. Uses UnitContext to access
 * the workbook collaboration provider.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$CommentGutterIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Workbook/CommentGutterIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$CommentThreadDrawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Workbook/CommentThreadDrawer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$BlockHistoryTimeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Workbook/BlockHistoryTimeline.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$NailedItBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/NailedItBadge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/workbookHooks.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
function WorkbookBlockEnhancements(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(31);
    if ($[0] !== "5eae9eea3fff1bf293a5688e79956f13fff49079fb9cfe7cf5f13c291cea5478") {
        for(let $i = 0; $i < 31; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5eae9eea3fff1bf293a5688e79956f13fff49079fb9cfe7cf5f13c291cea5478";
    }
    const { blockId, nailedIt, children } = t0;
    const { workbook, workbookEnabled, session } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [drawerOpen, setDrawerOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const provider = workbookEnabled ? workbook?.provider ?? null : null;
    const { threads, addComment, replyToComment, resolveThread } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWorkbookComments"])(provider, blockId);
    const { entries: historyEntries } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBlockHistory"])(provider, blockId);
    const commentCount = threads?.length ?? 0;
    let t1;
    if ($[1] !== threads) {
        t1 = threads?.filter(_WorkbookBlockEnhancementsAnonymous)?.length ?? 0;
        $[1] = threads;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const unresolvedCount = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "WorkbookBlockEnhancements[handleOpenDrawer]": ()=>setDrawerOpen(true)
        })["WorkbookBlockEnhancements[handleOpenDrawer]"];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const handleOpenDrawer = t2;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "WorkbookBlockEnhancements[handleCloseDrawer]": ()=>setDrawerOpen(false)
        })["WorkbookBlockEnhancements[handleCloseDrawer]"];
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const handleCloseDrawer = t3;
    let t4;
    if ($[5] !== addComment) {
        t4 = ({
            "WorkbookBlockEnhancements[handleAddComment]": (text)=>{
                addComment(text);
            }
        })["WorkbookBlockEnhancements[handleAddComment]"];
        $[5] = addComment;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const handleAddComment = t4;
    let t5;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            position: "relative"
        };
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] !== commentCount || $[9] !== provider || $[10] !== unresolvedCount) {
        t6 = provider && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                position: "absolute",
                left: -32,
                top: 8,
                zIndex: 1
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$CommentGutterIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommentGutterIcon"], {
                commentCount: commentCount,
                unresolvedCount: unresolvedCount,
                onClick: handleOpenDrawer
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/WorkbookBlockEnhancements.jsx",
                lineNumber: 106,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookBlockEnhancements.jsx",
            lineNumber: 101,
            columnNumber: 22
        }, this);
        $[8] = commentCount;
        $[9] = provider;
        $[10] = unresolvedCount;
        $[11] = t6;
    } else {
        t6 = $[11];
    }
    let t7;
    if ($[12] !== nailedIt) {
        t7 = nailedIt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                mt: 0.5
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$NailedItBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NailedItBadge"], {}, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/WorkbookBlockEnhancements.jsx",
                lineNumber: 118,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookBlockEnhancements.jsx",
            lineNumber: 116,
            columnNumber: 22
        }, this);
        $[12] = nailedIt;
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[14] !== historyEntries) {
        t8 = historyEntries.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$BlockHistoryTimeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BlockHistoryTimeline"], {
            entries: historyEntries,
            maxVisible: 5
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookBlockEnhancements.jsx",
            lineNumber: 126,
            columnNumber: 39
        }, this);
        $[14] = historyEntries;
        $[15] = t8;
    } else {
        t8 = $[15];
    }
    let t9;
    if ($[16] !== blockId || $[17] !== drawerOpen || $[18] !== handleAddComment || $[19] !== provider || $[20] !== replyToComment || $[21] !== resolveThread || $[22] !== session?.username || $[23] !== threads) {
        t9 = provider && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$CommentThreadDrawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommentThreadDrawer"], {
            open: drawerOpen,
            onClose: handleCloseDrawer,
            blockId: blockId,
            threads: threads,
            onAddComment: handleAddComment,
            onReply: replyToComment,
            onResolve: resolveThread,
            currentUsername: session?.username || ""
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/WorkbookBlockEnhancements.jsx",
            lineNumber: 134,
            columnNumber: 22
        }, this);
        $[16] = blockId;
        $[17] = drawerOpen;
        $[18] = handleAddComment;
        $[19] = provider;
        $[20] = replyToComment;
        $[21] = resolveThread;
        $[22] = session?.username;
        $[23] = threads;
        $[24] = t9;
    } else {
        t9 = $[24];
    }
    let t10;
    if ($[25] !== children || $[26] !== t6 || $[27] !== t7 || $[28] !== t8 || $[29] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t5,
            children: [
                t6,
                children,
                t7,
                t8,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/WorkbookBlockEnhancements.jsx",
            lineNumber: 149,
            columnNumber: 11
        }, this);
        $[25] = children;
        $[26] = t6;
        $[27] = t7;
        $[28] = t8;
        $[29] = t9;
        $[30] = t10;
    } else {
        t10 = $[30];
    }
    return t10;
}
_s(WorkbookBlockEnhancements, "qCsYcohBD8IogFEgLXxxVRIoLY8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWorkbookComments"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBlockHistory"]
    ];
});
_c = WorkbookBlockEnhancements;
function _WorkbookBlockEnhancementsAnonymous(t) {
    return !t.resolved;
}
var _c;
__turbopack_context__.k.register(_c, "WorkbookBlockEnhancements");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/AnswerComponent.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AnswerComponent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
// check if the answer is correct by calling the chatgpt api with the prompt and answer and ask to confirm if the answer is correct.
// provide the answer to the question to the user
// record answer for this question in a ref.
// update the progress bar with the number of correct answers.
// silently record incorrect answers for review, but allow the user to continue and try to answer the question again.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$527ad9__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:527ad9 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$e468d3__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:e468d3 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButtonGroup$2f$ToggleButtonGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButtonGroup$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ToggleButtonGroup/ToggleButtonGroup.js [app-client] (ecmascript) <export default as ToggleButtonGroup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ToggleButton/ToggleButton.js [app-client] (ecmascript) <export default as ToggleButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$history$2f$LexicalHistory$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/history/LexicalHistory.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PlainTextAnswerInput$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioAutoSubmitWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AudioAutoSubmitWrapper.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$WorkbookBlockEnhancements$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/WorkbookBlockEnhancements.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useVerifyContext$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useVerifyContext.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
const SketchPad = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(async ()=>(await __turbopack_context__.A("[project]/src/components/Editor3/components/SketchPad.jsx [app-client] (ecmascript, next/dynamic entry, async loader)")).default, {
    loadableGenerated: {
        modules: [
            "[project]/src/components/Editor3/components/SketchPad.jsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = SketchPad;
;
;
// Component to handle signed URL for word audio
function SignedAudioPlayer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "92cdc43bffc00bb3cacfec6404efafa3acdf5d2c277427b92838633cd5bf4486") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "92cdc43bffc00bb3cacfec6404efafa3acdf5d2c277427b92838633cd5bf4486";
    }
    const { audioKey, identityId, width, height, title } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("workbook");
    const [signedUrl, setSignedUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    let t1;
    if ($[1] !== audioKey) {
        t1 = ({
            "SignedAudioPlayer[useEffect()]": ()=>{
                const signUrl = {
                    "SignedAudioPlayer[useEffect() > signUrl]": async ()=>{
                        if (audioKey) {
                            ;
                            try {
                                const url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(audioKey);
                                setSignedUrl(url);
                            } catch (t2) {
                                const error = t2;
                                console.error("Error signing audio URL:", error);
                            }
                        }
                        setLoading(false);
                    }
                }["SignedAudioPlayer[useEffect() > signUrl]"];
                signUrl();
            }
        })["SignedAudioPlayer[useEffect()]"];
        $[1] = audioKey;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== audioKey || $[4] !== identityId) {
        t2 = [
            audioKey,
            identityId
        ];
        $[3] = audioKey;
        $[4] = identityId;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    if (loading) {
        let t3;
        if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                sx: {
                    opacity: 0.6
                },
                children: "Loading audio..."
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                lineNumber: 85,
                columnNumber: 12
            }, this);
            $[6] = t3;
        } else {
            t3 = $[6];
        }
        return t3;
    }
    if (!signedUrl) {
        let t3;
        if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = {
                opacity: 0.6,
                fontStyle: "italic"
            };
            $[7] = t3;
        } else {
            t3 = $[7];
        }
        let t4;
        if ($[8] !== t) {
            t4 = t("answerComponent.audioNotAvailable");
            $[8] = t;
            $[9] = t4;
        } else {
            t4 = $[9];
        }
        let t5;
        if ($[10] !== t4) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                sx: t3,
                children: t4
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                lineNumber: 115,
                columnNumber: 12
            }, this);
            $[10] = t4;
            $[11] = t5;
        } else {
            t5 = $[11];
        }
        return t5;
    }
    let t3;
    if ($[12] !== height || $[13] !== signedUrl || $[14] !== title || $[15] !== width) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            audioUrl: signedUrl,
            width: width,
            height: height,
            title: title
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
            lineNumber: 125,
            columnNumber: 10
        }, this);
        $[12] = height;
        $[13] = signedUrl;
        $[14] = title;
        $[15] = width;
        $[16] = t3;
    } else {
        t3 = $[16];
    }
    return t3;
}
_s(SignedAudioPlayer, "iQ2ABog0MlsYVs1AWVNAoGZVNxc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c1 = SignedAudioPlayer;
function LinearProgressWithLabel(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    if ($[0] !== "92cdc43bffc00bb3cacfec6404efafa3acdf5d2c277427b92838633cd5bf4486") {
        for(let $i = 0; $i < 11; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "92cdc43bffc00bb3cacfec6404efafa3acdf5d2c277427b92838633cd5bf4486";
    }
    const { value } = t0;
    let t1;
    if ($[1] !== value) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            width: "95%",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                variant: "determinate",
                value: value
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                lineNumber: 149,
                columnNumber: 27
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
            lineNumber: 149,
            columnNumber: 10
        }, this);
        $[1] = value;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            marginLeft: "1rem",
            width: "55%"
        };
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] !== value) {
        t3 = Math.round(value);
        $[4] = value;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const t4 = `${t3}%`;
    let t5;
    if ($[6] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            width: "fit-content",
            marginLeft: 1,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                color: "textSecondary",
                style: t2,
                children: t4
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                lineNumber: 176,
                columnNumber: 50
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
            lineNumber: 176,
            columnNumber: 10
        }, this);
        $[6] = t4;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] !== t1 || $[9] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                display: "flex",
                alignItems: "center",
                margin: 1,
                children: [
                    t1,
                    t5
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                lineNumber: 184,
                columnNumber: 12
            }, this)
        }, void 0, false);
        $[8] = t1;
        $[9] = t5;
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    return t6;
}
_c2 = LinearProgressWithLabel;
function AnswerComponent({ className, format, nodeKey, // setFileIDs,
wordIDs, requestDefinition, customPrompt, allowedInput, promptMethod }) {
    _s1();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("workbook");
    /**
   * Answer Schema
   *
   * ```json
   * {
   *    id: '1',
   *    answer: 'Paris',
   *    grade: 1,
   *    completed: true,
   *    reason: 'Paris is the capital of France.'
   *    model: 'gpt-3',
   * }
   * ```
   *
   * Flow:
   *   check if the answer is correct by calling the chatgpt api with the prompt and answer and ask to confirm if the answer is correct.
   *   provide the answer to the question to the user
   *   record answer for this question in a ref.
   *   update the progress bar with the number of correct answers.
   *   silently record incorrect answers for review, but allow the user to continue and try to answer the question again.
   */ const [answers, setAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [feedback, setFeedback] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [progress, setProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const sharedHistoryState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$history$2f$LexicalHistory$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEmptyHistoryState"])());
    const [currentInputMethod, setCurrentInputMethod] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(allowedInput?.[0] || "text");
    const [allowedInputMethods, setAllowedInputMethods] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(allowedInput?.length > 0 ? allowedInput : [
        "text",
        "audio",
        "writing"
    ]);
    const [currentPromptMethod, setCurrentPromptMethod] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(promptMethod?.[0] || "text");
    const handleInputChange = (event, newInputMethod)=>{
        if (newInputMethod !== null) {
            setCurrentInputMethod(newInputMethod);
        }
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "AnswerComponent.useEffect": ()=>{
            if (allowedInput?.length > 0) {
                setAllowedInputMethods(allowedInput);
                setCurrentInputMethod(allowedInput[0]);
            }
        }
    }["AnswerComponent.useEffect"], [
        JSON.stringify(allowedInput)
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "AnswerComponent.useEffect": ()=>{
            if (promptMethod?.length > 0) {
                setCurrentPromptMethod(promptMethod[0]);
            }
        }
    }["AnswerComponent.useEffect"], [
        JSON.stringify(promptMethod)
    ]);
    const { dictionary, grade, saveGrade, workbook: workbook1 } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { studentMemory, contentContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useVerifyContext$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVerifyContext"])();
    // Reset local state when grade changes (e.g., new grade after unit completion)
    const gradeIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(grade?.id);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "AnswerComponent.useEffect": ()=>{
            if (grade?.id && grade.id !== gradeIdRef.current) {
                gradeIdRef.current = grade.id;
                // Only reset if the new grade has no data for this exercise
                if (!grade?.data?.[nodeKey]) {
                    setAnswers({});
                    setFeedback({});
                    setProgress(0);
                }
            }
        }
    }["AnswerComponent.useEffect"], [
        grade?.id,
        grade?.data,
        nodeKey
    ]);
    let thisPrompt = customPrompt ? customPrompt : "Provide words that best match the following definition(s):";
    thisPrompt = requestDefinition ? "Please define the following word(s):" : thisPrompt;
    // Track completion and save grade
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "AnswerComponent.useEffect": ()=>{
            if (!wordIDs || !feedback || !saveGrade || !nodeKey) return;
            // Check if all words have been answered correctly
            const answeredWords = Object.keys(feedback);
            const correctAnswers = answeredWords.filter({
                "AnswerComponent.useEffect.correctAnswers": (wordId)=>feedback[wordId]?.answer === true
            }["AnswerComponent.useEffect.correctAnswers"]);
            const totalWords = wordIDs.length;
            const answeredCount = answeredWords.length;
            const correctCount = correctAnswers.length;
            // Update local progress bar
            const progressValue = totalWords > 0 ? Math.floor(correctCount / totalWords * 100) : 0;
            setProgress(progressValue);
            // Consider complete if all words have been attempted
            const isComplete = answeredCount >= totalWords;
            const accuracy = totalWords > 0 ? Math.floor(correctCount / totalWords * 100) : 0;
            // Save grade data on every answer (partial and complete)
            if (answeredCount > 0) {
                const currentGradeData = grade?.data || {};
                const updatedGradeData = {
                    ...currentGradeData,
                    [nodeKey]: {
                        complete: isComplete,
                        accuracy,
                        totalWords,
                        correctCount,
                        answeredCount,
                        feedback: feedback
                    }
                };
                saveGrade(updatedGradeData);
            }
        }
    }["AnswerComponent.useEffect"], [
        feedback,
        wordIDs,
        saveGrade,
        nodeKey,
        grade
    ]);
    const blockGradeData = grade?.data?.[nodeKey];
    const nailedIt = blockGradeData?.nailedIt === true;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$WorkbookBlockEnhancements$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WorkbookBlockEnhancements"], {
        blockId: nodeKey,
        nailedIt: nailedIt,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: className,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexGrow: 1
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "h6",
                        component: "div",
                        sx: {
                            flexGrow: 1
                        },
                        children: thisPrompt
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                        lineNumber: 321,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                    lineNumber: 318,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButtonGroup$2f$ToggleButtonGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButtonGroup$3e$__["ToggleButtonGroup"], {
                    exclusive: true,
                    value: currentInputMethod,
                    onChange: handleInputChange,
                    "aria-label": t("answerComponent.inputMethodSelector"),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButton$3e$__["ToggleButton"], {
                            disabled: !allowedInputMethods.includes("text"),
                            value: "text",
                            "aria-label": t("answerComponent.inputMethods.text"),
                            children: t("answerComponent.inputMethods.text")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 329,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButton$3e$__["ToggleButton"], {
                            disabled: !allowedInputMethods.includes("audio"),
                            value: "audio",
                            "aria-label": t("answerComponent.inputMethods.audio"),
                            children: t("answerComponent.inputMethods.audio")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 332,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButton$3e$__["ToggleButton"], {
                            disabled: !allowedInputMethods.includes("writing"),
                            value: "writing",
                            "aria-label": t("answerComponent.inputMethods.writing"),
                            children: t("answerComponent.inputMethods.writing")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 335,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                    lineNumber: 328,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinearProgressWithLabel, {
                        value: progress
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                        lineNumber: 344,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                    lineNumber: 343,
                    columnNumber: 9
                }, this),
                !requestDefinition && ByDefinitionWordList(wordIDs, dictionary, feedback, setAnswers, answers, setFeedback, currentInputMethod, currentPromptMethod, grade, nodeKey, t, sharedHistoryState.current),
                requestDefinition && ByWordList(wordIDs, feedback, dictionary, answers, setAnswers, setFeedback, currentInputMethod, currentPromptMethod, grade, nodeKey, t, saveGrade, sharedHistoryState.current)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
            lineNumber: 317,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
        lineNumber: 316,
        columnNumber: 10
    }, this);
}
_s1(AnswerComponent, "epUmA4lVPfkdQdpbWrMRUT2m2PE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useVerifyContext$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVerifyContext"]
    ];
});
_c3 = AnswerComponent;
function ByWordList(wordIDs, feedback, dictionary, answers, setAnswers, setFeedback, currentInputMethod, currentPromptMethod, grade, nodeKey, t, saveGrade, historyState) {
    // Add defensive check for dictionary
    if (!dictionary) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "error",
            children: t("answerComponent.noDictionaryAvailable")
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
            lineNumber: 354,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
        children: [
            currentInputMethod === "text" && wordIDs.map((wordId, key)=>{
                const isCorrect = feedback[key]?.answer;
                // Skip if word not in dictionary
                if (!dictionary[wordId]) {
                    console.warn(`Word ${wordId} not found in dictionary`);
                    return null;
                }
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    children: [
                        currentPromptMethod === "text" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1
                            },
                            children: dictionary[wordId]?.phrase
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 369,
                            columnNumber: 50
                        }, this),
                        currentPromptMethod === "audio" && (dictionary[wordId]?.audio ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SignedAudioPlayer, {
                            audioKey: dictionary[wordId].audio[0],
                            identityId: dictionary[wordId].identityId,
                            width: 400,
                            height: 60,
                            title: dictionary[wordId].phrase
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 374,
                            columnNumber: 80
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1,
                                fontStyle: "italic",
                                color: "text.disabled"
                            },
                            children: [
                                dictionary[wordId]?.phrase,
                                " ",
                                t("answerComponent.audioNotAvailableParens")
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 374,
                            columnNumber: 244
                        }, this)),
                        isCorrect !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                border: 1,
                                borderColor: isCorrect ? "success.main" : "error.main",
                                borderRadius: 1,
                                p: 1,
                                my: 1,
                                bgcolor: isCorrect ? "success.light" : "error.light",
                                opacity: 0.9
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                children: feedback[key]?.reason || ""
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                lineNumber: 393,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 384,
                            columnNumber: 43
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PlainTextAnswerInput$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            value: answers[key] || "",
                            onChange: (text)=>{
                                setAnswers({
                                    ...answers,
                                    [key]: text
                                });
                            },
                            onAutoSubmit: async (text)=>{
                                const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$527ad9__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["gradeDefinition"])({
                                    word: dictionary[wordId]?.phrase,
                                    definition: text,
                                    expectedDefinition: dictionary[wordId]?.definition
                                });
                                setFeedback({
                                    ...feedback,
                                    [key]: data
                                });
                            },
                            historyState: historyState,
                            placeholder: t("answerComponent.placeholder"),
                            ariaLabel: t("customAnswerComponent.yourAnswer", {
                                ns: "editor"
                            }),
                            testId: "answer-input",
                            wordId: wordId,
                            disabled: isCorrect !== undefined
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 399,
                            columnNumber: 15
                        }, this)
                    ]
                }, `${wordId}-${key}`, true, {
                    fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                    lineNumber: 367,
                    columnNumber: 14
                }, this);
            }),
            currentInputMethod === "audio" && wordIDs.map((wordId, key)=>{
                const isCorrect = feedback[key]?.answer;
                // Skip if word not in dictionary
                if (!dictionary[wordId]) {
                    console.warn(`Word ${wordId} not found in dictionary`);
                    return null;
                }
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    children: [
                        currentPromptMethod === "text" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1
                            },
                            children: dictionary[wordId]?.phrase
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 430,
                            columnNumber: 50
                        }, this),
                        currentPromptMethod === "audio" && (dictionary[wordId]?.audio ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SignedAudioPlayer, {
                            audioKey: dictionary[wordId].audio[0],
                            identityId: dictionary[wordId].identityId,
                            width: 400,
                            height: 60,
                            title: dictionary[wordId].phrase
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 435,
                            columnNumber: 80
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1,
                                fontStyle: "italic",
                                color: "text.disabled"
                            },
                            children: t("answerComponent.audioNotAvailable", {
                                text: dictionary[wordId]?.phrase
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 435,
                            columnNumber: 244
                        }, this)),
                        isCorrect !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                border: 1,
                                borderColor: isCorrect ? "success.main" : "error.main",
                                borderRadius: 1,
                                p: 1,
                                my: 1,
                                bgcolor: isCorrect ? "success.light" : "error.light",
                                opacity: 0.9
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                children: feedback[key]?.reason || ""
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                lineNumber: 455,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 446,
                            columnNumber: 43
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioAutoSubmitWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            children: ({ wrapOnRecordingComplete })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    enableRecording: true,
                                    gradeId: grade?.id,
                                    nodeKey: `${nodeKey}-${wordId}`,
                                    title: dictionary[wordId]?.phrase,
                                    onRecordingComplete: wrapOnRecordingComplete(async (audioFile, uploadResult)=>{
                                        // Verify the recorded audio against expected word
                                        try {
                                            const audioUrl = audioFile?.path || uploadResult?.path;
                                            if (audioUrl) {
                                                const feedbackData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$e468d3__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["transcribeAudio"])({
                                                    audioUrl,
                                                    expectedAnswer: dictionary[wordId]?.phrase
                                                });
                                                if (feedbackData) {
                                                    setFeedback((prev)=>({
                                                            ...prev,
                                                            [key]: feedbackData
                                                        }));
                                                    // Broadcast to collaborators via Yjs
                                                    workbook?.setFeedback?.(nodeKey, {
                                                        text: feedbackData?.reason || "",
                                                        timestamp: Date.now()
                                                    });
                                                }
                                            }
                                        } catch (err) {
                                            console.error("[AnswerComponent] Audio verification error:", err);
                                        }
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                    lineNumber: 463,
                                    columnNumber: 17
                                }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 460,
                            columnNumber: 15
                        }, this)
                    ]
                }, `${wordId}-${key}`, true, {
                    fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                    lineNumber: 428,
                    columnNumber: 14
                }, this);
            }),
            currentInputMethod === "writing" && wordIDs.map((wordId, key)=>{
                const isCorrect = feedback[key]?.answer;
                // Skip if word not in dictionary
                if (!dictionary[wordId]) {
                    console.warn(`Word ${wordId} not found in dictionary`);
                    return null;
                }
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    children: [
                        currentPromptMethod === "text" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1
                            },
                            children: dictionary[wordId]?.phrase
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 503,
                            columnNumber: 50
                        }, this),
                        currentPromptMethod === "audio" && (dictionary[wordId]?.audio ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SignedAudioPlayer, {
                            audioKey: dictionary[wordId].audio[0],
                            identityId: dictionary[wordId].identityId,
                            width: 400,
                            height: 60,
                            title: dictionary[wordId].phrase
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 509,
                            columnNumber: 80
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1,
                                fontStyle: "italic",
                                color: "text.disabled"
                            },
                            children: t("answerComponent.audioNotAvailable", {
                                text: dictionary[wordId]?.phrase
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 509,
                            columnNumber: 244
                        }, this)),
                        isCorrect !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                border: 1,
                                borderColor: isCorrect ? "success.main" : "error.main",
                                borderRadius: 1,
                                p: 1,
                                my: 1,
                                bgcolor: isCorrect ? "success.light" : "error.light",
                                opacity: 0.9
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                children: feedback[key]?.reason || ""
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                lineNumber: 529,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 520,
                            columnNumber: 43
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
                            fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                children: "Loading..."
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                lineNumber: 534,
                                columnNumber: 35
                            }, this),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SketchPad, {
                                expect: dictionary[wordId]?.definition,
                                excalidrawData: {},
                                setFeedback: (data)=>{
                                    setFeedback({
                                        ...feedback,
                                        [key]: data
                                    });
                                    // Broadcast to collaborators via Yjs
                                    workbook?.setFeedback?.(nodeKey, {
                                        text: data?.reason || "",
                                        timestamp: Date.now()
                                    });
                                },
                                feedback: feedback,
                                questionID: key
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                lineNumber: 535,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 534,
                            columnNumber: 15
                        }, this)
                    ]
                }, `${wordId}-${key}`, true, {
                    fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                    lineNumber: 501,
                    columnNumber: 14
                }, this);
            })
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
        lineNumber: 358,
        columnNumber: 10
    }, this);
}
_c4 = ByWordList;
function ByDefinitionWordList(wordIDs, dictionary, feedback, setAnswers, answers, setFeedback, currentInputMethod, currentPromptMethod, grade, nodeKey, t, historyState) {
    // Add defensive check for dictionary
    if (!dictionary) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "error",
            children: t("answerComponent.noDictionaryAvailable")
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
            lineNumber: 554,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
        children: [
            currentInputMethod === "text" && wordIDs.map((wordId, key)=>{
                const isCorrect = feedback[key]?.answer;
                // Skip if word not in dictionary
                if (!dictionary[wordId]) {
                    console.warn(`Word ${wordId} not found in dictionary`);
                    return null;
                }
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    children: [
                        currentPromptMethod === "text" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1
                            },
                            children: dictionary[wordId]?.definition
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 569,
                            columnNumber: 50
                        }, this),
                        currentPromptMethod === "audio" && (dictionary[wordId]?.definitionAudio ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SignedAudioPlayer, {
                            audioKey: dictionary[wordId].definitionAudio[0],
                            identityId: dictionary[wordId].identityId,
                            width: 400,
                            height: 60,
                            title: dictionary[wordId].definition
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 575,
                            columnNumber: 90
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1,
                                fontStyle: "italic",
                                color: "text.disabled"
                            },
                            children: t("answerComponent.audioNotAvailable", {
                                text: dictionary[wordId]?.definition
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 575,
                            columnNumber: 268
                        }, this)),
                        isCorrect !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                border: 1,
                                borderColor: isCorrect ? "success.main" : "error.main",
                                borderRadius: 1,
                                p: 1,
                                my: 1,
                                bgcolor: isCorrect ? "success.light" : "error.light",
                                opacity: 0.9
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                children: feedback[key]?.reason || ""
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                lineNumber: 595,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 586,
                            columnNumber: 43
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PlainTextAnswerInput$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            value: answers[key] || "",
                            onChange: (text)=>{
                                setAnswers({
                                    ...answers,
                                    [key]: text
                                });
                            },
                            onAutoSubmit: async (text)=>{
                                const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$527ad9__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["gradeDefinition"])({
                                    word: text,
                                    definition: dictionary[wordId]?.definition,
                                    expectedDefinition: dictionary[wordId]?.phrase
                                });
                                setFeedback({
                                    ...feedback,
                                    [key]: data
                                });
                            },
                            historyState: historyState,
                            placeholder: t("answerComponent.placeholder"),
                            ariaLabel: t("customAnswerComponent.yourAnswer", {
                                ns: "editor"
                            }),
                            testId: "answer-input",
                            wordId: wordId,
                            disabled: isCorrect !== undefined
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 601,
                            columnNumber: 15
                        }, this)
                    ]
                }, `${wordId}-${key}`, true, {
                    fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                    lineNumber: 567,
                    columnNumber: 14
                }, this);
            }),
            currentInputMethod === "audio" && wordIDs.map((wordId, key)=>{
                const isCorrect = feedback[key]?.answer;
                // Skip if word not in dictionary
                if (!dictionary[wordId]) {
                    console.warn(`Word ${wordId} not found in dictionary`);
                    return null;
                }
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    children: [
                        currentPromptMethod === "text" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1
                            },
                            children: dictionary[wordId]?.definition
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 632,
                            columnNumber: 50
                        }, this),
                        currentPromptMethod === "audio" && (dictionary[wordId]?.definitionAudio ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SignedAudioPlayer, {
                            audioKey: dictionary[wordId].definitionAudio[0],
                            identityId: dictionary[wordId].identityId,
                            width: 400,
                            height: 60,
                            title: dictionary[wordId].definition
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 638,
                            columnNumber: 90
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1,
                                fontStyle: "italic",
                                color: "text.disabled"
                            },
                            children: t("answerComponent.audioNotAvailable", {
                                text: dictionary[wordId]?.definition
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 638,
                            columnNumber: 268
                        }, this)),
                        isCorrect !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                border: 1,
                                borderColor: isCorrect ? "success.main" : "error.main",
                                borderRadius: 1,
                                p: 1,
                                my: 1,
                                bgcolor: isCorrect ? "success.light" : "error.light",
                                opacity: 0.9
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                children: feedback[key]?.reason || ""
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                lineNumber: 658,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 649,
                            columnNumber: 43
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioAutoSubmitWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            children: ({ wrapOnRecordingComplete })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    enableRecording: true,
                                    gradeId: grade?.id,
                                    nodeKey: `${nodeKey}-${wordId}`,
                                    title: dictionary[wordId]?.definition,
                                    onRecordingComplete: wrapOnRecordingComplete(async (audioFile, uploadResult)=>{
                                        // Verify the recorded audio against expected word
                                        try {
                                            const audioUrl = audioFile?.path || uploadResult?.path;
                                            if (audioUrl) {
                                                const feedbackData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$e468d3__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["transcribeAudio"])({
                                                    audioUrl,
                                                    expectedAnswer: dictionary[wordId]?.phrase
                                                });
                                                if (feedbackData) {
                                                    setFeedback((prev)=>({
                                                            ...prev,
                                                            [key]: feedbackData
                                                        }));
                                                }
                                            }
                                        } catch (err) {
                                            console.error("[AnswerComponent] Audio verification error:", err);
                                        }
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                    lineNumber: 666,
                                    columnNumber: 17
                                }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 663,
                            columnNumber: 15
                        }, this)
                    ]
                }, `${wordId}-${key}`, true, {
                    fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                    lineNumber: 630,
                    columnNumber: 14
                }, this);
            }),
            currentInputMethod === "writing" && wordIDs.map((wordId, key)=>{
                const isCorrect = feedback[key]?.answer;
                // Skip if word not in dictionary
                if (!dictionary[wordId]) {
                    console.warn(`Word ${wordId} not found in dictionary`);
                    return null;
                }
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    children: [
                        currentPromptMethod === "text" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1
                            },
                            children: dictionary[wordId]?.definition
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 700,
                            columnNumber: 50
                        }, this),
                        currentPromptMethod === "audio" && (dictionary[wordId]?.definitionAudio ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SignedAudioPlayer, {
                            audioKey: dictionary[wordId].definitionAudio[0],
                            identityId: dictionary[wordId].identityId,
                            width: 400,
                            height: 60,
                            title: dictionary[wordId].definition
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 706,
                            columnNumber: 90
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            component: "div",
                            sx: {
                                flexGrow: 1,
                                fontStyle: "italic",
                                color: "text.disabled"
                            },
                            children: t("answerComponent.audioNotAvailable", {
                                text: dictionary[wordId]?.definition
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 706,
                            columnNumber: 268
                        }, this)),
                        isCorrect !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                border: 1,
                                borderColor: isCorrect ? "success.main" : "error.main",
                                borderRadius: 1,
                                p: 1,
                                my: 1,
                                bgcolor: isCorrect ? "success.light" : "error.light",
                                opacity: 0.9
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                children: feedback[key]?.reason || ""
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                lineNumber: 726,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 717,
                            columnNumber: 43
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
                            fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                children: "Loading..."
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                lineNumber: 731,
                                columnNumber: 35
                            }, this),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SketchPad, {
                                expect: dictionary[wordId]?.definition,
                                excalidrawData: {},
                                requestDefinition: true,
                                setFeedback: (data)=>{
                                    setFeedback({
                                        ...feedback,
                                        [key]: data
                                    });
                                },
                                feedback: feedback,
                                questionID: key
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                                lineNumber: 732,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                            lineNumber: 731,
                            columnNumber: 15
                        }, this)
                    ]
                }, `${wordId}-${key}`, true, {
                    fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
                    lineNumber: 698,
                    columnNumber: 14
                }, this);
            })
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/AnswerComponent.jsx",
        lineNumber: 558,
        columnNumber: 10
    }, this);
}
_c5 = ByDefinitionWordList;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "SketchPad");
__turbopack_context__.k.register(_c1, "SignedAudioPlayer");
__turbopack_context__.k.register(_c2, "LinearProgressWithLabel");
__turbopack_context__.k.register(_c3, "AnswerComponent");
__turbopack_context__.k.register(_c4, "ByWordList");
__turbopack_context__.k.register(_c5, "ByDefinitionWordList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ActionsMenu",
    ()=>ActionsMenu,
    "default",
    ()=>MeaningAssociationEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$DataGrid$2f$DataGrid$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/DataGrid/DataGrid.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Menu/Menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContentText$2f$DialogContentText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContentText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContentText/DialogContentText.js [app-client] (ecmascript) <export default as DialogContentText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextareaAutosize/TextareaAutosize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Autocomplete/Autocomplete.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useAutocomplete$2f$useAutocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/useAutocomplete/useAutocomplete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/useLexicalNodeSelection.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/MeaningAssociationPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MoreVert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const filter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useAutocomplete$2f$useAutocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createFilterOptions"])();
const getColumns = (t)=>[
        {
            field: "phrase",
            headerName: t("meaningAssociationEditor.columnHeaders.phrase"),
            flex: 1,
            minWidth: 100
        },
        {
            field: "pronunciation",
            headerName: t("meaningAssociationEditor.columnHeaders.pronunciation"),
            flex: 1,
            minWidth: 100
        },
        {
            field: "definition",
            headerName: t("meaningAssociationEditor.columnHeaders.definition"),
            flex: 1,
            minWidth: 200
        }
    ];
function ActionsMenu(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(24);
    if ($[0] !== "3261df7a4d9a99963a784579000c6f25786fa9e7111e74f8ad7ac1ea14b5e289") {
        for(let $i = 0; $i < 24; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "3261df7a4d9a99963a784579000c6f25786fa9e7111e74f8ad7ac1ea14b5e289";
    }
    const { ids, removeWordIDs } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.blocks");
    const [anchorEl, setAnchorEl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const open = Boolean(anchorEl);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "ActionsMenu[handleClick]": (event)=>{
                setAnchorEl(event.currentTarget);
            }
        })["ActionsMenu[handleClick]"];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const handleClick = t1;
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "ActionsMenu[handleClose]": ()=>{
                setAnchorEl(null);
            }
        })["ActionsMenu[handleClose]"];
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const handleClose = t2;
    let t3;
    if ($[3] !== ids || $[4] !== removeWordIDs) {
        t3 = ({
            "ActionsMenu[removeFromAssignment]": ()=>{
                console.log("removeFromAssignment", ids);
                removeWordIDs(ids);
                setAnchorEl(null);
            }
        })["ActionsMenu[removeFromAssignment]"];
        $[3] = ids;
        $[4] = removeWordIDs;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const removeFromAssignment = t3;
    const t4 = open ? "basic-menu" : undefined;
    const t5 = open ? "true" : undefined;
    let t6;
    let t7;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            minWidth: "3rem",
            margin: "0 0 0 0.5rem"
        };
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 99,
            columnNumber: 10
        }, this);
        $[6] = t6;
        $[7] = t7;
    } else {
        t6 = $[6];
        t7 = $[7];
    }
    let t8;
    if ($[8] !== t4 || $[9] !== t5) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            id: "basic-button",
            color: "inherit",
            "aria-controls": t4,
            "aria-haspopup": "true",
            "aria-expanded": t5,
            onClick: handleClick,
            sx: t6,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 108,
            columnNumber: 10
        }, this);
        $[8] = t4;
        $[9] = t5;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            "aria-labelledby": "basic-button"
        };
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    let t10;
    if ($[12] !== t) {
        t10 = t("meaningAssociationEditor.removeFromAssignment");
        $[12] = t;
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] !== removeFromAssignment || $[15] !== t10) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            onClick: removeFromAssignment,
            children: t10
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 134,
            columnNumber: 11
        }, this);
        $[14] = removeFromAssignment;
        $[15] = t10;
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    let t12;
    if ($[17] !== anchorEl || $[18] !== open || $[19] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
            id: "basic-menu",
            anchorEl: anchorEl,
            open: open,
            onClose: handleClose,
            MenuListProps: t9,
            children: t11
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 143,
            columnNumber: 11
        }, this);
        $[17] = anchorEl;
        $[18] = open;
        $[19] = t11;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] !== t12 || $[22] !== t8) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t8,
                t12
            ]
        }, void 0, true);
        $[21] = t12;
        $[22] = t8;
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    return t13;
}
_s(ActionsMenu, "SoyN0DQMkGLnpyIiGHEDfYwt7xE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = ActionsMenu;
function MeaningAssociationEditor(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(126);
    if ($[0] !== "3261df7a4d9a99963a784579000c6f25786fa9e7111e74f8ad7ac1ea14b5e289") {
        for(let $i = 0; $i < 126; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "3261df7a4d9a99963a784579000c6f25786fa9e7111e74f8ad7ac1ea14b5e289";
    }
    const { nodeKey, wordIDs, enabledModes: t1 } = t0;
    t1 === undefined ? [
        "learn",
        "easy",
        "hard"
    ] : t1;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.blocks");
    const [value, setValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const [open, toggleOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = new Set();
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    const [gridSelection, setGridSelection] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](t2);
    let t3;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            phrase: "",
            definition: "",
            pronunciation: ""
        };
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    const [dialogValue, setDialogValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](t3);
    const { wordMapId } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { unit } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let rows;
    if ($[3] !== wordIDs || $[4] !== wordMapId) {
        rows = [];
        if (wordIDs) {
            wordIDs.forEach({
                "MeaningAssociationEditor[wordIDs.forEach()]": (id)=>{
                    const word = wordMapId[id];
                    if (word) {
                        rows.push({
                            id: word.id,
                            phrase: word.phrase,
                            pronunciation: word.pronunciation,
                            definition: word.definition
                        });
                    }
                }
            }["MeaningAssociationEditor[wordIDs.forEach()]"]);
        }
        $[3] = wordIDs;
        $[4] = wordMapId;
        $[5] = rows;
    } else {
        rows = $[5];
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const meaningAssociationRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [isSelected, setSelected, clearSelection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"])(nodeKey);
    let t4;
    if ($[6] !== wordMapId) {
        t4 = Object.values(wordMapId);
        $[6] = wordMapId;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    const _dictionary = t4;
    let t5;
    if ($[8] !== isSelected || $[9] !== nodeKey || $[10] !== wordIDs) {
        t5 = ({
            "MeaningAssociationEditor[onDelete]": async (payload)=>{
                if (isSelected && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])())) {
                    const event = payload;
                    event.preventDefault();
                    const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isMeaningAssociationNode"])(node)) {
                        node.remove();
                        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                        const _operations = [];
                        wordIDs.forEach({
                            "MeaningAssociationEditor[onDelete > wordIDs.forEach()]": (id_0)=>{
                                _operations.push(client.models.UnitWord.delete({
                                    id: id_0
                                }));
                            }
                        }["MeaningAssociationEditor[onDelete > wordIDs.forEach()]"]);
                        await Promise.allSettled(_operations);
                    }
                }
                return false;
            }
        })["MeaningAssociationEditor[onDelete]"];
        $[8] = isSelected;
        $[9] = nodeKey;
        $[10] = wordIDs;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    const onDelete = t5;
    let t6;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "MeaningAssociationEditor[handleClose]": ()=>{
                setDialogValue({
                    phrase: "",
                    pronunciation: "",
                    definition: ""
                });
                toggleOpen(false);
            }
        })["MeaningAssociationEditor[handleClose]"];
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    const handleClose = t6;
    let t7;
    if ($[13] !== editor || $[14] !== nodeKey || $[15] !== unit) {
        t7 = ({
            "MeaningAssociationEditor[addWordID]": (id_1)=>{
                editor.update({
                    "MeaningAssociationEditor[addWordID > editor.update()]": async ()=>{
                        const node_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isMeaningAssociationNode"])(node_0)) {
                            node_0.appendId(id_1);
                            if (unit) {
                                const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                                const { data: word_0 } = await client_0.models.Word.get({
                                    id: id_1
                                });
                                if (word_0) {
                                    await client_0.models.UnitWord.create({
                                        unitID: unit.id,
                                        wordID: word_0.id
                                    });
                                }
                            }
                        }
                    }
                }["MeaningAssociationEditor[addWordID > editor.update()]"]);
            }
        })["MeaningAssociationEditor[addWordID]"];
        $[13] = editor;
        $[14] = nodeKey;
        $[15] = unit;
        $[16] = t7;
    } else {
        t7 = $[16];
    }
    const addWordID = t7;
    let t8;
    if ($[17] !== editor || $[18] !== nodeKey) {
        t8 = ({
            "MeaningAssociationEditor[removeWordIDs]": (ids)=>{
                editor.update({
                    "MeaningAssociationEditor[removeWordIDs > editor.update()]": async ()=>{
                        const node_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isMeaningAssociationNode"])(node_1)) {
                            node_1.removeIntersection(ids);
                            const client_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                            const _operations_0 = [];
                            ids.forEach({
                                "MeaningAssociationEditor[removeWordIDs > editor.update() > ids.forEach()]": (id_2)=>{
                                    _operations_0.push(client_1.models.UnitWord.delete({
                                        id: id_2
                                    }));
                                }
                            }["MeaningAssociationEditor[removeWordIDs > editor.update() > ids.forEach()]"]);
                            await Promise.allSettled(_operations_0);
                        }
                    }
                }["MeaningAssociationEditor[removeWordIDs > editor.update()]"]);
            }
        })["MeaningAssociationEditor[removeWordIDs]"];
        $[17] = editor;
        $[18] = nodeKey;
        $[19] = t8;
    } else {
        t8 = $[19];
    }
    const removeWordIDs = t8;
    let t9;
    if ($[20] !== dialogValue.phrase) {
        t9 = ({
            "MeaningAssociationEditor[handleSubmit]": (event_0)=>{
                event_0.preventDefault();
                setValue({
                    phrase: dialogValue.phrase
                });
                handleClose();
            }
        })["MeaningAssociationEditor[handleSubmit]"];
        $[20] = dialogValue.phrase;
        $[21] = t9;
    } else {
        t9 = $[21];
    }
    const handleSubmit = t9;
    let t10;
    if ($[22] !== clearSelection || $[23] !== editor || $[24] !== onDelete || $[25] !== setSelected) {
        t10 = ({
            "MeaningAssociationEditor[useEffect()]": ()=>{
                let isMounted = true;
                const unregister = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CLICK_COMMAND"], {
                    "MeaningAssociationEditor[useEffect() > editor.registerCommand()]": (payload_0)=>{
                        const event_1 = payload_0;
                        if (meaningAssociationRef.current && meaningAssociationRef.current.contains(event_1.target)) {
                            event_1.preventDefault();
                            if (event_1.shiftKey) {
                                setSelected(_MeaningAssociationEditorUseEffectEditorRegisterCommandSetSelected);
                            } else {
                                setSelected({
                                    "MeaningAssociationEditor[useEffect() > editor.registerCommand() > setSelected()]": (prev_0)=>{
                                        if (!prev_0) {
                                            clearSelection();
                                        }
                                        return true;
                                    }
                                }["MeaningAssociationEditor[useEffect() > editor.registerCommand() > setSelected()]"]);
                            }
                            return true;
                        }
                        return false;
                    }
                }["MeaningAssociationEditor[useEffect() > editor.registerCommand()]"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_DELETE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_BACKSPACE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]));
                return ()=>{
                    isMounted = false;
                    unregister();
                };
            }
        })["MeaningAssociationEditor[useEffect()]"];
        $[22] = clearSelection;
        $[23] = editor;
        $[24] = onDelete;
        $[25] = setSelected;
        $[26] = t10;
    } else {
        t10 = $[26];
    }
    let t11;
    if ($[27] !== clearSelection || $[28] !== editor || $[29] !== isSelected || $[30] !== nodeKey || $[31] !== onDelete || $[32] !== setSelected) {
        t11 = [
            clearSelection,
            editor,
            isSelected,
            nodeKey,
            onDelete,
            setSelected
        ];
        $[27] = clearSelection;
        $[28] = editor;
        $[29] = isSelected;
        $[30] = nodeKey;
        $[31] = onDelete;
        $[32] = setSelected;
        $[33] = t11;
    } else {
        t11 = $[33];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t10, t11);
    const t12 = isSelected ? "2px solid var(--mui-palette-primary-main, #1976d2)" : "1px solid transparent";
    let t13;
    if ($[34] !== t12) {
        t13 = {
            maxHeight: "32rem",
            maxWidth: "72rem",
            border: t12,
            borderRadius: "4px",
            padding: "8px",
            cursor: "pointer"
        };
        $[34] = t12;
        $[35] = t13;
    } else {
        t13 = $[35];
    }
    let t14;
    if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = {
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between"
        };
        $[36] = t14;
    } else {
        t14 = $[36];
    }
    let t15;
    if ($[37] !== addWordID) {
        t15 = ({
            "MeaningAssociationEditor[<Autocomplete>.onChange]": (event_2, newValue)=>{
                if (typeof newValue === "string") {
                    setTimeout({
                        "MeaningAssociationEditor[<Autocomplete>.onChange > setTimeout()]": ()=>{
                            toggleOpen(true);
                            setDialogValue({
                                phrase: newValue,
                                pronunciation: "",
                                definition: ""
                            });
                        }
                    }["MeaningAssociationEditor[<Autocomplete>.onChange > setTimeout()]"]);
                } else {
                    if (newValue && newValue.inputValue) {
                        toggleOpen(true);
                        setDialogValue({
                            phrase: newValue.inputValue,
                            pronunciation: "",
                            definition: ""
                        });
                    } else {
                        console.log("Autocomplete.newValue", newValue);
                        const newWordID = newValue?.id;
                        if (newWordID) {
                            addWordID(newWordID);
                            setValue(null);
                            setDialogValue({
                                phrase: "",
                                pronunciation: "",
                                definition: ""
                            });
                        }
                    }
                }
            }
        })["MeaningAssociationEditor[<Autocomplete>.onChange]"];
        $[37] = addWordID;
        $[38] = t15;
    } else {
        t15 = $[38];
    }
    let t16;
    if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            flexGrow: 1
        };
        $[39] = t16;
    } else {
        t16 = $[39];
    }
    let t17;
    if ($[40] !== t) {
        t17 = ({
            "MeaningAssociationEditor[<Autocomplete>.renderInput]": (params_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                    ...params_0,
                    label: t("meaningAssociationEditor.addWordLabel")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
                    lineNumber: 513,
                    columnNumber: 75
                }, this)
        })["MeaningAssociationEditor[<Autocomplete>.renderInput]"];
        $[40] = t;
        $[41] = t17;
    } else {
        t17 = $[41];
    }
    let t18;
    if ($[42] !== _dictionary || $[43] !== t15 || $[44] !== t17 || $[45] !== value) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"], {
            value: value,
            onChange: t15,
            filterOptions: _MeaningAssociationEditorAutocompleteFilterOptions,
            sx: t16,
            id: "add-new-word",
            options: _dictionary,
            getOptionLabel: _MeaningAssociationEditorAutocompleteGetOptionLabel,
            selectOnFocus: true,
            clearOnBlur: true,
            handleHomeEndKeys: true,
            renderOption: _MeaningAssociationEditorAutocompleteRenderOption,
            freeSolo: true,
            renderInput: t17
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 522,
            columnNumber: 11
        }, this);
        $[42] = _dictionary;
        $[43] = t15;
        $[44] = t17;
        $[45] = value;
        $[46] = t18;
    } else {
        t18 = $[46];
    }
    let t19;
    if ($[47] !== gridSelection) {
        t19 = [
            ...gridSelection
        ];
        $[47] = gridSelection;
        $[48] = t19;
    } else {
        t19 = $[48];
    }
    let t20;
    if ($[49] !== removeWordIDs || $[50] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ActionsMenu, {
            removeWordIDs: removeWordIDs,
            ids: t19
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 541,
            columnNumber: 11
        }, this);
        $[49] = removeWordIDs;
        $[50] = t19;
        $[51] = t20;
    } else {
        t20 = $[51];
    }
    let t21;
    if ($[52] !== t18 || $[53] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: t14,
            children: [
                t18,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 550,
            columnNumber: 11
        }, this);
        $[52] = t18;
        $[53] = t20;
        $[54] = t21;
    } else {
        t21 = $[54];
    }
    let t22;
    if ($[55] !== t) {
        t22 = t("meaningAssociationEditor.dialogTitle");
        $[55] = t;
        $[56] = t22;
    } else {
        t22 = $[56];
    }
    let t23;
    if ($[57] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
            children: t22
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 567,
            columnNumber: 11
        }, this);
        $[57] = t22;
        $[58] = t23;
    } else {
        t23 = $[58];
    }
    let t24;
    if ($[59] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = {
            display: "flex",
            flexDirection: "column",
            width: "fit-content"
        };
        $[59] = t24;
    } else {
        t24 = $[59];
    }
    let t25;
    if ($[60] !== t) {
        t25 = t("meaningAssociationEditor.dialogDescription");
        $[60] = t;
        $[61] = t25;
    } else {
        t25 = $[61];
    }
    let t26;
    if ($[62] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContentText$2f$DialogContentText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContentText$3e$__["DialogContentText"], {
            children: t25
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 594,
            columnNumber: 11
        }, this);
        $[62] = t25;
        $[63] = t26;
    } else {
        t26 = $[63];
    }
    const t27 = dialogValue.phrase;
    let t28;
    if ($[64] !== dialogValue) {
        t28 = ({
            "MeaningAssociationEditor[<TextField>.onChange]": (event_3)=>setDialogValue({
                    ...dialogValue,
                    phrase: event_3.target.value
                })
        })["MeaningAssociationEditor[<TextField>.onChange]"];
        $[64] = dialogValue;
        $[65] = t28;
    } else {
        t28 = $[65];
    }
    let t29;
    if ($[66] !== t) {
        t29 = t("meaningAssociationEditor.phraseLabel");
        $[66] = t;
        $[67] = t29;
    } else {
        t29 = $[67];
    }
    let t30;
    if ($[68] !== dialogValue.phrase || $[69] !== t28 || $[70] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
            autoFocus: true,
            margin: "dense",
            id: "name",
            value: t27,
            onChange: t28,
            label: t29,
            type: "text",
            variant: "standard"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 624,
            columnNumber: 11
        }, this);
        $[68] = dialogValue.phrase;
        $[69] = t28;
        $[70] = t29;
        $[71] = t30;
    } else {
        t30 = $[71];
    }
    const t31 = dialogValue.pronunciation;
    let t32;
    if ($[72] !== dialogValue) {
        t32 = ({
            "MeaningAssociationEditor[<TextField>.onChange]": (event_4)=>setDialogValue({
                    ...dialogValue,
                    pronunciation: event_4.target.value
                })
        })["MeaningAssociationEditor[<TextField>.onChange]"];
        $[72] = dialogValue;
        $[73] = t32;
    } else {
        t32 = $[73];
    }
    let t33;
    if ($[74] !== t) {
        t33 = t("meaningAssociationEditor.pronunciationLabel");
        $[74] = t;
        $[75] = t33;
    } else {
        t33 = $[75];
    }
    let t34;
    if ($[76] !== dialogValue.pronunciation || $[77] !== t32 || $[78] !== t33) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
            margin: "dense",
            id: "pronunciation",
            value: t31,
            onChange: t32,
            label: t33,
            type: "text",
            variant: "standard"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 656,
            columnNumber: 11
        }, this);
        $[76] = dialogValue.pronunciation;
        $[77] = t32;
        $[78] = t33;
        $[79] = t34;
    } else {
        t34 = $[79];
    }
    let t35;
    if ($[80] === Symbol.for("react.memo_cache_sentinel")) {
        t35 = {
            width: "100%",
            marginTop: "1rem"
        };
        $[80] = t35;
    } else {
        t35 = $[80];
    }
    const t36 = dialogValue.definition;
    let t37;
    if ($[81] !== dialogValue) {
        t37 = ({
            "MeaningAssociationEditor[<TextareaAutosize>.onChange]": (event_5)=>setDialogValue({
                    ...dialogValue,
                    definition: event_5.target.value
                })
        })["MeaningAssociationEditor[<TextareaAutosize>.onChange]"];
        $[81] = dialogValue;
        $[82] = t37;
    } else {
        t37 = $[82];
    }
    let t38;
    if ($[83] !== t) {
        t38 = t("meaningAssociationEditor.definitionPlaceholder");
        $[83] = t;
        $[84] = t38;
    } else {
        t38 = $[84];
    }
    let t39;
    if ($[85] !== dialogValue.definition || $[86] !== t37 || $[87] !== t38) {
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            minRows: 3,
            style: t35,
            id: "definition",
            value: t36,
            onChange: t37,
            "aria-label": "Definition",
            placeholder: t38,
            type: "text",
            variant: "standard"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 698,
            columnNumber: 11
        }, this);
        $[85] = dialogValue.definition;
        $[86] = t37;
        $[87] = t38;
        $[88] = t39;
    } else {
        t39 = $[88];
    }
    let t40;
    if ($[89] !== t26 || $[90] !== t30 || $[91] !== t34 || $[92] !== t39) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
            sx: t24,
            children: [
                t26,
                t30,
                t34,
                t39
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 708,
            columnNumber: 11
        }, this);
        $[89] = t26;
        $[90] = t30;
        $[91] = t34;
        $[92] = t39;
        $[93] = t40;
    } else {
        t40 = $[93];
    }
    let t41;
    if ($[94] !== t) {
        t41 = t("meaningAssociationEditor.cancel");
        $[94] = t;
        $[95] = t41;
    } else {
        t41 = $[95];
    }
    let t42;
    if ($[96] !== t41) {
        t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: handleClose,
            children: t41
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 727,
            columnNumber: 11
        }, this);
        $[96] = t41;
        $[97] = t42;
    } else {
        t42 = $[97];
    }
    let t43;
    if ($[98] !== t) {
        t43 = t("meaningAssociationEditor.add");
        $[98] = t;
        $[99] = t43;
    } else {
        t43 = $[99];
    }
    let t44;
    if ($[100] !== t43) {
        t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            type: "submit",
            variant: "contained",
            color: "primary",
            children: t43
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 743,
            columnNumber: 11
        }, this);
        $[100] = t43;
        $[101] = t44;
    } else {
        t44 = $[101];
    }
    let t45;
    if ($[102] !== t42 || $[103] !== t44) {
        t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
            children: [
                t42,
                t44
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 751,
            columnNumber: 11
        }, this);
        $[102] = t42;
        $[103] = t44;
        $[104] = t45;
    } else {
        t45 = $[104];
    }
    let t46;
    if ($[105] !== handleSubmit || $[106] !== t23 || $[107] !== t40 || $[108] !== t45) {
        t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: handleSubmit,
            children: [
                t23,
                t40,
                t45
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 760,
            columnNumber: 11
        }, this);
        $[105] = handleSubmit;
        $[106] = t23;
        $[107] = t40;
        $[108] = t45;
        $[109] = t46;
    } else {
        t46 = $[109];
    }
    let t47;
    if ($[110] !== open || $[111] !== t46) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
            open: open,
            onClose: handleClose,
            children: t46
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 771,
            columnNumber: 11
        }, this);
        $[110] = open;
        $[111] = t46;
        $[112] = t47;
    } else {
        t47 = $[112];
    }
    let t48;
    if ($[113] !== rows.length || $[114] !== t) {
        t48 = rows.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                marginTop: "0.5"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: t("meaningAssociationEditor.emptyState")
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
                lineNumber: 782,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 780,
            columnNumber: 32
        }, this);
        $[113] = rows.length;
        $[114] = t;
        $[115] = t48;
    } else {
        t48 = $[115];
    }
    let t49;
    if ($[116] !== gridSelection || $[117] !== rows || $[118] !== t) {
        t49 = rows.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$DataGrid$2f$DataGrid$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DataGrid"], {
            sx: {
                marginTop: "0.5rem"
            },
            rows: rows,
            columns: getColumns(t),
            initialState: {
                pagination: {
                    paginationModel: {
                        page: 0,
                        pageSize: 10
                    }
                }
            },
            pageSizeOptions: [
                5,
                10,
                100
            ],
            checkboxSelection: true,
            rowSelectionModel: gridSelection,
            onRowSelectionModelChange: {
                "MeaningAssociationEditor[<DataGrid>.onRowSelectionModelChange]": (newSelection)=>{
                    setGridSelection(newSelection);
                }
            }["MeaningAssociationEditor[<DataGrid>.onRowSelectionModelChange]"]
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 791,
            columnNumber: 30
        }, this);
        $[116] = gridSelection;
        $[117] = rows;
        $[118] = t;
        $[119] = t49;
    } else {
        t49 = $[119];
    }
    let t50;
    if ($[120] !== t13 || $[121] !== t21 || $[122] !== t47 || $[123] !== t48 || $[124] !== t49) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: meaningAssociationRef,
            style: t13,
            children: [
                t21,
                t47,
                t48,
                t49
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
            lineNumber: 814,
            columnNumber: 11
        }, this);
        $[120] = t13;
        $[121] = t21;
        $[122] = t47;
        $[123] = t48;
        $[124] = t49;
        $[125] = t50;
    } else {
        t50 = $[125];
    }
    return t50;
}
_s1(MeaningAssociationEditor, "GHr2S1gwMKQkbcaVhKk7dK3aFFg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"]
    ];
});
_c1 = MeaningAssociationEditor;
function _MeaningAssociationEditorAutocompleteRenderOption(props, option_0, t0) {
    const { index } = t0;
    let phrase = option_0.phrase;
    if (option_0.phrase && option_0.pronunciation) {
        phrase = `${option_0.phrase} (${option_0.pronunciation})`;
    }
    const { key, ...otherProps } = props;
    const uniqueKey = option_0.id || `${option_0.phrase}-${index}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        ...otherProps,
        children: phrase
    }, uniqueKey, false, {
        fileName: "[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx",
        lineNumber: 839,
        columnNumber: 10
    }, this);
}
function _MeaningAssociationEditorAutocompleteGetOptionLabel(option) {
    if (typeof option === "string") {
        return option;
    }
    if (option.inputValue) {
        return option.inputValue;
    }
    return option.phrase;
}
function _MeaningAssociationEditorAutocompleteFilterOptions(options, params) {
    const filtered = filter(options, params);
    if (params.inputValue !== "") {
        filtered.push({
            inputValue: params.inputValue,
            phrase: `Add "${params.inputValue}"`
        });
    }
    return filtered;
}
function _MeaningAssociationEditorUseEffectEditorRegisterCommandSetSelected(prev) {
    return !prev;
}
var _c, _c1;
__turbopack_context__.k.register(_c, "ActionsMenu");
__turbopack_context__.k.register(_c1, "MeaningAssociationEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/PdfViewerNode.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createPdfViewerNode",
    ()=>$createPdfViewerNode,
    "$isPdfViewerNode",
    ()=>$isPdfViewerNode,
    "PdfViewerNode",
    ()=>PdfViewerNode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview PdfViewerNode - Lexical DecoratorNode for PDF documents.
 * 
 * Embeds PDF documents with viewing capabilities in the Lexical editor.
 * Stores PDF path, identity ID, and filename for S3 access.
 * 
 * @module PdfViewerNode
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
const PdfViewerComponent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"](()=>__turbopack_context__.A("[project]/src/components/Editor3/components/PdfViewerComponent.jsx [app-client] (ecmascript, async loader)"));
_c = PdfViewerComponent;
/**
 * Converts a DOM element into a PdfViewerNode.
 * 
 * @param {HTMLElement} domNode - DOM element with PDF data attributes
 * @returns {{node: PdfViewerNode} | null} Created node or null
 */ function convertPdfElement(domNode) {
    if (domNode instanceof HTMLDivElement) {
        const path = domNode.getAttribute('data-lexical-pdf-path');
        const identityId = domNode.getAttribute('data-lexical-pdf-identity-id');
        const filename = domNode.getAttribute('data-lexical-pdf-filename');
        if (path && identityId && filename) {
            const node = $createPdfViewerNode({
                path,
                identityId,
                filename
            });
            return {
                node
            };
        }
    }
    return null;
}
class PdfViewerNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __path;
    __identityId;
    __filename;
    static getType() {
        return 'pdf-viewer';
    }
    static clone(node) {
        return new PdfViewerNode(node.__path, node.__identityId, node.__filename, node.__key);
    }
    static importJSON(serializedNode) {
        const { path, identityId, filename } = serializedNode;
        const node = $createPdfViewerNode({
            path,
            identityId,
            filename
        });
        return node;
    }
    exportDOM() {
        const element = document.createElement('div');
        element.setAttribute('data-lexical-pdf-path', this.__path);
        element.setAttribute('data-lexical-pdf-identity-id', this.__identityId);
        element.setAttribute('data-lexical-pdf-filename', this.__filename);
        return {
            element
        };
    }
    static importDOM() {
        return {
            div: (node)=>{
                if (!node.hasAttribute('data-lexical-pdf-path')) {
                    return null;
                }
                return {
                    conversion: convertPdfElement,
                    priority: 1
                };
            }
        };
    }
    constructor(path, identityId, filename, key){
        super(key);
        this.__path = path;
        this.__identityId = identityId;
        this.__filename = filename;
    }
    exportJSON() {
        return {
            path: this.__path,
            identityId: this.__identityId,
            filename: this.__filename,
            type: 'pdf-viewer',
            version: 1
        };
    }
    createDOM(config) {
        const div = document.createElement('div');
        const theme = config.theme;
        const className = theme.pdfViewer;
        if (className !== undefined) {
            div.className = className;
        }
        return div;
    }
    updateDOM() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
    canBeEmpty() {
        return true;
    }
    isIsolated() {
        return true;
    }
    isTopLevel() {
        return true;
    }
    getPath() {
        return this.__path;
    }
    getIdentityId() {
        return this.__identityId;
    }
    getFilename() {
        return this.__filename;
    }
    decorate() {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "Loading PDF..."
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/PdfViewerNode.jsx",
                lineNumber: 165,
                columnNumber: 33
            }, this),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PdfViewerComponent, {
                path: this.__path,
                identityId: this.__identityId,
                filename: this.__filename,
                nodeKey: this.getKey()
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/PdfViewerNode.jsx",
                lineNumber: 166,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/PdfViewerNode.jsx",
            lineNumber: 165,
            columnNumber: 13
        }, this);
    }
}
function $createPdfViewerNode({ path, identityId, filename, key }) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new PdfViewerNode(path, identityId, filename, key));
}
function $isPdfViewerNode(node) {
    return node instanceof PdfViewerNode;
}
var _c;
__turbopack_context__.k.register(_c, "PdfViewerComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/AutocompleteNode.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createAutocompleteNode",
    ()=>$createAutocompleteNode,
    "AutocompleteNode",
    ()=>AutocompleteNode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$SharedAutocompleteContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/context/SharedAutocompleteContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AutocompletePlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/AutocompletePlugin.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
class AutocompleteNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __uuid;
    static clone(node) {
        return new AutocompleteNode(node.__uuid, node.__key);
    }
    static getType() {
        return 'autocomplete';
    }
    static importJSON(serializedNode) {
        const node = $createAutocompleteNode(serializedNode.uuid);
        return node;
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            type: 'autocomplete',
            uuid: this.__uuid,
            version: 1
        };
    }
    constructor(uuid, key){
        super(key);
        this.__uuid = uuid;
    }
    updateDOM(prevNode, dom, config) {
        return false;
    }
    createDOM(config) {
        return document.createElement('span');
    }
    decorate() {
        if (this.__uuid !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AutocompletePlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uuid"]) {
            return null;
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AutocompleteComponent, {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AutocompleteNode.jsx",
            lineNumber: 42,
            columnNumber: 12
        }, this);
    }
}
function $createAutocompleteNode(uuid) {
    return new AutocompleteNode(uuid);
}
function AutocompleteComponent() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "c3a3d64939dfb8440dd4c5282a244f8656f123d42ca0ee4feab40b5ab2474ac5") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c3a3d64939dfb8440dd4c5282a244f8656f123d42ca0ee4feab40b5ab2474ac5";
    }
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.shared");
    const { suggestion } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$SharedAutocompleteContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t0;
    if ($[1] !== suggestion) {
        t0 = suggestion || {};
        $[1] = suggestion;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const { autocompleteChunk } = t0;
    console.log("AutocompleteComponent() suggestion", suggestion);
    console.log("AutocompleteComponent() suggestion", suggestion);
    const userAgentData = window.navigator.userAgentData;
    const isMobile = userAgentData !== undefined ? userAgentData.mobile : window.innerWidth <= 800 && window.innerHeight <= 600;
    let t1;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            color: "var(--mui-palette-text-disabled, #ccc)"
        };
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    let t2;
    if ($[4] !== t) {
        t2 = isMobile ? t("autocompleteNode.mobileHint") : t("autocompleteNode.desktopHint");
        $[4] = t;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    let t3;
    if ($[6] !== autocompleteChunk || $[7] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            style: t1,
            spellCheck: "false",
            children: [
                autocompleteChunk,
                " ",
                t2
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/AutocompleteNode.jsx",
            lineNumber: 94,
            columnNumber: 10
        }, this);
        $[6] = autocompleteChunk;
        $[7] = t2;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    return t3;
}
_s(AutocompleteComponent, "fdIk8wOKK3306VA8GZ9rdasU6+s=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = AutocompleteComponent;
var _c;
__turbopack_context__.k.register(_c, "AutocompleteComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/AIContentSuggestionNode.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createAIContentSuggestionNode",
    ()=>$createAIContentSuggestionNode,
    "$createAILoadingNode",
    ()=>$createAILoadingNode,
    "AIContentSuggestionNode",
    ()=>AIContentSuggestionNode,
    "AILoadingNode",
    ()=>AILoadingNode,
    "AI_SUGGESTION_UUID",
    ()=>AI_SUGGESTION_UUID
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview AIContentSuggestionNode - Inline AI suggestion decorator node.
 *
 * Renders AI-generated text suggestions inline with the editor content as ghost text.
 * Does not get serialized to editor state - only displayed temporarily until accepted or dismissed.
 *
 * @module AIContentSuggestionNode
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
const AI_SUGGESTION_UUID = Math.random().toString(36).replace(/[^a-z]+/g, "").substr(0, 5);
class AIContentSuggestionNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __uuid;
    __suggestion;
    static clone(node) {
        return new AIContentSuggestionNode(node.__uuid, node.__suggestion, node.__key);
    }
    static getType() {
        return "ai-content-suggestion";
    }
    static importJSON(serializedNode) {
        // Transient node - create an empty instance that will be cleaned up
        return new AIContentSuggestionNode("", "");
    }
    exportJSON() {
        // Return valid JSON so serialization doesn't produce null/undefined types
        return {
            type: "ai-content-suggestion",
            version: 1
        };
    }
    constructor(uuid, suggestion, key){
        super(key);
        this.__uuid = uuid;
        this.__suggestion = suggestion || "";
    }
    updateDOM(prevNode, dom, config) {
        // Return true to force re-render when suggestion changes
        const needsUpdate = prevNode.__suggestion !== this.__suggestion;
        return needsUpdate;
    }
    createDOM(config) {
        return document.createElement("span");
    }
    decorate() {
        if (this.__uuid !== AI_SUGGESTION_UUID) {
            return null;
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AIContentSuggestionComponent, {
            suggestion: this.__suggestion
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AIContentSuggestionNode.jsx",
            lineNumber: 51,
            columnNumber: 12
        }, this);
    }
    isInline() {
        return true;
    }
    setSuggestion(suggestion) {
        const writable = this.getWritable();
        writable.__suggestion = suggestion;
    }
    getSuggestion() {
        return this.__suggestion;
    }
}
function $createAIContentSuggestionNode(uuid, suggestion) {
    return new AIContentSuggestionNode(uuid, suggestion);
}
class AILoadingNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __uuid;
    static clone(node) {
        return new AILoadingNode(node.__uuid, node.__key);
    }
    static getType() {
        return "ai-loading";
    }
    static importJSON(serializedNode) {
        return new AILoadingNode("");
    }
    exportJSON() {
        return {
            type: "ai-loading",
            version: 1
        };
    }
    constructor(uuid, key){
        super(key);
        this.__uuid = uuid;
    }
    isInline() {
        return true;
    }
    updateDOM(prevNode, dom, config) {
        return false;
    }
    createDOM(config) {
        return document.createElement("span");
    }
    decorate() {
        if (this.__uuid !== AI_SUGGESTION_UUID) {
            return null;
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AILoadingComponent, {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AIContentSuggestionNode.jsx",
            lineNumber: 101,
            columnNumber: 12
        }, this);
    }
}
function $createAILoadingNode(uuid) {
    return new AILoadingNode(uuid);
}
function AILoadingComponent() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "b90f93b1c6c9529101c3d8b953c44a0370544ab03e7e82c15c01c119af9d3d58") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b90f93b1c6c9529101c3d8b953c44a0370544ab03e7e82c15c01c119af9d3d58";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            color: "var(--mui-palette-text-secondary, #666)",
            opacity: 0.7,
            fontStyle: "italic",
            userSelect: "none",
            pointerEvents: "none",
            display: "inline-flex",
            alignItems: "center",
            gap: "4px"
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            style: {
                display: "inline-block",
                width: "8px",
                height: "8px",
                border: "2px solid var(--mui-palette-text-secondary, #666)",
                borderTopColor: "transparent",
                borderRadius: "50%",
                animation: "spin 0.8s linear infinite"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AIContentSuggestionNode.jsx",
            lineNumber: 133,
            columnNumber: 10
        }, this);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            style: t0,
            spellCheck: "false",
            contentEditable: false,
            children: [
                t1,
                "Generating...",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                    children: "\n        @keyframes spin {\n          to { transform: rotate(360deg); }\n        }\n      "
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/AIContentSuggestionNode.jsx",
                    lineNumber: 148,
                    columnNumber: 87
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/AIContentSuggestionNode.jsx",
            lineNumber: 148,
            columnNumber: 10
        }, this);
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_c = AILoadingComponent;
function AIContentSuggestionComponent(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "b90f93b1c6c9529101c3d8b953c44a0370544ab03e7e82c15c01c119af9d3d58") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b90f93b1c6c9529101c3d8b953c44a0370544ab03e7e82c15c01c119af9d3d58";
    }
    const { suggestion } = t0;
    console.log("AIContentSuggestionComponent rendering with suggestion:", suggestion);
    if (!suggestion) {
        return null;
    }
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            color: "var(--mui-palette-text-primary, #444)",
            opacity: 0.9,
            fontStyle: "italic",
            userSelect: "none",
            pointerEvents: "none"
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            style: {
                fontSize: "10px",
                marginLeft: "8px",
                opacity: 0.95
            },
            children: "(Tab to accept)"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/AIContentSuggestionNode.jsx",
            lineNumber: 185,
            columnNumber: 10
        }, this);
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== suggestion) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            style: t1,
            spellCheck: "false",
            contentEditable: false,
            children: [
                suggestion,
                t2
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/AIContentSuggestionNode.jsx",
            lineNumber: 196,
            columnNumber: 10
        }, this);
        $[3] = suggestion;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    return t3;
}
_c1 = AIContentSuggestionComponent;
var _c, _c1;
__turbopack_context__.k.register(_c, "AILoadingComponent");
__turbopack_context__.k.register(_c1, "AIContentSuggestionComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/LayoutContainerNode.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createLayoutContainerNode",
    ()=>$createLayoutContainerNode,
    "$isLayoutContainerNode",
    ()=>$isLayoutContainerNode,
    "LayoutContainerNode",
    ()=>LayoutContainerNode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
;
;
class LayoutContainerNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementNode"] {
    __templateColumns;
    constructor(templateColumns, key){
        super(key);
        this.__templateColumns = templateColumns;
    }
    static getType() {
        return 'layout-container';
    }
    static clone(node) {
        return new LayoutContainerNode(node.__templateColumns, node.__key);
    }
    createDOM(config) {
        const dom = document.createElement('div');
        dom.style.display = 'grid';
        dom.className = 'layout-container';
        dom.style.gridTemplateColumns = this.__templateColumns;
        if (typeof config.theme.layoutContainer === 'string') {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addClassNamesToElement"])(dom, config.theme.layoutContainer);
        }
        return dom;
    }
    updateDOM(prevNode, dom) {
        if (prevNode.__templateColumns !== this.__templateColumns) {
            dom.style.gridTemplateColumns = this.__templateColumns;
        }
        return false;
    }
    static importDOM() {
        return {};
    }
    static importJSON(json) {
        return $createLayoutContainerNode(json.templateColumns);
    }
    canBeEmpty() {
        return false;
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            templateColumns: this.__templateColumns,
            type: 'layout-container',
            version: 1
        };
    }
    getTemplateColumns() {
        return this.getLatest().__templateColumns;
    }
    setTemplateColumns(templateColumns) {
        this.getWritable().__templateColumns = templateColumns;
    }
}
function $createLayoutContainerNode(templateColumns) {
    return new LayoutContainerNode(templateColumns);
}
function $isLayoutContainerNode(node) {
    return node instanceof LayoutContainerNode;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/components/LayoutItemNode.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createLayoutItemNode",
    ()=>$createLayoutItemNode,
    "$isLayoutItemNode",
    ()=>$isLayoutItemNode,
    "LayoutItemNode",
    ()=>LayoutItemNode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
;
;
class LayoutItemNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementNode"] {
    static getType() {
        return 'layout-item';
    }
    static clone(node) {
        return new LayoutItemNode(node.__key);
    }
    createDOM(config) {
        const dom = document.createElement('div');
        if (typeof config.theme.layoutItem === 'string') {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addClassNamesToElement"])(dom, config.theme.layoutItem);
        }
        return dom;
    }
    updateDOM() {
        return false;
    }
    static importDOM() {
        return {};
    }
    static importJSON() {
        return $createLayoutItemNode();
    }
    isShadowRoot() {
        return true;
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            type: 'layout-item',
            version: 1
        };
    }
}
function $createLayoutItemNode() {
    return new LayoutItemNode();
}
function $isLayoutItemNode(node) {
    return node instanceof LayoutItemNode;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_Editor3_components_1gj-_-3._.js.map