(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Editor3/plugins/ImagesPlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "INSERT_IMAGE_COMMAND",
    ()=>INSERT_IMAGE_COMMAND,
    "InsertImageDialog",
    ()=>InsertImageDialog,
    "InsertImageUploadedDialogBody",
    ()=>InsertImageUploadedDialogBody,
    "InsertImageUriDialogBody",
    ()=>InsertImageUriDialogBody,
    "default",
    ()=>ImagesPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview ImagesPlugin - Image upload and embedding functionality.
 * @module ImagesPlugin
 * 
 * Handles image insertion via URL or file upload, drag-and-drop support,
 * and image node management in the editor.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
// import landscapeImage from '../../images/landscape.jpg';
// import yellowFlowerImage from '../../images/yellow-flower.jpg';
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$ImageNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/ImageNode.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
const INSERT_IMAGE_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('INSERT_IMAGE_COMMAND');
function InsertImageUriDialogBody(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(31);
    if ($[0] !== "9a047d17bd09709d43d8c9eb88fe7d5de5fcc734c8baa243aee454f4b8cd057c") {
        for(let $i = 0; $i < 31; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9a047d17bd09709d43d8c9eb88fe7d5de5fcc734c8baa243aee454f4b8cd057c";
    }
    const { onClick } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.shared");
    const [src, setSrc] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [altText, setAltText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const isDisabled = src === "";
    let t1;
    if ($[1] !== t) {
        t1 = t("imagesPlugin.imageUrl");
        $[1] = t;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== t) {
        t2 = t("imagesPlugin.imageUrlPlaceholder");
        $[3] = t;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] !== src || $[6] !== t1 || $[7] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TextInput, {
            label: t1,
            placeholder: t2,
            onChange: setSrc,
            value: src,
            "data-test-id": "image-modal-url-input"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
            lineNumber: 64,
            columnNumber: 10
        }, this);
        $[5] = src;
        $[6] = t1;
        $[7] = t2;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== t) {
        t4 = t("imagesPlugin.altText");
        $[9] = t;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== t) {
        t5 = t("imagesPlugin.altTextPlaceholder");
        $[11] = t;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    let t6;
    if ($[13] !== altText || $[14] !== t4 || $[15] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TextInput, {
            label: t4,
            placeholder: t5,
            onChange: setAltText,
            value: altText,
            "data-test-id": "image-modal-alt-text-input"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[13] = altText;
        $[14] = t4;
        $[15] = t5;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    let t7;
    if ($[17] !== altText || $[18] !== onClick || $[19] !== src) {
        t7 = ({
            "InsertImageUriDialogBody[<Button>.onClick]": ()=>onClick({
                    altText,
                    src
                })
        })["InsertImageUriDialogBody[<Button>.onClick]"];
        $[17] = altText;
        $[18] = onClick;
        $[19] = src;
        $[20] = t7;
    } else {
        t7 = $[20];
    }
    let t8;
    if ($[21] !== t) {
        t8 = t("imagesPlugin.confirm");
        $[21] = t;
        $[22] = t8;
    } else {
        t8 = $[22];
    }
    let t9;
    if ($[23] !== isDisabled || $[24] !== t7 || $[25] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogActions, {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Button, {
                "data-test-id": "image-modal-confirm-btn",
                disabled: isDisabled,
                onClick: t7,
                children: t8
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
                lineNumber: 123,
                columnNumber: 25
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
            lineNumber: 123,
            columnNumber: 10
        }, this);
        $[23] = isDisabled;
        $[24] = t7;
        $[25] = t8;
        $[26] = t9;
    } else {
        t9 = $[26];
    }
    let t10;
    if ($[27] !== t3 || $[28] !== t6 || $[29] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t3,
                t6,
                t9
            ]
        }, void 0, true);
        $[27] = t3;
        $[28] = t6;
        $[29] = t9;
        $[30] = t10;
    } else {
        t10 = $[30];
    }
    return t10;
}
_s(InsertImageUriDialogBody, "kJL/5Wef7t+et6xbDwB5n0DStGI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = InsertImageUriDialogBody;
function InsertImageUploadedDialogBody(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(28);
    if ($[0] !== "9a047d17bd09709d43d8c9eb88fe7d5de5fcc734c8baa243aee454f4b8cd057c") {
        for(let $i = 0; $i < 28; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9a047d17bd09709d43d8c9eb88fe7d5de5fcc734c8baa243aee454f4b8cd057c";
    }
    const { onClick } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.shared");
    const [src, setSrc] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [altText, setAltText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const isDisabled = src === "";
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "InsertImageUploadedDialogBody[loadImage]": (files)=>{
                const reader = new FileReader();
                reader.onload = function() {
                    if (typeof reader.result === "string") {
                        setSrc(reader.result);
                    }
                    return "";
                };
                if (files !== null) {
                    reader.readAsDataURL(files[0]);
                }
            }
        })["InsertImageUploadedDialogBody[loadImage]"];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const loadImage = t1;
    let t2;
    if ($[2] !== t) {
        t2 = t("imagesPlugin.imageUpload");
        $[2] = t;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FileInput, {
            label: t2,
            onChange: loadImage,
            accept: "image/*",
            "data-test-id": "image-modal-file-upload"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
            lineNumber: 189,
            columnNumber: 10
        }, this);
        $[4] = t2;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== t) {
        t4 = t("imagesPlugin.altText");
        $[6] = t;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] !== t) {
        t5 = t("imagesPlugin.altTextDescriptive");
        $[8] = t;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] !== altText || $[11] !== t4 || $[12] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TextInput, {
            label: t4,
            placeholder: t5,
            onChange: setAltText,
            value: altText,
            "data-test-id": "image-modal-alt-text-input"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
            lineNumber: 213,
            columnNumber: 10
        }, this);
        $[10] = altText;
        $[11] = t4;
        $[12] = t5;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    let t7;
    if ($[14] !== altText || $[15] !== onClick || $[16] !== src) {
        t7 = ({
            "InsertImageUploadedDialogBody[<Button>.onClick]": ()=>onClick({
                    altText,
                    src
                })
        })["InsertImageUploadedDialogBody[<Button>.onClick]"];
        $[14] = altText;
        $[15] = onClick;
        $[16] = src;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    let t8;
    if ($[18] !== t) {
        t8 = t("imagesPlugin.confirm");
        $[18] = t;
        $[19] = t8;
    } else {
        t8 = $[19];
    }
    let t9;
    if ($[20] !== isDisabled || $[21] !== t7 || $[22] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogActions, {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Button, {
                "data-test-id": "image-modal-file-upload-btn",
                disabled: isDisabled,
                onClick: t7,
                children: t8
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
                lineNumber: 246,
                columnNumber: 25
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
            lineNumber: 246,
            columnNumber: 10
        }, this);
        $[20] = isDisabled;
        $[21] = t7;
        $[22] = t8;
        $[23] = t9;
    } else {
        t9 = $[23];
    }
    let t10;
    if ($[24] !== t3 || $[25] !== t6 || $[26] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t3,
                t6,
                t9
            ]
        }, void 0, true);
        $[24] = t3;
        $[25] = t6;
        $[26] = t9;
        $[27] = t10;
    } else {
        t10 = $[27];
    }
    return t10;
}
_s1(InsertImageUploadedDialogBody, "kJL/5Wef7t+et6xbDwB5n0DStGI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c1 = InsertImageUploadedDialogBody;
function InsertImageDialog(t0) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(21);
    if ($[0] !== "9a047d17bd09709d43d8c9eb88fe7d5de5fcc734c8baa243aee454f4b8cd057c") {
        for(let $i = 0; $i < 21; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9a047d17bd09709d43d8c9eb88fe7d5de5fcc734c8baa243aee454f4b8cd057c";
    }
    const { activeEditor, onClose } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.shared");
    const [mode, setMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const hasModifier = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "InsertImageDialog[useEffect()]": ()=>{
                hasModifier.current = false;
                const handler = {
                    "InsertImageDialog[useEffect() > handler]": (e)=>{
                        hasModifier.current = e.altKey;
                    }
                }["InsertImageDialog[useEffect() > handler]"];
                document.addEventListener("keydown", handler);
                return ()=>{
                    document.removeEventListener("keydown", handler);
                };
            }
        })["InsertImageDialog[useEffect()]"];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== activeEditor) {
        t2 = [
            activeEditor
        ];
        $[2] = activeEditor;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[4] !== activeEditor || $[5] !== onClose) {
        t3 = ({
            "InsertImageDialog[onClick]": (payload)=>{
                activeEditor.dispatchCommand(INSERT_IMAGE_COMMAND, payload);
                onClose();
            }
        })["InsertImageDialog[onClick]"];
        $[4] = activeEditor;
        $[5] = onClose;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const onClick = t3;
    let t4;
    if ($[7] !== mode || $[8] !== onClick || $[9] !== t) {
        t4 = !mode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogButtonsList, {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Button, {
                    "data-test-id": "image-modal-option-sample",
                    onClick: {
                        "InsertImageDialog[<Button>.onClick]": ()=>onClick(hasModifier.current ? {
                                altText: "Daylight fir trees forest glacier green high ice landscape",
                                src: landscapeImage
                            } : {
                                altText: "Yellow flower in tilt shift lens",
                                src: yellowFlowerImage
                            })
                    }["InsertImageDialog[<Button>.onClick]"],
                    children: t("imagesPlugin.sample")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
                    lineNumber: 327,
                    columnNumber: 38
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Button, {
                    "data-test-id": "image-modal-option-url",
                    onClick: {
                        "InsertImageDialog[<Button>.onClick]": ()=>setMode("url")
                    }["InsertImageDialog[<Button>.onClick]"],
                    children: t("imagesPlugin.url")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
                    lineNumber: 335,
                    columnNumber: 84
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Button, {
                    "data-test-id": "image-modal-option-file",
                    onClick: {
                        "InsertImageDialog[<Button>.onClick]": ()=>setMode("file")
                    }["InsertImageDialog[<Button>.onClick]"],
                    children: t("imagesPlugin.file")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
                    lineNumber: 337,
                    columnNumber: 81
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
            lineNumber: 327,
            columnNumber: 19
        }, this);
        $[7] = mode;
        $[8] = onClick;
        $[9] = t;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== mode || $[12] !== onClick) {
        t5 = mode === "url" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(InsertImageUriDialogBody, {
            onClick: onClick
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
            lineNumber: 349,
            columnNumber: 28
        }, this);
        $[11] = mode;
        $[12] = onClick;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    let t6;
    if ($[14] !== mode || $[15] !== onClick) {
        t6 = mode === "file" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(InsertImageUploadedDialogBody, {
            onClick: onClick
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ImagesPlugin.jsx",
            lineNumber: 358,
            columnNumber: 29
        }, this);
        $[14] = mode;
        $[15] = onClick;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    let t7;
    if ($[17] !== t4 || $[18] !== t5 || $[19] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t4,
                t5,
                t6
            ]
        }, void 0, true);
        $[17] = t4;
        $[18] = t5;
        $[19] = t6;
        $[20] = t7;
    } else {
        t7 = $[20];
    }
    return t7;
}
_s2(InsertImageDialog, "6zFWOcK6x3WraQ0NXKPllG6MnTQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c2 = InsertImageDialog;
function ImagesPlugin(t0) {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "9a047d17bd09709d43d8c9eb88fe7d5de5fcc734c8baa243aee454f4b8cd057c") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9a047d17bd09709d43d8c9eb88fe7d5de5fcc734c8baa243aee454f4b8cd057c";
    }
    const { captionsEnabled } = t0;
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t1;
    if ($[1] !== editor) {
        t1 = ({
            "ImagesPlugin[useEffect()]": ()=>{
                if (!editor.hasNodes([
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$ImageNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageNode"]
                ])) {
                    throw new Error("ImagesPlugin: ImageNode not registered on editor");
                }
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(editor.registerCommand(INSERT_IMAGE_COMMAND, _ImagesPluginUseEffectEditorRegisterCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAGSTART_COMMAND"], _ImagesPluginUseEffectEditorRegisterCommand2, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_HIGH"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAGOVER_COMMAND"], _ImagesPluginUseEffectEditorRegisterCommand3, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DROP_COMMAND"], {
                    "ImagesPlugin[useEffect() > editor.registerCommand()]": (event_1)=>onDrop(event_1, editor)
                }["ImagesPlugin[useEffect() > editor.registerCommand()]"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_HIGH"]));
            }
        })["ImagesPlugin[useEffect()]"];
        $[1] = editor;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== captionsEnabled || $[4] !== editor) {
        t2 = [
            captionsEnabled,
            editor
        ];
        $[3] = captionsEnabled;
        $[4] = editor;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return null;
}
_s3(ImagesPlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c3 = ImagesPlugin;
function _ImagesPluginUseEffectEditorRegisterCommand3(event_0) {
    return onDragover(event_0);
}
function _ImagesPluginUseEffectEditorRegisterCommand2(event) {
    return onDragStart(event);
}
function _ImagesPluginUseEffectEditorRegisterCommand(payload) {
    console.log("INSERT_IMAGE_COMMAND", payload);
    const imageNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$ImageNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createImageNode"])(payload);
    console.log("INSERT_IMAGE_COMMAND imageNode", imageNode);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$insertNodes"])([
        imageNode
    ]);
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRootOrShadowRoot"])(imageNode.getParentOrThrow())) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$wrapNodeInElement"])(imageNode, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"]).selectEnd();
    }
    return true;
}
function onDragStart(event) {
    console.log('onDragStart', event);
    const TRANSPARENT_IMAGE = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
    let img;
    img = document.createElement('img');
    img.src = TRANSPARENT_IMAGE;
    const node = getImageNodeInSelection();
    if (!node) {
        return false;
    }
    const dataTransfer = event.dataTransfer;
    if (!dataTransfer) {
        return false;
    }
    dataTransfer.setData('text/plain', '_');
    dataTransfer.setDragImage(img, 0, 0);
    dataTransfer.setData('application/x-lexical-drag', JSON.stringify({
        data: {
            altText: node.__altText,
            caption: node.__caption,
            height: node.__height,
            key: node.getKey(),
            maxWidth: node.__maxWidth,
            showCaption: node.__showCaption,
            src: node.__src,
            path: node.__path,
            width: node.__width
        },
        type: 'image'
    }));
    return true;
}
function onDragover(event) {
    // Check if this is a block drag from DraggableBlockPlugin
    const blockDragData = event.dataTransfer?.getData('application/x-lexical-drag-block');
    if (blockDragData) {
        // Let DraggableBlockPlugin handle block-level dragging
        return false;
    }
    const node = getImageNodeInSelection();
    if (!node) {
        return false;
    }
    if (!canDropImage(event)) {
        event.preventDefault();
    }
    return true;
}
function onDrop(event, editor) {
    // Check if this is a block drag from DraggableBlockPlugin
    const blockDragData = event.dataTransfer?.getData('application/x-lexical-drag-block');
    if (blockDragData) {
        // Let DraggableBlockPlugin handle block-level dragging
        return false;
    }
    const node = getImageNodeInSelection();
    if (!node) {
        return false;
    }
    const data = getDragImageData(event);
    if (!data) {
        return false;
    }
    event.preventDefault();
    if (canDropImage(event)) {
        const range = getDragSelection(event);
        node.remove();
        const rangeSelection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createRangeSelection"])();
        if (range !== null && range !== undefined) {
            rangeSelection.applyDOMRange(range);
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$setSelection"])(rangeSelection);
        editor.dispatchCommand(INSERT_IMAGE_COMMAND, data);
    }
    return true;
}
function getImageNodeInSelection() {
    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])(selection)) {
        return null;
    }
    const nodes = selection.getNodes();
    const node = nodes[0];
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$ImageNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isImageNode"])(node) ? node : null;
}
function getDragImageData(event) {
    const dragData = event.dataTransfer?.getData('application/x-lexical-drag');
    if (!dragData) {
        return null;
    }
    const { type, data } = JSON.parse(dragData);
    if (type !== 'image') {
        return null;
    }
    return data;
}
function canDropImage(event) {
    const target = event.target;
    return !!(target && target instanceof HTMLElement && !target.closest('code, span.editor-image') && target.parentElement && target.parentElement.closest('div.ContentEditable__root'));
}
function getDragSelection(event) {
    let range;
    const target = event.target;
    const targetWindow = target == null ? null : target.nodeType === 9 ? target.defaultView : target.ownerDocument.defaultView;
    const domSelection = getDOMSelection(targetWindow);
    if (document.caretRangeFromPoint) {
        range = document.caretRangeFromPoint(event.clientX, event.clientY);
    } else if (event.rangeParent && domSelection !== null) {
        domSelection.collapse(event.rangeParent, event.rangeOffset || 0);
        range = domSelection.getRangeAt(0);
    } else {
        throw Error(`Cannot get the selection when dragging`);
    }
    return range;
}
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "InsertImageUriDialogBody");
__turbopack_context__.k.register(_c1, "InsertImageUploadedDialogBody");
__turbopack_context__.k.register(_c2, "InsertImageDialog");
__turbopack_context__.k.register(_c3, "ImagesPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/ConversationPlaylistPlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createConversationPlaylistNode",
    ()=>$createConversationPlaylistNode,
    "$isConversationPlaylistNode",
    ()=>$isConversationPlaylistNode,
    "ConversationPlaylistNode",
    ()=>ConversationPlaylistNode,
    "INSERT_CONVERSATION_PLAYLIST_COMMAND",
    ()=>INSERT_CONVERSATION_PLAYLIST_COMMAND,
    "default",
    ()=>ConversationPlaylistPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview ConversationPlaylistPlugin - Embeds subtitle-synced conversation playlists in the editor.
 *
 * Stores audio File IDs, dialogue subtitle lines (with per-line timing and optional still image),
 * and an optional generated movie File ID. In read mode renders ConversationPlayerComponent;
 * in edit mode renders ConversationPlaylistEditor.
 *
 * @module ConversationPlaylistPlugin
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalBlockWithAlignableContents$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalBlockWithAlignableContents.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
const ConversationPlayerComponent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/src/components/Editor3/components/ConversationPlayerComponent.jsx [app-client] (ecmascript, async loader)"));
_c = ConversationPlayerComponent;
const ConversationPlaylistEditor = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/src/components/Editor3/components/ConversationPlaylistEditor.jsx [app-client] (ecmascript, async loader)"));
_c1 = ConversationPlaylistEditor;
const INSERT_CONVERSATION_PLAYLIST_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('INSERT_CONVERSATION_PLAYLIST_COMMAND');
class ConversationPlaylistNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __fileIDs;
    __dialogue;
    __scriptTitle;
    __movieFileID;
    static getType() {
        return 'conversation-playlist';
    }
    static clone(node) {
        return new ConversationPlaylistNode(node.__fileIDs, node.__dialogue, node.__scriptTitle, node.__movieFileID, node.__key);
    }
    static importJSON(serializedNode) {
        return new ConversationPlaylistNode(serializedNode.fileIDs || [], serializedNode.dialogue || [], serializedNode.scriptTitle || '', serializedNode.movieFileID || null);
    }
    exportJSON() {
        return {
            type: 'conversation-playlist',
            version: 1,
            fileIDs: [
                ...this.__fileIDs
            ],
            dialogue: this.__dialogue ? JSON.parse(JSON.stringify(this.__dialogue)) : [],
            scriptTitle: this.__scriptTitle || '',
            movieFileID: this.__movieFileID || null
        };
    }
    constructor(fileIDs = [], dialogue = [], scriptTitle = '', movieFileID = null, key){
        super(key);
        this.__fileIDs = fileIDs;
        this.__dialogue = dialogue;
        this.__scriptTitle = scriptTitle;
        this.__movieFileID = movieFileID;
    }
    exportDOM() {
        const element = document.createElement('div');
        element.setAttribute('data-lexical-conversation-playlist', JSON.stringify({
            fileIDs: this.__fileIDs,
            dialogue: this.__dialogue,
            scriptTitle: this.__scriptTitle,
            movieFileID: this.__movieFileID
        }));
        return {
            element
        };
    }
    createDOM() {
        const div = document.createElement('div');
        div.setAttribute('data-lexical-conversation-playlist', 'true');
        return div;
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute('data-lexical-conversation-playlist')) {
                    return null;
                }
                return {
                    conversion: (domNode)=>{
                        try {
                            const raw = domNode.getAttribute('data-lexical-conversation-playlist');
                            const parsed = JSON.parse(raw);
                            return {
                                node: new ConversationPlaylistNode(parsed.fileIDs || [], parsed.dialogue || [], parsed.scriptTitle || '', parsed.movieFileID || null)
                            };
                        } catch  {
                            return null;
                        }
                    },
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
    canBeEmpty() {
        return true;
    }
    getFileIDs() {
        return this.__fileIDs;
    }
    getDialogue() {
        return this.__dialogue;
    }
    getScriptTitle() {
        return this.__scriptTitle;
    }
    getMovieFileID() {
        return this.__movieFileID;
    }
    setMovieFileID(id) {
        const writable = this.getWritable();
        writable.__movieFileID = id;
    }
    setFileIDs(ids) {
        const writable = this.getWritable();
        writable.__fileIDs = [
            ...ids
        ];
    }
    getTextContent() {
        return this.__scriptTitle || '';
    }
    decorate(_editor, config) {
        const isEditable = _editor.isEditable();
        const embedBlockTheme = config.theme.embedBlock || {};
        const className = {
            base: embedBlockTheme.base || '',
            focus: embedBlockTheme.focus || ''
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: isEditable ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalBlockWithAlignableContents$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BlockWithAlignableContents"], {
                className: className,
                nodeKey: this.getKey(),
                format: this.__format,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
                    fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "rectangular",
                        width: "100%",
                        height: 120,
                        sx: {
                            borderRadius: 1
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/plugins/ConversationPlaylistPlugin.jsx",
                        lineNumber: 156,
                        columnNumber: 33
                    }, this),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConversationPlaylistEditor, {
                        nodeKey: this.getKey(),
                        fileIDs: this.__fileIDs,
                        dialogue: this.__dialogue,
                        scriptTitle: this.__scriptTitle,
                        movieFileID: this.__movieFileID
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/plugins/ConversationPlaylistPlugin.jsx",
                        lineNumber: 159,
                        columnNumber: 15
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/ConversationPlaylistPlugin.jsx",
                    lineNumber: 156,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/plugins/ConversationPlaylistPlugin.jsx",
                lineNumber: 155,
                columnNumber: 23
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalBlockWithAlignableContents$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BlockWithAlignableContents"], {
                className: className,
                nodeKey: this.getKey(),
                format: this.__format,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
                    fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "rectangular",
                        width: "100%",
                        height: 240,
                        sx: {
                            borderRadius: 1
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/plugins/ConversationPlaylistPlugin.jsx",
                        lineNumber: 162,
                        columnNumber: 33
                    }, this),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConversationPlayerComponent, {
                        nodeKey: this.getKey(),
                        fileIDs: this.__fileIDs,
                        dialogue: this.__dialogue,
                        scriptTitle: this.__scriptTitle,
                        movieFileID: this.__movieFileID
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/plugins/ConversationPlaylistPlugin.jsx",
                        lineNumber: 165,
                        columnNumber: 15
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/ConversationPlaylistPlugin.jsx",
                    lineNumber: 162,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/plugins/ConversationPlaylistPlugin.jsx",
                lineNumber: 161,
                columnNumber: 43
            }, this)
        }, void 0, false);
    }
}
function $createConversationPlaylistNode(fileIDs, dialogue, scriptTitle, movieFileID) {
    return new ConversationPlaylistNode(fileIDs, dialogue, scriptTitle, movieFileID);
}
function $isConversationPlaylistNode(node) {
    return node instanceof ConversationPlaylistNode;
}
function ConversationPlaylistPlugin() {
    _s();
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const { unit } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const createUnitFileRelationship = async (fileId)=>{
        try {
            if (!unit) return;
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const { data: existing } = await client.models.UnitFile.list({
                filter: {
                    and: [
                        {
                            unitID: {
                                eq: unit.id
                            }
                        },
                        {
                            fileID: {
                                eq: fileId
                            }
                        }
                    ]
                }
            });
            if (!existing || existing.length === 0) {
                await client.models.UnitFile.create({
                    unitID: unit.id,
                    fileID: fileId
                });
            }
        } catch (error) {
            console.error('[ConversationPlaylistPlugin] UnitFile create error:', error);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConversationPlaylistPlugin.useEffect": ()=>{
            if (!editor.hasNodes([
                ConversationPlaylistNode
            ])) {
                throw new Error('ConversationPlaylistPlugin: ConversationPlaylistNode not registered on editor');
            }
            return editor.registerCommand(INSERT_CONVERSATION_PLAYLIST_COMMAND, {
                "ConversationPlaylistPlugin.useEffect": (payload)=>{
                    const { fileIDs = [], dialogue = [], scriptTitle = '', movieFileID = null } = payload || {};
                    const node = $createConversationPlaylistNode(fileIDs, dialogue, scriptTitle, movieFileID);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(node);
                    // Create UnitFile relationships for all audio files
                    fileIDs.forEach({
                        "ConversationPlaylistPlugin.useEffect": (id)=>{
                            if (id) createUnitFileRelationship(id);
                        }
                    }["ConversationPlaylistPlugin.useEffect"]);
                    // Also link stills
                    dialogue.forEach({
                        "ConversationPlaylistPlugin.useEffect": (line)=>{
                            if (line.stillFileID) createUnitFileRelationship(line.stillFileID);
                        }
                    }["ConversationPlaylistPlugin.useEffect"]);
                    return true;
                }
            }["ConversationPlaylistPlugin.useEffect"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
        }
    }["ConversationPlaylistPlugin.useEffect"], [
        editor,
        unit
    ]);
    return null;
}
_s(ConversationPlaylistPlugin, "34Ldibuw+x8+PVAb3JOAvDxeam0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c2 = ConversationPlaylistPlugin;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ConversationPlayerComponent");
__turbopack_context__.k.register(_c1, "ConversationPlaylistEditor");
__turbopack_context__.k.register(_c2, "ConversationPlaylistPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/SearchHighlightPlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SearchHighlightPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$mark$2f$LexicalMark$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/mark/LexicalMark.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function SearchHighlightPlugin(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "64e16058ffac71ca608634515b0fc0a474b3aa0a65afe0628482a8891a40c10d") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "64e16058ffac71ca608634515b0fc0a474b3aa0a65afe0628482a8891a40c10d";
    }
    const { searchTerm: t1 } = t0;
    const searchTerm = t1 === undefined ? "" : t1;
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t2;
    let t3;
    if ($[1] !== editor || $[2] !== searchTerm) {
        t2 = ({
            "SearchHighlightPlugin[useEffect()]": ()=>{
                editor.update({
                    "SearchHighlightPlugin[useEffect() > editor.update()]": ()=>{
                        const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
                        const allTextNodes = root.getAllTextNodes();
                        allTextNodes.forEach(_SearchHighlightPluginUseEffectEditorUpdateAllTextNodesForEach);
                        if (!searchTerm || searchTerm.length < 2) {
                            return;
                        }
                        const regex = new RegExp(searchTerm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
                        const textNodes = root.getAllTextNodes();
                        const nodesToProcess = [];
                        textNodes.forEach({
                            "SearchHighlightPlugin[useEffect() > editor.update() > textNodes.forEach()]": (textNode_0)=>{
                                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$mark$2f$LexicalMark$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isMarkNode"])(textNode_0.getParent()) && textNode_0.getParent().getIDs().includes("search-highlight")) {
                                    return;
                                }
                                const text = textNode_0.getTextContent();
                                const matches = [
                                    ...text.matchAll(regex)
                                ];
                                if (matches.length > 0) {
                                    nodesToProcess.push({
                                        textNode: textNode_0,
                                        matches
                                    });
                                }
                            }
                        }["SearchHighlightPlugin[useEffect() > editor.update() > textNodes.forEach()]"]);
                        nodesToProcess.forEach(_SearchHighlightPluginUseEffectEditorUpdateNodesToProcessForEach);
                    }
                }["SearchHighlightPlugin[useEffect() > editor.update()]"]);
            }
        })["SearchHighlightPlugin[useEffect()]"];
        t3 = [
            editor,
            searchTerm
        ];
        $[1] = editor;
        $[2] = searchTerm;
        $[3] = t2;
        $[4] = t3;
    } else {
        t2 = $[3];
        t3 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    return null;
}
_s(SearchHighlightPlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = SearchHighlightPlugin;
/**
 * CSS to add to your theme or global styles:
 * 
 * mark[data-lexical-mark-id*="search-highlight"] {
 *   background-color: #ffeb3b;
 *   padding: 0 2px;
 *   border-radius: 2px;
 * }
 */ function _SearchHighlightPluginUseEffectEditorUpdateNodesToProcessForEach(t0) {
    const { textNode: textNode_1, matches: matches_0 } = t0;
    if (!textNode_1.isAttached()) {
        return;
    }
    matches_0.sort(_SearchHighlightPluginUseEffectEditorUpdateNodesToProcessForEachMatches_0Sort);
    let currentNode = textNode_1;
    for (const match of matches_0){
        if (!currentNode.isAttached()) {
            break;
        }
        const matchStart = match.index;
        const matchEnd = matchStart + match[0].length;
        const nodeText = currentNode.getTextContent();
        if (matchStart >= nodeText.length) {
            continue;
        }
        if (matchEnd < nodeText.length) {
            const splits = currentNode.splitText(matchEnd);
            currentNode = splits[0];
        }
        if (matchStart > 0) {
            const splits_0 = currentNode.splitText(matchStart);
            currentNode = splits_0[1];
        }
        if (currentNode && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(currentNode) && currentNode.isAttached()) {
            const markNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$mark$2f$LexicalMark$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createMarkNode"])([
                "search-highlight"
            ]);
            currentNode.replace(markNode);
            markNode.append(currentNode);
        }
        currentNode = textNode_1;
    }
}
function _SearchHighlightPluginUseEffectEditorUpdateNodesToProcessForEachMatches_0Sort(a, b) {
    return b.index - a.index;
}
function _SearchHighlightPluginUseEffectEditorUpdateAllTextNodesForEach(textNode) {
    const parent = textNode.getParent();
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$mark$2f$LexicalMark$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isMarkNode"])(parent) && parent.getIDs().includes("search-highlight")) {
        const textContent = textNode.getTextContent();
        const newTextNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(textContent);
        newTextNode.setFormat(textNode.getFormat());
        newTextNode.setStyle(textNode.getStyle());
        parent.replace(newTextNode);
    }
}
var _c;
__turbopack_context__.k.register(_c, "SearchHighlightPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createPlaylistNode",
    ()=>$createPlaylistNode,
    "$isPlaylistNode",
    ()=>$isPlaylistNode,
    "INSERT_PLAYLIST_COMMAND",
    ()=>INSERT_PLAYLIST_COMMAND,
    "PlaylistNode",
    ()=>PlaylistNode,
    "default",
    ()=>PlaylistPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview PlaylistPlugin - Embeds audio/video playlists in the editor.
 * 
 * This plugin provides playlist functionality with multi-track playback,
 * navigation controls, and progress tracking for audio/video content.
 * 
 * @module PlaylistPlugin
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalBlockWithAlignableContents$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalBlockWithAlignableContents.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
// Type import removed - not needed in runtime JS
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PlaylistEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/PlaylistEditor.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
const MediaPlayerComponent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/src/components/Editor3/components/MediaPlayerComponent.jsx [app-client] (ecmascript, async loader)"));
_c = MediaPlayerComponent;
/**
 * Converts a DOM element into a PlaylistNode.
 * 
 * @param {HTMLElement} domNode - DOM element with playlist file IDs
 * @returns {{node: PlaylistNode} | null} Created node or null
 */ function convertPlaylistElement(domNode) {
    // comma separated list of word ids
    const fileIDs = domNode.getAttribute('data-lexical-playlist').split(',') || [];
    if ("TURBOPACK compile-time truthy", 1) {
        const node = $createPlaylistNode(fileIDs);
        return {
            node
        };
    }
    //TURBOPACK unreachable
    ;
}
class PlaylistNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __ids;
    static getType() {
        return 'playlist';
    }
    static clone(node) {
        return new PlaylistNode(node.__ids, node.__format, node.__key);
    }
    static importJSON(serializedNode) {
        const node = $createPlaylistNode(serializedNode.fileIDs);
        // node.setFormat(serializedNode.format);
        return node;
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            type: 'playlist',
            version: 1,
            fileIDs: [
                ...this.__ids
            ]
        };
    }
    constructor(ids = [], format, key){
        super(key);
        this.__ids = ids;
    }
    exportDOM() {
        const element = document.createElement('div');
        element.setAttribute('data-lexical-playlist', this.__ids.join(','));
        return {
            element
        };
    }
    createDOM(config) {
        const div = document.createElement('div');
        div.setAttribute('data-lexical-playlist', this.__ids.join(','));
        const theme = config.theme;
        const className = theme.image;
        if (className !== undefined) {
            div.className = className;
        }
        return div;
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute('data-lexical-playlist')) {
                    return null;
                }
                return {
                    conversion: convertPlaylistElement,
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
    canBeEmpty() {
        return true;
    }
    getIds() {
        return this.__ids;
    }
    removeIntersection(ids) {
        const writable = this.getWritable();
        let intersection = this.__ids.filter((x)=>!ids.includes(x));
        writable.__ids = [
            ...new Set([
                ...intersection
            ])
        ];
    }
    setIds(ids) {
        const writable = this.getWritable();
        writable.__ids = [
            ...new Set([
                ...ids
            ])
        ];
    }
    mergeIds(ids) {
        const writable = this.getWritable();
        // Deduplicate with a Set and then convert back to array
        writable.__ids = [
            ...new Set([
                ...writable.__ids,
                ...ids
            ])
        ];
    }
    appendId(id) {
        const writable = this.getWritable();
        // Deduplicate with a Set and then convert back to array
        writable.__ids = [
            ...new Set([
                ...writable.__ids,
                id
            ])
        ];
    }
    getTextContent(_includeInert, _includeDirectionless) {
        return this.__ids;
    }
    decorate(_editor, config) {
        const isEditable = _editor.isEditable();
        const embedBlockTheme = config.theme.embedBlock || {};
        const className = {
            base: embedBlockTheme.base || '',
            focus: embedBlockTheme.focus || ''
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalBlockWithAlignableContents$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BlockWithAlignableContents"], {
                    className: className,
                    nodeKey: this.getKey(),
                    format: this.__format,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PlaylistEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        className: className,
                        format: this.__format,
                        nodeKey: this.getKey(),
                        fileIDs: this.__ids
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx",
                        lineNumber: 151,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx",
                    lineNumber: 147,
                    columnNumber: 24
                }, this),
                !isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalBlockWithAlignableContents$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BlockWithAlignableContents"], {
                    className: className,
                    nodeKey: this.getKey(),
                    format: this.__format,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
                        fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "rectangular",
                            width: "100%",
                            height: 60,
                            sx: {
                                borderRadius: 1
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx",
                            lineNumber: 157,
                            columnNumber: 33
                        }, this),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MediaPlayerComponent, {
                            className: className,
                            format: this.__format,
                            nodeKey: this.getKey(),
                            fileIDs: this.__ids
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx",
                            lineNumber: 160,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx",
                        lineNumber: 157,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx",
                    lineNumber: 153,
                    columnNumber: 25
                }, this)
            ]
        }, void 0, true);
    }
}
function $createPlaylistNode(fileIDs) {
    return new PlaylistNode(fileIDs);
}
function $isPlaylistNode(node) {
    return node instanceof PlaylistNode;
}
const INSERT_PLAYLIST_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('INSERT_PLAYLIST_COMMAND');
function PlaylistPlugin() {
    _s();
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const { unit } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    // Helper function to create UnitFile relationship
    const createUnitFileRelationship = async (fileId)=>{
        try {
            if (!unit) return;
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            // Check if UnitFile relationship already exists
            const { data: existingUnitFiles } = await client.models.UnitFile.list({
                filter: {
                    and: [
                        {
                            unitID: {
                                eq: unit.id
                            }
                        },
                        {
                            fileID: {
                                eq: fileId
                            }
                        }
                    ]
                }
            });
            if (existingUnitFiles && existingUnitFiles.length === 0) {
                const { data: file } = await client.models.File.get({
                    id: fileId
                });
                if (file) {
                    await client.models.UnitFile.create({
                        unitID: unit.id,
                        fileID: fileId
                    });
                }
            }
        } catch (error) {
            console.error('Error creating UnitFile relationship:', error);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PlaylistPlugin.useEffect": ()=>{
            if (!editor.hasNodes([
                PlaylistNode
            ])) {
                throw new Error('PlaylistPlugin: PlaylistNode not registered on editor');
            }
            return editor.registerCommand(INSERT_PLAYLIST_COMMAND, {
                "PlaylistPlugin.useEffect": (payload)=>{
                    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
                    const fileIDs = Array.isArray(payload) ? payload : [
                        payload
                    ];
                    // Check if we have a node selection with a PlaylistNode
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])(selection)) {
                        const nodes = selection.getNodes();
                        const playlistNode = nodes.find({
                            "PlaylistPlugin.useEffect.playlistNode": (node)=>$isPlaylistNode(node)
                        }["PlaylistPlugin.useEffect.playlistNode"]);
                        if (playlistNode) {
                            // Append to existing playlist
                            fileIDs.forEach({
                                "PlaylistPlugin.useEffect": (id)=>{
                                    if (id) {
                                        playlistNode.appendId(id);
                                        // Create UnitFile relationship asynchronously
                                        createUnitFileRelationship(id);
                                    }
                                }
                            }["PlaylistPlugin.useEffect"]);
                            return true;
                        }
                    }
                    // No playlist selected, create new one
                    const PlaylistNode = $createPlaylistNode(payload);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(PlaylistNode);
                    // Create UnitFile relationships for new playlist asynchronously
                    fileIDs.forEach({
                        "PlaylistPlugin.useEffect": (id_0)=>{
                            if (id_0) {
                                createUnitFileRelationship(id_0);
                            }
                        }
                    }["PlaylistPlugin.useEffect"]);
                    return true;
                }
            }["PlaylistPlugin.useEffect"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
        }
    }["PlaylistPlugin.useEffect"], [
        editor
    ]);
    return null;
}
_s(PlaylistPlugin, "34Ldibuw+x8+PVAb3JOAvDxeam0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c1 = PlaylistPlugin;
var _c, _c1;
__turbopack_context__.k.register(_c, "MediaPlayerComponent");
__turbopack_context__.k.register(_c1, "PlaylistPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/DragDropPastePlugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ACCEPTABLE_AUDIO_TYPES",
    ()=>ACCEPTABLE_AUDIO_TYPES,
    "ACCEPTABLE_FILE_TYPES",
    ()=>ACCEPTABLE_FILE_TYPES,
    "ACCEPTABLE_IMAGE_TYPES",
    ()=>ACCEPTABLE_IMAGE_TYPES,
    "ANY_ACCEPTABLE_TYPES",
    ()=>ANY_ACCEPTABLE_TYPES,
    "default",
    ()=>DragDropPaste
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview DragDropPastePlugin - Handles drag-drop and paste for media files.
 * @module DragDropPastePlugin
 * 
 * Manages file uploads via drag-drop and paste operations. Supports images,
 * audio files, and documents with AWS S3 storage integration.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/client/apis/uploadData.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/rich-text/LexicalRichText.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ImagesPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/ImagesPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
// Type import removed - not needed in runtime JS
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/fileContext.jsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const ACCEPTABLE_IMAGE_TYPES = [
    'image/',
    'image/heic',
    'image/heif',
    'image/gif',
    'image/webp',
    'image/png',
    'image/jpeg'
];
const ACCEPTABLE_AUDIO_TYPES = [
    'audio/mp3',
    'audio/mpeg',
    'audio/wav',
    'audio/ogg',
    'audio/m4a',
    'audio/aac',
    'audio/webm',
    'audio/flac'
];
const ACCEPTABLE_FILE_TYPES = [
    'application/pdf',
    'text/plain',
    'text/markdown',
    'text/csv',
    'text/x-fountain',
    'text/x-gift',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/zip',
    'application/x-rar-compressed',
    'application/x-7z-compressed',
    'application/x-tar',
    'application/x-bzip',
    'application/x-bzip2',
    'application/gzip',
    'application/x-xz',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.ms-word',
    'application/vnd.oasis.opendocument.text',
    'application/vnd.oasis.opendocument.spreadsheet',
    'application/vnd.oasis.opendocument.presentation',
    'application/epub+zip',
    'application/x-imscc+zip',
    'application/x-qti+xml'
];
const ANY_ACCEPTABLE_TYPES = [
    ...ACCEPTABLE_IMAGE_TYPES,
    ...ACCEPTABLE_AUDIO_TYPES,
    ...ACCEPTABLE_FILE_TYPES
];
function DragDropPaste() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "a4c2d16a34fd9d3467de933a13dda3cc779451ebfcdd7c1c636c742dcdcff651") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a4c2d16a34fd9d3467de933a13dda3cc779451ebfcdd7c1c636c742dcdcff651";
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const { session } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const identityId = session?.identityId;
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [, setFileOperations] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(t0);
    let t1;
    if ($[2] !== editor || $[3] !== identityId) {
        t1 = ({
            "DragDropPaste[useEffect()]": ()=>{
                if (!identityId) {
                    console.log("[DragDropPaste] Skipping command registration - no identityId");
                    return;
                }
                return editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAG_DROP_PASTE"], {
                    "DragDropPaste[useEffect() > editor.registerCommand()]": (files)=>{
                        (async ()=>{
                            const _fileOperations = files.map(_DragDropPasteUseEffectEditorRegisterCommandAnonymousFilesMap);
                            setFileOperations(_fileOperations);
                            const _inProgress = files.map({
                                "DragDropPaste[useEffect() > editor.registerCommand() > <anonymous> > files.map()]": async (file, index)=>{
                                    let subfolder;
                                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isMimeType"])(file, ACCEPTABLE_IMAGE_TYPES)) {
                                        subfolder = "images";
                                    } else {
                                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isMimeType"])(file, ACCEPTABLE_AUDIO_TYPES)) {
                                            subfolder = "audio";
                                        } else {
                                            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isMimeType"])(file, ACCEPTABLE_FILE_TYPES)) {
                                                subfolder = "files";
                                            }
                                        }
                                    }
                                    const s3Path = `protected/${identityId}/${subfolder}/${file.name}`;
                                    const uploadOperation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
                                        path: s3Path,
                                        data: file,
                                        options: {
                                            contentType: file.type,
                                            onProgress (progress) {
                                                console.log(`Uploaded: ${progress.transferredBytes}/${progress.totalBytes}`);
                                                setFileOperations((prev)=>{
                                                    const newFileOperations = [
                                                        ...prev
                                                    ];
                                                    newFileOperations[index].progress = Math.round(progress.transferredBytes / progress.totalBytes * 100) + "%";
                                                    return newFileOperations;
                                                });
                                            }
                                        }
                                    });
                                    const uploadResult = await uploadOperation.result;
                                    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                                    const { data: newFile } = await client.models.File.create({
                                        path: uploadResult.path,
                                        name: file.name,
                                        size: file.size,
                                        mimeType: file.type,
                                        level: "PROTECTED",
                                        identityId
                                    });
                                    console.log("DragDropPastePlugin result", newFile);
                                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isMimeType"])(file, ACCEPTABLE_IMAGE_TYPES)) {
                                        setTimeout({
                                            "DragDropPaste[useEffect() > editor.registerCommand() > <anonymous> > files.map() > setTimeout()]": ()=>{
                                                editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ImagesPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_IMAGE_COMMAND"], {
                                                    altText: newFile.name,
                                                    path: newFile.path,
                                                    identityId
                                                });
                                            }
                                        }["DragDropPaste[useEffect() > editor.registerCommand() > <anonymous> > files.map() > setTimeout()]"], 3000);
                                    } else {
                                        if (file.type.includes("audio")) {
                                            setTimeout({
                                                "DragDropPaste[useEffect() > editor.registerCommand() > <anonymous> > files.map() > setTimeout()]": ()=>{
                                                    editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_PLAYLIST_COMMAND"], [
                                                        newFile.id
                                                    ]);
                                                }
                                            }["DragDropPaste[useEffect() > editor.registerCommand() > <anonymous> > files.map() > setTimeout()]"], 3000);
                                        }
                                    }
                                }
                            }["DragDropPaste[useEffect() > editor.registerCommand() > <anonymous> > files.map()]"]);
                            await Promise.allSettled(_inProgress);
                        })();
                        return true;
                    }
                }["DragDropPaste[useEffect() > editor.registerCommand()]"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_HIGH"]);
            }
        })["DragDropPaste[useEffect()]"];
        $[2] = editor;
        $[3] = identityId;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    let t2;
    if ($[5] !== editor) {
        t2 = [
            editor
        ];
        $[5] = editor;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return null;
}
_s(DragDropPaste, "6ThH+RCWfaWYzFQLwelgQ3ZUsG8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = DragDropPaste;
function _DragDropPasteUseEffectEditorRegisterCommandAnonymousFilesMap(f) {
    return {
        name: f.name,
        progress: "0%"
    };
}
var _c;
__turbopack_context__.k.register(_c, "DragDropPaste");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/StoryProgressPlugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StoryProgressPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview StoryProgressPlugin - Auto-populates grade data for Storybook stories.
 * @module StoryProgressPlugin
 * 
 * This plugin is only used in Storybook stories to automatically create grade data
 * after the editor state loads, using the actual auto-generated node keys.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function StoryProgressPlugin() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "1fb99900039359b3c8e93c0496fd8bd589fc4e1975ddc8bd85887e352f7607c2") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "1fb99900039359b3c8e93c0496fd8bd589fc4e1975ddc8bd85887e352f7607c2";
    }
    const { unit, grade } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t0;
    if ($[1] !== editor || $[2] !== grade || $[3] !== unit?.id) {
        t0 = ({
            "StoryProgressPlugin[useEffect()]": ()=>{
                if (unit?.id !== "workbook-with-progress-id") {
                    return;
                }
                const timeout = setTimeout({
                    "StoryProgressPlugin[useEffect() > setTimeout()]": ()=>{
                        editor.getEditorState().read({
                            "StoryProgressPlugin[useEffect() > setTimeout() > (anonymous)()]": ()=>{
                                const root = editor.getEditorState()._nodeMap;
                                const exerciseNodes = {
                                    "meaning-association": [],
                                    "quiz": [],
                                    "custom-answer": []
                                };
                                root.forEach({
                                    "StoryProgressPlugin[useEffect() > setTimeout() > (anonymous)() > root.forEach()]": (node, key)=>{
                                        if (exerciseNodes[node.__type] !== undefined) {
                                            exerciseNodes[node.__type].push(key);
                                        }
                                    }
                                }["StoryProgressPlugin[useEffect() > setTimeout() > (anonymous)() > root.forEach()]"]);
                                console.log("[StoryProgressPlugin] Exercise node keys:", exerciseNodes);
                                console.log("[StoryProgressPlugin] grade:", grade);
                                console.log("[StoryProgressPlugin] grade.data:", grade?.data);
                                console.log("[StoryProgressPlugin] typeof grade.data:", typeof grade?.data);
                                console.log("[StoryProgressPlugin] grade.data keys:", grade?.data ? Object.keys(grade.data) : "no data");
                                const hasExerciseData = grade?.data && typeof grade.data === "object" && Object.keys(grade.data).some(_StoryProgressPluginUseEffectSetTimeoutAnonymousAnonymous);
                                console.log("[StoryProgressPlugin] hasExerciseData:", hasExerciseData);
                                if (!grade) {
                                    console.log("[StoryProgressPlugin] Grade not yet loaded, will retry on next update");
                                    return;
                                }
                                if (!hasExerciseData) {
                                    const gradeData = {};
                                    exerciseNodes["meaning-association"].forEach({
                                        "StoryProgressPlugin[useEffect() > setTimeout() > (anonymous)() > (anonymous)()]": (key_1, index)=>{
                                            if (index === 0) {
                                                gradeData[String(key_1)] = {
                                                    tabIndex: 0,
                                                    complete: false,
                                                    easy: {
                                                        verifiedAnswers: [
                                                            "vocab-word-1",
                                                            "vocab-word-2",
                                                            "vocab-word-3"
                                                        ],
                                                        attemptedAnswers: {
                                                            "vocab-word-1": [],
                                                            "vocab-word-2": [
                                                                "vocab-word-3"
                                                            ],
                                                            "vocab-word-3": []
                                                        },
                                                        attemptsCount: 4,
                                                        accuracy: 0.75,
                                                        percentComplete: 0.6,
                                                        complete: false
                                                    },
                                                    hard: {
                                                        verifiedAnswers: [
                                                            "vocab-word-1",
                                                            "vocab-word-2"
                                                        ],
                                                        attemptedAnswers: {
                                                            "vocab-word-1": [
                                                                "vocab-word-1"
                                                            ],
                                                            "vocab-word-2": [
                                                                "vocab-word-3",
                                                                "vocab-word-2"
                                                            ]
                                                        },
                                                        percentComplete: 0.4,
                                                        complete: false
                                                    },
                                                    learn: {
                                                        verifiedAnswers: [
                                                            "vocab-word-1"
                                                        ],
                                                        attemptedAnswers: {
                                                            "vocab-word-1": [
                                                                "vocab-word-1"
                                                            ]
                                                        },
                                                        attemptsCount: 1,
                                                        accuracy: 1,
                                                        percentComplete: 0.2,
                                                        complete: false,
                                                        droppedPairs: {
                                                            "vocab-word-1": "vocab-word-1"
                                                        }
                                                    }
                                                };
                                            }
                                        }
                                    }["StoryProgressPlugin[useEffect() > setTimeout() > (anonymous)() > (anonymous)()]"]);
                                    exerciseNodes.quiz.forEach({
                                        "StoryProgressPlugin[useEffect() > setTimeout() > (anonymous)() > exerciseNodes.quiz.forEach()]": (key_2, index_0)=>{
                                            if (index_0 === 0) {
                                                gradeData[String(key_2)] = {
                                                    accuracy: 0.5,
                                                    attemptedAnswers: {
                                                        "0": "0",
                                                        "1": "1"
                                                    },
                                                    correctAnswers: {
                                                        "0": "0"
                                                    },
                                                    complete: false
                                                };
                                            }
                                        }
                                    }["StoryProgressPlugin[useEffect() > setTimeout() > (anonymous)() > exerciseNodes.quiz.forEach()]"]);
                                    exerciseNodes["custom-answer"].forEach({
                                        "StoryProgressPlugin[useEffect() > setTimeout() > (anonymous)() > (anonymous)()]": (key_3, index_1)=>{
                                            gradeData[String(key_3)] = {
                                                accuracy: 1,
                                                complete: true,
                                                userResponse: index_1 === 0 ? "Dog" : "A farewell greeting",
                                                feedback: index_1 === 0 ? "Correct! \"\u72AC\" (inu) means \"dog\" in Japanese." : "Great! \"\u3055\u3088\u3046\u306A\u3089\" (sayounara) is indeed a farewell greeting."
                                            };
                                        }
                                    }["StoryProgressPlugin[useEffect() > setTimeout() > (anonymous)() > (anonymous)()]"]);
                                    console.log("[StoryProgressPlugin] Seeding grade with data:", gradeData);
                                    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                                    console.log("[StoryProgressPlugin] Updating grade with data:", gradeData);
                                    client.models.Grade.update({
                                        id: grade.id,
                                        data: gradeData,
                                        percentComplete: 0.65,
                                        accuracy: 0.75
                                    }).catch(_StoryProgressPluginUseEffectSetTimeoutAnonymousAnonymous2);
                                }
                            }
                        }["StoryProgressPlugin[useEffect() > setTimeout() > (anonymous)()]"]);
                    }
                }["StoryProgressPlugin[useEffect() > setTimeout()]"], 200);
                return ()=>clearTimeout(timeout);
            }
        })["StoryProgressPlugin[useEffect()]"];
        $[1] = editor;
        $[2] = grade;
        $[3] = unit?.id;
        $[4] = t0;
    } else {
        t0 = $[4];
    }
    const t1 = unit?.id;
    let t2;
    if ($[5] !== editor || $[6] !== grade || $[7] !== t1) {
        t2 = [
            editor,
            t1,
            grade
        ];
        $[5] = editor;
        $[6] = grade;
        $[7] = t1;
        $[8] = t2;
    } else {
        t2 = $[8];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t2);
    return null;
}
_s(StoryProgressPlugin, "BwWaWfCSnE1fo085dOVWmOaoYD8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = StoryProgressPlugin;
function _StoryProgressPluginUseEffectSetTimeoutAnonymousAnonymous2(err) {
    return console.error("[StoryProgressPlugin] Failed to save grade:", err);
}
function _StoryProgressPluginUseEffectSetTimeoutAnonymousAnonymous(key_0) {
    return !isNaN(Number(key_0));
}
var _c;
__turbopack_context__.k.register(_c, "StoryProgressPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/QuizPlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createQuizNode",
    ()=>$createQuizNode,
    "$isQuizNode",
    ()=>$isQuizNode,
    "INSERT_QUIZ_COMMAND",
    ()=>INSERT_QUIZ_COMMAND,
    "QuizNode",
    ()=>QuizNode,
    "default",
    ()=>QuizPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview QuizPlugin - Creates interactive quiz nodes for assessments.
 * 
 * This plugin provides quiz functionality with multiple question types,
 * automatic grading, and progress tracking.
 * 
 * @module QuizPlugin
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$QuizEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/QuizEditor.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$QuizComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/QuizComponent.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
/**
 * Converts a DOM element into a QuizNode.
 * 
 * @param {HTMLElement} domNode - DOM element with quiz data
 * @returns {{node: QuizNode} | null} Created node or null
 */ function convertQuizElement(domNode) {
    // comma separated list of word ids
    const data = domNode.getAttribute('data-lexical-quiz') || [];
    if ("TURBOPACK compile-time truthy", 1) {
        const node = $createQuizNode(data);
        return {
            node
        };
    }
    //TURBOPACK unreachable
    ;
}
class QuizNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __data;
    static getType() {
        return 'quiz';
    }
    static clone(node) {
        return new QuizNode(node.__data, node.__format, node.__key);
    }
    static importJSON(serializedNode) {
        const node = $createQuizNode(serializedNode.data);
        // node.setFormat(serializedNode.format);
        return node;
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            type: 'quiz',
            version: 1,
            data: this.__data
        };
    }
    constructor(ids = [], format, key){
        super(key);
        this.__data = ids;
    }
    exportDOM() {
        const element = document.createElement('div');
        element.setAttribute('data-lexical-quiz', JSON.stringify(this.__data));
        return {
            element
        };
    }
    createDOM(config) {
        const div = document.createElement('div');
        div.setAttribute('data-lexical-quiz', JSON.stringify(this.__data));
        // const theme = config.theme;
        // const className = theme.image;
        // if (className !== undefined) {
        //   div.className = className;
        // }
        return div;
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute('data-lexical-quiz')) {
                    return null;
                }
                return {
                    conversion: convertQuizElement,
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
    canBeEmpty() {
        return true;
    }
    getData() {
        return this.__data || [];
    }
    saveData(data) {
        const writable = this.getWritable();
        writable.__data = data;
    }
    getTextContent(_includeInert, _includeDirectionless) {
        return this.__data;
    }
    decorate(_editor, config) {
        const isEditable = _editor.isEditable();
        const embedBlockTheme = config.theme.embedBlock || {};
        const className = {
            base: embedBlockTheme.base || '',
            focus: embedBlockTheme.focus || ''
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$QuizEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    data: this.getData()
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/QuizPlugin.jsx",
                    lineNumber: 128,
                    columnNumber: 22
                }, this),
                !isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$QuizComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    data: this.getData()
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/QuizPlugin.jsx",
                    lineNumber: 129,
                    columnNumber: 23
                }, this)
            ]
        }, void 0, true);
    }
}
function $createQuizNode(data) {
    return new QuizNode(data);
}
function $isQuizNode(node) {
    return node instanceof QuizNode;
}
const INSERT_QUIZ_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('INSERT_QUIZ_COMMAND');
function QuizPlugin() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "649d6d2535d8fbd7e5554426bdfd8a2945ff66a6e6fa6faed11abbaff082e130") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "649d6d2535d8fbd7e5554426bdfd8a2945ff66a6e6fa6faed11abbaff082e130";
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t0;
    let t1;
    if ($[1] !== editor) {
        t0 = ({
            "QuizPlugin[useEffect()]": ()=>{
                if (!editor.hasNodes([
                    QuizNode
                ])) {
                    throw new Error("QuizPlugin: QuizNode not registered on editor");
                }
                return editor.registerCommand(INSERT_QUIZ_COMMAND, _QuizPluginUseEffectEditorRegisterCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
            }
        })["QuizPlugin[useEffect()]"];
        t1 = [
            editor
        ];
        $[1] = editor;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return null;
}
_s(QuizPlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = QuizPlugin;
function _QuizPluginUseEffectEditorRegisterCommand(payload) {
    const meaningAssociationNode = $createQuizNode(payload);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(meaningAssociationNode);
    return true;
}
var _c;
__turbopack_context__.k.register(_c, "QuizPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/AnswerPlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createAnswerNode",
    ()=>$createAnswerNode,
    "$isAnswerNode",
    ()=>$isAnswerNode,
    "AnswerNode",
    ()=>AnswerNode,
    "INSERT_ANSWER_BLOCK_COMMAND",
    ()=>INSERT_ANSWER_BLOCK_COMMAND,
    "default",
    ()=>AnswerPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview AnswerPlugin - Creates interactive answer fields for vocabulary exercises.
 * 
 * This plugin provides functionality for creating answer nodes where learners are prompted
 * to provide translations or definitions of vocabulary words. It supports various input
 * methods and validation strategies.
 * 
 * @module AnswerPlugin
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
// import { BlockWithAlignableContents } from '@lexical/react/LexicalBlockWithAlignableContents';
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AnswerEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AnswerEditor.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AnswerComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AnswerComponent.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
/**
 * Converts a DOM element with answer attributes into an AnswerNode.
 * 
 * @param {HTMLElement} domNode - DOM element containing answer data attributes
 * @returns {{node: AnswerNode} | null} Object containing the created node or null if invalid
 */ function convertAnswerElement(domNode) {
    // comma separated list of word ids
    const wordIDs = domNode.getAttribute('data-lexical-answer').split(',') || [];
    const requestDefinition = domNode.getAttribute('data-lexical-answer-request-definition');
    const allowedInput = JSON.parse(domNode.getAttribute('data-lexical-answer-allowed-input')) || {};
    const promptMethod = JSON.parse(domNode.getAttribute('data-lexical-answer-prompt-method')) || {};
    if ("TURBOPACK compile-time truthy", 1) {
        const node = $createAnswerNode(wordIDs, requestDefinition, allowedInput, promptMethod);
        return {
            node
        };
    }
    //TURBOPACK unreachable
    ;
}
class AnswerNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __ids;
    __requestDefinition;
    __allowedInput;
    __promptMethod;
    static getType() {
        return 'answer';
    }
    static clone(node) {
        return new AnswerNode(node.__ids, node.__requestDefinition, node.__allowedInput, node.__promptMethod, node.__format, node.__key);
    }
    static importJSON(serializedNode) {
        const node = $createAnswerNode(serializedNode.wordIDs, serializedNode.requestDefinition, serializedNode.allowedInput, serializedNode.promptMethod, serializedNode.format);
        return node;
    }
    exportJSON() {
        return {
            type: 'answer',
            version: 1,
            wordIDs: [
                ...this.__ids
            ],
            requestDefinition: this.__requestDefinition,
            allowedInput: this.__allowedInput,
            promptMethod: this.__promptMethod
        };
    }
    constructor(ids = [], requestDefinition, allowedInput = {}, promptMethod = [], format, key){
        super(format, key);
        this.__ids = ids;
        this.__requestDefinition = requestDefinition;
        this.__allowedInput = allowedInput;
        this.__promptMethod = promptMethod;
    }
    exportDOM() {
        const element = document.createElement('div');
        element.setAttribute('data-lexical-answer', this.__ids.join(','));
        element.setAttribute('data-lexical-answer-request-definition', this.__requestDefinition);
        element.setAttribute('data-lexical-answer-allowed-input', JSON.stringify(this.__allowedInput));
        element.setAttribute('data-lexical-answer-prompt-method', JSON.stringify(this.__promptMethod));
        return {
            element
        };
    }
    createDOM(config) {
        const div = document.createElement('div');
        div.setAttribute('data-lexical-answer', this.__ids.join(','));
        div.setAttribute('data-lexical-answer-request-definition', this.__requestDefinition);
        div.setAttribute('data-lexical-answer-allowed-input', JSON.stringify(this.__allowedInput));
        div.setAttribute('data-lexical-answer-prompt-method', JSON.stringify(this.__promptMethod));
        const theme = config.theme;
        const className = theme.image;
        if (className !== undefined) {
            div.className = className;
        }
        return div;
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute('data-lexical-answer')) {
                    return null;
                }
                return {
                    conversion: convertAnswerElement,
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
    canBeEmpty() {
        return true;
    }
    getIds() {
        return this.__ids;
    }
    removeIntersection(ids) {
        const writable = this.getWritable();
        let intersection = this.__ids.filter((x)=>!ids.includes(x));
        writable.__ids = [
            ...new Set([
                ...intersection
            ])
        ];
    }
    setIds(ids) {
        const writable = this.getWritable();
        writable.__ids = [
            ...new Set([
                ...ids
            ])
        ];
    }
    mergeIds(ids) {
        const writable = this.getWritable();
        // Deduplicate with a Set and then convert back to array
        writable.__ids = [
            ...new Set([
                ...writable.__ids,
                ...ids
            ])
        ];
    }
    appendId(id) {
        const writable = this.getWritable();
        // Deduplicate with a Set and then convert back to array
        writable.__ids = [
            ...new Set([
                ...writable.__ids,
                id
            ])
        ];
    }
    setAllowedInput(allowedInput) {
        const writable = this.getWritable();
        writable.__allowedInput = allowedInput;
    }
    mergeAllowedInput(allowedInput) {
        const writable = this.getWritable();
        writable.__allowedInput = {
            ...writable.__allowedInput,
            ...allowedInput
        };
    }
    setPromptMethod(newPromptMethod) {
        const writable = this.getWritable();
        writable.__promptMethod = newPromptMethod;
    }
    getTextContent(_includeInert, _includeDirectionless) {
        return this.__ids;
    }
    setRequestDefinition(requestDefinition) {
        const writable = this.getWritable();
        writable.__requestDefinition = requestDefinition;
    }
    decorate(_editor, config) {
        const isEditable = _editor.isEditable();
        const embedBlockTheme = config.theme.embedBlock || {};
        const className = {
            base: embedBlockTheme.base || '',
            focus: embedBlockTheme.focus || ''
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AnswerEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    wordIDs: this.__ids,
                    requestDefinition: this.__requestDefinition,
                    allowedInput: this.__allowedInput,
                    promptMethod: this.__promptMethod
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/AnswerPlugin.jsx",
                    lineNumber: 180,
                    columnNumber: 22
                }, this),
                !isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AnswerComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    wordIDs: this.__ids,
                    requestDefinition: this.__requestDefinition,
                    allowedInput: this.__allowedInput,
                    promptMethod: this.__promptMethod
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/AnswerPlugin.jsx",
                    lineNumber: 182,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true);
    }
}
function $createAnswerNode(wordIDs, requestDefinition, allowedInputs, promptMethod, format) {
    return new AnswerNode(wordIDs, requestDefinition, allowedInputs, promptMethod, format);
}
function $isAnswerNode(node) {
    return node instanceof AnswerNode;
}
const INSERT_ANSWER_BLOCK_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('INSERT_ANSWER_BLOCK_COMMAND');
function AnswerPlugin() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "e50e6a259bb126f3ab0075abbaf8b88b60978b71b8600c578e8c69e92ba802e5") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e50e6a259bb126f3ab0075abbaf8b88b60978b71b8600c578e8c69e92ba802e5";
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t0;
    let t1;
    if ($[1] !== editor) {
        t0 = ({
            "AnswerPlugin[useEffect()]": ()=>{
                if (!editor.hasNodes([
                    AnswerNode
                ])) {
                    throw new Error("AnswerPlugin: AnswerNode not registered on editor");
                }
                return editor.registerCommand(INSERT_ANSWER_BLOCK_COMMAND, _AnswerPluginUseEffectEditorRegisterCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
            }
        })["AnswerPlugin[useEffect()]"];
        t1 = [
            editor
        ];
        $[1] = editor;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return null;
}
_s(AnswerPlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = AnswerPlugin;
function _AnswerPluginUseEffectEditorRegisterCommand(payload) {
    const { wordIDs: t0, requestDefinition: t1, allowedInput: t2, promptMethod: t3 } = payload || {};
    const wordIDs = t0 === undefined ? [] : t0;
    const requestDefinition = t1 === undefined ? "translation" : t1;
    const allowedInput = t2 === undefined ? [
        "text"
    ] : t2;
    const promptMethod = t3 === undefined ? [
        "phrase"
    ] : t3;
    const answerNode = $createAnswerNode(wordIDs, requestDefinition, allowedInput, promptMethod);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(answerNode);
    return true;
}
var _c;
__turbopack_context__.k.register(_c, "AnswerPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/MeaningAssociationPlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createMeaningAssociationNode",
    ()=>$createMeaningAssociationNode,
    "$isMeaningAssociationNode",
    ()=>$isMeaningAssociationNode,
    "INSERT_MEANING_ASSOCIATION_BLOCK_COMMAND",
    ()=>INSERT_MEANING_ASSOCIATION_BLOCK_COMMAND,
    "MeaningAssociationNode",
    ()=>MeaningAssociationNode,
    "default",
    ()=>MeaningAssociationPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview MeaningAssociationPlugin - Creates vocabulary matching exercises.
 * 
 * This plugin provides interactive exercises where learners match words with their
 * definitions or meanings. Supports Easy, Hard, and Learn modes for different
 * difficulty levels.
 * 
 * @module MeaningAssociationPlugin
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
// import { BlockWithAlignableContents } from '@lexical/react/LexicalBlockWithAlignableContents';
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$MeaningAssociationEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/MeaningAssociationEditor.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/index.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
/**
 * Converts a DOM element into a MeaningAssociationNode.
 * 
 * @param {HTMLElement} domNode - DOM element with meaning-association data attribute
 * @returns {{node: MeaningAssociationNode} | null} Created node or null
 */ function convertMeaningAssociationElement(domNode) {
    // comma separated list of word ids
    const wordIDs = domNode.getAttribute('data-lexical-meaning-association').split(',') || [];
    if ("TURBOPACK compile-time truthy", 1) {
        const node = $createMeaningAssociationNode(wordIDs);
        return {
            node
        };
    }
    //TURBOPACK unreachable
    ;
}
class MeaningAssociationNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __ids;
    __enabledModes;
    static getType() {
        return 'meaning-association';
    }
    static clone(node) {
        return new MeaningAssociationNode(node.__ids, node.__enabledModes, node.__format, node.__key);
    }
    static importJSON(serializedNode) {
        const node = $createMeaningAssociationNode(serializedNode.wordIDs, serializedNode.enabledModes);
        // node.setFormat(serializedNode.format);
        return node;
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            type: 'meaning-association',
            version: 1,
            wordIDs: [
                ...this.__ids
            ],
            enabledModes: this.__enabledModes || [
                'learn',
                'easy',
                'hard'
            ]
        };
    }
    constructor(ids = [], enabledModes = [
        'learn',
        'easy',
        'hard'
    ], format, key){
        super(key);
        this.__ids = ids;
        this.__enabledModes = enabledModes;
    }
    exportDOM() {
        const element = document.createElement('div');
        element.setAttribute('data-lexical-meaning-association', this.__ids.join(','));
        return {
            element
        };
    }
    createDOM(config) {
        const div = document.createElement('div');
        div.setAttribute('data-lexical-meaning-association', this.__ids.join(','));
        const theme = config.theme;
        const className = theme.image;
        if (className !== undefined) {
            div.className = className;
        }
        return div;
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute('data-lexical-meaning-association')) {
                    return null;
                }
                return {
                    conversion: convertMeaningAssociationElement,
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
    canBeEmpty() {
        return true;
    }
    getIds() {
        return this.__ids;
    }
    getEnabledModes() {
        return this.__enabledModes || [
            'learn',
            'easy',
            'hard'
        ];
    }
    setEnabledModes(modes) {
        const writable = this.getWritable();
        writable.__enabledModes = modes;
    }
    removeIntersection(ids) {
        const writable = this.getWritable();
        let intersection = this.__ids.filter((x)=>!ids.includes(x));
        writable.__ids = [
            ...new Set([
                ...intersection
            ])
        ];
    }
    setIds(ids) {
        const writable = this.getWritable();
        writable.__ids = [
            ...new Set([
                ...ids
            ])
        ];
    }
    mergeIds(ids) {
        const writable = this.getWritable();
        // Deduplicate with a Set and then convert back to array
        writable.__ids = [
            ...new Set([
                ...writable.__ids,
                ...ids
            ])
        ];
    }
    appendId(id) {
        const writable = this.getWritable();
        // Deduplicate with a Set and then convert back to array
        writable.__ids = [
            ...new Set([
                ...writable.__ids,
                id
            ])
        ];
    }
    getTextContent(_includeInert, _includeDirectionless) {
        return this.__ids;
    }
    decorate(_editor, config) {
        const isEditable = _editor.isEditable();
        const embedBlockTheme = config.theme.embedBlock || {};
        const className = {
            base: embedBlockTheme.base || '',
            focus: embedBlockTheme.focus || ''
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$MeaningAssociationEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    wordIDs: this.__ids,
                    enabledModes: this.__enabledModes || [
                        'learn',
                        'easy',
                        'hard'
                    ]
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/MeaningAssociationPlugin.jsx",
                    lineNumber: 156,
                    columnNumber: 22
                }, this),
                !isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    wordIDs: this.__ids,
                    enabledModes: this.__enabledModes || [
                        'learn',
                        'easy',
                        'hard'
                    ]
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/MeaningAssociationPlugin.jsx",
                    lineNumber: 158,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true);
    }
}
function $createMeaningAssociationNode(wordIDs, enabledModes = [
    'learn',
    'easy',
    'hard'
]) {
    return new MeaningAssociationNode(wordIDs, enabledModes);
}
function $isMeaningAssociationNode(node) {
    return node instanceof MeaningAssociationNode;
}
const INSERT_MEANING_ASSOCIATION_BLOCK_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('INSERT_MEANING_ASSOCIATION_BLOCK_COMMAND');
function MeaningAssociationPlugin() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "fd2acfd400e12badae30ea8fd77ef13f0ced0cfd2345e20bc85b152ac787954a") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "fd2acfd400e12badae30ea8fd77ef13f0ced0cfd2345e20bc85b152ac787954a";
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t0;
    let t1;
    if ($[1] !== editor) {
        t0 = ({
            "MeaningAssociationPlugin[useEffect()]": ()=>{
                if (!editor.hasNodes([
                    MeaningAssociationNode
                ])) {
                    throw new Error("MeaningAssociationPlugin: MeaningAssociationNode not registered on editor");
                }
                return editor.registerCommand(INSERT_MEANING_ASSOCIATION_BLOCK_COMMAND, _MeaningAssociationPluginUseEffectEditorRegisterCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
            }
        })["MeaningAssociationPlugin[useEffect()]"];
        t1 = [
            editor
        ];
        $[1] = editor;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return null;
}
_s(MeaningAssociationPlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = MeaningAssociationPlugin;
function _MeaningAssociationPluginUseEffectEditorRegisterCommand(payload) {
    const meaningAssociationNode = $createMeaningAssociationNode(payload);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(meaningAssociationNode);
    return true;
}
var _c;
__turbopack_context__.k.register(_c, "MeaningAssociationPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/CustomAnswerPlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createCustomAnswerNode",
    ()=>$createCustomAnswerNode,
    "$isCustomAnswerNode",
    ()=>$isCustomAnswerNode,
    "CustomAnswerNode",
    ()=>CustomAnswerNode,
    "INSERT_CUSTOM_ANSWER_BLOCK_COMMAND",
    ()=>INSERT_CUSTOM_ANSWER_BLOCK_COMMAND,
    "default",
    ()=>CustomAnswerPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview CustomAnswerPlugin - Creates custom question-answer exercises.
 * 
 * This plugin allows educators to create flexible Q&A exercises with
 * custom questions, validation rules, and prompting strategies.
 * 
 * @module CustomAnswerPlugin
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$nodes$2f$CustomAnswerNode$2f$CustomAnswerEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$nodes$2f$CustomAnswerNode$2f$CustomAnswerComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
/**
 * Converts a DOM element into a CustomAnswerNode.
 * 
 * @param {HTMLElement} domNode - DOM element with custom answer data
 * @returns {{node: CustomAnswerNode} | null} Created node or null
 */ function convertCustomAnswerElement(domNode) {
    const ids = domNode.getAttribute('data-lexical-custom-answer').split(',') || [];
    const allowedInput = JSON.parse(domNode.getAttribute('data-lexical-custom-answer-allowed-input')) || {};
    const promptMethod = JSON.parse(domNode.getAttribute('data-lexical-custom-answer-prompt-method')) || {};
    if ("TURBOPACK compile-time truthy", 1) {
        const node = $createCustomAnswerNode(ids, allowedInput, promptMethod);
        return {
            node
        };
    }
    //TURBOPACK unreachable
    ;
}
class CustomAnswerNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __ids;
    __promptMethod;
    __allowedInput;
    __format;
    static getType() {
        return 'custom-answer';
    }
    static clone(node) {
        return new CustomAnswerNode(node.__ids, node.__allowedInput, node.__promptMethod, node.__format, node.__key);
    }
    static importJSON(serializedNode) {
        const node = $createCustomAnswerNode(serializedNode.ids, serializedNode.allowedInput, serializedNode.promptMethod, serializedNode.format);
        if (serializedNode.format !== undefined) {
            node.setFormat(serializedNode.format);
        }
        return node;
    }
    exportJSON() {
        return {
            type: 'custom-answer',
            version: 1,
            ids: [
                ...this.__ids
            ],
            promptMethod: this.__promptMethod,
            allowedInput: this.__allowedInput,
            format: this.__format
        };
    }
    constructor(ids = [], allowedInput = [], promptMethod = [], format = '', key){
        super(key);
        this.__ids = ids;
        this.__promptMethod = promptMethod;
        this.__allowedInput = allowedInput;
        this.__format = format;
    }
    exportDOM() {
        const element = document.createElement('div');
        element.setAttribute('data-lexical-custom-answer', this.__ids.join(','));
        element.setAttribute('data-lexical-custom-answer-allowed-input', JSON.stringify(this.__allowedInput));
        element.setAttribute('data-lexical-custom-answer-prompt-method', JSON.stringify(this.__promptMethod));
        return {
            element
        };
    }
    createDOM(config) {
        const div = document.createElement('div');
        div.setAttribute('data-lexical-custom-answer', this.__ids.join(','));
        div.setAttribute('data-lexical-custom-answer-allowed-input', JSON.stringify(this.__allowedInput));
        div.setAttribute('data-lexical-custom-answer-prompt-method', JSON.stringify(this.__promptMethod));
        const theme = config.theme;
        const className = theme.image;
        if (className !== undefined) {
            div.className = className;
        }
        return div;
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute('data-lexical-custom-answer')) {
                    return null;
                }
                return {
                    conversion: convertCustomAnswerElement,
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
    isSelectable() {
        return true;
    }
    canBeEmpty() {
        return true;
    }
    getIds() {
        return this.__ids;
    }
    appendId(id) {
        console.log('appendId', id);
        const writable = this.getWritable();
        writable.__ids = [
            ...new Set([
                ...writable.__ids,
                id
            ])
        ];
    }
    removeIntersection(questionIDs) {
        const writable = this.getWritable();
        const idsArray = Array.isArray(questionIDs) ? questionIDs : [
            ...questionIDs
        ];
        let intersection = this.__ids.filter((x)=>{
            return !idsArray.includes(x);
        });
        // if intersection is undefined, set it to empty array
        intersection ? intersection : [];
        writable.__ids = [
            ...intersection
        ];
    }
    setids(ids) {
        const writable = this.getWritable();
        writable.__ids = [
            ...ids
        ];
    }
    mergeids(ids) {
        const writable = this.getWritable();
        writable.__ids = [
            ...writable.__ids,
            ...ids
        ];
    }
    appendQuestion(question) {
        const writable = this.getWritable();
        writable.__ids = [
            ...writable.__ids,
            question
        ];
    }
    setAllowedInput(allowedInput) {
        const writable = this.getWritable();
        writable.__allowedInput = allowedInput;
    }
    mergeAllowedInput(allowedInput) {
        const writable = this.getWritable();
        writable.__allowedInput = {
            ...writable.__allowedInput,
            ...allowedInput
        };
    }
    setPromptMethod(newPromptMethod) {
        const writable = this.getWritable();
        writable.__promptMethod = newPromptMethod;
    }
    getTextContent(_includeInert, _includeDirectionless) {
        return this.__ids;
    }
    setFormat(format) {
        const self = this.getWritable();
        self.__format = format;
        return self;
    }
    getFormat() {
        return this.__format;
    }
    decorate(_editor, config) {
        const isEditable = _editor.isEditable();
        const embedBlockTheme = config.theme.embedBlock || {};
        const className = {
            base: embedBlockTheme.base || '',
            focus: embedBlockTheme.focus || ''
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$nodes$2f$CustomAnswerNode$2f$CustomAnswerEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    ids: this.__ids,
                    allowedInput: this.__allowedInput,
                    promptMethod: this.__promptMethod
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/CustomAnswerPlugin.jsx",
                    lineNumber: 193,
                    columnNumber: 24
                }, this),
                !isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$nodes$2f$CustomAnswerNode$2f$CustomAnswerComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    ids: this.__ids,
                    allowedInput: this.__allowedInput,
                    promptMethod: this.__promptMethod
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/CustomAnswerPlugin.jsx",
                    lineNumber: 195,
                    columnNumber: 25
                }, this)
            ]
        }, void 0, true);
    }
}
function $createCustomAnswerNode(ids, allowedInput, promptMethod, format) {
    return new CustomAnswerNode(ids, allowedInput, promptMethod, format);
}
function $isCustomAnswerNode(node) {
    return node instanceof CustomAnswerNode;
}
const INSERT_CUSTOM_ANSWER_BLOCK_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('INSERT_CUSTOM_ANSWER_BLOCK_COMMAND');
function CustomAnswerPlugin() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "1fc8a5acecf5cca9a56909887502f1728925a50bbe7d7e6e17b82462e99d4062") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "1fc8a5acecf5cca9a56909887502f1728925a50bbe7d7e6e17b82462e99d4062";
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t0;
    let t1;
    if ($[1] !== editor) {
        t0 = ({
            "CustomAnswerPlugin[useEffect()]": ()=>{
                if (!editor.hasNodes([
                    CustomAnswerNode
                ])) {
                    throw new Error("CustomAnswerPlugin: CustomAnswerNode not registered on editor");
                }
                return editor.registerCommand(INSERT_CUSTOM_ANSWER_BLOCK_COMMAND, _CustomAnswerPluginUseEffectEditorRegisterCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
            }
        })["CustomAnswerPlugin[useEffect()]"];
        t1 = [
            editor
        ];
        $[1] = editor;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return null;
}
_s(CustomAnswerPlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = CustomAnswerPlugin;
function _CustomAnswerPluginUseEffectEditorRegisterCommand(payload) {
    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    let selectedCustomAnswerNode = null;
    if (selection) {
        const nodes = selection.getNodes();
        for (const node of nodes){
            if ($isCustomAnswerNode(node)) {
                selectedCustomAnswerNode = node;
                break;
            }
            let parent = node.getParent();
            while(parent){
                if ($isCustomAnswerNode(parent)) {
                    selectedCustomAnswerNode = parent;
                    break;
                }
                parent = parent.getParent();
            }
            if (selectedCustomAnswerNode) {
                break;
            }
        }
    }
    if (selectedCustomAnswerNode) {
        payload.forEach({
            "CustomAnswerPlugin[useEffect() > editor.registerCommand() > payload.forEach()]": (id)=>{
                selectedCustomAnswerNode.appendId(id);
            }
        }["CustomAnswerPlugin[useEffect() > editor.registerCommand() > payload.forEach()]"]);
    } else {
        const customAnswerNode = $createCustomAnswerNode(payload);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(customAnswerNode);
    }
    return true;
}
var _c;
__turbopack_context__.k.register(_c, "CustomAnswerPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/YouTubePlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createYouTubeNode",
    ()=>$createYouTubeNode,
    "$isYouTubeNode",
    ()=>$isYouTubeNode,
    "INSERT_YOUTUBE_COMMAND",
    ()=>INSERT_YOUTUBE_COMMAND,
    "YouTubeNode",
    ()=>YouTubeNode,
    "default",
    ()=>YouTubePlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview YouTubePlugin - Embeds YouTube videos in the editor.
 * 
 * This plugin provides YouTube video embedding with privacy-enhanced mode,
 * responsive sizing, and alignment controls.
 * 
 * @module YouTubePlugin
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalBlockWithAlignableContents$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalBlockWithAlignableContents.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalDecoratorBlockNode.dev.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
/**
 * YouTubeComponent - Renders an embedded YouTube video iframe.
 * 
 * @param {Object} props - Component props
 * @param {string} props.className - CSS class name
 * @param {string} props.format - format/alignment
 * @param {string} props.nodeKey - Lexical node key
 * @param {string} props.videoID - YouTube video identifier
 * @returns {JSX.Element} YouTube iframe component
 */ const YouTubeComponent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](function YouTubeComponent(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "922990943316c42d9ae0315d07db176864cf947816242ffc69bc2efa504c7c80") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "922990943316c42d9ae0315d07db176864cf947816242ffc69bc2efa504c7c80";
    }
    const { className, format, nodeKey, videoID } = t0;
    const t1 = `https://www.youtube-nocookie.com/embed/${videoID}`;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            maxWidth: "100%",
            width: "100%",
            height: "auto",
            aspectRatio: "16 / 9"
        };
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    let t3;
    if ($[2] !== t1) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
            width: "560",
            height: "315",
            src: t1,
            frameBorder: "0",
            allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
            allowFullScreen: true,
            title: "YouTube video",
            style: t2
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/YouTubePlugin.jsx",
            lineNumber: 58,
            columnNumber: 10
        }, this);
        $[2] = t1;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    let t4;
    if ($[4] !== className || $[5] !== format || $[6] !== nodeKey || $[7] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalBlockWithAlignableContents$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BlockWithAlignableContents"], {
            className: className,
            format: format,
            nodeKey: nodeKey,
            children: t3
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/YouTubePlugin.jsx",
            lineNumber: 66,
            columnNumber: 10
        }, this);
        $[4] = className;
        $[5] = format;
        $[6] = nodeKey;
        $[7] = t3;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    return t4;
});
_c = YouTubeComponent;
/**
 * Converts a DOM element into a YouTubeNode.
 * 
 * @param {HTMLElement} domNode - DOM element with YouTube video ID
 * @returns {{node: YouTubeNode} | null} Created node or null
 */ function convertYoutubeElement(domNode) {
    const videoID = domNode.getAttribute('data-lexical-youtube');
    if (videoID) {
        const node = $createYouTubeNode(videoID);
        return {
            node
        };
    }
    return null;
}
class YouTubeNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorBlockNode"] {
    __id;
    static getType() {
        return 'youtube';
    }
    static clone(node) {
        return new YouTubeNode(node.__id, node.__format, node.__key);
    }
    static importJSON(serializedNode) {
        const node = $createYouTubeNode(serializedNode.videoID);
        node.setFormat(serializedNode.format);
        return node;
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            type: 'youtube',
            version: 1,
            videoID: this.__id
        };
    }
    constructor(id, format, key){
        super(key);
        this.__id = id;
    }
    exportDOM() {
        const element = document.createElement('iframe');
        element.setAttribute('data-lexical-youtube', this.__id);
        element.setAttribute('width', '560');
        element.setAttribute('height', '315');
        element.setAttribute('src', `https://www.youtube-nocookie.com/embed/${this.__id}`);
        element.setAttribute('frameborder', '0');
        element.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture');
        element.setAttribute('allowfullscreen', 'true');
        element.setAttribute('title', 'YouTube video');
        return {
            element
        };
    }
    static importDOM() {
        return {
            iframe: (domNode)=>{
                if (!domNode.hasAttribute('data-lexical-youtube')) {
                    return null;
                }
                return {
                    conversion: convertYoutubeElement,
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
    canBeEmpty() {
        return true;
    }
    getId() {
        return this.__id;
    }
    getTextContent(_includeInert, _includeDirectionless) {
        return `https://www.youtube.com/watch?v=${this.__id}`;
    }
    decorate(_editor, config) {
        const embedBlockTheme = config.theme.embedBlock || {};
        const className = {
            base: embedBlockTheme.base || '',
            focus: embedBlockTheme.focus || ''
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(YouTubeComponent, {
            className: className,
            format: this.__format,
            nodeKey: this.getKey(),
            videoID: this.__id
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/YouTubePlugin.jsx",
            lineNumber: 177,
            columnNumber: 12
        }, this);
    }
}
function $createYouTubeNode(videoID) {
    return new YouTubeNode(videoID);
}
function $isYouTubeNode(node) {
    return node instanceof YouTubeNode;
}
const INSERT_YOUTUBE_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('INSERT_YOUTUBE_COMMAND');
function YouTubePlugin() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "922990943316c42d9ae0315d07db176864cf947816242ffc69bc2efa504c7c80") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "922990943316c42d9ae0315d07db176864cf947816242ffc69bc2efa504c7c80";
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t0;
    let t1;
    if ($[1] !== editor) {
        t0 = ({
            "YouTubePlugin[useEffect()]": ()=>{
                if (!editor.hasNodes([
                    YouTubeNode
                ])) {
                    throw new Error("YouTubePlugin: YouTubeNode not registered on editor");
                }
                return editor.registerCommand(INSERT_YOUTUBE_COMMAND, _YouTubePluginUseEffectEditorRegisterCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
            }
        })["YouTubePlugin[useEffect()]"];
        t1 = [
            editor
        ];
        $[1] = editor;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return null;
}
_s(YouTubePlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c1 = YouTubePlugin;
function _YouTubePluginUseEffectEditorRegisterCommand(payload) {
    const youTubeNode = $createYouTubeNode(payload);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(youTubeNode);
    return true;
}
var _c, _c1;
__turbopack_context__.k.register(_c, "YouTubeComponent");
__turbopack_context__.k.register(_c1, "YouTubePlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createWordBlockNode",
    ()=>$createWordBlockNode,
    "$isWordBlockNode",
    ()=>$isWordBlockNode,
    "INSERT_WORD_BLOCK_COMMAND",
    ()=>INSERT_WORD_BLOCK_COMMAND,
    "WordBlockNode",
    ()=>WordBlockNode,
    "default",
    ()=>WordBlockPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview WordBlockPlugin - Displays vocabulary word information in a card.
 * @module WordBlockPlugin
 *
 * Creates an interactive word block that displays a vocabulary word's phrase,
 * pronunciation, and definition from the dictionary context.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/useLexicalNodeSelection.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalBlockWithAlignableContents$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalBlockWithAlignableContents.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalDecoratorBlockNode.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript) <export default as CardContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RecordVoiceOver$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RecordVoiceOver.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$sanitizeHtml$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/sanitizeHtml.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
/**
 * WordBlockComponent - Displays word information in a block.
 *
 * @param {Object} props - Component props
 * @param {string} props.className - CSS className for styling
 * @param {string} props.format - Block alignment format
 * @param {string} props.nodeKey - Lexical node key
 * @param {string} props.wordID - Dictionary word identifier
 * @returns {JSX.Element} Word block component
 */ const WordBlockComponent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](_s(function WordBlockComponent({ className, format, nodeKey, wordID }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.shared");
    const { wordMapId: dictionary } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const word = dictionary[wordID];
    const [signedAudioUrl, setSignedAudioUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [audioLoading, setAudioLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Sign the audio URL when word changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WordBlockComponent.WordBlockComponent.useEffect": ()=>{
            const signAudioUrl = {
                "WordBlockComponent.WordBlockComponent.useEffect.signAudioUrl": async ()=>{
                    if (word?.audio && word.audio[0]) {
                        setAudioLoading(true);
                        try {
                            const url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(word.audio[0]);
                            setSignedAudioUrl(url);
                        } catch (error) {
                            console.error("Error signing word audio URL:", error);
                            setSignedAudioUrl(null);
                        } finally{
                            setAudioLoading(false);
                        }
                    } else {
                        setSignedAudioUrl(null);
                        setAudioLoading(false);
                    }
                }
            }["WordBlockComponent.WordBlockComponent.useEffect.signAudioUrl"];
            signAudioUrl();
        }
    }["WordBlockComponent.WordBlockComponent.useEffect"], [
        word?.audio,
        word?.identityId
    ]);
    if (!word) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalBlockWithAlignableContents$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BlockWithAlignableContents"], {
            className: className,
            format: format,
            nodeKey: nodeKey,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                variant: "outlined",
                sx: {
                    my: 2,
                    bgcolor: "#fff3e0",
                    borderColor: "#ff9800",
                    borderWidth: 2
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "error",
                        children: t("wordBlockPlugin.wordNotFound", {
                            wordID
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                        lineNumber: 80,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                    lineNumber: 79,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                lineNumber: 73,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
            lineNumber: 72,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalBlockWithAlignableContents$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BlockWithAlignableContents"], {
        className: className,
        format: format,
        nodeKey: nodeKey,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
            variant: "outlined",
            sx: {
                my: 2,
                bgcolor: (theme)=>theme.palette.mode === "dark" ? "grey.900" : "grey.100",
                border: "none",
                borderRadius: 2,
                boxShadow: (theme_0)=>theme_0.palette.mode === "dark" ? "0 1px 3px rgba(0,0,0,0.4)" : "0 1px 3px rgba(0,0,0,0.12)",
                transition: "all 0.2s ease",
                userSelect: "none",
                cursor: "default",
                "& *": {
                    userSelect: "none"
                }
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: "flex",
                        alignItems: "flex-start",
                        gap: 2
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            flex: 1
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 1,
                                    mb: 1
                                },
                                children: word.rubyTags ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "h4",
                                    component: "ruby",
                                    sx: {
                                        fontWeight: 700,
                                        color: "primary.main",
                                        fontFamily: word?.phrase?.match(/[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]/) ? '"Noto Sans JP", sans-serif' : "inherit",
                                        "& rt": {
                                            fontWeight: 400,
                                            fontSize: "0.5em",
                                            color: "text.secondary"
                                        }
                                    },
                                    dangerouslySetInnerHTML: {
                                        __html: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$sanitizeHtml$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sanitizeInlineHtml"])(word.rubyTags)
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                    lineNumber: 119,
                                    columnNumber: 34
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "h4",
                                    component: "div",
                                    sx: {
                                        fontWeight: 700,
                                        color: "primary.main",
                                        fontFamily: word?.phrase?.match(/[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]/) ? '"Noto Sans JP", sans-serif' : "inherit"
                                    },
                                    children: word.phrase
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                    lineNumber: 130,
                                    columnNumber: 23
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                lineNumber: 113,
                                columnNumber: 15
                            }, this),
                            word.audio && word.audio.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    mb: 1.5
                                },
                                children: audioLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    sx: {
                                        opacity: 0.6
                                    },
                                    children: t("wordBlockPlugin.loadingAudio")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                    lineNumber: 143,
                                    columnNumber: 35
                                }, this) : signedAudioUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    audioUrl: signedAudioUrl,
                                    title: null,
                                    enableRecording: false
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                    lineNumber: 147,
                                    columnNumber: 54
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    sx: {
                                        opacity: 0.6,
                                        fontStyle: "italic"
                                    },
                                    children: t("wordBlockPlugin.audioUnavailable")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                    lineNumber: 147,
                                    columnNumber: 143
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                lineNumber: 140,
                                columnNumber: 55
                            }, this),
                            word.pronunciation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 1,
                                    mb: 1.5
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RecordVoiceOver$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        sx: {
                                            fontSize: 18,
                                            color: "text.secondary"
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                        lineNumber: 162,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "body1",
                                        sx: {
                                            color: "text.secondary",
                                            fontStyle: "italic",
                                            fontFamily: "monospace"
                                        },
                                        children: [
                                            "/",
                                            word.pronunciation,
                                            "/"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                        lineNumber: 166,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                lineNumber: 156,
                                columnNumber: 38
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body1",
                                sx: {
                                    color: "text.primary",
                                    lineHeight: 1.6,
                                    mb: 1
                                },
                                children: word.definition
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                lineNumber: 176,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    gap: 0.5,
                                    mt: 2,
                                    flexWrap: "wrap"
                                },
                                children: [
                                    word.partOfSpeech && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                        label: word.partOfSpeech,
                                        size: "small",
                                        color: "primary",
                                        variant: "outlined"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                        lineNumber: 191,
                                        columnNumber: 39
                                    }, this),
                                    word.context && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                        label: word.context,
                                        size: "small",
                                        variant: "outlined"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                        lineNumber: 192,
                                        columnNumber: 34
                                    }, this),
                                    word.level && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                        label: `Level: ${word.level}`,
                                        size: "small",
                                        color: "secondary",
                                        variant: "outlined"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                        lineNumber: 193,
                                        columnNumber: 32
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                                lineNumber: 185,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                        lineNumber: 109,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                    lineNumber: 104,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                lineNumber: 103,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
            lineNumber: 90,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
        lineNumber: 89,
        columnNumber: 10
    }, this);
}, "2TRiuTDL/KWbHW5927J9PJWGN0o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
}));
_c = WordBlockComponent;
/**
 * WordBlockEditor - Edit-mode wrapper with selection and keyboard controls.
 */ const WordBlockEditor = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](_s1(function WordBlockEditor(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(31);
    if ($[0] !== "9a6ced3b876d96aac74c882f779db04a60a9b31de0a0e4d6273adb9c9afd048c") {
        for(let $i = 0; $i < 31; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9a6ced3b876d96aac74c882f779db04a60a9b31de0a0e4d6273adb9c9afd048c";
    }
    const { className, format, nodeKey, wordID } = t0;
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isSelected, setSelected, clearSelection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"])(nodeKey);
    let t1;
    if ($[1] !== editor || $[2] !== isSelected || $[3] !== nodeKey) {
        t1 = ({
            "WordBlockEditor[onDelete]": (payload)=>{
                if (isSelected && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])())) {
                    payload.preventDefault();
                    editor.update({
                        "WordBlockEditor[onDelete > editor.update()]": ()=>{
                            const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                            if ($isWordBlockNode(node)) {
                                node.remove();
                            }
                        }
                    }["WordBlockEditor[onDelete > editor.update()]"]);
                    return true;
                }
                return false;
            }
        })["WordBlockEditor[onDelete]"];
        $[1] = editor;
        $[2] = isSelected;
        $[3] = nodeKey;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    const onDelete = t1;
    let t2;
    if ($[5] !== clearSelection || $[6] !== isSelected) {
        t2 = ({
            "WordBlockEditor[onEscape]": (payload_0)=>{
                if (isSelected) {
                    payload_0.preventDefault();
                    clearSelection();
                    return true;
                }
                return false;
            }
        })["WordBlockEditor[onEscape]"];
        $[5] = clearSelection;
        $[6] = isSelected;
        $[7] = t2;
    } else {
        t2 = $[7];
    }
    const onEscape = t2;
    let t3;
    if ($[8] !== editor || $[9] !== isSelected || $[10] !== nodeKey) {
        t3 = ({
            "WordBlockEditor[onEnter]": (payload_1)=>{
                if (isSelected && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])())) {
                    payload_1.preventDefault();
                    editor.update({
                        "WordBlockEditor[onEnter > editor.update()]": ()=>{
                            const node_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                            if ($isWordBlockNode(node_0)) {
                                const paragraph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])();
                                node_0.insertAfter(paragraph);
                                paragraph.select();
                            }
                        }
                    }["WordBlockEditor[onEnter > editor.update()]"]);
                    return true;
                }
                return false;
            }
        })["WordBlockEditor[onEnter]"];
        $[8] = editor;
        $[9] = isSelected;
        $[10] = nodeKey;
        $[11] = t3;
    } else {
        t3 = $[11];
    }
    const onEnter = t3;
    let t4;
    let t5;
    if ($[12] !== clearSelection || $[13] !== editor || $[14] !== isSelected || $[15] !== onDelete || $[16] !== onEnter || $[17] !== onEscape || $[18] !== setSelected) {
        t4 = ({
            "WordBlockEditor[useEffect()]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CLICK_COMMAND"], {
                    "WordBlockEditor[useEffect() > editor.registerCommand()]": (payload_2)=>{
                        const event = payload_2;
                        if (containerRef.current && containerRef.current.contains(event.target)) {
                            if (event.shiftKey) {
                                setSelected(!isSelected);
                            } else {
                                clearSelection();
                                setSelected(true);
                            }
                            return true;
                        }
                        return false;
                    }
                }["WordBlockEditor[useEffect() > editor.registerCommand()]"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_DELETE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_BACKSPACE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_ESCAPE_COMMAND"], onEscape, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_ENTER_COMMAND"], onEnter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]))
        })["WordBlockEditor[useEffect()]"];
        t5 = [
            editor,
            isSelected,
            onDelete,
            onEscape,
            onEnter,
            setSelected,
            clearSelection
        ];
        $[12] = clearSelection;
        $[13] = editor;
        $[14] = isSelected;
        $[15] = onDelete;
        $[16] = onEnter;
        $[17] = onEscape;
        $[18] = setSelected;
        $[19] = t4;
        $[20] = t5;
    } else {
        t4 = $[19];
        t5 = $[20];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t4, t5);
    const t6 = isSelected ? "2px solid var(--mui-palette-primary-main, #1976d2)" : "1px solid transparent";
    let t7;
    if ($[21] !== t6) {
        t7 = {
            border: t6,
            borderRadius: 8,
            transition: "border 0.2s ease"
        };
        $[21] = t6;
        $[22] = t7;
    } else {
        t7 = $[22];
    }
    let t8;
    if ($[23] !== className || $[24] !== format || $[25] !== nodeKey || $[26] !== wordID) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WordBlockComponent, {
            className: className,
            format: format,
            nodeKey: nodeKey,
            wordID: wordID
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
            lineNumber: 347,
            columnNumber: 10
        }, this);
        $[23] = className;
        $[24] = format;
        $[25] = nodeKey;
        $[26] = wordID;
        $[27] = t8;
    } else {
        t8 = $[27];
    }
    let t9;
    if ($[28] !== t7 || $[29] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: containerRef,
            style: t7,
            children: t8
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
            lineNumber: 358,
            columnNumber: 10
        }, this);
        $[28] = t7;
        $[29] = t8;
        $[30] = t9;
    } else {
        t9 = $[30];
    }
    return t9;
}, "9zOY7h24IQ0rqoMN1+1iptobTOA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"]
    ];
}));
_c1 = WordBlockEditor;
function convertYoutubeElement(domNode) {
    const wordID = domNode.getAttribute("data-lexical-word-block");
    if (wordID) {
        /**
     * WordBlockNode - Lexical decorator block node for displaying vocabulary words.
     *
     * @class
     * @extends {DecoratorBlockNode}
     */ const node = $createWordBlockNode(wordID);
        return {
            node
        };
    }
    return null;
}
class WordBlockNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorBlockNode"] {
    __id;
    static getType() {
        return "word-block";
    }
    static clone(node) {
        return new WordBlockNode(node.__id, node.__format, node.__key);
    }
    static importJSON(serializedNode) {
        const node = $createWordBlockNode(serializedNode.wordID);
        node.setFormat(serializedNode.format);
        return node;
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            type: "word-block",
            version: 1,
            wordID: this.__id
        };
    }
    constructor(id, format, key){
        super(key);
        this.__id = id;
    }
    exportDOM() {
        const element = document.createElement("div");
        element.setAttribute("data-lexical-word-block", this.__id);
        return {
            element
        };
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute("data-lexical-word-block")) {
                    return null;
                }
                return {
                    conversion: convertYoutubeElement,
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    getId() {
        return this.__id;
    }
    getTextContent(_includeInert, _includeDirectionless) {
        return this.__id;
    }
    decorate(_editor, config) {
        const embedBlockTheme = config.theme.embedBlock || {};
        const className = {
            base: embedBlockTheme.base || "",
            focus: embedBlockTheme.focus || ""
        };
        const isEditable = _editor.isEditable();
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WordBlockEditor, {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    wordID: this.__id
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                    lineNumber: 445,
                    columnNumber: 24
                }, this),
                !isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WordBlockComponent, {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    wordID: this.__id
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx",
                    lineNumber: 446,
                    columnNumber: 25
                }, this)
            ]
        }, void 0, true);
    }
}
function $createWordBlockNode(wordID) {
    return new WordBlockNode(wordID);
}
function $isWordBlockNode(node) {
    return node instanceof WordBlockNode;
}
const INSERT_WORD_BLOCK_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("INSERT_WORD_BLOCK_COMMAND");
function WordBlockPlugin() {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "9a6ced3b876d96aac74c882f779db04a60a9b31de0a0e4d6273adb9c9afd048c") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9a6ced3b876d96aac74c882f779db04a60a9b31de0a0e4d6273adb9c9afd048c";
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t0;
    let t1;
    if ($[1] !== editor) {
        t0 = ({
            "WordBlockPlugin[useEffect()]": ()=>{
                if (!editor.hasNodes([
                    WordBlockNode
                ])) {
                    throw new Error("WordBlockPlugin: WordBlockNode not registered on editor");
                }
                return editor.registerCommand(INSERT_WORD_BLOCK_COMMAND, _WordBlockPluginUseEffectEditorRegisterCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
            }
        })["WordBlockPlugin[useEffect()]"];
        t1 = [
            editor
        ];
        $[1] = editor;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return null;
}
_s2(WordBlockPlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c2 = WordBlockPlugin;
function _WordBlockPluginUseEffectEditorRegisterCommand(payload) {
    const wordBlockNode = $createWordBlockNode(payload);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(wordBlockNode);
    return true;
}
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "WordBlockComponent");
__turbopack_context__.k.register(_c1, "WordBlockEditor");
__turbopack_context__.k.register(_c2, "WordBlockPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/AutocompletePlugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AutocompletePlugin,
    "uuid",
    ()=>uuid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview AutocompletePlugin - Word autocomplete suggestions.
 * @module AutocompletePlugin
 * 
 * Provides autocomplete suggestions as users type, with keyboard and
 * swipe gesture support for accepting suggestions.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/selection/LexicalSelection.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$SharedAutocompleteContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/context/SharedAutocompleteContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AutocompleteNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AutocompleteNode.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$utils$2f$swipe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/utils/swipe.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
const uuid = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 5);
function $search(selection) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(selection) || !selection.isCollapsed()) {
        return [
            false,
            ''
        ];
    }
    const node = selection.getNodes()[0];
    const anchor = selection.anchor;
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(node) || !node.isSimpleText() || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$isAtNodeEnd"])(anchor)) {
        return [
            false,
            ''
        ];
    }
    const word = [];
    const text = node.getTextContent();
    let i = node.getTextContentSize();
    let c;
    while(i-- && i >= 0 && (c = text[i]) !== ' '){
        word.push(c);
    }
    if (word.length === 0) {
        return [
            false,
            ''
        ];
    }
    return [
        true,
        word.reverse().join('')
    ];
}
function useQuery() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "61fff55191a537e9d85e9121d4b2f313af9a185b8d77c127ff411ee69e339e8b") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "61fff55191a537e9d85e9121d4b2f313af9a185b8d77c127ff411ee69e339e8b";
    }
    return _temp;
}
function _temp(searchText) {
    const server = new AutocompleteServer();
    const response = server.query(searchText);
    return response;
}
function AutocompletePlugin() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "61fff55191a537e9d85e9121d4b2f313af9a185b8d77c127ff411ee69e339e8b") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "61fff55191a537e9d85e9121d4b2f313af9a185b8d77c127ff411ee69e339e8b";
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const { setSuggestion } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$SharedAutocompleteContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const query = useQuery();
    let t0;
    let t1;
    if ($[1] !== editor || $[2] !== query || $[3] !== setSuggestion) {
        t0 = ({
            "AutocompletePlugin[useEffect()]": ()=>{
                let autocompleteNodeKey = null;
                let lastMatch = null;
                let lastSuggestion = null;
                let lastData = null;
                let searchPromise = null;
                const $clearSuggestion = function $clearSuggestion() {
                    const autocompleteNode = autocompleteNodeKey !== null ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(autocompleteNodeKey) : null;
                    if (autocompleteNode !== null && autocompleteNode.isAttached()) {
                        autocompleteNode.remove();
                        autocompleteNodeKey = null;
                    }
                    if (searchPromise !== null) {
                        searchPromise.dismiss();
                        searchPromise = null;
                    }
                    lastMatch = null;
                    lastSuggestion = null;
                    lastData = null;
                    setSuggestion(null);
                };
                const updateAsyncSuggestion = function updateAsyncSuggestion(refSearchPromise, newSuggestion) {
                    if (searchPromise !== refSearchPromise || newSuggestion === null) {
                        return;
                    }
                    editor.update({
                        "AutocompletePlugin[useEffect() > updateAsyncSuggestion > editor.update()]": ()=>{
                            const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
                            const [hasMatch, match] = $search(selection);
                            if (!hasMatch || match !== lastMatch || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(selection)) {
                                return;
                            }
                            const selectionCopy = selection.clone();
                            const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AutocompleteNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createAutocompleteNode"])(uuid);
                            autocompleteNodeKey = node.getKey();
                            selection.insertNodes([
                                node
                            ]);
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$setSelection"])(selectionCopy);
                            lastSuggestion = newSuggestion;
                            setSuggestion(newSuggestion);
                            console.log("setSuggestion(newSuggestion)", newSuggestion);
                        }
                    }["AutocompletePlugin[useEffect() > updateAsyncSuggestion > editor.update()]"], {
                        discrete: true
                    });
                };
                const handleAutocompleteNodeTransform = function handleAutocompleteNodeTransform(node_0) {
                    const key = node_0.getKey();
                    console.log("handleAutocompleteNodeTransform", node_0);
                    if (node_0.__uuid === uuid && key !== autocompleteNodeKey) {
                        $clearSuggestion();
                    }
                };
                const handleUpdate = function handleUpdate(t2) {
                    const { tags } = t2;
                    if (tags && (tags.has("skip-save") || tags.has("historic") || tags.has("history-push") || tags.has("history-merge"))) {
                        return;
                    }
                    editor.getEditorState().read({
                        "AutocompletePlugin[useEffect() > handleUpdate > (anonymous)()]": ()=>{
                            const selection_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
                            const [hasMatch_0, match_0] = $search(selection_0);
                            if (!hasMatch_0) {
                                if (autocompleteNodeKey !== null || lastMatch !== null) {
                                    editor.update({
                                        "AutocompletePlugin[useEffect() > handleUpdate > (anonymous)() > editor.update()]": ()=>{
                                            $clearSuggestion();
                                        }
                                    }["AutocompletePlugin[useEffect() > handleUpdate > (anonymous)() > editor.update()]"], {
                                        discrete: true
                                    });
                                }
                                return;
                            }
                            if (match_0 === lastMatch) {
                                return;
                            }
                            editor.update({
                                "AutocompletePlugin[useEffect() > handleUpdate > (anonymous)() > editor.update()]": ()=>{
                                    $clearSuggestion();
                                }
                            }["AutocompletePlugin[useEffect() > handleUpdate > (anonymous)() > editor.update()]"], {
                                discrete: true
                            });
                            searchPromise = query(match_0);
                            searchPromise.promise.then({
                                "AutocompletePlugin[useEffect() > handleUpdate > (anonymous)() > searchPromise.promise.then()]": (newSuggestion_0)=>{
                                    if (searchPromise !== null) {
                                        updateAsyncSuggestion(searchPromise, newSuggestion_0);
                                    }
                                }
                            }["AutocompletePlugin[useEffect() > handleUpdate > (anonymous)() > searchPromise.promise.then()]"]).catch(_AutocompletePluginUseEffectHandleUpdateAnonymousAnonymous);
                            lastMatch = match_0;
                        }
                    }["AutocompletePlugin[useEffect() > handleUpdate > (anonymous)()]"]);
                };
                const $handleAutocompleteIntent = function $handleAutocompleteIntent() {
                    const { autocompleteChunk } = lastSuggestion || {};
                    if (autocompleteChunk === null || autocompleteNodeKey === null) {
                        return false;
                    }
                    const autocompleteNode_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(autocompleteNodeKey);
                    if (autocompleteNode_0 === null) {
                        return false;
                    }
                    const textNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(autocompleteChunk);
                    autocompleteNode_0.replace(textNode);
                    textNode.selectNext();
                    $clearSuggestion();
                    return true;
                };
                const $handleKeypressCommand = function $handleKeypressCommand(e_0) {
                    if ($handleAutocompleteIntent()) {
                        e_0.preventDefault();
                        return true;
                    }
                    return false;
                };
                const handleSwipeRight = function handleSwipeRight(_force, e_1) {
                    editor.update({
                        "AutocompletePlugin[useEffect() > handleSwipeRight > editor.update()]": ()=>{
                            if ($handleAutocompleteIntent()) {
                                e_1.preventDefault();
                            }
                        }
                    }["AutocompletePlugin[useEffect() > handleSwipeRight > editor.update()]"], {
                        tag: "history-merge"
                    });
                };
                const unmountSuggestion = function unmountSuggestion() {
                    editor.update({
                        "AutocompletePlugin[useEffect() > unmountSuggestion > editor.update()]": ()=>{
                            $clearSuggestion();
                        }
                    }["AutocompletePlugin[useEffect() > unmountSuggestion > editor.update()]"], {
                        tag: "history-merge"
                    });
                };
                const rootElem = editor.getRootElement();
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(editor.registerNodeTransform(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AutocompleteNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AutocompleteNode"], handleAutocompleteNodeTransform), editor.registerUpdateListener(handleUpdate), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_TAB_COMMAND"], $handleKeypressCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_ARROW_RIGHT_COMMAND"], $handleKeypressCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), ...rootElem !== null ? [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$utils$2f$swipe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addSwipeRightListener"])(rootElem, handleSwipeRight)
                ] : [], unmountSuggestion);
            }
        })["AutocompletePlugin[useEffect()]"];
        t1 = [
            editor,
            query,
            setSuggestion
        ];
        $[1] = editor;
        $[2] = query;
        $[3] = setSuggestion;
        $[4] = t0;
        $[5] = t1;
    } else {
        t0 = $[4];
        t1 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return null;
}
_s(AutocompletePlugin, "lDWfisaE/N+RolLaRx0ZDcydjy0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        useQuery
    ];
});
_c = AutocompletePlugin;
function _AutocompletePluginUseEffectHandleUpdateAnonymousAnonymous(e) {
    if (e !== "Dismissed") {
        console.error(e);
    }
}
class AutocompleteServer {
    DATABASE = DICTIONARY;
    LATENCY = 200;
    query = (searchText)=>{
        let isDismissed = false;
        const dismiss = ()=>{
            isDismissed = true;
        };
        const promise = new Promise((resolve, reject)=>{
            setTimeout(()=>{
                if (isDismissed) {
                    return reject('Dismissed');
                }
                const searchTextLength = searchText.length;
                if (searchText === '' || searchTextLength < 4) {
                    return resolve(null);
                }
                const char0 = searchText.charCodeAt(0);
                const isCapitalized = char0 >= 65 && char0 <= 90;
                const caseInsensitiveSearchText = isCapitalized ? String.fromCharCode(char0 + 32) + searchText.substring(1) : searchText;
                const match = this.DATABASE.find((dictionaryWord)=>dictionaryWord.startsWith(caseInsensitiveSearchText) ?? null);
                if (match === undefined) {
                    return resolve(null);
                }
                const matchCapitalized = isCapitalized ? String.fromCharCode(match.charCodeAt(0) - 32) + match.substring(1) : match;
                const autocompleteChunk = matchCapitalized.substring(searchTextLength);
                if (autocompleteChunk === '') {
                    return resolve(null);
                }
                return resolve({
                    autocompleteChunk
                });
            }, this.LATENCY);
        });
        return {
            dismiss,
            promise
        };
    };
}
const DICTIONARY = [
    'information',
    'available',
    'copyright'
];
var _c;
__turbopack_context__.k.register(_c, "AutocompletePlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/CustomAIPlugin.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createCustomAINode",
    ()=>$createCustomAINode,
    "$isCustomAINode",
    ()=>$isCustomAINode,
    "CustomAINode",
    ()=>CustomAINode,
    "INSERT_CUSTOM_AI_BLOCK_COMMAND",
    ()=>INSERT_CUSTOM_AI_BLOCK_COMMAND,
    "default",
    ()=>CustomAIPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview CustomAIPlugin - Creates AI-graded exercises with security guardrails.
 *
 * This plugin provides instructor-customizable AI-graded exercises where:
 * - Instructors set grading criteria and choose input modes (text/audio/image/drawing)
 * - Students submit answers through the configured input mode
 * - AI grades submissions with an immutable, secure system prompt
 * - The UI interface is non-customizable to prevent security bypass
 *
 * @module CustomAIPlugin
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
const CustomAIEditor = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/src/components/Editor3/nodes/CustomAINode/CustomAIEditor.tsx [app-client] (ecmascript, async loader)"));
_c = CustomAIEditor;
const CustomAIComponent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/src/components/Editor3/nodes/CustomAINode/CustomAIComponent.tsx [app-client] (ecmascript, async loader)"));
_c1 = CustomAIComponent;
function convertCustomAIElement(domNode) {
    const idsAttr = domNode.getAttribute("data-lexical-custom-ai");
    if (!idsAttr) return null;
    const ids = idsAttr.split(",").filter(Boolean);
    const inputMode = domNode.getAttribute("data-lexical-custom-ai-input-mode") || "text";
    const criteria = domNode.getAttribute("data-lexical-custom-ai-criteria") || "";
    const allowedInput = (()=>{
        try {
            return JSON.parse(domNode.getAttribute("data-lexical-custom-ai-allowed-input") || "[]");
        } catch  {
            return [
                "text"
            ];
        }
    })();
    const node = $createCustomAINode(ids, inputMode, criteria, allowedInput);
    return {
        node
    };
}
class CustomAINode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __ids;
    __inputMode;
    __criteria;
    __allowedInput;
    __format;
    static getType() {
        return "custom-ai";
    }
    static clone(node) {
        return new CustomAINode(node.__ids, node.__inputMode, node.__criteria, node.__allowedInput, node.__format, node.__key);
    }
    static importJSON(serializedNode) {
        const node = $createCustomAINode(serializedNode.ids, serializedNode.inputMode, serializedNode.criteria, serializedNode.allowedInput, serializedNode.format);
        return node;
    }
    exportJSON() {
        return {
            type: "custom-ai",
            version: 1,
            ids: [
                ...this.__ids
            ],
            inputMode: this.__inputMode,
            criteria: this.__criteria,
            allowedInput: [
                ...this.__allowedInput
            ],
            format: this.__format
        };
    }
    constructor(ids = [], inputMode = "text", criteria = "", allowedInput = [
        "text"
    ], format = "", key){
        super(key);
        this.__ids = ids;
        this.__inputMode = inputMode;
        this.__criteria = criteria;
        this.__allowedInput = allowedInput;
        this.__format = format;
    }
    exportDOM() {
        const element = document.createElement("div");
        element.setAttribute("data-lexical-custom-ai", this.__ids.join(","));
        element.setAttribute("data-lexical-custom-ai-input-mode", this.__inputMode);
        element.setAttribute("data-lexical-custom-ai-criteria", this.__criteria);
        element.setAttribute("data-lexical-custom-ai-allowed-input", JSON.stringify(this.__allowedInput));
        return {
            element
        };
    }
    createDOM() {
        const div = document.createElement("div");
        div.setAttribute("data-lexical-custom-ai", this.__ids.join(","));
        div.setAttribute("data-lexical-custom-ai-input-mode", this.__inputMode);
        div.setAttribute("data-lexical-custom-ai-criteria", this.__criteria);
        div.setAttribute("data-lexical-custom-ai-allowed-input", JSON.stringify(this.__allowedInput));
        return div;
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute("data-lexical-custom-ai")) {
                    return null;
                }
                return {
                    conversion: convertCustomAIElement,
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
    isSelectable() {
        return true;
    }
    canBeEmpty() {
        return true;
    }
    getIds() {
        return this.__ids;
    }
    appendId(id) {
        const writable = this.getWritable();
        writable.__ids = [
            ...new Set([
                ...writable.__ids,
                id
            ])
        ];
    }
    removeId(id) {
        const writable = this.getWritable();
        writable.__ids = writable.__ids.filter((i)=>i !== id);
    }
    setIds(ids) {
        const writable = this.getWritable();
        writable.__ids = [
            ...ids
        ];
    }
    getInputMode() {
        return this.__inputMode;
    }
    setInputMode(mode) {
        const writable = this.getWritable();
        writable.__inputMode = mode;
    }
    getCriteria() {
        return this.__criteria;
    }
    setCriteria(criteria) {
        const writable = this.getWritable();
        writable.__criteria = criteria;
    }
    getAllowedInput() {
        return this.__allowedInput;
    }
    setAllowedInput(allowedInput) {
        const writable = this.getWritable();
        writable.__allowedInput = [
            ...allowedInput
        ];
    }
    setFormat(format) {
        const self = this.getWritable();
        self.__format = format;
    }
    getFormat() {
        return this.__format;
    }
    getTextContent() {
        return this.__ids.join(",");
    }
    decorate(_editor, config) {
        const isEditable = _editor.isEditable();
        const embedBlockTheme = config.theme.embedBlock || {};
        const className = {
            base: embedBlockTheme.base || "",
            focus: embedBlockTheme.focus || ""
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: null,
            children: [
                isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CustomAIEditor, {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    ids: this.__ids,
                    inputMode: this.__inputMode,
                    criteria: this.__criteria,
                    allowedInput: this.__allowedInput
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/CustomAIPlugin.tsx",
                    lineNumber: 202,
                    columnNumber: 24
                }, this),
                !isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CustomAIComponent, {
                    className: className,
                    format: this.__format,
                    nodeKey: this.getKey(),
                    ids: this.__ids,
                    inputMode: this.__inputMode,
                    criteria: this.__criteria,
                    allowedInput: this.__allowedInput
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/CustomAIPlugin.tsx",
                    lineNumber: 203,
                    columnNumber: 25
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/plugins/CustomAIPlugin.tsx",
            lineNumber: 201,
            columnNumber: 12
        }, this);
    }
}
function $createCustomAINode(ids = [], inputMode = "text", criteria = "", allowedInput = [
    "text"
], format = "") {
    return new CustomAINode(ids, inputMode, criteria, allowedInput, format);
}
function $isCustomAINode(node) {
    return node instanceof CustomAINode;
}
const INSERT_CUSTOM_AI_BLOCK_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("INSERT_CUSTOM_AI_BLOCK_COMMAND");
function CustomAIPlugin() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "c58cf31fd0f66692e6605e4de360482562387d20ac80796c5f6d46c7bf58bf9b") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c58cf31fd0f66692e6605e4de360482562387d20ac80796c5f6d46c7bf58bf9b";
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t0;
    let t1;
    if ($[1] !== editor) {
        t0 = ({
            "CustomAIPlugin[useEffect()]": ()=>{
                if (!editor.hasNodes([
                    CustomAINode
                ])) {
                    throw new Error("CustomAIPlugin: CustomAINode not registered on editor");
                }
                return editor.registerCommand(INSERT_CUSTOM_AI_BLOCK_COMMAND, _CustomAIPluginUseEffectEditorRegisterCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
            }
        })["CustomAIPlugin[useEffect()]"];
        t1 = [
            editor
        ];
        $[1] = editor;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return null;
}
_s(CustomAIPlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c2 = CustomAIPlugin;
function _CustomAIPluginUseEffectEditorRegisterCommand(payload) {
    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    let selectedNode = null;
    if (selection) {
        const nodes = selection.getNodes();
        for (const node of nodes){
            if ($isCustomAINode(node)) {
                selectedNode = node;
                break;
            }
            let parent = node.getParent();
            while(parent){
                if ($isCustomAINode(parent)) {
                    selectedNode = parent;
                    break;
                }
                parent = parent.getParent();
            }
            if (selectedNode) {
                break;
            }
        }
    }
    if (selectedNode) {
        payload.forEach({
            "CustomAIPlugin[useEffect() > editor.registerCommand() > payload.forEach()]": (id)=>selectedNode.appendId(id)
        }["CustomAIPlugin[useEffect() > editor.registerCommand() > payload.forEach()]"]);
    } else {
        const node_0 = $createCustomAINode(payload);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(node_0);
    }
    return true;
}
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "CustomAIEditor");
__turbopack_context__.k.register(_c1, "CustomAIComponent");
__turbopack_context__.k.register(_c2, "CustomAIPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/ArmorEditorBlock.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ArmorEditorBlock
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview ArmorEditorBlock - React component rendered by ArmorEditorNode.decorate().
 * In editable mode: shows a shield preview with an "Edit" button that opens ArmorEditor dialog.
 * In read-only mode: shows just the static shield SVG.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/useLexicalNodeSelection.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Edit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ArmorEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/ArmorEditor.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ArmorEditorPlugin$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/ArmorEditorPlugin.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$sanitizeHtml$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/sanitizeHtml.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
function ArmorEditorBlock(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(46);
    if ($[0] !== "4d047e44811154ea10d18bd6645551e674beeabd1462f5056589ba14b45a7c26") {
        for(let $i = 0; $i < 46; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4d047e44811154ea10d18bd6645551e674beeabd1462f5056589ba14b45a7c26";
    }
    const { nodeKey, data, isEditable, className } = t0;
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const [isSelected, setSelected, clearSelection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"])(nodeKey);
    const [dialogOpen, setDialogOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    if ($[1] !== data) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ArmorEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderShieldSvg"])(data);
        $[1] = data;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const svgString = t1;
    let t2;
    if ($[3] !== isEditable) {
        t2 = ({
            "ArmorEditorBlock[handleOpen]": ()=>{
                if (isEditable) {
                    setDialogOpen(true);
                }
            }
        })["ArmorEditorBlock[handleOpen]"];
        $[3] = isEditable;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const handleOpen = t2;
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "ArmorEditorBlock[handleClose]": ()=>{
                setDialogOpen(false);
            }
        })["ArmorEditorBlock[handleClose]"];
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const handleClose = t3;
    let t4;
    if ($[6] !== editor || $[7] !== nodeKey) {
        t4 = ({
            "ArmorEditorBlock[handleSave]": (config, _svg, name, description)=>{
                editor.update({
                    "ArmorEditorBlock[handleSave > editor.update()]": ()=>{
                        const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ArmorEditorPlugin$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isArmorEditorNode"])(node)) {
                            node.saveData(config);
                        }
                    }
                }["ArmorEditorBlock[handleSave > editor.update()]"]);
                setDialogOpen(false);
            }
        })["ArmorEditorBlock[handleSave]"];
        $[6] = editor;
        $[7] = nodeKey;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const handleSave = t4;
    const t5 = isSelected ? className.focus : "";
    let t6;
    if ($[9] !== className.base || $[10] !== t5) {
        t6 = [
            className.base,
            t5
        ].filter(Boolean);
        $[9] = className.base;
        $[10] = t5;
        $[11] = t6;
    } else {
        t6 = $[11];
    }
    const containerClass = t6.join(" ");
    let t7;
    if ($[12] !== clearSelection || $[13] !== setSelected) {
        t7 = ({
            "ArmorEditorBlock[<Box>.onClick]": ()=>{
                clearSelection();
                setSelected(true);
            }
        })["ArmorEditorBlock[<Box>.onClick]"];
        $[12] = clearSelection;
        $[13] = setSelected;
        $[14] = t7;
    } else {
        t7 = $[14];
    }
    const t8 = isSelected ? "2px solid" : "2px solid transparent";
    const t9 = isSelected ? "primary.main" : "transparent";
    const t10 = isEditable ? "pointer" : "default";
    let t11;
    if ($[15] !== isEditable) {
        t11 = isEditable ? {
            borderColor: "action.hover"
        } : undefined;
        $[15] = isEditable;
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    let t12;
    if ($[17] !== t10 || $[18] !== t11 || $[19] !== t8 || $[20] !== t9) {
        t12 = {
            position: "relative",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            my: 1,
            p: 1,
            border: t8,
            borderColor: t9,
            borderRadius: 2,
            cursor: t10,
            transition: "border-color 0.15s",
            "&:hover": t11
        };
        $[17] = t10;
        $[18] = t11;
        $[19] = t8;
        $[20] = t9;
        $[21] = t12;
    } else {
        t12 = $[21];
    }
    let t13;
    if ($[22] !== svgString) {
        t13 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$sanitizeHtml$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sanitizeSvg"])(svgString);
        $[22] = svgString;
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    let t14;
    if ($[24] !== t13) {
        t14 = {
            __html: t13
        };
        $[24] = t13;
        $[25] = t14;
    } else {
        t14 = $[25];
    }
    let t15;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            "& svg": {
                width: 120,
                height: 120
            }
        };
        $[26] = t15;
    } else {
        t15 = $[26];
    }
    let t16;
    if ($[27] !== t14) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            dangerouslySetInnerHTML: t14,
            sx: t15
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ArmorEditorBlock.tsx",
            lineNumber: 198,
            columnNumber: 11
        }, this);
        $[27] = t14;
        $[28] = t16;
    } else {
        t16 = $[28];
    }
    let t17;
    if ($[29] !== handleOpen || $[30] !== isEditable) {
        t17 = isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: "Edit coat of arms",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                onClick: {
                    "ArmorEditorBlock[<IconButton>.onClick]": (e)=>{
                        e.stopPropagation();
                        handleOpen();
                    }
                }["ArmorEditorBlock[<IconButton>.onClick]"],
                size: "small",
                sx: {
                    position: "absolute",
                    top: 4,
                    right: 4,
                    bgcolor: "background.paper",
                    boxShadow: 1,
                    "&:hover": {
                        bgcolor: "action.hover"
                    }
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/ArmorEditorBlock.tsx",
                    lineNumber: 220,
                    columnNumber: 10
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/plugins/ArmorEditorBlock.tsx",
                lineNumber: 206,
                columnNumber: 60
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ArmorEditorBlock.tsx",
            lineNumber: 206,
            columnNumber: 25
        }, this);
        $[29] = handleOpen;
        $[30] = isEditable;
        $[31] = t17;
    } else {
        t17 = $[31];
    }
    let t18;
    if ($[32] !== containerClass || $[33] !== t12 || $[34] !== t16 || $[35] !== t17 || $[36] !== t7) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: containerClass,
            onClick: t7,
            sx: t12,
            children: [
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/plugins/ArmorEditorBlock.tsx",
            lineNumber: 229,
            columnNumber: 11
        }, this);
        $[32] = containerClass;
        $[33] = t12;
        $[34] = t16;
        $[35] = t17;
        $[36] = t7;
        $[37] = t18;
    } else {
        t18 = $[37];
    }
    let t19;
    if ($[38] !== data || $[39] !== dialogOpen || $[40] !== handleSave || $[41] !== isEditable) {
        t19 = isEditable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ArmorEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: dialogOpen,
            squadName: "",
            initialConfig: data,
            onSave: handleSave,
            onClose: handleClose,
            autoSaveDelay: 0
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ArmorEditorBlock.tsx",
            lineNumber: 241,
            columnNumber: 25
        }, this);
        $[38] = data;
        $[39] = dialogOpen;
        $[40] = handleSave;
        $[41] = isEditable;
        $[42] = t19;
    } else {
        t19 = $[42];
    }
    let t20;
    if ($[43] !== t18 || $[44] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t18,
                t19
            ]
        }, void 0, true);
        $[43] = t18;
        $[44] = t19;
        $[45] = t20;
    } else {
        t20 = $[45];
    }
    return t20;
}
_s(ArmorEditorBlock, "MWvGrP3iNU6Sg1pNr0Fcyy09md4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"]
    ];
});
_c = ArmorEditorBlock;
var _c;
__turbopack_context__.k.register(_c, "ArmorEditorBlock");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/ArmorEditorPlugin.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createArmorEditorNode",
    ()=>$createArmorEditorNode,
    "$isArmorEditorNode",
    ()=>$isArmorEditorNode,
    "ArmorEditorNode",
    ()=>ArmorEditorNode,
    "INSERT_ARMOR_EDITOR_COMMAND",
    ()=>INSERT_ARMOR_EDITOR_COMMAND,
    "default",
    ()=>ArmorEditorPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview ArmorEditorPlugin - Lexical DecoratorNode for embedding
 * the squad Armor Editor (coat of arms designer) as an interactive block.
 *
 * Pattern follows existing custom blocks (QuizPlugin, AnswerPlugin, etc.):
 *   - DecoratorNode stores the ArmorEditorConfig as JSON data
 *   - In edit mode: renders the ArmorEditor inline
 *   - In read mode: renders the static SVG shield preview
 *   - INSERT_ARMOR_EDITOR_COMMAND to insert via toolbar/menu
 *
 * @module ArmorEditorPlugin
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ArmorEditorBlock$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/ArmorEditorBlock.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
// ============================================================================
// Node
// ============================================================================
function convertArmorEditorElement(domNode) {
    const raw = domNode.getAttribute('data-lexical-armor-editor');
    if (raw) {
        try {
            const data = JSON.parse(raw);
            const node = $createArmorEditorNode(data);
            return {
                node
            };
        } catch  {
            return null;
        }
    }
    return null;
}
class ArmorEditorNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __data;
    static getType() {
        return 'armor-editor';
    }
    static clone(node) {
        return new ArmorEditorNode(node.__data, node.__key);
    }
    static importJSON(serializedNode) {
        return $createArmorEditorNode(serializedNode.data);
    }
    exportJSON() {
        return {
            type: 'armor-editor',
            version: 1,
            data: this.__data
        };
    }
    constructor(data, key){
        super(key);
        this.__data = data;
    }
    exportDOM() {
        const element = document.createElement('div');
        element.setAttribute('data-lexical-armor-editor', JSON.stringify(this.__data));
        return {
            element
        };
    }
    createDOM() {
        const div = document.createElement('div');
        div.setAttribute('data-lexical-armor-editor', JSON.stringify(this.__data));
        return div;
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute('data-lexical-armor-editor')) {
                    return null;
                }
                return {
                    conversion: convertArmorEditorElement,
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
    canBeEmpty() {
        return true;
    }
    getData() {
        return this.__data;
    }
    saveData(data) {
        const writable = this.getWritable();
        writable.__data = data;
    }
    getTextContent() {
        return '[Coat of Arms]';
    }
    decorate(_editor, config) {
        const isEditable = _editor.isEditable();
        const embedBlockTheme = config.theme?.embedBlock || {};
        const className = {
            base: embedBlockTheme.base || '',
            focus: embedBlockTheme.focus || ''
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ArmorEditorBlock$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            nodeKey: this.getKey(),
            data: this.__data,
            isEditable: isEditable,
            className: className
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ArmorEditorPlugin.tsx",
            lineNumber: 117,
            columnNumber: 12
        }, this);
    }
}
function $createArmorEditorNode(data) {
    const defaultData = data || {
        shape: 'classic',
        fieldColor: '#1565c0',
        fieldColor2: '#f9a825',
        division: 'none',
        chargeId: 'none',
        chargeColor: '#f9a825',
        chargePosition: 'center',
        chargeScale: 1,
        charges: []
    };
    return new ArmorEditorNode(defaultData);
}
function $isArmorEditorNode(node) {
    return node instanceof ArmorEditorNode;
}
const INSERT_ARMOR_EDITOR_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('INSERT_ARMOR_EDITOR_COMMAND');
function ArmorEditorPlugin() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "a0c92c1c036afda1e0de780b1fe9daef07b66702144bca6888550eeb010b402c") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a0c92c1c036afda1e0de780b1fe9daef07b66702144bca6888550eeb010b402c";
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t0;
    let t1;
    if ($[1] !== editor) {
        t0 = ({
            "ArmorEditorPlugin[useEffect()]": ()=>{
                if (!editor.hasNodes([
                    ArmorEditorNode
                ])) {
                    throw new Error("ArmorEditorPlugin: ArmorEditorNode not registered on editor");
                }
                return editor.registerCommand(INSERT_ARMOR_EDITOR_COMMAND, _ArmorEditorPluginUseEffectEditorRegisterCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
            }
        })["ArmorEditorPlugin[useEffect()]"];
        t1 = [
            editor
        ];
        $[1] = editor;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return null;
}
_s(ArmorEditorPlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = ArmorEditorPlugin;
function _ArmorEditorPluginUseEffectEditorRegisterCommand(payload) {
    const node = $createArmorEditorNode(payload);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(node);
    return true;
}
var _c;
__turbopack_context__.k.register(_c, "ArmorEditorPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/WorkbookStatePlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WorkbookStatePlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview WorkbookStatePlugin - Loads unit content for read-only Workbook mode
 * @module WorkbookStatePlugin
 *
 * In production, this plugin loads the Unit.data (lesson content) into the read-only
 * Workbook view. The student interacts with graded blocks, whose state is managed
 * by the workbookCollaboration system (Grade.data), not the unit content itself.
 *
 * This is different from the Editor component which uses CollaborationPlugin for
 * real-time collaborative editing of Unit.data by instructors.
 *
 * Usage: Add this plugin to the Workbook component (student view - read-only content).
 * It loads Unit.data while graded blocks use workbookCollaboration.workbookData for answers.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/editorConfig.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
function WorkbookStatePlugin() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("pages");
    const { unit } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const hasLoaded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const loadedVersion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [updateAvailable, setUpdateAvailable] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WorkbookStatePlugin.useEffect": ()=>{
            // Only load once and only if we have unit data
            if (hasLoaded.current || !unit?.data) {
                return;
            }
            try {
                // Sanitize the JSON to strip nodes with invalid/unregistered types
                const sanitized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sanitizeEditorStateJSON"])(typeof unit.data === "string" ? unit.data : JSON.stringify(unit.data));
                if (sanitized) {
                    const editorState = JSON.parse(sanitized);
                    console.log("[WorkbookStatePlugin] Loading unit content into read-only workbook:", unit.id);
                    // Convert JSON to EditorState and update editor
                    const parsedState = editor.parseEditorState(editorState);
                    // Defer state update to avoid flushSync during React lifecycle
                    queueMicrotask({
                        "WorkbookStatePlugin.useEffect": ()=>{
                            editor.setEditorState(parsedState);
                        }
                    }["WorkbookStatePlugin.useEffect"]);
                    hasLoaded.current = true;
                    loadedVersion.current = unit._version;
                }
            } catch (error) {
                console.warn("[WorkbookStatePlugin] Failed to load unit content:", error.message);
            }
        }
    }["WorkbookStatePlugin.useEffect"], [
        unit?.data,
        unit?.id,
        editor
    ]);
    // Detect version changes after initial load
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WorkbookStatePlugin.useEffect": ()=>{
            if (!hasLoaded.current || loadedVersion.current == null || unit?._version == null) {
                return;
            }
            if (unit._version > loadedVersion.current) {
                console.log("[WorkbookStatePlugin] Unit updated while student is working:", loadedVersion.current, "→", unit._version);
                setUpdateAvailable(true);
            }
        }
    }["WorkbookStatePlugin.useEffect"], [
        unit?._version
    ]);
    const handleReload = ()=>{
        window.location.reload();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        open: updateAvailable,
        message: t("workbook.unitUpdated"),
        anchorOrigin: {
            vertical: "top",
            horizontal: "center"
        },
        action: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            color: "primary",
            variant: "contained",
            size: "small",
            onClick: handleReload,
            children: t("workbook.reload")
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/WorkbookStatePlugin.jsx",
            lineNumber: 75,
            columnNumber: 14
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Editor3/plugins/WorkbookStatePlugin.jsx",
        lineNumber: 72,
        columnNumber: 10
    }, this);
}
_s(WorkbookStatePlugin, "HjcqJyT5k/WP0lQ0YqOZkK9On3Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = WorkbookStatePlugin;
var _c;
__turbopack_context__.k.register(_c, "WorkbookStatePlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CAN_USE_DOM",
    ()=>CAN_USE_DOM,
    "IS_APPLE",
    ()=>IS_APPLE,
    "default",
    ()=>ToolBarRoPlugin,
    "getSelectedNode",
    ()=>getSelectedNode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview ToolBarRoPlugin - Read-only toolbar for viewing educational content.
 * @module ToolBarRoPlugin
 *
 * Provides a read-only toolbar that displays unit information and a countdown timer.
 * Used when displaying content in read-only/student view mode.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
// import { useLexicalComposerContext } from '@lexical/react/LexicalComposerContext';
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useToolbarScroll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useToolbarScroll.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ToolbarScrollButton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ToolbarScrollButton.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/AppShellContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Timer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Timer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$ConnectionStatus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Workbook/ConnectionStatus.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/selection/LexicalSelection.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$StreakIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/StreakIndicator.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
const drawerWidth = 400;
const CAN_USE_DOM = ("TURBOPACK compile-time value", "object") !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
const IS_APPLE = CAN_USE_DOM && /Mac|iPod|iPhone|iPad/.test(navigator.platform);
;
;
;
;
/**
 * @param {number} countDown
 * @returns {number[]} [hours, minutes, seconds]
 *
 * @example
 * formatTime(1000) // [0, 0, 1]
 *
 * @example
 * formatTime(1000 * 60 * 60 * 24) // [24, 0, 0]
 *
 * @description
 * Convert milliseconds to hours, minutes, seconds
 *
 */ const formatTime = (countDown)=>{
    const hours = Math.floor(countDown % (1000 * 60 * 60 * 24) / (1000 * 60 * 60));
    const minutes = Math.floor(countDown % (1000 * 60 * 60) / (1000 * 60));
    const seconds = Math.floor(countDown % (1000 * 60) / 1000);
    return [
        hours,
        minutes,
        seconds
    ];
};
/**
 *
 * @param {number} timerStartedAt
 * @param {number} timeLimitSeconds
 * @returns {JSX.Element}
 *
 * @example
 * <TimeLeft timerStartedAt={1634170800000} timeLimitSeconds={60} />
 *
 * @description
 * Display a countdown timer. Input is a timestamp and a number of seconds.
 */ const TimeLeft = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](_s(()=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23);
    if ($[0] !== "a2a89f15eecfb530cb18b494bac40e052cde9adf76715dd5f8b4ad8d9dbd25f5") {
        for(let $i = 0; $i < 23; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a2a89f15eecfb530cb18b494bac40e052cde9adf76715dd5f8b4ad8d9dbd25f5";
    }
    const { grade, unit } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const timeLimitSeconds = unit?.timeLimitSeconds || 0;
    const timerStartedAt = grade?.createdAt;
    const [countDown, setCountDown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(timeLimitSeconds * 1000);
    let t0;
    let t1;
    if ($[1] !== timeLimitSeconds || $[2] !== timerStartedAt) {
        t0 = ()=>{
            if (!timerStartedAt) {
                setCountDown(timeLimitSeconds * 1000);
            } else {
                if (timeLimitSeconds > 0 && timerStartedAt) {
                    const [, minutes, seconds] = formatTime(timeLimitSeconds * 1000);
                    const targetDate = new Date(timerStartedAt);
                    targetDate.setMinutes(targetDate.getMinutes() + minutes);
                    targetDate.setSeconds(targetDate.getSeconds() + seconds);
                    const countDownDate = new Date(targetDate).getTime();
                    const interval = setInterval(()=>{
                        console.log("TimeLeft.interval");
                        const timeRemaining = countDownDate - new Date().getTime();
                        if (timeRemaining <= 0) {
                            setCountDown(0);
                            clearInterval(interval);
                        } else {
                            setCountDown(timeRemaining);
                        }
                    }, 1000);
                    return ()=>clearInterval(interval);
                }
            }
        };
        t1 = [
            timeLimitSeconds,
            timerStartedAt
        ];
        $[1] = timeLimitSeconds;
        $[2] = timerStartedAt;
        $[3] = t0;
        $[4] = t1;
    } else {
        t0 = $[3];
        t1 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    let t2;
    if ($[5] !== countDown) {
        t2 = formatTime(countDown);
        $[5] = countDown;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    const [hoursLeft, minutesLeft, secondsLeft] = t2;
    let t3;
    if ($[7] !== hoursLeft) {
        t3 = hoursLeft.toString().padStart(2, "0");
        $[7] = hoursLeft;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== minutesLeft) {
        t4 = minutesLeft.toString().padStart(2, "0");
        $[9] = minutesLeft;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== secondsLeft) {
        t5 = secondsLeft.toString().padStart(2, "0");
        $[11] = secondsLeft;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    let t6;
    if ($[13] !== t3 || $[14] !== t4 || $[15] !== t5) {
        t6 = [
            t3,
            t4,
            t5
        ];
        $[13] = t3;
        $[14] = t4;
        $[15] = t5;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    const timeString = t6.join(":");
    const isOutOfTime = 0 >= hoursLeft && 0 >= minutesLeft && 0 >= secondsLeft;
    const chipColor = !isOutOfTime ? "primary" : undefined;
    let t7;
    if ($[17] !== chipColor || $[18] !== timeLimitSeconds || $[19] !== timeString) {
        t7 = timeLimitSeconds > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Timer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    display: {
                        xs: "none",
                        sm: "inline-flex"
                    }
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                lineNumber: 163,
                columnNumber: 46
            }, ("TURBOPACK compile-time value", void 0)),
            label: timeString,
            color: chipColor,
            sx: {
                "& .MuiChip-icon": {
                    display: {
                        xs: "none",
                        sm: "inline-flex"
                    }
                }
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
            lineNumber: 163,
            columnNumber: 34
        }, ("TURBOPACK compile-time value", void 0));
        $[17] = chipColor;
        $[18] = timeLimitSeconds;
        $[19] = timeString;
        $[20] = t7;
    } else {
        t7 = $[20];
    }
    let t8;
    if ($[21] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: t7
        }, void 0, false);
        $[21] = t7;
        $[22] = t8;
    } else {
        t8 = $[22];
    }
    return t8;
}, "liXY0wUGn/44+14ogShgeVrtGEU="));
_c = TimeLeft;
function getSelectedNode(selection) {
    const anchor = selection.anchor;
    const focus = selection.focus;
    const anchorNode = selection.anchor.getNode();
    const focusNode = selection.focus.getNode();
    if (anchorNode === focusNode) {
        return anchorNode;
    }
    const isBackward = selection.isBackward();
    if (isBackward) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$isAtNodeEnd"])(focus) ? anchorNode : focusNode;
    } else {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$isAtNodeEnd"])(anchor) ? anchorNode : focusNode;
    }
}
function ToolBarRoPlugin({ open, setOpen, setTabValue, isScrolled = false }) {
    _s1();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("workbook");
    const { unit, finishedQuestions, rubric } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { toolbarChildrenPortalRef, appBarHeight } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppShell"])();
    const { xpLogs } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"])();
    // Derive current streak from XP logs (latest streak entry)
    const currentStreak = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "ToolBarRoPlugin.useMemo[currentStreak]": ()=>{
            const streakLogs = xpLogs.filter({
                "ToolBarRoPlugin.useMemo[currentStreak].streakLogs": (l)=>l.reason === "STREAK_3DAY" || l.reason === "STREAK_7DAY"
            }["ToolBarRoPlugin.useMemo[currentStreak].streakLogs"]);
            return streakLogs.length > 0 ? streakLogs.length >= 2 ? 7 : 3 : 0;
        }
    }["ToolBarRoPlugin.useMemo[currentStreak]"], [
        xpLogs
    ]);
    const name = unit?.name;
    const description = unit?.description;
    const { toolbarRef, showLeftArrow, showRightArrow, scrollToolbar } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useToolbarScroll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToolbarScroll"])();
    const firstAppBarRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [firstAppBarHeight, setFirstAppBarHeight] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](0);
    // Sync --app-bar-height CSS variable from AppShell's measured height
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "ToolBarRoPlugin.useEffect": ()=>{
            if (appBarHeight > 0) {
                document.documentElement.style.setProperty("--app-bar-height", `${appBarHeight}px`);
            }
        }
    }["ToolBarRoPlugin.useEffect"], [
        appBarHeight
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "69a07bd5bc63ea1a",
                children: ".editor-toolbar button{min-width:1rem}"
            }, void 0, false, void 0, this),
            toolbarChildrenPortalRef?.current && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                ref: firstAppBarRef,
                sx: {
                    flexGrow: 1,
                    overflowX: "hidden",
                    transition: "all 0.3s ease",
                    display: "contents"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexGrow: 1,
                        margin: isScrolled ? "0.5rem 1rem" : "1rem",
                        transition: "all 0.3s ease",
                        display: "flex",
                        alignItems: isScrolled ? "center" : "flex-start",
                        flexDirection: isScrolled ? "row" : "column",
                        gap: isScrolled ? 2 : 0,
                        width: "100%",
                        maxWidth: "100%",
                        overflow: "hidden",
                        boxSizing: "border-box"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                flexGrow: 1,
                                minWidth: 0,
                                overflow: "hidden"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("title", {
                                    className: "jsx-69a07bd5bc63ea1a",
                                    children: name
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                    lineNumber: 279,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: isScrolled ? "body1" : "h6",
                                    component: "div",
                                    sx: {
                                        flexGrow: 1,
                                        transition: "all 0.3s ease",
                                        fontWeight: isScrolled ? 500 : 400,
                                        overflow: "hidden",
                                        textOverflow: "ellipsis",
                                        whiteSpace: "nowrap"
                                    },
                                    children: name || t("toolBarRoPlugin.untitledUnit")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                    lineNumber: 280,
                                    columnNumber: 17
                                }, this),
                                !isScrolled && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "p",
                                    component: "div",
                                    sx: {
                                        flexGrow: 1,
                                        transition: "opacity 0.3s ease",
                                        display: {
                                            xs: "none",
                                            sm: "block"
                                        },
                                        overflow: "hidden",
                                        textOverflow: "ellipsis",
                                        whiteSpace: "nowrap"
                                    },
                                    children: description || t("toolBarRoPlugin.noDescription")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                    lineNumber: 291,
                                    columnNumber: 33
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                            lineNumber: 274,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                alignItems: "center",
                                flexShrink: 0,
                                minWidth: 0
                            },
                            children: [
                                showLeftArrow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ToolbarScrollButton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    direction: "left",
                                    onClick: ()=>scrollToolbar("left"),
                                    ariaLabel: t("toolBarRoPlugin.scrollLeft", "Scroll left"),
                                    height: isScrolled ? "1.5rem" : "2rem"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                    lineNumber: 312,
                                    columnNumber: 35
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                    ref: toolbarRef,
                                    direction: "row",
                                    spacing: 1,
                                    sx: {
                                        alignItems: "center",
                                        flex: 1,
                                        minWidth: 0,
                                        overflowX: "hidden",
                                        scrollSnapType: "x mandatory",
                                        scrollbarWidth: "none",
                                        "&::-webkit-scrollbar": {
                                            display: "none"
                                        },
                                        msOverflowStyle: "none",
                                        "& > *": {
                                            scrollSnapAlign: "start",
                                            flexShrink: 0
                                        }
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TimeLeft, {}, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                            lineNumber: 329,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$StreakIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StreakIndicator"], {
                                            currentStreak: currentStreak,
                                            size: "small"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                            lineNumber: 330,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$ConnectionStatus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectionStatus"], {
                                            size: isScrolled ? "small" : "small",
                                            showLabel: !isScrolled
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                            lineNumber: 331,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                            label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                component: "span",
                                                children: [
                                                    `${finishedQuestions} of ${rubric?.length || 0}`,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        component: "span",
                                                        sx: {
                                                            display: {
                                                                xs: "none",
                                                                sm: "inline"
                                                            },
                                                            ml: 0.5
                                                        },
                                                        children: "Questions Completed"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                                        lineNumber: 334,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                                lineNumber: 332,
                                                columnNumber: 32
                                            }, this),
                                            variant: "outlined",
                                            size: isScrolled ? "small" : "medium"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                            lineNumber: 332,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                    lineNumber: 313,
                                    columnNumber: 17
                                }, this),
                                showRightArrow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ToolbarScrollButton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    direction: "right",
                                    onClick: ()=>scrollToolbar("right"),
                                    ariaLabel: t("toolBarRoPlugin.scrollRight", "Scroll right"),
                                    height: isScrolled ? "1.5rem" : "2rem"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                                    lineNumber: 345,
                                    columnNumber: 36
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                            lineNumber: 306,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                    lineNumber: 261,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx",
                lineNumber: 255,
                columnNumber: 58
            }, this), toolbarChildrenPortalRef.current)
        ]
    }, void 0, true);
}
_s1(ToolBarRoPlugin, "rTkSfX/axQNMffHDxDux4rAFBk0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppShell"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useToolbarScroll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToolbarScroll"]
    ];
});
_c1 = ToolBarRoPlugin;
var _c, _c1;
__turbopack_context__.k.register(_c, "TimeLeft");
__turbopack_context__.k.register(_c1, "ToolBarRoPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/PdfViewerPlugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "INSERT_PDF_COMMAND",
    ()=>INSERT_PDF_COMMAND,
    "default",
    ()=>PdfViewerPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview PdfViewerPlugin - Embeds PDF documents in the editor.
 * 
 * This plugin provides PDF viewing functionality with document embedding
 * and viewing capabilities for PDF files.
 * 
 * @module PdfViewerPlugin
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PdfViewerNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/PdfViewerNode.jsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
const INSERT_PDF_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('INSERT_PDF_COMMAND');
function PdfViewerPlugin() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "de9b7e9fa3037e0c9d18095e368c1a7eca8e8f2e8177d7491655f8705dae5a5e") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "de9b7e9fa3037e0c9d18095e368c1a7eca8e8f2e8177d7491655f8705dae5a5e";
    }
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    let t0;
    let t1;
    if ($[1] !== editor) {
        t0 = ({
            "PdfViewerPlugin[useEffect()]": ()=>{
                if (!editor.hasNodes([
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PdfViewerNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PdfViewerNode"]
                ])) {
                    throw new Error("PdfViewerPlugin: PdfViewerNode not registered on editor");
                }
                return editor.registerCommand(INSERT_PDF_COMMAND, _PdfViewerPluginUseEffectEditorRegisterCommand, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
            }
        })["PdfViewerPlugin[useEffect()]"];
        t1 = [
            editor
        ];
        $[1] = editor;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return null;
}
_s(PdfViewerPlugin, "mCqe7sh4aC9mLBXPHfG3d/PNTaQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = PdfViewerPlugin;
function _PdfViewerPluginUseEffectEditorRegisterCommand(payload) {
    const { path, identityId, filename } = payload;
    const pdfViewerNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PdfViewerNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createPdfViewerNode"])({
        path,
        identityId,
        filename
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(pdfViewerNode);
    return true;
}
var _c;
__turbopack_context__.k.register(_c, "PdfViewerPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>UnitCompletedPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
/**
 * @fileoverview UnitCompletedPlugin - Displays unit completion modal.
 * @module UnitCompletedPlugin
 *
 * Shows a congratulatory modal when a unit is completed, displaying
 * the unit name, top grades/scores, and action buttons (Try Again, Peer Review).
 * The modal persists across navigation until the student explicitly starts a new attempt.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PeerReview$2f$OpenPeerReviewButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PeerReview/OpenPeerReviewButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$HomeworkXPSummary$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/HomeworkXPSummary.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$PersonalBestBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/PersonalBestBanner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Modal/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Replay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Replay.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$NavigateNext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/NavigateNext.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function UnitCompletedPlugin() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("workbook");
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { unit, name, grade, showUnitComplete, setShowUnitComplete, personalBestResult, setPersonalBestResult, createGrade, recentGrades = [], sectionId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {};
    const [retrying, setRetrying] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { totalXP, xpLogs } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"])();
    const { assignments } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {
        assignments: []
    };
    const retryEnabled = unit?.retryEnabled === true;
    // Most recent completed grade for peer review
    const latestCompletedGrade = recentGrades[0];
    // Compute next assignment in same section (sorted by due date, skip current)
    const nextAssignment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "UnitCompletedPlugin.useMemo[nextAssignment]": ()=>{
            if (!sectionId || !unit?.id || !assignments?.length) return null;
            const now = new Date();
            const sectionAssignments = assignments.filter({
                "UnitCompletedPlugin.useMemo[nextAssignment].sectionAssignments": (a)=>a && a.sectionID === sectionId && a.unitID !== unit.id
            }["UnitCompletedPlugin.useMemo[nextAssignment].sectionAssignments"]).filter({
                "UnitCompletedPlugin.useMemo[nextAssignment].sectionAssignments": (a_0)=>!a_0.dueDate || new Date(a_0.dueDate) >= now
            }["UnitCompletedPlugin.useMemo[nextAssignment].sectionAssignments"]).sort({
                "UnitCompletedPlugin.useMemo[nextAssignment].sectionAssignments": (a_1, b)=>{
                    if (!a_1.dueDate) return 1;
                    if (!b.dueDate) return -1;
                    return new Date(a_1.dueDate) - new Date(b.dueDate);
                }
            }["UnitCompletedPlugin.useMemo[nextAssignment].sectionAssignments"]);
            return sectionAssignments[0] || null;
        }
    }["UnitCompletedPlugin.useMemo[nextAssignment]"], [
        assignments,
        sectionId,
        unit?.id
    ]);
    const handleTryAgain = async ()=>{
        setRetrying(true);
        try {
            await createGrade(0, false);
            setShowUnitComplete(false);
        } catch (err) {
            console.error("[UnitCompletedPlugin] Error creating new grade:", err);
        } finally{
            setRetrying(false);
        }
    };
    const handleCreateRoom = async (gradeId, invitedUserIds)=>{
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        const { data: room } = await client.models.HomeworkRoom.create({
            gradeId,
            status: "open",
            peerGroup: invitedUserIds
        });
        return room.id;
    };
    const handleRoomCreated = (roomId)=>{
        router.push(`/review/${roomId}`);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        open: showUnitComplete,
        onClose: (_, reason)=>{
            // Only allow close if retryEnabled, or if there's an active incomplete grade
            if (retryEnabled || grade) {
                setShowUnitComplete(false);
            }
        // Otherwise: no backdrop/escape dismiss — student must use Try Again
        },
        "aria-labelledby": "modal-modal-title",
        "aria-describedby": "modal-modal-description",
        sx: {
            overflow: "auto",
            zIndex: (theme)=>theme.zIndex.modal + 3
        },
        slotProps: {
            backdrop: {
                sx: {
                    backdropFilter: "blur(5px)"
                }
            }
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
            "data-tour": "results",
            sx: {
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                width: "70vw",
                maxWidth: "700px",
                bgcolor: "background.paper",
                boxShadow: "0 0 10px 3px rgba(0, 0, 0, .3)",
                backdropFilter: "blur(5px)",
                overflow: "auto",
                maxHeight: "90vh"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "h3",
                    component: "h3",
                    sx: {
                        flexGrow: 1,
                        textAlign: "center",
                        margin: "2rem 0.5rem 0.5rem"
                    },
                    children: [
                        t("unitCompletedPlugin.completionMessage"),
                        " ",
                        name
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                    lineNumber: 129,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "h6",
                    component: "h6",
                    sx: {
                        flexGrow: 1,
                        textAlign: "center"
                    },
                    children: t("unitCompletedPlugin.sectionHeading")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                    lineNumber: 137,
                    columnNumber: 9
                }, this),
                personalBestResult?.isNewBest && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        mx: 2,
                        mt: 1
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$PersonalBestBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PersonalBestBanner"], {
                        open: true,
                        newScore: personalBestResult.bestScore,
                        previousBest: personalBestResult.previousBest,
                        onClose: ()=>setPersonalBestResult?.(null)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                        lineNumber: 149,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                    lineNumber: 145,
                    columnNumber: 43
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    id: "edfe377d8da5ac7c",
                    children: "ol.recent-grades{counter-reset:my-counter;list-style-type:none}ol.recent-grades li:before{content:counter(my-counter);counter-increment:my-counter;margin-right:-.5em;font-size:1.5em;font-weight:700;position:relative;top:2rem;left:-1.5rem}"
                }, void 0, false, void 0, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    style: {
                        padding: "0 2rem",
                        margin: "1rem 2rem",
                        maxHeight: "40vh",
                        overflow: "auto"
                    },
                    className: "jsx-edfe377d8da5ac7c" + " " + "recent-grades",
                    children: recentGrades.map((grade_0, index)=>{
                        const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
                        const localTime = new Date(grade_0?.createdAt).toLocaleString(undefined, {
                            timeZone
                        });
                        const _roundedAccuracy = Math.round(grade_0?.accuracy * 100) / 100;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            className: "jsx-edfe377d8da5ac7c",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    justifyContent: "center",
                                    margin: "0"
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h6",
                                        component: "div",
                                        sx: {
                                            textAlign: "left",
                                            paddingLeft: "2rem"
                                        },
                                        children: `${localTime}`
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                                        lineNumber: 188,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            flex: 1,
                                            textAlign: "center",
                                            flexGrow: 1,
                                            borderBottom: "1px dashed currentColor",
                                            margin: "0 0.4rem",
                                            position: "relative",
                                            top: "-0.5rem"
                                        },
                                        className: "jsx-edfe377d8da5ac7c"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                                        lineNumber: 195,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h6",
                                        component: "div",
                                        sx: {
                                            textAlign: "right",
                                            margin: "0"
                                        },
                                        children: `${_roundedAccuracy}%`
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                                        lineNumber: 205,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                                lineNumber: 183,
                                columnNumber: 17
                            }, this)
                        }, index, false, {
                            fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                            lineNumber: 182,
                            columnNumber: 18
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                    lineNumber: 170,
                    columnNumber: 9
                }, this),
                xpLogs.length > 0 && (()=>{
                    // Show XP earned from this grade's reference
                    const gradeId_0 = latestCompletedGrade?.id;
                    const relevantLogs = gradeId_0 ? xpLogs.filter((l)=>l.referenceId === gradeId_0) : xpLogs.slice(-3);
                    if (relevantLogs.length === 0) return null;
                    const lineItems = relevantLogs.map((l_0)=>({
                            label: l_0.reason?.replace(/_/g, " ") || "XP",
                            xp: l_0.xpAmount || 0
                        }));
                    const earnedXP = lineItems.reduce((s, i)=>s + i.xp, 0);
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            px: 3,
                            pb: 1
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$HomeworkXPSummary$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HomeworkXPSummary"], {
                            lineItems: lineItems,
                            totalXP: earnedXP,
                            cumulativeXP: totalXP
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                            lineNumber: 231,
                            columnNumber: 17
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                        lineNumber: 227,
                        columnNumber: 16
                    }, this);
                })(),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
                    sx: {
                        mx: 2
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                    lineNumber: 235,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: "flex",
                        flexDirection: "column",
                        gap: 1.5,
                        p: 3,
                        alignItems: "center"
                    },
                    children: [
                        retryEnabled && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            variant: "contained",
                            size: "large",
                            startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Replay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                                lineNumber: 246,
                                columnNumber: 80
                            }, this),
                            onClick: handleTryAgain,
                            disabled: retrying,
                            sx: {
                                width: "100%",
                                maxWidth: "400px"
                            },
                            children: retrying ? t("unitCompletedPlugin.retrying", "Starting new attempt...") : t("unitCompletedPlugin.tryAgain", "Try Again")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                            lineNumber: 246,
                            columnNumber: 28
                        }, this),
                        latestCompletedGrade && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PeerReview$2f$OpenPeerReviewButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OpenPeerReviewButton"], {
                            gradeId: latestCompletedGrade.id,
                            onCreateRoom: handleCreateRoom,
                            onRoomCreated: handleRoomCreated
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                            lineNumber: 253,
                            columnNumber: 36
                        }, this),
                        nextAssignment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            variant: "outlined",
                            size: "large",
                            endIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$NavigateNext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                                lineNumber: 255,
                                columnNumber: 79
                            }, this),
                            onClick: ()=>{
                                setShowUnitComplete(false);
                                router.push(`/workbook/${nextAssignment.unitID}`);
                            },
                            sx: {
                                width: "100%",
                                maxWidth: "400px"
                            },
                            children: t("unitCompletedPlugin.nextAssignment", "Next Assignment")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                            lineNumber: 255,
                            columnNumber: 30
                        }, this),
                        !nextAssignment && !retryEnabled && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "text.secondary",
                            sx: {
                                mt: 1
                            },
                            children: t("unitCompletedPlugin.allCaughtUp", "All caught up! No more assignments.")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                            lineNumber: 265,
                            columnNumber: 48
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
                    lineNumber: 239,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
            lineNumber: 116,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx",
        lineNumber: 100,
        columnNumber: 10
    }, this);
}
_s(UnitCompletedPlugin, "rDmY0GfO0qfeEJsXhqSiXjVoYo0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"]
    ];
});
_c = UnitCompletedPlugin;
var _c;
__turbopack_context__.k.register(_c, "UnitCompletedPlugin");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_Editor3_plugins_1c2gtat._.js.map