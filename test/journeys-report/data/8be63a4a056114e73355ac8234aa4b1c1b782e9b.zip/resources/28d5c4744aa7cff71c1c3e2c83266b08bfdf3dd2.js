(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/MeaningAssociationExercise/DndWrapper.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DndWrapper",
    ()=>DndWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/react-dnd-multi-backend/dist/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rdndmb$2d$html5$2d$to$2d$touch$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rdndmb-html5-to-touch/dist/index.js [app-client] (ecmascript)");
;
;
;
;
;
const DndWrapper = (t0)=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "3973eb49b5edac7705618c6803fd8c4c267d3780fced70ff212a2d1506d05f37") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "3973eb49b5edac7705618c6803fd8c4c267d3780fced70ff212a2d1506d05f37";
    }
    const { children } = t0;
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    let t1;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            display: "flex",
            flexDirection: "column",
            flex: "1 1 auto",
            minHeight: 0,
            overflow: "hidden"
        };
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    let t2;
    if ($[5] !== children) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DndProvider"], {
            options: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rdndmb$2d$html5$2d$to$2d$touch$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HTML5toTouch"],
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: t1,
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/MeaningAssociationExercise/DndWrapper.jsx",
                lineNumber: 55,
                columnNumber: 46
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/DndWrapper.jsx",
            lineNumber: 55,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[5] = children;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    return t2;
};
_c = DndWrapper;
var _c;
__turbopack_context__.k.register(_c, "DndWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/MeaningAssociationExercise/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "shuffle",
    ()=>shuffle
]);
/**
 * Simple seeded random number generator (Mulberry32)
 * @param {number} seed - Seed value
 * @returns {function(): number} Random number generator function
 */ function seededRandom(seed) {
    return function() {
        let t = seed += 0x6D2B79F5;
        t = Math.imul(t ^ t >>> 15, t | 1);
        t ^= t + Math.imul(t ^ t >>> 7, t | 61);
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}
function shuffle(array, seed) {
    const arrayCopy = [
        ...array
    ];
    let currentIndex = arrayCopy.length, randomIndex;
    const random = seed !== undefined ? seededRandom(seed) : Math.random;
    // While there remain elements to shuffle.
    while(currentIndex != 0){
        // Pick a remaining element.
        randomIndex = Math.floor(random() * currentIndex);
        currentIndex--;
        // And swap it with the current element.
        [arrayCopy[currentIndex], arrayCopy[randomIndex]] = [
            arrayCopy[randomIndex],
            arrayCopy[currentIndex]
        ];
    }
    return arrayCopy;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/MeaningAssociationExercise/DragBox.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DragBox",
    ()=>DragBox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrag$2f$useDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-dnd/dist/hooks/useDrag/useDrag.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
const onTouchMove = ()=>{
    window.navigator.vibrate(5);
};
const DragBox = (t0)=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    if ($[0] !== "6ac28517793876c2be98a564290e0dcfd82ddd76704407f5b2f33b332c159d11") {
        for(let $i = 0; $i < 11; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6ac28517793876c2be98a564290e0dcfd82ddd76704407f5b2f33b332c159d11";
    }
    const { answer, wordID } = t0;
    let t1;
    if ($[1] !== answer || $[2] !== wordID) {
        t1 = {
            type: "box",
            item: {
                answer,
                wordID
            },
            end: _temp,
            collect: _temp2
        };
        $[1] = answer;
        $[2] = wordID;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const [t2, drag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrag$2f$useDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrag"])(t1);
    const { isDragging } = t2;
    const opacity = isDragging ? 0.4 : 1;
    let t3;
    if ($[4] !== opacity) {
        t3 = {
            fontSize: "1.2rem",
            margin: ".3rem",
            padding: ".8rem",
            display: "inline-flex",
            cursor: "move",
            opacity,
            borderRadius: "8px",
            border: "2px dotted var(--mui-palette-primary-light)",
            backgroundColor: "var(--mui-palette-background-default)",
            color: "var(--mui-palette-primary-main)",
            fontWeight: 500,
            touchAction: "none",
            transition: "all 0.2s ease",
            width: "140px",
            minWidth: "140px",
            maxWidth: "140px",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "normal",
            wordBreak: "break-word",
            flexShrink: 0,
            justifyContent: "center",
            textAlign: "center",
            boxSizing: "border-box"
        };
        $[4] = opacity;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== answer || $[7] !== drag || $[8] !== t3 || $[9] !== wordID) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            className: "strokeorder",
            component: "div",
            ref: drag,
            variant: "outlined",
            boxShadow: "0 2px 4px var(--mui-palette-action-disabledBackground)",
            onTouchStart: onTouchMove,
            "data-testid": "drag-box",
            "data-word-id": wordID,
            "data-answer": answer,
            style: t3,
            children: answer
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/DragBox.jsx",
            lineNumber: 77,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[6] = answer;
        $[7] = drag;
        $[8] = t3;
        $[9] = wordID;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    return t4;
};
_s(DragBox, "Y0arsWXYe1/RlwFhDiDlbSHult0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrag$2f$useDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrag"]
    ];
});
_c = DragBox;
async function _temp(item, monitor) {
    const dropResult = monitor.getDropResult();
    if (item && dropResult) {
        if (item.wordID === dropResult.targetWordID) {
            console.log("Correct match! Dragged:", item.wordID, "Target:", dropResult.targetWordID);
            dropResult.correctAnswer.sendPass();
            await dropResult.correctAnswer.progressAssignment(item.wordID, dropResult.targetWordID);
        } else {
            console.log("Incorrect match! Dragged:", item.wordID, "Target:", dropResult.targetWordID);
            await dropResult.correctAnswer.sendFail(item.wordID, dropResult.targetWordID);
        }
    }
}
function _temp2(monitor_0) {
    return {
        isDragging: monitor_0.isDragging()
    };
}
var _c;
__turbopack_context__.k.register(_c, "DragBox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/MeaningAssociationExercise/Easy.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Easy",
    ()=>Easy
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/index.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DragBox$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/DragBox.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
const Easy = ({ tabIndex, setTabIndex, nodeKey, wordIDs })=>{
    _s();
    let [assignment, setAssignment] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [answers, setAnswers] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [filterEasy, setFilterEasy] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [verifiedAnswers, setVerifiedAnswers] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [completedEasy, setCompletedEasy] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](0);
    const [startPositionEasy, setStartPositionEasy] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](0);
    const [showCompletion, setShowCompletion] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const hasAutoShownCompletion = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    // Seed combines nodeKey with a per-mount random value so order
    // differs each visit but stays stable within the session
    const mountSeed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](Math.floor(Math.random() * 2147483647));
    const shuffleSeed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Easy.useMemo[shuffleSeed]": ()=>{
            let hash = mountSeed.current;
            const str = String(nodeKey) + "-easy";
            for(let i = 0; i < str.length; i++){
                hash = (hash << 5) - hash + str.charCodeAt(i);
                hash = hash & hash;
            }
            return Math.abs(hash);
        }
    }["Easy.useMemo[shuffleSeed]"], [
        nodeKey
    ]);
    const { wordMapId: dictionary } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Easy.useEffect": ()=>{
            // Use dictionary context instead of DataStore for Storybook compatibility
            const _vocabulary = wordIDs.map({
                "Easy.useEffect._vocabulary": (id)=>dictionary[id]
            }["Easy.useEffect._vocabulary"]).filter(Boolean);
            console.log("MeaningAssociationExercise._vocabulary", _vocabulary);
            setAssignment([
                ..._vocabulary
            ]);
            setAnswers([
                ..._vocabulary
            ]);
        }
    }["Easy.useEffect"], [
        wordIDs,
        dictionary
    ]);
    const { grade, saveGrade } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    // Parse grade.data if it's a string
    const gradeData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Easy.useMemo[gradeData]": ()=>{
            if (!grade?.data) return {};
            if (typeof grade.data === "string") {
                try {
                    return JSON.parse(grade.data);
                } catch (e) {
                    console.error("Failed to parse grade.data:", e);
                    return {};
                }
            }
            return grade.data;
        }
    }["Easy.useMemo[gradeData]"], [
        grade?.data
    ]);
    const inProgress = gradeData[nodeKey] || {};
    // Show completion screen once when exercise completes — don't re-show after dismiss
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Easy.useEffect": ()=>{
            const isComplete = inProgress?.easy?.complete;
            if (isComplete && !hasAutoShownCompletion.current) {
                hasAutoShownCompletion.current = true;
                setShowCompletion(true);
            }
        }
    }["Easy.useEffect"], [
        inProgress?.easy?.complete
    ]);
    console.log("Easy.nodeKey", nodeKey, "type:", typeof nodeKey);
    console.log("Easy.grade:", grade);
    console.log("Easy.grade.data:", grade?.data);
    console.log("Easy.grade.data === grade?", grade?.data === grade);
    console.log("Easy.grade.data keys:", grade?.data ? Object.keys(grade.data) : "no data");
    console.log("Easy.grade.data[nodeKey]:", grade?.data?.[nodeKey]);
    console.log("Easy.inProgress", inProgress);
    // Update progress state when grade data changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Easy.useEffect": ()=>{
            if (inProgress && Object.keys(inProgress).length > 0) {
                const verified = inProgress?.easy?.verifiedAnswers || [];
                const percentComplete = (inProgress?.easy?.percentComplete || 0) * 100;
                setFilterEasy(verified);
                setVerifiedAnswers(verified);
                setCompletedEasy(percentComplete);
                setStartPositionEasy(verified.length);
            }
        }
    }["Easy.useEffect"], [
        inProgress
    ]);
    // Stable shuffled orders — computed once when answers load, never reshuffled mid-exercise
    const shuffledWords = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Easy.useMemo[shuffledWords]": ()=>{
            if (answers.length === 0) return [];
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shuffle"])([
                ...answers
            ], shuffleSeed);
        }
    }["Easy.useMemo[shuffledWords]"], [
        answers,
        shuffleSeed
    ]);
    const shuffledDragOrder = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Easy.useMemo[shuffledDragOrder]": ()=>{
            if (answers.length === 0) return [];
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shuffle"])([
                ...answers
            ], shuffleSeed + 1);
        }
    }["Easy.useMemo[shuffledDragOrder]"], [
        answers,
        shuffleSeed
    ]);
    const shuffledDropOrder = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Easy.useMemo[shuffledDropOrder]": ()=>{
            if (answers.length === 0) return [];
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shuffle"])([
                ...answers
            ], shuffleSeed + 2);
        }
    }["Easy.useMemo[shuffledDropOrder]"], [
        answers,
        shuffleSeed
    ]);
    // Filter out matched cards from stable order — no reshuffling
    const easyVocab = shuffledDragOrder.filter((word)=>!filterEasy.includes(word?.id)).map((word_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DragBox$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragBox"], {
            answer: word_0.phrase,
            wordID: word_0.id
        }, word_0.id, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
            lineNumber: 111,
            columnNumber: 100
        }, ("TURBOPACK compile-time value", void 0)));
    // Find the first unmatched word in the stable shuffled order
    const correctAnswer = shuffledWords.find((word_1)=>!filterEasy.includes(word_1?.id));
    const currentQuestion = startPositionEasy;
    const percentComplete_0 = completedEasy;
    const loadAttemptedAnswers = inProgress?.easy?.attemptedAnswers || {};
    let _correctAnswer = "";
    // console.log('Easy.correctAnswer', correctAnswer)
    if (typeof correctAnswer === "string") {
        _correctAnswer = dictionary[correctAnswer];
    } else {
        _correctAnswer = correctAnswer;
    }
    // console.log('Easy._correctAnswer', _correctAnswer)
    const correctId = _correctAnswer?.id;
    const correctWord = _correctAnswer;
    // const attemptsCount = inProgress?.easy?.attemptsCount || 0;
    // const [attemptedAnswers, setAttemptedAnswers] = useState(loadAttemptedAnswers);
    const totalWords = shuffledWords.length;
    async function progressAssignment(draggedWordID, targetWordID) {
        // Verify the match is correct
        if (draggedWordID !== targetWordID) {
            console.error("Mismatch in Easy progressAssignment:", draggedWordID, targetWordID);
            return;
        }
        let newTab = tabIndex;
        let allTabsComplete = false;
        let thisExerciseComplete = false;
        let _verified = [
            ...new Set([
                ...verifiedAnswers,
                targetWordID
            ])
        ];
        let _attemptedAnswers = JSON.parse(JSON.stringify(loadAttemptedAnswers));
        if (typeof _attemptedAnswers[targetWordID] === "undefined") {
            _attemptedAnswers[targetWordID] = [];
        }
        _attemptedAnswers[targetWordID].push(draggedWordID);
        // for each array in attempted answers sum the lengths
        let attemptedAnswersLength = 0;
        Object.entries(_attemptedAnswers).forEach(([key, value])=>{
            attemptedAnswersLength += value.length;
        });
        const attempts = attemptedAnswersLength;
        // setAttemptedAnswers(_attemptedAnswers);
        // setAttemptsCount(attempts);
        // Check completion against the full word count, not filtered length
        if (_verified.length === totalWords) {
            // // console.log('newIndex === length')
            thisExerciseComplete = true;
            const completedHard = inProgress.hard?.complete;
            const completedLearn = inProgress.learn?.complete;
            if (completedHard && completedLearn) {
                allTabsComplete = true;
            }
        // Don't auto-advance, show completion screen instead
        // newTab++;
        }
        let savedGradeCopy = JSON.parse(JSON.stringify(gradeData));
        if (!savedGradeCopy[nodeKey]) {
            savedGradeCopy[nodeKey] = {
                easy: {}
            };
        }
        // console.log('easy _verified.length / length,', _verified.length, totalWords)
        savedGradeCopy[nodeKey]["easy"] = {
            verifiedAnswers: _verified,
            attemptedAnswers: _attemptedAnswers,
            attemptsCount: attempts,
            accuracy: _verified.length / attempts,
            percentComplete: _verified.length / totalWords,
            complete: thisExerciseComplete
        };
        if (allTabsComplete) {
            savedGradeCopy[nodeKey].complete = true;
        }
        savedGradeCopy[nodeKey].tabIndex = newTab;
        // Update local state immediately before saving to prevent reset
        setFilterEasy(_verified);
        setVerifiedAnswers(_verified);
        setStartPositionEasy(_verified.length);
        setCompletedEasy(_verified.length / totalWords * 100);
        await saveGrade(savedGradeCopy);
        // Show completion screen if exercise is complete
        if (thisExerciseComplete) {
            setShowCompletion(true);
        }
    }
    async function sendFail(draggedWordID_0, targetWordID_0) {
        let _attemptedAnswers_0 = JSON.parse(JSON.stringify(loadAttemptedAnswers));
        if (typeof _attemptedAnswers_0[targetWordID_0] === "undefined") {
            _attemptedAnswers_0[targetWordID_0] = [];
        }
        _attemptedAnswers_0[targetWordID_0].push(draggedWordID_0);
        // for each array in attempted answers sum the lengths
        let attemptedAnswersLength_0 = 0;
        Object.entries(_attemptedAnswers_0).forEach(([key_0, value_0])=>{
            attemptedAnswersLength_0 += value_0.length;
        });
        const attempts_0 = attemptedAnswersLength_0;
        // setAttemptsCount(attempts);
        let savedGradeCopy_0 = JSON.parse(JSON.stringify(gradeData));
        if (!savedGradeCopy_0[nodeKey]) {
            savedGradeCopy_0[nodeKey] = {
                easy: {}
            };
        }
        // console.log('easy verifiedAnswers.length / length,', verifiedAnswers.length, totalWords)
        // console.log('easy currentQuestion+1 / length', currentQuestion + 1, totalWords)
        savedGradeCopy_0[nodeKey]["easy"] = {
            ...savedGradeCopy_0[nodeKey]["easy"],
            attemptedAnswers: _attemptedAnswers_0,
            attemptsCount: attempts_0,
            accuracy: verifiedAnswers.length / attempts_0,
            percentComplete: currentQuestion / totalWords,
            complete: false
        };
        savedGradeCopy_0[nodeKey].tabIndex = 1;
        await saveGrade(savedGradeCopy_0);
    }
    function sendPass() {
        console.log("sendPass");
    }
    const handleContinueFromCompletion = ()=>{
        setShowCompletion(false);
        setTabIndex(2); // Move to Hard mode
    };
    const handleDismissCompletion = ()=>{
        setShowCompletion(false);
    };
    // Calculate min height based on drag card count: ~56px per row of cards (140px wide + margin),
    // estimate ~3 cards per row in the sidebar. Minimum 300px.
    const allCardRows = Math.ceil(shuffledDragOrder.length / 2);
    const dropZoneMinHeight = Math.max(300, allCardRows * 56);
    // Build result cards for completed state — check if word was matched on first try
    const resultCards = shuffledDragOrder.map((word_2)=>{
        const attempts_1 = loadAttemptedAnswers[word_2?.id] || [];
        // Passed if the first attempt was correct (word matched itself)
        const passed = attempts_1.length > 0 && attempts_1[0] === word_2?.id;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResultCard"], {
            phrase: word_2?.phrase,
            passed: passed,
            audioPaths: word_2?.audio
        }, word_2?.id, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
            lineNumber: 264,
            columnNumber: 12
        }, ("TURBOPACK compile-time value", void 0));
    });
    const accuracyPercent = Math.round(verifiedAnswers.length / (inProgress?.easy?.attemptsCount || 1) * 100);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            position: "relative",
            flex: "1 1 auto",
            minHeight: `${dropZoneMinHeight}px`,
            overflow: "auto",
            width: "100%",
            maxWidth: "100vw"
        },
        children: showCompletion ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                flexDirection: "column",
                height: "100%",
                width: "100%",
                maxWidth: "100%",
                gap: 1,
                overflow: "hidden"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexShrink: 0,
                        width: "100%"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinearProgressWithLabel"], {
                        value: 100
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                        lineNumber: 288,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                    lineNumber: 284,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexShrink: 0,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        px: 1
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "textSecondary",
                            children: [
                                "Easy Mode Complete — ",
                                accuracyPercent,
                                "% accuracy"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                            lineNumber: 297,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                gap: 1
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "outlined",
                                    size: "small",
                                    onClick: handleDismissCompletion,
                                    children: "Back"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                                    lineNumber: 304,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "contained",
                                    size: "small",
                                    onClick: handleContinueFromCompletion,
                                    children: "Continue to Hard Mode"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                                    lineNumber: 307,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                            lineNumber: 300,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                    lineNumber: 290,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: "flex",
                        flexDirection: {
                            xs: "column",
                            sm: "row"
                        },
                        flex: "1 1 auto",
                        minHeight: 0,
                        width: "100%",
                        maxWidth: "100%",
                        gap: 1,
                        overflow: "hidden"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                minWidth: 0,
                                flex: {
                                    xs: "0 0 auto",
                                    sm: "1 1 0"
                                },
                                minHeight: {
                                    xs: `${dropZoneMinHeight}px`,
                                    sm: `${dropZoneMinHeight}px`
                                },
                                maxWidth: {
                                    xs: "100%",
                                    sm: "66.666667%"
                                }
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    height: "100%",
                                    minHeight: `${dropZoneMinHeight}px`,
                                    display: "flex",
                                    borderRadius: "8px",
                                    border: "1px dashed var(--mui-palette-divider)",
                                    backgroundColor: "var(--mui-palette-action-disabledBackground)",
                                    alignItems: "center",
                                    justifyContent: "center"
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    color: "textSecondary",
                                    children: "Complete"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                                    lineNumber: 351,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                                lineNumber: 341,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                            lineNumber: 326,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                minWidth: 0,
                                flex: {
                                    xs: "1 1 auto",
                                    sm: "0 0 auto"
                                },
                                maxWidth: {
                                    xs: "100%",
                                    sm: "33.333333%"
                                }
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    flexWrap: "wrap",
                                    flexDirection: "row",
                                    gap: 0,
                                    height: {
                                        xs: "auto",
                                        sm: "100%"
                                    },
                                    minHeight: {
                                        xs: "auto",
                                        sm: `${dropZoneMinHeight}px`
                                    },
                                    overflowY: "auto",
                                    overflowX: "hidden",
                                    padding: 0.5,
                                    alignContent: "flex-start",
                                    justifyContent: "flex-start",
                                    width: "100%",
                                    maxWidth: "100%",
                                    boxSizing: "border-box"
                                },
                                children: resultCards
                            }, void 0, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                                lineNumber: 368,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                            lineNumber: 357,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                    lineNumber: 312,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
            lineNumber: 275,
            columnNumber: 25
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                flexDirection: "column",
                height: "100%",
                width: "100%",
                maxWidth: "100%",
                gap: 1,
                overflow: "hidden"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexShrink: 0,
                        width: "100%"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinearProgressWithLabel"], {
                        value: percentComplete_0
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                        lineNumber: 407,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                    lineNumber: 403,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: "flex",
                        flexDirection: {
                            xs: "column",
                            sm: "row"
                        },
                        flex: "1 1 auto",
                        minHeight: 0,
                        width: "100%",
                        maxWidth: "100%",
                        gap: 1,
                        overflow: "hidden"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                minWidth: 0,
                                flex: {
                                    xs: "0 0 auto",
                                    sm: "1 1 0"
                                },
                                minHeight: {
                                    xs: `${dropZoneMinHeight}px`,
                                    sm: `${dropZoneMinHeight}px`
                                },
                                maxWidth: {
                                    xs: "100%",
                                    sm: "66.666667%"
                                }
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    height: "100%",
                                    minHeight: `${dropZoneMinHeight}px`,
                                    display: "flex"
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnswerDrop"], {
                                    correctAnswer: {
                                        ...correctWord,
                                        progressAssignment,
                                        sendFail,
                                        sendPass
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                                    lineNumber: 443,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                                lineNumber: 438,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                            lineNumber: 423,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                minWidth: 0,
                                flex: {
                                    xs: "1 1 auto",
                                    sm: "0 0 auto"
                                },
                                maxWidth: {
                                    xs: "100%",
                                    sm: "33.333333%"
                                }
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    flexWrap: "wrap",
                                    flexDirection: "row",
                                    gap: 0,
                                    height: {
                                        xs: "auto",
                                        sm: "100%"
                                    },
                                    minHeight: {
                                        xs: "auto",
                                        sm: `${dropZoneMinHeight}px`
                                    },
                                    maxHeight: {
                                        xs: "none",
                                        sm: "100%"
                                    },
                                    overflowY: "auto",
                                    overflowX: "hidden",
                                    padding: 0.5,
                                    alignContent: "flex-start",
                                    justifyContent: {
                                        xs: "flex-start",
                                        sm: "flex-start"
                                    },
                                    width: "100%",
                                    maxWidth: "100%",
                                    boxSizing: "border-box"
                                },
                                children: easyVocab
                            }, void 0, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                                lineNumber: 463,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                            lineNumber: 452,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
                    lineNumber: 409,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
            lineNumber: 394,
            columnNumber: 18
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/MeaningAssociationExercise/Easy.jsx",
        lineNumber: 267,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Easy, "J2W/r69FSf9Qu4m68MxHadBhHYU=");
_c = Easy;
var _c;
__turbopack_context__.k.register(_c, "Easy");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/MeaningAssociationExercise/Hard.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Hard",
    ()=>Hard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DragBox$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/DragBox.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/index.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
const Hard = ({ nodeKey, tabIndex, setTabIndex, wordIDs })=>{
    _s();
    let [assignment, setAssignment] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [answers, setAnswers] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [length, setLength] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]();
    const [vocabulary, setVocabulary] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [filterHard, setFilterHard] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [completedHard, setCompletedHard] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](0);
    const [startPositionHard, setStartPositionHard] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](0);
    const [verifiedAnswers, setVerifiedAnswers] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [showCompletion, setShowCompletion] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const hasAutoShownCompletion = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    // Seed combines nodeKey with a per-mount random value so order
    // differs each visit but stays stable within the session
    const mountSeed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](Math.floor(Math.random() * 2147483647));
    const shuffleSeed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Hard.useMemo[shuffleSeed]": ()=>{
            let hash = mountSeed.current;
            const str = String(nodeKey) + '-hard';
            for(let i = 0; i < str.length; i++){
                hash = (hash << 5) - hash + str.charCodeAt(i);
                hash = hash & hash;
            }
            return Math.abs(hash);
        }
    }["Hard.useMemo[shuffleSeed]"], [
        nodeKey
    ]);
    const { wordMapId: dictionary } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Hard.useEffect": ()=>{
            // Use dictionary context instead of DataStore for Storybook compatibility
            const _vocabulary = wordIDs.map({
                "Hard.useEffect._vocabulary": (id)=>dictionary[id]
            }["Hard.useEffect._vocabulary"]).filter(Boolean);
            console.log('Hard._vocabulary', _vocabulary);
            setVocabulary(_vocabulary);
            setAssignment([
                ..._vocabulary
            ]);
            setAnswers([
                ..._vocabulary
            ]);
            setLength(_vocabulary.length);
        }
    }["Hard.useEffect"], [
        wordIDs,
        dictionary
    ]);
    const { grade, saveGrade } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    // Parse grade.data if it's a string
    const gradeData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Hard.useMemo[gradeData]": ()=>{
            if (!grade?.data) return {};
            if (typeof grade.data === 'string') {
                try {
                    return JSON.parse(grade.data);
                } catch (e) {
                    console.error('Failed to parse grade.data:', e);
                    return {};
                }
            }
            return grade.data;
        }
    }["Hard.useMemo[gradeData]"], [
        grade?.data
    ]);
    const inProgress = gradeData[nodeKey] || {};
    // Show completion screen once when exercise completes — don't re-show after dismiss
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Hard.useEffect": ()=>{
            const isComplete = inProgress?.hard?.complete;
            if (isComplete && !hasAutoShownCompletion.current) {
                hasAutoShownCompletion.current = true;
                setShowCompletion(true);
            }
        }
    }["Hard.useEffect"], [
        inProgress?.hard?.complete
    ]);
    // Update progress state when grade data changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Hard.useEffect": ()=>{
            if (inProgress && Object.keys(inProgress).length > 0) {
                const verified = inProgress?.hard?.verifiedAnswers || [];
                const percentComplete = (inProgress?.hard?.percentComplete || 0) * 100;
                setFilterHard(verified);
                setVerifiedAnswers(verified);
                setCompletedHard(percentComplete);
                setStartPositionHard(verified.length);
            }
        }
    }["Hard.useEffect"], [
        inProgress
    ]);
    // Stable shuffled orders — computed once when answers load, never reshuffled mid-exercise
    const shuffledWords = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Hard.useMemo[shuffledWords]": ()=>{
            if (answers.length === 0) return [];
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shuffle"])([
                ...answers
            ], shuffleSeed);
        }
    }["Hard.useMemo[shuffledWords]"], [
        answers,
        shuffleSeed
    ]);
    const shuffledDragOrder = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Hard.useMemo[shuffledDragOrder]": ()=>{
            if (answers.length === 0) return [];
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shuffle"])([
                ...answers
            ], shuffleSeed + 1);
        }
    }["Hard.useMemo[shuffledDragOrder]"], [
        answers,
        shuffleSeed
    ]);
    const shuffledDropOrder = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Hard.useMemo[shuffledDropOrder]": ()=>{
            if (answers.length === 0) return [];
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shuffle"])([
                ...answers
            ], shuffleSeed + 2);
        }
    }["Hard.useMemo[shuffledDropOrder]"], [
        answers,
        shuffleSeed
    ]);
    // Hard mode shows ALL drag chips (matched ones stay visible), drop target changes
    const hardVocabList = shuffledDragOrder.filter((word)=>word?.phrase).map((word_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DragBox$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragBox"], {
            answer: word_0.phrase,
            wordID: word_0.id
        }, word_0.id, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
            lineNumber: 108,
            columnNumber: 86
        }, ("TURBOPACK compile-time value", void 0)));
    // Find the first unmatched word in the stable shuffled order
    const correctAnswer = shuffledWords.find((word_1)=>!filterHard.includes(word_1?.id));
    const currentQuestion = startPositionHard;
    const percentComplete_0 = completedHard;
    const totalWords = shuffledWords.length;
    const loadAttemptedAnswers = inProgress?.hard?.attemptedAnswers || {};
    // const correctPhrase = correctAnswer?.phrase
    // If the type of correctAnswer is a string, then it is an Id and we need to look up the word
    let _correctAnswer = '';
    // console.log('Hard.correctAnswer', correctAnswer)
    // console.log('Hard.dictionary', dictionary)
    if (typeof correctAnswer === 'string') {
        _correctAnswer = dictionary[correctAnswer];
    } else {
        _correctAnswer = correctAnswer;
    }
    // console.log('Hard.correctAnswer', _correctAnswer)
    const correctId = _correctAnswer?.id;
    const correctWord = _correctAnswer;
    console.log('Hard.loadAttemptedAnswers', loadAttemptedAnswers);
    // const [attemptedAnswers, setAttemptedAnswers] = useState(loadAttemptedAnswers);
    async function progressAssignment(draggedWordID, targetWordID) {
        // Verify the match is correct
        if (draggedWordID !== targetWordID) {
            console.error('Mismatch in Hard progressAssignment:', draggedWordID, targetWordID);
            return;
        }
        let newTab = tabIndex;
        let allTabsComplete = false;
        let thisExerciseComplete = false;
        let _verified = [
            ...new Set([
                ...verifiedAnswers
            ])
        ];
        // Add to verified answers
        _verified.push(targetWordID);
        let _attemptedAnswers = JSON.parse(JSON.stringify(loadAttemptedAnswers));
        console.log('_attemptedAnswers', _attemptedAnswers);
        if (typeof _attemptedAnswers[targetWordID] === 'undefined') {
            _attemptedAnswers[targetWordID] = [];
        }
        console.log('_attemptedAnswers', _attemptedAnswers);
        _attemptedAnswers[targetWordID].push(draggedWordID);
        // for each array in attempted answers sum the lengths
        let attemptedAnswersLength = 0;
        Object.entries(_attemptedAnswers).forEach(([key, value])=>{
            attemptedAnswersLength += value.length;
        });
        const attempts = attemptedAnswersLength;
        console.log('Hard progress:', {
            verified: _verified.length,
            total: totalWords,
            attempts,
            attemptedAnswers: _attemptedAnswers
        });
        // Check completion against the full word count
        if (_verified.length === totalWords) {
            thisExerciseComplete = true;
            const completedEasy = inProgress.easy?.complete;
            const completedLearn = inProgress.learn?.complete;
            if (completedEasy && completedLearn) {
                allTabsComplete = true;
            }
        // Don't auto-advance, show completion screen instead
        // newTab = 0;
        }
        let savedGradeCopy = JSON.parse(JSON.stringify(gradeData));
        if (!savedGradeCopy[nodeKey]) {
            savedGradeCopy[nodeKey] = {
                'hard': {}
            };
        }
        savedGradeCopy[nodeKey]['hard'] = {
            verifiedAnswers: _verified,
            attemptedAnswers: _attemptedAnswers,
            attemptsCount: attempts,
            accuracy: _verified.length / attempts,
            percentComplete: _verified.length / totalWords,
            complete: thisExerciseComplete
        };
        if (allTabsComplete) {
            savedGradeCopy[nodeKey].complete = true;
        }
        savedGradeCopy[nodeKey].tabIndex = newTab; //Go back to beginning? TODO Follow up with a success page
        // Update local state immediately before saving to prevent reset
        setFilterHard(_verified);
        setVerifiedAnswers(_verified);
        setStartPositionHard(_verified.length);
        setCompletedHard(_verified.length / totalWords * 100);
        await saveGrade(savedGradeCopy);
        // Show completion screen if exercise is complete
        if (thisExerciseComplete) {
            setShowCompletion(true);
        }
    }
    async function sendFail(draggedWordID_0, targetWordID_0) {
        let _attemptedAnswers_0 = JSON.parse(JSON.stringify(loadAttemptedAnswers));
        console.log('sendFail._attemptedAnswers', _attemptedAnswers_0);
        if (typeof _attemptedAnswers_0[targetWordID_0] === 'undefined') {
            _attemptedAnswers_0[targetWordID_0] = [];
        }
        _attemptedAnswers_0[targetWordID_0].push(draggedWordID_0);
        // for each array in attempted answers sum the lengths
        let attemptedAnswersLength_0 = 0;
        Object.entries(_attemptedAnswers_0).forEach(([key_0, value_0])=>{
            attemptedAnswersLength_0 += value_0.length;
        });
        const attempts_0 = attemptedAnswersLength_0;
        let newTab_0 = tabIndex;
        let savedGradeCopy_0 = JSON.parse(JSON.stringify(gradeData));
        if (!savedGradeCopy_0[nodeKey]) {
            savedGradeCopy_0[nodeKey] = {
                'hard': {}
            };
        }
        savedGradeCopy_0[nodeKey]['hard'] = {
            ...savedGradeCopy_0[nodeKey]['hard'],
            attemptedAnswers: _attemptedAnswers_0,
            attemptsCount: attempts_0,
            accuracy: verifiedAnswers.length / attempts_0,
            percentComplete: currentQuestion / totalWords,
            complete: false
        };
        savedGradeCopy_0[nodeKey].tabIndex = newTab_0;
        await saveGrade(savedGradeCopy_0);
    }
    function sendPass() {
    // // console.log('sendPass')
    }
    const handleContinueFromCompletion = ()=>{
        setShowCompletion(false);
        setTabIndex(0); // Go back to Learn mode or could show final completion
    };
    const handleDismissCompletion = ()=>{
        setShowCompletion(false);
    };
    // Check if all exercises are complete
    const allComplete = inProgress?.easy?.complete && inProgress?.learn?.complete;
    // Calculate min height: hard shows ALL cards (matched stay visible), ~56px per row of ~2 cards
    const cardRows = Math.ceil(hardVocabList.length / 2);
    const dropZoneMinHeight = Math.max(300, cardRows * 56);
    // Build result cards for completed state
    const resultCards = shuffledDragOrder.filter((word_2)=>word_2?.phrase).map((word_3)=>{
        const attempts_1 = loadAttemptedAnswers[word_3?.id] || [];
        const passed = attempts_1.length > 0 && attempts_1[0] === word_3?.id;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResultCard"], {
            phrase: word_3?.phrase,
            passed: passed,
            audioPaths: word_3?.audio
        }, word_3?.id, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
            lineNumber: 266,
            columnNumber: 12
        }, ("TURBOPACK compile-time value", void 0));
    });
    const accuracyPercent = Math.round(verifiedAnswers.length / (inProgress?.hard?.attemptsCount || 1) * 100);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            position: 'relative',
            flex: '1 1 auto',
            minHeight: `${dropZoneMinHeight}px`,
            overflow: 'auto',
            width: '100%',
            maxWidth: '100vw'
        },
        children: showCompletion ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: 'flex',
                flexDirection: 'column',
                height: '100%',
                width: '100%',
                maxWidth: '100%',
                gap: 1,
                overflow: 'hidden'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexShrink: 0,
                        width: '100%'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinearProgressWithLabel"], {
                        value: 100
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                        lineNumber: 290,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                    lineNumber: 286,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexShrink: 0,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        px: 1,
                        flexWrap: 'wrap',
                        gap: 1
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "textSecondary",
                            children: [
                                "Hard Mode Complete — ",
                                accuracyPercent,
                                "% accuracy"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                            lineNumber: 301,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: 'flex',
                                gap: 1
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "outlined",
                                    size: "small",
                                    onClick: handleDismissCompletion,
                                    children: "Back"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                                    lineNumber: 308,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                allComplete ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "contained",
                                    color: "success",
                                    size: "small",
                                    onClick: handleContinueFromCompletion,
                                    children: "Finish Exercise"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                                    lineNumber: 309,
                                    columnNumber: 28
                                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "contained",
                                    size: "small",
                                    onClick: handleContinueFromCompletion,
                                    children: "Continue to Learn Mode"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                                    lineNumber: 309,
                                    columnNumber: 151
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                            lineNumber: 304,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                    lineNumber: 292,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: 'flex',
                        flexDirection: {
                            xs: 'column',
                            sm: 'row'
                        },
                        flex: '1 1 auto',
                        minHeight: 0,
                        width: '100%',
                        maxWidth: '100%',
                        gap: 1,
                        overflow: 'hidden'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                minWidth: 0,
                                flex: {
                                    xs: '0 0 auto',
                                    sm: '1 1 0'
                                },
                                minHeight: {
                                    xs: `${dropZoneMinHeight}px`,
                                    sm: `${dropZoneMinHeight}px`
                                },
                                maxWidth: {
                                    xs: '100%',
                                    sm: '66.666667%'
                                }
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    height: '100%',
                                    minHeight: `${dropZoneMinHeight}px`,
                                    display: 'flex',
                                    borderRadius: '8px',
                                    border: '1px dashed var(--mui-palette-divider)',
                                    backgroundColor: 'var(--mui-palette-action-disabledBackground)',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    color: "textSecondary",
                                    children: "Complete"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                                    lineNumber: 351,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                                lineNumber: 341,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                            lineNumber: 326,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                minWidth: 0,
                                flex: {
                                    xs: '1 1 auto',
                                    sm: '0 0 auto'
                                },
                                maxWidth: {
                                    xs: '100%',
                                    sm: '33.333333%'
                                }
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: 'flex',
                                    flexWrap: 'wrap',
                                    flexDirection: 'row',
                                    gap: 0,
                                    height: {
                                        xs: 'auto',
                                        sm: '100%'
                                    },
                                    minHeight: {
                                        xs: 'auto',
                                        sm: `${dropZoneMinHeight}px`
                                    },
                                    overflowY: 'auto',
                                    overflowX: 'hidden',
                                    padding: 0.5,
                                    alignContent: 'flex-start',
                                    justifyContent: 'flex-start',
                                    width: '100%',
                                    maxWidth: '100%',
                                    boxSizing: 'border-box'
                                },
                                children: resultCards
                            }, void 0, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                                lineNumber: 366,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                            lineNumber: 355,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                    lineNumber: 312,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
            lineNumber: 277,
            columnNumber: 25
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: 'flex',
                flexDirection: 'column',
                height: '100%',
                width: '100%',
                maxWidth: '100%',
                gap: 1,
                overflow: 'hidden'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexShrink: 0,
                        width: '100%'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinearProgressWithLabel"], {
                        value: percentComplete_0
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                        lineNumber: 405,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                    lineNumber: 401,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: 'flex',
                        flexDirection: {
                            xs: 'column',
                            sm: 'row'
                        },
                        flex: '1 1 auto',
                        minHeight: 0,
                        width: '100%',
                        maxWidth: '100%',
                        gap: 1,
                        overflow: 'hidden'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                minWidth: 0,
                                flex: {
                                    xs: '0 0 auto',
                                    sm: '1 1 0'
                                },
                                minHeight: {
                                    xs: `${dropZoneMinHeight}px`,
                                    sm: `${dropZoneMinHeight}px`
                                },
                                maxWidth: {
                                    xs: '100%',
                                    sm: '66.666667%'
                                }
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    height: '100%',
                                    minHeight: `${dropZoneMinHeight}px`,
                                    display: 'flex'
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnswerDrop"], {
                                    correctAnswer: {
                                        ...correctWord,
                                        progressAssignment,
                                        sendFail,
                                        sendPass
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                                    lineNumber: 441,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                                lineNumber: 436,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                            lineNumber: 421,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                minWidth: 0,
                                flex: {
                                    xs: '1 1 auto',
                                    sm: '0 0 auto'
                                },
                                maxWidth: {
                                    xs: '100%',
                                    sm: '33.333333%'
                                }
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: 'flex',
                                    flexWrap: 'wrap',
                                    flexDirection: 'row',
                                    gap: 0,
                                    height: {
                                        xs: 'auto',
                                        sm: '100%'
                                    },
                                    minHeight: {
                                        xs: 'auto',
                                        sm: `${dropZoneMinHeight}px`
                                    },
                                    maxHeight: {
                                        xs: 'none',
                                        sm: '100%'
                                    },
                                    overflowY: 'auto',
                                    overflowX: 'hidden',
                                    padding: 0.5,
                                    alignContent: 'flex-start',
                                    justifyContent: {
                                        xs: 'flex-start',
                                        sm: 'flex-start'
                                    },
                                    width: '100%',
                                    maxWidth: '100%',
                                    boxSizing: 'border-box'
                                },
                                children: hardVocabList
                            }, void 0, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                                lineNumber: 461,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                            lineNumber: 450,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
                    lineNumber: 407,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
            lineNumber: 392,
            columnNumber: 16
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/MeaningAssociationExercise/Hard.jsx",
        lineNumber: 269,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Hard, "TFz9+k+0hjdnDqMF+37uXjWaAlk=");
_c = Hard;
var _c;
__turbopack_context__.k.register(_c, "Hard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/MeaningAssociationExercise/Learn.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Learn",
    ()=>Learn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronLeft$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ChevronLeft.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ChevronRight.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/index.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DragBox$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/DragBox.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/utils.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
const Learn = ({ tabIndex, setTabIndex, nodeKey, wordIDs })=>{
    _s();
    const [answers, setAnswers] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [length, setLength] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]();
    const [vocabulary, setVocabulary] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    let [assignment, setAssignment] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [filterLearn, setFilterLearn] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [completedLearn, setCompletedLearn] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](0);
    const [startPositionLearn, setStartPositionLearn] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](0);
    const [dropAnswerVisibility, setDropAnswerVisibility] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [droppedPairs, setDroppedPairs] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({}); // Track which answer was dropped on which target
    const [showCompletion, setShowCompletion] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const hasAutoShownCompletion = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    // Seed combines nodeKey with a per-mount random value so order
    // differs each visit but stays stable within the session
    const mountSeed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](Math.floor(Math.random() * 2147483647));
    const shuffleSeed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Learn.useMemo[shuffleSeed]": ()=>{
            let hash = mountSeed.current;
            const str = String(nodeKey) + '-learn';
            for(let i = 0; i < str.length; i++){
                hash = (hash << 5) - hash + str.charCodeAt(i);
                hash = hash & hash;
            }
            return Math.abs(hash);
        }
    }["Learn.useMemo[shuffleSeed]"], [
        nodeKey
    ]);
    const { wordMapId: dictionary } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Learn.useEffect": ()=>{
            // Use dictionary context instead of DataStore for Storybook compatibility
            const _vocabulary = wordIDs.map({
                "Learn.useEffect._vocabulary": (id)=>dictionary[id]
            }["Learn.useEffect._vocabulary"]).filter(Boolean);
            console.log('Learn._vocabulary', _vocabulary);
            setVocabulary(_vocabulary);
            setAssignment([
                ..._vocabulary
            ]);
            setAnswers([
                ..._vocabulary
            ]);
            setLength(_vocabulary.length);
        }
    }["Learn.useEffect"], [
        wordIDs,
        dictionary
    ]);
    const { grade, saveGrade } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const gradeData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Learn.useMemo[gradeData]": ()=>{
            if (!grade?.data) return {};
            if (typeof grade.data === 'string') {
                try {
                    return JSON.parse(grade.data);
                } catch  {
                    return {};
                }
            }
            return grade.data;
        }
    }["Learn.useMemo[gradeData]"], [
        grade?.data
    ]);
    const inProgress = gradeData[nodeKey] || {};
    // Show completion screen once when exercise completes — don't re-show after dismiss
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Learn.useEffect": ()=>{
            const isComplete = inProgress?.learn?.complete;
            if (isComplete && !hasAutoShownCompletion.current) {
                hasAutoShownCompletion.current = true;
                setShowCompletion(true);
            }
        }
    }["Learn.useEffect"], [
        inProgress?.learn?.complete
    ]);
    // Update progress state when grade data changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Learn.useEffect": ()=>{
            if (inProgress && Object.keys(inProgress).length > 0) {
                const verified = inProgress?.learn?.verifiedAnswers || [];
                const percentComplete = (inProgress?.learn?.percentComplete || 0) * 100;
                const pairs = inProgress?.learn?.droppedPairs || {};
                setFilterLearn(verified);
                setCompletedLearn(percentComplete);
                setStartPositionLearn(verified.length);
                setDropAnswerVisibility(verified);
                setDroppedPairs(pairs);
            }
        }
    }["Learn.useEffect"], [
        inProgress
    ]);
    // Stable shuffled orders — computed once when answers load, never reshuffled mid-exercise
    const stableAssignment = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Learn.useMemo[stableAssignment]": ()=>{
            if (answers.length === 0) return [];
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shuffle"])([
                ...answers
            ], shuffleSeed + 2);
        }
    }["Learn.useMemo[stableAssignment]"], [
        answers,
        shuffleSeed
    ]);
    const shuffledDragOrder = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Learn.useMemo[shuffledDragOrder]": ()=>{
            if (answers.length === 0) return [];
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shuffle"])([
                ...answers
            ], shuffleSeed + 1);
        }
    }["Learn.useMemo[shuffledDragOrder]"], [
        answers,
        shuffleSeed
    ]);
    // Filter out matched cards from stable drag order — no reshuffling
    const easyVocab = shuffledDragOrder.filter((word)=>!filterLearn.includes(word?.id)).map((word_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DragBox$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragBox"], {
            answer: word_0.phrase,
            wordID: word_0.id
        }, word_0.id, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
            lineNumber: 104,
            columnNumber: 101
        }, ("TURBOPACK compile-time value", void 0)));
    const easyAssignment = stableAssignment;
    const verifiedAnswers = filterLearn;
    const percentComplete_0 = completedLearn;
    const totalWords = stableAssignment.length;
    const currentQuestion = startPositionLearn;
    const loadAttemptedAnswers = inProgress?.learn?.attemptedAnswers || {};
    const attemptsCount = inProgress?.learn?.attemptsCount || 0;
    async function progressAssignment(draggedWordID, targetWordID) {
        // Verify the match is correct
        if (draggedWordID !== targetWordID) {
            console.error('Mismatch in progressAssignment:', draggedWordID, targetWordID);
            return;
        }
        const newIndex = verifiedAnswers.length + 1;
        let newTab = tabIndex;
        let allTabsComplete = false;
        let thisExerciseComplete = false;
        // Use the current state values
        // Track which answer was dropped on which target
        let _droppedPairs = {
            ...droppedPairs
        };
        _droppedPairs[targetWordID] = draggedWordID; // Store the dropped wordID for this target
        // Add correctly matched wordID to verified list
        const _verified = [
            ...new Set([
                ...verifiedAnswers,
                targetWordID
            ])
        ];
        // Add to attempted answers
        let _attemptedAnswers = JSON.parse(JSON.stringify(loadAttemptedAnswers));
        if (typeof _attemptedAnswers[targetWordID] === 'undefined') {
            _attemptedAnswers[targetWordID] = [];
        }
        _attemptedAnswers[targetWordID].push(draggedWordID);
        const attempts = attemptsCount + 1;
        if (_verified.length === totalWords) {
            thisExerciseComplete = true;
            // check for top level complete, all assignments are completed
            const completedEasy = inProgress.easy?.complete;
            const completedHard = inProgress.hard?.complete;
            if (completedEasy && completedHard) {
                allTabsComplete = true;
            }
        // Don't auto-advance, show completion screen instead
        // newTab++;
        }
        // Handle grade.data - it might be a string or object
        let gradeData_0 = grade?.data || {};
        if (typeof gradeData_0 === 'string') {
            try {
                gradeData_0 = JSON.parse(gradeData_0);
            } catch (e) {
                gradeData_0 = {};
            }
        }
        let savedGradeCopy = JSON.parse(JSON.stringify(gradeData_0));
        if (!savedGradeCopy[nodeKey]) {
            savedGradeCopy[nodeKey] = {
                'learn': {}
            };
        }
        savedGradeCopy[nodeKey]['learn'] = {
            verifiedAnswers: _verified,
            attemptedAnswers: _attemptedAnswers,
            attemptsCount: attempts,
            accuracy: _verified.length / attempts,
            percentComplete: newIndex / totalWords,
            complete: thisExerciseComplete,
            droppedPairs: _droppedPairs
        };
        if (allTabsComplete) {
            savedGradeCopy[nodeKey].complete = true;
        }
        savedGradeCopy[nodeKey].tabIndex = newTab;
        // Update local state immediately before saving to prevent reset
        setFilterLearn(_verified);
        setStartPositionLearn(_verified.length);
        setCompletedLearn(newIndex / totalWords * 100);
        setDroppedPairs(_droppedPairs);
        await saveGrade(savedGradeCopy);
        // Show completion screen if exercise is complete
        if (thisExerciseComplete) {
            setShowCompletion(true);
        }
    }
    async function sendFail(draggedWordID_0, targetWordID_0) {
        let _attemptedAnswers_0 = JSON.parse(JSON.stringify(loadAttemptedAnswers));
        if (typeof _attemptedAnswers_0[targetWordID_0] === 'undefined') {
            _attemptedAnswers_0[targetWordID_0] = [];
        }
        _attemptedAnswers_0[targetWordID_0].push(draggedWordID_0);
        const attempts_0 = attemptsCount + 1;
        // Handle grade.data - it might be a string or object
        let gradeData_1 = grade?.data || {};
        if (typeof gradeData_1 === 'string') {
            try {
                gradeData_1 = JSON.parse(gradeData_1);
            } catch (e_0) {
                gradeData_1 = {};
            }
        }
        let savedGradeCopy_0 = JSON.parse(JSON.stringify(gradeData_1));
        if (!savedGradeCopy_0[nodeKey]) {
            savedGradeCopy_0[nodeKey] = {
                'learn': {}
            };
        }
        savedGradeCopy_0[nodeKey]['learn'] = {
            ...savedGradeCopy_0[nodeKey]['learn'],
            attemptedAnswers: _attemptedAnswers_0,
            attemptsCount: attempts_0,
            accuracy: verifiedAnswers.length / attempts_0,
            percentComplete: currentQuestion / totalWords,
            complete: false,
            tabIndex
        };
        savedGradeCopy_0[nodeKey].tabIndex = 0;
        console.log('Learn savedGradeCopy', savedGradeCopy_0);
        await saveGrade(savedGradeCopy_0);
    }
    function sendPass() {
    // // // console.log('sendPass')
    }
    const handleContinueFromCompletion = ()=>{
        setShowCompletion(false);
        setTabIndex(1); // Move to Easy mode
    };
    const handleDismissCompletion = ()=>{
        setShowCompletion(false);
    };
    // Calculate min height based on card count: ~70px per drop target, minimum 300px
    const dropZoneMinHeight = Math.max(300, easyAssignment.length * 70);
    // Carousel scroll for small screens
    const carouselRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const scrollCarousel = (direction)=>{
        if (carouselRef.current) {
            const scrollAmount = 240;
            carouselRef.current.scrollBy({
                left: direction * scrollAmount,
                behavior: 'smooth'
            });
        }
    };
    const accuracyPercent = Math.round(dropAnswerVisibility.length / (inProgress?.learn?.attemptsCount || 1) * 100);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            position: 'relative',
            flex: '1 1 auto',
            minHeight: `${dropZoneMinHeight}px`,
            overflow: 'auto',
            width: '100%',
            maxWidth: '100vw'
        },
        children: showCompletion ? /* Completed state: show all drop targets as a full list with pass/fail marks */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: 'flex',
                flexDirection: 'column',
                height: '100%',
                width: '100%',
                maxWidth: '100%',
                gap: 1,
                overflow: 'hidden'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexShrink: 0,
                        width: '100%'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinearProgressWithLabel"], {
                        value: 100
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                        lineNumber: 278,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                    lineNumber: 274,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexShrink: 0,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        px: 1,
                        flexWrap: 'wrap',
                        gap: 1
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "textSecondary",
                            children: [
                                "Learn Mode Complete — ",
                                accuracyPercent,
                                "% accuracy"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                            lineNumber: 289,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: 'flex',
                                gap: 1
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "outlined",
                                    size: "small",
                                    onClick: handleDismissCompletion,
                                    children: "Back"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                    lineNumber: 296,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "contained",
                                    size: "small",
                                    onClick: handleContinueFromCompletion,
                                    children: "Continue to Easy Mode"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                    lineNumber: 297,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                            lineNumber: 292,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                    lineNumber: 280,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flex: '1 1 auto',
                        minHeight: 0,
                        overflowY: 'auto',
                        overflowX: 'hidden',
                        width: '100%'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                        sx: {
                            padding: 0
                        },
                        children: easyAssignment.map((listItem)=>{
                            let _correctWord = typeof listItem === 'string' ? dictionary[listItem] : listItem;
                            const matchedWordId = droppedPairs[_correctWord?.id];
                            const matchedWord = matchedWordId ? dictionary[matchedWordId] : null;
                            // Determine pass/fail: passed if matched on first attempt
                            const attempts_1 = loadAttemptedAnswers[_correctWord?.id] || [];
                            const passed = attempts_1.length > 0 && attempts_1[0] === _correctWord?.id;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResultDropLearn"], {
                                pronunciation: _correctWord?.pronunciation,
                                definition: _correctWord?.definition,
                                matchedWord: matchedWord || _correctWord,
                                passed: passed,
                                audioPaths: _correctWord?.audio,
                                definitionAudioPaths: _correctWord?.definitionAudio
                            }, _correctWord?.id, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                lineNumber: 317,
                                columnNumber: 20
                            }, ("TURBOPACK compile-time value", void 0));
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                        lineNumber: 307,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                    lineNumber: 300,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
            lineNumber: 265,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: 'flex',
                flexDirection: 'column',
                height: '100%',
                width: '100%',
                maxWidth: '100%',
                gap: 1,
                overflow: 'hidden'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexShrink: 0,
                        width: '100%'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinearProgressWithLabel"], {
                        value: percentComplete_0
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                        lineNumber: 334,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                    lineNumber: 330,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: 'flex',
                        flexDirection: {
                            xs: 'column',
                            sm: 'row'
                        },
                        flex: '1 1 auto',
                        minHeight: 0,
                        width: '100%',
                        maxWidth: '100%',
                        gap: 1,
                        overflow: 'hidden'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                minWidth: 0,
                                flex: {
                                    xs: '0 0 auto',
                                    sm: '1 1 0'
                                },
                                minHeight: {
                                    xs: 'auto',
                                    sm: `${dropZoneMinHeight}px`
                                },
                                maxWidth: {
                                    xs: '100%',
                                    sm: '66.666667%'
                                },
                                order: {
                                    xs: 1,
                                    sm: 1
                                }
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        display: {
                                            xs: 'flex',
                                            sm: 'none'
                                        },
                                        alignItems: 'center',
                                        width: '100%'
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                            size: "small",
                                            onClick: ()=>scrollCarousel(-1),
                                            sx: {
                                                flexShrink: 0
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronLeft$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                                lineNumber: 381,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                            lineNumber: 378,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            ref: carouselRef,
                                            sx: {
                                                flex: 1,
                                                overflowX: 'auto',
                                                overflowY: 'hidden',
                                                display: 'flex',
                                                flexDirection: 'row',
                                                gap: 1,
                                                scrollSnapType: 'x mandatory',
                                                '&::-webkit-scrollbar': {
                                                    display: 'none'
                                                },
                                                scrollbarWidth: 'none',
                                                py: 0.5
                                            },
                                            children: easyAssignment.map((listItem_0)=>{
                                                let _correctWord_0 = typeof listItem_0 === 'string' ? dictionary[listItem_0] : listItem_0;
                                                const matchedWordId_0 = droppedPairs[_correctWord_0?.id];
                                                const matchedWord_0 = matchedWordId_0 ? dictionary[matchedWordId_0] : null;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        scrollSnapAlign: 'start',
                                                        flexShrink: 0
                                                    },
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnswerDropLearn"], {
                                                        id: _correctWord_0?.id,
                                                        correctAnswer: {
                                                            ..._correctWord_0,
                                                            progressAssignment,
                                                            sendFail,
                                                            sendPass
                                                        },
                                                        pronunciation: _correctWord_0?.pronunciation,
                                                        definition: _correctWord_0?.definition,
                                                        phrase: _correctWord_0?.phrase,
                                                        matchedWord: matchedWord_0,
                                                        isMatched: !!matchedWordId_0,
                                                        audioPaths: _correctWord_0?.audio,
                                                        definitionAudioPaths: _correctWord_0?.definitionAudio
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                                        lineNumber: 405,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, _correctWord_0?.id, false, {
                                                    fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                                    lineNumber: 401,
                                                    columnNumber: 24
                                                }, ("TURBOPACK compile-time value", void 0));
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                            lineNumber: 383,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                            size: "small",
                                            onClick: ()=>scrollCarousel(1),
                                            sx: {
                                                flexShrink: 0
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                                lineNumber: 417,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                            lineNumber: 414,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                    lineNumber: 370,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        display: {
                                            xs: 'none',
                                            sm: 'block'
                                        },
                                        height: '100%',
                                        minHeight: `${dropZoneMinHeight}px`,
                                        overflowY: 'auto',
                                        overflowX: 'hidden'
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                        sx: {
                                            padding: 0
                                        },
                                        children: easyAssignment.map((listItem_1)=>{
                                            let _correctWord_1 = typeof listItem_1 === 'string' ? dictionary[listItem_1] : listItem_1;
                                            const matchedWordId_1 = droppedPairs[_correctWord_1?.id];
                                            const matchedWord_1 = matchedWordId_1 ? dictionary[matchedWordId_1] : null;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnswerDropLearn"], {
                                                id: _correctWord_1?.id,
                                                correctAnswer: {
                                                    ..._correctWord_1,
                                                    progressAssignment,
                                                    sendFail,
                                                    sendPass
                                                },
                                                pronunciation: _correctWord_1?.pronunciation,
                                                definition: _correctWord_1?.definition,
                                                phrase: _correctWord_1?.phrase,
                                                matchedWord: matchedWord_1,
                                                isMatched: !!matchedWordId_1,
                                                audioPaths: _correctWord_1?.audio,
                                                definitionAudioPaths: _correctWord_1?.definitionAudio
                                            }, _correctWord_1?.id, false, {
                                                fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                                lineNumber: 438,
                                                columnNumber: 24
                                            }, ("TURBOPACK compile-time value", void 0));
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                        lineNumber: 431,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                    lineNumber: 421,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                            lineNumber: 350,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                minWidth: 0,
                                flex: {
                                    xs: '1 1 auto',
                                    sm: '0 0 auto'
                                },
                                maxWidth: {
                                    xs: '100%',
                                    sm: '33.333333%'
                                },
                                order: {
                                    xs: 2,
                                    sm: 2
                                }
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: 'flex',
                                    flexWrap: 'wrap',
                                    flexDirection: 'row',
                                    gap: 0,
                                    height: {
                                        xs: 'auto',
                                        sm: '100%'
                                    },
                                    minHeight: {
                                        xs: 'auto',
                                        sm: `${dropZoneMinHeight}px`
                                    },
                                    maxHeight: {
                                        xs: 'none',
                                        sm: '100%'
                                    },
                                    overflowY: 'auto',
                                    overflowX: 'hidden',
                                    padding: 0.5,
                                    width: '100%',
                                    maxWidth: '100%',
                                    alignContent: 'flex-start',
                                    justifyContent: {
                                        xs: 'flex-start',
                                        sm: 'flex-start'
                                    },
                                    boxSizing: 'border-box'
                                },
                                children: easyVocab
                            }, void 0, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                                lineNumber: 464,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                            lineNumber: 449,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
                    lineNumber: 336,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
            lineNumber: 321,
            columnNumber: 17
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/MeaningAssociationExercise/Learn.jsx",
        lineNumber: 256,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Learn, "4z2fE5aWxsxx7SyHdDxOb+v0thU=");
_c = Learn;
var _c;
__turbopack_context__.k.register(_c, "Learn");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/MeaningAssociationExercise/index.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnswerDrop",
    ()=>AnswerDrop,
    "AnswerDropLearn",
    ()=>AnswerDropLearn,
    "LinearProgressWithLabel",
    ()=>LinearProgressWithLabel,
    "PlayAudioButton",
    ()=>PlayAudioButton,
    "ResultCard",
    ()=>ResultCard,
    "ResultDropLearn",
    ()=>ResultDropLearn,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @module MeaningAssociationExercise
 * @category Components
 * @description MeaningAssociationExercise component
 *
 * MeaningAssociationExercise component for the app.
 *
 * This component is a game where the user has to match the words with their
 * meanings. The user can listen to the words by clicking on the play button.
 *
 *
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-dnd/dist/hooks/useDrop/useDrop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tabs/Tabs.js [app-client] (ecmascript) <export default as Tabs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tab/Tab.js [app-client] (ecmascript) <export default as Tab>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AppBar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AppBar/AppBar.js [app-client] (ecmascript) <export default as AppBar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Cancel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Cancel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$VolumeUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/VolumeUp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$Easy$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/Easy.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$Hard$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/Hard.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$Learn$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/Learn.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DndWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/DndWrapper.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function LinearProgressWithLabel(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d";
    }
    let t0;
    if ($[1] !== props) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            flex: 1,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                variant: "determinate",
                ...props
            }, void 0, false, {
                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                lineNumber: 38,
                columnNumber: 24
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 38,
            columnNumber: 10
        }, this);
        $[1] = props;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    let t1;
    if ($[3] !== props.value) {
        t1 = Math.round(props.value);
        $[3] = props.value;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    const t2 = `${t1}%`;
    let t3;
    if ($[5] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            width: "fit-content",
            marginLeft: 1,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                color: "textSecondary",
                children: t2
            }, void 0, false, {
                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                lineNumber: 55,
                columnNumber: 50
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 55,
            columnNumber: 10
        }, this);
        $[5] = t2;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== t0 || $[8] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            display: "flex",
            alignItems: "center",
            children: [
                t0,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 63,
            columnNumber: 10
        }, this);
        $[7] = t0;
        $[8] = t3;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    return t4;
}
_c = LinearProgressWithLabel;
const PlayAudioButton = (t0)=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d";
    }
    const { audioPaths, size: t1 } = t0;
    const size = t1 === undefined ? "small" : t1;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("common");
    const audioRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [playing, setPlaying] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    let t2;
    if ($[1] !== audioPaths) {
        t2 = async (e)=>{
            e.stopPropagation();
            e.preventDefault();
            if (!audioPaths || audioPaths.length === 0) {
                return;
            }
            const path = audioPaths[Math.floor(Math.random() * audioPaths.length)];
            if (!path) {
                return;
            }
            ;
            try {
                const url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(path);
                if (!url) {
                    return;
                }
                if (audioRef.current) {
                    audioRef.current.pause();
                    audioRef.current = null;
                }
                const audio = new Audio(url);
                audioRef.current = audio;
                setPlaying(true);
                audio.addEventListener("ended", ()=>setPlaying(false));
                audio.addEventListener("error", ()=>setPlaying(false));
                await audio.play();
            } catch (t3) {
                const err = t3;
                console.error("PlayAudioButton error:", err);
                setPlaying(false);
            }
        };
        $[1] = audioPaths;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const handlePlay = t2;
    let t3;
    let t4;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ()=>()=>{
                if (audioRef.current) {
                    audioRef.current.pause();
                    audioRef.current = null;
                }
            };
        t4 = [];
        $[3] = t3;
        $[4] = t4;
    } else {
        t3 = $[3];
        t4 = $[4];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t3, t4);
    if (!audioPaths || audioPaths.length === 0) {
        return null;
    }
    let t5;
    if ($[5] !== t) {
        t5 = t("common.playAudio");
        $[5] = t;
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    const t6 = playing ? "primary.main" : "text.secondary";
    let t7;
    if ($[7] !== t6) {
        t7 = {
            color: t6,
            flexShrink: 0,
            p: 0.5
        };
        $[7] = t6;
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] !== size) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$VolumeUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: size
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 173,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[9] = size;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] !== handlePlay || $[12] !== size || $[13] !== t5 || $[14] !== t7 || $[15] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            size: size,
            onClick: handlePlay,
            onMouseDown: _temp,
            onTouchStart: _temp2,
            "aria-label": t5,
            sx: t7,
            children: t8
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 181,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[11] = handlePlay;
        $[12] = size;
        $[13] = t5;
        $[14] = t7;
        $[15] = t8;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    return t9;
};
_s(PlayAudioButton, "tNdtzejSiO98li79xaA+aqyFGaA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c1 = PlayAudioButton;
const ResultCard = (t0)=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    if ($[0] !== "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d") {
        for(let $i = 0; $i < 15; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d";
    }
    const { phrase, passed, audioPaths } = t0;
    const t1 = passed ? "2px solid var(--mui-palette-success-main, #4caf50)" : "2px solid var(--mui-palette-error-main, #f44336)";
    const t2 = passed ? "var(--mui-palette-success-light, #e8f5e9)" : "var(--mui-palette-error-light, #ffebee)";
    const t3 = passed ? "var(--mui-palette-success-dark, #2e7d32)" : "var(--mui-palette-error-dark, #c62828)";
    let t4;
    if ($[1] !== t1 || $[2] !== t2 || $[3] !== t3) {
        t4 = {
            fontSize: "1.2rem",
            margin: ".3rem",
            padding: ".8rem",
            display: "inline-flex",
            alignItems: "center",
            gap: "0.5rem",
            borderRadius: "8px",
            border: t1,
            backgroundColor: t2,
            color: t3,
            fontWeight: 500,
            width: "140px",
            minWidth: "140px",
            maxWidth: "140px",
            boxSizing: "border-box",
            flexShrink: 0,
            justifyContent: "center",
            textAlign: "center",
            whiteSpace: "normal",
            wordBreak: "break-word"
        };
        $[1] = t1;
        $[2] = t2;
        $[3] = t3;
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    let t5;
    if ($[5] !== passed) {
        t5 = passed ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: "1rem",
                flexShrink: 0
            }
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 244,
            columnNumber: 19
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Cancel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: "1rem",
                flexShrink: 0
            }
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 247,
            columnNumber: 13
        }, ("TURBOPACK compile-time value", void 0));
        $[5] = passed;
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] !== audioPaths) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PlayAudioButton, {
            audioPaths: audioPaths
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 258,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[7] = audioPaths;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] !== passed || $[10] !== phrase || $[11] !== t4 || $[12] !== t5 || $[13] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            "data-testid": "result-card",
            "data-passed": passed,
            sx: t4,
            children: [
                t5,
                phrase,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 266,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[9] = passed;
        $[10] = phrase;
        $[11] = t4;
        $[12] = t5;
        $[13] = t6;
        $[14] = t7;
    } else {
        t7 = $[14];
    }
    return t7;
};
_c2 = ResultCard;
const ResultDropLearn = (t0)=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(42);
    if ($[0] !== "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d") {
        for(let $i = 0; $i < 42; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d";
    }
    const { pronunciation, definition, matchedWord, passed, audioPaths, definitionAudioPaths } = t0;
    const borderColor = passed ? "var(--mui-palette-success-main, #4caf50)" : "var(--mui-palette-error-main, #f44336)";
    const backgroundColor = passed ? "var(--mui-palette-success-light, #e8f5e9)" : "var(--mui-palette-error-light, #ffebee)";
    const t1 = `1px solid ${borderColor}`;
    let t2;
    if ($[1] !== backgroundColor || $[2] !== t1) {
        t2 = {
            margin: "0.25rem 0",
            padding: "0.75rem",
            border: t1,
            backgroundColor,
            borderRadius: "8px",
            boxSizing: "border-box",
            width: "100%",
            flexShrink: 0
        };
        $[1] = backgroundColor;
        $[2] = t1;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            display: "flex",
            alignItems: "flex-start",
            gap: 1,
            width: "100%"
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== passed) {
        t4 = passed ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: "1.2rem",
                color: "var(--mui-palette-success-main, #4caf50)",
                mt: "2px",
                flexShrink: 0
            }
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 331,
            columnNumber: 19
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Cancel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: "1.2rem",
                color: "var(--mui-palette-error-main, #f44336)",
                mt: "2px",
                flexShrink: 0
            }
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 336,
            columnNumber: 13
        }, ("TURBOPACK compile-time value", void 0));
        $[5] = passed;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            component: "div"
        };
        t6 = {
            component: "div"
        };
        $[7] = t5;
        $[8] = t6;
    } else {
        t5 = $[7];
        t6 = $[8];
    }
    let t7;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            display: "flex",
            alignItems: "center",
            gap: 0.5,
            marginBottom: "0.25rem"
        };
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            fontWeight: "bold",
            fontSize: "1.1rem"
        };
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    const t9 = matchedWord?.phrase;
    let t10;
    if ($[11] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            component: "span",
            style: t8,
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 387,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[11] = t9;
        $[12] = t10;
    } else {
        t10 = $[12];
    }
    let t11;
    if ($[13] !== audioPaths) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PlayAudioButton, {
            audioPaths: audioPaths
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 395,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[13] = audioPaths;
        $[14] = t11;
    } else {
        t11 = $[14];
    }
    let t12;
    if ($[15] !== t10 || $[16] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t7,
            children: [
                t10,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 403,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[15] = t10;
        $[16] = t11;
        $[17] = t12;
    } else {
        t12 = $[17];
    }
    let t13;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            display: "block",
            fontStyle: "italic",
            color: "var(--mui-palette-text-disabled)",
            marginBottom: "0.25rem"
        };
        $[18] = t13;
    } else {
        t13 = $[18];
    }
    let t14;
    if ($[19] !== pronunciation) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            component: "span",
            style: t13,
            children: pronunciation
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 424,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[19] = pronunciation;
        $[20] = t14;
    } else {
        t14 = $[20];
    }
    let t15;
    if ($[21] !== t12 || $[22] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: [
                t12,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 432,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[21] = t12;
        $[22] = t14;
        $[23] = t15;
    } else {
        t15 = $[23];
    }
    let t16;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            display: "flex",
            alignItems: "center",
            gap: 0.5
        };
        $[24] = t16;
    } else {
        t16 = $[24];
    }
    let t17;
    if ($[25] !== definition) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            component: "span",
            variant: "body2",
            color: "textSecondary",
            children: definition
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 452,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[25] = definition;
        $[26] = t17;
    } else {
        t17 = $[26];
    }
    let t18;
    if ($[27] !== definitionAudioPaths) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PlayAudioButton, {
            audioPaths: definitionAudioPaths
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 460,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[27] = definitionAudioPaths;
        $[28] = t18;
    } else {
        t18 = $[28];
    }
    let t19;
    if ($[29] !== t17 || $[30] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t16,
            children: [
                t17,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 468,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[29] = t17;
        $[30] = t18;
        $[31] = t19;
    } else {
        t19 = $[31];
    }
    let t20;
    if ($[32] !== t15 || $[33] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
            primaryTypographyProps: t5,
            secondaryTypographyProps: t6,
            primary: t15,
            secondary: t19
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 477,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[32] = t15;
        $[33] = t19;
        $[34] = t20;
    } else {
        t20 = $[34];
    }
    let t21;
    if ($[35] !== t20 || $[36] !== t4) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t3,
            children: [
                t4,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 486,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[35] = t20;
        $[36] = t4;
        $[37] = t21;
    } else {
        t21 = $[37];
    }
    let t22;
    if ($[38] !== passed || $[39] !== t2 || $[40] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
            "data-testid": "result-drop-learn",
            "data-passed": passed,
            sx: t2,
            children: t21
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 495,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[38] = passed;
        $[39] = t2;
        $[40] = t21;
        $[41] = t22;
    } else {
        t22 = $[41];
    }
    return t22;
};
_c3 = ResultDropLearn;
const AnswerDropLearn = (t0)=>{
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23);
    if ($[0] !== "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d") {
        for(let $i = 0; $i < 23; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d";
    }
    const { correctAnswer, pronunciation, definition, id, matchedWord, isMatched, audioPaths, definitionAudioPaths } = t0;
    let t1;
    if ($[1] !== correctAnswer || $[2] !== id) {
        t1 = {
            accept: "box",
            drop: ()=>({
                    correctAnswer,
                    targetWordID: id
                }),
            collect: _temp3
        };
        $[1] = correctAnswer;
        $[2] = id;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const [t2, drop] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrop"])(t1);
    const { canDrop, isOver } = t2;
    const isActive = canDrop && isOver;
    let borderColor = "var(--mui-palette-text-disabled)";
    let backgroundColor = "var(--mui-palette-action-disabledBackground)";
    if (isMatched) {
        borderColor = "var(--mui-palette-divider)";
        backgroundColor = "var(--mui-palette-action-selected)";
    } else {
        if (isActive) {
            borderColor = "var(--mui-palette-primary-main)";
            backgroundColor = "var(--mui-palette-action-focus)";
        } else {
            if (canDrop) {
                borderColor = "var(--mui-palette-text-primary)";
            }
        }
    }
    const t3 = `1px solid ${borderColor}`;
    let t4;
    let t5;
    let t6;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            xs: "220px",
            sm: "100%"
        };
        t5 = {
            xs: "220px",
            sm: "auto"
        };
        t6 = {
            xs: "220px",
            sm: "100%"
        };
        $[4] = t4;
        $[5] = t5;
        $[6] = t6;
    } else {
        t4 = $[4];
        t5 = $[5];
        t6 = $[6];
    }
    let t7;
    if ($[7] !== backgroundColor || $[8] !== t3) {
        t7 = {
            margin: "0.25rem 0",
            padding: "0.75rem",
            border: t3,
            backgroundColor,
            borderRadius: "8px",
            boxSizing: "border-box",
            width: t4,
            minWidth: t5,
            maxWidth: t6,
            flexShrink: 0
        };
        $[7] = backgroundColor;
        $[8] = t3;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] !== audioPaths || $[11] !== definition || $[12] !== definitionAudioPaths || $[13] !== isMatched || $[14] !== matchedWord || $[15] !== pronunciation) {
        t8 = isMatched && matchedWord ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
            primaryTypographyProps: {
                component: "div"
            },
            secondaryTypographyProps: {
                component: "div"
            },
            primary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            display: "flex",
                            alignItems: "center",
                            gap: 0.5,
                            marginBottom: "0.25rem"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                component: "span",
                                style: {
                                    fontWeight: "bold",
                                    fontSize: "1.1rem"
                                },
                                children: matchedWord.phrase
                            }, void 0, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                                lineNumber: 616,
                                columnNumber: 10
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PlayAudioButton, {
                                audioPaths: audioPaths
                            }, void 0, false, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                                lineNumber: 619,
                                columnNumber: 45
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                        lineNumber: 611,
                        columnNumber: 22
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        component: "span",
                        style: {
                            display: "block",
                            fontStyle: "italic",
                            color: "var(--mui-palette-text-disabled)",
                            marginBottom: "0.25rem"
                        },
                        children: pronunciation
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                        lineNumber: 619,
                        columnNumber: 94
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                lineNumber: 611,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0)),
            secondary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    alignItems: "center",
                    gap: 0.5
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        component: "span",
                        variant: "body2",
                        color: "textSecondary",
                        children: definition
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                        lineNumber: 628,
                        columnNumber: 8
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PlayAudioButton, {
                        audioPaths: definitionAudioPaths
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                        lineNumber: 628,
                        columnNumber: 100
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                lineNumber: 624,
                columnNumber: 57
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 607,
            columnNumber: 37
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
            secondaryTypographyProps: {
                component: "div"
            },
            primary: pronunciation,
            secondary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    alignItems: "center",
                    gap: 0.5
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        component: "span",
                        variant: "body2",
                        color: "textSecondary",
                        children: definition
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                        lineNumber: 634,
                        columnNumber: 8
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PlayAudioButton, {
                        audioPaths: definitionAudioPaths
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                        lineNumber: 634,
                        columnNumber: 100
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                lineNumber: 630,
                columnNumber: 43
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 628,
            columnNumber: 166
        }, ("TURBOPACK compile-time value", void 0));
        $[10] = audioPaths;
        $[11] = definition;
        $[12] = definitionAudioPaths;
        $[13] = isMatched;
        $[14] = matchedWord;
        $[15] = pronunciation;
        $[16] = t8;
    } else {
        t8 = $[16];
    }
    let t9;
    if ($[17] !== drop || $[18] !== id || $[19] !== isMatched || $[20] !== t7 || $[21] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
            ref: drop,
            "data-testid": "drop-target-learn",
            "data-word-id": id,
            "data-is-matched": isMatched,
            sx: t7,
            children: t8
        }, id, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 647,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[17] = drop;
        $[18] = id;
        $[19] = isMatched;
        $[20] = t7;
        $[21] = t8;
        $[22] = t9;
    } else {
        t9 = $[22];
    }
    return t9;
};
_s1(AnswerDropLearn, "fF6x1T+EDLOJUW5Rp8CxNyvVsK4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrop"]
    ];
});
_c4 = AnswerDropLearn;
const AnswerDrop = (t0)=>{
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d";
    }
    const { correctAnswer } = t0;
    let t1;
    if ($[1] !== correctAnswer) {
        t1 = {
            accept: "box",
            drop: ()=>({
                    correctAnswer,
                    targetWordID: correctAnswer.id
                }),
            collect: _temp4
        };
        $[1] = correctAnswer;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [t2, drop] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrop"])(t1);
    const { canDrop, isOver } = t2;
    const isActive = canDrop && isOver;
    let borderColor = "var(--mui-palette-text-disabled)";
    let backgroundColor = "var(--mui-palette-action-disabledBackground)";
    if (isActive) {
        borderColor = "var(--mui-palette-primary-main)";
        backgroundColor = "var(--mui-palette-action-focus)";
    } else {
        if (canDrop) {
            borderColor = "var(--mui-palette-text-primary)";
        }
    }
    const t3 = correctAnswer?.id;
    const t4 = `1px solid ${borderColor}`;
    let t5;
    if ($[3] !== backgroundColor || $[4] !== t4) {
        t5 = {
            borderStyle: "dashed",
            width: "100%",
            maxWidth: "100%",
            minWidth: "0",
            height: "100%",
            maxHeight: "100%",
            overflow: "hidden",
            alignContent: "center",
            justifyContent: "center",
            display: "flex",
            flexDirection: "column",
            padding: "1rem",
            borderRadius: "8px",
            border: t4,
            backgroundColor
        };
        $[3] = backgroundColor;
        $[4] = t4;
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    let t6;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            width: "100%",
            alignItems: "center",
            display: "flex",
            flexDirection: "column",
            textAlign: "center",
            wordWrap: "break-word",
            overflowWrap: "break-word",
            gap: "0.5rem"
        };
        $[6] = t6;
    } else {
        t6 = $[6];
    }
    const t7 = correctAnswer?.definition;
    const t8 = correctAnswer?.definitionAudio || correctAnswer?.audio;
    let t9;
    if ($[7] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PlayAudioButton, {
            audioPaths: t8
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 748,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[7] = t8;
        $[8] = t9;
    } else {
        t9 = $[8];
    }
    let t10;
    if ($[9] !== t7 || $[10] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: t6,
            children: [
                t7,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 756,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[9] = t7;
        $[10] = t9;
        $[11] = t10;
    } else {
        t10 = $[11];
    }
    let t11;
    if ($[12] !== drop || $[13] !== t10 || $[14] !== t3 || $[15] !== t5) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                ref: drop,
                borderRadius: 3,
                border: 1,
                "data-testid": "drop-target",
                "data-word-id": t3,
                style: t5,
                children: t10
            }, void 0, false, {
                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                lineNumber: 765,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false);
        $[12] = drop;
        $[13] = t10;
        $[14] = t3;
        $[15] = t5;
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    return t11;
};
_s2(AnswerDrop, "fF6x1T+EDLOJUW5Rp8CxNyvVsK4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrop"]
    ];
});
_c5 = AnswerDrop;
function TabPanel(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d";
    }
    let children;
    let index;
    let other;
    let value;
    if ($[1] !== props) {
        ({ children, value, index, ...other } = props);
        $[1] = props;
        $[2] = children;
        $[3] = index;
        $[4] = other;
        $[5] = value;
    } else {
        children = $[2];
        index = $[3];
        other = $[4];
        value = $[5];
    }
    const t0 = value !== index;
    const t1 = `scrollable-auto-tabpanel-${index}`;
    const t2 = `scrollable-auto-tab-${index}`;
    const t3 = value === index ? "1 1 auto" : undefined;
    const t4 = value === index ? "flex" : "none";
    let t5;
    if ($[6] !== t3 || $[7] !== t4) {
        t5 = {
            width: "100%",
            maxWidth: "100vw",
            overflow: "hidden",
            boxSizing: "border-box",
            flex: t3,
            minHeight: 0,
            display: t4,
            flexDirection: "column"
        };
        $[6] = t3;
        $[7] = t4;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] !== children || $[10] !== other || $[11] !== t0 || $[12] !== t1 || $[13] !== t2 || $[14] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            role: "tabpanel",
            hidden: t0,
            id: t1,
            "aria-labelledby": t2,
            style: t5,
            ...other,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 831,
            columnNumber: 10
        }, this);
        $[9] = children;
        $[10] = other;
        $[11] = t0;
        $[12] = t1;
        $[13] = t2;
        $[14] = t5;
        $[15] = t6;
    } else {
        t6 = $[15];
    }
    return t6;
}
_c6 = TabPanel;
function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        "aria-controls": `scrollable-auto-tabpanel-${index}`
    };
}
const MeaningAssociationTabs = ({ nodeKey, wordIDs, enabledModes = [
    "learn",
    "easy",
    "hard"
] })=>{
    _s3();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("common");
    const { grade } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const gradeData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MeaningAssociationTabs.useMemo[gradeData]": ()=>{
            if (!grade?.data) return {};
            if (typeof grade.data === "string") {
                try {
                    return JSON.parse(grade.data);
                } catch  {
                    return {};
                }
            }
            return grade.data;
        }
    }["MeaningAssociationTabs.useMemo[gradeData]"], [
        grade?.data
    ]);
    const inProgress = gradeData[nodeKey] || {};
    // Load saved tab index or default to 0
    const savedTabIndex = inProgress?.tabIndex || 0;
    const [tabIndex, setTabIndex] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](savedTabIndex);
    // Update tab index when grade data changes (e.g., from another component)
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "MeaningAssociationTabs.useEffect": ()=>{
            if (inProgress?.tabIndex !== undefined && inProgress.tabIndex !== tabIndex) {
                setTabIndex(inProgress.tabIndex);
            }
        }
    }["MeaningAssociationTabs.useEffect"], [
        inProgress?.tabIndex
    ]);
    const handleTabChange = (event, newValue)=>{
        setTabIndex(newValue);
    };
    // Check completion status for each mode
    const learnComplete = inProgress?.learn?.complete || false;
    const easyComplete = inProgress?.easy?.complete || false;
    const hardComplete = inProgress?.hard?.complete || false;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            width: "100%",
            maxWidth: "100vw",
            overflow: "hidden",
            boxSizing: "border-box",
            display: "flex",
            flexDirection: "column",
            flex: "1 1 auto",
            minHeight: 0
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AppBar$3e$__["AppBar"], {
                elevation: 2,
                style: {
                    borderRadius: "3px"
                },
                position: "static",
                color: "inherit",
                margin: 1,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__["Tabs"], {
                    value: tabIndex,
                    onChange: handleTabChange,
                    indicatorColor: "primary",
                    textColor: "primary",
                    variant: "scrollable",
                    scrollButtons: "auto",
                    "aria-label": t("common.filter"),
                    style: {
                        margin: 0,
                        padding: 0
                    },
                    children: [
                        enabledModes.includes("learn") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                            label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                display: "flex",
                                alignItems: "center",
                                gap: 1,
                                children: [
                                    "Learn",
                                    learnComplete && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        style: {
                                            fontSize: "1rem",
                                            color: "var(--mui-palette-success-main, #4caf50)"
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                                        lineNumber: 909,
                                        columnNumber: 37
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                                lineNumber: 907,
                                columnNumber: 58
                            }, ("TURBOPACK compile-time value", void 0)),
                            ...a11yProps(enabledModes.indexOf("learn"))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                            lineNumber: 907,
                            columnNumber: 46
                        }, ("TURBOPACK compile-time value", void 0)),
                        enabledModes.includes("easy") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                            label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                display: "flex",
                                alignItems: "center",
                                gap: 1,
                                children: [
                                    "Easy",
                                    easyComplete && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        style: {
                                            fontSize: "1rem",
                                            color: "var(--mui-palette-success-main, #4caf50)"
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                                        lineNumber: 916,
                                        columnNumber: 36
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                                lineNumber: 914,
                                columnNumber: 57
                            }, ("TURBOPACK compile-time value", void 0)),
                            ...a11yProps(enabledModes.indexOf("easy"))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                            lineNumber: 914,
                            columnNumber: 45
                        }, ("TURBOPACK compile-time value", void 0)),
                        enabledModes.includes("hard") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                            label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                display: "flex",
                                alignItems: "center",
                                gap: 1,
                                children: [
                                    "Hard",
                                    hardComplete && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        style: {
                                            fontSize: "1rem",
                                            color: "var(--mui-palette-success-main, #4caf50)"
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                                        lineNumber: 923,
                                        columnNumber: 36
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                                lineNumber: 921,
                                columnNumber: 57
                            }, ("TURBOPACK compile-time value", void 0)),
                            ...a11yProps(enabledModes.indexOf("hard"))
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                            lineNumber: 921,
                            columnNumber: 45
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                    lineNumber: 903,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                lineNumber: 900,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DndWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndWrapper"], {
                children: [
                    enabledModes.includes("learn") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
                        value: tabIndex,
                        index: enabledModes.indexOf("learn"),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$Learn$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Learn"], {
                            nodeKey: nodeKey,
                            setTabIndex: setTabIndex,
                            tabIndex: tabIndex,
                            wordIDs: wordIDs
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                            lineNumber: 932,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                        lineNumber: 931,
                        columnNumber: 44
                    }, ("TURBOPACK compile-time value", void 0)),
                    enabledModes.includes("easy") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
                        value: tabIndex,
                        index: enabledModes.indexOf("easy"),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$Easy$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Easy"], {
                            nodeKey: nodeKey,
                            setTabIndex: setTabIndex,
                            tabIndex: tabIndex,
                            wordIDs: wordIDs
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                            lineNumber: 935,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                        lineNumber: 934,
                        columnNumber: 43
                    }, ("TURBOPACK compile-time value", void 0)),
                    enabledModes.includes("hard") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
                        value: tabIndex,
                        index: enabledModes.indexOf("hard"),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$Hard$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hard"], {
                            nodeKey: nodeKey,
                            setTabIndex: setTabIndex,
                            tabIndex: tabIndex,
                            wordIDs: wordIDs
                        }, void 0, false, {
                            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                            lineNumber: 938,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                        lineNumber: 937,
                        columnNumber: 43
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                lineNumber: 930,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
        lineNumber: 890,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s3(MeaningAssociationTabs, "uk8NAtFq9+MzkVtDfmLRYRRmBL4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c7 = MeaningAssociationTabs;
const MeaningAssociationExercise = (t0)=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9ffdcf09aae5bab82419e952e185d99cca759720f0f3397894af6b910223697d";
    }
    const { nodeKey, wordIDs, enabledModes: t1 } = t0;
    let t2;
    if ($[1] !== t1) {
        t2 = t1 === undefined ? [
            "learn",
            "easy",
            "hard"
        ] : t1;
        $[1] = t1;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const enabledModes = t2;
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            flexGrow: 1,
            width: "100%",
            maxWidth: "100vw",
            minHeight: "400px",
            margin: 0,
            padding: 0,
            boxSizing: "border-box",
            display: "flex",
            flexDirection: "column"
        };
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    let t4;
    if ($[4] !== enabledModes || $[5] !== nodeKey || $[6] !== wordIDs) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: t3,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MeaningAssociationTabs, {
                nodeKey: nodeKey,
                wordIDs: wordIDs,
                enabledModes: enabledModes
            }, void 0, false, {
                fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
                lineNumber: 984,
                columnNumber: 26
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/MeaningAssociationExercise/index.jsx",
            lineNumber: 984,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[4] = enabledModes;
        $[5] = nodeKey;
        $[6] = wordIDs;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    return t4;
};
_c8 = MeaningAssociationExercise;
const __TURBOPACK__default__export__ = MeaningAssociationExercise;
function _temp(e_0) {
    return e_0.stopPropagation();
}
function _temp2(e_1) {
    return e_1.stopPropagation();
}
function _temp3(monitor) {
    return {
        isOver: monitor.isOver(),
        canDrop: monitor.canDrop()
    };
}
function _temp4(monitor) {
    return {
        isOver: monitor.isOver(),
        canDrop: monitor.canDrop()
    };
}
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8;
__turbopack_context__.k.register(_c, "LinearProgressWithLabel");
__turbopack_context__.k.register(_c1, "PlayAudioButton");
__turbopack_context__.k.register(_c2, "ResultCard");
__turbopack_context__.k.register(_c3, "ResultDropLearn");
__turbopack_context__.k.register(_c4, "AnswerDropLearn");
__turbopack_context__.k.register(_c5, "AnswerDrop");
__turbopack_context__.k.register(_c6, "TabPanel");
__turbopack_context__.k.register(_c7, "MeaningAssociationTabs");
__turbopack_context__.k.register(_c8, "MeaningAssociationExercise");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_MeaningAssociationExercise_20qz0r6._.js.map