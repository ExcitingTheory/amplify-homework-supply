(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/ChatSidebar.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// react component that renders the chat session with the user and the bot
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript) <export default as Paper>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Portal/Portal.js [app-client] (ecmascript) <export default as Portal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript) <export default as Snackbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemButton/ListItemButton.js [app-client] (ecmascript) <export default as ListItemButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$180649__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:180649 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Chat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Chat.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Delete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Send.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$UploadFile$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/UploadFile.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AttachFile$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AttachFile.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PictureAsPdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PictureAsPdf.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Cancel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Cancel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RateReview$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RateReview.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$History$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/History.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Add.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Archive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Archive.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Unarchive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Unarchive.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$serializeLexicalToSparseText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/serializeLexicalToSparseText.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$vectorStoreContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/vectorStoreContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/chatContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tabContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/tabContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tourContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/tourContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$react$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/react/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/ai/dist/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/apis/fetchAuthSession.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/fileUploadUtils.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useNailedItDetection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useNailedItDetection.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$NailedItCelebration$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/NailedItCelebration.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/fileContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VocabularyReview2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/VocabularyReview2.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatTools$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/chatTools.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AIFeedbackWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/AIFeedbackWidget.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2f$SearchResults$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ChatSidebar/SearchResults.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PracticeDrillDialog$3e$__ = __turbopack_context__.i("[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx [app-client] (ecmascript) <export default as PracticeDrillDialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2f$VirtualizedMessageList$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ChatSidebar/VirtualizedMessageList.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2f$LexicalMessageRenderer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ChatSidebar/LexicalMessageRenderer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2f$BlockInsertPreview$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ChatSidebar/BlockInsertPreview.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2f$RecordingScriptPreview$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ChatSidebar/RecordingScriptPreview.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/QuizPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/AnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/MeaningAssociationPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/CustomAnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BotAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/BotAvatar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/analytics.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const ChatSidebar = ({ onClose })=>{
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const tCommon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("common");
    const ready = true; // next-intl translations are always ready when provider is mounted
    // Utility function to deep clone messages to prevent frozen object errors
    // The AI SDK mutates message objects during streaming, so they must be mutable
    const deepCloneMessages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSidebar.useCallback[deepCloneMessages]": (messages)=>{
            if (!messages || !Array.isArray(messages) || messages.length === 0) {
                console.log("[ChatSidebar] deepCloneMessages: returning empty array");
                return [];
            }
            // Use structuredClone if available (better performance, handles more types)
            // Otherwise fallback to JSON stringify/parse
            try {
                const cloned = typeof structuredClone !== "undefined" ? structuredClone(messages) : JSON.parse(JSON.stringify(messages));
                // Ensure every message has an id (older persisted messages may lack one)
                const withIds = cloned.map({
                    "ChatSidebar.useCallback[deepCloneMessages].withIds": (msg)=>{
                        if (!msg.id) {
                            msg.id = crypto.randomUUID ? crypto.randomUUID() : `msg-${Date.now()}-${Math.random().toString(36).slice(2)}`;
                        }
                        return msg;
                    }
                }["ChatSidebar.useCallback[deepCloneMessages].withIds"]);
                console.log("[ChatSidebar] deepCloneMessages: cloned", withIds.length, "messages");
                return withIds;
            } catch (error) {
                console.error("[ChatSidebar] Error cloning messages:", error);
                // Last resort: return empty array to prevent crashes
                return [];
            }
        }
    }["ChatSidebar.useCallback[deepCloneMessages]"], []);
    // Action types for the reducer
    const ACTIONS = {
        SET_DRAGGING: "SET_DRAGGING",
        SET_UPLOADED_FILES: "SET_UPLOADED_FILES",
        ADD_UPLOADED_FILES: "ADD_UPLOADED_FILES",
        REMOVE_UPLOADED_FILE: "REMOVE_UPLOADED_FILE",
        SET_DOCUMENT_PROCESSING_STATUS: "SET_DOCUMENT_PROCESSING_STATUS",
        UPDATE_DOCUMENT_PROCESSING_STATUS: "UPDATE_DOCUMENT_PROCESSING_STATUS",
        SET_DOCUMENT_STATUSES: "SET_DOCUMENT_STATUSES",
        SET_VOCABULARY_REVIEW_DIALOG: "SET_VOCABULARY_REVIEW_DIALOG",
        SET_REVIEW_DOCUMENT_ID: "SET_REVIEW_DOCUMENT_ID",
        SET_CONFIRM_DIALOG: "SET_CONFIRM_DIALOG",
        SET_TOOL_EXECUTION_STATES: "SET_TOOL_EXECUTION_STATES",
        UPDATE_TOOL_EXECUTION_STATES: "UPDATE_TOOL_EXECUTION_STATES",
        SET_HISTORY_DRAWER_OPEN: "SET_HISTORY_DRAWER_OPEN",
        SET_INPUT: "SET_INPUT",
        SET_LAST_CHAT_ID: "SET_LAST_CHAT_ID",
        RESET_FOR_NEW_CHAT: "RESET_FOR_NEW_CHAT"
    };
    // Initial state for the reducer
    const initialState = {
        isDragging: false,
        uploadedFiles: [],
        documentProcessingStatus: {},
        documentStatuses: {},
        vocabularyReviewDialogOpen: false,
        reviewDocumentId: null,
        confirmDialog: {
            open: false,
            message: "",
            onConfirm: null,
            severity: "info"
        },
        toolExecutionStates: {},
        historyDrawerOpen: false,
        input: "",
        lastChatId: null
    };
    // Reducer function
    function chatSidebarReducer(state, action) {
        switch(action.type){
            case ACTIONS.SET_DRAGGING:
                return {
                    ...state,
                    isDragging: action.payload
                };
            case ACTIONS.SET_UPLOADED_FILES:
                return {
                    ...state,
                    uploadedFiles: action.payload
                };
            case ACTIONS.ADD_UPLOADED_FILES:
                return {
                    ...state,
                    uploadedFiles: [
                        ...state.uploadedFiles,
                        ...action.payload
                    ]
                };
            case ACTIONS.REMOVE_UPLOADED_FILE:
                return {
                    ...state,
                    uploadedFiles: state.uploadedFiles.filter((_, i)=>i !== action.payload),
                    documentProcessingStatus: Object.fromEntries(Object.entries(state.documentProcessingStatus).filter(([index])=>parseInt(index) !== action.payload))
                };
            case ACTIONS.SET_DOCUMENT_PROCESSING_STATUS:
                return {
                    ...state,
                    documentProcessingStatus: action.payload
                };
            case ACTIONS.UPDATE_DOCUMENT_PROCESSING_STATUS:
                return {
                    ...state,
                    documentProcessingStatus: {
                        ...state.documentProcessingStatus,
                        ...action.payload
                    }
                };
            case ACTIONS.SET_DOCUMENT_STATUSES:
                return {
                    ...state,
                    documentStatuses: action.payload
                };
            case ACTIONS.SET_VOCABULARY_REVIEW_DIALOG:
                return {
                    ...state,
                    vocabularyReviewDialogOpen: action.payload
                };
            case ACTIONS.SET_REVIEW_DOCUMENT_ID:
                return {
                    ...state,
                    reviewDocumentId: action.payload
                };
            case ACTIONS.SET_CONFIRM_DIALOG:
                return {
                    ...state,
                    confirmDialog: action.payload
                };
            case ACTIONS.SET_TOOL_EXECUTION_STATES:
                return {
                    ...state,
                    toolExecutionStates: action.payload
                };
            case ACTIONS.UPDATE_TOOL_EXECUTION_STATES:
                return {
                    ...state,
                    toolExecutionStates: {
                        ...state.toolExecutionStates,
                        ...action.payload
                    }
                };
            case ACTIONS.SET_HISTORY_DRAWER_OPEN:
                return {
                    ...state,
                    historyDrawerOpen: action.payload
                };
            case ACTIONS.SET_INPUT:
                return {
                    ...state,
                    input: action.payload
                };
            case ACTIONS.SET_LAST_CHAT_ID:
                return {
                    ...state,
                    lastChatId: action.payload
                };
            case ACTIONS.RESET_FOR_NEW_CHAT:
                return {
                    ...state,
                    uploadedFiles: [],
                    input: "",
                    documentProcessingStatus: {},
                    toolExecutionStates: {}
                };
            default:
                return state;
        }
    }
    // UI State - now using reducer
    const [state_0, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(chatSidebarReducer, initialState);
    const { isDragging, uploadedFiles, documentProcessingStatus, documentStatuses, vocabularyReviewDialogOpen, reviewDocumentId, confirmDialog, toolExecutionStates, historyDrawerOpen, input, lastChatId } = state_0;
    // Refs for DOM interaction
    const chatContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastChatIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const unitContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    // Consume document data from FilesContext (avoids duplicate Document.observeQuery subscription)
    const { documents: filesContextDocuments } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {};
    const { unit, files, questionBank, dictionary, editorRef, insertWord, insertQuestion, sectionId, grade } = unitContext;
    // Get chat state from ChatContext
    const { assistantChat, chatHistories, setCurrentChat, chatVersionRef, isLoadingChat, chatCreationError } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    // Get tab context (optional - only available in Editor)
    const tabContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tabContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabContext"])() || {};
    // Get auth state
    const { user, isLoading: authLoading } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    // Fetch student memory for AI context
    const [studentMemory, setStudentMemory] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const studentMemoryVersionRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(0);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "ChatSidebar.useEffect": ()=>{
            if (!user?.username) return;
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            if (!client?.models?.StudentMemory) return;
            // Single observeQuery replaces list() + onUpdate
            const subscription = client.models.StudentMemory.observeQuery({
                filter: {
                    studentId: {
                        eq: user.username
                    }
                }
            }).subscribe({
                next: {
                    "ChatSidebar.useEffect.subscription": ({ items })=>{
                        const valid = (items || []).filter({
                            "ChatSidebar.useEffect.subscription.valid": (i_0)=>i_0 != null && i_0.id != null
                        }["ChatSidebar.useEffect.subscription.valid"]);
                        if (valid.length > 0) {
                            const memory = valid[0];
                            // Version guard: only rerender if incoming version is greater than expected
                            if (memory._version != null && !(memory._version > studentMemoryVersionRef.current)) return;
                            studentMemoryVersionRef.current = memory._version || 0;
                            setStudentMemory(memory.memoryMarkdown || null);
                        }
                    }
                }["ChatSidebar.useEffect.subscription"],
                error: {
                    "ChatSidebar.useEffect.subscription": (err)=>console.warn("[ChatSidebar] StudentMemory subscription error:", err?.message)
                }["ChatSidebar.useEffect.subscription"]
            });
            return ({
                "ChatSidebar.useEffect": ()=>subscription.unsubscribe()
            })["ChatSidebar.useEffect"];
        }
    }["ChatSidebar.useEffect"], [
        user?.username
    ]);
    // Get tour context (optional - may not be available in all pages)
    const tourContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tourContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTourSafe"])();
    // Get sections from SectionContext instead of local query
    const { sections = [] } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {};
    // Simple handlers
    const handleInsertWord = (word)=>insertWord?.(word);
    const handleInsertQuestion = (question)=>insertQuestion?.(question);
    const handleFocusItem = (type, id)=>{
        // Note: setFocusItem is not available in ChatContext, only in Editor's TabContext
        console.log("[ChatSidebar] handleFocusItem called:", type, id);
    };
    // Handle inserting editor blocks from chat
    const handleInsertBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSidebar.useCallback[handleInsertBlock]": (blockType, blockData)=>{
            if (!editorRef?.current) {
                console.error("[ChatSidebar] No editor ref available");
                return;
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackChatBlockInserted"])(assistantChat?.id, blockType);
            const editor = editorRef.current;
            editor.update({
                "ChatSidebar.useCallback[handleInsertBlock]": ()=>{
                    switch(blockType){
                        case "quiz":
                            editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_QUIZ_COMMAND"], blockData);
                            console.log("[ChatSidebar] Inserted quiz block:", blockData);
                            break;
                        case "answer":
                            editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_ANSWER_BLOCK_COMMAND"], blockData);
                            console.log("[ChatSidebar] Inserted answer block:", blockData);
                            break;
                        case "meaning-association":
                            editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_MEANING_ASSOCIATION_BLOCK_COMMAND"], blockData);
                            console.log("[ChatSidebar] Inserted meaning association block:", blockData);
                            break;
                        case "custom-answer":
                            editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_CUSTOM_ANSWER_BLOCK_COMMAND"], blockData);
                            console.log("[ChatSidebar] Inserted custom answer block:", blockData);
                            break;
                        default:
                            console.warn("[ChatSidebar] Unknown block type:", blockType);
                    }
                }
            }["ChatSidebar.useCallback[handleInsertBlock]"]);
        }
    }["ChatSidebar.useCallback[handleInsertBlock]"], [
        editorRef
    ]);
    // Load chat data when chat changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSidebar.useEffect": ()=>{
            if (!assistantChat || isLoadingChat) return;
            const chatChanged = lastChatIdRef.current !== assistantChat.id;
            if (chatChanged) {
                lastChatIdRef.current = assistantChat.id;
                // Load messages - ensure it's always an array
                // Messages are stored as JSON string in database
                let messagesArray = [];
                const rawMessages = assistantChat.messages;
                if (Array.isArray(rawMessages)) {
                    messagesArray = rawMessages;
                } else if (typeof rawMessages === "string" && rawMessages) {
                    try {
                        messagesArray = JSON.parse(rawMessages);
                        if (!Array.isArray(messagesArray)) messagesArray = [];
                    } catch (e) {
                        console.error("[ChatSidebar] Failed to parse messages:", e);
                        messagesArray = [];
                    }
                }
                console.log("[ChatSidebar] Loading messages for chat:", assistantChat.id, "count:", messagesArray.length);
                setMessages(deepCloneMessages(messagesArray));
                // Load draft (only on chat change, not version updates)
                dispatch({
                    type: ACTIONS.SET_INPUT,
                    payload: assistantChat.draft || ""
                });
                // Load files via direct list() call instead of lazy loader to avoid
                // auto-pagination (which fires 11+ separate GraphQL queries)
                const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                client_0.models.AssistantChatFile.list({
                    filter: {
                        chatID: {
                            eq: assistantChat.id
                        }
                    }
                }).then({
                    "ChatSidebar.useEffect": (result)=>dispatch({
                            type: ACTIONS.SET_UPLOADED_FILES,
                            payload: result?.data || []
                        })
                }["ChatSidebar.useEffect"]).catch({
                    "ChatSidebar.useEffect": (err_0)=>console.error("[ChatSidebar] Error loading files:", err_0)
                }["ChatSidebar.useEffect"]);
            }
        }
    }["ChatSidebar.useEffect"], [
        assistantChat?.id,
        isLoadingChat
    ]);
    const vectorStoreCtx = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$vectorStoreContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    // Register vector store search function with chatTools
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "ChatSidebar.useEffect": ()=>{
            if (vectorStoreCtx?.search) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatTools$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setVectorStoreSearch"])(vectorStoreCtx.search);
                console.log("[ChatSidebar] Registered vector store search, isReady:", vectorStoreCtx.isReady);
            }
            return ({
                "ChatSidebar.useEffect": ()=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatTools$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setVectorStoreSearch"])(null);
                }
            })["ChatSidebar.useEffect"];
        }
    }["ChatSidebar.useEffect"], [
        vectorStoreCtx
    ]);
    // Practice drill state — opened by chat tool call
    const [practiceDrillConfig, setPracticeDrillConfig] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [practiceDrillOpen, setPracticeDrillOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "ChatSidebar.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatTools$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setPracticeDrillCallback"])({
                "ChatSidebar.useEffect": (config)=>{
                    setPracticeDrillConfig(config);
                    setPracticeDrillOpen(true);
                }
            }["ChatSidebar.useEffect"]);
            return ({
                "ChatSidebar.useEffect": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatTools$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setPracticeDrillCallback"])(null)
            })["ChatSidebar.useEffect"];
        }
    }["ChatSidebar.useEffect"], []);
    // Simple context data for chat API — sparse text for unit content to stay under API Gateway limits
    const contextData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ChatSidebar.useMemo[contextData]": ()=>{
            // Only send the current section (if known) instead of all sections
            const relevantSections = sectionId ? sections?.filter({
                "ChatSidebar.useMemo[contextData]": (s)=>s.id === sectionId
            }["ChatSidebar.useMemo[contextData]"]) || [] : sections?.slice(0, 5) || [];
            // Build lookup maps for the serializer to resolve IDs to content
            const wordMap = dictionary ? Object.fromEntries(Object.values(dictionary).filter({
                "ChatSidebar.useMemo[contextData]": (d)=>d != null
            }["ChatSidebar.useMemo[contextData]"]).map({
                "ChatSidebar.useMemo[contextData]": (d_0)=>[
                        d_0.id,
                        d_0
                    ]
            }["ChatSidebar.useMemo[contextData]"])) : {};
            const questionMap = questionBank ? Object.fromEntries(Object.values(questionBank).filter({
                "ChatSidebar.useMemo[contextData]": (q)=>q != null
            }["ChatSidebar.useMemo[contextData]"]).map({
                "ChatSidebar.useMemo[contextData]": (q_0)=>[
                        q_0.id,
                        q_0
                    ]
            }["ChatSidebar.useMemo[contextData]"])) : {};
            const fileMap = files ? Object.fromEntries(Object.values(files).filter({
                "ChatSidebar.useMemo[contextData]": (f)=>f != null
            }["ChatSidebar.useMemo[contextData]"]).map({
                "ChatSidebar.useMemo[contextData]": (f_0)=>[
                        f_0.id,
                        f_0
                    ]
            }["ChatSidebar.useMemo[contextData]"])) : {};
            // Parse grade data for in-progress block status
            let gradeData = {};
            if (grade?.data) {
                try {
                    gradeData = typeof grade.data === "string" ? JSON.parse(grade.data) : grade.data;
                } catch  {
                /* ignore parse errors */ }
            }
            return {
                unit: unit ? {
                    id: unit.id,
                    name: unit.name,
                    description: unit.description,
                    // Sparse text with resolved word/question content and grade progress
                    content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$serializeLexicalToSparseText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(unit.data, {
                        words: wordMap,
                        questions: questionMap,
                        files: fileMap,
                        gradeData
                    })
                } : null,
                files: files ? Object.values(files).filter({
                    "ChatSidebar.useMemo[contextData]": (f_1)=>f_1 != null
                }["ChatSidebar.useMemo[contextData]"]).map({
                    "ChatSidebar.useMemo[contextData]": (f_2)=>({
                            id: f_2.id,
                            name: f_2.name,
                            description: f_2.description,
                            mimeType: f_2.mimeType
                        })
                }["ChatSidebar.useMemo[contextData]"]) : [],
                questionBank: questionBank ? Object.values(questionBank).filter({
                    "ChatSidebar.useMemo[contextData]": (q_1)=>q_1 != null
                }["ChatSidebar.useMemo[contextData]"]).map({
                    "ChatSidebar.useMemo[contextData]": (q_2)=>({
                            id: q_2.id,
                            prompt: q_2.prompt,
                            answer: q_2.answer
                        })
                }["ChatSidebar.useMemo[contextData]"]) : [],
                dictionary: dictionary ? Object.values(dictionary).filter({
                    "ChatSidebar.useMemo[contextData]": (d_1)=>d_1 != null
                }["ChatSidebar.useMemo[contextData]"]).map({
                    "ChatSidebar.useMemo[contextData]": (d_2)=>({
                            id: d_2.id,
                            phrase: d_2.phrase,
                            definition: d_2.definition
                        })
                }["ChatSidebar.useMemo[contextData]"]) : [],
                sections: relevantSections.map({
                    "ChatSidebar.useMemo[contextData]": (s_0)=>({
                            id: s_0.id,
                            name: s_0.name,
                            description: s_0.description
                        })
                }["ChatSidebar.useMemo[contextData]"]),
                // Course outline from the relevant section for progression context
                courseOutline: ({
                    "ChatSidebar.useMemo[contextData]": ()=>{
                        const section = relevantSections.find({
                            "ChatSidebar.useMemo[contextData].section": (s_1)=>s_1.courseOutline
                        }["ChatSidebar.useMemo[contextData].section"]);
                        if (!section?.courseOutline) return null;
                        try {
                            return typeof section.courseOutline === "string" ? JSON.parse(section.courseOutline) : section.courseOutline;
                        } catch  {
                            return null;
                        }
                    }
                })["ChatSidebar.useMemo[contextData]"](),
                grade: grade ? {
                    id: grade.id,
                    complete: grade.complete,
                    percentComplete: grade.percentComplete,
                    accuracy: grade.accuracy,
                    attempt: grade.attempt
                } : null,
                studentMemory: studentMemory || null,
                sectionId: sectionId || null
            };
        }
    }["ChatSidebar.useMemo[contextData]"], [
        unit,
        files,
        questionBank,
        dictionary,
        sections,
        sectionId,
        grade,
        studentMemory
    ]);
    // Memoize the fetch function to prevent recreation on every render
    const customFetch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSidebar.useCallback[customFetch]": async (url, options)=>{
            console.log("[ChatSidebar] Custom fetch routing to local /api/chat route, ignoring AI SDK url:", url);
            // ── Offline: route through on-device AI ─────────────────────────
            if (typeof navigator !== "undefined" && !navigator.onLine) {
                console.log("[ChatSidebar] Offline — routing through AIRouter");
                try {
                    const { aiRouter } = await __turbopack_context__.A("[project]/src/offline/AIRouter.ts [app-client] (ecmascript, async loader)");
                    const requestBody = options.body ? JSON.parse(options.body) : {};
                    const userMessages = requestBody.messages || [];
                    // Build SSE stream from AIRouter async generator
                    const stream = new ReadableStream({
                        async start (controller) {
                            const encoder = new TextEncoder();
                            try {
                                const generator = aiRouter.chat(userMessages, {
                                    unitId: contextData.unit?.id || "",
                                    unitName: contextData.unit?.name || "",
                                    unitDescription: contextData.unit?.description || "",
                                    vocabulary: contextData.dictionary || [],
                                    questions: contextData.questionBank || [],
                                    studentMemory: contextData.studentMemory || "",
                                    gradeAccuracy: contextData.grade?.accuracy
                                });
                                let fullText = "";
                                for await (const chunk of generator){
                                    fullText += chunk;
                                    // Emit AI SDK "data" stream protocol format
                                    const event = `0:${JSON.stringify(chunk)}\n`;
                                    controller.enqueue(encoder.encode(event));
                                }
                                // Send finish event
                                const finishEvent_0 = `d:{"finishReason":"stop"}\n`;
                                controller.enqueue(encoder.encode(finishEvent_0));
                                controller.close();
                            } catch (err_2) {
                                console.error("[ChatSidebar] Offline chat error:", err_2);
                                const errorChunk = `0:${JSON.stringify("Sorry, offline AI is not available right now.")}\n`;
                                controller.enqueue(encoder.encode(errorChunk));
                                const finishEvent = `d:{"finishReason":"stop"}\n`;
                                controller.enqueue(encoder.encode(finishEvent));
                                controller.close();
                            }
                        }
                    });
                    return new Response(stream, {
                        status: 200,
                        headers: new Headers({
                            "Content-Type": "text/event-stream",
                            "Cache-Control": "no-cache"
                        })
                    });
                } catch (err_1) {
                    console.error("[ChatSidebar] Failed to load AIRouter:", err_1);
                    throw err_1;
                }
            }
            // ── End offline routing ─────────────────────────────────────────
            try {
                // Parse the request body from AI SDK
                const requestBody_0 = options.body ? JSON.parse(options.body) : {};
                // Add context to the request body
                const bodyWithContext = {
                    ...requestBody_0,
                    context: contextData
                };
                console.log("[ChatSidebar] Sending request to /api/chat:", {
                    hasUnit: !!contextData.unit,
                    filesCount: contextData.files?.length || 0,
                    questionsCount: contextData.questionBank?.length || 0,
                    wordsCount: contextData.dictionary?.length || 0
                });
                // Call local Route Handler — no Lambda cold start, same-origin
                const response = await fetch("/api/chat", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(bodyWithContext)
                });
                console.log("[ChatSidebar] Response received:", {
                    ok: response.ok,
                    status: response.status
                });
                return response;
            } catch (error_0) {
                console.error("[ChatSidebar] Error in customFetch:", error_0);
                throw error_0;
            }
        }
    }["ChatSidebar.useCallback[customFetch]"], [
        contextData
    ]);
    // Memoize the transport object to prevent recreation on every render
    // Using 'data' streamProtocol for Server-Sent Events format: "data: {...}\n\n"
    const transport = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ChatSidebar.useMemo[transport]": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DefaultChatTransport"]({
                api: "/api/chat",
                fetch: customFetch,
                // Use our custom fetch that routes through Amplify
                streamProtocol: "data" // SSE format with tool call support
            })
    }["ChatSidebar.useMemo[transport]"], [
        customFetch
    ]);
    // Register all client-side tools with experimental_tools pattern
    // These tools execute on the client where DataStore is available
    const clientSideTools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ChatSidebar.useMemo[clientSideTools]": ()=>{
            const tools = {};
            // List of tools that should execute client-side (have access to DataStore)
            const clientSideToolNames = [
                "search_content",
                "create_section",
                "create_unit",
                "create_assignment",
                "add_timer_to_unit",
                "create_vocabulary_word",
                "create_question",
                "list_sections",
                "list_units",
                "get_unit_details",
                "update_unit",
                "delete_assignment",
                "start_practice_drill"
            ];
            // Register each client-side tool
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatTools$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toolDefinitions"].forEach({
                "ChatSidebar.useMemo[clientSideTools]": (toolDef)=>{
                    const toolName = toolDef.function.name;
                    if (clientSideToolNames.includes(toolName)) {
                        tools[toolName] = {
                            description: toolDef.function.description,
                            parameters: toolDef.function.parameters,
                            execute: ({
                                "ChatSidebar.useMemo[clientSideTools]": async (args)=>{
                                    console.log(`[ChatSidebar] Executing ${toolName}:`, args);
                                    try {
                                        const result_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatTools$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["executeTool"])(toolName, args);
                                        console.log(`[ChatSidebar] ${toolName} result:`, result_0);
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackChatToolUsed"])(assistantChat?.id, toolName, sectionId);
                                        return result_0;
                                    } catch (error_1) {
                                        console.error(`[ChatSidebar] Error executing ${toolName}:`, error_1);
                                        return {
                                            success: false,
                                            error: error_1.message || `Failed to execute ${toolName}`
                                        };
                                    }
                                }
                            })["ChatSidebar.useMemo[clientSideTools]"]
                        };
                    }
                }
            }["ChatSidebar.useMemo[clientSideTools]"]);
            return tools;
        }
    }["ChatSidebar.useMemo[clientSideTools]"], []);
    // Debounced save — coalesces rapid draft/message saves into a single write
    const pendingSaveRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null); // { chatId, fields: { draft?, messages? } }
    const saveTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const SAVE_DEBOUNCE_MS = 1500;
    const flushSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSidebar.useCallback[flushSave]": async ()=>{
            const pending = pendingSaveRef.current;
            if (!pending) return;
            pendingSaveRef.current = null;
            try {
                const client_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                // Fetch fresh _version to avoid conflicts
                const { data: fresh } = await client_1.models.AssistantChat.get({
                    id: pending.chatId
                });
                if (!fresh) {
                    console.warn("[ChatSidebar] Chat not found for save, skipping:", pending.chatId);
                    return;
                }
                // Optimistic version bump — subscription echo will be skipped
                if (chatVersionRef) {
                    chatVersionRef.current = (fresh._version || 0) + 1;
                }
                await client_1.models.AssistantChat.update({
                    id: pending.chatId,
                    _version: fresh._version,
                    ...pending.fields
                });
            } catch (error_2) {
                console.error("[ChatSidebar] Error in debounced save:", error_2);
            }
        }
    }["ChatSidebar.useCallback[flushSave]"], []);
    // Cleanup timer on unmount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSidebar.useEffect": ()=>{
            return ({
                "ChatSidebar.useEffect": ()=>{
                    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
                    // Flush any pending save on unmount
                    if (pendingSaveRef.current) flushSave();
                }
            })["ChatSidebar.useEffect"];
        }
    }["ChatSidebar.useEffect"], [
        flushSave
    ]);
    const enqueueSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSidebar.useCallback[enqueueSave]": (chatId, fields)=>{
            if (!chatId) return;
            // Merge into pending save — later fields overwrite earlier ones
            if (pendingSaveRef.current?.chatId === chatId) {
                Object.assign(pendingSaveRef.current.fields, fields);
            } else {
                // Different chat or first save — flush old, start new
                if (pendingSaveRef.current) flushSave();
                pendingSaveRef.current = {
                    chatId,
                    fields: {
                        ...fields
                    }
                };
            }
            if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
            saveTimerRef.current = setTimeout(flushSave, SAVE_DEBOUNCE_MS);
        }
    }["ChatSidebar.useCallback[enqueueSave]"], [
        flushSave
    ]);
    const saveDraft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSidebar.useCallback[saveDraft]": (draftText, chat, currentMessages = [])=>{
            if (!chat?.id) return;
            const fields_0 = {
                draft: draftText
            };
            if (currentMessages.length > 0) {
                fields_0.messages = JSON.stringify(currentMessages);
            }
            enqueueSave(chat.id, fields_0);
        }
    }["ChatSidebar.useCallback[saveDraft]"], [
        enqueueSave
    ]);
    const saveMessages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSidebar.useCallback[saveMessages]": (msgs, chat_0, currentDraft)=>{
            if (!chat_0) return;
            const clonedMessages = deepCloneMessages(msgs);
            const fields_1 = {
                messages: JSON.stringify(clonedMessages)
            };
            if (currentDraft !== undefined) fields_1.draft = currentDraft;
            enqueueSave(chat_0.id, fields_1);
        }
    }["ChatSidebar.useCallback[saveMessages]"], [
        deepCloneMessages,
        enqueueSave
    ]);
    const saveFileAssociations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSidebar.useCallback[saveFileAssociations]": async (files_0, chat_1)=>{
            if (!chat_1) return;
            try {
                const client_2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                // Query existing associations
                const { data: currentAssociations } = await client_2.models.AssistantChatFile.list({
                    filter: {
                        chatID: {
                            eq: chat_1.id
                        }
                    }
                });
                const currentFileIds = new Set(currentAssociations.map({
                    "ChatSidebar.useCallback[saveFileAssociations]": (a)=>a.fileID
                }["ChatSidebar.useCallback[saveFileAssociations]"]));
                const uploadedFileIds = new Set(files_0.filter({
                    "ChatSidebar.useCallback[saveFileAssociations]": (f_3)=>f_3.id
                }["ChatSidebar.useCallback[saveFileAssociations]"]).map({
                    "ChatSidebar.useCallback[saveFileAssociations]": (f_4)=>f_4.id
                }["ChatSidebar.useCallback[saveFileAssociations]"]));
                const filesToAdd = files_0.filter({
                    "ChatSidebar.useCallback[saveFileAssociations].filesToAdd": (f_5)=>f_5.id && !currentFileIds.has(f_5.id)
                }["ChatSidebar.useCallback[saveFileAssociations].filesToAdd"]);
                const associationsToRemove = currentAssociations.filter({
                    "ChatSidebar.useCallback[saveFileAssociations].associationsToRemove": (a_0)=>!uploadedFileIds.has(a_0.fileID)
                }["ChatSidebar.useCallback[saveFileAssociations].associationsToRemove"]);
                if (filesToAdd.length === 0 && associationsToRemove.length === 0) return;
                for (const association of associationsToRemove){
                    await client_2.models.AssistantChatFile.delete({
                        id: association.id
                    });
                }
                for (const file of filesToAdd){
                    await client_2.models.AssistantChatFile.create({
                        chatID: chat_1.id,
                        fileID: file.id
                    });
                }
            } catch (error_3) {
                console.error("[ChatSidebar] Error saving file associations:", error_3);
            }
        }
    }["ChatSidebar.useCallback[saveFileAssociations]"], []);
    // Nailed It detection — processes AI responses for mastery signals
    const { processResponse: processNailedIt, showCelebration, dismissCelebration, lastResult: nailedItResult } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useNailedItDetection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNailedItDetection"])({
        onAwardXP: {
            "ChatSidebar.useNailedItDetection": (xp, reason)=>{
                if (!user?.username) return;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$180649__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["awardXP"])(user.username, reason);
            }
        }["ChatSidebar.useNailedItDetection"]
    });
    // Use Vercel AI SDK's useChat hook with memoized transport
    const chatHookResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$react$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChat"])({
        transport,
        // Register client-side tools using experimental_tools
        // These execute in the browser with access to DataStore
        experimental_tools: clientSideTools,
        // Automatically send when all tool results are available
        experimental_sendAutomaticallyWhen: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lastAssistantMessageIsCompleteWithToolCalls"],
        onError: {
            "ChatSidebar.useChat[chatHookResult]": (error_4)=>{
                console.error("[ChatSidebar] Chat error:", error_4);
            }
        }["ChatSidebar.useChat[chatHookResult]"],
        onFinish: {
            "ChatSidebar.useChat[chatHookResult]": (message)=>{
                console.log("[ChatSidebar] Message finished:", message);
                // Check AI response for Nailed It signals
                const textContent = message?.parts?.filter({
                    "ChatSidebar.useChat[chatHookResult]": (p)=>p.type === "text"
                }["ChatSidebar.useChat[chatHookResult]"]).map({
                    "ChatSidebar.useChat[chatHookResult]": (p_0)=>p_0.text
                }["ChatSidebar.useChat[chatHookResult]"]).join("") || "";
                if (textContent) {
                    processNailedIt(textContent);
                }
                // Save messages when streaming completes
                if (assistantChat) {
                    saveMessages(messages_0, assistantChat, input);
                }
            }
        }["ChatSidebar.useChat[chatHookResult]"]
    });
    // Validate hook result
    if (!chatHookResult) {
        console.error("[ChatSidebar] useChat returned null/undefined!");
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                p: 2
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                severity: "error",
                children: t("chatSidebar.chatInitFailure")
            }, void 0, false, {
                fileName: "[project]/src/components/ChatSidebar.jsx",
                lineNumber: 810,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/ChatSidebar.jsx",
            lineNumber: 807,
            columnNumber: 12
        }, ("TURBOPACK compile-time value", void 0));
    }
    // Destructure all available functions from useChat API
    const { messages: messages_0 = [], sendMessage, regenerate, setMessages = ()=>{}, error: chatError, status = "idle", stop, toolCalls = [] } = chatHookResult || {};
    // Derive loading state from useChat status
    const isLoading = status === "in_progress" || status === "streaming" || status === "submitted";
    // Monitor messages for tool actions and execute them
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSidebar.useEffect": ()=>{
            if (!messages_0 || messages_0.length === 0) return;
            // Get the last message
            const lastMessage = messages_0[messages_0.length - 1];
            if (!lastMessage || lastMessage.role !== "assistant") return;
            // Extract tool parts with outputs
            const toolParts = lastMessage.parts?.filter({
                "ChatSidebar.useEffect": (part)=>part.type?.startsWith("tool-") && part.state === "output-available" && part.output
            }["ChatSidebar.useEffect"]) || [];
            if (toolParts.length === 0) return;
            // Process each tool output for actions
            toolParts.forEach({
                "ChatSidebar.useEffect": (part_0)=>{
                    let output;
                    try {
                        output = typeof part_0.output === "string" ? JSON.parse(part_0.output) : part_0.output;
                    } catch (e_0) {
                        console.error("[ChatSidebar] Failed to parse tool output:", e_0);
                        return;
                    }
                    if (!output || !output.action) return;
                    const { action: action_0 } = output;
                    // Handle tour actions
                    if (action_0 === "start_tour" && tourContext) {
                        const { tourId, mode = "tutorial" } = output;
                        console.log("[ChatSidebar] Starting tour:", tourId, "mode:", mode);
                        tourContext.startTour(tourId, mode);
                    } else if (action_0 === "stop_tour" && tourContext) {
                        console.log("[ChatSidebar] Stopping tour");
                        tourContext.stopTour();
                    } else if (action_0 === "navigate_to_tab" && tabContext?.setLeftTab) {
                        const { tab } = output;
                        console.log("[ChatSidebar] Navigating to tab:", tab);
                        tabContext.setLeftTab(tab);
                    }
                // Note: 'insert_editor_block' actions are handled by BlockInsertPreview component
                }
            }["ChatSidebar.useEffect"]);
        }
    }["ChatSidebar.useEffect"], [
        messages_0,
        tourContext,
        tabContext
    ]);
    // Simple input change handler with debounced draft saving
    const handleInputChange = (e_1)=>{
        const newValue = e_1.target.value;
        dispatch({
            type: ACTIONS.SET_INPUT,
            payload: newValue
        });
        // Debounce draft saving
        if (assistantChat) {
            clearTimeout(handleInputChange.timeoutId);
            handleInputChange.timeoutId = setTimeout(()=>{
                saveDraft(newValue, assistantChat, messages_0);
            }, 1000);
        }
    };
    // Simple submit function
    const submitMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSidebar.useCallback[submitMessage]": async (e_2)=>{
            e_2?.preventDefault();
            if (!input?.trim() || !sendMessage) return;
            try {
                sendMessage({
                    text: input
                });
                dispatch({
                    type: ACTIONS.SET_INPUT,
                    payload: ""
                });
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackChatMessageSent"])(assistantChat?.id, sectionId, input.length);
                // Clear draft (debounced)
                if (assistantChat?.draft) {
                    enqueueSave(assistantChat.id, {
                        draft: ""
                    });
                }
            } catch (error_5) {
                console.error("[ChatSidebar] Error sending message:", error_5);
            }
        }
    }["ChatSidebar.useCallback[submitMessage]"], [
        input,
        sendMessage,
        assistantChat,
        enqueueSave
    ]);
    // Auto-scroll to bottom when messages change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSidebar.useEffect": ()=>{
            if (chatContainerRef.current) {
                chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
            }
        }
    }["ChatSidebar.useEffect"], [
        messages_0
    ]);
    // Save file associations when files change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSidebar.useEffect": ()=>{
            if (assistantChat && uploadedFiles) {
                saveFileAssociations(uploadedFiles, assistantChat);
            }
        }
    }["ChatSidebar.useEffect"], [
        uploadedFiles,
        assistantChat?.id,
        saveFileAssociations
    ]);
    // Note: Section data is now provided by SectionContext
    // Removed redundant Section observer to reduce subscription overhead
    // Sync document statuses from FilesContext (avoids duplicate Document.observeQuery)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSidebar.useEffect": ()=>{
            if (!filesContextDocuments || Object.keys(filesContextDocuments).length === 0) return;
            const statusMap = {};
            Object.values(filesContextDocuments).forEach({
                "ChatSidebar.useEffect": (doc)=>{
                    if (doc && doc.id) {
                        statusMap[doc.id] = {
                            status: doc.status,
                            pageCount: doc.pageCount,
                            s3Key: doc.s3Key,
                            _version: doc._version
                        };
                    }
                }
            }["ChatSidebar.useEffect"]);
            dispatch({
                type: ACTIONS.SET_DOCUMENT_STATUSES,
                payload: statusMap
            });
        }
    }["ChatSidebar.useEffect"], [
        filesContextDocuments
    ]);
    // Update document processing status when document status changes
    const documentStatusesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSidebar.useEffect": ()=>{
            // Only run if documentStatuses actually changed
            const statusesStr = JSON.stringify(documentStatuses);
            if (documentStatusesRef.current.str === statusesStr) return;
            documentStatusesRef.current.str = statusesStr;
            const updated = {
                ...documentProcessingStatus
            };
            let hasChanges = false;
            Object.entries(updated).forEach({
                "ChatSidebar.useEffect": ([index_0, status_0])=>{
                    if (status_0.documentId && documentStatuses[status_0.documentId]) {
                        const docStatus = documentStatuses[status_0.documentId].status;
                        const pageCount = documentStatuses[status_0.documentId].pageCount;
                        // Map document status to processing status
                        if (docStatus === "completed" && status_0.status !== "analyzed") {
                            updated[index_0] = {
                                ...status_0,
                                status: "analyzed",
                                progress: 100,
                                message: `Analysis complete! ${pageCount ? `${pageCount} pages analyzed.` : ""}`.trim()
                            };
                            hasChanges = true;
                        } else if (docStatus === "analyzing" && status_0.status !== "analyzing") {
                            updated[index_0] = {
                                ...status_0,
                                status: "analyzing",
                                message: "Analyzing content..."
                            };
                            hasChanges = true;
                        } else if (docStatus === "extracting" && status_0.status !== "extracting") {
                            updated[index_0] = {
                                ...status_0,
                                status: "extracting",
                                message: "Extracting text..."
                            };
                            hasChanges = true;
                        } else if (docStatus === "uploaded" && [
                            "analyzing",
                            "extracting"
                        ].includes(status_0.status)) {
                            // Document went back to uploaded - likely cancelled
                            updated[index_0] = {
                                ...status_0,
                                status: "cancelled",
                                message: t("chatSidebar.analysisCancelled")
                            };
                            hasChanges = true;
                        } else if (docStatus === "failed") {
                            updated[index_0] = {
                                ...status_0,
                                status: "error",
                                message: "Analysis failed"
                            };
                            hasChanges = true;
                        }
                    }
                }
            }["ChatSidebar.useEffect"]);
            if (hasChanges) {
                dispatch({
                    type: ACTIONS.SET_DOCUMENT_PROCESSING_STATUS,
                    payload: updated
                });
            }
        }
    }["ChatSidebar.useEffect"], [
        Object.keys(documentStatuses).length
    ]);
    const handleDragOver = (e_3)=>{
        e_3.preventDefault();
        e_3.stopPropagation();
        dispatch({
            type: ACTIONS.SET_DRAGGING,
            payload: true
        });
    };
    const handleDragLeave = (e_4)=>{
        e_4.preventDefault();
        e_4.stopPropagation();
        dispatch({
            type: ACTIONS.SET_DRAGGING,
            payload: false
        });
    };
    const handleDrop = async (e_5)=>{
        e_5.preventDefault();
        e_5.stopPropagation();
        dispatch({
            type: ACTIONS.SET_DRAGGING,
            payload: false
        });
        const files_1 = Array.from(e_5.dataTransfer.files);
        console.log("Files dropped:", files_1);
        dispatch({
            type: ACTIONS.ADD_UPLOADED_FILES,
            payload: files_1
        });
    };
    const handleFileSelect = (e_6)=>{
        const files_2 = Array.from(e_6.target.files);
        console.log("Files selected:", files_2);
        dispatch({
            type: ACTIONS.ADD_UPLOADED_FILES,
            payload: files_2
        });
        files_2.forEach((f_6)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackChatFileUploaded"])(assistantChat?.id, f_6.type || "unknown"));
    };
    const removeFile = (index_1)=>{
        dispatch({
            type: ACTIONS.REMOVE_UPLOADED_FILE,
            payload: index_1
        });
    };
    // Cancel document processing
    const cancelProcessing = async (index_2)=>{
        const status_1 = documentProcessingStatus[index_2];
        if (!status_1 || !status_1.documentId) {
            console.warn("[ChatSidebar] No document ID to cancel");
            return;
        }
        try {
            console.log("[ChatSidebar] Cancelling analysis for document:", status_1.documentId);
            dispatch({
                type: ACTIONS.UPDATE_DOCUMENT_PROCESSING_STATUS,
                payload: {
                    [index_2]: {
                        ...documentProcessingStatus[index_2],
                        message: t("chatSidebar.cancellingMessage")
                    }
                }
            });
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cancelPDFAnalysis"])(status_1.documentId);
            dispatch({
                type: ACTIONS.UPDATE_DOCUMENT_PROCESSING_STATUS,
                payload: {
                    [index_2]: {
                        ...documentProcessingStatus[index_2],
                        status: "cancelled",
                        message: t("chatSidebar.analysisCancelled")
                    }
                }
            });
        } catch (error_6) {
            console.error("[ChatSidebar] Error cancelling analysis:", error_6);
            dispatch({
                type: ACTIONS.UPDATE_DOCUMENT_PROCESSING_STATUS,
                payload: {
                    [index_2]: {
                        ...documentProcessingStatus[index_2],
                        message: `Cancel failed: ${error_6.message}`
                    }
                }
            });
        }
    };
    // Open vocabulary review dialog
    const openVocabularyReview = (documentId)=>{
        dispatch({
            type: ACTIONS.SET_REVIEW_DOCUMENT_ID,
            payload: documentId
        });
        dispatch({
            type: ACTIONS.SET_VOCABULARY_REVIEW_DIALOG,
            payload: true
        });
    };
    // Handle vocabulary import completion
    const handleVocabularyImportComplete = (result_1)=>{
        console.log("[ChatSidebar] Vocabulary import complete:", result_1);
        // Could show a success message or update UI
        // Optionally close the dialog after a delay
        setTimeout(()=>{
            dispatch({
                type: ACTIONS.SET_VOCABULARY_REVIEW_DIALOG,
                payload: false
            });
        }, 2000);
    };
    // Process documents when they're added
    const processDocument = async (file_0, index_3)=>{
        if (file_0.type !== "application/pdf" && file_0.type !== "application/vnd.openxmlformats-officedocument.wordprocessingml.document" && file_0.type !== "application/msword" && file_0.type !== "text/plain" && file_0.type !== "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" && file_0.type !== "application/vnd.ms-excel" && file_0.type !== "text/csv") return;
        try {
            console.log("[ChatSidebar] Processing document:", file_0.name, {
                index: index_3
            });
            // Update status to uploading
            dispatch({
                type: ACTIONS.UPDATE_DOCUMENT_PROCESSING_STATUS,
                payload: {
                    [index_3]: {
                        status: "uploading",
                        progress: 0,
                        message: "Uploading document..."
                    }
                }
            });
            // Get identity ID if not already available
            const session1 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAuthSession"])();
            const identityId1 = session1.identityId;
            console.log("[ChatSidebar] Identity ID:", identityId1);
            console.log("[ChatSidebar] Unit ID:", unit?.id);
            // Upload and analyze
            const result_2 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadAndAnalyzePDF"])(file_0, identityId1, unit?.id, true, // auto-analyze
            (loaded, total)=>{
                const progress = Math.round(loaded / total * 100);
                dispatch({
                    type: ACTIONS.UPDATE_DOCUMENT_PROCESSING_STATUS,
                    payload: {
                        [index_3]: {
                            status: "uploading",
                            progress,
                            message: `Uploading... ${progress}%`
                        }
                    }
                });
            });
            console.log("[ChatSidebar] Upload result:", result_2);
            // Update status based on result - store documentId for tracking
            if (result_2.analysisResult && result_2.analysisResult.success) {
                dispatch({
                    type: ACTIONS.UPDATE_DOCUMENT_PROCESSING_STATUS,
                    payload: {
                        [index_3]: {
                            status: "analyzing",
                            progress: 100,
                            message: "Document uploaded, analysis started...",
                            documentId: result_2.documentModel?.id
                        }
                    }
                });
            } else if (result_2.documentModel) {
                dispatch({
                    type: ACTIONS.UPDATE_DOCUMENT_PROCESSING_STATUS,
                    payload: {
                        [index_3]: {
                            status: "uploaded",
                            progress: 100,
                            message: "Document uploaded successfully",
                            documentId: result_2.documentModel?.id
                        }
                    }
                });
            } else {
                dispatch({
                    type: ACTIONS.UPDATE_DOCUMENT_PROCESSING_STATUS,
                    payload: {
                        [index_3]: {
                            status: "uploaded",
                            progress: 100,
                            message: "Document uploaded (no document created)"
                        }
                    }
                });
            }
        } catch (error_7) {
            console.error("[ChatSidebar] Error processing document:", error_7);
            dispatch({
                type: ACTIONS.UPDATE_DOCUMENT_PROCESSING_STATUS,
                payload: {
                    [index_3]: {
                        status: "error",
                        progress: 0,
                        message: `Error: ${error_7.message}`
                    }
                }
            });
        }
    };
    // Detect documents and offer to process them
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSidebar.useEffect": ()=>{
            uploadedFiles.forEach({
                "ChatSidebar.useEffect": (file_1, index_4)=>{
                    if (file_1.type === "application/pdf" && !documentProcessingStatus[index_4]) {
                        // Ask user if they want to process the document
                        dispatch({
                            type: ACTIONS.SET_CONFIRM_DIALOG,
                            payload: {
                                open: true,
                                message: `Would you like to upload and analyze "${file_1.name}"? This will extract text and generate vocabulary.`,
                                severity: "info",
                                onConfirm: {
                                    "ChatSidebar.useEffect": ()=>{
                                        processDocument(file_1, index_4);
                                        dispatch({
                                            type: ACTIONS.SET_CONFIRM_DIALOG,
                                            payload: {
                                                open: false,
                                                message: "",
                                                onConfirm: null,
                                                severity: "info"
                                            }
                                        });
                                    }
                                }["ChatSidebar.useEffect"],
                                onCancel: {
                                    "ChatSidebar.useEffect": ()=>{
                                        // Mark as declined
                                        dispatch({
                                            type: ACTIONS.UPDATE_DOCUMENT_PROCESSING_STATUS,
                                            payload: {
                                                [index_4]: {
                                                    status: "declined",
                                                    progress: 0,
                                                    message: "Analysis declined"
                                                }
                                            }
                                        });
                                        dispatch({
                                            type: ACTIONS.SET_CONFIRM_DIALOG,
                                            payload: {
                                                open: false,
                                                message: "",
                                                onConfirm: null,
                                                severity: "info"
                                            }
                                        });
                                    }
                                }["ChatSidebar.useEffect"]
                            }
                        });
                    }
                }
            }["ChatSidebar.useEffect"]);
        }
    }["ChatSidebar.useEffect"], [
        uploadedFiles.length,
        unit?.id
    ]); // Use length instead of the full objects to prevent infinite loops
    // Don't render until translations are ready to prevent hydration errors
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    flexDirection: "column",
                    height: "100%",
                    minHeight: 0,
                    position: "relative"
                },
                onDragOver: handleDragOver,
                onDragLeave: handleDragLeave,
                onDrop: handleDrop,
                children: [
                    isDragging && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            position: "absolute",
                            height: "100%",
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            bgcolor: "primary.main",
                            opacity: 0.9,
                            zIndex: 1000,
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            pointerEvents: "none"
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                textAlign: "center",
                                color: "white"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$UploadFile$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    sx: {
                                        fontSize: 64,
                                        mb: 2
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                    lineNumber: 1311,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "h6",
                                    children: t("chatSidebar.dropFilesHere")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                    lineNumber: 1315,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    children: t("chatSidebar.attachFilesMessage")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                    lineNumber: 1318,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ChatSidebar.jsx",
                            lineNumber: 1307,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/ChatSidebar.jsx",
                        lineNumber: 1292,
                        columnNumber: 24
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
                        elevation: 0,
                        sx: {
                            p: 1.5,
                            borderBottom: "1px solid",
                            borderColor: "divider",
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 1
                                },
                                children: historyDrawerOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$History$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            color: "primary"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                            lineNumber: 1338,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "h6",
                                            sx: {
                                                fontSize: "1rem",
                                                fontWeight: 600
                                            },
                                            children: t("chatSidebar.history")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                            lineNumber: 1339,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Chat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            color: "primary"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                            lineNumber: 1346,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "h6",
                                            sx: {
                                                fontSize: "1rem",
                                                fontWeight: 600
                                            },
                                            children: t("chatSidebar.aiAssistant")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                            lineNumber: 1347,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                lineNumber: 1332,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    gap: 0.5
                                },
                                children: [
                                    historyDrawerOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                        size: "small",
                                        onClick: ()=>dispatch({
                                                type: ACTIONS.SET_HISTORY_DRAWER_OPEN,
                                                payload: false
                                            }),
                                        title: t("chatSidebar.backToChat"),
                                        sx: {
                                            color: "primary.main"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Chat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            fontSize: "small"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                            lineNumber: 1365,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 1359,
                                        columnNumber: 34
                                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                size: "small",
                                                onClick: async ()=>{
                                                    // Save current draft before switching to history
                                                    if (input && assistantChat?.id) {
                                                        await saveDraft(input, assistantChat, messages_0);
                                                    }
                                                    dispatch({
                                                        type: ACTIONS.SET_HISTORY_DRAWER_OPEN,
                                                        payload: true
                                                    });
                                                },
                                                title: "Chat history",
                                                sx: {
                                                    color: "primary.main"
                                                },
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$History$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    fontSize: "small"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 1379,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 1367,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                size: "small",
                                                onClick: async ()=>{
                                                    try {
                                                        // Step 0: Save current state if there's a current chat
                                                        if (assistantChat?.id && (input.trim() || messages_0.length > 0)) {
                                                            console.log("[ChatSidebar] Saving current chat state before creating new chat");
                                                            await saveDraft(input, assistantChat, messages_0);
                                                        }
                                                        console.log("[ChatSidebar] Creating new chat");
                                                        // Clear local state
                                                        setMessages([]);
                                                        dispatch({
                                                            type: ACTIONS.RESET_FOR_NEW_CHAT
                                                        });
                                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackChatSessionStarted"])(sectionId);
                                                        // Create new AssistantChat directly
                                                        const client_3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                                                        const result_3 = await client_3.models.AssistantChat.create({
                                                            model: "gpt-4",
                                                            messages: JSON.stringify([]),
                                                            // messages field is AWSJSON type (string)
                                                            threadInstructions: "",
                                                            additionalInstructions: ""
                                                        });
                                                        console.log("[ChatSidebar] Create result:", result_3);
                                                        if (result_3.errors && result_3.errors.length > 0) {
                                                            console.error("[ChatSidebar] Errors creating chat:", result_3.errors);
                                                            throw new Error(result_3.errors[0].message);
                                                        }
                                                        if (!result_3.data) {
                                                            console.error("[ChatSidebar] No data returned from create. Full result:", JSON.stringify(result_3, null, 2));
                                                            throw new Error("Failed to create chat - no data returned. Check that backend is deployed and accessible.");
                                                        }
                                                        console.log("[ChatSidebar] Created new chat:", result_3.data.id, "at:", result_3.data.createdAt);
                                                    // ChatContext subscription will pick up the new chat automatically
                                                    } catch (error_8) {
                                                        console.error("[ChatSidebar] Error creating new chat:", error_8);
                                                        alert("Failed to create new chat. Please check that the backend is running and try again.");
                                                    }
                                                },
                                                title: t("chatSidebar.newChat"),
                                                sx: {
                                                    color: "success.main"
                                                },
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    fontSize: "small"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 1425,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 1381,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                size: "small",
                                                onClick: async ()=>{
                                                    // Archive current chat by marking it archived
                                                    // ChatContext will detect this and create a new chat automatically
                                                    if (assistantChat?.id && !isLoadingChat) {
                                                        try {
                                                            // Mark current chat as archived
                                                            const client_4 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                                                            // Flush pending debounced saves before archiving
                                                            await flushSave();
                                                            const { data: freshChat } = await client_4.models.AssistantChat.get({
                                                                id: assistantChat.id
                                                            });
                                                            await client_4.models.AssistantChat.update({
                                                                id: assistantChat.id,
                                                                archived: true,
                                                                _version: freshChat?._version
                                                            });
                                                            console.log("[ChatSidebar] Chat archived - ChatContext will create new chat");
                                                            // Clear local state
                                                            setMessages([]);
                                                            dispatch({
                                                                type: ACTIONS.RESET_FOR_NEW_CHAT
                                                            });
                                                        } catch (error_9) {
                                                            console.error("[ChatSidebar] Error archiving chat:", error_9);
                                                        }
                                                    }
                                                },
                                                title: t("chatSidebar.archiveChat"),
                                                sx: {
                                                    color: "warning.main"
                                                },
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Archive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    fontSize: "small"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 1460,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 1427,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true),
                                    onClose && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                        size: "small",
                                        onClick: onClose,
                                        "aria-label": t("chatSidebar.close"),
                                        "data-testid": "chat-close-button",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            fontSize: "small"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                            lineNumber: 1464,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 1463,
                                        columnNumber: 25
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                lineNumber: 1355,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ChatSidebar.jsx",
                        lineNumber: 1324,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            flex: 1,
                            display: "flex",
                            flexDirection: "column",
                            bgcolor: "background.default",
                            minHeight: 0,
                            overflow: "hidden"
                        },
                        children: historyDrawerOpen ? /* Show chat history list */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                p: 2
                            },
                            children: isLoadingChat && chatHistories.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    justifyContent: "center",
                                    p: 3
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                    variant: "rectangular",
                                    width: "100%",
                                    height: 60,
                                    sx: {
                                        borderRadius: 1
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                    lineNumber: 1487,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                lineNumber: 1482,
                                columnNumber: 62
                            }, ("TURBOPACK compile-time value", void 0)) : chatHistories.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    height: "100%",
                                    color: "text.secondary",
                                    textAlign: "center",
                                    p: 3
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$History$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        sx: {
                                            fontSize: 48,
                                            mb: 2,
                                            opacity: 0.3
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 1500,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "body2",
                                        children: t("chatSidebar.noHistoryAvailable")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 1505,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                lineNumber: 1490,
                                columnNumber: 55
                            }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    chatHistories.filter((h_0)=>!h_0.archived).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                variant: "subtitle2",
                                                sx: {
                                                    px: 2,
                                                    py: 1,
                                                    color: "text.secondary",
                                                    fontWeight: 600
                                                },
                                                children: t("chatSidebar.activeChats")
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 1511,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                                sx: {
                                                    p: 0
                                                },
                                                children: chatHistories.filter((h)=>!h.archived).map((history, index_5)=>{
                                                    console.log("[ChatSidebar] Rendering chat history:", history.id, history);
                                                    const isActive = assistantChat?.id === history.id;
                                                    const isArchived = history.archived;
                                                    let historyMessages = [];
                                                    let historyDraft = "";
                                                    try {
                                                        // Ensure messages is always an array (stored as JSON string in DB)
                                                        const rawMessages_0 = history?.messages;
                                                        if (Array.isArray(rawMessages_0)) {
                                                            historyMessages = rawMessages_0;
                                                        } else if (typeof rawMessages_0 === "string" && rawMessages_0) {
                                                            historyMessages = JSON.parse(rawMessages_0);
                                                            if (!Array.isArray(historyMessages)) historyMessages = [];
                                                        }
                                                        historyDraft = history?.draft || "";
                                                    } catch (err_3) {
                                                        console.error("[ChatSidebar] Error parsing messages:", err_3);
                                                        historyMessages = [];
                                                    }
                                                    const messageCount = historyMessages.length;
                                                    const firstUserMessage = historyMessages.find((m)=>m.role === "user");
                                                    console.log("First user message for history", history.id, ":", firstUserMessage, historyMessages);
                                                    // Extract text from message.parts array (AI SDK v6 format)
                                                    let preview = historyDraft || t("chatSidebar.emptyChat");
                                                    if (firstUserMessage?.parts && Array.isArray(firstUserMessage.parts)) {
                                                        preview = firstUserMessage.parts.filter((p_1)=>p_1.type === "text").map((p_2)=>p_2.text).join("");
                                                    }
                                                    const displayPreview = typeof preview === "string" ? preview : JSON.stringify(preview);
                                                    const createdAt = history.createdAt ? new Date(history.createdAt).toLocaleDateString() : t("chatSidebar.unknown");
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__["ListItemButton"], {
                                                                onClick: async ()=>{
                                                                    if (assistantChat && input.trim()) {
                                                                        try {
                                                                            // Flush + save draft with fresh _version before switching
                                                                            await flushSave();
                                                                            const client_5 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                                                                            const { data: freshChat_0 } = await client_5.models.AssistantChat.get({
                                                                                id: assistantChat.id
                                                                            });
                                                                            await client_5.models.AssistantChat.update({
                                                                                id: assistantChat.id,
                                                                                draft: input,
                                                                                _version: freshChat_0?._version
                                                                            });
                                                                        } catch (error_10) {
                                                                            console.error("[ChatSidebar] Error saving draft:", error_10);
                                                                        }
                                                                    }
                                                                    if (tabContext?.switchToChat) {
                                                                        tabContext.switchToChat(history.id);
                                                                    } else {
                                                                        setCurrentChat(history);
                                                                        setMessages(JSON.parse(JSON.stringify(historyMessages)));
                                                                        dispatch({
                                                                            type: ACTIONS.SET_INPUT,
                                                                            payload: historyDraft || ""
                                                                        });
                                                                    }
                                                                    dispatch({
                                                                        type: ACTIONS.SET_HISTORY_DRAWER_OPEN,
                                                                        payload: false
                                                                    });
                                                                    console.log("[ChatSidebar] Switching to chat history:", history.id);
                                                                },
                                                                selected: isActive,
                                                                sx: {
                                                                    borderRadius: 1,
                                                                    mb: 0.5,
                                                                    bgcolor: isActive ? "primary.light" : "transparent",
                                                                    "&:hover": {
                                                                        bgcolor: isActive ? "primary.light" : "action.hover"
                                                                    }
                                                                },
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                                                    primary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                        variant: "body2",
                                                                        sx: {
                                                                            fontWeight: isActive ? 600 : 400,
                                                                            overflow: "hidden",
                                                                            textOverflow: "ellipsis",
                                                                            whiteSpace: "nowrap"
                                                                        },
                                                                        children: [
                                                                            displayPreview.substring(0, 50),
                                                                            displayPreview.length > 50 ? "..." : ""
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                        lineNumber: 1596,
                                                                        columnNumber: 58
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    secondary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                        variant: "caption",
                                                                        color: "text.secondary",
                                                                        children: [
                                                                            messageCount,
                                                                            " messages • ",
                                                                            createdAt,
                                                                            isArchived ? " • Archived" : ""
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                        lineNumber: 1604,
                                                                        columnNumber: 65
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                    lineNumber: 1596,
                                                                    columnNumber: 35
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                lineNumber: 1553,
                                                                columnNumber: 33
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            index_5 < chatHistories.length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
                                                                sx: {
                                                                    my: 0.5
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                lineNumber: 1609,
                                                                columnNumber: 72
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, history.id, true, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 1552,
                                                        columnNumber: 26
                                                    }, ("TURBOPACK compile-time value", void 0));
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 1519,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true),
                                    chatHistories.filter((h_3)=>h_3.archived).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                variant: "subtitle2",
                                                sx: {
                                                    px: 2,
                                                    py: 1,
                                                    mt: 2,
                                                    color: "text.secondary",
                                                    fontWeight: 600
                                                },
                                                children: t("chatSidebar.archivedChats")
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 1619,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                                sx: {
                                                    p: 0
                                                },
                                                children: chatHistories.filter((h_1)=>h_1.archived).map((history_0, index_6)=>{
                                                    const isActive_0 = assistantChat?.id === history_0.id;
                                                    const isLegacy = !history_0.assistantID;
                                                    let historyMessages_0 = [];
                                                    let historyDraft_0 = "";
                                                    try {
                                                        // Ensure messages is always an array (stored as JSON string in DB)
                                                        const rawMessages_1 = history_0?.messages;
                                                        if (Array.isArray(rawMessages_1)) {
                                                            historyMessages_0 = rawMessages_1;
                                                        } else if (typeof rawMessages_1 === "string" && rawMessages_1) {
                                                            historyMessages_0 = JSON.parse(rawMessages_1);
                                                            if (!Array.isArray(historyMessages_0)) historyMessages_0 = [];
                                                        }
                                                        historyDraft_0 = history_0?.draft || "";
                                                    } catch (err_4) {
                                                        console.error("[ChatSidebar] Error parsing messages:", err_4);
                                                        historyMessages_0 = [];
                                                    }
                                                    const messageCount_0 = historyMessages_0.length;
                                                    const firstUserMessage_0 = historyMessages_0.find((m_0)=>m_0.role === "user");
                                                    // Extract text from message.parts array (AI SDK v6 format)
                                                    let preview_0 = historyDraft_0 || t("chatSidebar.emptyChat");
                                                    if (firstUserMessage_0?.parts && Array.isArray(firstUserMessage_0.parts)) {
                                                        preview_0 = firstUserMessage_0.parts.filter((p_3)=>p_3.type === "text").map((p_4)=>p_4.text).join("");
                                                    }
                                                    const displayPreview_0 = typeof preview_0 === "string" ? preview_0 : JSON.stringify(preview_0);
                                                    const createdAt_0 = history_0.createdAt ? new Date(history_0.createdAt).toLocaleDateString() : t("chatSidebar.unknown");
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__["ListItemButton"], {
                                                                onClick: async ()=>{
                                                                    if (tabContext?.switchToChat) {
                                                                        tabContext.switchToChat(history_0.id);
                                                                    } else {
                                                                        setCurrentChat(history_0);
                                                                        setMessages(JSON.parse(JSON.stringify(historyMessages_0)));
                                                                        dispatch({
                                                                            type: ACTIONS.SET_INPUT,
                                                                            payload: historyDraft_0 || ""
                                                                        });
                                                                    }
                                                                    dispatch({
                                                                        type: ACTIONS.SET_HISTORY_DRAWER_OPEN,
                                                                        payload: false
                                                                    });
                                                                    console.log("[ChatSidebar] Switching to archived chat:", history_0.id);
                                                                },
                                                                selected: isActive_0,
                                                                sx: {
                                                                    borderRadius: 1,
                                                                    mb: 0.5,
                                                                    bgcolor: isActive_0 ? "primary.light" : "transparent",
                                                                    "&:hover": {
                                                                        bgcolor: isActive_0 ? "primary.light" : "action.hover"
                                                                    },
                                                                    opacity: 0.7
                                                                },
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                                                        primary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                            variant: "body2",
                                                                            sx: {
                                                                                fontWeight: isActive_0 ? 600 : 400,
                                                                                overflow: "hidden",
                                                                                textOverflow: "ellipsis",
                                                                                whiteSpace: "nowrap"
                                                                            },
                                                                            children: [
                                                                                displayPreview_0.substring(0, 50),
                                                                                displayPreview_0.length > 50 ? "..." : ""
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                            lineNumber: 1685,
                                                                            columnNumber: 58
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        secondary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                            variant: "caption",
                                                                            color: "text.secondary",
                                                                            children: [
                                                                                messageCount_0,
                                                                                " messages • ",
                                                                                createdAt_0,
                                                                                isLegacy ? " • Legacy (read-only)" : ""
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                            lineNumber: 1693,
                                                                            columnNumber: 65
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                        lineNumber: 1685,
                                                                        columnNumber: 35
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                                                        title: isLegacy ? "Cannot unarchive legacy chat" : "Unarchive chat",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                                                size: "small",
                                                                                onClick: async (e_7)=>{
                                                                                    e_7.stopPropagation();
                                                                                    if (history_0.assistantID) {
                                                                                        try {
                                                                                            const client_6 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                                                                                            const { data: freshHistory } = await client_6.models.AssistantChat.get({
                                                                                                id: history_0.id
                                                                                            });
                                                                                            await client_6.models.AssistantChat.update({
                                                                                                id: history_0.id,
                                                                                                archived: false,
                                                                                                _version: freshHistory?._version
                                                                                            });
                                                                                            console.log("[ChatSidebar] Unarchived chat:", history_0.id);
                                                                                        } catch (error_11) {
                                                                                            console.error("[ChatSidebar] Error unarchiving chat:", error_11);
                                                                                        }
                                                                                    } else {
                                                                                        console.warn("[ChatSidebar] Cannot unarchive legacy chat");
                                                                                    }
                                                                                },
                                                                                disabled: isLegacy,
                                                                                sx: {
                                                                                    opacity: isLegacy ? 0.3 : 1
                                                                                },
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Unarchive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                    fontSize: "small"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                                    lineNumber: 1724,
                                                                                    columnNumber: 41
                                                                                }, ("TURBOPACK compile-time value", void 0))
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                                lineNumber: 1699,
                                                                                columnNumber: 39
                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                            lineNumber: 1698,
                                                                            columnNumber: 37
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                        lineNumber: 1697,
                                                                        columnNumber: 35
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                lineNumber: 1660,
                                                                columnNumber: 33
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            index_6 < chatHistories.filter((h_2)=>h_2.archived).length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
                                                                sx: {
                                                                    my: 0.5
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                lineNumber: 1729,
                                                                columnNumber: 100
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, history_0.id, true, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 1659,
                                                        columnNumber: 26
                                                    }, ("TURBOPACK compile-time value", void 0));
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 1628,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true)
                                ]
                            }, void 0, true)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ChatSidebar.jsx",
                            lineNumber: 1479,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0)) : /* Show normal chat messages with virtualization */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2f$VirtualizedMessageList$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VirtualizedMessageList"], {
                            messages: messages_0,
                            useLexicalRenderer: true,
                            "data-testid": "chat-messages",
                            renderMessage: (message_0, index_7)=>{
                                // Extract text content from message.parts (AI SDK v6 format)
                                let textContent_0 = "";
                                if (message_0.parts && Array.isArray(message_0.parts)) {
                                    textContent_0 = message_0.parts.filter((part_1)=>part_1.type === "text").map((part_2)=>part_2.text).join("");
                                }
                                // Extract tool invocations from message.parts
                                const toolParts_0 = message_0.parts?.filter((part_3)=>part_3.type?.startsWith("tool-")) || [];
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        width: "100%",
                                        mb: 1
                                    },
                                    children: [
                                        textContent_0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            sx: {
                                                display: "flex",
                                                alignItems: "flex-start",
                                                gap: 1,
                                                ...message_0.role === "user" ? {
                                                    justifyContent: "flex-end"
                                                } : {}
                                            },
                                            children: [
                                                message_0.role === "assistant" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BotAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BotAvatar"], {
                                                    size: 24
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 1760,
                                                    columnNumber: 60
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    className: message_0.role === "user" ? "user" : "assistant",
                                                    "data-role": message_0.role,
                                                    ...message_0.role === "assistant" ? {
                                                        "data-tour": "ai-message"
                                                    } : {},
                                                    sx: {
                                                        m: 0.75,
                                                        p: "0.75rem 1rem",
                                                        borderRadius: "1rem",
                                                        maxWidth: "85%",
                                                        wordWrap: "break-word",
                                                        ...message_0.role === "user" ? {
                                                            background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                                                            color: "white",
                                                            alignSelf: "flex-end",
                                                            marginLeft: "auto",
                                                            borderBottomRightRadius: "0.25rem"
                                                        } : {
                                                            bgcolor: "custom.chatBubbleAssistant",
                                                            color: "text.primary",
                                                            alignSelf: "flex-start",
                                                            borderBottomLeftRadius: "0.25rem",
                                                            border: 1,
                                                            borderColor: "divider",
                                                            position: "relative",
                                                            pr: 6,
                                                            pb: 4
                                                        }
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2f$LexicalMessageRenderer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalMessageRenderer"], {
                                                            content: textContent_0,
                                                            isStreaming: message_0.isStreaming || false
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1787,
                                                            columnNumber: 27
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        message_0.role === "assistant" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                            sx: {
                                                                position: "absolute",
                                                                bottom: 4,
                                                                right: 4
                                                            },
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AIFeedbackWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                contentType: "CHAT_MESSAGE",
                                                                messageId: message_0.id,
                                                                generatedContent: textContent_0,
                                                                model: message_0.model,
                                                                unitId: unit?.id,
                                                                sessionId: assistantChat?.id,
                                                                metadata: {
                                                                    unitName: unit?.name
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                lineNumber: 1795,
                                                                columnNumber: 31
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1790,
                                                            columnNumber: 62
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 1761,
                                                    columnNumber: 25
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                            lineNumber: 1752,
                                            columnNumber: 39
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        toolParts_0.map((part_4, toolIdx)=>{
                                            const callId = part_4.toolCallId;
                                            // Extract tool name from type (e.g., 'tool-search_content' -> 'search_content')
                                            const toolName_0 = part_4.type?.replace("tool-", "") || part_4.toolName || t("chatSidebar.unknown");
                                            // Render tool parts based on specific tool names
                                            if (toolName_0 === "search_content") {
                                                const executionState = toolExecutionStates[callId];
                                                let parsedOutput = null;
                                                if (part_4.state === "output-available" && part_4.output) {
                                                    try {
                                                        parsedOutput = typeof part_4.output === "string" ? JSON.parse(part_4.output) : part_4.output;
                                                    } catch (e_8) {
                                                        console.error("[ChatSidebar] Failed to parse search output:", e_8);
                                                    }
                                                }
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        width: "100%",
                                                        mb: 2,
                                                        p: 2,
                                                        bgcolor: "background.paper",
                                                        borderRadius: 2,
                                                        border: "1px solid",
                                                        borderColor: part_4.state === "output-error" ? "error.main" : "divider",
                                                        boxShadow: 1
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                            sx: {
                                                                display: "flex",
                                                                alignItems: "center",
                                                                gap: 1,
                                                                mb: 1.5
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                    variant: "body2",
                                                                    sx: {
                                                                        fontWeight: 600,
                                                                        color: "primary.main"
                                                                    },
                                                                    children: t("chatSidebar.searchResultsHeader")
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                    lineNumber: 1835,
                                                                    columnNumber: 31
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                executionState === "executing" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                                                    variant: "circular",
                                                                    width: 16,
                                                                    height: 16
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                    lineNumber: 1841,
                                                                    columnNumber: 66
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1829,
                                                            columnNumber: 29
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "input-streaming" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                fontStyle: "italic",
                                                                color: "text.secondary"
                                                            },
                                                            children: "Preparing search..."
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1844,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "input-available" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "body2",
                                                            sx: {
                                                                color: "text.secondary",
                                                                mb: 1,
                                                                fontStyle: "italic"
                                                            },
                                                            children: t("chatSidebar.searchingFor", {
                                                                query: part_4.input?.query
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1852,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-available" && parsedOutput && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                            sx: {
                                                                width: "100%"
                                                            },
                                                            children: parsedOutput.success ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                        variant: "body2",
                                                                        sx: {
                                                                            color: "success.dark",
                                                                            mb: 2,
                                                                            fontWeight: 500
                                                                        },
                                                                        children: t("chatSidebar.foundResults", {
                                                                            count: parsedOutput.results?.length || 0
                                                                        })
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                        lineNumber: 1866,
                                                                        columnNumber: 39
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2f$SearchResults$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                        results: parsedOutput.results || [],
                                                                        unitId: unit?.id,
                                                                        searchQuery: part_4.input?.query || "",
                                                                        tabHandlers: tabContext,
                                                                        onInsertWord: handleInsertWord,
                                                                        onInsertQuestion: handleInsertQuestion,
                                                                        onFocusItem: handleFocusItem
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                        lineNumber: 1875,
                                                                        columnNumber: 39
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                variant: "body2",
                                                                sx: {
                                                                    color: "error.main"
                                                                },
                                                                children: parsedOutput.error || t("chatSidebar.searchFailed")
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                lineNumber: 1876,
                                                                columnNumber: 43
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1862,
                                                            columnNumber: 85
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-error" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                color: "error.main",
                                                                wordBreak: "break-word",
                                                                overflowWrap: "break-word",
                                                                whiteSpace: "normal"
                                                            },
                                                            children: [
                                                                "✗ ",
                                                                part_4.errorText
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1883,
                                                            columnNumber: 65
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, callId || toolIdx, true, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 1819,
                                                    columnNumber: 24
                                                }, ("TURBOPACK compile-time value", void 0));
                                            }
                                            // Handle create_section tool
                                            if (toolName_0 === "create_section") {
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        width: "100%",
                                                        mb: 1,
                                                        p: 1,
                                                        bgcolor: "transparent",
                                                        borderLeft: "2px solid",
                                                        borderColor: part_4.state === "output-error" ? "error.main" : "grey.400",
                                                        fontSize: "0.8rem",
                                                        color: "text.secondary",
                                                        overflow: "hidden",
                                                        overflowWrap: "break-word",
                                                        wordBreak: "break-word"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                fontWeight: 600,
                                                                display: "block",
                                                                mb: 0.5,
                                                                color: "text.primary"
                                                            },
                                                            children: t("chatSidebar.createSection")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1910,
                                                            columnNumber: 29
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "input-streaming" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                fontStyle: "italic"
                                                            },
                                                            children: "Preparing..."
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1919,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "input-available" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                wordBreak: "break-word",
                                                                overflowWrap: "break-word",
                                                                whiteSpace: "normal"
                                                            },
                                                            children: [
                                                                '"',
                                                                part_4.input?.name,
                                                                '"'
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1926,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-available" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                color: "success.dark",
                                                                wordBreak: "break-word",
                                                                overflowWrap: "break-word",
                                                                whiteSpace: "normal"
                                                            },
                                                            children: [
                                                                "✓",
                                                                " ",
                                                                part_4.output?.message || t("chatSidebar.created")
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1935,
                                                            columnNumber: 69
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-error" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                color: "error.main",
                                                                wordBreak: "break-word",
                                                                overflowWrap: "break-word",
                                                                whiteSpace: "normal"
                                                            },
                                                            children: [
                                                                "✗ ",
                                                                part_4.errorText
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1946,
                                                            columnNumber: 65
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, callId || toolIdx, true, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 1897,
                                                    columnNumber: 24
                                                }, ("TURBOPACK compile-time value", void 0));
                                            }
                                            // Handle block insertion tools (quiz, answer, meaning-association, custom-answer, content)
                                            if ([
                                                "insert_quiz",
                                                "insert_answer_block",
                                                "insert_meaning_association",
                                                "insert_custom_answer",
                                                "insert_content_block"
                                            ].includes(toolName_0)) {
                                                // Parse output to get block data
                                                let parsedOutput_0 = null;
                                                if (part_4.state === "output-available" && part_4.output) {
                                                    try {
                                                        parsedOutput_0 = typeof part_4.output === "string" ? JSON.parse(part_4.output) : part_4.output;
                                                    } catch (e_9) {
                                                        console.error("[ChatSidebar] Failed to parse block output:", e_9);
                                                    }
                                                }
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        width: "100%",
                                                        mb: 2,
                                                        overflow: "hidden",
                                                        overflowWrap: "break-word",
                                                        wordBreak: "break-word"
                                                    },
                                                    children: [
                                                        part_4.state === "input-streaming" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                fontStyle: "italic",
                                                                color: "text.secondary"
                                                            },
                                                            children: "Preparing block..."
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1976,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "input-available" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                color: "text.secondary"
                                                            },
                                                            children: [
                                                                "Creating",
                                                                " ",
                                                                toolName_0.replace("insert_", "").replace(/_/g, " "),
                                                                " ",
                                                                "block..."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1984,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-available" && parsedOutput_0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2f$BlockInsertPreview$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            toolOutput: parsedOutput_0,
                                                            onInsertBlock: handleInsertBlock,
                                                            onReject: ()=>console.log("[ChatSidebar] Block insert rejected")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1993,
                                                            columnNumber: 87
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-error" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                            sx: {
                                                                p: 2,
                                                                bgcolor: "error.light",
                                                                borderRadius: 1,
                                                                color: "error.dark",
                                                                wordBreak: "break-word",
                                                                overflowWrap: "break-word"
                                                            },
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                variant: "body2",
                                                                sx: {
                                                                    wordBreak: "break-word",
                                                                    overflowWrap: "break-word",
                                                                    whiteSpace: "normal"
                                                                },
                                                                children: [
                                                                    "Error creating block: ",
                                                                    part_4.errorText
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                lineNumber: 2003,
                                                                columnNumber: 33
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 1995,
                                                            columnNumber: 65
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, callId || toolIdx, true, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 1969,
                                                    columnNumber: 24
                                                }, ("TURBOPACK compile-time value", void 0));
                                            }
                                            // Handle create_recording_script tool
                                            if (toolName_0 === "create_recording_script") {
                                                let parsedOutput_1 = null;
                                                if (part_4.state === "output-available" && part_4.output) {
                                                    try {
                                                        parsedOutput_1 = typeof part_4.output === "string" ? JSON.parse(part_4.output) : part_4.output;
                                                    } catch (e_10) {
                                                        console.error("[ChatSidebar] Failed to parse recording script output:", e_10);
                                                    }
                                                }
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        width: "100%",
                                                        mb: 2,
                                                        overflow: "hidden",
                                                        overflowWrap: "break-word",
                                                        wordBreak: "break-word"
                                                    },
                                                    children: [
                                                        part_4.state === "input-streaming" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                fontStyle: "italic",
                                                                color: "text.secondary"
                                                            },
                                                            children: "Generating recording script..."
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2031,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "input-available" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                color: "text.secondary"
                                                            },
                                                            children: [
                                                                "Creating ",
                                                                part_4.input?.preset,
                                                                " recording script..."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2039,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-available" && parsedOutput_1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2f$RecordingScriptPreview$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            toolOutput: parsedOutput_1,
                                                            unitId: unit?.id,
                                                            owner: user?.username,
                                                            identityId: user?.identityId
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2047,
                                                            columnNumber: 87
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-error" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                            sx: {
                                                                p: 2,
                                                                bgcolor: "error.light",
                                                                borderRadius: 1,
                                                                color: "error.dark"
                                                            },
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                variant: "body2",
                                                                children: [
                                                                    "Error creating recording script:",
                                                                    " ",
                                                                    part_4.errorText
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                lineNumber: 2055,
                                                                columnNumber: 33
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2049,
                                                            columnNumber: 65
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, callId || toolIdx, true, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 2024,
                                                    columnNumber: 24
                                                }, ("TURBOPACK compile-time value", void 0));
                                            }
                                            // Handle generate_unit_content tool (deprecated - kept for backwards compatibility)
                                            if (toolName_0 === "generate_unit_content") {
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        width: "100%",
                                                        mb: 1,
                                                        p: 1,
                                                        bgcolor: "transparent",
                                                        borderLeft: "2px solid",
                                                        borderColor: part_4.state === "output-error" ? "error.main" : "grey.400",
                                                        fontSize: "0.8rem",
                                                        color: "text.secondary",
                                                        overflow: "hidden",
                                                        overflowWrap: "break-word",
                                                        wordBreak: "break-word"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                fontWeight: 600,
                                                                display: "block",
                                                                mb: 0.5,
                                                                color: "text.primary"
                                                            },
                                                            children: t("chatSidebar.generateContent")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2078,
                                                            columnNumber: 29
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "input-streaming" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                fontStyle: "italic"
                                                            },
                                                            children: "Preparing..."
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2087,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "input-available" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                wordBreak: "break-word",
                                                                overflowWrap: "break-word",
                                                                whiteSpace: "normal"
                                                            },
                                                            children: t("chatSidebar.contentTypeAndTopic", {
                                                                contentType: part_4.input?.contentType,
                                                                topic: part_4.input?.topic
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2094,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-available" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                color: "success.dark",
                                                                wordBreak: "break-word",
                                                                overflowWrap: "break-word",
                                                                whiteSpace: "normal"
                                                            },
                                                            children: [
                                                                "✓",
                                                                " ",
                                                                part_4.output?.message || t("chatSidebar.ready")
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2106,
                                                            columnNumber: 69
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-error" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                color: "error.main",
                                                                wordBreak: "break-word",
                                                                overflowWrap: "break-word",
                                                                whiteSpace: "normal"
                                                            },
                                                            children: [
                                                                "✗ ",
                                                                part_4.errorText
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2117,
                                                            columnNumber: 65
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, callId || toolIdx, true, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 2065,
                                                    columnNumber: 24
                                                }, ("TURBOPACK compile-time value", void 0));
                                            }
                                            // Handle generate_quiz_questions tool
                                            if (toolName_0 === "generate_quiz_questions") {
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        width: "100%",
                                                        mb: 1,
                                                        p: 1,
                                                        bgcolor: "transparent",
                                                        borderLeft: "2px solid",
                                                        borderColor: part_4.state === "output-error" ? "error.main" : "primary.main",
                                                        fontSize: "0.8rem",
                                                        color: "text.secondary",
                                                        overflow: "hidden",
                                                        overflowWrap: "break-word",
                                                        wordBreak: "break-word"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                fontWeight: 600,
                                                                display: "block",
                                                                mb: 0.5,
                                                                color: "text.primary"
                                                            },
                                                            children: "📝 Generate Quiz Questions"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2144,
                                                            columnNumber: 29
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "input-streaming" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                fontStyle: "italic"
                                                            },
                                                            children: "Preparing..."
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2153,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "input-available" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                wordBreak: "break-word",
                                                                overflowWrap: "break-word",
                                                                whiteSpace: "normal"
                                                            },
                                                            children: [
                                                                "Topic: ",
                                                                part_4.input?.topic,
                                                                " (",
                                                                part_4.input?.count,
                                                                " ",
                                                                part_4.input?.questionType,
                                                                " questions,",
                                                                " ",
                                                                part_4.input?.difficulty,
                                                                " difficulty)"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2160,
                                                            columnNumber: 68
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-available" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                color: "success.dark",
                                                                wordBreak: "break-word",
                                                                overflowWrap: "break-word",
                                                                whiteSpace: "normal"
                                                            },
                                                            children: [
                                                                "✓",
                                                                " ",
                                                                part_4.output?.message || `Generated ${part_4.output?.questionsGenerated || part_4.input?.count} questions`
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2171,
                                                            columnNumber: 69
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        part_4.state === "output-error" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            sx: {
                                                                display: "block",
                                                                color: "error.main",
                                                                wordBreak: "break-word",
                                                                overflowWrap: "break-word",
                                                                whiteSpace: "normal"
                                                            },
                                                            children: [
                                                                "✗ ",
                                                                part_4.errorText
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                                            lineNumber: 2182,
                                                            columnNumber: 65
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, callId || toolIdx, true, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 2131,
                                                    columnNumber: 24
                                                }, ("TURBOPACK compile-time value", void 0));
                                            }
                                            // Handle dynamic or unknown tools
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                sx: {
                                                    width: "100%",
                                                    mb: 1,
                                                    p: 1,
                                                    bgcolor: "transparent",
                                                    borderLeft: "2px solid",
                                                    borderColor: part_4.state === "output-error" ? "error.main" : "grey.400",
                                                    fontSize: "0.8rem",
                                                    color: "text.secondary",
                                                    overflow: "hidden",
                                                    overflowWrap: "break-word",
                                                    wordBreak: "break-word"
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "caption",
                                                        sx: {
                                                            fontWeight: 600,
                                                            display: "block",
                                                            color: "text.primary"
                                                        },
                                                        children: [
                                                            "🔧 ",
                                                            toolName_0 || t("chatSidebar.unknown")
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 2208,
                                                        columnNumber: 27
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    part_4.state === "input-streaming" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "caption",
                                                        sx: {
                                                            display: "block",
                                                            mt: 0.5
                                                        },
                                                        children: "Preparing..."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 2216,
                                                        columnNumber: 66
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    part_4.state === "input-available" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "caption",
                                                        sx: {
                                                            display: "block",
                                                            mt: 0.5
                                                        },
                                                        children: "Executing..."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 2223,
                                                        columnNumber: 66
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    part_4.state === "output-available" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "caption",
                                                        sx: {
                                                            display: "block",
                                                            mt: 0.5,
                                                            color: "success.dark"
                                                        },
                                                        children: t("chatSidebar.complete")
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 2230,
                                                        columnNumber: 67
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    part_4.state === "output-error" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "caption",
                                                        sx: {
                                                            display: "block",
                                                            mt: 0.5,
                                                            color: "error.main",
                                                            wordBreak: "break-word",
                                                            overflowWrap: "break-word",
                                                            whiteSpace: "normal"
                                                        },
                                                        children: [
                                                            "✗ ",
                                                            part_4.errorText
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 2238,
                                                        columnNumber: 63
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, callId || toolIdx, true, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 2195,
                                                columnNumber: 22
                                            }, ("TURBOPACK compile-time value", void 0));
                                        }),
                                        index_7 === messages_0.length - 1 && isLoading && message_0.role !== "assistant" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            sx: {
                                                display: "flex",
                                                alignItems: "center",
                                                gap: 1,
                                                p: 2,
                                                alignSelf: "flex-start",
                                                m: 0.75
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                sx: {
                                                    display: "flex",
                                                    gap: 0.5,
                                                    p: "0.75rem 1rem",
                                                    borderRadius: "1rem",
                                                    bgcolor: "custom.chatBubbleAssistant",
                                                    border: 1,
                                                    borderColor: "divider"
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        sx: {
                                                            width: 8,
                                                            height: 8,
                                                            borderRadius: "50%",
                                                            bgcolor: "text.disabled",
                                                            animation: "typing 1s infinite",
                                                            animationDelay: "0s",
                                                            "@keyframes typing": {
                                                                "0%, 60%, 100%": {
                                                                    transform: "translateY(0)",
                                                                    opacity: 0.7
                                                                },
                                                                "30%": {
                                                                    transform: "translateY(-7px)",
                                                                    opacity: 1
                                                                }
                                                            }
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 2269,
                                                        columnNumber: 29
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        sx: {
                                                            width: 8,
                                                            height: 8,
                                                            borderRadius: "50%",
                                                            bgcolor: "text.disabled",
                                                            animation: "typing 1s infinite",
                                                            animationDelay: "0.2s",
                                                            "@keyframes typing": {
                                                                "0%, 60%, 100%": {
                                                                    transform: "translateY(0)",
                                                                    opacity: 0.7
                                                                },
                                                                "30%": {
                                                                    transform: "translateY(-7px)",
                                                                    opacity: 1
                                                                }
                                                            }
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 2287,
                                                        columnNumber: 29
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        sx: {
                                                            width: 8,
                                                            height: 8,
                                                            borderRadius: "50%",
                                                            bgcolor: "text.disabled",
                                                            animation: "typing 1s infinite",
                                                            animationDelay: "0.4s",
                                                            "@keyframes typing": {
                                                                "0%, 60%, 100%": {
                                                                    transform: "translateY(0)",
                                                                    opacity: 0.7
                                                                },
                                                                "30%": {
                                                                    transform: "translateY(-7px)",
                                                                    opacity: 1
                                                                }
                                                            }
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 2305,
                                                        columnNumber: 29
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 2260,
                                                columnNumber: 27
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                            lineNumber: 2252,
                                            columnNumber: 106
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, message_0.id || `message-${index_7}`, true, {
                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                    lineNumber: 1747,
                                    columnNumber: 18
                                }, ("TURBOPACK compile-time value", void 0));
                            },
                            emptyState: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    height: "100%",
                                    color: "text.secondary",
                                    textAlign: "center",
                                    p: 3
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Chat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        sx: {
                                            fontSize: 48,
                                            mb: 2,
                                            opacity: 0.3
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2336,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "body2",
                                        sx: {
                                            wordWrap: "break-word",
                                            textAlign: "center",
                                            whiteSpace: "normal"
                                        },
                                        children: t("chatSidebar.welcomeMessage")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2341,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                lineNumber: 2326,
                                columnNumber: 24
                            }, ("TURBOPACK compile-time value", void 0))
                        }, assistantChat ? assistantChat.id : "no-history", false, {
                            fileName: "[project]/src/components/ChatSidebar.jsx",
                            lineNumber: 1738,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/ChatSidebar.jsx",
                        lineNumber: 1470,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
                        component: "form",
                        onSubmit: submitMessage,
                        elevation: 2,
                        sx: {
                            p: 1.5,
                            borderTop: "1px solid",
                            borderColor: "divider"
                        },
                        children: [
                            uploadedFiles.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    mb: 1,
                                    display: "flex",
                                    gap: 1,
                                    flexWrap: "wrap"
                                },
                                children: uploadedFiles.map((file_2, index_8)=>{
                                    const isDocument = file_2.type === "application/pdf";
                                    const status_2 = documentProcessingStatus[index_8];
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
                                        elevation: 1,
                                        sx: {
                                            p: 1,
                                            display: "flex",
                                            alignItems: "center",
                                            gap: 1,
                                            bgcolor: isDocument ? status_2?.status === "error" ? "error.light" : status_2?.status === "analyzed" ? "success.light" : status_2?.status === "analyzing" || status_2?.status === "extracting" ? "warning.light" : status_2?.status === "cancelled" ? "action.disabledBackground" : "action.hover" : "action.hover",
                                            border: isDocument ? "1px solid" : "none",
                                            borderColor: isDocument ? status_2?.status === "error" ? "error.main" : status_2?.status === "analyzed" ? "success.main" : status_2?.status === "analyzing" || status_2?.status === "extracting" ? "warning.main" : status_2?.status === "cancelled" ? "text.disabled" : "divider" : "transparent"
                                        },
                                        children: [
                                            isDocument && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PictureAsPdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                sx: {
                                                    fontSize: 18,
                                                    color: "error.main"
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 2376,
                                                columnNumber: 36
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            !isDocument && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AttachFile$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                sx: {
                                                    fontSize: 18
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 2380,
                                                columnNumber: 37
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                sx: {
                                                    flex: 1
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "body2",
                                                        sx: {
                                                            fontSize: "0.75rem"
                                                        },
                                                        children: file_2.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 2387,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    status_2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "caption",
                                                        sx: {
                                                            fontSize: "0.65rem",
                                                            display: "flex",
                                                            alignItems: "center",
                                                            gap: 0.5,
                                                            color: status_2.status === "error" ? "error.main" : status_2.status === "analyzed" ? "success.main" : "text.secondary"
                                                        },
                                                        children: [
                                                            status_2.status === "uploading" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                                                variant: "circular",
                                                                width: 10,
                                                                height: 10
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                lineNumber: 2399,
                                                                columnNumber: 63
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            status_2.status === "analyzed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                sx: {
                                                                    fontSize: 12
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                                lineNumber: 2400,
                                                                columnNumber: 62
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            status_2.message
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                                        lineNumber: 2392,
                                                        columnNumber: 36
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 2384,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            isDocument && status_2 && [
                                                t("chatSidebar.uploading"),
                                                t("chatSidebar.analyzing"),
                                                t("chatSidebar.extracting")
                                            ].includes(status_2.status) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                size: "small",
                                                onClick: ()=>cancelProcessing(index_8),
                                                sx: {
                                                    p: 0.5
                                                },
                                                title: t("chatSidebar.cancelAnalysis"),
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Cancel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    sx: {
                                                        fontSize: 16,
                                                        color: "warning.main"
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 2411,
                                                    columnNumber: 27
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 2408,
                                                columnNumber: 163
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            isDocument && status_2 && status_2.status === "analyzed" && status_2.documentId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                size: "small",
                                                onClick: ()=>openVocabularyReview(status_2.documentId),
                                                sx: {
                                                    p: 0.5
                                                },
                                                title: t("chatSidebar.reviewVocabulary"),
                                                color: "primary",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RateReview$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    sx: {
                                                        fontSize: 16
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 2421,
                                                    columnNumber: 27
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 2418,
                                                columnNumber: 105
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                size: "small",
                                                onClick: ()=>removeFile(index_8),
                                                sx: {
                                                    p: 0.5
                                                },
                                                title: t("chatSidebar.removeFile"),
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    sx: {
                                                        fontSize: 16
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                                    lineNumber: 2430,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                                lineNumber: 2427,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, index_8, true, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2367,
                                        columnNumber: 20
                                    }, ("TURBOPACK compile-time value", void 0));
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                lineNumber: 2358,
                                columnNumber: 40
                            }, ("TURBOPACK compile-time value", void 0)),
                            chatCreationError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    mb: 2,
                                    p: 2,
                                    bgcolor: "error.light",
                                    borderRadius: 1,
                                    border: "1px solid",
                                    borderColor: "error.main"
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "body2",
                                        color: "error.dark",
                                        sx: {
                                            mb: 1,
                                            fontWeight: 600
                                        },
                                        children: "⚠️ Failed to create chat session"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2473,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "body2",
                                        color: "error.dark",
                                        sx: {
                                            mb: 1.5
                                        },
                                        children: chatCreationError
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2479,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "caption",
                                        color: "error.dark",
                                        sx: {
                                            display: "block",
                                            mb: 2
                                        },
                                        children: "Possible causes: Backend not deployed, authentication issue, or network error"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2484,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        size: "small",
                                        variant: "contained",
                                        color: "error",
                                        onClick: ()=>window.location.reload(),
                                        children: "Reload Page"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2491,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                lineNumber: 2465,
                                columnNumber: 33
                            }, ("TURBOPACK compile-time value", void 0)),
                            !authLoading && !user && !chatCreationError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    mb: 2,
                                    p: 2,
                                    bgcolor: "info.light",
                                    borderRadius: 1,
                                    border: "1px solid",
                                    borderColor: "info.main"
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "body2",
                                        color: "info.dark",
                                        sx: {
                                            mb: 1,
                                            fontWeight: 600
                                        },
                                        children: "🔐 Authentication Required"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2505,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "body2",
                                        color: "info.dark",
                                        children: "Please sign in to use the AI Assistant chat feature."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2511,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                lineNumber: 2497,
                                columnNumber: 59
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    gap: 1
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        ref: fileInputRef,
                                        type: "file",
                                        multiple: true,
                                        hidden: true,
                                        onChange: handleFileSelect
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2521,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                        onClick: ()=>fileInputRef.current?.click(),
                                        disabled: isLoading || !assistantChat?.id,
                                        sx: {
                                            alignSelf: "flex-end"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$UploadFile$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                            lineNumber: 2527,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2524,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                        fullWidth: true,
                                        size: "small",
                                        "data-tour": "chat-input",
                                        "data-testid": "chat-input",
                                        value: input,
                                        onChange: handleInputChange,
                                        onKeyPress: (e_11)=>{
                                            if (e_11.key === "Enter" && !e_11.shiftKey) {
                                                e_11.preventDefault();
                                                submitMessage(e_11);
                                            }
                                        },
                                        placeholder: !user && !authLoading ? "Please sign in to use chat" : !assistantChat?.id ? t("chatSidebar.settingUpChat") : t("chatSidebar.askMeAnything"),
                                        disabled: isLoading || !assistantChat?.id || !user,
                                        multiline: true,
                                        maxRows: 4,
                                        variant: "outlined",
                                        sx: {
                                            "& .MuiOutlinedInput-root": {
                                                borderRadius: 2
                                            }
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2530,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        type: "submit",
                                        variant: "contained",
                                        "aria-label": tCommon("actions.send"),
                                        disabled: isLoading || !assistantChat?.id || !user,
                                        "data-testid": "chat-send",
                                        sx: {
                                            minWidth: "auto",
                                            px: 2,
                                            borderRadius: 2
                                        },
                                        children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                            variant: "circular",
                                            width: 20,
                                            height: 20
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                            lineNumber: 2545,
                                            columnNumber: 28
                                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/components/ChatSidebar.jsx",
                                            lineNumber: 2545,
                                            columnNumber: 85
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatSidebar.jsx",
                                        lineNumber: 2540,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                lineNumber: 2516,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ChatSidebar.jsx",
                        lineNumber: 2352,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ChatSidebar.jsx",
                lineNumber: 1284,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                open: vocabularyReviewDialogOpen,
                onClose: ()=>dispatch({
                        type: ACTIONS.SET_VOCABULARY_REVIEW_DIALOG,
                        payload: false
                    }),
                maxWidth: "md",
                fullWidth: true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                        children: [
                            t("chatSidebar.reviewImportVocabulary"),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                onClick: ()=>dispatch({
                                        type: ACTIONS.SET_VOCABULARY_REVIEW_DIALOG,
                                        payload: false
                                    }),
                                sx: {
                                    position: "absolute",
                                    right: 8,
                                    top: 8
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                    lineNumber: 2566,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatSidebar.jsx",
                                lineNumber: 2558,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ChatSidebar.jsx",
                        lineNumber: 2556,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                        dividers: true,
                        sx: {
                            p: 0
                        },
                        children: reviewDocumentId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VocabularyReview2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            documentId: reviewDocumentId,
                            unitId: unit?.id,
                            owner: session?.sub,
                            identityId: identityId,
                            onImportComplete: handleVocabularyImportComplete
                        }, void 0, false, {
                            fileName: "[project]/src/components/ChatSidebar.jsx",
                            lineNumber: 2572,
                            columnNumber: 32
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/ChatSidebar.jsx",
                        lineNumber: 2569,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ChatSidebar.jsx",
                lineNumber: 2552,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__["Portal"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
                    open: confirmDialog.open,
                    anchorOrigin: {
                        vertical: "top",
                        horizontal: "center"
                    },
                    onClose: (event, reason_0)=>{
                        if (reason_0 === "clickaway") {
                            return;
                        }
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                        severity: confirmDialog.severity,
                        sx: {
                            width: "100%",
                            minWidth: "300px",
                            boxShadow: 3
                        },
                        action: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                gap: 1,
                                ml: 2
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    color: "inherit",
                                    size: "small",
                                    onClick: (e_12)=>{
                                        e_12.stopPropagation();
                                        if (confirmDialog.onConfirm) {
                                            confirmDialog.onConfirm();
                                        }
                                    },
                                    variant: "outlined",
                                    children: t("chatSidebar.confirm")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                    lineNumber: 2595,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    color: "inherit",
                                    size: "small",
                                    onClick: (e_13)=>{
                                        e_13.stopPropagation();
                                        if (confirmDialog.onCancel) {
                                            confirmDialog.onCancel();
                                        } else {
                                            dispatch({
                                                type: ACTIONS.SET_CONFIRM_DIALOG,
                                                payload: {
                                                    open: false,
                                                    message: "",
                                                    onConfirm: null,
                                                    severity: "info"
                                                }
                                            });
                                        }
                                    },
                                    variant: "contained",
                                    children: t("chatSidebar.cancel")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ChatSidebar.jsx",
                                    lineNumber: 2603,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ChatSidebar.jsx",
                            lineNumber: 2590,
                            columnNumber: 20
                        }, ("TURBOPACK compile-time value", void 0)),
                        children: confirmDialog.message
                    }, void 0, false, {
                        fileName: "[project]/src/components/ChatSidebar.jsx",
                        lineNumber: 2586,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ChatSidebar.jsx",
                    lineNumber: 2578,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ChatSidebar.jsx",
                lineNumber: 2577,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$NailedItCelebration$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NailedItCelebration"], {
                open: showCelebration,
                nailedItReason: nailedItResult?.nailedItReason || "",
                onClose: dismissCelebration
            }, void 0, false, {
                fileName: "[project]/src/components/ChatSidebar.jsx",
                lineNumber: 2626,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            practiceDrillOpen && practiceDrillConfig && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PracticeDrillDialog$3e$__["PracticeDrillDialog"], {
                open: practiceDrillOpen,
                onClose: ()=>{
                    setPracticeDrillOpen(false);
                    setPracticeDrillConfig(null);
                },
                unitId: unit?.id || "",
                unitName: unit?.name || "",
                config: practiceDrillConfig
            }, void 0, false, {
                fileName: "[project]/src/components/ChatSidebar.jsx",
                lineNumber: 2627,
                columnNumber: 52
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(ChatSidebar, "Dynf2aMdDUMR/2lamsEsKkxVzCk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tabContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tourContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTourSafe"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useNailedItDetection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNailedItDetection"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$react$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChat"]
    ];
});
_c = ChatSidebar;
const __TURBOPACK__default__export__ = /*#__PURE__*/ _c1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(ChatSidebar);
var _c, _c1;
__turbopack_context__.k.register(_c, "ChatSidebar");
__turbopack_context__.k.register(_c1, "%default%");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_ChatSidebar_jsx_0zich0m._.js.map