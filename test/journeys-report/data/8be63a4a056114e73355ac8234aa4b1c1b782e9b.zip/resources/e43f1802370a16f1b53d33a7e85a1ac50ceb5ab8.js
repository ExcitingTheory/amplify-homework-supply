(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PracticeDrillProgress
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/EmojiObjects.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Bolt$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Bolt.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function PracticeDrillProgress(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(39);
    if ($[0] !== "59fe481f5949af8ffe3ba75cf3025cfa5b45cf51f7d4064c4b45454c1695ec70") {
        for(let $i = 0; $i < 39; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "59fe481f5949af8ffe3ba75cf3025cfa5b45cf51f7d4064c4b45454c1695ec70";
    }
    const { blocksCompleted, blockCount, xpEarned, xpDiminished: t1, streakCount } = t0;
    const xpDiminished = t1 === undefined ? false : t1;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    let t2;
    if ($[1] !== blockCount || $[2] !== blocksCompleted) {
        t2 = blockCount > 0 ? Math.round(blocksCompleted / blockCount * 100) : 0;
        $[1] = blockCount;
        $[2] = blocksCompleted;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const percent = t2;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            px: 2,
            py: 1
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            display: "flex",
            alignItems: "center",
            gap: 1,
            mb: 0.5
        };
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            flex: 1,
            height: 8,
            borderRadius: 4
        };
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] !== percent) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
            variant: "determinate",
            value: percent,
            sx: t5
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx",
            lineNumber: 96,
            columnNumber: 10
        }, this);
        $[7] = percent;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            minWidth: 70,
            textAlign: "right"
        };
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] !== t) {
        t8 = t("practiceDrill.progress.questions");
        $[10] = t;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== blockCount || $[13] !== blocksCompleted || $[14] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            sx: t7,
            children: [
                blocksCompleted,
                "/",
                blockCount,
                " ",
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx",
            lineNumber: 122,
            columnNumber: 10
        }, this);
        $[12] = blockCount;
        $[13] = blocksCompleted;
        $[14] = t8;
        $[15] = t9;
    } else {
        t9 = $[15];
    }
    let t10;
    if ($[16] !== t6 || $[17] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t4,
            children: [
                t6,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx",
            lineNumber: 132,
            columnNumber: 11
        }, this);
        $[16] = t6;
        $[17] = t9;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    let t11;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            display: "flex",
            alignItems: "center",
            gap: 1
        };
        $[19] = t11;
    } else {
        t11 = $[19];
    }
    let t12;
    if ($[20] !== t || $[21] !== xpDiminished) {
        t12 = xpDiminished ? t("practiceDrill.progress.xpDiminishedTooltip") : t("practiceDrill.progress.xpTooltip");
        $[20] = t;
        $[21] = xpDiminished;
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    let t13;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx",
            lineNumber: 161,
            columnNumber: 11
        }, this);
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    const t14 = `+${xpEarned} XP`;
    const t15 = xpDiminished ? "default" : "primary";
    let t16;
    if ($[24] !== t14 || $[25] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            size: "small",
            icon: t13,
            label: t14,
            color: t15,
            variant: "outlined"
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx",
            lineNumber: 170,
            columnNumber: 11
        }, this);
        $[24] = t14;
        $[25] = t15;
        $[26] = t16;
    } else {
        t16 = $[26];
    }
    let t17;
    if ($[27] !== t12 || $[28] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: t12,
            children: t16
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx",
            lineNumber: 179,
            columnNumber: 11
        }, this);
        $[27] = t12;
        $[28] = t16;
        $[29] = t17;
    } else {
        t17 = $[29];
    }
    let t18;
    if ($[30] !== streakCount || $[31] !== t) {
        t18 = streakCount != null && streakCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: t("practiceDrill.progress.streakTooltip", {
                count: streakCount
            }),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                size: "small",
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Bolt$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx",
                    lineNumber: 190,
                    columnNumber: 34
                }, this),
                label: streakCount,
                color: "warning",
                variant: "outlined"
            }, void 0, false, {
                fileName: "[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx",
                lineNumber: 190,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx",
            lineNumber: 188,
            columnNumber: 53
        }, this);
        $[30] = streakCount;
        $[31] = t;
        $[32] = t18;
    } else {
        t18 = $[32];
    }
    let t19;
    if ($[33] !== t17 || $[34] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t11,
            children: [
                t17,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx",
            lineNumber: 199,
            columnNumber: 11
        }, this);
        $[33] = t17;
        $[34] = t18;
        $[35] = t19;
    } else {
        t19 = $[35];
    }
    let t20;
    if ($[36] !== t10 || $[37] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t3,
            children: [
                t10,
                t19
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx",
            lineNumber: 208,
            columnNumber: 11
        }, this);
        $[36] = t10;
        $[37] = t19;
        $[38] = t20;
    } else {
        t20 = $[38];
    }
    return t20;
}
_s(PracticeDrillProgress, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = PracticeDrillProgress;
var _c;
__turbopack_context__.k.register(_c, "PracticeDrillProgress");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PracticeDrill/buildDrillEditorState.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @fileoverview buildDrillEditorState — Converts PracticeDrillBlock[] into
 * a Lexical editor state JSON structure compatible with the existing Workbook
 * plugins (QuizPlugin, AnswerPlugin, MeaningAssociationPlugin, CustomAnswerPlugin).
 *
 * Each node is serialized in the exact format that the corresponding Lexical
 * node's importJSON expects so the standard workbook can render them.
 */ // ============================================================================
// Types
// ============================================================================
__turbopack_context__.s([
    "buildDrillEditorState",
    ()=>buildDrillEditorState,
    "extractDrillMetadata",
    ()=>extractDrillMetadata
]);
// ============================================================================
// Lexical node builders — match existing importJSON formats
// ============================================================================
function textNode(text) {
    return {
        detail: 0,
        format: 0,
        mode: 'normal',
        style: '',
        text,
        type: 'text',
        version: 1
    };
}
function paragraphNode(children) {
    return {
        children,
        direction: 'ltr',
        format: '',
        indent: 0,
        type: 'paragraph',
        version: 1
    };
}
/**
 * Build a quiz node — matches QuizNode.importJSON which reads `serializedNode.data`.
 * QuizComponent expects data as `[{ answer: string, correct: boolean }, ...]`.
 */ function buildQuizNode(block) {
    return {
        type: 'quiz',
        version: 1,
        data: (block.choices || []).map((c)=>({
                answer: c.choice,
                correct: c.correct
            }))
    };
}
/**
 * Build an answer node — matches AnswerNode.importJSON which reads
 * `serializedNode.wordIDs`, `.requestDefinition`, `.allowedInput`, `.promptMethod`.
 *
 * AnswerComponent expects:
 *   allowedInput: string[] — e.g. ['text', 'audio', 'writing']
 *   promptMethod: string[] — e.g. ['phrase', 'definition', 'audio']
 */ function buildAnswerNode(block) {
    return {
        type: 'answer',
        version: 1,
        wordIDs: [
            block.sourceItemId
        ],
        requestDefinition: 'definition',
        allowedInput: [
            'text'
        ],
        promptMethod: [
            'phrase'
        ]
    };
}
/**
 * Build a meaning-association node — matches MeaningAssociationNode.importJSON
 * which reads `serializedNode.wordIDs`, `.enabledModes`.
 *
 * Uses `sourceItemIds` if available, otherwise falls back to resolving pair
 * terms against the provided dictionary.
 */ function buildMeaningAssociationNode(block, dictionary) {
    let wordIDs = [];
    if (block.sourceItemIds && block.sourceItemIds.length > 0) {
        // Use explicitly provided word IDs
        wordIDs = block.sourceItemIds;
    } else if (dictionary && block.pairs) {
        // Resolve term text → word ID via dictionary lookup
        const phraseToId = new Map();
        for (const [id, word] of Object.entries(dictionary)){
            if (word?.phrase) {
                phraseToId.set(word.phrase.toLowerCase(), id);
            }
        }
        for (const pair of block.pairs){
            const resolved = phraseToId.get(pair.term.toLowerCase());
            if (resolved) wordIDs.push(resolved);
        }
    }
    // Fallback: use sourceItemId if we couldn't resolve any IDs
    if (wordIDs.length === 0 && block.sourceItemId) {
        wordIDs = [
            block.sourceItemId
        ];
    }
    return {
        type: 'meaning-association',
        version: 1,
        wordIDs,
        enabledModes: [
            'learn',
            'easy',
            'hard'
        ]
    };
}
/**
 * Build a custom-answer node — matches CustomAnswerNode.importJSON which reads
 * `serializedNode.wordIDs`, `.promptMethod`, `.allowedInput`, `.format`.
 */ function buildCustomAnswerNode(block) {
    return {
        type: 'custom-answer',
        version: 1,
        wordIDs: [
            block.sourceItemId
        ],
        promptMethod: 'word',
        allowedInput: [
            'text'
        ],
        format: 'default'
    };
}
function buildDrillEditorState(blocks, dictionary) {
    const children = [];
    for(let i = 0; i < blocks.length; i++){
        const block = blocks[i];
        // Add instruction as a paragraph above the block
        if (block.instruction) {
            children.push(paragraphNode([
                textNode(block.instruction)
            ]));
        }
        // Add document reference if present
        if (block.documentRef) {
            children.push(paragraphNode([
                textNode(`📄 ${block.documentRef.filename}, p. ${block.documentRef.page}`)
            ]));
        }
        // Add the graded block node in the format the existing plugins expect
        switch(block.type){
            case 'quiz':
                children.push(buildQuizNode(block));
                break;
            case 'answer':
                children.push(buildAnswerNode(block));
                break;
            case 'meaning-association':
                children.push(buildMeaningAssociationNode(block, dictionary));
                break;
            case 'custom-answer':
                children.push(buildCustomAnswerNode(block));
                break;
            default:
                // Fallback: render as answer block
                children.push(buildAnswerNode(block));
        }
        // Add separator between blocks (not after last)
        if (i < blocks.length - 1) {
            children.push({
                type: 'horizontalrule',
                version: 1
            });
        }
    }
    return {
        root: {
            children,
            direction: 'ltr',
            format: '',
            indent: 0,
            type: 'root',
            version: 1
        }
    };
}
function extractDrillMetadata(blocks) {
    return new Map(blocks.map((block, i)=>[
            i,
            block
        ]));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PracticeDrill/DrillGradeAdapter.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DrillGradeAdapter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview DrillGradeAdapter — Provides a UnitContext override that lets
 * the existing Editor3/Workbook render AI-generated drill content.
 *
 * Supplies:
 *  • A synthetic `unit` whose `data` field contains the drill Lexical JSON
 *    (so WorkbookStatePlugin loads it automatically).
 *  • A local `grade` / `saveGrade` pair backed by React state instead of
 *    DynamoDB, so graded block components function normally.
 *  • Disables unit-level completion / workbook collaboration side effects.
 *
 * Wrap the real `<Workbook />` in this adapter and it "just works".
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$buildDrillEditorState$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PracticeDrill/buildDrillEditorState.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function DrillGradeAdapter(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(32);
    if ($[0] !== "b72932ded35de6330f74ef2811ca807b95da650977dcd8699faf4014fc59d5ff") {
        for(let $i = 0; $i < 32; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b72932ded35de6330f74ef2811ca807b95da650977dcd8699faf4014fc59d5ff";
    }
    const { sessionId, blocks, onGradeChange, children } = t0;
    const parentContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { wordMapId: dictionary } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {};
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const gradeDataRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(t1);
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {};
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const [gradeData, setGradeData] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(t2);
    let t3;
    if ($[3] !== blocks) {
        t3 = blocks.filter(_DrillGradeAdapterBlocksFilter);
        $[3] = blocks;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const gradedBlockCount = t3.length;
    let t4;
    if ($[5] !== blocks || $[6] !== dictionary) {
        t4 = blocks.length > 0 ? JSON.stringify((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$buildDrillEditorState$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildDrillEditorState"])(blocks, dictionary)) : null;
        $[5] = blocks;
        $[6] = dictionary;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    const editorStateJSON = t4;
    const t5 = `drill-${sessionId}`;
    let t6;
    if ($[8] !== editorStateJSON || $[9] !== t5) {
        t6 = {
            id: t5,
            name: "Practice Drill",
            data: editorStateJSON,
            _version: 1
        };
        $[8] = editorStateJSON;
        $[9] = t5;
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    const syntheticUnit = t6;
    const t7 = `drill-grade-${sessionId}`;
    let t8;
    if ($[11] !== gradeData || $[12] !== t7) {
        t8 = {
            id: t7,
            data: gradeData,
            complete: false,
            accuracy: null,
            _version: 1
        };
        $[11] = gradeData;
        $[12] = t7;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    const grade = t8;
    let t9;
    if ($[14] !== gradedBlockCount) {
        t9 = ({
            "DrillGradeAdapter[computeStats]": (data)=>{
                const entries = Object.values(data);
                const completed = entries.filter(_DrillGradeAdapterComputeStatsEntriesFilter).length;
                const accuracies = entries.filter(_DrillGradeAdapterComputeStatsEntriesFilter2).map(_DrillGradeAdapterComputeStatsAnonymous);
                const normalizedAccuracies = accuracies.map(_DrillGradeAdapterComputeStatsAccuraciesMap);
                const avgAccuracy = normalizedAccuracies.length > 0 ? Math.round(normalizedAccuracies.reduce(_DrillGradeAdapterComputeStatsNormalizedAccuraciesReduce, 0) / normalizedAccuracies.length) : 0;
                return {
                    blocksCompleted: completed,
                    accuracy: avgAccuracy,
                    complete: gradedBlockCount > 0 && completed >= gradedBlockCount
                };
            }
        })["DrillGradeAdapter[computeStats]"];
        $[14] = gradedBlockCount;
        $[15] = t9;
    } else {
        t9 = $[15];
    }
    const computeStats = t9;
    let t10;
    if ($[16] !== computeStats || $[17] !== onGradeChange) {
        t10 = ({
            "DrillGradeAdapter[saveGrade]": async (data_0)=>{
                gradeDataRef.current = data_0;
                setGradeData({
                    ...data_0
                });
                const stats = computeStats(data_0);
                onGradeChange?.(data_0, stats);
            }
        })["DrillGradeAdapter[saveGrade]"];
        $[16] = computeStats;
        $[17] = onGradeChange;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    const saveGrade = t10;
    let t11;
    if ($[19] !== gradedBlockCount) {
        t11 = new Array(gradedBlockCount).fill(null);
        $[19] = gradedBlockCount;
        $[20] = t11;
    } else {
        t11 = $[20];
    }
    let t12;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            setFeedback: _temp2
        };
        $[21] = t12;
    } else {
        t12 = $[21];
    }
    let t13;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = [];
        $[22] = t13;
    } else {
        t13 = $[22];
    }
    let t14;
    if ($[23] !== grade || $[24] !== parentContext || $[25] !== saveGrade || $[26] !== syntheticUnit || $[27] !== t11) {
        t14 = {
            ...parentContext,
            unit: syntheticUnit,
            grade,
            saveGrade,
            rubric: t11,
            showUnitComplete: false,
            setShowUnitComplete: _temp,
            workbook: t12,
            workbookEnabled: false,
            workbookStats: null,
            recentGrades: t13
        };
        $[23] = grade;
        $[24] = parentContext;
        $[25] = saveGrade;
        $[26] = syntheticUnit;
        $[27] = t11;
        $[28] = t14;
    } else {
        t14 = $[28];
    }
    const contextValue = t14;
    const t15 = contextValue;
    let t16;
    if ($[29] !== children || $[30] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
            value: t15,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/DrillGradeAdapter.tsx",
            lineNumber: 224,
            columnNumber: 11
        }, this);
        $[29] = children;
        $[30] = t15;
        $[31] = t16;
    } else {
        t16 = $[31];
    }
    return t16;
}
_s(DrillGradeAdapter, "o0vmSPFoCOGiVUV2PhSmJRGgcJk=");
_c = DrillGradeAdapter;
function _temp2() {}
function _temp() {}
function _DrillGradeAdapterComputeStatsNormalizedAccuraciesReduce(s, v) {
    return s + v;
}
function _DrillGradeAdapterComputeStatsAccuraciesMap(a) {
    return a <= 1 ? a * 100 : a;
}
function _DrillGradeAdapterComputeStatsAnonymous(e_1) {
    return e_1.accuracy;
}
function _DrillGradeAdapterComputeStatsEntriesFilter2(e_0) {
    return e_0?.complete === true && typeof e_0?.accuracy === "number";
}
function _DrillGradeAdapterComputeStatsEntriesFilter(e) {
    return e?.complete === true;
}
function _DrillGradeAdapterBlocksFilter(b) {
    return [
        "quiz",
        "answer",
        "meaning-association",
        "custom-answer"
    ].includes(b.type);
}
var _c;
__turbopack_context__.k.register(_c, "DrillGradeAdapter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CollaborativePresenceBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview CollaborativePresenceBar — Shows participant avatars, group
 * stats, and connection status for collaborative practice sessions.
 * Sits between the progress bar and the workbook content.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AvatarGroup$2f$AvatarGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AvatarGroup$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AvatarGroup/AvatarGroup.js [app-client] (ecmascript) <export default as AvatarGroup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript) <export default as Avatar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Groups$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Groups.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Wifi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Wifi.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$WifiOff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/WifiOff.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ContentCopy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ContentCopy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
// ============================================================================
// Helpers
// ============================================================================
/** Deterministic color from username */ function stringToColor(str) {
    let hash = 0;
    for(let i = 0; i < str.length; i++){
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    const h = Math.abs(hash % 360);
    return `hsl(${h}, 65%, 50%)`;
}
function getInitials(user) {
    const name = user.displayName || user.username || '?';
    return name.split(/[\s_.-]+/).map((w)=>w[0]).filter(Boolean).slice(0, 2).join('').toUpperCase();
}
function CollaborativePresenceBar(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(62);
    if ($[0] !== "58047a2275c16b85d1dec7a50e5fe0e42fbd0d9f934425c398ddaef2ba3feab6") {
        for(let $i = 0; $i < 62; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "58047a2275c16b85d1dec7a50e5fe0e42fbd0d9f934425c398ddaef2ba3feab6";
    }
    const { participants, currentUser, groupStats, roomCode, isConnected } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const [copied, setCopied] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    let T0;
    let T1;
    let allParticipants;
    let handleCopyCode;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    if ($[1] !== currentUser || $[2] !== isConnected || $[3] !== participants || $[4] !== roomCode || $[5] !== t) {
        allParticipants = [
            currentUser,
            ...participants
        ];
        let t6;
        if ($[15] !== roomCode) {
            t6 = ({
                "CollaborativePresenceBar[handleCopyCode]": async ()=>{
                    try {
                        await navigator.clipboard.writeText(roomCode);
                        setCopied(true);
                        setTimeout({
                            "CollaborativePresenceBar[handleCopyCode > setTimeout()]": ()=>setCopied(false)
                        }["CollaborativePresenceBar[handleCopyCode > setTimeout()]"], 2000);
                    } catch  {}
                }
            })["CollaborativePresenceBar[handleCopyCode]"];
            $[15] = roomCode;
            $[16] = t6;
        } else {
            t6 = $[16];
        }
        handleCopyCode = t6;
        T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"];
        if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = {
                px: 2,
                py: 1,
                display: "flex",
                alignItems: "center",
                gap: 1.5,
                bgcolor: "action.hover",
                borderBottom: "1px solid",
                borderColor: "divider",
                flexWrap: "wrap"
            };
            $[17] = t4;
        } else {
            t4 = $[17];
        }
        let t7;
        if ($[18] !== isConnected || $[19] !== t) {
            t7 = isConnected ? t("practiceDrill.collab.connected") : t("practiceDrill.collab.disconnected");
            $[18] = isConnected;
            $[19] = t;
            $[20] = t7;
        } else {
            t7 = $[20];
        }
        let t8;
        if ($[21] !== isConnected) {
            t8 = isConnected ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Wifi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fontSize: "small",
                color: "success"
            }, void 0, false, {
                fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
                lineNumber: 133,
                columnNumber: 26
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$WifiOff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fontSize: "small",
                color: "error"
            }, void 0, false, {
                fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
                lineNumber: 133,
                columnNumber: 74
            }, this);
            $[21] = isConnected;
            $[22] = t8;
        } else {
            t8 = $[22];
        }
        if ($[23] !== t7 || $[24] !== t8) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                title: t7,
                children: t8
            }, void 0, false, {
                fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
                lineNumber: 140,
                columnNumber: 12
            }, this);
            $[23] = t7;
            $[24] = t8;
            $[25] = t5;
        } else {
            t5 = $[25];
        }
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AvatarGroup$2f$AvatarGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AvatarGroup$3e$__["AvatarGroup"];
        t1 = 6;
        if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = {
                "& .MuiAvatar-root": {
                    width: 28,
                    height: 28,
                    fontSize: "0.75rem"
                }
            };
            $[26] = t2;
        } else {
            t2 = $[26];
        }
        t3 = allParticipants.map(_CollaborativePresenceBarAllParticipantsMap);
        $[1] = currentUser;
        $[2] = isConnected;
        $[3] = participants;
        $[4] = roomCode;
        $[5] = t;
        $[6] = T0;
        $[7] = T1;
        $[8] = allParticipants;
        $[9] = handleCopyCode;
        $[10] = t1;
        $[11] = t2;
        $[12] = t3;
        $[13] = t4;
        $[14] = t5;
    } else {
        T0 = $[6];
        T1 = $[7];
        allParticipants = $[8];
        handleCopyCode = $[9];
        t1 = $[10];
        t2 = $[11];
        t3 = $[12];
        t4 = $[13];
        t5 = $[14];
    }
    let t6;
    if ($[27] !== T0 || $[28] !== t1 || $[29] !== t2 || $[30] !== t3) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            max: t1,
            sx: t2,
            children: t3
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
            lineNumber: 189,
            columnNumber: 10
        }, this);
        $[27] = T0;
        $[28] = t1;
        $[29] = t2;
        $[30] = t3;
        $[31] = t6;
    } else {
        t6 = $[31];
    }
    let t7;
    if ($[32] !== allParticipants.length || $[33] !== t) {
        t7 = t("practiceDrill.collab.participants", {
            count: allParticipants.length
        });
        $[32] = allParticipants.length;
        $[33] = t;
        $[34] = t7;
    } else {
        t7 = $[34];
    }
    let t8;
    if ($[35] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
            lineNumber: 211,
            columnNumber: 10
        }, this);
        $[35] = t7;
        $[36] = t8;
    } else {
        t8 = $[36];
    }
    let t9;
    if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
            orientation: "vertical",
            flexItem: true
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
            lineNumber: 219,
            columnNumber: 10
        }, this);
        $[37] = t9;
    } else {
        t9 = $[37];
    }
    let t10;
    if ($[38] !== groupStats.averageAccuracy || $[39] !== groupStats.totalParticipants || $[40] !== t) {
        t10 = groupStats.totalParticipants > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: t("practiceDrill.collab.groupAccuracyTip"),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Groups$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
                    lineNumber: 226,
                    columnNumber: 119
                }, this),
                size: "small",
                label: t("practiceDrill.collab.groupAccuracy", {
                    accuracy: Math.round(groupStats.averageAccuracy)
                }),
                variant: "outlined",
                color: groupStats.averageAccuracy >= 80 ? "success" : groupStats.averageAccuracy >= 50 ? "warning" : "default"
            }, void 0, false, {
                fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
                lineNumber: 226,
                columnNumber: 107
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
            lineNumber: 226,
            columnNumber: 47
        }, this);
        $[38] = groupStats.averageAccuracy;
        $[39] = groupStats.totalParticipants;
        $[40] = t;
        $[41] = t10;
    } else {
        t10 = $[41];
    }
    let t11;
    if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            ml: "auto",
            display: "flex",
            alignItems: "center",
            gap: 0.5
        };
        $[42] = t11;
    } else {
        t11 = $[42];
    }
    let t12;
    if ($[43] !== copied || $[44] !== t) {
        t12 = copied ? t("practiceDrill.collab.copied") : t("practiceDrill.collab.copyCode");
        $[43] = copied;
        $[44] = t;
        $[45] = t12;
    } else {
        t12 = $[45];
    }
    let t13;
    if ($[46] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ContentCopy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
            lineNumber: 259,
            columnNumber: 11
        }, this);
        $[46] = t13;
    } else {
        t13 = $[46];
    }
    let t14;
    if ($[47] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = {
            fontFamily: "monospace",
            letterSpacing: "0.1em",
            cursor: "pointer"
        };
        $[47] = t14;
    } else {
        t14 = $[47];
    }
    let t15;
    if ($[48] !== handleCopyCode || $[49] !== roomCode) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            icon: t13,
            size: "small",
            label: roomCode,
            onClick: handleCopyCode,
            variant: "outlined",
            sx: t14
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
            lineNumber: 277,
            columnNumber: 11
        }, this);
        $[48] = handleCopyCode;
        $[49] = roomCode;
        $[50] = t15;
    } else {
        t15 = $[50];
    }
    let t16;
    if ($[51] !== t12 || $[52] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t11,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                title: t12,
                children: t15
            }, void 0, false, {
                fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
                lineNumber: 286,
                columnNumber: 25
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
            lineNumber: 286,
            columnNumber: 11
        }, this);
        $[51] = t12;
        $[52] = t15;
        $[53] = t16;
    } else {
        t16 = $[53];
    }
    let t17;
    if ($[54] !== T1 || $[55] !== t10 || $[56] !== t16 || $[57] !== t4 || $[58] !== t5 || $[59] !== t6 || $[60] !== t8) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
            sx: t4,
            children: [
                t5,
                t6,
                t8,
                t9,
                t10,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
            lineNumber: 295,
            columnNumber: 11
        }, this);
        $[54] = T1;
        $[55] = t10;
        $[56] = t16;
        $[57] = t4;
        $[58] = t5;
        $[59] = t6;
        $[60] = t8;
        $[61] = t17;
    } else {
        t17 = $[61];
    }
    return t17;
}
_s(CollaborativePresenceBar, "HgltYR3ZdsANlRgRhqCxecrZf8s=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = CollaborativePresenceBar;
function _CollaborativePresenceBarAllParticipantsMap(p) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
        title: p.displayName || p.username,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__["Avatar"], {
            sx: {
                bgcolor: p.color || stringToColor(p.username),
                width: 28,
                height: 28,
                fontSize: "0.75rem"
            },
            children: getInitials(p)
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
            lineNumber: 310,
            columnNumber: 72
        }, this)
    }, p.username, false, {
        fileName: "[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx",
        lineNumber: 310,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "CollaborativePresenceBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PracticeDrill/buildPracticeDrillFeedback.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @fileoverview buildPracticeDrillFeedback — Generates a markdown summary of
 * practice drill results for appending to StudentMemory via upsertStudentMemory.
 * Also produces structured data for InstructorInsight records.
 */ // ============================================================================
// Types
// ============================================================================
__turbopack_context__.s([
    "buildFeedbackData",
    ()=>buildFeedbackData,
    "buildFeedbackMarkdown",
    ()=>buildFeedbackMarkdown
]);
// ============================================================================
// Feedback Builder
// ============================================================================
const WEAK_THRESHOLD = 70;
const STRONG_THRESHOLD = 90;
function buildFeedbackData(sessionData, generatedContent, unitName, drillType, sourcesEnabled) {
    const blockResults = [];
    const sourceAccuracies = {};
    for (const block of generatedContent){
        const blockId = block.sourceItemId || block.instruction.slice(0, 20);
        const result = sessionData[blockId];
        if (!result) continue;
        const sourceType = block.sourceType || 'text';
        const accuracy = result.accuracy ?? 0;
        const wasCorrect = accuracy >= STRONG_THRESHOLD;
        // Derive the concept label from instruction text (first ~60 chars)
        const concept = block.instruction.length > 60 ? block.instruction.slice(0, 57) + '...' : block.instruction;
        blockResults.push({
            blockId,
            blockType: block.type,
            sourceType,
            concept,
            accuracy,
            userAnswer: result.userAnswer ?? '',
            expectedAnswer: block.expectedAnswer ?? '',
            wasCorrect
        });
        if (!sourceAccuracies[sourceType]) sourceAccuracies[sourceType] = [];
        sourceAccuracies[sourceType].push(accuracy);
    }
    // Compute per-source average accuracy
    const blockBreakdown = {};
    for (const [source, accuracies] of Object.entries(sourceAccuracies)){
        const avg = accuracies.reduce((s, v)=>s + v, 0) / accuracies.length;
        blockBreakdown[source] = Math.round(avg);
    }
    // Identify weak and strong areas
    const weakAreas = blockResults.filter((r)=>r.accuracy < WEAK_THRESHOLD).map((r)=>r.concept);
    const strongAreas = blockResults.filter((r)=>r.accuracy >= STRONG_THRESHOLD).map((r)=>r.concept);
    // Overall accuracy
    const allAccuracies = blockResults.map((r)=>r.accuracy);
    const overallAccuracy = allAccuracies.length > 0 ? Math.round(allAccuracies.reduce((s, v)=>s + v, 0) / allAccuracies.length) : 0;
    // Sources used (from the enabled config)
    const sourcesUsed = Object.entries(sourcesEnabled).filter(([, enabled])=>enabled).map(([key])=>key);
    return {
        unitName,
        drillType,
        overallAccuracy,
        blockResults,
        weakAreas,
        strongAreas,
        sourcesUsed,
        blockBreakdown,
        timestamp: new Date().toISOString()
    };
}
function buildFeedbackMarkdown(feedback) {
    const lines = [];
    lines.push(`- **Type**: ${feedback.drillType} | **Accuracy**: ${feedback.overallAccuracy}% | **Blocks**: ${feedback.blockResults.length}`);
    lines.push(`- **Sources**: ${feedback.sourcesUsed.join(', ')}`);
    if (feedback.weakAreas.length > 0) {
        lines.push(`- **Weak areas**: ${feedback.weakAreas.slice(0, 5).join(', ')}`);
    }
    if (feedback.strongAreas.length > 0) {
        lines.push(`- **Strong areas**: ${feedback.strongAreas.slice(0, 5).join(', ')}`);
    }
    // Source breakdown
    const breakdownParts = Object.entries(feedback.blockBreakdown).map(([source, avg])=>`${source}: ${avg}%`).join(', ');
    if (breakdownParts) {
        lines.push(`- **By source**: ${breakdownParts}`);
    }
    // AI tutor note
    if (feedback.weakAreas.length > 0 && feedback.strongAreas.length > 0) {
        lines.push(`- **Note**: Student struggles with ${feedback.weakAreas.length} concept(s) but excels at ${feedback.strongAreas.length} concept(s).`);
    } else if (feedback.weakAreas.length > 0) {
        lines.push(`- **Note**: Student needs more practice on ${feedback.weakAreas.length} concept(s).`);
    } else if (feedback.overallAccuracy >= 90) {
        lines.push(`- **Note**: Excellent performance across all concepts.`);
    }
    return lines.join('\n');
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PracticeDrill/usePracticeDrill.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePracticeDrill",
    ()=>usePracticeDrill
]);
/**
 * @fileoverview usePracticeDrill — Core hook for managing a practice drill
 * session lifecycle: generation, state tracking, saving, and XP award.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$practiceXPCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/practiceXPCalculator.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$buildPracticeDrillFeedback$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PracticeDrill/buildPracticeDrillFeedback.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$8a8fb6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:8a8fb6 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$952585__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:952585 [app-client] (ecmascript) <text/javascript>");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
// ============================================================================
// Initial state
// ============================================================================
const INITIAL_SESSION = {
    id: null,
    blocks: [],
    answers: {},
    accuracy: 0,
    blocksCompleted: 0,
    complete: false,
    xpAwarded: 0
};
function usePracticeDrill(unitName = "") {
    _s();
    const [session, setSession] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(INITIAL_SESSION);
    const [generating, setGenerating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const sessionIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const generateDrill = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeDrill.useCallback[generateDrill]": async (unitId, config)=>{
            setGenerating(true);
            setError(null);
            try {
                const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$952585__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generatePracticeDrill"])({
                    unitId,
                    drillType: config.drillType.toUpperCase(),
                    count: config.count,
                    sourcesEnabled: config.sources
                });
                const blocks = result.blocks || [];
                // Create PracticeSession record
                const { data: sessionRecord, errors: sessionErrors } = await client.models.PracticeSession.create({
                    unitID: unitId,
                    drillType: config.drillType.toUpperCase(),
                    blockCount: blocks.length,
                    blocksCompleted: 0,
                    complete: false,
                    xpAwarded: 0,
                    generatedContent: JSON.stringify(blocks),
                    sourcesEnabled: config.sources,
                    data: JSON.stringify({})
                });
                if (sessionErrors && sessionErrors.length > 0) {
                    console.error("[usePracticeDrill] Failed to create session record:", sessionErrors);
                }
                const sessionId = sessionRecord?.id || `local-${Date.now()}`;
                sessionIdRef.current = sessionId;
                setSession({
                    id: sessionId,
                    blocks,
                    answers: {},
                    accuracy: 0,
                    blocksCompleted: 0,
                    complete: false,
                    xpAwarded: 0,
                    metadata: {
                        unitId,
                        drillType: config.drillType,
                        sourcesEnabled: config.sources,
                        ...result?.metadata
                    }
                });
            } catch (err) {
                console.error("[usePracticeDrill] Generation error:", err);
                setError(err.message || "Failed to generate drill");
            } finally{
                setGenerating(false);
            }
        }
    }["usePracticeDrill.useCallback[generateDrill]"], []);
    const resumeSession = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeDrill.useCallback[resumeSession]": async (sessionId_0)=>{
            setGenerating(true);
            setError(null);
            try {
                const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const { data: record } = await client_0.models.PracticeSession.get({
                    id: sessionId_0
                });
                if (!record) throw new Error("Session not found");
                const blocks_0 = record.generatedContent ? typeof record.generatedContent === "string" ? JSON.parse(record.generatedContent) : record.generatedContent : [];
                const answers = record.data ? typeof record.data === "string" ? JSON.parse(record.data) : record.data : {};
                const completed = Object.values(answers).filter({
                    "usePracticeDrill.useCallback[resumeSession]": (a)=>a?.complete
                }["usePracticeDrill.useCallback[resumeSession]"]).length;
                const accuracies = Object.values(answers).filter({
                    "usePracticeDrill.useCallback[resumeSession].accuracies": (a_0)=>a_0?.complete && typeof a_0?.accuracy === "number"
                }["usePracticeDrill.useCallback[resumeSession].accuracies"]).map({
                    "usePracticeDrill.useCallback[resumeSession].accuracies": (a_1)=>a_1.accuracy
                }["usePracticeDrill.useCallback[resumeSession].accuracies"]);
                const avgAccuracy = accuracies.length > 0 ? Math.round(accuracies.reduce({
                    "usePracticeDrill.useCallback[resumeSession]": (s, v)=>s + v
                }["usePracticeDrill.useCallback[resumeSession]"], 0) / accuracies.length) : 0;
                sessionIdRef.current = sessionId_0;
                setSession({
                    id: sessionId_0,
                    blocks: blocks_0,
                    answers,
                    accuracy: avgAccuracy,
                    blocksCompleted: completed,
                    complete: record.complete || false,
                    xpAwarded: record.xpAwarded || 0,
                    metadata: {
                        unitId: record.unitID,
                        drillType: record.drillType
                    }
                });
            } catch (err_0) {
                console.error("[usePracticeDrill] Resume error:", err_0);
                setError(err_0.message || "Failed to resume session");
            } finally{
                setGenerating(false);
            }
        }
    }["usePracticeDrill.useCallback[resumeSession]"], []);
    const replayTemplate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeDrill.useCallback[replayTemplate]": async (templateSessionId, unitId_0)=>{
            setGenerating(true);
            setError(null);
            try {
                const client_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                // Load template blocks
                const { data: template } = await client_1.models.PracticeSession.get({
                    id: templateSessionId
                });
                if (!template) throw new Error("Template session not found");
                const blocks_1 = template.generatedContent ? typeof template.generatedContent === "string" ? JSON.parse(template.generatedContent) : template.generatedContent : [];
                if (blocks_1.length === 0) throw new Error("Template has no blocks");
                // Create a new session record with cloned blocks
                const { data: newRecord, errors: sessionErrors_0 } = await client_1.models.PracticeSession.create({
                    unitID: unitId_0,
                    drillType: template.drillType || "MIXED",
                    blockCount: blocks_1.length,
                    blocksCompleted: 0,
                    complete: false,
                    xpAwarded: 0,
                    generatedContent: typeof template.generatedContent === "string" ? template.generatedContent : JSON.stringify(blocks_1),
                    sourcesEnabled: template.sourcesEnabled,
                    data: JSON.stringify({})
                });
                if (sessionErrors_0?.length) {
                    console.error("[usePracticeDrill] Failed to create replay session:", sessionErrors_0);
                }
                const sessionId_1 = newRecord?.id || `local-${Date.now()}`;
                sessionIdRef.current = sessionId_1;
                setSession({
                    id: sessionId_1,
                    blocks: blocks_1,
                    answers: {},
                    accuracy: 0,
                    blocksCompleted: 0,
                    complete: false,
                    xpAwarded: 0,
                    metadata: {
                        unitId: unitId_0,
                        drillType: template.drillType,
                        templateSessionId
                    }
                });
            } catch (err_1) {
                console.error("[usePracticeDrill] Replay error:", err_1);
                setError(err_1.message || "Failed to start from template");
            } finally{
                setGenerating(false);
            }
        }
    }["usePracticeDrill.useCallback[replayTemplate]"], []);
    const submitAnswer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeDrill.useCallback[submitAnswer]": (blockId, answer)=>{
            setSession({
                "usePracticeDrill.useCallback[submitAnswer]": (prev)=>{
                    const newAnswers = {
                        ...prev.answers,
                        [blockId]: answer
                    };
                    const completed_0 = Object.values(newAnswers).filter({
                        "usePracticeDrill.useCallback[submitAnswer]": (a_2)=>a_2.complete
                    }["usePracticeDrill.useCallback[submitAnswer]"]).length;
                    const accuracies_0 = Object.values(newAnswers).filter({
                        "usePracticeDrill.useCallback[submitAnswer].accuracies_0": (a_3)=>a_3.complete
                    }["usePracticeDrill.useCallback[submitAnswer].accuracies_0"]).map({
                        "usePracticeDrill.useCallback[submitAnswer].accuracies_0": (a_4)=>a_4.accuracy
                    }["usePracticeDrill.useCallback[submitAnswer].accuracies_0"]);
                    const avgAccuracy_0 = accuracies_0.length > 0 ? Math.round(accuracies_0.reduce({
                        "usePracticeDrill.useCallback[submitAnswer]": (s_0, v_0)=>s_0 + v_0
                    }["usePracticeDrill.useCallback[submitAnswer]"], 0) / accuracies_0.length) : 0;
                    return {
                        ...prev,
                        answers: newAnswers,
                        blocksCompleted: completed_0,
                        accuracy: avgAccuracy_0
                    };
                }
            }["usePracticeDrill.useCallback[submitAnswer]"]);
            // Persist to DynamoDB (fire and forget)
            if (sessionIdRef.current) {
                const client_2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                client_2.models.PracticeSession.update({
                    id: sessionIdRef.current,
                    data: JSON.stringify({
                        ...session.answers,
                        [blockId]: answer
                    }),
                    blocksCompleted: Object.values(session.answers).filter({
                        "usePracticeDrill.useCallback[submitAnswer]": (a_5)=>a_5.complete
                    }["usePracticeDrill.useCallback[submitAnswer]"]).length + 1
                }).catch({
                    "usePracticeDrill.useCallback[submitAnswer]": (err_2)=>console.error("[usePracticeDrill] Save error:", err_2)
                }["usePracticeDrill.useCallback[submitAnswer]"]);
            }
        }
    }["usePracticeDrill.useCallback[submitAnswer]"], [
        session.answers
    ]);
    const completeDrill = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeDrill.useCallback[completeDrill]": async ()=>{
            setSaving(true);
            try {
                const client_3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                // Calculate XP (we'd need sessionsCompletedToday from server, approximate with 0 for now)
                const drillXP = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$practiceXPCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateDrillXP"])(0);
                const accuracyBonus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$practiceXPCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateAccuracyBonus"])(session.accuracy);
                const totalXP = drillXP + accuracyBonus;
                // Update PracticeSession
                if (sessionIdRef.current) {
                    await client_3.models.PracticeSession.update({
                        id: sessionIdRef.current,
                        complete: true,
                        accuracy: session.accuracy,
                        blocksCompleted: session.blocksCompleted,
                        xpAwarded: totalXP,
                        data: JSON.stringify(session.answers)
                    });
                }
                // Create Grade record for this practice attempt
                const unitId_1 = session.metadata?.unitId || "";
                let attemptNumber = 1;
                if (sessionIdRef.current) {
                    try {
                        const { data: existingGrades } = await client_3.models.Grade.listGradeByPracticeSessionID({
                            practiceSessionID: sessionIdRef.current
                        });
                        attemptNumber = (existingGrades?.length || 0) + 1;
                    } catch (err_4) {
                        console.error("[usePracticeDrill] Failed to count existing attempts:", err_4);
                    }
                }
                try {
                    await client_3.models.Grade.create({
                        unitID: unitId_1,
                        practiceSessionID: sessionIdRef.current || undefined,
                        attempt: attemptNumber,
                        data: JSON.stringify(session.answers),
                        accuracy: session.accuracy,
                        complete: true,
                        percentComplete: 100
                    });
                } catch (err_5) {
                    console.error("[usePracticeDrill] Grade creation error:", err_5);
                }
                // Build and send student memory feedback
                const feedbackData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$buildPracticeDrillFeedback$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildFeedbackData"])(session.answers, session.blocks, unitName, session.metadata?.drillType || "mixed", session.metadata?.sourcesEnabled || {});
                const feedbackMarkdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$buildPracticeDrillFeedback$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildFeedbackMarkdown"])(feedbackData);
                // Write insight fields directly onto PracticeSession (InstructorInsight model removed)
                try {
                    if (sessionIdRef.current) {
                        await client_3.models.PracticeSession.update({
                            id: sessionIdRef.current,
                            insightStudentId: "",
                            // filled by owner auth
                            weakAreas: feedbackData.weakAreas || [],
                            strongAreas: feedbackData.strongAreas || [],
                            sourcesUsedList: feedbackData.sourcesUsed || [],
                            blockBreakdown: feedbackData.blockBreakdown || {},
                            insightTimestamp: new Date().toISOString()
                        });
                    }
                } catch (err_6) {
                    console.error("[usePracticeDrill] PracticeSession insight update error:", err_6);
                }
                // Update per-unit learning memory and rebuild central profile (fire-and-forget)
                if (unitId_1) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$8a8fb6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["updateLearningMemory"])("", // studentId filled server-side via owner auth
                    unitId_1, session.accuracy, feedbackData.weakAreas, feedbackData.strongAreas, {
                        accuracyBySource: feedbackData.blockBreakdown,
                        sourceType: session.metadata?.drillType || "practice"
                    }).catch({
                        "usePracticeDrill.useCallback[completeDrill]": (err_7)=>console.error("[usePracticeDrill] updateLearningMemory error:", err_7)
                    }["usePracticeDrill.useCallback[completeDrill]"]);
                }
                setSession({
                    "usePracticeDrill.useCallback[completeDrill]": (prev_0)=>({
                            ...prev_0,
                            complete: true,
                            xpAwarded: totalXP
                        })
                }["usePracticeDrill.useCallback[completeDrill]"]);
            } catch (err_3) {
                console.error("[usePracticeDrill] Completion error:", err_3);
                setError(err_3.message || "Failed to complete drill");
            } finally{
                setSaving(false);
            }
        }
    }["usePracticeDrill.useCallback[completeDrill]"], [
        session,
        unitName
    ]);
    const reset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeDrill.useCallback[reset]": ()=>{
            setSession(INITIAL_SESSION);
            sessionIdRef.current = null;
            setError(null);
        }
    }["usePracticeDrill.useCallback[reset]"], []);
    return {
        session,
        generating,
        saving,
        error,
        generateDrill,
        resumeSession,
        replayTemplate,
        submitAnswer,
        completeDrill,
        reset
    };
}
_s(usePracticeDrill, "UYXja23t1H6LVPyqxnxgRb1tnnw=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PracticeDrillDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview PracticeDrillDialog — Full-screen dialog wrapper for practice
 * drills. Contains PracticeDrillProgress header + PracticeDrillWorkbook body.
 * Orchestrates the full drill lifecycle via usePracticeDrill.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slide$2f$Slide$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Slide$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Slide/Slide.js [app-client] (ecmascript) <export default as Slide>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillProgress$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PracticeDrill/PracticeDrillProgress.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$DrillGradeAdapter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PracticeDrill/DrillGradeAdapter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$CollaborativePresenceBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PracticeDrill/CollaborativePresenceBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$Workbook$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/Workbook.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/fileContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$usePracticeDrill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PracticeDrill/usePracticeDrill.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$practiceCollaborationHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/practiceCollaborationHooks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$practiceXPCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/practiceXPCalculator.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// ============================================================================
// Transition
// ============================================================================
const Transition = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = function Transition(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "19b057423e38992b2e15c7b2a521494b36e8aeb5ea47dc7c1f16427606ee79b7") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "19b057423e38992b2e15c7b2a521494b36e8aeb5ea47dc7c1f16427606ee79b7";
    }
    let t0;
    if ($[1] !== props || $[2] !== ref) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slide$2f$Slide$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Slide$3e$__["Slide"], {
            direction: "up",
            ref: ref,
            ...props
        }, void 0, false, {
            fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
            lineNumber: 40,
            columnNumber: 10
        }, this);
        $[1] = props;
        $[2] = ref;
        $[3] = t0;
    } else {
        t0 = $[3];
    }
    return t0;
});
_c1 = Transition;
function PracticeDrillDialog({ open, onClose, unitId, unitName = '', config, sessionsCompletedToday = 0, username = '', displayName = '', joinSessionId, joinRoomCode }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('components');
    const { session, generating, saving, error, generateDrill, completeDrill, reset } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$usePracticeDrill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePracticeDrill"])(unitName);
    const [drillStats, setDrillStats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        blocksCompleted: 0,
        accuracy: 0,
        complete: false
    });
    const [roomCode, setRoomCode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(joinRoomCode || '');
    const isCollaborative = config.collaborative === true || !!joinSessionId;
    const effectiveSessionId = joinSessionId || session.id || '';
    // Collaborative hook — only active when in collaborative mode with a session
    const collab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$practiceCollaborationHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePracticeCollaboration"])(isCollaborative && effectiveSessionId && username ? {
        sessionId: effectiveSessionId,
        user: {
            username,
            displayName: displayName || username
        }
    } : null);
    // Start generation when dialog opens with blocks not yet loaded
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "PracticeDrillDialog.useEffect": ()=>{
            if (open && session.blocks.length === 0 && !generating && !error && !joinSessionId) {
                generateDrill(unitId, config);
            }
        }
    }["PracticeDrillDialog.useEffect"], [
        open,
        session.blocks.length,
        generating,
        error,
        generateDrill,
        unitId,
        config,
        joinSessionId
    ]);
    // Generate room code for new collaborative sessions
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "PracticeDrillDialog.useEffect": ()=>{
            if (isCollaborative && session.id && !roomCode) {
                const code = session.id.slice(0, 6).toUpperCase();
                setRoomCode(code);
                // Update PracticeSession record with roomCode and collaborative flag
                const client = ({
                    "PracticeDrillDialog.useEffect.client": async ()=>{
                        try {
                            const { getAmplifyClient } = await __turbopack_context__.A("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript, async loader)");
                            const c = getAmplifyClient();
                            await c.models.PracticeSession.update({
                                id: session.id,
                                collaborative: true,
                                roomCode: code,
                                maxParticipants: config.maxParticipants || 5,
                                participantIds: JSON.stringify([
                                    username
                                ])
                            });
                        } catch (err) {
                            console.error('[PracticeDrillDialog] Failed to set room code:', err);
                        }
                    }
                })["PracticeDrillDialog.useEffect.client"]();
            }
        }
    }["PracticeDrillDialog.useEffect"], [
        isCollaborative,
        session.id,
        roomCode,
        config.maxParticipants,
        username
    ]);
    const handleClose = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PracticeDrillDialog.useCallback[handleClose]": ()=>{
            reset();
            setDrillStats({
                blocksCompleted: 0,
                accuracy: 0,
                complete: false
            });
            setRoomCode('');
            onClose();
        }
    }["PracticeDrillDialog.useCallback[handleClose]"], [
        reset,
        onClose
    ]);
    const handleComplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PracticeDrillDialog.useCallback[handleComplete]": async ()=>{
            await completeDrill();
        }
    }["PracticeDrillDialog.useCallback[handleComplete]"], [
        completeDrill
    ]);
    const handleStatsChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PracticeDrillDialog.useCallback[handleStatsChange]": (stats)=>{
            setDrillStats(stats);
        }
    }["PracticeDrillDialog.useCallback[handleStatsChange]"], []);
    const xpPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$practiceXPCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["previewXP"])(sessionsCompletedToday, drillStats.accuracy);
    const allCompleted = drillStats.complete && session.blocks.length > 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
        open: open,
        onClose: handleClose,
        fullScreen: true,
        TransitionComponent: Transition,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                sx: {
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1,
                    pr: 6
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "h6",
                        component: "span",
                        sx: {
                            flex: 1
                        },
                        children: unitName ? `${t('practiceDrill.dialog.title')}: ${unitName}` : t('practiceDrill.dialog.title')
                    }, void 0, false, {
                        fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                        lineNumber: 172,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                        onClick: handleClose,
                        "aria-label": t('practiceDrill.dialog.close'),
                        sx: {
                            position: 'absolute',
                            right: 8,
                            top: 8
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                            lineNumber: 182,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                        lineNumber: 177,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this),
            isCollaborative && effectiveSessionId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$CollaborativePresenceBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                participants: collab.participants,
                currentUser: {
                    username,
                    displayName: displayName || username
                },
                groupStats: collab.groupStats,
                ownProgress: collab.ownProgress,
                roomCode: roomCode,
                isConnected: collab.isConnected
            }, void 0, false, {
                fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                lineNumber: 187,
                columnNumber: 49
            }, this),
            session.blocks.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillProgress$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                blocksCompleted: drillStats.blocksCompleted,
                blockCount: session.blocks.length,
                xpEarned: session.complete ? session.xpAwarded : xpPreview.total,
                xpDiminished: sessionsCompletedToday > 0
            }, void 0, false, {
                fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                lineNumber: 193,
                columnNumber: 37
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                dividers: true,
                children: [
                    generating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            py: 8,
                            gap: 2
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                variant: "circular",
                                width: 48,
                                height: 48
                            }, void 0, false, {
                                fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                                lineNumber: 204,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                variant: "text",
                                width: 240,
                                height: 24
                            }, void 0, false, {
                                fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                                lineNumber: 205,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                        lineNumber: 197,
                        columnNumber: 24
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                        severity: "error",
                        sx: {
                            mb: 2
                        },
                        children: [
                            error,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                size: "small",
                                onClick: ()=>generateDrill(unitId, config),
                                sx: {
                                    ml: 1
                                },
                                children: t('practiceDrill.dialog.retry')
                            }, void 0, false, {
                                fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                                lineNumber: 213,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                        lineNumber: 209,
                        columnNumber: 19
                    }, this),
                    session.complete && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                        severity: "success",
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                            lineNumber: 221,
                            columnNumber: 62
                        }, this),
                        sx: {
                            mb: 2
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "subtitle1",
                                fontWeight: 600,
                                children: t('practiceDrill.dialog.complete')
                            }, void 0, false, {
                                fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                                lineNumber: 224,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                children: t('practiceDrill.dialog.completeSummary', {
                                    accuracy: drillStats.accuracy,
                                    xp: session.xpAwarded
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                                lineNumber: 227,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                        lineNumber: 221,
                        columnNumber: 30
                    }, this),
                    !generating && session.blocks.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilesProvider"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DictionaryProvider"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$DrillGradeAdapter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                sessionId: session.id || '',
                                blocks: session.blocks,
                                onGradeChange: (_data, stats_0)=>handleStatsChange(stats_0),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$Workbook$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Workbook"], {}, void 0, false, {
                                    fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                                    lineNumber: 239,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                                lineNumber: 238,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                            lineNumber: 237,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                        lineNumber: 236,
                        columnNumber: 54
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                lineNumber: 195,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        onClick: handleClose,
                        color: "inherit",
                        children: session.complete ? t('practiceDrill.dialog.done') : t('practiceDrill.dialog.cancel')
                    }, void 0, false, {
                        fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                        lineNumber: 246,
                        columnNumber: 9
                    }, this),
                    !session.complete && allCompleted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        variant: "contained",
                        onClick: handleComplete,
                        disabled: saving,
                        startIcon: saving ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                            variant: "circular",
                            width: 16,
                            height: 16
                        }, void 0, false, {
                            fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                            lineNumber: 249,
                            columnNumber: 138
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                            lineNumber: 249,
                            columnNumber: 195
                        }, this),
                        children: t('practiceDrill.dialog.finish')
                    }, void 0, false, {
                        fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                        lineNumber: 249,
                        columnNumber: 47
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
                lineNumber: 245,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx",
        lineNumber: 165,
        columnNumber: 10
    }, this);
}
_s(PracticeDrillDialog, "HUm/G0AOmbyIml0ar73i2oHdstA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$usePracticeDrill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePracticeDrill"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$practiceCollaborationHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePracticeCollaboration"]
    ];
});
_c2 = PracticeDrillDialog;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Transition$React.forwardRef");
__turbopack_context__.k.register(_c1, "Transition");
__turbopack_context__.k.register(_c2, "PracticeDrillDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx [app-client] (ecmascript) <export default as PracticeDrillDialog>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PracticeDrillDialog",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PracticeDrill$2f$PracticeDrillDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PracticeDrill/PracticeDrillDialog.tsx [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=src_components_PracticeDrill_1krtnym._.js.map