(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/utils/debug/StateSnapshot.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_utils_debug_1k0uqmh._.js",
  "static/chunks/src_utils_debug_StateSnapshot_ts_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/utils/debug/StateSnapshot.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/src/offline/SyncQueue.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/offline/SyncQueue.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/canvas-confetti/dist/confetti.module.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_canvas-confetti_dist_confetti_module_mjs_1mhq54j._.js",
  "static/chunks/node_modules_canvas-confetti_dist_confetti_module_mjs_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/canvas-confetti/dist/confetti.module.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/idb/build/index.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_idb_build_index_0tf3rx8.js",
  "static/chunks/node_modules_idb_build_index_07nfyrb.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/idb/build/index.js [app-client] (ecmascript)");
    });
});
}),
"[project]/src/utils/generateThumbnail.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_utils_generateThumbnail_ts_1e9pt-8._.js",
  "static/chunks/src_utils_generateThumbnail_ts_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/utils/generateThumbnail.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/src/utils/unitContentStorage.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/utils/unitContentStorage.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/components/ImageComponent.jsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_18pedkr._.js",
  "static/chunks/src_components_Editor3_components_ImageComponent_jsx_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/ImageComponent.jsx [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/aws-amplify/dist/esm/storage/index.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_05kkgtf._.js",
  "static/chunks/node_modules_aws-amplify_dist_esm_storage_index_mjs_1xnf1lc._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/aws-amplify/dist/esm/storage/index.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/pako/dist/pako.esm.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_pako_dist_pako_esm_mjs_0ghgpjx._.js",
  "static/chunks/node_modules_pako_dist_pako_esm_mjs_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/pako/dist/pako.esm.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/components/ConversationPlayerComponent.jsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_0nqr146._.js",
  "static/chunks/src_components_Editor3_components_ConversationPlayerComponent_jsx_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/ConversationPlayerComponent.jsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/components/ConversationPlaylistEditor.jsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_0viiev8._.js",
  "static/chunks/src_components_Editor3_components_ConversationPlaylistEditor_jsx_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/ConversationPlaylistEditor.jsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/utils/amplifyClient.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/aws-amplify/dist/esm/auth/index.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_158zjje._.js",
  "static/chunks/node_modules_aws-amplify_dist_esm_auth_index_mjs_1xnf1lc._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/aws-amplify/dist/esm/auth/index.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/src/utils/embeddingStorage.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_utils_embeddingStorage_ts_12q19vg._.js",
  "static/chunks/src_utils_embeddingStorage_ts_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/utils/embeddingStorage.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/components/MediaPlayerComponent.jsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@xmldom_xmldom_lib_1_eqfsl._.js",
  "static/chunks/node_modules_video_js_dist_video_es_1zaxhyv.js",
  "static/chunks/node_modules_17bjtht._.js",
  "static/chunks/src_components_Editor3_components_MediaPlayerComponent_jsx_1n_vwi8._.js",
  {
    "path": "static/chunks/node_modules_video_js_dist_video-js_0vmwhu_.css",
    "included": [
      "[project]/node_modules/video.js/dist/video-js.css [app-client] (css)"
    ]
  },
  "static/chunks/src_components_Editor3_components_MediaPlayerComponent_jsx_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/MediaPlayerComponent.jsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/components/SketchPad.jsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  {
    "path": "static/chunks/node_modules_@excalidraw_excalidraw_dist_dev_index_0lnl-ta.css",
    "included": [
      "[project]/node_modules/@excalidraw/excalidraw/dist/dev/index.css [app-client] (css)"
    ]
  },
  "static/chunks/node_modules_@excalidraw_excalidraw_dist_dev_index_06hf1e-.js",
  "static/chunks/_1wanbry._.js",
  "static/chunks/src_components_Editor3_components_SketchPad_jsx_1yjdi1b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/SketchPad.jsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/Editor3/components/PdfViewerComponent.jsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_0j5ea82._.js",
  "static/chunks/src_components_Editor3_components_PdfViewerComponent_jsx_1vf1t1t._.js",
  {
    "path": "static/chunks/node_modules_react-pdf_dist_Page_19_l86v._.css",
    "included": [
      "[project]/node_modules/react-pdf/dist/Page/TextLayer.css [app-client] (css)",
      "[project]/node_modules/react-pdf/dist/Page/AnnotationLayer.css [app-client] (css)"
    ],
    "moduleChunks": [
      "static/chunks/node_modules_react-pdf_dist_Page_TextLayer_css_1igg3k2._.single.css",
      "static/chunks/node_modules_react-pdf_dist_Page_AnnotationLayer_css_1igg3k2._.single.css"
    ]
  },
  "static/chunks/src_components_Editor3_components_PdfViewerComponent_jsx_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/PdfViewerComponent.jsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/nodes/CustomAINode/CustomAIEditor.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_11b611h._.js",
  "static/chunks/src_components_Editor3_nodes_CustomAINode_CustomAIEditor_tsx_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/nodes/CustomAINode/CustomAIEditor.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/Editor3/nodes/CustomAINode/CustomAIComponent.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_Editor3_components_SketchPad_jsx_0k419tl._.js",
  "static/chunks/src_components_Editor3_nodes_CustomAINode_CustomAIComponent_tsx_0hd7i-z._.js",
  "static/chunks/src_components_Editor3_nodes_CustomAINode_CustomAIComponent_tsx_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/nodes/CustomAINode/CustomAIComponent.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/offline/AIRouter.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_1amnfle._.js",
  "static/chunks/src_offline_0lt5a9t._.js",
  "static/chunks/src_offline_AIRouter_ts_07nfyrb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/offline/AIRouter.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/aws-amplify/dist/esm/api/index.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_0lpq2z1._.js",
  "static/chunks/node_modules_aws-amplify_dist_esm_api_index_mjs_1xnf1lc._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/aws-amplify/dist/esm/api/index.mjs [app-client] (ecmascript)");
    });
});
}),
]);