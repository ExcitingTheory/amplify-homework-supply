(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Editor3/components/FileManager2.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CourseVectorStore",
    ()=>CourseVectorStore,
    "default",
    ()=>FileManager2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Collapse/Collapse.js [app-client] (ecmascript) <export default as Collapse>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Modal/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tabs/Tabs.js [app-client] (ecmascript) <export default as Tabs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tab/Tab.js [app-client] (ecmascript) <export default as Tab>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Menu/Menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$InputAdornment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputAdornment$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputAdornment/InputAdornment.js [app-client] (ecmascript) <export default as InputAdornment>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript) <export default as Snackbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Portal/Portal.js [app-client] (ecmascript) <export default as Portal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-virtual/dist/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$vectorStoreContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/vectorStoreContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Search.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$UploadFile$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/UploadFile.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Delete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Add.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MoreVert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Refresh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Refresh.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandMore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandLess.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Autorenew$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Autorenew.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Edit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MenuBook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MenuBook.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Quiz$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Quiz.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Summarize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Summarize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Flag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Flag.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lightbulb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Lightbulb.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/fileContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/settingsContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$f001e6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:f001e6 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$274953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:274953 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$7d3f15__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:7d3f15 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useYjsFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useYjsFile.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/remove.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/apis/fetchAuthSession.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/fileUploadUtils.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vectorStoreDB$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/vectorStoreDB.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$embeddingWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/embeddingWorkerManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ConversationPlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/ConversationPlaylistPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ImagesPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/ImagesPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ShowDeletedToggle$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ShowDeletedToggle.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useRecycleBin.js [app-client] (ecmascript)");
// Lexical imports for inline editing
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposer.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalRichTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalRichTextPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalContentEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHistoryPlugin.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalOnChangePlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalErrorBoundary.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$html$2f$LexicalHtml$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/html/LexicalHtml.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$FileManagerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/FileManagerContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getResponsiveImageUrls$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getResponsiveImageUrls.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$StaticWaveform$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/StaticWaveform.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$FileThumbnail$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/FileThumbnail.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PictureAsPdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PictureAsPdf.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$HourglassEmpty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/HourglassEmpty.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Error.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudUpload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CloudUpload.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Download.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Folder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Folder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Description.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextareaAutosize/TextareaAutosize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Mic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Mic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$hexToRgb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/hexToRgb.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$EnhancedGenerators$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/EnhancedGenerators.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$SuggestedContent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/SuggestedContent.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3Modal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudio3Modal.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudioEnhancedModal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudioEnhancedModal.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$recordingStudioPresets$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/recordingStudioPresets.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature(), _s9 = __turbopack_context__.k.signature(), _s10 = __turbopack_context__.k.signature(), _s11 = __turbopack_context__.k.signature(), _s12 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Utility functions for hybrid search
const debounce = (func, wait)=>{
    let timeout;
    return function executedFunction(...args) {
        const later = ()=>{
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
};
// Highlight text matches
const highlightMatches = (text, searchTerm)=>{
    if (!searchTerm || !text) return text;
    const regex = new RegExp(`(${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi");
    const parts = text.split(regex);
    return parts.map((part, i)=>regex.test(part) ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("mark", {
            key: i,
            style: {
                backgroundColor: "var(--mui-palette-custom-searchHighlight, #ffeb3b)",
                padding: "0 2px"
            }
        }, part) : part);
};
// Check if text contains search term (case-insensitive)
const containsSearchTerm = (text, searchTerm)=>{
    if (!text || !searchTerm) return false;
    return text.toLowerCase().includes(searchTerm.toLowerCase());
};
class CourseVectorStore {
    constructor(){
        this.items = []; // In-memory cache for fast search
        this.loaded = false; // Track if IndexedDB data has been loaded
        this.loadPromise = null; // Prevent duplicate loads
    }
    async clear() {
        this.items = [];
        this.loaded = false;
    }
    add(item) {
        console.log(`[VectorStore.add] Adding embedding:`, {
            id: item.id,
            documentId: item.documentId,
            page: item.page,
            hasVector: !!item.vector,
            vectorLength: item.vector?.length,
            fileName: item.metadata?.fileName,
            totalItemsAfter: this.items.length + 1
        });
        this.items.push(item);
    }
    /**
   * Load all embeddings from IndexedDB into memory
   * @returns {Promise<number>} Number of embeddings loaded
   */ async loadFromIndexedDB() {
        if (this.loadPromise) {
            return this.loadPromise;
        }
        this.loadPromise = (async ()=>{
            try {
                const embeddings = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vectorStoreDB$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadAllEmbeddings"])();
                this.items = embeddings;
                this.loaded = true;
                console.log(`[VectorStore] Loaded ${embeddings.length} embeddings from IndexedDB`);
                return embeddings.length;
            } catch (error) {
                console.error("[VectorStore] Failed to load from IndexedDB:", error);
                this.loaded = false;
                return 0;
            } finally{
                this.loadPromise = null;
            }
        })();
        return this.loadPromise;
    }
    /**
   * Save document embeddings to IndexedDB
   * @param {string} documentId
   * @param {Array} embeddings - Array of {page, embedding} objects
   * @param {Object} metadata - File metadata
   */ async saveToIndexedDB(documentId, embeddings, metadata) {
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vectorStoreDB$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveEmbeddings"])(documentId, embeddings, metadata);
        } catch (error) {
            console.error("[VectorStore] Failed to save to IndexedDB:", error);
        }
    }
    /**
   * Delete document embeddings from IndexedDB
   * @param {string} documentId
   */ async deleteFromIndexedDB(documentId) {
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vectorStoreDB$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteEmbeddings"])(documentId);
            // Also remove from in-memory cache
            this.items = this.items.filter((item)=>item.documentId !== documentId);
        } catch (error) {
            console.error("[VectorStore] Failed to delete from IndexedDB:", error);
        }
    }
    async search(queryVector, filters = {}, topK = 50, queryText = "") {
        let results = this.items;
        // Apply metadata filters first
        if (filters.fileId) {
            results = results.filter((item)=>item.metadata?.fileId === filters.fileId);
        }
        if (filters.documentId) {
            results = results.filter((item)=>item.metadata?.documentId === filters.documentId || item.documentId === filters.documentId);
        }
        if (filters.mimeType) {
            results = results.filter((item)=>item.metadata?.mimeType === filters.mimeType);
        }
        // Separate items with and without embeddings
        const itemsWithEmbeddings = results.filter((item)=>queryVector && item.vector);
        const itemsWithoutEmbeddings = results.filter((item)=>!(queryVector && item.vector));
        console.log(`[VectorStore.search] Processing ${itemsWithEmbeddings.length} items with embeddings, ${itemsWithoutEmbeddings.length} without`);
        // Compute vector similarities using worker (for large batches)
        let vectorResults = [];
        if (itemsWithEmbeddings.length > 0) {
            // For large datasets, use the worker to calculate similarities in parallel
            if (itemsWithEmbeddings.length > 50) {
                console.log("[VectorStore.search] Using worker for similarity calculations");
                try {
                    // Calculate similarities in the worker
                    const similarityResults = await Promise.allSettled(itemsWithEmbeddings.map((item)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$embeddingWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cosineSimilarity"](queryVector, item.vector)));
                    vectorResults = itemsWithEmbeddings.map((item, i)=>({
                            ...item,
                            similarity: similarityResults[i].status === "fulfilled" ? similarityResults[i].value : 0
                        })).filter((item)=>item.similarity > 0);
                } catch (error) {
                    console.error("[VectorStore.search] Worker error, falling back to main thread:", error);
                    // Fallback: calculate on main thread
                    vectorResults = await this._calculateSimilaritiesMainThread(queryVector, itemsWithEmbeddings);
                }
            } else {
                // For small datasets, calculate on main thread (avoid worker overhead)
                vectorResults = await this._calculateSimilaritiesMainThread(queryVector, itemsWithEmbeddings);
            }
        }
        // Compute text similarities for items without embeddings
        const textResults = itemsWithoutEmbeddings.map((item)=>{
            let similarity = 0;
            if (queryText && item.text) {
                const queryLower = queryText.toLowerCase();
                const textLower = item.text.toLowerCase();
                // Simple text matching score
                if (textLower.includes(queryLower)) {
                    // Exact phrase match
                    similarity = 0.8;
                } else {
                    // Word-level matching
                    const queryWords = queryLower.split(/\s+/).filter((w)=>w.length > 2);
                    const matchedWords = queryWords.filter((word)=>textLower.includes(word));
                    similarity = matchedWords.length / Math.max(queryWords.length, 1) * 0.6;
                }
            }
            return {
                ...item,
                similarity
            };
        });
        // Combine results
        results = [
            ...vectorResults,
            ...textResults
        ];
        // Filter out very low scores
        results = results.filter((item)=>item.similarity > 0.1);
        // Sort and return top K (use worker for large result sets)
        if (results.length > 100) {
            try {
                return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$embeddingWorkerManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortAndLimit"](results, topK);
            } catch (error) {
                console.error("[VectorStore.search] Worker sort error, falling back:", error);
                return results.sort((a, b)=>b.similarity - a.similarity).slice(0, topK);
            }
        } else {
            return results.sort((a, b)=>b.similarity - a.similarity).slice(0, topK);
        }
    }
    // Fallback method: calculate similarities on main thread
    async _calculateSimilaritiesMainThread(queryVector, items) {
        // Inline cosine similarity for fallback
        const cosineSimilarity = (vecA, vecB)=>{
            if (!vecA || !vecB || vecA.length !== vecB.length) return 0;
            let dotProduct = 0, normA = 0, normB = 0;
            for(let i = 0; i < vecA.length; i++){
                dotProduct += vecA[i] * vecB[i];
                normA += vecA[i] * vecA[i];
                normB += vecB[i] * vecB[i];
            }
            const denominator = Math.sqrt(normA) * Math.sqrt(normB);
            return denominator === 0 ? 0 : dotProduct / denominator;
        };
        return items.map((item)=>({
                ...item,
                similarity: cosineSimilarity(queryVector, item.vector)
            }));
    }
}
// =============================================================================
// InlineEditorField - Lexical editor for inline filename and content editing
// =============================================================================
function InlineEditorField(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(68);
    if ($[0] !== "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab") {
        for(let $i = 0; $i < 68; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab";
    }
    const { value, field, onSave, placeholder: t1, label: t2, multiline: t3, autosave: t4, storageKey } = t0;
    const placeholder = t1 === undefined ? "" : t1;
    const label = t2 === undefined ? "" : t2;
    const multiline = t3 === undefined ? false : t3;
    const autosave = t4 === undefined ? true : t4;
    const [localValue, setLocalValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(value);
    const [isDraft, setIsDraft] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const saveTimeoutRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const editorRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    let t5;
    let t6;
    if ($[1] !== storageKey || $[2] !== value) {
        t5 = ({
            "InlineEditorField[useEffect()]": ()=>{
                if (storageKey && ("TURBOPACK compile-time value", "object") !== "undefined") {
                    const draft = sessionStorage.getItem(`draft_${storageKey}`);
                    if (draft && draft !== value) {
                        setLocalValue(draft);
                        setIsDraft(true);
                    }
                }
            }
        })["InlineEditorField[useEffect()]"];
        t6 = [
            storageKey,
            value
        ];
        $[1] = storageKey;
        $[2] = value;
        $[3] = t5;
        $[4] = t6;
    } else {
        t5 = $[3];
        t6 = $[4];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t5, t6);
    let t7;
    let t8;
    if ($[5] !== value) {
        t7 = ({
            "InlineEditorField[useEffect()]": ()=>{
                setLocalValue(value);
                setIsDraft(false);
            }
        })["InlineEditorField[useEffect()]"];
        t8 = [
            value
        ];
        $[5] = value;
        $[6] = t7;
        $[7] = t8;
    } else {
        t7 = $[6];
        t8 = $[7];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t7, t8);
    let initialConfig;
    if ($[8] !== field || $[9] !== localValue || $[10] !== storageKey) {
        let t9;
        if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = {
                text: {
                    bold: "font-weight: bold;",
                    italic: "font-style: italic;"
                }
            };
            $[12] = t9;
        } else {
            t9 = $[12];
        }
        initialConfig = {
            namespace: `InlineEditor-${field}-${storageKey}`,
            theme: t9,
            onError: _temp,
            editorState: ()=>{
                if (localValue) {
                    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEditor"])(initialConfig);
                    const parser = new DOMParser();
                    parser.parseFromString(localValue, "text/html");
                    return editor.setEditorState(editor.parseEditorState(JSON.stringify({
                        root: {
                            children: [
                                {
                                    children: [
                                        {
                                            detail: 0,
                                            format: 0,
                                            mode: "normal",
                                            style: "",
                                            text: localValue,
                                            type: "text",
                                            version: 1
                                        }
                                    ],
                                    direction: "ltr",
                                    format: "",
                                    indent: 0,
                                    type: "paragraph",
                                    version: 1
                                }
                            ],
                            direction: "ltr",
                            format: "",
                            indent: 0,
                            type: "root",
                            version: 1
                        }
                    })));
                }
                return null;
            }
        };
        $[8] = field;
        $[9] = localValue;
        $[10] = storageKey;
        $[11] = initialConfig;
    } else {
        initialConfig = $[11];
    }
    let t9;
    if ($[13] !== autosave || $[14] !== onSave || $[15] !== storageKey || $[16] !== value) {
        t9 = ({
            "InlineEditorField[handleChange]": (editorState, editor_0)=>{
                editor_0.read({
                    "InlineEditorField[handleChange > editor_0.read()]": ()=>{
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$html$2f$LexicalHtml$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$generateHtmlFromNodes"])(editor_0, null);
                        const textContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().getTextContent();
                        setLocalValue(textContent);
                        if (storageKey && ("TURBOPACK compile-time value", "object") !== "undefined") {
                            sessionStorage.setItem(`draft_${storageKey}`, textContent);
                        }
                        const hasChanges = textContent !== value;
                        setIsDraft(hasChanges);
                        if (autosave && hasChanges) {
                            if (saveTimeoutRef.current) {
                                clearTimeout(saveTimeoutRef.current);
                            }
                            saveTimeoutRef.current = setTimeout({
                                "InlineEditorField[handleChange > editor_0.read() > setTimeout()]": ()=>{
                                    onSave(textContent);
                                    setIsDraft(false);
                                    if (storageKey && ("TURBOPACK compile-time value", "object") !== "undefined") {
                                        sessionStorage.removeItem(`draft_${storageKey}`);
                                    }
                                }
                            }["InlineEditorField[handleChange > editor_0.read() > setTimeout()]"], 1000);
                        }
                    }
                }["InlineEditorField[handleChange > editor_0.read()]"]);
            }
        })["InlineEditorField[handleChange]"];
        $[13] = autosave;
        $[14] = onSave;
        $[15] = storageKey;
        $[16] = value;
        $[17] = t9;
    } else {
        t9 = $[17];
    }
    const handleChange = t9;
    let t10;
    if ($[18] !== localValue || $[19] !== onSave || $[20] !== storageKey || $[21] !== value) {
        t10 = ({
            "InlineEditorField[handleSaveNow]": ()=>{
                if (localValue !== value) {
                    onSave(localValue);
                    setIsDraft(false);
                    if (storageKey && ("TURBOPACK compile-time value", "object") !== "undefined") {
                        sessionStorage.removeItem(`draft_${storageKey}`);
                    }
                }
            }
        })["InlineEditorField[handleSaveNow]"];
        $[18] = localValue;
        $[19] = onSave;
        $[20] = storageKey;
        $[21] = value;
        $[22] = t10;
    } else {
        t10 = $[22];
    }
    const handleSaveNow = t10;
    let t11;
    if ($[23] !== storageKey || $[24] !== value) {
        t11 = ({
            "InlineEditorField[handleRevert]": ()=>{
                setLocalValue(value);
                setIsDraft(false);
                if (storageKey && ("TURBOPACK compile-time value", "object") !== "undefined") {
                    sessionStorage.removeItem(`draft_${storageKey}`);
                }
                if (editorRef.current) {
                    editorRef.current.setEditorState(editorRef.current.parseEditorState(JSON.stringify({
                        root: {
                            children: [
                                {
                                    children: [
                                        {
                                            detail: 0,
                                            format: 0,
                                            mode: "normal",
                                            style: "",
                                            text: value,
                                            type: "text",
                                            version: 1
                                        }
                                    ],
                                    direction: "ltr",
                                    format: "",
                                    indent: 0,
                                    type: "paragraph",
                                    version: 1
                                }
                            ],
                            direction: "ltr",
                            format: "",
                            indent: 0,
                            type: "root",
                            version: 1
                        }
                    })));
                }
            }
        })["InlineEditorField[handleRevert]"];
        $[23] = storageKey;
        $[24] = value;
        $[25] = t11;
    } else {
        t11 = $[25];
    }
    const handleRevert = t11;
    const t12 = multiline ? "2.5rem" : "1.5rem";
    const t13 = multiline ? "2.5rem" : "1.5rem";
    const t14 = isDraft ? "warning.main" : "divider";
    const t15 = isDraft ? "warning.50" : "background.paper";
    let t16;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            borderColor: "primary.main",
            boxShadow: "0 0 0 2px rgba(25, 118, 210, 0.2)"
        };
        $[26] = t16;
    } else {
        t16 = $[26];
    }
    let t17;
    if ($[27] !== t13 || $[28] !== t14 || $[29] !== t15) {
        t17 = {
            outline: "none",
            minHeight: t13,
            cursor: "text",
            padding: "4px 8px",
            border: "1px solid",
            borderColor: t14,
            borderRadius: "4px",
            backgroundColor: t15,
            "&:focus-within": t16
        };
        $[27] = t13;
        $[28] = t14;
        $[29] = t15;
        $[30] = t17;
    } else {
        t17 = $[30];
    }
    let t18;
    if ($[31] !== t12 || $[32] !== t17) {
        t18 = {
            minHeight: t12,
            position: "relative",
            "& .inline-editor": t17
        };
        $[31] = t12;
        $[32] = t17;
        $[33] = t18;
    } else {
        t18 = $[33];
    }
    let t19;
    if ($[34] !== label) {
        t19 = label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            sx: {
                mb: 0.5,
                display: "block"
            },
            children: label
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 601,
            columnNumber: 20
        }, this);
        $[34] = label;
        $[35] = t19;
    } else {
        t19 = $[35];
    }
    const t20 = label || "File metadata field";
    const t21 = multiline ? "vertical" : "none";
    const t22 = multiline ? "2.5rem" : "1.5rem";
    const t23 = multiline ? "10rem" : "1.5rem";
    const t24 = multiline ? "auto" : "hidden";
    let t25;
    if ($[36] !== t21 || $[37] !== t22 || $[38] !== t23 || $[39] !== t24) {
        t25 = {
            fontSize: "0.875rem",
            lineHeight: "1.4",
            resize: t21,
            minHeight: t22,
            maxHeight: t23,
            overflow: t24
        };
        $[36] = t21;
        $[37] = t22;
        $[38] = t23;
        $[39] = t24;
        $[40] = t25;
    } else {
        t25 = $[40];
    }
    let t26;
    if ($[41] !== t20 || $[42] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentEditable"], {
            className: "inline-editor",
            "aria-label": t20,
            style: t25
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 635,
            columnNumber: 11
        }, this);
        $[41] = t20;
        $[42] = t25;
        $[43] = t26;
    } else {
        t26 = $[43];
    }
    const t27 = multiline ? "8px" : "6px";
    let t28;
    if ($[44] !== t27) {
        t28 = {
            position: "absolute",
            top: t27,
            left: "12px",
            color: "var(--mui-palette-text-disabled, #999)",
            fontSize: "0.875rem",
            pointerEvents: "none"
        };
        $[44] = t27;
        $[45] = t28;
    } else {
        t28 = $[45];
    }
    let t29;
    if ($[46] !== placeholder || $[47] !== t28) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: t28,
            children: placeholder
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 660,
            columnNumber: 11
        }, this);
        $[46] = placeholder;
        $[47] = t28;
        $[48] = t29;
    } else {
        t29 = $[48];
    }
    let t30;
    if ($[49] !== t26 || $[50] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalRichTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RichTextPlugin"], {
            contentEditable: t26,
            placeholder: t29,
            ErrorBoundary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalErrorBoundary"]
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 669,
            columnNumber: 11
        }, this);
        $[49] = t26;
        $[50] = t29;
        $[51] = t30;
    } else {
        t30 = $[51];
    }
    let t31;
    if ($[52] !== handleChange) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OnChangePlugin"], {
            onChange: handleChange
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 678,
            columnNumber: 11
        }, this);
        $[52] = handleChange;
        $[53] = t31;
    } else {
        t31 = $[53];
    }
    let t32;
    if ($[54] === Symbol.for("react.memo_cache_sentinel")) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HistoryPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 686,
            columnNumber: 11
        }, this);
        $[54] = t32;
    } else {
        t32 = $[54];
    }
    let t33;
    if ($[55] !== initialConfig || $[56] !== t30 || $[57] !== t31) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalComposer"], {
            initialConfig: initialConfig,
            children: [
                t30,
                t31,
                t32
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 693,
            columnNumber: 11
        }, this);
        $[55] = initialConfig;
        $[56] = t30;
        $[57] = t31;
        $[58] = t33;
    } else {
        t33 = $[58];
    }
    let t34;
    if ($[59] !== handleRevert || $[60] !== handleSaveNow || $[61] !== isDraft) {
        t34 = isDraft && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                mt: 1,
                display: "flex",
                gap: 1,
                alignItems: "center"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "caption",
                    color: "warning.main",
                    children: t("fileManager.draftChanges")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 708,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    size: "small",
                    variant: "outlined",
                    color: "primary",
                    onClick: handleSaveNow,
                    sx: {
                        minWidth: "auto",
                        px: 1
                    },
                    children: t("fileManager.save")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 708,
                    columnNumber: 103
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    size: "small",
                    variant: "text",
                    color: "error",
                    onClick: handleRevert,
                    sx: {
                        minWidth: "auto",
                        px: 1
                    },
                    children: t("fileManager.revert")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 711,
                    columnNumber: 42
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 703,
            columnNumber: 22
        }, this);
        $[59] = handleRevert;
        $[60] = handleSaveNow;
        $[61] = isDraft;
        $[62] = t34;
    } else {
        t34 = $[62];
    }
    let t35;
    if ($[63] !== t18 || $[64] !== t19 || $[65] !== t33 || $[66] !== t34) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t18,
            children: [
                t19,
                t33,
                t34
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 724,
            columnNumber: 11
        }, this);
        $[63] = t18;
        $[64] = t19;
        $[65] = t33;
        $[66] = t34;
        $[67] = t35;
    } else {
        t35 = $[67];
    }
    return t35;
}
_s(InlineEditorField, "rA9vAfIjMsNZqmBGife/faMw3rM=");
_c = InlineEditorField;
// =============================================================================
// ExpandedFileContent - Display extracted content from embeddings and analysis
// =============================================================================
// =============================================================================
// FileNameField - Simple contentEditable field for filename editing
// =============================================================================
function _temp(error) {
    return console.error("Lexical error:", error);
}
function FileNameField(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(24);
    if ($[0] !== "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab") {
        for(let $i = 0; $i < 24; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab";
    }
    const { value, fileId, onSave } = t0;
    const t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.files");
    const [localValue, setLocalValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(value);
    const editableRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    let t11;
    let t2;
    if ($[1] !== value) {
        t11 = ({
            "FileNameField[useEffect()]": ()=>{
                setLocalValue(value);
                if (editableRef.current) {
                    editableRef.current.textContent = value;
                }
            }
        })["FileNameField[useEffect()]"];
        t2 = [
            value
        ];
        $[1] = value;
        $[2] = t11;
        $[3] = t2;
    } else {
        t11 = $[2];
        t2 = $[3];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t11, t2);
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "FileNameField[handleInput]": (e)=>{
                const newValue = e.target.textContent;
                setLocalValue(newValue);
            }
        })["FileNameField[handleInput]"];
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const handleInput = t3;
    let t4;
    if ($[5] !== fileId || $[6] !== localValue || $[7] !== onSave || $[8] !== value) {
        t4 = ({
            "FileNameField[handleSave]": ()=>{
                if (onSave && localValue !== value && localValue.trim()) {
                    onSave(fileId, localValue);
                }
            }
        })["FileNameField[handleSave]"];
        $[5] = fileId;
        $[6] = localValue;
        $[7] = onSave;
        $[8] = value;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    const handleSave = t4;
    let t5;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "FileNameField[handleClick]": (e_0)=>{
                e_0.stopPropagation();
                if (editableRef.current) {
                    editableRef.current.focus();
                    const text = editableRef.current.textContent;
                    const lastDotIndex = text.lastIndexOf(".");
                    if (lastDotIndex > 0) {
                        const range = document.createRange();
                        const sel = window.getSelection();
                        const textNode = editableRef.current.firstChild;
                        if (textNode && textNode.nodeType === Node.TEXT_NODE) {
                            range.setStart(textNode, 0);
                            range.setEnd(textNode, lastDotIndex);
                            sel.removeAllRanges();
                            sel.addRange(range);
                        }
                    } else {
                        const range_0 = document.createRange();
                        const sel_0 = window.getSelection();
                        range_0.selectNodeContents(editableRef.current);
                        sel_0.removeAllRanges();
                        sel_0.addRange(range_0);
                    }
                }
            }
        })["FileNameField[handleClick]"];
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    const handleClick = t5;
    let t6;
    if ($[11] !== handleSave || $[12] !== value) {
        t6 = ({
            "FileNameField[handleKeyDown]": (e_1)=>{
                e_1.stopPropagation();
                if (e_1.key === "Enter") {
                    e_1.preventDefault();
                    handleSave();
                    e_1.target.blur();
                } else {
                    if (e_1.key === "Escape") {
                        e_1.preventDefault();
                        setLocalValue(value);
                        if (editableRef.current) {
                            editableRef.current.textContent = value;
                        }
                        e_1.target.blur();
                    }
                }
            }
        })["FileNameField[handleKeyDown]"];
        $[11] = handleSave;
        $[12] = value;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    const handleKeyDown = t6;
    let t7;
    if ($[14] !== handleSave) {
        t7 = ({
            "FileNameField[handleBlur]": ()=>{
                handleSave();
            }
        })["FileNameField[handleBlur]"];
        $[14] = handleSave;
        $[15] = t7;
    } else {
        t7 = $[15];
    }
    const handleBlur = t7;
    let t8;
    if ($[16] !== t1) {
        t8 = t1("fileMetadataComponent.filename");
        $[16] = t1;
        $[17] = t8;
    } else {
        t8 = $[17];
    }
    let t9;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            outline: "none",
            cursor: "text",
            fontSize: "0.875rem",
            minHeight: "1.2rem",
            "&:focus": {
                backgroundColor: "action.hover"
            }
        };
        $[18] = t9;
    } else {
        t9 = $[18];
    }
    let t10;
    if ($[19] !== handleBlur || $[20] !== handleKeyDown || $[21] !== t8 || $[22] !== value) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            ref: editableRef,
            contentEditable: true,
            suppressContentEditableWarning: true,
            "aria-label": t8,
            onInput: handleInput,
            onClick: handleClick,
            onKeyDown: handleKeyDown,
            onBlur: handleBlur,
            sx: t9,
            children: value
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 913,
            columnNumber: 11
        }, this);
        $[19] = handleBlur;
        $[20] = handleKeyDown;
        $[21] = t8;
        $[22] = value;
        $[23] = t10;
    } else {
        t10 = $[23];
    }
    return t10;
}
_s1(FileNameField, "WhkLUGA+3YeSOzjObDTamtRG42E=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c1 = FileNameField;
// =============================================================================
// ExpandedFileContent - Display extracted content from embeddings and analysis
// =============================================================================
// Metadata Editor Component for editing file properties
function MetadataEditor({ file, onUpdate, onClose }) {
    _s2();
    const t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.files");
    const { bumpFileVersion } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [editing, setEditing] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [formData, setFormData] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        name: file.name || "",
        description: file.description || "",
        prompt: file.prompt || "",
        model: file.model || "",
        variant: file.variant || ""
    });
    const handleSave = async ()=>{
        const versionCtrl = file._version != null ? bumpFileVersion(file.id, file._version) : null;
        try {
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const { data: updatedFile, errors } = await client.models.File.update({
                id: file.id,
                name: formData.name,
                description: formData.description,
                prompt: formData.prompt,
                model: formData.model,
                variant: formData.variant,
                ...file._version != null && {
                    _version: file._version
                }
            });
            if (errors?.length) {
                versionCtrl?.rollback();
            } else {
                versionCtrl?.confirm(updatedFile?._version);
            }
            onUpdate?.(updatedFile);
            setEditing(false);
        } catch (error) {
            console.error("Error updating file:", error);
            versionCtrl?.rollback();
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            p: 2,
            backgroundColor: "action.hover",
            borderRadius: 1,
            mt: 1
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    mb: 2
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "h6",
                        children: t1("fileManager2.metadataEditor.heading")
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 989,
                        columnNumber: 9
                    }, this),
                    !editing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                        size: "small",
                        onClick: ()=>setEditing(true),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 993,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 992,
                        columnNumber: 22
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 983,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    flexDirection: "column",
                    gap: 2
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                        label: t1("fileManager2.metadataEditor.nameLabel"),
                        value: formData.name,
                        onChange: (e)=>setFormData({
                                ...formData,
                                name: e.target.value
                            }),
                        disabled: !editing,
                        size: "small",
                        fullWidth: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 1002,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                        label: t1("fileManager2.metadataEditor.descriptionLabel"),
                        value: formData.description,
                        onChange: (e_0)=>setFormData({
                                ...formData,
                                description: e_0.target.value
                            }),
                        disabled: !editing,
                        multiline: true,
                        rows: 2,
                        size: "small",
                        fullWidth: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 1006,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                        label: t1("fileManager2.metadataEditor.promptLabel"),
                        value: formData.prompt,
                        onChange: (e_1)=>setFormData({
                                ...formData,
                                prompt: e_1.target.value
                            }),
                        disabled: !editing,
                        multiline: true,
                        rows: 2,
                        size: "small",
                        fullWidth: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 1010,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            display: "flex",
                            gap: 1
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                label: t1("fileManager2.metadataEditor.modelLabel"),
                                value: formData.model,
                                onChange: (e_2)=>setFormData({
                                        ...formData,
                                        model: e_2.target.value
                                    }),
                                disabled: !editing,
                                size: "small",
                                sx: {
                                    flex: 1
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1018,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                label: t1("fileManager2.metadataEditor.variantLabel"),
                                value: formData.variant,
                                onChange: (e_3)=>setFormData({
                                        ...formData,
                                        variant: e_3.target.value
                                    }),
                                disabled: !editing,
                                size: "small",
                                sx: {
                                    flex: 1
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1024,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 1014,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            pt: 2,
                            borderTop: 1,
                            borderColor: "divider"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "caption",
                                color: "text.secondary",
                                display: "block",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: [
                                            t1("fileManager2.metadataEditor.typeLabel"),
                                            ":"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1039,
                                        columnNumber: 13
                                    }, this),
                                    " ",
                                    file.mimeType
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1038,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "caption",
                                color: "text.secondary",
                                display: "block",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: [
                                            t1("fileManager2.metadataEditor.sizeLabel"),
                                            ":"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1043,
                                        columnNumber: 13
                                    }, this),
                                    " ",
                                    file.size ? `${(file.size / 1000).toFixed(2)} KB` : t1("fileManager2.metadataEditor.unknown")
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1042,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "caption",
                                color: "text.secondary",
                                display: "block",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: [
                                            t1("fileManager2.metadataEditor.pathLabel"),
                                            ":"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1047,
                                        columnNumber: 13
                                    }, this),
                                    " ",
                                    file.path
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1046,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "caption",
                                color: "text.secondary",
                                display: "block",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: [
                                            t1("fileManager2.metadataEditor.protectionLevelLabel"),
                                            ":"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1051,
                                        columnNumber: 13
                                    }, this),
                                    " ",
                                    file.level || "UNSET"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1050,
                                columnNumber: 11
                            }, this),
                            file.createdAt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "caption",
                                color: "text.secondary",
                                display: "block",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: [
                                            t1("fileManager2.metadataEditor.createdLabel"),
                                            ":"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1057,
                                        columnNumber: 15
                                    }, this),
                                    " ",
                                    new Date(file.createdAt).toLocaleString()
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1056,
                                columnNumber: 30
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 1033,
                        columnNumber: 9
                    }, this),
                    editing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            display: "flex",
                            gap: 1,
                            justifyContent: "flex-end",
                            pt: 1
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "outlined",
                                size: "small",
                                onClick: ()=>{
                                    setFormData({
                                        name: file.name || "",
                                        description: file.description || "",
                                        prompt: file.prompt || "",
                                        model: file.model || "",
                                        variant: file.variant || ""
                                    });
                                    setEditing(false);
                                },
                                children: t1("fileManager2.metadataEditor.cancelButton")
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1068,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "contained",
                                size: "small",
                                onClick: handleSave,
                                children: t1("fileManager2.metadataEditor.saveButton")
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1080,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 1062,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 997,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
        lineNumber: 977,
        columnNumber: 10
    }, this);
}
_s2(MetadataEditor, "LqlJN9IzjjLl6F2EJW9VVKueMSU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c2 = MetadataEditor;
const ExpandedFileContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(_s3(function ExpandedFileContent(t0) {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(44);
    if ($[0] !== "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab") {
        for(let $i = 0; $i < 44; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab";
    }
    const { file, parsedContent, search, editor } = t0;
    const t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.files");
    const [activeTab, setActiveTab] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(0);
    let T0;
    let highlightText;
    let isDocument;
    let metadata;
    let t11;
    let t2;
    if ($[1] !== file.metadata || $[2] !== file.mimeType || $[3] !== search || $[4] !== t1) {
        metadata = file.metadata ? (()=>{
            ;
            try {
                return JSON.parse(file.metadata);
            } catch (t3) {
                return null;
            }
        })() : null;
        let t4;
        if ($[11] !== search) {
            t4 = ({
                "ExpandedFileContent[highlightText]": (text)=>{
                    if (!search || !text) {
                        return text;
                    }
                    return highlightMatches(text, search);
                }
            })["ExpandedFileContent[highlightText]"];
            $[11] = search;
            $[12] = t4;
        } else {
            t4 = $[12];
        }
        highlightText = t4;
        isDocument = file.mimeType === "application/pdf" || file.mimeType === "text/plain" || file.mimeType === "text/markdown";
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"];
        if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
            t11 = {
                p: 2
            };
            $[13] = t11;
        } else {
            t11 = $[13];
        }
        t2 = metadata && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "h6",
                    gutterBottom: true,
                    children: t1("fileManager2.expandedContent.extractedContentHeading")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 1144,
                    columnNumber: 27
                }, this),
                metadata.analysis?.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        mb: 2
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "subtitle2",
                            color: "primary",
                            children: t1("fileManager2.expandedContent.descriptionLabel")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1146,
                            columnNumber: 10
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            children: highlightText(metadata.analysis.description)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1146,
                            columnNumber: 123
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 1144,
                    columnNumber: 179
                }, this),
                metadata.analysis?.transcription && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        mb: 2
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "subtitle2",
                            color: "primary",
                            children: t1("fileManager2.expandedContent.transcriptionLabel")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1148,
                            columnNumber: 10
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            children: highlightText(metadata.analysis.transcription)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1148,
                            columnNumber: 125
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 1146,
                    columnNumber: 254
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1144,
            columnNumber: 22
        }, this);
        $[1] = file.metadata;
        $[2] = file.mimeType;
        $[3] = search;
        $[4] = t1;
        $[5] = T0;
        $[6] = highlightText;
        $[7] = isDocument;
        $[8] = metadata;
        $[9] = t11;
        $[10] = t2;
    } else {
        T0 = $[5];
        highlightText = $[6];
        isDocument = $[7];
        metadata = $[8];
        t11 = $[9];
        t2 = $[10];
    }
    let t3;
    if ($[14] !== activeTab || $[15] !== editor?.__unit?.id || $[16] !== file.documentID || $[17] !== file.id || $[18] !== highlightText || $[19] !== isDocument || $[20] !== parsedContent || $[21] !== t1) {
        t3 = isDocument && parsedContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                position: "relative",
                zIndex: 1,
                mx: -2
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__["Tabs"], {
                    value: activeTab,
                    scrollButtons: "auto",
                    variant: "scrollable",
                    onChange: {
                        "ExpandedFileContent[<Tabs>.onChange]": (e_0, newValue)=>setActiveTab(newValue)
                    }["ExpandedFileContent[<Tabs>.onChange]"],
                    sx: {
                        position: "relative",
                        zIndex: 2,
                        backgroundColor: "background.paper",
                        borderBottom: 1,
                        borderColor: "divider"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                            title: t1("fileMetadataComponent.vocabulary", "Vocabulary"),
                            arrow: true,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MenuBook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 1181,
                                    columnNumber: 103
                                }, this),
                                label: `(${parsedContent.vocabularyJSON.length})`,
                                iconPosition: "start"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1181,
                                columnNumber: 92
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1181,
                            columnNumber: 10
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                            title: t1("fileMetadataComponent.questions", "Questions"),
                            arrow: true,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Quiz$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 1181,
                                    columnNumber: 296
                                }, this),
                                label: `(${parsedContent.questionsJSON.length})`,
                                iconPosition: "start"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1181,
                                columnNumber: 285
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1181,
                            columnNumber: 205
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                            title: t1("fileMetadataComponent.summaries", "Summaries"),
                            arrow: true,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Summarize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 1181,
                                    columnNumber: 484
                                }, this),
                                label: `(${parsedContent.summariesJSON.length})`,
                                iconPosition: "start"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1181,
                                columnNumber: 473
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1181,
                            columnNumber: 393
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                            title: t1("fileMetadataComponent.objectives", "Objectives"),
                            arrow: true,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Flag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 1181,
                                    columnNumber: 679
                                }, this),
                                label: `(${parsedContent.objectivesJSON.length})`,
                                iconPosition: "start"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1181,
                                columnNumber: 668
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1181,
                            columnNumber: 586
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                            title: t1("fileMetadataComponent.concepts", "Concepts"),
                            arrow: true,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lightbulb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 1181,
                                    columnNumber: 866
                                }, this),
                                label: `(${parsedContent.conceptsJSON.length})`,
                                iconPosition: "start"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1181,
                                columnNumber: 855
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1181,
                            columnNumber: 777
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 1173,
                    columnNumber: 8
                }, this),
                activeTab === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        pt: 2,
                        px: 2
                    },
                    children: parsedContent.vocabularyJSON.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                severity: "info",
                                sx: {
                                    mb: 2
                                },
                                children: t1("fileManager2.expandedContent.reviewVocabularyMessage")
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1184,
                                columnNumber: 55
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$SuggestedContent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SuggestedVocabulary"], {
                                documentId: file.documentID,
                                fileId: file.id,
                                unitId: editor?.__unit?.id,
                                enableInlineEditing: true,
                                onImport: _ExpandedFileContentSuggestedVocabularyOnImport
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1186,
                                columnNumber: 81
                            }, this)
                        ]
                    }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "text.secondary",
                        sx: {
                            mt: 2,
                            textAlign: "center"
                        },
                        children: t1("fileManager2.expandedContent.noVocabularyExtracted")
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 1186,
                        columnNumber: 270
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 1181,
                    columnNumber: 994
                }, this),
                activeTab === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        pt: 2,
                        px: 2
                    },
                    children: parsedContent.questionsJSON.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                severity: "info",
                                sx: {
                                    mb: 2
                                },
                                children: t1("fileManager2.expandedContent.reviewQuestionsMessage")
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1192,
                                columnNumber: 54
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$SuggestedContent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SuggestedQuestions"], {
                                documentId: file.documentID,
                                fileId: file.id,
                                unitId: editor?.__unit?.id,
                                enableInlineEditing: true,
                                onImport: _ExpandedFileContentSuggestedQuestionsOnImport
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1194,
                                columnNumber: 80
                            }, this)
                        ]
                    }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "text.secondary",
                        sx: {
                            mt: 2,
                            textAlign: "center"
                        },
                        children: t1("fileManager2.expandedContent.noQuestionsExtracted")
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 1194,
                        columnNumber: 267
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 1189,
                    columnNumber: 110
                }, this),
                activeTab === 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        pt: 2,
                        px: 2
                    },
                    children: parsedContent.summariesJSON.length > 0 ? parsedContent.summariesJSON.map({
                        "ExpandedFileContent[parsedContent.summariesJSON.map()]": (item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    mb: 2,
                                    p: 2,
                                    border: 2,
                                    borderColor: "primary.main",
                                    borderRadius: 1,
                                    backgroundColor: "primary.light",
                                    opacity: 0.9
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "subtitle2",
                                        color: "primary.dark",
                                        sx: {
                                            fontWeight: "bold",
                                            mb: 1
                                        },
                                        children: highlightText(item.title)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1209,
                                        columnNumber: 14
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "body2",
                                        sx: {
                                            mb: 1,
                                            color: "text.primary"
                                        },
                                        children: highlightText(item.content)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1212,
                                        columnNumber: 56
                                    }, this),
                                    item.page_range && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                        label: `Pages: ${item.page_range}`,
                                        size: "small",
                                        color: "primary",
                                        variant: "outlined"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1215,
                                        columnNumber: 78
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1201,
                                columnNumber: 86
                            }, this)
                    }["ExpandedFileContent[parsedContent.summariesJSON.map()]"]) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "text.secondary",
                        sx: {
                            mt: 2,
                            textAlign: "center"
                        },
                        children: t1("fileManager2.expandedContent.noSummariesExtracted")
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 1216,
                        columnNumber: 72
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 1197,
                    columnNumber: 109
                }, this),
                activeTab === 3 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        pt: 2,
                        px: 2
                    },
                    children: parsedContent.objectivesJSON.length > 0 ? parsedContent.objectivesJSON.map({
                        "ExpandedFileContent[parsedContent.objectivesJSON.map()]": (item_0, index_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    mb: 2,
                                    p: 2,
                                    border: 2,
                                    borderColor: "secondary.main",
                                    borderRadius: 1,
                                    backgroundColor: "secondary.light",
                                    opacity: 0.9
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "body2",
                                        sx: {
                                            mb: 1,
                                            fontWeight: 500
                                        },
                                        children: highlightText(item_0.objective)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1231,
                                        columnNumber: 14
                                    }, this),
                                    item_0.bloom_level && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                        label: `Bloom Level: ${item_0.bloom_level}`,
                                        size: "small",
                                        color: "secondary",
                                        sx: {
                                            fontSize: "0.75rem",
                                            fontWeight: 600
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1234,
                                        columnNumber: 85
                                    }, this)
                                ]
                            }, index_0, true, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1223,
                                columnNumber: 91
                            }, this)
                    }["ExpandedFileContent[parsedContent.objectivesJSON.map()]"]) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "text.secondary",
                        sx: {
                            mt: 2,
                            textAlign: "center"
                        },
                        children: t1("fileManager2.expandedContent.noObjectivesExtracted")
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 1238,
                        columnNumber: 73
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 1219,
                    columnNumber: 109
                }, this),
                activeTab === 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        pt: 2,
                        px: 2
                    },
                    children: parsedContent.conceptsJSON.length > 0 ? parsedContent.conceptsJSON.map({
                        "ExpandedFileContent[parsedContent.conceptsJSON.map()]": (item_1, index_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    mb: 2,
                                    p: 2,
                                    border: 2,
                                    borderColor: "success.main",
                                    borderRadius: 1,
                                    backgroundColor: "success.light",
                                    opacity: 0.9
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "subtitle2",
                                        color: "success.dark",
                                        sx: {
                                            fontWeight: "bold",
                                            mb: 1
                                        },
                                        children: highlightText(item_1.concept)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1253,
                                        columnNumber: 14
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "body2",
                                        sx: {
                                            mb: 1
                                        },
                                        children: highlightText(item_1.description)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1256,
                                        columnNumber: 60
                                    }, this),
                                    item_1.related_vocabulary && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                        sx: {
                                            mt: 1
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                            label: `Related: ${highlightText(item_1.related_vocabulary)}`,
                                            size: "small",
                                            color: "success",
                                            variant: "outlined"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 1260,
                                            columnNumber: 16
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 1258,
                                        columnNumber: 94
                                    }, this)
                                ]
                            }, index_1, true, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 1245,
                                columnNumber: 89
                            }, this)
                    }["ExpandedFileContent[parsedContent.conceptsJSON.map()]"]) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "text.secondary",
                        sx: {
                            mt: 2,
                            textAlign: "center"
                        },
                        children: t1("fileManager2.expandedContent.noConceptsExtracted")
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 1261,
                        columnNumber: 71
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 1241,
                    columnNumber: 110
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1169,
            columnNumber: 41
        }, this);
        $[14] = activeTab;
        $[15] = editor?.__unit?.id;
        $[16] = file.documentID;
        $[17] = file.id;
        $[18] = highlightText;
        $[19] = isDocument;
        $[20] = parsedContent;
        $[21] = t1;
        $[22] = t3;
    } else {
        t3 = $[22];
    }
    let t4;
    if ($[23] !== file.duration || $[24] !== file.mimeType || $[25] !== file.path || $[26] !== file.size || $[27] !== isDocument || $[28] !== metadata || $[29] !== parsedContent || $[30] !== t1) {
        t4 = !metadata && !parsedContent && !isDocument && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "subtitle2",
                    color: "text.secondary",
                    gutterBottom: true,
                    children: t1("fileManager2.expandedContent.fileInfoHeading", "File Info")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 1279,
                    columnNumber: 61
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: "grid",
                        gridTemplateColumns: "auto 1fr",
                        gap: 1,
                        alignItems: "baseline"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "text.secondary",
                            children: t1("fileMetadataComponent.type", "Type:")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1284,
                            columnNumber: 10
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            children: file.mimeType || t1("fileMetadataComponent.unknown", "Unknown")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1284,
                            columnNumber: 116
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "text.secondary",
                            children: t1("fileMetadataComponent.path", "Path:")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1284,
                            columnNumber: 221
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            sx: {
                                wordBreak: "break-all"
                            },
                            children: file.path
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 1284,
                            columnNumber: 327
                        }, this),
                        file.size != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    color: "text.secondary",
                                    children: t1("fileManager2.expandedContent.sizeLabel", "Size:")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 1286,
                                    columnNumber: 60
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    children: [
                                        (file.size / 1024).toFixed(1),
                                        " KB"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 1286,
                                    columnNumber: 178
                                }, this)
                            ]
                        }, void 0, true),
                        file.duration != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    color: "text.secondary",
                                    children: t1("fileManager2.expandedContent.durationLabel", "Duration:")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 1286,
                                    columnNumber: 285
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    children: [
                                        file.duration,
                                        "s"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 1286,
                                    columnNumber: 411
                                }, this)
                            ]
                        }, void 0, true)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 1279,
                    columnNumber: 213
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1279,
            columnNumber: 56
        }, this);
        $[23] = file.duration;
        $[24] = file.mimeType;
        $[25] = file.path;
        $[26] = file.size;
        $[27] = isDocument;
        $[28] = metadata;
        $[29] = parsedContent;
        $[30] = t1;
        $[31] = t4;
    } else {
        t4 = $[31];
    }
    let t5;
    if ($[32] !== isDocument || $[33] !== metadata || $[34] !== parsedContent || $[35] !== t1) {
        t5 = !metadata && !parsedContent && isDocument && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            sx: {
                textAlign: "center"
            },
            children: t1("fileManager2.expandedContent.noContentAvailable")
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1301,
            columnNumber: 55
        }, this);
        $[32] = isDocument;
        $[33] = metadata;
        $[34] = parsedContent;
        $[35] = t1;
        $[36] = t5;
    } else {
        t5 = $[36];
    }
    let t6;
    if ($[37] !== T0 || $[38] !== t11 || $[39] !== t2 || $[40] !== t3 || $[41] !== t4 || $[42] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            sx: t11,
            children: [
                t2,
                t3,
                t4,
                t5
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1314,
            columnNumber: 10
        }, this);
        $[37] = T0;
        $[38] = t11;
        $[39] = t2;
        $[40] = t3;
        $[41] = t4;
        $[42] = t5;
        $[43] = t6;
    } else {
        t6 = $[43];
    }
    return t6;
}, "K8hwUQmmeWr35ALovJWVvI9Ag/o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
}));
_c3 = ExpandedFileContent;
function NewImageFileForm(t0) {
    _s4();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(60);
    if ($[0] !== "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab") {
        for(let $i = 0; $i < 60; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab";
    }
    const { open } = t0;
    const t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.files");
    const tEditorAi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.ai");
    const [newDescription, setNewDescription] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [presignedUrl, setPresignedUrl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [isOpen, setIsOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [working, setWorking] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [previewMessage, setPreviewMessage] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const imageRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    let t11;
    if ($[1] !== presignedUrl || $[2] !== t1) {
        t11 = ({
            "NewImageFileForm[useEffect()]": ()=>{
                const fetchImage = {
                    "NewImageFileForm[useEffect() > fetchImage]": async ()=>{
                        ;
                        try {
                            console.log("presignedUrl!!!", presignedUrl);
                            const response = await fetch(presignedUrl);
                            console.log("response!!!", response);
                            const blob = await response.blob();
                            const url = URL.createObjectURL(blob);
                            console.log("url!!!", url);
                            imageRef.current.src = url;
                            setWorking(false);
                            setNewDescription("");
                            setPreviewMessage(t1("fileManager2.generators.successfullyGeneratedImage"));
                        } catch (t2) {
                            const error = t2;
                            console.error(error);
                        }
                    }
                }["NewImageFileForm[useEffect() > fetchImage]"];
                if (!presignedUrl) {
                    return;
                }
                fetchImage();
            }
        })["NewImageFileForm[useEffect()]"];
        $[1] = presignedUrl;
        $[2] = t1;
        $[3] = t11;
    } else {
        t11 = $[3];
    }
    let t2;
    if ($[4] !== presignedUrl) {
        t2 = [
            presignedUrl
        ];
        $[4] = presignedUrl;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t11, t2);
    let t3;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            width: "100%"
        };
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "NewImageFileForm[<TextareaAutosize>.onChange]": (e)=>{
                setNewDescription(e.target.value);
            }
        })["NewImageFileForm[<TextareaAutosize>.onChange]"];
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] !== t1) {
        t5 = t1("fileManager2.generators.imagePromptPlaceholder");
        $[8] = t1;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            width: "100%",
            wordWrap: "break-word",
            minHeight: "3rem"
        };
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    let t7;
    if ($[11] !== newDescription || $[12] !== t5) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            minRows: 3,
            value: newDescription,
            onChange: t4,
            onClick: _NewImageFileFormTextareaAutosizeOnClick,
            placeholder: t5,
            ref: _NewImageFileFormTextareaAutosizeRef,
            style: t6
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1436,
            columnNumber: 10
        }, this);
        $[11] = newDescription;
        $[12] = t5;
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[14] !== tEditorAi) {
        t8 = tEditorAi("unifiedGenerateModal.generate");
        $[14] = tEditorAi;
        $[15] = t8;
    } else {
        t8 = $[15];
    }
    let t9;
    if ($[16] !== newDescription || $[17] !== t1) {
        t9 = ({
            "NewImageFileForm[<Button>.onClick]": async ()=>{
                setIsOpen(true);
                setWorking(true);
                setPreviewMessage(t1("fileManager2.generators.generatingImage"));
                const { identityId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAuthSession"])();
                const imageResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$7d3f15__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateImage"])({
                    phrase: newDescription,
                    model: "dall-e-3"
                });
                const path = imageResult.path;
                if (path) {
                    console.log("s3Key", path, identityId);
                    const _presignedUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(path, "protected", identityId);
                    console.log("_presignedUrl", _presignedUrl);
                    setPresignedUrl(_presignedUrl);
                } else {
                    console.error("Image generation failed - no path returned");
                    setPreviewMessage(t1("fileManager2.generators.errorGeneratingImage"));
                    setWorking(false);
                }
            }
        })["NewImageFileForm[<Button>.onClick]"];
        $[16] = newDescription;
        $[17] = t1;
        $[18] = t9;
    } else {
        t9 = $[18];
    }
    let t10;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            width: "100%",
            margin: "1rem"
        };
        $[19] = t10;
    } else {
        t10 = $[19];
    }
    let t111;
    if ($[20] !== t1) {
        t111 = t1("fileManager.create");
        $[20] = t1;
        $[21] = t111;
    } else {
        t111 = $[21];
    }
    let t12;
    if ($[22] !== t111 || $[23] !== t8 || $[24] !== t9) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            variant: "outlined",
            "aria-label": t8,
            onClick: t9,
            style: t10,
            children: t111
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1504,
            columnNumber: 11
        }, this);
        $[22] = t111;
        $[23] = t8;
        $[24] = t9;
        $[25] = t12;
    } else {
        t12 = $[25];
    }
    let t13;
    if ($[26] !== t12 || $[27] !== t7) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            style: t3,
            children: [
                t7,
                t12
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1514,
            columnNumber: 11
        }, this);
        $[26] = t12;
        $[27] = t7;
        $[28] = t13;
    } else {
        t13 = $[28];
    }
    let t14;
    if ($[29] !== open || $[30] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__["Collapse"], {
            in: open,
            children: t13
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1523,
            columnNumber: 11
        }, this);
        $[29] = open;
        $[30] = t13;
        $[31] = t14;
    } else {
        t14 = $[31];
    }
    let t15;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = ({
            "NewImageFileForm[<Modal>.onClose]": ()=>{
                setWorking(false);
                setPreviewMessage("");
                setIsOpen(false);
            }
        })["NewImageFileForm[<Modal>.onClose]"];
        $[32] = t15;
    } else {
        t15 = $[32];
    }
    let t16;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: 400,
            bgcolor: "background.paper",
            style: {
                minWidth: "20vw",
                maxWidth: "80vw",
                minHeight: "20vw",
                maxHeight: "80vw",
                padding: "1rem"
            }
        };
        $[33] = t16;
    } else {
        t16 = $[33];
    }
    let t17;
    if ($[34] !== t1) {
        t17 = t1("fileManager.textToImagePreview");
        $[34] = t1;
        $[35] = t17;
    } else {
        t17 = $[35];
    }
    let t18;
    if ($[36] !== working) {
        t18 = working && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "rectangular",
            width: 24,
            height: 24,
            sx: {
                display: "inline-block",
                borderRadius: 1,
                verticalAlign: "middle"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1574,
            columnNumber: 22
        }, this);
        $[36] = working;
        $[37] = t18;
    } else {
        t18 = $[37];
    }
    let t19;
    if ($[38] !== t17 || $[39] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            id: "modal-text-to-image-preview",
            variant: "h6",
            component: "h2",
            children: [
                t17,
                " ",
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1586,
            columnNumber: 11
        }, this);
        $[38] = t17;
        $[39] = t18;
        $[40] = t19;
    } else {
        t19 = $[40];
    }
    let t20;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = {
            mt: 2
        };
        $[41] = t20;
    } else {
        t20 = $[41];
    }
    let t21;
    if ($[42] !== previewMessage) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            id: "modal-text-to-image-preview-description",
            sx: t20,
            children: previewMessage
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1604,
            columnNumber: 11
        }, this);
        $[42] = previewMessage;
        $[43] = t21;
    } else {
        t21 = $[43];
    }
    let t22;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            style: {
                display: "flex",
                flexDirection: "column",
                width: "100%",
                justifyContent: "space-between",
                alignItems: "center"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                style: {
                    backgroundColor: "background.paper",
                    width: "100%",
                    margin: "1rem auto"
                },
                ref: imageRef
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 1618,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1612,
            columnNumber: 11
        }, this);
        $[44] = t22;
    } else {
        t22 = $[44];
    }
    let t23;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = ({
            "NewImageFileForm[<Button>.onClick]": ()=>{
                setIsOpen(false);
            }
        })["NewImageFileForm[<Button>.onClick]"];
        $[45] = t23;
    } else {
        t23 = $[45];
    }
    let t24;
    if ($[46] !== t1) {
        t24 = t1("fileManager.close");
        $[46] = t1;
        $[47] = t24;
    } else {
        t24 = $[47];
    }
    let t25;
    if ($[48] !== t24) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            onClick: t23,
            children: t24
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1648,
            columnNumber: 11
        }, this);
        $[48] = t24;
        $[49] = t25;
    } else {
        t25 = $[49];
    }
    let t26;
    if ($[50] !== t19 || $[51] !== t21 || $[52] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
            style: t16,
            children: [
                t19,
                t21,
                t22,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1656,
            columnNumber: 11
        }, this);
        $[50] = t19;
        $[51] = t21;
        $[52] = t25;
        $[53] = t26;
    } else {
        t26 = $[53];
    }
    let t27;
    if ($[54] !== isOpen || $[55] !== t26) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
            open: isOpen,
            onClose: t15,
            "aria-labelledby": "modal-text-to-image-preview",
            "aria-describedby": "modal-text-to-image-preview-description",
            children: t26
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1666,
            columnNumber: 11
        }, this);
        $[54] = isOpen;
        $[55] = t26;
        $[56] = t27;
    } else {
        t27 = $[56];
    }
    let t28;
    if ($[57] !== t14 || $[58] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t14,
                t27
            ]
        }, void 0, true);
        $[57] = t14;
        $[58] = t27;
        $[59] = t28;
    } else {
        t28 = $[59];
    }
    return t28;
}
_s4(NewImageFileForm, "o0REdbvw3Rsa4f+3rMVRZPI1JIU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c4 = NewImageFileForm;
function _NewImageFileFormTextareaAutosizeRef(input) {
    if (input != null) {
        input.focus();
    }
}
function _NewImageFileFormTextareaAutosizeOnClick(e_0) {
    e_0.preventDefault();
    e_0.stopPropagation();
}
function NewVideoFileForm(t0) {
    _s5();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18);
    if ($[0] !== "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab") {
        for(let $i = 0; $i < 18; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab";
    }
    const { open } = t0;
    const tEditorAi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.ai");
    const [newDescription, setNewDescription] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            width: "100%"
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "NewVideoFileForm[<TextareaAutosize>.onChange]": (e)=>{
                setNewDescription(e.target.value);
            }
        })["NewVideoFileForm[<TextareaAutosize>.onChange]"];
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            width: "100%",
            wordWrap: "break-word",
            minHeight: "3rem"
        };
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    let t4;
    if ($[4] !== newDescription) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            minRows: 3,
            value: newDescription,
            onChange: t2,
            onClick: _NewVideoFileFormTextareaAutosizeOnClick,
            placeholder: "No Description",
            style: t3
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1743,
            columnNumber: 10
        }, this);
        $[4] = newDescription;
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== tEditorAi) {
        t5 = tEditorAi("unifiedGenerateModal.generate");
        $[6] = tEditorAi;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            width: "100%",
            margin: "1rem"
        };
        t7 = t("fileManager.create");
        $[8] = t6;
        $[9] = t7;
    } else {
        t6 = $[8];
        t7 = $[9];
    }
    let t8;
    if ($[10] !== t5) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            variant: "outlined",
            "aria-label": t5,
            onClick: _NewVideoFileFormButtonOnClick,
            style: t6,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1773,
            columnNumber: 10
        }, this);
        $[10] = t5;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== t4 || $[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            style: t1,
            children: [
                t4,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1781,
            columnNumber: 10
        }, this);
        $[12] = t4;
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== open || $[16] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__["Collapse"], {
            in: open,
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1790,
            columnNumber: 11
        }, this);
        $[15] = open;
        $[16] = t9;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    return t10;
}
_s5(NewVideoFileForm, "0H2zibAXsYHV8vRDBgRgV0vfsJ0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c5 = NewVideoFileForm;
function _NewVideoFileFormButtonOnClick() {}
function _NewVideoFileFormTextareaAutosizeOnClick(e_0) {
    e_0.preventDefault();
    e_0.stopPropagation();
}
function NewAudioFileForm(t0) {
    _s6();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(65);
    if ($[0] !== "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab") {
        for(let $i = 0; $i < 65; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab";
    }
    const { open } = t0;
    const t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.files");
    const tEditorAi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.ai");
    const [newDescription, setNewDescription] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [audioSrc, setAudioSrc] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [presignedUrl, setPresignedUrl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [isOpen, setIsOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [working, setWorking] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [previewMessage, setPreviewMessage] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const audioRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const canvasRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const audioContextRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const sourceRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const analyserRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createRef(null);
    let t11;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        const mainColor = typeof document !== "undefined" ? getComputedStyle(document.documentElement).getPropertyValue("--mui-palette-primary-main").trim() || "#556cd6" : "#556cd6";
        t11 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$hexToRgb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(mainColor);
        $[1] = t11;
    } else {
        t11 = $[1];
    }
    const rgbColor = t11;
    const _g = rgbColor.g;
    const _b = rgbColor.b;
    let t2;
    if ($[2] !== t1) {
        t2 = ({
            "NewAudioFileForm[useEffect()]": ()=>{
                const audio = audioRef.current;
                if (!audio) {
                    return;
                } else {
                    if (audio.srcObject) {
                        const tracks = audio.srcObject.getTracks();
                        tracks.forEach(_NewAudioFileFormUseEffectTracksForEach);
                        audio.srcObject = null;
                    }
                }
                const audioContext = audioContextRef.current || new AudioContext();
                const source = sourceRef.current || audioContext.createMediaElementSource(audio);
                const analyser = analyserRef.current || audioContext.createAnalyser();
                sourceRef.current = source;
                audioContextRef.current = audioContext;
                analyserRef.current = analyser;
                source.connect(analyser);
                analyser.connect(audioContext.destination);
                analyser.fftSize = 2048;
                analyser.smoothingTimeConstant = 0.8;
                const canvas = canvasRef.current;
                const canvasCtx = canvas.getContext("2d");
                const bufferLength = analyser.frequencyBinCount;
                const dataArray = new Uint8Array(bufferLength);
                const draw = {
                    "NewAudioFileForm[useEffect() > draw]": ()=>{
                        requestAnimationFrame(draw);
                        analyser.getByteFrequencyData(dataArray);
                        canvasCtx.fillStyle = "rgb(255, 255, 255)";
                        canvasCtx.fillRect(0, 0, canvas.width, canvas.height);
                        const barWidth = canvas.width / bufferLength * 2.5;
                        let barHeight;
                        let x = 0;
                        const max = Math.max(...dataArray);
                        canvasCtx.scale(-1, 1);
                        canvasCtx.translate(-canvas.width, 0);
                        for(let i = 0; i < bufferLength; i++){
                            barHeight = dataArray[i] / max * canvas.height / 2;
                            canvasCtx.fillStyle = `rgb(${barHeight + 100},${_g},${_b})`;
                            canvasCtx.fillRect(canvas.width - (x + barWidth / 2), canvas.height / 2 - barHeight / 2, barWidth, barHeight);
                            x = x + (barWidth + 1);
                        }
                        canvasCtx.setTransform(1, 0, 0, 1, 0, 0);
                    }
                }["NewAudioFileForm[useEffect() > draw]"];
                draw();
                audio.addEventListener("canplaythrough", {
                    "NewAudioFileForm[useEffect() > audio.addEventListener()]": ()=>{
                        console.log("canplaythrough");
                        audio.play();
                        setWorking(false);
                        setNewDescription("");
                        setPreviewMessage(t1("fileManager2.generators.successfullyGeneratedAudio"));
                    }
                }["NewAudioFileForm[useEffect() > audio.addEventListener()]"]);
            }
        })["NewAudioFileForm[useEffect()]"];
        $[2] = t1;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] !== audioSrc) {
        t3 = [
            audioSrc
        ];
        $[4] = audioSrc;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t2, t3);
    let t4;
    let t5;
    if ($[6] !== presignedUrl) {
        t4 = ({
            "NewAudioFileForm[useEffect()]": ()=>{
                const fetchAudio = {
                    "NewAudioFileForm[useEffect() > fetchAudio]": async ()=>{
                        ;
                        try {
                            console.log("presignedUrl!!!", presignedUrl);
                            const response = await fetch(presignedUrl);
                            console.log("response!!!", response);
                            const blob = await response.blob();
                            const url = URL.createObjectURL(blob);
                            console.log("url!!!", url);
                            setAudioSrc(url);
                        } catch (t6) {
                            const error = t6;
                            console.error(error);
                        }
                    }
                }["NewAudioFileForm[useEffect() > fetchAudio]"];
                fetchAudio();
            }
        })["NewAudioFileForm[useEffect()]"];
        t5 = [
            presignedUrl
        ];
        $[6] = presignedUrl;
        $[7] = t4;
        $[8] = t5;
    } else {
        t4 = $[7];
        t5 = $[8];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t4, t5);
    let t6;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            width: "100%"
        };
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = ({
            "NewAudioFileForm[<TextareaAutosize>.onChange]": (e_0)=>{
                setNewDescription(e_0.target.value);
            }
        })["NewAudioFileForm[<TextareaAutosize>.onChange]"];
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    let t8;
    if ($[11] !== t1) {
        t8 = t1("fileManager2.generators.audioPromptPlaceholder");
        $[11] = t1;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            width: "100%",
            wordWrap: "break-word",
            minHeight: "3rem"
        };
        $[13] = t9;
    } else {
        t9 = $[13];
    }
    let t10;
    if ($[14] !== newDescription || $[15] !== t8) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            minRows: 3,
            value: newDescription,
            onChange: t7,
            onClick: _NewAudioFileFormTextareaAutosizeOnClick,
            placeholder: t8,
            ref: _NewAudioFileFormTextareaAutosizeRef,
            style: t9
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 1994,
            columnNumber: 11
        }, this);
        $[14] = newDescription;
        $[15] = t8;
        $[16] = t10;
    } else {
        t10 = $[16];
    }
    let t111;
    if ($[17] !== tEditorAi) {
        t111 = tEditorAi("unifiedGenerateModal.generate");
        $[17] = tEditorAi;
        $[18] = t111;
    } else {
        t111 = $[18];
    }
    let t12;
    if ($[19] !== newDescription || $[20] !== t1) {
        t12 = ({
            "NewAudioFileForm[<Button>.onClick]": async ()=>{
                setIsOpen(true);
                setWorking(true);
                setPreviewMessage(t1("fileManager2.generators.generatingAudio"));
                const { identityId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAuthSession"])();
                const audioResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$274953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateSpeech"])({
                    phrase: newDescription,
                    voice: "shimmer",
                    model: "tts-1-hd"
                });
                const path = audioResult.path;
                if (path) {
                    console.log("s3Key", path, identityId);
                    const _presignedUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(path, "protected", identityId);
                    console.log("_presignedUrl", _presignedUrl);
                    setPresignedUrl(_presignedUrl);
                } else {
                    console.error("Audio generation failed - no path returned");
                    setPreviewMessage(t1("fileManager2.generators.errorGeneratingAudio"));
                    setWorking(false);
                }
            }
        })["NewAudioFileForm[<Button>.onClick]"];
        $[19] = newDescription;
        $[20] = t1;
        $[21] = t12;
    } else {
        t12 = $[21];
    }
    let t13;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            width: "100%",
            margin: "1rem"
        };
        $[22] = t13;
    } else {
        t13 = $[22];
    }
    let t14;
    if ($[23] !== t111 || $[24] !== t12) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            variant: "outlined",
            "aria-label": t111,
            onClick: t12,
            style: t13,
            children: "Create"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2055,
            columnNumber: 11
        }, this);
        $[23] = t111;
        $[24] = t12;
        $[25] = t14;
    } else {
        t14 = $[25];
    }
    let t15;
    if ($[26] !== t10 || $[27] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            style: t6,
            children: [
                t10,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2064,
            columnNumber: 11
        }, this);
        $[26] = t10;
        $[27] = t14;
        $[28] = t15;
    } else {
        t15 = $[28];
    }
    let t16;
    if ($[29] !== open || $[30] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__["Collapse"], {
            in: open,
            children: t15
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2073,
            columnNumber: 11
        }, this);
        $[29] = open;
        $[30] = t15;
        $[31] = t16;
    } else {
        t16 = $[31];
    }
    let t17;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = ({
            "NewAudioFileForm[<Modal>.onClose]": ()=>{
                setWorking(false);
                setPreviewMessage("");
                setIsOpen(false);
            }
        })["NewAudioFileForm[<Modal>.onClose]"];
        $[32] = t17;
    } else {
        t17 = $[32];
    }
    let t18;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = {
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: 400,
            bgcolor: "background.paper",
            p: 4,
            style: {
                minWidth: "20vw",
                maxWidth: "80vw",
                minHeight: "20vw",
                maxHeight: "80vw",
                padding: "1rem"
            }
        };
        $[33] = t18;
    } else {
        t18 = $[33];
    }
    let t19;
    if ($[34] !== t1) {
        t19 = t1("fileManager.textToSpeechPreview");
        $[34] = t1;
        $[35] = t19;
    } else {
        t19 = $[35];
    }
    let t20;
    if ($[36] !== working) {
        t20 = working && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "rectangular",
            width: 24,
            height: 24,
            sx: {
                display: "inline-block",
                borderRadius: 1,
                verticalAlign: "middle"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2125,
            columnNumber: 22
        }, this);
        $[36] = working;
        $[37] = t20;
    } else {
        t20 = $[37];
    }
    let t21;
    if ($[38] !== t19 || $[39] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            id: "modal-modal-title",
            variant: "h6",
            component: "h2",
            children: [
                t19,
                " ",
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2137,
            columnNumber: 11
        }, this);
        $[38] = t19;
        $[39] = t20;
        $[40] = t21;
    } else {
        t21 = $[40];
    }
    let t22;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = {
            mt: 2
        };
        $[41] = t22;
    } else {
        t22 = $[41];
    }
    let t23;
    if ($[42] !== previewMessage) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            id: "modal-modal-description",
            sx: t22,
            children: previewMessage
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2155,
            columnNumber: 11
        }, this);
        $[42] = previewMessage;
        $[43] = t23;
    } else {
        t23 = $[43];
    }
    let t24;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = {
            display: "flex",
            flexDirection: "column",
            width: "100%",
            justifyContent: "space-between",
            alignItems: "center"
        };
        $[44] = t24;
    } else {
        t24 = $[44];
    }
    let t25;
    if ($[45] !== audioSrc) {
        t25 = audioSrc && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            audioUrl: audioSrc,
            width: 600,
            height: 120,
            title: previewFile?.name || "Audio Preview",
            showDuration: true
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2176,
            columnNumber: 23
        }, this);
        $[45] = audioSrc;
        $[46] = t25;
    } else {
        t25 = $[46];
    }
    let t26;
    if ($[47] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            style: t24,
            children: t25
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2184,
            columnNumber: 11
        }, this);
        $[47] = t25;
        $[48] = t26;
    } else {
        t26 = $[48];
    }
    let t27;
    if ($[49] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = ({
            "NewAudioFileForm[<Button>.onClick]": ()=>{
                setIsOpen(false);
            }
        })["NewAudioFileForm[<Button>.onClick]"];
        $[49] = t27;
    } else {
        t27 = $[49];
    }
    let t28;
    if ($[50] !== t1) {
        t28 = t1("fileManager.close");
        $[50] = t1;
        $[51] = t28;
    } else {
        t28 = $[51];
    }
    let t29;
    if ($[52] !== t28) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            onClick: t27,
            children: t28
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2211,
            columnNumber: 11
        }, this);
        $[52] = t28;
        $[53] = t29;
    } else {
        t29 = $[53];
    }
    let t30;
    if ($[54] !== t21 || $[55] !== t23 || $[56] !== t26 || $[57] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
            style: t18,
            children: [
                t21,
                t23,
                t26,
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2219,
            columnNumber: 11
        }, this);
        $[54] = t21;
        $[55] = t23;
        $[56] = t26;
        $[57] = t29;
        $[58] = t30;
    } else {
        t30 = $[58];
    }
    let t31;
    if ($[59] !== isOpen || $[60] !== t30) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
            open: isOpen,
            onClose: t17,
            "aria-labelledby": "modal-text-to-speech-preview",
            "aria-describedby": "modal-text-to-speech-preview-description",
            children: t30
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2230,
            columnNumber: 11
        }, this);
        $[59] = isOpen;
        $[60] = t30;
        $[61] = t31;
    } else {
        t31 = $[61];
    }
    let t32;
    if ($[62] !== t16 || $[63] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t16,
                t31
            ]
        }, void 0, true);
        $[62] = t16;
        $[63] = t31;
        $[64] = t32;
    } else {
        t32 = $[64];
    }
    return t32;
}
_s6(NewAudioFileForm, "Ps84bgVzxSNmZeygNi54m58mIsg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c6 = NewAudioFileForm;
// =============================================================================
// Header Components for File List
// =============================================================================
function _NewAudioFileFormTextareaAutosizeRef(input) {
    if (input != null) {
        input.focus();
    }
}
function _NewAudioFileFormTextareaAutosizeOnClick(e_1) {
    e_1.preventDefault();
    e_1.stopPropagation();
}
function _NewAudioFileFormUseEffectTracksForEach(track) {
    return track.stop();
}
const ProtectionLevelHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(_c7 = function ProtectionLevelHeader(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab";
    }
    const { label, totalFiles, isExpanded: t1, onToggleExpand: t2 } = t0;
    const isExpanded = t1 === undefined ? true : t1;
    const onToggleExpand = t2 === undefined ? _temp2 : t2;
    let t3;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            position: "sticky",
            top: 0,
            height: "100%",
            minHeight: 48,
            px: 2,
            bgcolor: "primary.main",
            color: "primary.contrastText",
            display: "flex",
            alignItems: "center",
            gap: 1,
            flexShrink: 0,
            zIndex: 98,
            borderBottom: "1px solid",
            borderColor: "divider",
            cursor: "pointer",
            transition: "all 0.2s ease",
            "&:hover": {
                bgcolor: "primary.dark"
            }
        };
        $[1] = t3;
    } else {
        t3 = $[1];
    }
    let t4;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            display: "flex",
            alignItems: "center",
            transition: "transform 0.2s"
        };
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    let t5;
    if ($[3] !== isExpanded) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t4,
            children: isExpanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 2320,
                columnNumber: 37
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 2320,
                columnNumber: 58
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2320,
            columnNumber: 10
        }, this);
        $[3] = isExpanded;
        $[4] = t5;
    } else {
        t5 = $[4];
    }
    let t6;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            fontWeight: "bold",
            color: "inherit",
            fontSize: "0.875rem"
        };
        $[5] = t6;
    } else {
        t6 = $[5];
    }
    let t7;
    if ($[6] !== label) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            sx: t6,
            children: label
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2339,
            columnNumber: 10
        }, this);
        $[6] = label;
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    let t8;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            bgcolor: "rgba(255,255,255,0.2)",
            color: "primary.contrastText",
            height: 20,
            fontSize: "0.7rem",
            fontWeight: 600
        };
        $[8] = t8;
    } else {
        t8 = $[8];
    }
    let t9;
    if ($[9] !== totalFiles) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            label: totalFiles,
            size: "small",
            sx: t8
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2360,
            columnNumber: 10
        }, this);
        $[9] = totalFiles;
        $[10] = t9;
    } else {
        t9 = $[10];
    }
    let t10;
    if ($[11] !== onToggleExpand || $[12] !== t5 || $[13] !== t7 || $[14] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t3,
            onClick: onToggleExpand,
            children: [
                t5,
                t7,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2368,
            columnNumber: 11
        }, this);
        $[11] = onToggleExpand;
        $[12] = t5;
        $[13] = t7;
        $[14] = t9;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    return t10;
});
_c8 = ProtectionLevelHeader;
const FileTypeSubheader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(function FileTypeSubheader(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    if ($[0] !== "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab") {
        for(let $i = 0; $i < 15; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab";
    }
    const { label, fileType, isExpanded, onToggleExpand } = t0;
    const getIconForType = _FileTypeSubheaderGetIconForType;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            height: "100%",
            minHeight: 36,
            px: 2,
            pl: 0.625,
            bgcolor: "action.hover",
            display: "flex",
            alignItems: "center",
            gap: 1,
            borderBottom: "1px solid",
            borderLeft: "3px solid transparent",
            borderColor: "divider",
            flexShrink: 0,
            cursor: "pointer",
            userSelect: "none",
            "&:hover": {
                bgcolor: "action.focus"
            }
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const t2 = isExpanded ? "rotate(0deg)" : "rotate(-90deg)";
    let t3;
    if ($[2] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: "1.2rem",
                transform: t2,
                transition: "transform 0.2s ease"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2422,
            columnNumber: 10
        }, this);
        $[2] = t2;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            fontSize: "1rem",
            lineHeight: 1
        };
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    const t5 = getIconForType(fileType);
    let t6;
    if ($[5] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            component: "span",
            sx: t4,
            children: t5
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2445,
            columnNumber: 10
        }, this);
        $[5] = t5;
        $[6] = t6;
    } else {
        t6 = $[6];
    }
    let t7;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            fontWeight: 600,
            fontSize: "0.8rem",
            lineHeight: 1
        };
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    let t8;
    if ($[8] !== label) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            sx: t7,
            children: label
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2464,
            columnNumber: 10
        }, this);
        $[8] = label;
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    let t9;
    if ($[10] !== onToggleExpand || $[11] !== t3 || $[12] !== t6 || $[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            onClick: onToggleExpand,
            sx: t1,
            children: [
                t3,
                t6,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 2472,
            columnNumber: 10
        }, this);
        $[10] = onToggleExpand;
        $[11] = t3;
        $[12] = t6;
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    return t9;
});
_c9 = FileTypeSubheader;
// =============================================================================
// FileDetailsPanel - Shows file details and actions in right panel header
// =============================================================================
const FileDetailsPanel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(_s7(function FileDetailsPanel({ file, documentStatus, editor }) {
    _s7();
    const t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.files");
    const { setConfirmDialog } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$FileManagerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFileManager"])();
    const [imageUrl, setImageUrl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [imageSrcSet, setImageSrcSet] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [imageSizes, setImageSizes] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [audioUrl, setAudioUrl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [videoUrl, setVideoUrl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const audioContainerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const [audioWidth, setAudioWidth] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(400);
    // Measure audio container width
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FileDetailsPanel.FileDetailsPanel.useEffect": ()=>{
            if (!file.mimeType?.startsWith("audio/") || !audioContainerRef.current) return;
            const observer = new ResizeObserver({
                "FileDetailsPanel.FileDetailsPanel.useEffect": (entries)=>{
                    for (const entry of entries){
                        const w = Math.floor(entry.contentRect.width);
                        if (w > 0) setAudioWidth(w);
                    }
                }
            }["FileDetailsPanel.FileDetailsPanel.useEffect"]);
            observer.observe(audioContainerRef.current);
            return ({
                "FileDetailsPanel.FileDetailsPanel.useEffect": ()=>observer.disconnect()
            })["FileDetailsPanel.FileDetailsPanel.useEffect"];
        }
    }["FileDetailsPanel.FileDetailsPanel.useEffect"], [
        file.mimeType
    ]);
    // Load signed URLs for media files
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FileDetailsPanel.FileDetailsPanel.useEffect": ()=>{
            const loadUrls = {
                "FileDetailsPanel.FileDetailsPanel.useEffect.loadUrls": async ()=>{
                    try {
                        if (file.mimeType?.startsWith("image/")) {
                            const url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(file.path, file.level?.toLowerCase() || "protected", file.identityId);
                            setImageUrl(url);
                            // Load responsive srcSet variants
                            if (file.id && file.identityId) {
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getResponsiveImageUrls$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getResponsiveImageUrls"])(file.id, file.identityId).then({
                                    "FileDetailsPanel.FileDetailsPanel.useEffect.loadUrls": (result)=>{
                                        if (result) {
                                            setImageSrcSet(result.srcSet);
                                            setImageSizes(result.sizes);
                                        }
                                    }
                                }["FileDetailsPanel.FileDetailsPanel.useEffect.loadUrls"]).catch({
                                    "FileDetailsPanel.FileDetailsPanel.useEffect.loadUrls": ()=>{}
                                }["FileDetailsPanel.FileDetailsPanel.useEffect.loadUrls"]);
                            }
                        } else if (file.mimeType?.startsWith("audio/")) {
                            const url_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(file.path, file.level?.toLowerCase() || "protected", file.identityId);
                            setAudioUrl(url_0);
                        } else if (file.mimeType?.startsWith("video/")) {
                            const url_1 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(file.path, file.level?.toLowerCase() || "protected", file.identityId);
                            setVideoUrl(url_1);
                        }
                    } catch (error) {
                        console.error("Error loading file URL:", error);
                    }
                }
            }["FileDetailsPanel.FileDetailsPanel.useEffect.loadUrls"];
            loadUrls();
        }
    }["FileDetailsPanel.FileDetailsPanel.useEffect"], [
        file.id,
        file.path,
        file.level,
        file.identityId,
        file.mimeType
    ]);
    const handleMenuAction = async (action)=>{
        switch(action){
            case "insert-image":
                if (editor) {
                    editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ImagesPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_IMAGE_COMMAND"], {
                        altText: file.name,
                        path: file.path,
                        identityId: file.identityId,
                        fileId: file.id
                    });
                }
                break;
            case "insert-audio":
                if (editor) {
                    editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_PLAYLIST_COMMAND"], [
                        file.id
                    ]);
                }
                break;
            case "download":
                try {
                    const url_2 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(file.path, "protected", file.identityId);
                    const link = document.createElement("a");
                    link.href = url_2;
                    link.download = file.name;
                    link.target = "_blank";
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                } catch (error_2) {
                    console.error("Error downloading file:", error_2);
                }
                break;
            case "delete":
                setConfirmDialog({
                    open: true,
                    message: `Move to Recycle Bin: ${file.name}?`,
                    severity: "warning",
                    onConfirm: async ()=>{
                        try {
                            console.log("[FileManager2] Soft deleting file:", file.name, file.id);
                            await softDeleteRecord("File", file.id);
                            console.log("[FileManager2] Successfully soft deleted:", file.name);
                            setConfirmDialog({
                                open: false,
                                message: "",
                                onConfirm: null,
                                severity: "warning"
                            });
                        } catch (error_1) {
                            console.error("[FileManager2] Failed to soft delete file:", file.name, error_1);
                            setConfirmDialog({
                                open: true,
                                message: `Failed to move ${file.name} to Recycle Bin: ${error_1.message}`,
                                severity: "error",
                                onConfirm: ()=>setConfirmDialog({
                                        open: false,
                                        message: "",
                                        onConfirm: null,
                                        severity: "warning"
                                    })
                            });
                        }
                    }
                });
                break;
            case "re-analyze":
                try {
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAnalyzableDocument"])(file.mimeType)) {
                        console.log("[FileManager2] Re-analyzing document:", file.name, "type:", file.mimeType, "documentID:", file.documentID);
                        // Analyze document - analyzeDocument will create Document if needed
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["analyzePDF"])(file.id);
                        console.log("[FileManager2] Document analysis started for:", file.name);
                        // Generate embeddings after analysis
                        console.log("[FileManager2] Generating embeddings for:", file.name);
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateEmbeddings"])(file.id);
                        console.log("[FileManager2] Embedding generation started for:", file.name);
                    } else if (file.documentID) {
                        // For non-analyzable files with existing embeddings, just regenerate
                        console.log("[FileManager2] Re-generating embeddings for:", file.name);
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateEmbeddings"])(file.id);
                        console.log("[FileManager2] Embedding generation started for:", file.name);
                    } else {
                        console.warn("[FileManager2] Cannot re-analyze - not an analyzable document and no documentID:", file.name, file.mimeType);
                    }
                } catch (error_0) {
                    console.error("[FileManager2] Error re-analyzing document:", error_0);
                    // Show error to user
                    setConfirmDialog({
                        open: true,
                        message: `Error re-analyzing ${file.name}: ${error_0.message}`,
                        severity: "error",
                        onConfirm: ()=>{
                            setConfirmDialog({
                                open: false,
                                message: "",
                                onConfirm: null,
                                severity: "warning"
                            });
                        }
                    });
                }
                break;
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            borderBottom: "1px solid",
            borderColor: "divider",
            p: 2,
            flexShrink: 0
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    width: "100%",
                    minHeight: "200px",
                    mb: 2,
                    bgcolor: "action.hover",
                    borderRadius: 1,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    overflow: "hidden",
                    flexShrink: 0,
                    p: 2
                },
                children: file.mimeType?.startsWith("image/") ? imageUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    component: "img",
                    src: imageUrl,
                    srcSet: imageSrcSet || undefined,
                    sizes: imageSizes || undefined,
                    alt: file.name,
                    sx: {
                        maxWidth: "100%",
                        maxHeight: 300,
                        objectFit: "cover",
                        borderRadius: 1
                    },
                    onError: (e)=>{
                        e.target.style.display = "none";
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 2673,
                    columnNumber: 59
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "rectangular",
                    width: "100%",
                    height: 200,
                    sx: {
                        borderRadius: 1
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 2680,
                    columnNumber: 15
                }, this) : file.mimeType?.startsWith("audio/") ? audioUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    ref: audioContainerRef,
                    sx: {
                        width: "100%",
                        overflow: "hidden"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        audioUrl: audioUrl,
                        file: file,
                        width: Math.max(audioWidth - 36, 100),
                        height: 80,
                        title: file.name,
                        showDuration: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 2686,
                        columnNumber: 15
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 2682,
                    columnNumber: 64
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    ref: audioContainerRef,
                    sx: {
                        width: "100%",
                        overflow: "hidden"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$StaticWaveform$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        file: file,
                        width: Math.max(audioWidth - 2, 100),
                        height: 80,
                        backgroundColor: "transparent"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 2691,
                        columnNumber: 15
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 2687,
                    columnNumber: 22
                }, this) : file.mimeType?.startsWith("video/") ? videoUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("video", {
                    controls: true,
                    style: {
                        width: "100%",
                        height: "100%",
                        objectFit: "contain"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("source", {
                            src: videoUrl,
                            type: file.mimeType
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 2697,
                            columnNumber: 15
                        }, this),
                        t1("fileManager2.fileDetails.videoNotSupported")
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 2692,
                    columnNumber: 71
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "rectangular",
                    width: "100%",
                    height: 200,
                    sx: {
                        borderRadius: 1
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 2699,
                    columnNumber: 24
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        textAlign: "center",
                        color: "action.disabled"
                    },
                    children: [
                        file.mimeType === "application/pdf" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PictureAsPdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                fontSize: "64px"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 2705,
                            columnNumber: 53
                        }, this),
                        file.mimeType !== "application/pdf" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                fontSize: "64px"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 2708,
                            columnNumber: 53
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 2701,
                    columnNumber: 15
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 2660,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    gap: 2,
                    mb: 1
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "subtitle2",
                    sx: {
                        fontWeight: 600,
                        wordBreak: "break-word"
                    },
                    children: file.name
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 2719,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 2714,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    gap: 2,
                    alignItems: "center",
                    flexWrap: "wrap"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        color: "text.secondary",
                        children: [
                            (file.size / 1000).toFixed(2),
                            " KB"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 2732,
                        columnNumber: 9
                    }, this),
                    documentStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                        label: documentStatus.status,
                        size: "small",
                        variant: "outlined"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 2735,
                        columnNumber: 28
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            ml: "auto",
                            display: "flex",
                            gap: 0.5,
                            flexWrap: "wrap",
                            justifyContent: "flex-end"
                        },
                        children: [
                            editor && file.mimeType?.startsWith("image/") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                title: t1("fileManager2.fileDetails.insertTooltip"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "small",
                                    onClick: ()=>handleMenuAction("insert-image"),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 2745,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 2744,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 2743,
                                columnNumber: 61
                            }, this),
                            editor && (file.mimeType?.startsWith("audio/") || file.mimeType === "application/octet-stream") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                title: t1("fileManager2.fileDetails.insertTooltip"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "small",
                                    onClick: ()=>handleMenuAction("insert-audio"),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 2750,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 2749,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 2748,
                                columnNumber: 111
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                title: t1("fileManager2.fileDetails.downloadTooltip"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "small",
                                    onClick: ()=>handleMenuAction("download"),
                                    "aria-label": t1("fileManager2.fileDetails.downloadTooltip"),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 2755,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 2754,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 2753,
                                columnNumber: 11
                            }, this),
                            ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAnalyzableDocument"])(file.mimeType) || file.documentID) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                title: t1("fileManager2.fileDetails.reAnalyzeTooltip"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "small",
                                    onClick: ()=>handleMenuAction("re-analyze"),
                                    "aria-label": t1("fileManager2.fileDetails.reAnalyzeTooltip"),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Refresh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 2760,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 2759,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 2758,
                                columnNumber: 72
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                title: t1("fileManager2.fileDetails.deleteTooltip"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "small",
                                    onClick: ()=>handleMenuAction("delete"),
                                    sx: {
                                        color: "error.main"
                                    },
                                    "aria-label": t1("fileManager2.fileDetails.deleteTooltip"),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 2767,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 2764,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 2763,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                        lineNumber: 2736,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 2726,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
        lineNumber: 2653,
        columnNumber: 10
    }, this);
}, "vagqDCzIBOMwNBgxCRkm4dZptm8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$FileManagerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFileManager"]
    ];
}));
_c10 = FileDetailsPanel;
// =============================================================================
// FileRowComponent - Renders individual file rows based on file type
// =============================================================================
const FileRowComponent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(_s8(function FileRowComponent({ file, fileType, index, isSelected, allFiles, selectedItems, setSelectedItems, search }) {
    _s8();
    const [isEditing, setIsEditing] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [editedName, setEditedName] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(file.name);
    const [isSaving, setIsSaving] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const { handleFileNameUpdate } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$FileManagerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFileManager"])();
    const { bumpFileVersion } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const isEvenRow = index % 2 === 0;
    // Lazy Yjs: Only connect when editing
    const { metadata, updateMetadata, forceSave, isSynced } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useYjsFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useYjsFile"])({
        fileId: isEditing ? file.id : null,
        enableWebSocket: isEditing,
        enablePersistence: false,
        // No need for IndexedDB on quick edits
        bumpVersion: bumpFileVersion
    });
    const handleSaveFileName = async ()=>{
        if (!editedName.trim() || editedName === file.name) {
            setIsEditing(false);
            setEditedName(file.name);
            return;
        }
        try {
            setIsSaving(true);
            // Extract extension from original filename
            const originalName = file.name;
            const lastDotIndex = originalName.lastIndexOf(".");
            const extension = lastDotIndex > 0 ? originalName.substring(lastDotIndex) : "";
            // Check if new name has an extension
            const newNameTrimmed = editedName.trim();
            const newHasExtension = newNameTrimmed.lastIndexOf(".") > 0;
            // If new name doesn't have extension, append the original extension
            const finalName = newHasExtension ? newNameTrimmed : newNameTrimmed + extension;
            // Use Yjs metadata for real-time sync if available
            if (metadata && updateMetadata) {
                updateMetadata({
                    name: finalName
                });
                await forceSave(); // Force immediate save to GraphQL
                console.log("[FileRowComponent] Saved via Yjs:", finalName);
            } else {
                // Fallback to direct GraphQL if Yjs not ready
                await handleFileNameUpdate(file.id, finalName);
                console.log("[FileRowComponent] Saved via GraphQL:", finalName);
            }
            setIsEditing(false);
        } catch (error) {
            console.error("Error updating filename:", error);
            setEditedName(file.name);
        } finally{
            setIsSaving(false);
        }
    };
    const handleCancelEdit = ()=>{
        setIsEditing(false);
        setEditedName(file.name);
    };
    const handleKeyDown = (e)=>{
        if (e.key === "Enter") {
            handleSaveFileName();
        } else if (e.key === "Escape") {
            handleCancelEdit();
        }
    };
    const handleCheckboxChange = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "FileRowComponent.FileRowComponent.useCallback[handleCheckboxChange]": (e_0)=>{
            e_0.stopPropagation();
            if (e_0.shiftKey) {
                // Shift-click: range select
                const selectedArray = Array.from(selectedItems);
                if (selectedArray.length === 0) {
                    // No previous selection, just toggle this file
                    setSelectedItems(new Set([
                        file.id
                    ]));
                } else {
                    // Find range between last selected and current file
                    const lastSelectedId = selectedArray[selectedArray.length - 1];
                    const lastSelectedIndex = allFiles.findIndex({
                        "FileRowComponent.FileRowComponent.useCallback[handleCheckboxChange].lastSelectedIndex": (f)=>f.id === lastSelectedId
                    }["FileRowComponent.FileRowComponent.useCallback[handleCheckboxChange].lastSelectedIndex"]);
                    const currentIndex = allFiles.findIndex({
                        "FileRowComponent.FileRowComponent.useCallback[handleCheckboxChange].currentIndex": (f_0)=>f_0.id === file.id
                    }["FileRowComponent.FileRowComponent.useCallback[handleCheckboxChange].currentIndex"]);
                    const start = Math.min(lastSelectedIndex, currentIndex);
                    const end = Math.max(lastSelectedIndex, currentIndex);
                    const rangeSet = new Set(selectedArray);
                    for(let i = start; i <= end; i++){
                        rangeSet.add(allFiles[i].id);
                    }
                    setSelectedItems(rangeSet);
                }
            } else {
                // Toggle selection
                const newSet = new Set(selectedItems);
                if (newSet.has(file.id)) {
                    newSet.delete(file.id);
                } else {
                    newSet.add(file.id);
                }
                setSelectedItems(newSet);
            }
        }
    }["FileRowComponent.FileRowComponent.useCallback[handleCheckboxChange]"], [
        selectedItems,
        setSelectedItems,
        allFiles,
        file.id
    ]);
    const handleRowClick = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "FileRowComponent.FileRowComponent.useCallback[handleRowClick]": (e_1)=>{
            if (isEditing) return;
            // Shift-click: range select
            if (e_1.shiftKey) {
                const selectedArray_0 = Array.from(selectedItems);
                if (selectedArray_0.length === 0) {
                    // No previous selection, just select this file
                    setSelectedItems(new Set([
                        file.id
                    ]));
                } else {
                    // Find range between last selected and current file
                    const lastSelectedId_0 = selectedArray_0[selectedArray_0.length - 1];
                    const lastSelectedIndex_0 = allFiles.findIndex({
                        "FileRowComponent.FileRowComponent.useCallback[handleRowClick].lastSelectedIndex_0": (f_1)=>f_1.id === lastSelectedId_0
                    }["FileRowComponent.FileRowComponent.useCallback[handleRowClick].lastSelectedIndex_0"]);
                    const currentIndex_0 = allFiles.findIndex({
                        "FileRowComponent.FileRowComponent.useCallback[handleRowClick].currentIndex_0": (f_2)=>f_2.id === file.id
                    }["FileRowComponent.FileRowComponent.useCallback[handleRowClick].currentIndex_0"]);
                    const start_0 = Math.min(lastSelectedIndex_0, currentIndex_0);
                    const end_0 = Math.max(lastSelectedIndex_0, currentIndex_0);
                    const rangeSet_0 = new Set(selectedArray_0);
                    for(let i_0 = start_0; i_0 <= end_0; i_0++){
                        rangeSet_0.add(allFiles[i_0].id);
                    }
                    setSelectedItems(rangeSet_0);
                }
            } else {
                // Single click: select only this file
                setSelectedItems(new Set([
                    file.id
                ]));
            }
        }
    }["FileRowComponent.FileRowComponent.useCallback[handleRowClick]"], [
        isEditing,
        selectedItems,
        setSelectedItems,
        allFiles,
        file.id
    ]);
    const handleFileNameClick = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "FileRowComponent.FileRowComponent.useCallback[handleFileNameClick]": (e_2)=>{
            e_2.stopPropagation();
            setSelectedItems(new Set([
                file.id
            ]));
            setIsEditing(true);
        }
    }["FileRowComponent.FileRowComponent.useCallback[handleFileNameClick]"], [
        file.id,
        setSelectedItems
    ]);
    const typographySx = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "FileRowComponent.FileRowComponent.useMemo[typographySx]": ()=>({
                fontWeight: 500,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                cursor: "pointer",
                "&:hover": {
                    textDecoration: "underline",
                    color: "primary.main"
                }
            })
    }["FileRowComponent.FileRowComponent.useMemo[typographySx]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        onClick: handleRowClick,
        sx: {
            backgroundColor: isSelected ? "action.selected" : isEvenRow ? "action.hover" : "background.paper",
            borderBottom: "1px solid",
            borderColor: "divider",
            borderLeft: "3px solid",
            borderLeftColor: isSelected ? "primary.main" : "transparent",
            transition: "all 0.2s ease",
            cursor: isEditing ? "text" : "pointer",
            p: 1,
            pl: 0.625,
            // Consistent left padding with 3px border
            display: "flex",
            alignItems: "center",
            gap: 0.75,
            "&:hover": {
                backgroundColor: isSelected ? "action.selected" : "action.focus"
            }
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    flexShrink: 0,
                    display: "flex",
                    alignItems: "center"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                    size: "small",
                    checked: isSelected,
                    onChange: handleCheckboxChange,
                    sx: {
                        p: 0,
                        mr: 0.5
                    },
                    onClick: (e_3)=>e_3.stopPropagation()
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 2964,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 2959,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$FileThumbnail$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                file: file,
                fileType: fileType,
                size: 32,
                isSelected: isSelected
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 2970,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    flex: 1,
                    minWidth: 0
                },
                children: isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                    size: "small",
                    value: editedName,
                    onChange: (e_4)=>setEditedName(e_4.target.value),
                    onBlur: handleSaveFileName,
                    onKeyDown: handleKeyDown,
                    autoFocus: true,
                    disabled: isSaving,
                    fullWidth: true
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 2977,
                    columnNumber: 24
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "body2",
                    onClick: handleFileNameClick,
                    sx: typographySx,
                    children: search ? highlightMatches(file.name, search) : file.name
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 2977,
                    columnNumber: 216
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 2973,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
        lineNumber: 2940,
        columnNumber: 10
    }, this);
}, "8CpLJgcWTZWJhvB4RCKQVwq/AR4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$FileManagerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFileManager"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useYjsFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useYjsFile"]
    ];
}), (prevProps, nextProps)=>{
    // Custom comparison - only re-render if these specific props change
    return prevProps.file.id === nextProps.file.id && prevProps.file.thumbnail === nextProps.file.thumbnail && prevProps.fileType === nextProps.fileType && prevProps.index === nextProps.index && prevProps.isSelected === nextProps.isSelected && prevProps.search === nextProps.search;
});
_c11 = FileRowComponent;
const ListItemImage = /*#__PURE__*/ _s9(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(_c12 = _s9(function ListItemImage(t0) {
    _s9();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    if ($[0] !== "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab") {
        for(let $i = 0; $i < 15; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab";
    }
    const { file } = t0;
    const [url, setUrl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    let t1;
    let t2;
    if ($[1] !== file.identityId || $[2] !== file.path) {
        t1 = ({
            "ListItemImage[useEffect()]": ()=>{
                const asyncFunc = {
                    "ListItemImage[useEffect() > asyncFunc]": async ()=>{
                        const _url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(file.path, "protected", file.identityId);
                        setUrl(_url);
                    }
                }["ListItemImage[useEffect() > asyncFunc]"];
                asyncFunc();
            }
        })["ListItemImage[useEffect()]"];
        t2 = [
            file.path,
            file.identityId
        ];
        $[1] = file.identityId;
        $[2] = file.path;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t1, t2);
    let t3;
    if ($[5] !== file.mimeType || $[6] !== url) {
        t3 = file.mimeType.includes("image") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            src: url,
            style: {
                width: "3rem",
                height: "3rem",
                objectFit: "contain"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 3026,
            columnNumber: 45
        }, this);
        $[5] = file.mimeType;
        $[6] = url;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    let t4;
    if ($[8] !== file.mimeType || $[9] !== file.name || $[10] !== url) {
        t4 = file.mimeType.includes("audio") && (url ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                width: "100%"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                audioUrl: url,
                displayTitle: true,
                title: file.name,
                width: 200,
                height: 60,
                showDuration: true
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 3041,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 3039,
            columnNumber: 52
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                width: "100%",
                height: "60px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                width: "80%",
                height: 40,
                sx: {
                    borderRadius: 1
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 3047,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 3041,
            columnNumber: 137
        }, this));
        $[8] = file.mimeType;
        $[9] = file.name;
        $[10] = url;
        $[11] = t4;
    } else {
        t4 = $[11];
    }
    let t5;
    if ($[12] !== t3 || $[13] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t3,
                t4
            ]
        }, void 0, true);
        $[12] = t3;
        $[13] = t4;
        $[14] = t5;
    } else {
        t5 = $[14];
    }
    return t5;
}, "2bP48bgC9x4MxGX+fFJYZwu2rfU=")), "2bP48bgC9x4MxGX+fFJYZwu2rfU=");
_c13 = ListItemImage;
/**
 * Helper function to completely delete a file from both Gen2 client and S3
 * @param {FileModel} file - The file model to delete
 * @returns {Promise<void>}
 */ async function deleteFileCompletely(file) {
    if (!file) return;
    try {
        const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        // Delete associated Document and all its relationships if it exists
        if (file.documentID) {
            const { data: document1 } = await client.models.Document.get({
                id: file.documentID
            });
            if (document1) {
                console.log("Deleting Document and all related records:", file.documentID);
                // Delete embeddings from IndexedDB
                try {
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vectorStoreDB$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteEmbeddings"])(file.documentID);
                    console.log("Deleted embeddings for document:", file.documentID);
                } catch (embError) {
                    console.warn("Failed to delete embeddings:", embError);
                }
                // Delete all ParsedContent records associated with this document
                const { data: parsedContents } = await client.models.ParsedContent.list({
                    filter: {
                        documentID: {
                            eq: file.documentID
                        }
                    }
                });
                for (const parsedContent of parsedContents || []){
                    await client.models.ParsedContent.delete({
                        id: parsedContent.id
                    });
                }
                console.log(`Deleted ${parsedContents?.length || 0} ParsedContent records`);
                // Delete all UnitDocument join table entries
                const { data: unitDocuments } = await client.models.UnitDocument.list({
                    filter: {
                        documentID: {
                            eq: file.documentID
                        }
                    }
                });
                for (const unitDoc of unitDocuments || []){
                    await client.models.UnitDocument.delete({
                        id: unitDoc.id
                    });
                }
                console.log(`Deleted ${unitDocuments?.length || 0} UnitDocument links`);
                // Delete all DocumentWord join table entries
                const { data: documentWords } = await client.models.DocumentWord.list({
                    filter: {
                        documentID: {
                            eq: file.documentID
                        }
                    }
                });
                for (const docWord of documentWords || []){
                    await client.models.DocumentWord.delete({
                        id: docWord.id
                    });
                }
                console.log(`Deleted ${documentWords?.length || 0} DocumentWord links`);
                // Delete all DocumentQuestion join table entries
                const { data: documentQuestions } = await client.models.DocumentQuestion.list({
                    filter: {
                        documentID: {
                            eq: file.documentID
                        }
                    }
                });
                for (const docQuestion of documentQuestions || []){
                    await client.models.DocumentQuestion.delete({
                        id: docQuestion.id
                    });
                }
                console.log(`Deleted ${documentQuestions?.length || 0} DocumentQuestion links`);
                // Delete all AgentJob records
                const { data: agentJobs } = await client.models.AgentJob.list({
                    filter: {
                        documentID: {
                            eq: file.documentID
                        }
                    }
                });
                for (const job of agentJobs || []){
                    await client.models.AgentJob.delete({
                        id: job.id
                    });
                }
                console.log(`Deleted ${agentJobs?.length || 0} AgentJob records`);
                // Finally delete the Document model itself
                await client.models.Document.delete({
                    id: file.documentID
                });
                console.log("Deleted Document model:", file.documentID);
            }
        }
        // Delete all File relationship join table entries
        // Delete UnitFile join table entries
        const { data: unitFiles } = await client.models.UnitFile.list({
            filter: {
                fileID: {
                    eq: file.id
                }
            }
        });
        for (const unitFile of unitFiles || []){
            await client.models.UnitFile.delete({
                id: unitFile.id
            });
        }
        console.log(`Deleted ${unitFiles?.length || 0} UnitFile links`);
        // Delete WordFile join table entries
        const { data: wordFiles } = await client.models.WordFile.list({
            filter: {
                fileID: {
                    eq: file.id
                }
            }
        });
        for (const wordFile of wordFiles || []){
            await client.models.WordFile.delete({
                id: wordFile.id
            });
        }
        console.log(`Deleted ${wordFiles?.length || 0} WordFile links`);
        // Delete QuestionFile join table entries
        const { data: questionFiles } = await client.models.QuestionFile.list({
            filter: {
                fileID: {
                    eq: file.id
                }
            }
        });
        for (const questionFile of questionFiles || []){
            await client.models.QuestionFile.delete({
                id: questionFile.id
            });
        }
        console.log(`Deleted ${questionFiles?.length || 0} QuestionFile links`);
        // Delete AssistantChatFile join table entries
        const { data: chatFiles } = await client.models.AssistantChatFile.list({
            filter: {
                fileID: {
                    eq: file.id
                }
            }
        });
        for (const chatFile of chatFiles || []){
            await client.models.AssistantChatFile.delete({
                id: chatFile.id
            });
        }
        console.log(`Deleted ${chatFiles?.length || 0} AssistantChatFile links`);
        // Delete ParsedContent associated directly with the file
        const { data: fileParsedContents } = await client.models.ParsedContent.list({
            filter: {
                fileID: {
                    eq: file.id
                }
            }
        });
        for (const parsedContent of fileParsedContents || []){
            await client.models.ParsedContent.delete({
                id: parsedContent.id
            });
        }
        console.log(`Deleted ${fileParsedContents?.length || 0} ParsedContent records for file`);
        // Delete the File model itself
        await client.models.File.delete({
            id: file.id
        });
        console.log("Successfully deleted File model:", file.id);
        // Delete from S3 - must provide accessLevel and identityId for protected files
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["remove"])({
                key: file.path,
                options: {
                    accessLevel: "protected",
                    identityId: file.identityId
                }
            });
            console.log("Deleted S3 file:", file.path);
        } catch (s3Error) {
            console.error("S3 deletion error (file may not exist):", s3Error);
        // Don't throw - file model is already deleted
        }
    } catch (error) {
        console.error("Error deleting file:", error);
        console.error("Error details:", {
            message: error.message,
            name: error.name,
            stack: error.stack
        });
        throw error;
    }
}
/**
 * Component to handle selected file view with parsedContent
 * parsedContent is lazy-loaded via Amplify Gen 2 hasMany relationship
 */ function SelectedFileView({ selectedFile, documentStatus, search, editor }) {
    _s10();
    const [parsedContent, setParsedContent] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "SelectedFileView.useEffect": ()=>{
            let cancelled = false;
            setParsedContent(null);
            const loadParsedContent = {
                "SelectedFileView.useEffect.loadParsedContent": async ()=>{
                    try {
                        if (typeof selectedFile.parsedContent === "function") {
                            const result = await selectedFile.parsedContent();
                            if (!cancelled) {
                                setParsedContent(result?.data?.[0] || null);
                            }
                        } else if (Array.isArray(selectedFile.parsedContent)) {
                            if (!cancelled) {
                                setParsedContent(selectedFile.parsedContent[0] || null);
                            }
                        }
                    } catch (err) {
                        console.error("[SelectedFileView] Failed to load parsedContent:", err);
                    }
                }
            }["SelectedFileView.useEffect.loadParsedContent"];
            if (selectedFile?.id) {
                loadParsedContent();
            }
            return ({
                "SelectedFileView.useEffect": ()=>{
                    cancelled = true;
                }
            })["SelectedFileView.useEffect"];
        }
    }["SelectedFileView.useEffect"], [
        selectedFile?.id,
        selectedFile?._version
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FileDetailsPanel, {
                file: selectedFile,
                documentStatus: documentStatus,
                editor: editor
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 3346,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MetadataEditor, {
                file: selectedFile
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 3348,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    flex: 1,
                    overflow: "auto",
                    minHeight: 0
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandedFileContent, {
                    file: selectedFile,
                    parsedContent: parsedContent,
                    search: search,
                    editor: editor
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 3355,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 3350,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s10(SelectedFileView, "R7usCYHzT4GQXnICpMRKN+tYoik=");
_c14 = SelectedFileView;
/**
 * Component to render selected file details panel
 * Handles finding the selected file and wrapping with Suspense
 */ function SelectedFileDetailsPanel(t0) {
    _s11();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(55);
    if ($[0] !== "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab") {
        for(let $i = 0; $i < 55; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d667c732cc51157c2b201c8f93b40f813a36ffb7445f318e5c1cfe56e75f5dab";
    }
    const { selectedItems, files, documentStatuses, search, editor } = t0;
    const t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.files");
    if (selectedItems.size === 0) {
        let t11;
        if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
            t11 = {
                flex: 1,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "text.secondary"
            };
            $[1] = t11;
        } else {
            t11 = $[1];
        }
        let t2;
        if ($[2] !== t1) {
            t2 = t1("fileManager2.selectedFileDetails.emptyState");
            $[2] = t1;
            $[3] = t2;
        } else {
            t2 = $[3];
        }
        let t3;
        if ($[4] !== t2) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t11,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "body2",
                    children: t2
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 3404,
                    columnNumber: 25
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 3404,
                columnNumber: 12
            }, this);
            $[4] = t2;
            $[5] = t3;
        } else {
            t3 = $[5];
        }
        return t3;
    }
    if (selectedItems.size > 1) {
        let T0;
        let T1;
        let t11;
        let t2;
        let t3;
        let t4;
        let t5;
        let t6;
        let t7;
        if ($[6] !== files || $[7] !== selectedItems || $[8] !== t1) {
            let t8;
            if ($[18] !== selectedItems) {
                t8 = ({
                    "SelectedFileDetailsPanel[files.filter()]": (f)=>selectedItems.has(f.id)
                })["SelectedFileDetailsPanel[files.filter()]"];
                $[18] = selectedItems;
                $[19] = t8;
            } else {
                t8 = $[19];
            }
            const selectedFiles = files.filter(t8);
            const totalSize = selectedFiles.reduce(_SelectedFileDetailsPanelSelectedFilesReduce, 0);
            const byType = {};
            selectedFiles.forEach({
                "SelectedFileDetailsPanel[selectedFiles.forEach()]": (f_1)=>{
                    const type = f_1.mimeType?.split("/")[0] || "other";
                    byType[type] = (byType[type] || 0) + 1;
                }
            }["SelectedFileDetailsPanel[selectedFiles.forEach()]"]);
            T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"];
            if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
                t4 = {
                    p: 2,
                    overflow: "auto",
                    flex: 1
                };
                $[20] = t4;
            } else {
                t4 = $[20];
            }
            let t9;
            if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
                t9 = {
                    fontWeight: 600,
                    mb: 1
                };
                $[21] = t9;
            } else {
                t9 = $[21];
            }
            let t10;
            if ($[22] !== selectedItems.size || $[23] !== t1) {
                t10 = t1("fileManager2.selectedFileDetails.multiSelectHeading", {
                    count: selectedItems.size,
                    defaultValue: "{{count}} files selected"
                });
                $[22] = selectedItems.size;
                $[23] = t1;
                $[24] = t10;
            } else {
                t10 = $[24];
            }
            if ($[25] !== t10) {
                t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "subtitle1",
                    sx: t9,
                    children: t10
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 3476,
                    columnNumber: 14
                }, this);
                $[25] = t10;
                $[26] = t5;
            } else {
                t5 = $[26];
            }
            let t111;
            if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
                t111 = {
                    mb: 2
                };
                $[27] = t111;
            } else {
                t111 = $[27];
            }
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                color: "text.secondary",
                sx: t111,
                children: t1("fileManager2.selectedFileDetails.totalSize", {
                    size: (totalSize / 1024).toFixed(1),
                    defaultValue: "Total size: {{size}} KB"
                })
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 3491,
                columnNumber: 12
            }, this);
            t7 = Object.entries(byType).map(_SelectedFileDetailsPanelAnonymous);
            T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"];
            t11 = "ul";
            if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
                t2 = {
                    mt: 2,
                    pl: 2,
                    m: 0
                };
                $[28] = t2;
            } else {
                t2 = $[28];
            }
            t3 = selectedFiles.map(_SelectedFileDetailsPanelSelectedFilesMap);
            $[6] = files;
            $[7] = selectedItems;
            $[8] = t1;
            $[9] = T0;
            $[10] = T1;
            $[11] = t11;
            $[12] = t2;
            $[13] = t3;
            $[14] = t4;
            $[15] = t5;
            $[16] = t6;
            $[17] = t7;
        } else {
            T0 = $[9];
            T1 = $[10];
            t11 = $[11];
            t2 = $[12];
            t3 = $[13];
            t4 = $[14];
            t5 = $[15];
            t6 = $[16];
            t7 = $[17];
        }
        let t8;
        if ($[29] !== T0 || $[30] !== t11 || $[31] !== t2 || $[32] !== t3) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
                component: t11,
                sx: t2,
                children: t3
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 3534,
                columnNumber: 12
            }, this);
            $[29] = T0;
            $[30] = t11;
            $[31] = t2;
            $[32] = t3;
            $[33] = t8;
        } else {
            t8 = $[33];
        }
        let t9;
        if ($[34] !== T1 || $[35] !== t4 || $[36] !== t5 || $[37] !== t6 || $[38] !== t7 || $[39] !== t8) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
                sx: t4,
                children: [
                    t5,
                    t6,
                    t7,
                    t8
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 3545,
                columnNumber: 12
            }, this);
            $[34] = T1;
            $[35] = t4;
            $[36] = t5;
            $[37] = t6;
            $[38] = t7;
            $[39] = t8;
            $[40] = t9;
        } else {
            t9 = $[40];
        }
        return t9;
    }
    let t11;
    if ($[41] !== selectedItems) {
        t11 = Array.from(selectedItems);
        $[41] = selectedItems;
        $[42] = t11;
    } else {
        t11 = $[42];
    }
    const firstSelectedId = t11[0];
    let t2;
    if ($[43] !== files || $[44] !== firstSelectedId) {
        let t3;
        if ($[46] !== firstSelectedId) {
            t3 = ({
                "SelectedFileDetailsPanel[files.find()]": (f_3)=>f_3.id === firstSelectedId
            })["SelectedFileDetailsPanel[files.find()]"];
            $[46] = firstSelectedId;
            $[47] = t3;
        } else {
            t3 = $[47];
        }
        t2 = files.find(t3);
        $[43] = files;
        $[44] = firstSelectedId;
        $[45] = t2;
    } else {
        t2 = $[45];
    }
    const selectedFile = t2;
    if (!selectedFile) {
        return null;
    }
    const documentStatus = documentStatuses[selectedFile.documentID];
    let t3;
    if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            flex: 1,
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
        };
        $[48] = t3;
    } else {
        t3 = $[48];
    }
    let t4;
    if ($[49] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t3,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                width: "80%",
                height: 200,
                sx: {
                    borderRadius: 1
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 3605,
                columnNumber: 23
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 3605,
            columnNumber: 10
        }, this);
        $[49] = t4;
    } else {
        t4 = $[49];
    }
    let t5;
    if ($[50] !== documentStatus || $[51] !== editor || $[52] !== search || $[53] !== selectedFile) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Suspense, {
            fallback: t4,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SelectedFileView, {
                selectedFile: selectedFile,
                documentStatus: documentStatus,
                search: search,
                editor: editor
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 3614,
                columnNumber: 40
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 3614,
            columnNumber: 10
        }, this);
        $[50] = documentStatus;
        $[51] = editor;
        $[52] = search;
        $[53] = selectedFile;
        $[54] = t5;
    } else {
        t5 = $[54];
    }
    return t5;
}
_s11(SelectedFileDetailsPanel, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c15 = SelectedFileDetailsPanel;
function _SelectedFileDetailsPanelSelectedFilesMap(f_2) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
        component: "li",
        variant: "body2",
        sx: {
            py: 0.25
        },
        children: f_2.name
    }, f_2.id, false, {
        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
        lineNumber: 3626,
        columnNumber: 10
    }, this);
}
function _SelectedFileDetailsPanelAnonymous(t0) {
    const [type_0, count] = t0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
        label: `${type_0}: ${count}`,
        size: "small",
        variant: "outlined",
        sx: {
            mr: 0.5,
            mb: 0.5
        }
    }, type_0, false, {
        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
        lineNumber: 3632,
        columnNumber: 10
    }, this);
}
function _SelectedFileDetailsPanelSelectedFilesReduce(sum, f_0) {
    return sum + (f_0.size || 0);
}
function FileManager2() {
    _s12();
    const t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.files");
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const [search, setSearch] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        "FileManager2.useState": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                return searchParams?.get("q") || "";
            }
            //TURBOPACK unreachable
            ;
        }
    }["FileManager2.useState"]);
    const [searchMode, setSearchMode] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("hybrid"); // 'keyword', 'semantic', 'hybrid'
    const [searching, setSearching] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [selectedItems, setSelectedItems] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(new Set());
    // Load expanded items from localStorage
    const [expandedItems, setExpandedItems] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        "FileManager2.useState": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                const saved = localStorage.getItem("fileManager2_expandedItems");
                if (saved) {
                    try {
                        return new Set(JSON.parse(saved));
                    } catch (e) {
                        return new Set();
                    }
                }
            }
            return new Set();
        }
    }["FileManager2.useState"]);
    // Track collapsed protection levels - all expanded by default
    const [collapsedProtectionLevels, setCollapsedProtectionLevels] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        "FileManager2.useState": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                const saved_0 = localStorage.getItem("fileManager2_collapsedProtectionLevels");
                if (saved_0) {
                    try {
                        return new Set(JSON.parse(saved_0));
                    } catch (e_0) {
                        return new Set();
                    }
                }
            }
            return new Set();
        }
    }["FileManager2.useState"]);
    const handleToggleProtectionLevelCollapse = (protectionLevel)=>{
        setCollapsedProtectionLevels((prev)=>{
            const newSet = new Set(prev);
            if (newSet.has(protectionLevel)) {
                newSet.delete(protectionLevel);
            } else {
                newSet.add(protectionLevel);
            }
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("fileManager2_collapsedProtectionLevels", JSON.stringify(Array.from(newSet)));
            }
            return newSet;
        });
    };
    // Track collapsed file types - all expanded by default
    const [collapsedFileTypes, setCollapsedFileTypes] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        "FileManager2.useState": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                const saved_1 = localStorage.getItem("fileManager2_collapsedFileTypes");
                if (saved_1) {
                    try {
                        return new Set(JSON.parse(saved_1));
                    } catch (e_1) {
                        return new Set();
                    }
                }
            }
            return new Set();
        }
    }["FileManager2.useState"]);
    const handleToggleFileTypeCollapse = (fileTypeKey)=>{
        setCollapsedFileTypes((prev_0)=>{
            const newSet_0 = new Set(prev_0);
            if (newSet_0.has(fileTypeKey)) {
                newSet_0.delete(fileTypeKey);
            } else {
                newSet_0.add(fileTypeKey);
            }
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("fileManager2_collapsedFileTypes", JSON.stringify(Array.from(newSet_0)));
            }
            return newSet_0;
        });
    };
    // Persist expanded items to localStorage
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FileManager2.useEffect": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("fileManager2_expandedItems", JSON.stringify(Array.from(expandedItems)));
            }
        }
    }["FileManager2.useEffect"], [
        expandedItems
    ]);
    const [contextMenu, setContextMenu] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [confirmDialog, setConfirmDialog] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        open: false,
        message: "",
        onConfirm: null,
        severity: "warning"
    });
    const [editingFileId, setEditingFileId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [semanticResults, setSemanticResults] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null); // {fileId: {maxScore, pages: [{page, score}]}}
    const [fileEmbeddings, setFileEmbeddings] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({}); // Cache embeddings
    // Use vector store from FilesContext (shared across entire app, initialized early)
    const { vectorStore, vectorStoreReady } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { unit } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const loadedVersions = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(new Map()); // Track loaded document versions
    const debouncedSearch = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(debounce({
        "FileManager2.useRef": (value)=>{
            setSearch(value);
        }
    }["FileManager2.useRef"], 300)).current;
    const handleSearch = (e_2)=>{
        const value_0 = e_2.target.value;
        setSearch(value_0);
        debouncedSearch(value_0);
        // Trigger semantic search for semantic/hybrid modes
        if ((searchMode === "semantic" || searchMode === "hybrid") && value_0.trim()) {
            performSemanticSearch(value_0);
        } else {
            setSemanticResults(null);
        }
    };
    // Select/Deselect handlers
    const handleSelectAll = ()=>{
        // Filter out null items before mapping to IDs
        const allFileIds = new Set(files.filter((f)=>f != null && f.id != null).map((f_0)=>f_0.id));
        setSelectedItems(allFileIds);
    };
    const handleDeselectAll = ()=>{
        setSelectedItems(new Set());
    };
    const handleToggleSelect = (fileId)=>{
        setSelectedItems((prev_1)=>{
            const newSet_1 = new Set(prev_1);
            if (newSet_1.has(fileId)) {
                newSet_1.delete(fileId);
            } else {
                newSet_1.add(fileId);
            }
            return newSet_1;
        });
    };
    // --- RecordingStudio3 handlers ---
    /**
   * Open RS3 with a new conversation preset, or re-open an existing script file.
   * @param {Object|null} scriptFile - Existing File record with mimeType text/x-fountain, or null for new
   */ const handleOpenStudio = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "FileManager2.useCallback[handleOpenStudio]": (scriptFile = null)=>{
            setStudioScriptFile(scriptFile);
            setStudioOpen(true);
        }
    }["FileManager2.useCallback[handleOpenStudio]"], []);
    /**
   * RS3Modal onSave handler — creates File records for audio takes and
   * persists the script as a text/x-fountain File record.
   */ const handleStudioSave = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "FileManager2.useCallback[handleStudioSave]": async (payload)=>{
            const { audioFiles, scriptData } = payload;
            console.log("[FileManager2] RS3 save payload:", {
                audioCount: audioFiles?.length,
                scriptData: !!scriptData
            });
        // Audio File records are already created by RS3 during take recording.
        // The scriptData is the conversation metadata we persist for re-opening.
        // Future: save as .fountain file and create/update UnitFile join.
        }
    }["FileManager2.useCallback[handleStudioSave]"], []);
    /**
   * Save handler for RecordingStudioEnhancedModal.
   * Uploads each track's recorded clips as protected audio File records, then
   * inserts a ConversationPlaylistNode into the editor with the resulting file IDs
   * and dialogue subtitle lines derived from the track prompts.
   */ const handleEnhancedStudioSave = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "FileManager2.useCallback[handleEnhancedStudioSave]": async (studioState)=>{
            const { tracks = [], filters } = studioState || {};
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            try {
                // Resolve the caller's identityId once
                const { fetchAuthSession, getCurrentUser } = await __turbopack_context__.A("[project]/node_modules/aws-amplify/dist/esm/auth/index.mjs [app-client] (ecmascript, async loader)");
                const session = await fetchAuthSession();
                const resolvedIdentityId = session?.identityCredentials?.identityId;
                const { username: owner } = await getCurrentUser();
                const audioFileIds = [];
                const dialogue = [];
                for(let trackIdx = 0; trackIdx < tracks.length; trackIdx++){
                    const track = tracks[trackIdx];
                    for(let clipIdx = 0; clipIdx < (track.clips || []).length; clipIdx++){
                        const clip = track.clips[clipIdx];
                        if (!clip?.audioBlob) continue;
                        const filename = [
                            "conversation",
                            unit?.name?.replace(/[^a-zA-Z0-9]/g, "-") || "audio",
                            track.name?.replace(/[^a-zA-Z0-9]/g, "-") || `track${trackIdx + 1}`,
                            clip.id || clipIdx
                        ].join("-") + ".mp3";
                        const file = new File([
                            clip.audioBlob
                        ], filename, {
                            type: "audio/mpeg"
                        });
                        const s3Path = `protected/${resolvedIdentityId}/audio/${filename}`;
                        const { uploadData } = await __turbopack_context__.A("[project]/node_modules/aws-amplify/dist/esm/storage/index.mjs [app-client] (ecmascript, async loader)");
                        const uploadResult = await uploadData({
                            path: s3Path,
                            data: file,
                            options: {
                                contentType: "audio/mpeg"
                            }
                        }).result;
                        const { data: fileRecord } = await client.models.File.create({
                            path: uploadResult.path,
                            owner,
                            identityId: resolvedIdentityId,
                            name: filename,
                            size: file.size,
                            mimeType: "audio/mpeg",
                            level: "PROTECTED"
                        });
                        if (fileRecord?.id) {
                            audioFileIds.push(fileRecord.id);
                            // Create UnitFile join
                            if (unit?.id) {
                                await client.models.UnitFile.create({
                                    unitID: unit.id,
                                    fileID: fileRecord.id
                                }).catch({
                                    "FileManager2.useCallback[handleEnhancedStudioSave]": (err_0)=>console.warn("[FileManager2] UnitFile create error:", err_0)
                                }["FileManager2.useCallback[handleEnhancedStudioSave]"]);
                            }
                            // Build a dialogue line from this clip's track prompt
                            if (track.prompt?.trim()) {
                                dialogue.push({
                                    id: audioFileIds.length,
                                    speaker: track.name || `Track ${trackIdx + 1}`,
                                    text: track.prompt,
                                    timing: {
                                        start: 0,
                                        end: 0
                                    },
                                    audioFileID: fileRecord.id,
                                    stillFileID: null
                                });
                            }
                        }
                    }
                }
                // Persist the script as a text/x-fountain File record for re-opening
                if (audioFileIds.length > 0) {
                    const scriptTitle = unit?.name || "Conversation";
                    const scriptContent = JSON.stringify({
                        title: scriptTitle,
                        tracks: tracks.map({
                            "FileManager2.useCallback[handleEnhancedStudioSave].scriptContent": (tr)=>({
                                    name: tr.name,
                                    voice: tr.voice,
                                    prompt: tr.prompt
                                })
                        }["FileManager2.useCallback[handleEnhancedStudioSave].scriptContent"]),
                        dialogue,
                        audioFileIds
                    });
                    const scriptBlob = new Blob([
                        scriptContent
                    ], {
                        type: "text/x-fountain"
                    });
                    const scriptFile_0 = new File([
                        scriptBlob
                    ], `${scriptTitle.replace(/[^a-zA-Z0-9]/g, "-")}-conversation.fountain`, {
                        type: "text/x-fountain"
                    });
                    const scriptS3Path = `protected/${resolvedIdentityId}/files/${scriptFile_0.name}`;
                    const { uploadData: uploadScriptData } = await __turbopack_context__.A("[project]/node_modules/aws-amplify/dist/esm/storage/index.mjs [app-client] (ecmascript, async loader)");
                    const scriptUploadResult = await uploadScriptData({
                        path: scriptS3Path,
                        data: scriptFile_0,
                        options: {
                            contentType: "text/x-fountain"
                        }
                    }).result;
                    const { data: scriptFileRecord } = await client.models.File.create({
                        path: scriptUploadResult.path,
                        owner,
                        identityId: resolvedIdentityId,
                        name: scriptFile_0.name,
                        size: scriptFile_0.size,
                        mimeType: "text/x-fountain",
                        level: "PROTECTED"
                    });
                    if (scriptFileRecord?.id && unit?.id) {
                        await client.models.UnitFile.create({
                            unitID: unit.id,
                            fileID: scriptFileRecord.id
                        }).catch({
                            "FileManager2.useCallback[handleEnhancedStudioSave]": (err_1)=>console.warn("[FileManager2] UnitFile (script) create error:", err_1)
                        }["FileManager2.useCallback[handleEnhancedStudioSave]"]);
                    }
                }
                // Insert ConversationPlaylistNode into editor
                if (audioFileIds.length > 0) {
                    editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ConversationPlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_CONVERSATION_PLAYLIST_COMMAND"], {
                        fileIDs: audioFileIds,
                        dialogue,
                        scriptTitle: unit?.name || "Conversation",
                        movieFileID: null
                    });
                }
            } catch (err) {
                console.error("[FileManager2] handleEnhancedStudioSave error:", err);
            }
            setEnhancedStudioOpen(false);
        }
    }["FileManager2.useCallback[handleEnhancedStudioSave]"], [
        unit,
        editor
    ]);
    // // Expand/Collapse handlers
    // const handleExpandAll = () => {
    //     const allFileIds = new Set(files.map(f => f.id));
    //     setExpandedItems(allFileIds);
    // };
    // const handleCollapseAll = () => {
    //     setExpandedItems(new Set());
    // };
    // const handleToggleExpand = (fileId) => {
    //     setExpandedItems(prev => {
    //         const newSet = new Set(prev);
    //         if (newSet.has(fileId)) {
    //             newSet.delete(fileId);
    //         } else {
    //             newSet.add(fileId);
    //         }
    //         return newSet;
    //     });
    // };
    // Handle filename updates
    const handleFileNameUpdate = async (fileId_0, newName)=>{
        try {
            const fileToUpdate = files.find((f_1)=>f_1.id === fileId_0);
            if (!fileToUpdate) return;
            // Extract extension from original filename
            const originalName = fileToUpdate.name;
            const lastDotIndex = originalName.lastIndexOf(".");
            const extension = lastDotIndex > 0 ? originalName.substring(lastDotIndex) : "";
            // Check if new name has an extension
            const newNameTrimmed = newName.trim();
            const newHasExtension = newNameTrimmed.lastIndexOf(".") > 0;
            // If new name doesn't have extension, append the original extension
            const finalName = newHasExtension ? newNameTrimmed : newNameTrimmed + extension;
            const versionCtrl = fileToUpdate._version != null ? bumpFileVersion(fileToUpdate.id, fileToUpdate._version) : null;
            const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const { data: saved_2, errors } = await client_0.models.File.update({
                id: fileToUpdate.id,
                name: finalName,
                ...fileToUpdate._version != null && {
                    _version: fileToUpdate._version
                }
            });
            if (errors?.length) {
                versionCtrl?.rollback();
            } else {
                versionCtrl?.confirm(saved_2?._version);
            }
            console.log("File name updated successfully");
            setEditingFileId(null);
        } catch (error) {
            console.error("Error updating file name:", error);
            alert("Failed to update file name: " + error.message);
        }
    };
    // Handle escape key to cancel editing
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FileManager2.useEffect": ()=>{
            const handleKeyDown = {
                "FileManager2.useEffect.handleKeyDown": (event)=>{
                    if (event.key === "Escape" && editingFileId) {
                        setEditingFileId(null);
                    }
                }
            }["FileManager2.useEffect.handleKeyDown"];
            document.addEventListener("keydown", handleKeyDown);
            return ({
                "FileManager2.useEffect": ()=>{
                    document.removeEventListener("keydown", handleKeyDown);
                }
            })["FileManager2.useEffect"];
        }
    }["FileManager2.useEffect"], [
        editingFileId
    ]);
    const [isDragging, setIsDragging] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [fileOperations, setFileOperations] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    const [filesToUpload, setFilesToUpload] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    const uploadInProgressRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(false);
    const [newFileFormOpen, setNewFileFormOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    // Calculate overall upload progress
    const uploadProgress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "FileManager2.useMemo[uploadProgress]": ()=>{
            if (fileOperations.length === 0) return 0;
            const totalProgress = fileOperations.reduce({
                "FileManager2.useMemo[uploadProgress].totalProgress": (sum, op)=>{
                    const percent = parseInt(op.progress) || 0;
                    return sum + percent;
                }
            }["FileManager2.useMemo[uploadProgress].totalProgress"], 0);
            return Math.round(totalProgress / fileOperations.length);
        }
    }["FileManager2.useMemo[uploadProgress]"], [
        fileOperations
    ]);
    const [newImageFileFormOpen, setNewImageFileFormOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [newAudioFileFormOpen, setNewAudioFileFormOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [newVideoFileFormOpen, setNewVideoFileFormOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    // RecordingStudio3 modal state
    const [studioOpen, setStudioOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [studioScriptFile, setStudioScriptFile] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    // RecordingStudioEnhanced modal state
    const [enhancedStudioOpen, setEnhancedStudioOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    // Load generator tab from localStorage, default to 'all'
    const [generator, setGenerator] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        "FileManager2.useState": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                const saved_3 = localStorage.getItem("fileManager2_activeTab");
                return saved_3 || "all";
            }
            //TURBOPACK unreachable
            ;
        }
    }["FileManager2.useState"]);
    // Persist tab selection to localStorage
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FileManager2.useEffect": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("fileManager2_activeTab", generator);
            }
        }
    }["FileManager2.useEffect"], [
        generator
    ]);
    const [selectedDocument, setSelectedDocument] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [suggestionTab, setSuggestionTab] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(0);
    const { files, documents, session: session_0, bumpFileVersion, showDeleted, setShowDeleted } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { softDelete: softDeleteRecord1 } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecycleBin"])();
    // Debug: log files received
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FileManager2.useEffect": ()=>{
            console.log("[FileManager2] Files received from context:", files?.length || 0, files);
        }
    }["FileManager2.useEffect"], [
        files
    ]);
    const documentStatuses = documents || {};
    const { identityId } = session_0 || {};
    // Enhanced text search function
    const performSimpleTextSearch = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "FileManager2.useCallback[performSimpleTextSearch]": (query)=>{
            if (!query.trim()) {
                setSemanticResults(null);
                return;
            }
            const searchTerms = query.toLowerCase().split(/\s+/).filter({
                "FileManager2.useCallback[performSimpleTextSearch].searchTerms": (term)=>term.length > 0
            }["FileManager2.useCallback[performSimpleTextSearch].searchTerms"]);
            const results = {};
            // Search through file names and any extracted content
            files.forEach({
                "FileManager2.useCallback[performSimpleTextSearch]": (file_0)=>{
                    const fileName = file_0.name.toLowerCase();
                    const filePath = file_0.path?.toLowerCase() || "";
                    const matches = [];
                    // Check file name matches
                    searchTerms.forEach({
                        "FileManager2.useCallback[performSimpleTextSearch]": (term_0)=>{
                            if (fileName.includes(term_0)) {
                                matches.push({
                                    type: "filename",
                                    score: 0.9,
                                    text: file_0.name,
                                    term: term_0
                                });
                            }
                            if (filePath.includes(term_0)) {
                                matches.push({
                                    type: "path",
                                    score: 0.7,
                                    text: file_0.path,
                                    term: term_0
                                });
                            }
                        }
                    }["FileManager2.useCallback[performSimpleTextSearch]"]);
                    // Check parsed content if available (parsedContent is a hasMany array, take first item)
                    const parsedContent = file_0.parsedContent?.[0] || file_0.document?.parsedContent?.[0];
                    console.log("[SimpleTextSearch] Parsed content for file", file_0.id, parsedContent);
                    if (parsedContent) {
                        // Search vocabulary
                        (parsedContent.vocabulary || []).forEach({
                            "FileManager2.useCallback[performSimpleTextSearch]": (v)=>{
                                const vocabText = `${v.term} ${v.definition}`.toLowerCase();
                                searchTerms.forEach({
                                    "FileManager2.useCallback[performSimpleTextSearch]": (term_1)=>{
                                        if (vocabText.includes(term_1)) {
                                            matches.push({
                                                type: "vocabulary",
                                                score: 0.8,
                                                text: `${v.term}: ${v.definition}`,
                                                term: term_1
                                            });
                                        }
                                    }
                                }["FileManager2.useCallback[performSimpleTextSearch]"]);
                            }
                        }["FileManager2.useCallback[performSimpleTextSearch]"]);
                        // Search summaries
                        (parsedContent.summaries || []).forEach({
                            "FileManager2.useCallback[performSimpleTextSearch]": (s)=>{
                                const summaryText = s.content.toLowerCase();
                                searchTerms.forEach({
                                    "FileManager2.useCallback[performSimpleTextSearch]": (term_2)=>{
                                        if (summaryText.includes(term_2)) {
                                            matches.push({
                                                type: "summary",
                                                score: 0.6,
                                                text: s.content,
                                                term: term_2
                                            });
                                        }
                                    }
                                }["FileManager2.useCallback[performSimpleTextSearch]"]);
                            }
                        }["FileManager2.useCallback[performSimpleTextSearch]"]);
                        // Search objectives
                        (parsedContent.objectives || []).forEach({
                            "FileManager2.useCallback[performSimpleTextSearch]": (o)=>{
                                const objText = o.description.toLowerCase();
                                searchTerms.forEach({
                                    "FileManager2.useCallback[performSimpleTextSearch]": (term_3)=>{
                                        if (objText.includes(term_3)) {
                                            matches.push({
                                                type: "objective",
                                                score: 0.6,
                                                text: o.description,
                                                term: term_3
                                            });
                                        }
                                    }
                                }["FileManager2.useCallback[performSimpleTextSearch]"]);
                            }
                        }["FileManager2.useCallback[performSimpleTextSearch]"]);
                        // Search concepts
                        (parsedContent.concepts || []).forEach({
                            "FileManager2.useCallback[performSimpleTextSearch]": (c)=>{
                                const conceptText = `${c.name} ${c.description}`.toLowerCase();
                                searchTerms.forEach({
                                    "FileManager2.useCallback[performSimpleTextSearch]": (term_4)=>{
                                        if (conceptText.includes(term_4)) {
                                            matches.push({
                                                type: "concept",
                                                score: 0.6,
                                                text: `${c.name}: ${c.description}`,
                                                term: term_4
                                            });
                                        }
                                    }
                                }["FileManager2.useCallback[performSimpleTextSearch]"]);
                            }
                        }["FileManager2.useCallback[performSimpleTextSearch]"]);
                        // Search questions
                        (parsedContent.questions || []).forEach({
                            "FileManager2.useCallback[performSimpleTextSearch]": (q)=>{
                                const questionText = `${q.question} ${q.answer || ""}`.toLowerCase();
                                searchTerms.forEach({
                                    "FileManager2.useCallback[performSimpleTextSearch]": (term_5)=>{
                                        if (questionText.includes(term_5)) {
                                            matches.push({
                                                type: "question",
                                                score: 0.7,
                                                text: `Q: ${q.question}${q.answer ? ` A: ${q.answer}` : ""}`,
                                                term: term_5
                                            });
                                        }
                                    }
                                }["FileManager2.useCallback[performSimpleTextSearch]"]);
                            }
                        }["FileManager2.useCallback[performSimpleTextSearch]"]);
                    }
                    if (matches.length > 0) {
                        // Sort matches by score and create pages
                        matches.sort({
                            "FileManager2.useCallback[performSimpleTextSearch]": (a, b)=>b.score - a.score
                        }["FileManager2.useCallback[performSimpleTextSearch]"]);
                        const maxScore = Math.max(...matches.map({
                            "FileManager2.useCallback[performSimpleTextSearch].maxScore": (m)=>m.score
                        }["FileManager2.useCallback[performSimpleTextSearch].maxScore"]));
                        results[file_0.id] = {
                            maxScore,
                            pages: matches.slice(0, 10).map({
                                "FileManager2.useCallback[performSimpleTextSearch]": (match, index)=>({
                                        page: index + 1,
                                        score: match.score,
                                        text: match.text,
                                        type: match.type
                                    })
                            }["FileManager2.useCallback[performSimpleTextSearch]"])
                        };
                    }
                }
            }["FileManager2.useCallback[performSimpleTextSearch]"]);
            setSemanticResults(Object.keys(results).length > 0 ? results : null);
        }
    }["FileManager2.useCallback[performSimpleTextSearch]"], [
        files
    ]);
    // Vector store search function exposed to other components
    const performVectorSearch = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "FileManager2.useCallback[performVectorSearch]": async (query_0, options = {})=>{
            const { topK = 10, filters: filters_0 = {}, includeText = true } = options;
            console.log(`[FileManager2.performVectorSearch] Query: "${query_0}", topK: ${topK}`);
            if (!query_0.trim()) {
                return {
                    results: [],
                    query: query_0
                };
            }
            try {
                // Generate embedding for the query
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$f001e6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateEmbedding"])({
                    content: query_0
                });
                const queryEmbedding = result.embedding;
                console.log(`[FileManager2.performVectorSearch] Generated ${queryEmbedding.length}D embedding`);
                // Search vector store (now async due to worker usage)
                const results_0 = await vectorStore.search(queryEmbedding, filters_0, topK, query_0);
                console.log(`[FileManager2.performVectorSearch] Found ${results_0.length} results`);
                return {
                    success: true,
                    query: query_0,
                    results: results_0.map({
                        "FileManager2.useCallback[performVectorSearch]": (r)=>({
                                id: r.id,
                                documentId: r.documentId || r.metadata?.documentId,
                                fileId: r.metadata?.fileId,
                                fileName: r.metadata?.fileName,
                                page: r.page,
                                similarity: r.similarity,
                                text: includeText ? r.text : undefined,
                                metadata: r.metadata
                            })
                    }["FileManager2.useCallback[performVectorSearch]"])
                };
            } catch (error_0) {
                console.error("[FileManager2.performVectorSearch] Error:", error_0);
                return {
                    success: false,
                    error: error_0.message,
                    query: query_0,
                    results: []
                };
            }
        }
    }["FileManager2.useCallback[performVectorSearch]"], [
        vectorStore
    ]);
    // Enhanced text search function — uses vector store when available
    const performSemanticSearch = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "FileManager2.useCallback[performSemanticSearch]": async (query_1)=>{
            if (!query_1.trim()) {
                setSemanticResults(null);
                return;
            }
            setSearching(true);
            try {
                if (vectorStoreReady) {
                    // Use actual vector search when embeddings are loaded
                    const { results } = await performVectorSearch(query_1);
                    if (results && results.length > 0) {
                        setSemanticResults(results);
                        return;
                    }
                }
                // Fallback to text search
                performSimpleTextSearch(query_1);
            } finally{
                setSearching(false);
            }
        }
    }["FileManager2.useCallback[performSemanticSearch]"], [
        vectorStoreReady,
        performVectorSearch,
        performSimpleTextSearch
    ]);
    // Filter files based on search term and mode
    const filteredFiles = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "FileManager2.useMemo[filteredFiles]": ()=>{
            if (!search.trim()) return files;
            const searchLower = search.toLowerCase();
            // Helper: Check if file matches keyword search
            const matchesKeyword = {
                "FileManager2.useMemo[filteredFiles].matchesKeyword": (file_1)=>{
                    // Search in filename
                    if (containsSearchTerm(file_1.name, search)) return true;
                    // Search in file description/summary
                    if (file_1.description && containsSearchTerm(file_1.description, search)) return true;
                    // Search in metadata if available
                    if (file_1.metadata) {
                        const metadataStr = JSON.stringify(file_1.metadata);
                        if (containsSearchTerm(metadataStr, search)) return true;
                    }
                    return false;
                }
            }["FileManager2.useMemo[filteredFiles].matchesKeyword"];
            // Mode-specific filtering
            if (searchMode === "keyword") {
                // Pure keyword search with highlighting
                return files.filter(matchesKeyword);
            }
            if (searchMode === "semantic") {
                // Pure semantic search (requires embeddings)
                if (!semanticResults) return files.filter(matchesKeyword); // Fallback to keyword
                // Sort by semantic similarity score (using max page score)
                return files.map({
                    "FileManager2.useMemo[filteredFiles]": (file_2)=>({
                            file: file_2,
                            score: semanticResults[file_2.id]?.maxScore || 0,
                            pages: semanticResults[file_2.id]?.pages || []
                        })
                }["FileManager2.useMemo[filteredFiles]"]).filter({
                    "FileManager2.useMemo[filteredFiles]": (item)=>item.score > 0.5
                }["FileManager2.useMemo[filteredFiles]"]) // Threshold for relevance
                .sort({
                    "FileManager2.useMemo[filteredFiles]": (a_0, b_0)=>b_0.score - a_0.score
                }["FileManager2.useMemo[filteredFiles]"]).map({
                    "FileManager2.useMemo[filteredFiles]": (item_0)=>item_0.file
                }["FileManager2.useMemo[filteredFiles]"]);
            }
            // Hybrid: Combine keyword and semantic
            if (searchMode === "hybrid") {
                // Filter out null items before processing
                const validFiles = files.filter({
                    "FileManager2.useMemo[filteredFiles].validFiles": (f_2)=>f_2 != null && f_2.id != null
                }["FileManager2.useMemo[filteredFiles].validFiles"]);
                const keywordMatches = new Set(validFiles.filter(matchesKeyword).map({
                    "FileManager2.useMemo[filteredFiles]": (f_3)=>f_3.id
                }["FileManager2.useMemo[filteredFiles]"]));
                if (!semanticResults) {
                    // No semantic results yet, use keyword only
                    return files.filter({
                        "FileManager2.useMemo[filteredFiles]": (f_4)=>keywordMatches.has(f_4.id)
                    }["FileManager2.useMemo[filteredFiles]"]);
                }
                // Combine: Include keyword matches + high-scoring semantic matches (best page)
                return files.map({
                    "FileManager2.useMemo[filteredFiles]": (file_3)=>{
                        const keywordMatch = keywordMatches.has(file_3.id);
                        const semanticScore = semanticResults[file_3.id]?.maxScore || 0;
                        const pages = semanticResults[file_3.id]?.pages || [];
                        // Boost score if keyword match
                        const finalScore = keywordMatch ? semanticScore + 0.5 : semanticScore;
                        return {
                            file: file_3,
                            score: finalScore,
                            keywordMatch,
                            pages
                        };
                    }
                }["FileManager2.useMemo[filteredFiles]"]).filter({
                    "FileManager2.useMemo[filteredFiles]": (item_1)=>item_1.keywordMatch || item_1.score > 0.4
                }["FileManager2.useMemo[filteredFiles]"]).sort({
                    "FileManager2.useMemo[filteredFiles]": (a_1, b_1)=>b_1.score - a_1.score
                }["FileManager2.useMemo[filteredFiles]"]).map({
                    "FileManager2.useMemo[filteredFiles]": (item_2)=>item_2.file
                }["FileManager2.useMemo[filteredFiles]"]);
            }
            return files;
        }
    }["FileManager2.useMemo[filteredFiles]"], [
        files,
        search,
        searchMode,
        semanticResults,
        documentStatuses
    ]);
    // Helper function to organize files by protection level
    const organizeFilesByProtectionLevel = (files_0)=>{
        const organized = {
            PRIVATE: {
                images: [],
                audio: [],
                documents: [],
                video: [],
                scripts: [],
                other: []
            },
            PUBLIC: {
                images: [],
                audio: [],
                documents: [],
                video: [],
                scripts: [],
                other: []
            },
            PROTECTED: {
                images: [],
                audio: [],
                documents: [],
                video: [],
                scripts: [],
                other: []
            },
            UNSET: {
                images: [],
                audio: [],
                documents: [],
                video: [],
                scripts: [],
                other: []
            }
        };
        files_0.forEach((file_4)=>{
            // Default to UNSET if no level property
            const level = file_4.level || "UNSET";
            const mimeType = file_4.mimeType || "";
            // Make sure the level exists in organized
            if (!organized[level]) {
                organized[level] = {
                    images: [],
                    audio: [],
                    documents: [],
                    video: [],
                    scripts: [],
                    other: []
                };
            }
            if (mimeType.includes("image")) {
                organized[level].images.push(file_4);
            } else if (mimeType.includes("audio")) {
                organized[level].audio.push(file_4);
            } else if (mimeType.includes("video")) {
                organized[level].video.push(file_4);
            } else if (mimeType === "text/x-fountain") {
                organized[level].scripts.push(file_4);
            } else if (mimeType === "text/x-fountain") {
                organized[level].scripts.push(file_4);
            } else if (mimeType === "application/pdf" || mimeType === "text/plain" || mimeType === "text/markdown" || mimeType === "text/csv" || mimeType === "application/msword" || mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
                organized[level].documents.push(file_4);
            } else {
                // Default to 'other' for unrecognized types
                organized[level].other.push(file_4);
            }
        });
        return organized;
    };
    const organizedFiles = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "FileManager2.useMemo[organizedFiles]": ()=>organizeFilesByProtectionLevel(filteredFiles)
    }["FileManager2.useMemo[organizedFiles]"], [
        filteredFiles
    ]);
    // Flatten file organization into a flat list with headers/subheaders
    const fileListItems = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "FileManager2.useMemo[fileListItems]": ()=>{
            const items = [];
            // For each protection level
            Object.entries(organizedFiles).forEach({
                "FileManager2.useMemo[fileListItems]": ([protectionLevel_0, filesByType])=>{
                    const totalFiles = Object.values(filesByType).reduce({
                        "FileManager2.useMemo[fileListItems].totalFiles": (sum_0, files_1)=>sum_0 + files_1.length
                    }["FileManager2.useMemo[fileListItems].totalFiles"], 0);
                    if (totalFiles === 0) return;
                    const isCollapsed = collapsedProtectionLevels.has(protectionLevel_0);
                    // Add protection level header
                    items.push({
                        type: "protection-header",
                        level: protectionLevel_0,
                        label: protectionLevel_0,
                        id: `header-${protectionLevel_0}`,
                        totalFiles,
                        isExpanded: !isCollapsed,
                        onToggleExpand: {
                            "FileManager2.useMemo[fileListItems]": ()=>handleToggleProtectionLevelCollapse(protectionLevel_0)
                        }["FileManager2.useMemo[fileListItems]"]
                    });
                    // If collapsed, skip rendering files
                    if (isCollapsed) return;
                    // For each file type (images, audio, documents, video, scripts, other)
                    [
                        "images",
                        "audio",
                        "documents",
                        "video",
                        "scripts",
                        "other"
                    ].forEach({
                        "FileManager2.useMemo[fileListItems]": (fileType)=>{
                            const fileTypeFiles = filesByType[fileType] || [];
                            if (fileTypeFiles.length > 0) {
                                // Add file type subheader
                                const label = fileType.charAt(0).toUpperCase() + fileType.slice(1);
                                const fileTypeKey_0 = `${protectionLevel_0}-${fileType}`;
                                const isFileTypeCollapsed = collapsedFileTypes.has(fileTypeKey_0);
                                items.push({
                                    type: "filetype-subheader",
                                    fileType,
                                    label: `${label} (${fileTypeFiles.length})`,
                                    id: `subheader-${protectionLevel_0}-${fileType}`,
                                    fileTypeKey: fileTypeKey_0,
                                    isExpanded: !isFileTypeCollapsed,
                                    onToggleExpand: {
                                        "FileManager2.useMemo[fileListItems]": ()=>handleToggleFileTypeCollapse(fileTypeKey_0)
                                    }["FileManager2.useMemo[fileListItems]"]
                                });
                                // If collapsed, skip rendering files
                                if (isFileTypeCollapsed) return;
                                // Add individual files
                                fileTypeFiles.forEach({
                                    "FileManager2.useMemo[fileListItems]": (file_5)=>{
                                        items.push({
                                            type: "file",
                                            file: file_5,
                                            fileType,
                                            id: file_5.id
                                        });
                                    }
                                }["FileManager2.useMemo[fileListItems]"]);
                            }
                        }
                    }["FileManager2.useMemo[fileListItems]"]);
                }
            }["FileManager2.useMemo[fileListItems]"]);
            return items;
        }
    }["FileManager2.useMemo[fileListItems]"], [
        organizedFiles,
        collapsedProtectionLevels,
        handleToggleProtectionLevelCollapse,
        collapsedFileTypes,
        handleToggleFileTypeCollapse
    ]);
    // Setup parent ref for virtualized scrolling
    const parentRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    // Setup virtualizer for performance with dynamic measurement
    const virtualizer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"])({
        count: fileListItems.length,
        getScrollElement: {
            "FileManager2.useVirtualizer[virtualizer]": ()=>parentRef?.current
        }["FileManager2.useVirtualizer[virtualizer]"],
        estimateSize: {
            "FileManager2.useVirtualizer[virtualizer]": (index_0)=>{
                const item_3 = fileListItems[index_0];
                if (item_3.type === "protection-header") return 48;
                if (item_3.type === "filetype-subheader") return 36;
                // File rows: initial estimate, will be replaced by actual measurements
                return 140;
            }
        }["FileManager2.useVirtualizer[virtualizer]"],
        // Enable dynamic measurement with ResizeObserver
        measureElement: {
            "FileManager2.useVirtualizer[virtualizer]": (element)=>{
                // Return actual height of the rendered element
                return element?.getBoundingClientRect().height ?? 140;
            }
        }["FileManager2.useVirtualizer[virtualizer]"],
        overscan: 3
    });
    // Note: Settings are now provided by SettingsContext
    // Get settings from context instead of local subscription
    const settingsContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const settings = settingsContext?.settings || null;
    // Global platform override for auto-analyze
    const { autoAnalyzeDocuments: globalAutoAnalyze } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePlatformSettings"])();
    // Periodic cleanup of old sessionStorage drafts (run every 5 minutes)
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FileManager2.useEffect": ()=>{
            const cleanupDrafts = {
                "FileManager2.useEffect.cleanupDrafts": ()=>{
                    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
                    ;
                    // Clean up old drafts for files that no longer exist
                    for(let i = 0; i < sessionStorage.length; i++){
                        const key = sessionStorage.key(i);
                        if (key && key.startsWith("draft_file_name_")) {
                            try {
                                const fileId_1 = key.replace("draft_file_name_", "");
                                const fileExists = files.some({
                                    "FileManager2.useEffect.cleanupDrafts.fileExists": (f_5)=>f_5.id === fileId_1
                                }["FileManager2.useEffect.cleanupDrafts.fileExists"]);
                                if (!fileExists) {
                                    sessionStorage.removeItem(key);
                                }
                            } catch (e_3) {
                                console.warn("Could not process draft item:", key);
                                sessionStorage.removeItem(key); // Remove corrupted items
                            }
                        }
                    }
                }
            }["FileManager2.useEffect.cleanupDrafts"];
            cleanupDrafts(); // Run once on mount
            const interval = setInterval(cleanupDrafts, 5 * 60 * 1000); // Run every 5 minutes
            return ({
                "FileManager2.useEffect": ()=>clearInterval(interval)
            })["FileManager2.useEffect"];
        }
    }["FileManager2.useEffect"], [
        files
    ]);
    // Helper function to get status display info
    const getDocumentStatusInfo = (status)=>{
        const statusConfig = {
            uploaded: {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudUpload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 4581,
                    columnNumber: 15
                }, this),
                color: "default",
                label: "Ready",
                chipColor: "default"
            },
            extracting: {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$HourglassEmpty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 4587,
                    columnNumber: 15
                }, this),
                color: "info",
                label: "Extracting...",
                chipColor: "info"
            },
            extracted: {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$HourglassEmpty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 4593,
                    columnNumber: 15
                }, this),
                color: "primary",
                label: "Extracted",
                chipColor: "primary"
            },
            analyzing: {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$HourglassEmpty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 4599,
                    columnNumber: 15
                }, this),
                color: "warning",
                label: "Analyzing...",
                chipColor: "warning"
            },
            completed: {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 4605,
                    columnNumber: 15
                }, this),
                color: "success",
                label: "Analyzed",
                chipColor: "success"
            },
            failed: {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 4611,
                    columnNumber: 15
                }, this),
                color: "error",
                label: "Failed",
                chipColor: "error"
            }
        };
        return statusConfig[status] || statusConfig["uploaded"];
    };
    const toggleNewAudioFileForm = ()=>{
        setNewAudioFileFormOpen(!newAudioFileFormOpen);
    };
    const toggleNewImageFileForm = ()=>{
        setNewImageFileFormOpen(!newImageFileFormOpen);
    };
    const toggleNewVideoFileForm = ()=>{
        setNewVideoFileFormOpen(!newVideoFileFormOpen);
    };
    const toggleNewFileForm = ()=>{
        const newState = !newFileFormOpen;
        setNewFileFormOpen(newState);
        // When opening, also open the form for the current tab
        if (newState) {
            if (generator === "image") {
                setNewImageFileFormOpen(true);
            } else if (generator === "audio") {
                setNewAudioFileFormOpen(true);
            } else if (generator === "video") {
                setNewVideoFileFormOpen(true);
            }
        } else {
            // When closing, close all forms
            setNewImageFileFormOpen(false);
            setNewAudioFileFormOpen(false);
            setNewVideoFileFormOpen(false);
        }
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "FileManager2.useEffect": ()=>{
            const asyncFunc = {
                "FileManager2.useEffect.asyncFunc": async ()=>{
                    // when files change, upload them to S3
                    // and update the entry in the database
                    console.log("[FileManager2] Upload useEffect triggered. filesToUpload:", filesToUpload.length, "uploadInProgress:", uploadInProgressRef.current);
                    if (filesToUpload.length === 0 || uploadInProgressRef.current) {
                        console.log("[FileManager2] Skipping upload - no files or already in progress");
                        return;
                    }
                    uploadInProgressRef.current = true;
                    console.log("[FileManager2] About to start upload. filesToUpload:", filesToUpload.length, filesToUpload);
                    const fileKeys = await Promise.allSettled(filesToUpload.map({
                        "FileManager2.useEffect.asyncFunc": async (fileInput, mapIndex)=>{
                            const { file: file_6, index: index_1 } = fileInput;
                            const progressIndex = index_1 !== undefined ? index_1 : mapIndex;
                            console.log("[FileManager2] Uploading file:", file_6.name, "identityId:", identityId, "unitId:", unit?.id);
                            try {
                                // Use shared utility for file upload
                                const result_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadFile"])(file_6, identityId, unit?.id, {
                                    "FileManager2.useEffect.asyncFunc": (loaded, total)=>{
                                        setFileOperations({
                                            "FileManager2.useEffect.asyncFunc": (prev_2)=>{
                                                const newFileOperations = [
                                                    ...prev_2
                                                ];
                                                if (newFileOperations[progressIndex]) {
                                                    newFileOperations[progressIndex].progress = Math.round(loaded / total * 100) + "%";
                                                }
                                                return newFileOperations;
                                            }
                                        }["FileManager2.useEffect.asyncFunc"]);
                                    }
                                }["FileManager2.useEffect.asyncFunc"]);
                                console.log("[FileManager2] Upload result:", {
                                    fileId: result_0?.fileModel?.id,
                                    fileName: result_0?.fileModel?.name,
                                    documentId: result_0?.documentModel?.id
                                });
                                // If analyzable document and auto-analyze is enabled, trigger both analysis and embeddings in parallel
                                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAnalyzableDocument"])(file_6.type) && globalAutoAnalyze && settings?.autoAnalyzeDocuments && result_0.documentModel) {
                                    console.log("Auto-analyzing and generating embeddings for document:", result_0.fileModel.id, "type:", file_6.type);
                                    // Run both in parallel - don't await
                                    Promise.allSettled([
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["analyzePDF"])(result_0.fileModel.id),
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateEmbeddings"])(result_0.fileModel.id)
                                    ]).then({
                                        "FileManager2.useEffect.asyncFunc": (results_1)=>{
                                            const analysisResult = results_1[0].status === "fulfilled" ? results_1[0].value : null;
                                            const embeddingsResult = results_1[1].status === "fulfilled" ? results_1[1].value : null;
                                            if (analysisResult) console.log("Auto-analysis completed:", analysisResult);
                                            if (embeddingsResult) console.log("Embeddings generation completed:", embeddingsResult);
                                            if (results_1[0].status === "rejected") {
                                                const error_2 = results_1[0].reason;
                                                if (error_2?.message?.includes("currently being processed") || error_2?.message?.includes("already been analyzed")) {
                                                    console.log("Document processing already in progress or completed:", error_2.message);
                                                } else {
                                                    console.error("Auto-processing failed:", error_2);
                                                }
                                            }
                                        }
                                    }["FileManager2.useEffect.asyncFunc"]);
                                }
                            } catch (error_1) {
                                console.error("Error uploading file:", error_1);
                                return {
                                    status: "rejected",
                                    reason: error_1
                                };
                            }
                        }
                    }["FileManager2.useEffect.asyncFunc"]));
                    // Check results and log any failures
                    const failures = fileKeys.filter({
                        "FileManager2.useEffect.asyncFunc.failures": (result_1)=>result_1.status === "rejected"
                    }["FileManager2.useEffect.asyncFunc.failures"]);
                    if (failures.length > 0) {
                        console.error(`${failures.length} file(s) failed to upload:`, failures);
                        failures.forEach({
                            "FileManager2.useEffect.asyncFunc": (failure, index_2)=>{
                                console.error(`File ${index_2 + 1} error:`, failure.reason);
                            }
                        }["FileManager2.useEffect.asyncFunc"]);
                    }
                    const successes = fileKeys.filter({
                        "FileManager2.useEffect.asyncFunc.successes": (result_2)=>result_2.status === "fulfilled"
                    }["FileManager2.useEffect.asyncFunc.successes"]);
                    console.log(`[FileManager2] Upload complete. ${successes.length} succeeded, ${failures.length} failed`);
                    // timeout to allow for the UI to update
                    setTimeout({
                        "FileManager2.useEffect.asyncFunc": ()=>{
                            setFilesToUpload([]);
                            setFileOperations([]);
                            uploadInProgressRef.current = false;
                        }
                    }["FileManager2.useEffect.asyncFunc"], 1000);
                }
            }["FileManager2.useEffect.asyncFunc"];
            asyncFunc();
        }
    }["FileManager2.useEffect"], [
        filesToUpload
    ]);
    // const audioUrls = entry?.audioUrls || [];
    const handleDragOver = (event_0)=>{
        event_0.preventDefault();
        setIsDragging(true);
    };
    const handleDrop = async (event_1)=>{
        console.log("dropped");
        event_1.preventDefault();
        //   event.stopPropagation();
        console.log(event_1.dataTransfer.files);
        const _files = Array.from(event_1.dataTransfer.files);
        console.log("files>>>>", _files);
        const _toupload = _files.map((f_6, index_3)=>{
            return {
                file: f_6,
                index: index_3
            };
        });
        const _fileOperations = _files.map((f_7)=>({
                name: f_7.name,
                progress: "0%"
            }));
        console.log("_toupload", _toupload);
        console.log("_fileOperations", _fileOperations);
        setFilesToUpload(_toupload);
        setFileOperations(_fileOperations);
        setIsDragging(false);
    };
    const handleChange = (event_2)=>{
        console.log("handleChange", event_2.target.value);
    };
    // Context value for VectorStoreContext
    const vectorStoreContextValue = {
        vectorStore,
        search: performVectorSearch,
        isReady: vectorStore.loaded && vectorStore.items.length > 0
    };
    // Context value for FileManagerProvider
    const fileManagerContextValue = {
        search,
        expandedItems,
        selectedItems,
        documentStatuses,
        handleToggleSelect,
        handleFileNameUpdate,
        setConfirmDialog,
        setGenerator,
        setSelectedDocument,
        remove: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["remove"]
    };
    try {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$vectorStoreContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
            value: vectorStoreContextValue,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$FileManagerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileManagerProvider"], {
                value: fileManagerContextValue,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        height: "100%",
                        minHeight: 0,
                        display: "flex",
                        flexDirection: "column",
                        borderRadius: 1,
                        position: "relative"
                    },
                    onDragOver: handleDragOver,
                    onDragLeave: ()=>setIsDragging(false),
                    onDrop: handleDrop,
                    children: [
                        fileOperations.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                            variant: "determinate",
                            value: uploadProgress,
                            sx: {
                                position: "absolute",
                                top: 0,
                                left: 0,
                                right: 0,
                                zIndex: 1100,
                                height: 3,
                                borderRadius: "1px 1px 0 0"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 4800,
                            columnNumber: 43
                        }, this),
                        isDragging && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                position: "absolute",
                                top: 0,
                                left: 0,
                                right: 0,
                                bottom: 0,
                                bgcolor: "rgba(25, 118, 210, 0.08)",
                                border: "3px dashed",
                                borderColor: "primary.main",
                                borderRadius: 1,
                                zIndex: 1000,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                pointerEvents: "none"
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "center",
                                    gap: 2,
                                    p: 4,
                                    bgcolor: "background.paper",
                                    borderRadius: 2,
                                    boxShadow: 3
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudUpload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        sx: {
                                            fontSize: 64,
                                            color: "primary.main"
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 4836,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h6",
                                        color: "primary",
                                        children: t1("fileManager2.dragDrop.dropFilesHere")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 4840,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "body2",
                                        color: "text.secondary",
                                        children: t1("fileManager2.dragDrop.supportedFormats")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 4843,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 4826,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 4810,
                            columnNumber: 28
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                bgcolor: "background.paper",
                                borderBottom: "1px solid",
                                borderColor: "divider",
                                display: "flex",
                                gap: 0,
                                alignItems: "center",
                                px: 1,
                                py: 0.5
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        display: "flex",
                                        gap: 0,
                                        alignItems: "center"
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                        title: t1("fileManager2.toolbar.selectAllTooltip"),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                                                size: "small",
                                                checked: Boolean(files && files.length > 0 && selectedItems.size === files.length),
                                                indeterminate: selectedItems.size > 0 && selectedItems.size < files.length,
                                                onChange: (e_4)=>{
                                                    if (e_4.target.checked) {
                                                        handleSelectAll();
                                                    } else {
                                                        handleDeselectAll();
                                                    }
                                                },
                                                disabled: !files || files.length === 0,
                                                sx: {
                                                    p: 0.25
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                lineNumber: 4865,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 4864,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 4863,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 4858,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                    value: search,
                                    onInput: handleSearch,
                                    size: "small",
                                    placeholder: t1("fileManager2.toolbar.searchPlaceholder"),
                                    sx: {
                                        flex: 1,
                                        minWidth: "100px",
                                        mx: 1
                                    },
                                    InputProps: {
                                        startAdornment: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$InputAdornment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputAdornment$3e$__["InputAdornment"], {
                                            position: "start",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                fontSize: "small"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                lineNumber: 4885,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 4884,
                                            columnNumber: 31
                                        }, this)
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 4879,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                    title: t1("fileManager2.toolbar.uploadTooltip"),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                        onClick: ()=>{
                                            document.getElementById("file-upload-input")?.click();
                                        },
                                        color: "primary",
                                        size: "small",
                                        "aria-label": t1("fileManager2.toolbar.uploadTooltip"),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$UploadFile$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            fontSize: "small"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 4893,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 4890,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 4889,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                    title: t1("fileManager2.toolbar.recordConversation", "Generate Conversation"),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                        onClick: ()=>setEnhancedStudioOpen(true),
                                        size: "small",
                                        "aria-label": t1("fileManager2.toolbar.recordConversation", "Record Conversation"),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Mic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            fontSize: "small"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 4899,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 4898,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 4897,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                    title: t1("fileManager2.toolbar.actionsTooltip"),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                            onClick: (e_5)=>setContextMenu(contextMenu ? null : {
                                                    mouseX: e_5.clientX,
                                                    mouseY: e_5.clientY
                                                }),
                                            size: "small",
                                            disabled: selectedItems.size === 0,
                                            "aria-label": t1("fileManager2.toolbar.actionsTooltip"),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                lineNumber: 4909,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 4905,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 4904,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 4903,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                    open: contextMenu !== null,
                                    onClose: ()=>setContextMenu(null),
                                    anchorReference: "anchorPosition",
                                    anchorPosition: contextMenu !== null ? {
                                        top: contextMenu.mouseY,
                                        left: contextMenu.mouseX
                                    } : undefined,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                            onClick: ()=>{
                                                handleDeselectAll();
                                                setContextMenu(null);
                                            },
                                            children: t1("fileManager2.contextMenu.deselectAll")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 4920,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                            onClick: ()=>{
                                                setContextMenu(null);
                                                setConfirmDialog({
                                                    open: true,
                                                    message: `Move ${selectedItems.size} file(s) to Recycle Bin?`,
                                                    severity: "warning",
                                                    onConfirm: async ()=>{
                                                        console.log("[FileManager2] Starting soft delete for", selectedItems.size, "files");
                                                        const deleteErrors = [];
                                                        for (const fileId_2 of selectedItems){
                                                            const file_7 = files.find((f_8)=>f_8.id === fileId_2);
                                                            if (file_7) {
                                                                try {
                                                                    console.log("[FileManager2] Soft deleting file:", file_7.name, file_7.id);
                                                                    await softDeleteRecord1("File", file_7.id);
                                                                    console.log("[FileManager2] Successfully soft deleted:", file_7.name);
                                                                } catch (error_3) {
                                                                    console.error("[FileManager2] Failed to soft delete file:", file_7.name, error_3);
                                                                    deleteErrors.push({
                                                                        file: file_7.name,
                                                                        error: error_3.message
                                                                    });
                                                                }
                                                            }
                                                        }
                                                        setSelectedItems(new Set());
                                                        if (deleteErrors.length > 0) {
                                                            console.error("[FileManager2] Soft delete completed with errors:", deleteErrors);
                                                            setConfirmDialog({
                                                                open: true,
                                                                message: `Failed to move ${deleteErrors.length} file(s) to Recycle Bin: ${deleteErrors.map((e_6)=>e_6.file).join(", ")}`,
                                                                severity: "error",
                                                                onConfirm: ()=>setConfirmDialog({
                                                                        open: false,
                                                                        message: "",
                                                                        onConfirm: null,
                                                                        severity: "warning"
                                                                    })
                                                            });
                                                        } else {
                                                            console.log("[FileManager2] All files soft deleted successfully");
                                                            setConfirmDialog({
                                                                open: false,
                                                                message: "",
                                                                onConfirm: null,
                                                                severity: "warning"
                                                            });
                                                        }
                                                    }
                                                });
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    fontSize: "small",
                                                    sx: {
                                                        mr: 1
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                    lineNumber: 4981,
                                                    columnNumber: 19
                                                }, this),
                                                t1("fileManager2.contextMenu.deleteSelected", {
                                                    count: selectedItems.size
                                                })
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 4930,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                            onClick: ()=>{
                                                setContextMenu(null);
                                                selectedItems.forEach(async (fileId_3)=>{
                                                    const file_8 = files.find((f_9)=>f_9.id === fileId_3);
                                                    if (file_8) {
                                                        try {
                                                            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAnalyzableDocument"])(file_8.mimeType)) {
                                                                console.log("[FileManager2] Re-analyzing document:", file_8.name, "type:", file_8.mimeType);
                                                                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["analyzePDF"])(file_8.id);
                                                                console.log("[FileManager2] Generating embeddings for:", file_8.name);
                                                                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateEmbeddings"])(file_8.id);
                                                            } else if (file_8.documentID) {
                                                                console.log("[FileManager2] Re-generating embeddings for:", file_8.name);
                                                                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fileUploadUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateEmbeddings"])(file_8.id);
                                                            } else {
                                                                console.warn("[FileManager2] Cannot re-analyze - not an analyzable document and no documentID:", file_8.name, file_8.mimeType);
                                                            }
                                                        } catch (error_4) {
                                                            console.error("[FileManager2] Error re-analyzing document:", file_8.name, error_4);
                                                        }
                                                    }
                                                });
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Autorenew$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    fontSize: "small",
                                                    sx: {
                                                        mr: 1
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                    lineNumber: 5015,
                                                    columnNumber: 19
                                                }, this),
                                                t1("fileManager2.contextMenu.reAnalyzeSelected", {
                                                    count: selectedItems.size
                                                })
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 4992,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 4913,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ShowDeletedToggle$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    showDeleted: showDeleted,
                                    setShowDeleted: setShowDeleted
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 5023,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 4848,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                width: "100%",
                                flex: 1,
                                overflow: "auto",
                                minHeight: 0,
                                display: "flex",
                                flexDirection: "row"
                            },
                            children: [
                                !files?.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        width: "100%",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        p: 3,
                                        color: "text.secondary"
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        children: t1("fileManager2.mainView.noFilesMessage")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 5044,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 5036,
                                    columnNumber: 33
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            ref: parentRef,
                                            sx: {
                                                flex: "0 0 35%",
                                                borderRight: "1px solid",
                                                borderColor: "divider",
                                                overflow: "auto",
                                                overflowX: "hidden",
                                                height: "100%",
                                                display: "flex",
                                                flexDirection: "column",
                                                minWidth: 0,
                                                scrollbarWidth: "thin",
                                                scrollbarColor: (theme)=>`${theme.palette.action.disabled} transparent`,
                                                "&::-webkit-scrollbar": {
                                                    width: "8px"
                                                },
                                                "&::-webkit-scrollbar-track": {
                                                    background: "transparent"
                                                },
                                                "&::-webkit-scrollbar-thumb": {
                                                    background: (theme_0)=>theme_0.palette.action.disabled,
                                                    borderRadius: "4px",
                                                    "&:hover": {
                                                        background: (theme_1)=>theme_1.palette.action.active
                                                    }
                                                }
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    height: `${virtualizer.getTotalSize()}px`,
                                                    width: "100%",
                                                    position: "relative",
                                                    display: "flex",
                                                    flexDirection: "column",
                                                    boxSizing: "border-box"
                                                },
                                                children: (()=>{
                                                    const virtualItems = virtualizer.getVirtualItems();
                                                    return virtualItems.map((virtualRow)=>{
                                                        const item_4 = fileListItems[virtualRow.index];
                                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            "data-index": virtualRow.index,
                                                            ref: virtualizer.measureElement,
                                                            style: {
                                                                position: "absolute",
                                                                top: 0,
                                                                left: 0,
                                                                width: "100%",
                                                                transform: `translateY(${virtualRow.start}px)`
                                                            },
                                                            children: [
                                                                item_4.type === "protection-header" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                                    onClick: (e_7)=>{
                                                                        e_7.stopPropagation();
                                                                        item_4.onToggleExpand?.();
                                                                    },
                                                                    sx: {
                                                                        px: 2,
                                                                        pl: 0.625,
                                                                        py: 1.5,
                                                                        bgcolor: (theme_2)=>theme_2.vars ? `rgba(${theme_2.vars.palette.primary.mainChannel} / 0.08)` : theme_2.palette.action.hover,
                                                                        borderBottom: "1px solid",
                                                                        borderLeft: "3px solid transparent",
                                                                        borderColor: "divider",
                                                                        fontWeight: 600,
                                                                        fontSize: "0.95rem",
                                                                        display: "flex",
                                                                        alignItems: "center",
                                                                        gap: 1,
                                                                        color: "primary.main",
                                                                        cursor: "pointer",
                                                                        transition: "all 0.2s ease",
                                                                        "&:hover": {
                                                                            bgcolor: (theme_3)=>theme_3.vars ? `rgba(${theme_3.vars.palette.primary.mainChannel} / 0.14)` : theme_3.palette.action.focus
                                                                        }
                                                                    },
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                                            sx: {
                                                                                display: "flex",
                                                                                alignItems: "center",
                                                                                transition: "transform 0.2s",
                                                                                transform: item_4.isExpanded ? "rotate(0deg)" : "rotate(-90deg)"
                                                                            },
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                fontSize: "small"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                                                lineNumber: 5123,
                                                                                columnNumber: 37
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                                            lineNumber: 5117,
                                                                            columnNumber: 35
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Folder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                            fontSize: "small"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                                            lineNumber: 5125,
                                                                            columnNumber: 35
                                                                        }, this),
                                                                        item_4.label,
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                                                            label: item_4.totalFiles,
                                                                            size: "small",
                                                                            variant: "outlined",
                                                                            sx: {
                                                                                ml: "auto",
                                                                                height: "20px",
                                                                                fontSize: "0.7rem"
                                                                            },
                                                                            onClick: (e_8)=>e_8.stopPropagation()
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                                            lineNumber: 5127,
                                                                            columnNumber: 35
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                                    lineNumber: 5093,
                                                                    columnNumber: 71
                                                                }, this),
                                                                item_4.type === "filetype-subheader" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FileTypeSubheader, {
                                                                    label: item_4.label,
                                                                    fileType: item_4.fileType,
                                                                    isExpanded: item_4.isExpanded,
                                                                    onToggleExpand: item_4.onToggleExpand
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                                    lineNumber: 5134,
                                                                    columnNumber: 72
                                                                }, this),
                                                                item_4.type === "file" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FileRowComponent, {
                                                                    file: item_4.file,
                                                                    fileType: item_4.fileType,
                                                                    index: virtualRow.index,
                                                                    isSelected: selectedItems.has(item_4.file.id),
                                                                    allFiles: filteredFiles,
                                                                    selectedItems: selectedItems,
                                                                    setSelectedItems: setSelectedItems,
                                                                    search: search
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                                    lineNumber: 5136,
                                                                    columnNumber: 58
                                                                }, this)
                                                            ]
                                                        }, item_4.id, true, {
                                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                            lineNumber: 5086,
                                                            columnNumber: 30
                                                        }, this);
                                                    });
                                                })()
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                lineNumber: 5074,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 5048,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            sx: {
                                                flex: "0 0 65%",
                                                display: "flex",
                                                flexDirection: "column",
                                                overflow: "hidden",
                                                bgcolor: "background.paper",
                                                minWidth: 0
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SelectedFileDetailsPanel, {
                                                selectedItems: selectedItems,
                                                files: files,
                                                documentStatuses: documentStatuses,
                                                search: search,
                                                editor: editor
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                lineNumber: 5151,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 5143,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true),
                                generator === "image" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$EnhancedGenerators$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageGeneratorButton"], {
                                    open: newFileFormOpen,
                                    onSuccess: ()=>{
                                        setNewFileFormOpen(false);
                                        setNewImageFileFormOpen(false);
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 5156,
                                    columnNumber: 41
                                }, this),
                                generator === "audio" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$EnhancedGenerators$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AudioGeneratorButton"], {
                                    open: newFileFormOpen,
                                    onSuccess: ()=>{
                                        setNewFileFormOpen(false);
                                        setNewAudioFileFormOpen(false);
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 5160,
                                    columnNumber: 41
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    id: "file-upload-input",
                                    type: "file",
                                    multiple: true,
                                    accept: "image/*,audio/*,video/*,.pdf,.doc,.docx,.txt,.md,.csv,.xls,.xlsx,.ppt,.pptx,.fountain,.odt,.ods,.odp,.imscc,.epub,.gift,.qti.xml",
                                    hidden: true,
                                    "aria-label": t1("fileManager2.toolbar.uploadTooltip"),
                                    onChange: (e_9)=>{
                                        const files_2 = Array.from(e_9.target.files || []);
                                        console.log("[FileManager2] Files selected:", files_2.length, files_2.map((f_10)=>f_10.name));
                                        setFilesToUpload(files_2.map((f_11, index_4)=>({
                                                file: f_11,
                                                index: index_4
                                            })));
                                        setFileOperations(files_2.map((f_12)=>({
                                                name: f_12.name,
                                                progress: "0%"
                                            })));
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 5166,
                                    columnNumber: 15
                                }, this),
                                fileOperations.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        p: 1
                                    },
                                    children: fileOperations.map((fileOperation, index_5)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            sx: {
                                                display: "flex",
                                                flexDirection: "row",
                                                justifyContent: "space-between",
                                                alignItems: "center",
                                                py: 0.5
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    variant: "body2",
                                                    children: fileOperation.name
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                    lineNumber: 5190,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    variant: "body2",
                                                    children: fileOperation.progress
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                    lineNumber: 5193,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, index_5, true, {
                                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                            lineNumber: 5183,
                                            columnNumber: 67
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 5180,
                                    columnNumber: 45
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 5027,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__["Portal"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
                                open: confirmDialog.open,
                                anchorOrigin: {
                                    vertical: "top",
                                    horizontal: "center"
                                },
                                onClose: (event_3, reason)=>{
                                    if (reason === "clickaway") {
                                        return;
                                    }
                                    console.log("[Snackbar] onClose triggered");
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                    severity: confirmDialog.severity,
                                    sx: {
                                        width: "100%",
                                        minWidth: "300px",
                                        boxShadow: 3
                                    },
                                    action: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                        sx: {
                                            display: "flex",
                                            gap: 1,
                                            ml: 2
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                color: "inherit",
                                                size: "small",
                                                onClick: (e_10)=>{
                                                    e_10.stopPropagation();
                                                    console.log("[Snackbar] Confirm clicked");
                                                    if (confirmDialog.onConfirm) {
                                                        confirmDialog.onConfirm();
                                                    }
                                                },
                                                variant: "outlined",
                                                children: "Confirm"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                lineNumber: 5219,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                color: "inherit",
                                                size: "small",
                                                onClick: (e_11)=>{
                                                    e_11.stopPropagation();
                                                    console.log("[Snackbar] Cancel clicked");
                                                    setConfirmDialog({
                                                        open: false,
                                                        message: "",
                                                        onConfirm: null,
                                                        severity: "warning"
                                                    });
                                                },
                                                variant: "contained",
                                                children: "Cancel"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                                lineNumber: 5228,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                        lineNumber: 5214,
                                        columnNumber: 26
                                    }, this),
                                    children: confirmDialog.message
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                    lineNumber: 5210,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                                lineNumber: 5201,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 5200,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3Modal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            open: studioOpen,
                            onClose: ()=>{
                                setStudioOpen(false);
                                setStudioScriptFile(null);
                            },
                            onSave: handleStudioSave,
                            title: unit?.name ? `${t1("fileManager2.toolbar.recordConversation", "Record Conversation")}: ${unit.name}` : t1("fileManager2.toolbar.recordConversation", "Record Conversation"),
                            preset: "conversation",
                            scriptData: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$recordingStudioPresets$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createConversationPreset"])(unit?.name).scriptData,
                            lockedTracks: [],
                            identityId: identityId
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 5247,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudioEnhancedModal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            open: enhancedStudioOpen,
                            onClose: ()=>setEnhancedStudioOpen(false),
                            onSave: handleEnhancedStudioSave,
                            title: unit?.name ? `Generate Conversation: ${unit.name}` : "Generate Conversation",
                            metadata: {
                                unitId: unit?.id
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                            lineNumber: 5253,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                    lineNumber: 4791,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
                lineNumber: 4790,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 4789,
            columnNumber: 12
        }, this);
    } catch (err_2) {
        console.error("[FileManager2] Render error:", err_2);
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: t1("fileManager.errorRendering", {
                message: err_2?.message
            })
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/components/FileManager2.jsx",
            lineNumber: 5261,
            columnNumber: 12
        }, this);
    }
}
_s12(FileManager2, "rahT4NMPQ+kEpGfSz9425u7r1uk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecycleBin"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePlatformSettings"]
    ];
});
_c16 = FileManager2;
function _ExpandedFileContentSuggestedVocabularyOnImport(count) {
    console.log(`Imported ${count} vocabulary words`);
}
function _ExpandedFileContentSuggestedQuestionsOnImport(count_0) {
    console.log(`Imported ${count_0} questions`);
}
function _temp2() {}
function _FileTypeSubheaderGetIconForType(type) {
    switch(type){
        case "images":
            {
                return "\uD83D\uDDBC\uFE0F";
            }
        case "audio":
            {
                return "\uD83C\uDFB5";
            }
        case "documents":
            {
                return "\uD83D\uDCC4";
            }
        case "video":
            {
                return "\uD83C\uDFAC";
            }
        case "other":
            {
                return "\uD83D\uDCCE";
            }
        default:
            {
                return "\uD83D\uDCC1";
            }
    }
}
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16;
__turbopack_context__.k.register(_c, "InlineEditorField");
__turbopack_context__.k.register(_c1, "FileNameField");
__turbopack_context__.k.register(_c2, "MetadataEditor");
__turbopack_context__.k.register(_c3, "ExpandedFileContent");
__turbopack_context__.k.register(_c4, "NewImageFileForm");
__turbopack_context__.k.register(_c5, "NewVideoFileForm");
__turbopack_context__.k.register(_c6, "NewAudioFileForm");
__turbopack_context__.k.register(_c7, "ProtectionLevelHeader$React.memo");
__turbopack_context__.k.register(_c8, "ProtectionLevelHeader");
__turbopack_context__.k.register(_c9, "FileTypeSubheader");
__turbopack_context__.k.register(_c10, "FileDetailsPanel");
__turbopack_context__.k.register(_c11, "FileRowComponent");
__turbopack_context__.k.register(_c12, "ListItemImage$React.memo");
__turbopack_context__.k.register(_c13, "ListItemImage");
__turbopack_context__.k.register(_c14, "SelectedFileView");
__turbopack_context__.k.register(_c15, "SelectedFileDetailsPanel");
__turbopack_context__.k.register(_c16, "FileManager2");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_Editor3_components_FileManager2_jsx_1dpn_79._.js.map