(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/RecordingStudio3/RecordingSettings.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RecordingSettings,
    "getCleanupFilters",
    ()=>getCleanupFilters
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * RecordingSettings — Cleanup strength slider for audio recordings.
 *
 * Allows users to control how aggressively pre-submission audio cleanup
 * is applied to human recordings. TTS-generated takes are never processed.
 *
 * Strength levels:
 * - Off: No cleanup applied (raw recording uploaded)
 * - Light: Highpass @ 80 Hz only (removes sub-bass rumble)
 * - Standard: Highpass + compress + normalize (default)
 * - Aggressive: Highpass + RNNoise ML noise suppression + compress + normalize
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Slider/Slider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$InfoOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/InfoOutlined.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
const CLEANUP_LEVELS = [
    {
        value: 0,
        label: "Off",
        key: "off"
    },
    {
        value: 1,
        label: "Light",
        key: "light"
    },
    {
        value: 2,
        label: "Standard",
        key: "standard"
    },
    {
        value: 3,
        label: "Aggressive",
        key: "aggressive"
    }
];
const LEVEL_DESCRIPTIONS = {
    off: "No audio cleanup. Raw recording is uploaded as-is.",
    light: "Removes low-frequency rumble (desk vibration, handling noise).",
    standard: "Removes rumble, evens volume, normalizes loudness.",
    aggressive: "ML noise suppression (removes fan, AC, keyboard noise) + compression + normalization."
};
function getCleanupFilters(strength) {
    switch(strength){
        case "off":
            return new Set();
        case "light":
            return new Set([
                "derumble"
            ]);
        case "standard":
            return new Set([
                "derumble",
                "compress",
                "normalize"
            ]);
        case "aggressive":
            return new Set([
                "derumble",
                "noisecancel",
                "compress",
                "normalize"
            ]);
        default:
            return new Set([
                "derumble",
                "compress",
                "normalize"
            ]);
    }
}
function RecordingSettings(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23);
    if ($[0] !== "6cd763303be91c84de99359f2beb6537f7ecafd9b69757934ab5a0c42f797529") {
        for(let $i = 0; $i < 23; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6cd763303be91c84de99359f2beb6537f7ecafd9b69757934ab5a0c42f797529";
    }
    const { value, onChange } = t0;
    let t1;
    if ($[1] !== value) {
        t1 = CLEANUP_LEVELS.find({
            "RecordingSettings[CLEANUP_LEVELS.find()]": (l)=>l.key === value
        }["RecordingSettings[CLEANUP_LEVELS.find()]"]) || CLEANUP_LEVELS[2];
        $[1] = value;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const currentLevel = t1;
    let t2;
    if ($[3] !== onChange) {
        t2 = ({
            "RecordingSettings[handleSliderChange]": (_, newValue)=>{
                const level = CLEANUP_LEVELS[newValue];
                if (level && onChange) {
                    onChange(level.key);
                }
            }
        })["RecordingSettings[handleSliderChange]"];
        $[3] = onChange;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const handleSliderChange = t2;
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            px: 2,
            py: 1
        };
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            display: "flex",
            alignItems: "center",
            gap: 0.5,
            mb: 1
        };
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle2",
            color: "text.secondary",
            children: "Recording Cleanup"
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/RecordingSettings.jsx",
            lineNumber: 120,
            columnNumber: 10
        }, this);
        $[6] = t4;
        $[7] = t5;
    } else {
        t4 = $[6];
        t5 = $[7];
    }
    const t6 = LEVEL_DESCRIPTIONS[currentLevel.key];
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$InfoOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: 16,
                color: "text.disabled"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/RecordingSettings.jsx",
            lineNumber: 130,
            columnNumber: 10
        }, this);
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] !== t6) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t4,
            children: [
                t5,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    title: t6,
                    arrow: true,
                    children: t7
                }, void 0, false, {
                    fileName: "[project]/src/components/RecordingStudio3/RecordingSettings.jsx",
                    lineNumber: 140,
                    columnNumber: 27
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/RecordingSettings.jsx",
            lineNumber: 140,
            columnNumber: 10
        }, this);
        $[9] = t6;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    const t9 = currentLevel.value;
    let t10;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = CLEANUP_LEVELS.map(_RecordingSettingsCLEANUP_LEVELSMap);
        $[11] = t10;
    } else {
        t10 = $[11];
    }
    let t11;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            maxWidth: 240
        };
        $[12] = t11;
    } else {
        t11 = $[12];
    }
    let t12;
    if ($[13] !== currentLevel.value || $[14] !== handleSliderChange) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            value: t9,
            onChange: handleSliderChange,
            min: 0,
            max: 3,
            step: 1,
            marks: t10,
            size: "small",
            sx: t11,
            "aria-label": "Recording cleanup strength"
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/RecordingSettings.jsx",
            lineNumber: 165,
            columnNumber: 11
        }, this);
        $[13] = currentLevel.value;
        $[14] = handleSliderChange;
        $[15] = t12;
    } else {
        t12 = $[15];
    }
    let t13;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            mt: 0.5
        };
        $[16] = t13;
    } else {
        t13 = $[16];
    }
    const t14 = LEVEL_DESCRIPTIONS[currentLevel.key];
    let t15;
    if ($[17] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            sx: t13,
            children: t14
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/RecordingSettings.jsx",
            lineNumber: 184,
            columnNumber: 11
        }, this);
        $[17] = t14;
        $[18] = t15;
    } else {
        t15 = $[18];
    }
    let t16;
    if ($[19] !== t12 || $[20] !== t15 || $[21] !== t8) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t8,
                t12,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/RecordingSettings.jsx",
            lineNumber: 192,
            columnNumber: 11
        }, this);
        $[19] = t12;
        $[20] = t15;
        $[21] = t8;
        $[22] = t16;
    } else {
        t16 = $[22];
    }
    return t16;
}
_c = RecordingSettings;
function _RecordingSettingsCLEANUP_LEVELSMap(l_0) {
    return {
        value: l_0.value,
        label: l_0.label
    };
}
var _c;
__turbopack_context__.k.register(_c, "RecordingSettings");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ScreenplayEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview ScreenplayEditor — editable Fountain editor + AI prompt input.
 *
 * Two-zone layout:
 *  1. **Fountain editor** — Editable Lexical plain-text editor with monospace
 *     Fountain styling. Manual edits re-parse into RS3 `scriptData` on every
 *     change (debounced 500ms) via the parent's `onFountainChange` callback.
 *  2. **Prompt input** — Text field for AI-assisted screenplay generation.
 *
 * The component is controlled: it receives `fountainText` and calls
 * `onFountainChange(newText)` whenever the editor or AI updates the script.
 * The parent (RecordingStudio3) calls `parseFountainToScriptData()` and
 * merges the result into its state.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Send.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposer.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalPlainTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalPlainTextPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalContentEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalErrorBoundary.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHistoryPlugin.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalOnChangePlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
// ── Debounce helper ──
function useDebouncedCallback(callback, delay) {
    _s();
    const timerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const callbackRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(callback);
    callbackRef.current = callback;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDebouncedCallback.useCallback": (...args)=>{
            if (timerRef.current) clearTimeout(timerRef.current);
            timerRef.current = setTimeout({
                "useDebouncedCallback.useCallback": ()=>callbackRef.current(...args)
            }["useDebouncedCallback.useCallback"], delay);
        }
    }["useDebouncedCallback.useCallback"], [
        delay
    ]);
}
_s(useDebouncedCallback, "uTybhikfXy6qUDT2opGJ//otgwo=");
// ── Plugin: Set editor content from outside ──
function SetContentPlugin(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "2c9ae619dc29155e414077936eb3130f82f1581e260f4707f8016089964c8252") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2c9ae619dc29155e414077936eb3130f82f1581e260f4707f8016089964c8252";
    }
    const { text } = t0;
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const lastSetRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])("");
    let t1;
    let t2;
    if ($[1] !== editor || $[2] !== text) {
        t1 = ({
            "SetContentPlugin[useEffect()]": ()=>{
                if (text === lastSetRef.current) {
                    return;
                }
                lastSetRef.current = text;
                editor.update({
                    "SetContentPlugin[useEffect() > editor.update()]": ()=>{
                        const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
                        root.clear();
                        const lines = text.split("\n");
                        for (const line of lines){
                            const p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])();
                            p.append((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(line));
                            root.append(p);
                        }
                    }
                }["SetContentPlugin[useEffect() > editor.update()]"]);
            }
        })["SetContentPlugin[useEffect()]"];
        t2 = [
            editor,
            text
        ];
        $[1] = editor;
        $[2] = text;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return null;
}
_s1(SetContentPlugin, "QFk0kql5nE6yDYaluRksqrXKfmM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"]
    ];
});
_c = SetContentPlugin;
// ── Fountain syntax highlighting theme ──
const fountainTheme = {
    paragraph: 'screenplay-line',
    root: 'screenplay-root'
};
function ScreenplayEditor({ fountainText = '', onFountainChange, onPromptSubmit, isGenerating = false, readOnly = false }) {
    _s2();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('components');
    const [promptValue, setPromptValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // Track the text that the editor itself produced so we can distinguish
    // "editor changed locally" from "parent pushed new text".
    const localTextRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(fountainText);
    // Debounced callback that fires onFountainChange
    const debouncedChange = useDebouncedCallback({
        "ScreenplayEditor.useDebouncedCallback[debouncedChange]": (newText)=>{
            localTextRef.current = newText;
            onFountainChange?.(newText);
        }
    }["ScreenplayEditor.useDebouncedCallback[debouncedChange]"], 500);
    // Lexical onChange handler — extract plain text from editor state
    // NOTE: We join paragraph text with single '\n' (not getTextContent which uses
    // '\n\n' between block nodes) so Fountain format stays intact — character names
    // must be on the line immediately before their dialogue.
    const handleEditorChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ScreenplayEditor.useCallback[handleEditorChange]": (editorState)=>{
            editorState.read({
                "ScreenplayEditor.useCallback[handleEditorChange]": ()=>{
                    const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
                    const paragraphs = root.getChildren();
                    const text = paragraphs.map({
                        "ScreenplayEditor.useCallback[handleEditorChange].text": (p)=>p.getTextContent()
                    }["ScreenplayEditor.useCallback[handleEditorChange].text"]).join('\n');
                    debouncedChange(text);
                }
            }["ScreenplayEditor.useCallback[handleEditorChange]"]);
        }
    }["ScreenplayEditor.useCallback[handleEditorChange]"], [
        debouncedChange
    ]);
    // We want SetContentPlugin to react only when the *parent* pushes new text
    // (e.g., AI generation result), not when the user types. We detect this by
    // comparing against localTextRef.
    const externalText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ScreenplayEditor.useMemo[externalText]": ()=>{
            if (fountainText !== localTextRef.current) {
                localTextRef.current = fountainText;
                return fountainText;
            }
            return localTextRef.current;
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["ScreenplayEditor.useMemo[externalText]"], [
        fountainText
    ]);
    const handlePromptSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ScreenplayEditor.useCallback[handlePromptSubmit]": ()=>{
            const trimmed = promptValue.trim();
            if (!trimmed || isGenerating) return;
            onPromptSubmit?.(trimmed);
            setPromptValue('');
        }
    }["ScreenplayEditor.useCallback[handlePromptSubmit]"], [
        promptValue,
        isGenerating,
        onPromptSubmit
    ]);
    const handlePromptKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ScreenplayEditor.useCallback[handlePromptKeyDown]": (e)=>{
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handlePromptSubmit();
            }
        }
    }["ScreenplayEditor.useCallback[handlePromptKeyDown]"], [
        handlePromptSubmit
    ]);
    const initialConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ScreenplayEditor.useMemo[initialConfig]": ()=>({
                namespace: 'ScreenplayEditor',
                theme: fountainTheme,
                onError: ({
                    "ScreenplayEditor.useMemo[initialConfig]": (error)=>console.error('ScreenplayEditor Lexical error:', error)
                })["ScreenplayEditor.useMemo[initialConfig]"],
                editable: !readOnly
            })
    }["ScreenplayEditor.useMemo[initialConfig]"], [
        readOnly
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
            overflow: 'hidden'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    flex: 1,
                    overflow: 'auto',
                    position: 'relative',
                    '& .screenplay-root': {
                        fontFamily: '"Courier New", Courier, monospace',
                        fontSize: '12pt',
                        lineHeight: 1.6,
                        padding: '16px 24px',
                        outline: 'none',
                        minHeight: '100%',
                        whiteSpace: 'pre-wrap'
                    },
                    '& .screenplay-line': {
                        margin: 0
                    }
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalComposer"], {
                    initialConfig: initialConfig,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalPlainTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlainTextPlugin"], {
                            contentEditable: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentEditable"], {
                                className: "screenplay-root",
                                "aria-label": t('screenplayEditor.editorLabel', 'Fountain screenplay editor')
                            }, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                                lineNumber: 197,
                                columnNumber: 45
                            }, this),
                            ErrorBoundary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalErrorBoundary"]
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                            lineNumber: 197,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HistoryPlugin"], {}, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                            lineNumber: 198,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OnChangePlugin"], {
                            onChange: handleEditorChange
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                            lineNumber: 199,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SetContentPlugin, {
                            text: externalText
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                            lineNumber: 200,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                    lineNumber: 196,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                lineNumber: 179,
                columnNumber: 7
            }, this),
            onPromptSubmit && !readOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    borderTop: 1,
                    borderColor: 'divider',
                    p: 1.5,
                    bgcolor: 'background.paper'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                        direction: "row",
                        spacing: 1,
                        alignItems: "flex-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                fullWidth: true,
                                size: "small",
                                multiline: true,
                                maxRows: 3,
                                placeholder: t('screenplayEditor.promptPlaceholder', 'Describe what you want\u2026 e.g. "Add a scene where the student practices ordering coffee"'),
                                value: promptValue,
                                onChange: (e)=>setPromptValue(e.target.value),
                                onKeyDown: handlePromptKeyDown,
                                disabled: isGenerating,
                                slotProps: {
                                    input: {
                                        sx: {
                                            fontFamily: 'inherit',
                                            fontSize: '0.875rem'
                                        }
                                    }
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                                lineNumber: 212,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                onClick: handlePromptSubmit,
                                disabled: isGenerating || !promptValue.trim(),
                                color: "primary",
                                "aria-label": t('screenplayEditor.send', 'Send prompt'),
                                children: isGenerating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                    variant: "circular",
                                    width: 20,
                                    height: 20
                                }, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                                    lineNumber: 221,
                                    columnNumber: 31
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                                    lineNumber: 221,
                                    columnNumber: 88
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                                lineNumber: 220,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                        lineNumber: 211,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        color: "text.secondary",
                        sx: {
                            mt: 0.5,
                            display: 'block'
                        },
                        children: t('screenplayEditor.examples', 'Examples: "Add a scene where they practice at a train station" \u00b7 "Make Akiko speak more casually" \u00b7 "Add direction notes for pauses"')
                    }, void 0, false, {
                        fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                        lineNumber: 224,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
                lineNumber: 205,
                columnNumber: 39
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx",
        lineNumber: 172,
        columnNumber: 10
    }, this);
}
_s2(ScreenplayEditor, "FQ4lbgbdYP4tpfgoHwwzNoZoIuQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        useDebouncedCallback
    ];
});
_c1 = ScreenplayEditor;
var _c, _c1;
__turbopack_context__.k.register(_c, "SetContentPlugin");
__turbopack_context__.k.register(_c1, "ScreenplayEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RecordingStudio3/TimelineCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TimelineCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$GraphicEq$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/GraphicEq.js [app-client] (ecmascript)");
;
;
;
;
function TimelineCard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(40);
    if ($[0] !== "f932130f61dba24f97ffd6b4743e069cc21a5d88cd3ac309fb207e3d0949ed47") {
        for(let $i = 0; $i < 40; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f932130f61dba24f97ffd6b4743e069cc21a5d88cd3ac309fb207e3d0949ed47";
    }
    const { line, speaker, isSelected, left, width, onClick } = t0;
    const activeTake = line.activeTakeIndex !== null && line.takes?.[line.activeTakeIndex];
    const t1 = line.text || "(empty)";
    let t2;
    if ($[1] !== line.id || $[2] !== onClick) {
        t2 = ({
            "TimelineCard[<Box>.onClick]": ()=>onClick(line.id)
        })["TimelineCard[<Box>.onClick]"];
        $[1] = line.id;
        $[2] = onClick;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] !== line.id || $[5] !== onClick) {
        t3 = ({
            "TimelineCard[<Box>.onKeyDown]": (e)=>{
                if (e.key === "Enter" || e.key === " ") {
                    onClick(line.id);
                }
            }
        })["TimelineCard[<Box>.onKeyDown]"];
        $[4] = line.id;
        $[5] = onClick;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const t4 = `${speaker?.name || "Unknown"}: ${line.text || "empty"}`;
    const t5 = Math.max(width, 60);
    const t6 = isSelected ? "primary.main" : "primary.light";
    const t7 = isSelected ? "primary.contrastText" : "text.primary";
    const t8 = isSelected ? 1 : 0.85;
    const t9 = isSelected ? 2 : 1;
    const t10 = isSelected ? "primary.dark" : "divider";
    let t11;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            opacity: 1,
            borderColor: "primary.main"
        };
        $[7] = t11;
    } else {
        t11 = $[7];
    }
    let t12;
    if ($[8] !== left || $[9] !== t10 || $[10] !== t5 || $[11] !== t6 || $[12] !== t7 || $[13] !== t8 || $[14] !== t9) {
        t12 = {
            position: "absolute",
            left,
            width: t5,
            top: 4,
            bottom: 4,
            borderRadius: 1,
            bgcolor: t6,
            color: t7,
            opacity: t8,
            border: t9,
            borderColor: t10,
            cursor: "pointer",
            overflow: "hidden",
            px: 0.75,
            py: 0.5,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            transition: "opacity 0.15s, border-color 0.15s",
            "&:hover": t11
        };
        $[8] = left;
        $[9] = t10;
        $[10] = t5;
        $[11] = t6;
        $[12] = t7;
        $[13] = t8;
        $[14] = t9;
        $[15] = t12;
    } else {
        t12 = $[15];
    }
    let t13;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            fontWeight: 500,
            lineHeight: 1.3
        };
        $[16] = t13;
    } else {
        t13 = $[16];
    }
    const t14 = line.text || "(empty)";
    let t15;
    if ($[17] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            noWrap: true,
            sx: t13,
            children: t14
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/TimelineCard.tsx",
            lineNumber: 130,
            columnNumber: 11
        }, this);
        $[17] = t14;
        $[18] = t15;
    } else {
        t15 = $[18];
    }
    let t16;
    if ($[19] !== line.direction) {
        t16 = line.direction && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            noWrap: true,
            sx: {
                fontStyle: "italic",
                opacity: 0.7,
                fontSize: "0.65rem",
                lineHeight: 1.2
            },
            children: line.direction
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/TimelineCard.tsx",
            lineNumber: 138,
            columnNumber: 29
        }, this);
        $[19] = line.direction;
        $[20] = t16;
    } else {
        t16 = $[20];
    }
    let t17;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = {
            display: "flex",
            alignItems: "center",
            gap: 0.5,
            mt: 0.25
        };
        $[21] = t17;
    } else {
        t17 = $[21];
    }
    let t18;
    if ($[22] !== line.emotion) {
        t18 = line.emotion && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            label: line.emotion,
            size: "small",
            sx: {
                height: 16,
                fontSize: "0.6rem",
                "& .MuiChip-label": {
                    px: 0.5
                }
            }
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/TimelineCard.tsx",
            lineNumber: 163,
            columnNumber: 27
        }, this);
        $[22] = line.emotion;
        $[23] = t18;
    } else {
        t18 = $[23];
    }
    let t19;
    if ($[24] !== activeTake) {
        t19 = activeTake && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$GraphicEq$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: 12,
                opacity: 0.6
            }
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/TimelineCard.tsx",
            lineNumber: 177,
            columnNumber: 25
        }, this);
        $[24] = activeTake;
        $[25] = t19;
    } else {
        t19 = $[25];
    }
    let t20;
    if ($[26] !== t18 || $[27] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t17,
            children: [
                t18,
                t19
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/TimelineCard.tsx",
            lineNumber: 188,
            columnNumber: 11
        }, this);
        $[26] = t18;
        $[27] = t19;
        $[28] = t20;
    } else {
        t20 = $[28];
    }
    let t21;
    if ($[29] !== t12 || $[30] !== t15 || $[31] !== t16 || $[32] !== t2 || $[33] !== t20 || $[34] !== t3 || $[35] !== t4) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            onClick: t2,
            role: "button",
            tabIndex: 0,
            onKeyDown: t3,
            "aria-label": t4,
            sx: t12,
            children: [
                t15,
                t16,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/TimelineCard.tsx",
            lineNumber: 197,
            columnNumber: 11
        }, this);
        $[29] = t12;
        $[30] = t15;
        $[31] = t16;
        $[32] = t2;
        $[33] = t20;
        $[34] = t3;
        $[35] = t4;
        $[36] = t21;
    } else {
        t21 = $[36];
    }
    let t22;
    if ($[37] !== t1 || $[38] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: t1,
            enterDelay: 400,
            placement: "top",
            children: t21
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/TimelineCard.tsx",
            lineNumber: 211,
            columnNumber: 11
        }, this);
        $[37] = t1;
        $[38] = t21;
        $[39] = t22;
    } else {
        t22 = $[39];
    }
    return t22;
}
_c = TimelineCard;
var _c;
__turbopack_context__.k.register(_c, "TimelineCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HorizontalTimeline
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview HorizontalTimeline — scrollable horizontal timeline with speaker track rows.
 *
 * Each speaker gets a row. Dialogue cards are absolutely positioned at their
 * `timing.start` offset and span `timing.end - timing.start`. The timeline
 * includes transport controls (play/stop/record), a draggable playhead,
 * time ruler, and zoom via Ctrl+scroll.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PlayArrow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PlayArrow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Stop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Stop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$TimelineCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudio3/TimelineCard.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
/** Pixels per second at zoom level 1.0 */ const BASE_PX_PER_SEC = 80;
const MIN_ZOOM = 0.25;
const MAX_ZOOM = 4;
/**
 * Format seconds as M:SS.
 */ function formatTime(s) {
    const mins = Math.floor(s / 60);
    const secs = Math.floor(s % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}
function HorizontalTimeline(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(80);
    if ($[0] !== "8b6a082d8001bd304f1783d407d3f7afc9f9bc51657def5848891e344989ad30") {
        for(let $i = 0; $i < 80; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8b6a082d8001bd304f1783d407d3f7afc9f9bc51657def5848891e344989ad30";
    }
    const { scriptData, selectedDialogueId, onSelectDialogue, recording: t1, playing: t2, onPlay, onStop, onRecordingComplete, readOnly: t3 } = t0;
    t1 === undefined ? false : t1;
    const playing = t2 === undefined ? false : t2;
    const readOnly = t3 === undefined ? false : t3;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [zoom, setZoom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const pxPerSec = BASE_PX_PER_SEC * zoom;
    scriptData.dialogue.find({
        "HorizontalTimeline[scriptData.dialogue.find()]": (d)=>d.id === selectedDialogueId
    }["HorizontalTimeline[scriptData.dialogue.find()]"]) || null;
    let t4;
    bb0: {
        if (!scriptData.dialogue.length) {
            t4 = 10;
            break bb0;
        }
        let t5;
        if ($[1] !== scriptData.dialogue) {
            t5 = Math.max(...scriptData.dialogue.map(_HorizontalTimelineScriptDataDialogueMap));
            $[1] = scriptData.dialogue;
            $[2] = t5;
        } else {
            t5 = $[2];
        }
        const maxEnd = t5;
        t4 = maxEnd + 2;
    }
    const totalDuration = t4;
    const containerWidth = totalDuration * pxPerSec;
    let order;
    if ($[3] !== scriptData.dialogue || $[4] !== scriptData.speakers) {
        const seen = new Set();
        order = [];
        for (const line of scriptData.dialogue){
            if (!seen.has(line.speaker)) {
                seen.add(line.speaker);
                order.push(line.speaker);
            }
        }
        let t5;
        if ($[6] !== scriptData.speakers) {
            t5 = Object.keys(scriptData.speakers);
            $[6] = scriptData.speakers;
            $[7] = t5;
        } else {
            t5 = $[7];
        }
        for (const key of t5){
            if (!seen.has(key)) {
                seen.add(key);
                order.push(key);
            }
        }
        $[3] = scriptData.dialogue;
        $[4] = scriptData.speakers;
        $[5] = order;
    } else {
        order = $[5];
    }
    const speakerOrder = order;
    let map;
    if ($[8] !== scriptData.dialogue || $[9] !== speakerOrder) {
        map = {};
        for (const key_0 of speakerOrder){
            map[key_0] = [];
        }
        for (const line_0 of scriptData.dialogue){
            if (!map[line_0.speaker]) {
                map[line_0.speaker] = [];
            }
            map[line_0.speaker].push(line_0);
        }
        $[8] = scriptData.dialogue;
        $[9] = speakerOrder;
        $[10] = map;
    } else {
        map = $[10];
    }
    const linesBySpeaker = map;
    let t5;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "HorizontalTimeline[handleWheel]": (e)=>{
                if (!e.ctrlKey && !e.metaKey) {
                    return;
                }
                e.preventDefault();
                setZoom({
                    "HorizontalTimeline[handleWheel > setZoom()]": (prev)=>{
                        const delta = e.deltaY > 0 ? 0.9 : 1.1;
                        return Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, prev * delta));
                    }
                }["HorizontalTimeline[handleWheel > setZoom()]"]);
            }
        })["HorizontalTimeline[handleWheel]"];
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    const handleWheel = t5;
    const step = zoom >= 2 ? 1 : zoom >= 0.75 ? 5 : 10;
    let arr;
    if ($[12] !== step || $[13] !== totalDuration) {
        arr = [];
        for(let s = 0; s <= totalDuration; s = s + step, s){
            arr.push(s);
        }
        $[12] = step;
        $[13] = totalDuration;
        $[14] = arr;
    } else {
        arr = $[14];
    }
    const ticks = arr;
    const t6 = 64 * Math.max(speakerOrder.length, 1) + 80;
    let t7;
    if ($[15] !== t6) {
        t7 = {
            display: "flex",
            flexDirection: "column",
            bgcolor: "action.hover",
            borderTop: 1,
            borderColor: "divider",
            minHeight: t6
        };
        $[15] = t6;
        $[16] = t7;
    } else {
        t7 = $[16];
    }
    let t8;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            px: 1,
            py: 0.5
        };
        $[17] = t8;
    } else {
        t8 = $[17];
    }
    const t9 = playing ? onStop : onPlay;
    const t10 = readOnly && !playing;
    const t11 = playing ? "error" : "default";
    let t12;
    if ($[18] !== playing || $[19] !== t) {
        t12 = playing ? t("recordingStudio3.stop") : t("recordingStudio3.play");
        $[18] = playing;
        $[19] = t;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] !== playing) {
        t13 = playing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Stop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 242,
            columnNumber: 21
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PlayArrow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 242,
            columnNumber: 36
        }, this);
        $[21] = playing;
        $[22] = t13;
    } else {
        t13 = $[22];
    }
    let t14;
    if ($[23] !== t10 || $[24] !== t11 || $[25] !== t12 || $[26] !== t13 || $[27] !== t9) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            size: "small",
            onClick: t9,
            disabled: t10,
            color: t11,
            "aria-label": t12,
            children: t13
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 250,
            columnNumber: 11
        }, this);
        $[23] = t10;
        $[24] = t11;
        $[25] = t12;
        $[26] = t13;
        $[27] = t9;
        $[28] = t14;
    } else {
        t14 = $[28];
    }
    let t15;
    if ($[29] !== onRecordingComplete || $[30] !== readOnly || $[31] !== selectedDialogueId) {
        t15 = !readOnly && selectedDialogueId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                flex: "0 0 auto"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                enableRecording: true,
                onRecordingComplete: onRecordingComplete,
                height: 50,
                width: 250
            }, void 0, false, {
                fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
                lineNumber: 264,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 262,
            columnNumber: 46
        }, this);
        $[29] = onRecordingComplete;
        $[30] = readOnly;
        $[31] = selectedDialogueId;
        $[32] = t15;
    } else {
        t15 = $[32];
    }
    let t16;
    let t17;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            ml: 1
        };
        t17 = formatTime(0);
        $[33] = t16;
        $[34] = t17;
    } else {
        t16 = $[33];
        t17 = $[34];
    }
    let t18;
    if ($[35] !== totalDuration) {
        t18 = formatTime(totalDuration);
        $[35] = totalDuration;
        $[36] = t18;
    } else {
        t18 = $[36];
    }
    let t19;
    if ($[37] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            sx: t16,
            children: [
                t17,
                " / ",
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 295,
            columnNumber: 11
        }, this);
        $[37] = t18;
        $[38] = t19;
    } else {
        t19 = $[38];
    }
    let t20;
    if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = {
            ml: "auto"
        };
        $[39] = t20;
    } else {
        t20 = $[39];
    }
    let t21;
    if ($[40] !== zoom) {
        t21 = Math.round(zoom * 100);
        $[40] = zoom;
        $[41] = t21;
    } else {
        t21 = $[41];
    }
    let t22;
    if ($[42] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            sx: t20,
            children: [
                "Zoom: ",
                t21,
                "%"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 320,
            columnNumber: 11
        }, this);
        $[42] = t21;
        $[43] = t22;
    } else {
        t22 = $[43];
    }
    let t23;
    if ($[44] !== t14 || $[45] !== t15 || $[46] !== t19 || $[47] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
            direction: "row",
            spacing: 1,
            alignItems: "center",
            sx: t8,
            children: [
                t14,
                t15,
                t19,
                t22
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 328,
            columnNumber: 11
        }, this);
        $[44] = t14;
        $[45] = t15;
        $[46] = t19;
        $[47] = t22;
        $[48] = t23;
    } else {
        t23 = $[48];
    }
    let t24;
    if ($[49] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {}, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 339,
            columnNumber: 11
        }, this);
        $[49] = t24;
    } else {
        t24 = $[49];
    }
    let t25;
    if ($[50] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = {
            display: "flex",
            overflow: "auto",
            flex: 1
        };
        $[50] = t25;
    } else {
        t25 = $[50];
    }
    let t26;
    if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
        t26 = {
            width: 100,
            minWidth: 100,
            flexShrink: 0,
            borderRight: 1,
            borderColor: "divider"
        };
        $[51] = t26;
    } else {
        t26 = $[51];
    }
    let t27;
    if ($[52] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                height: 24,
                borderBottom: 1,
                borderColor: "divider"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 370,
            columnNumber: 11
        }, this);
        $[52] = t27;
    } else {
        t27 = $[52];
    }
    let t28;
    if ($[53] !== scriptData || $[54] !== speakerOrder) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t26,
            children: [
                t27,
                speakerOrder.map({
                    "HorizontalTimeline[speakerOrder.map()]": (key_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                height: 64,
                                display: "flex",
                                alignItems: "center",
                                px: 1,
                                borderBottom: 1,
                                borderColor: "divider"
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "caption",
                                noWrap: true,
                                sx: {
                                    fontWeight: 600
                                },
                                children: scriptData.speakers[key_1]?.name || key_1
                            }, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
                                lineNumber: 389,
                                columnNumber: 12
                            }, this)
                        }, key_1, false, {
                            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
                            lineNumber: 382,
                            columnNumber: 60
                        }, this)
                }["HorizontalTimeline[speakerOrder.map()]"])
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 381,
            columnNumber: 11
        }, this);
        $[53] = scriptData;
        $[54] = speakerOrder;
        $[55] = t28;
    } else {
        t28 = $[55];
    }
    let t29;
    if ($[56] !== containerWidth) {
        t29 = {
            position: "relative",
            width: containerWidth,
            flexShrink: 0
        };
        $[56] = containerWidth;
        $[57] = t29;
    } else {
        t29 = $[57];
    }
    let t30;
    if ($[58] === Symbol.for("react.memo_cache_sentinel")) {
        t30 = {
            height: 24,
            position: "relative",
            borderBottom: 1,
            borderColor: "divider"
        };
        $[58] = t30;
    } else {
        t30 = $[58];
    }
    let t31;
    if ($[59] !== pxPerSec || $[60] !== ticks) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t30,
            children: ticks.map({
                "HorizontalTimeline[ticks.map()]": (s_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        sx: {
                            position: "absolute",
                            left: s_0 * pxPerSec,
                            top: 4,
                            fontSize: "0.6rem",
                            color: "text.secondary",
                            userSelect: "none"
                        },
                        children: formatTime(s_0)
                    }, s_0, false, {
                        fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
                        lineNumber: 426,
                        columnNumber: 51
                    }, this)
            }["HorizontalTimeline[ticks.map()]"])
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 425,
            columnNumber: 11
        }, this);
        $[59] = pxPerSec;
        $[60] = ticks;
        $[61] = t31;
    } else {
        t31 = $[61];
    }
    let t32;
    if ($[62] !== linesBySpeaker || $[63] !== onSelectDialogue || $[64] !== pxPerSec || $[65] !== scriptData || $[66] !== selectedDialogueId || $[67] !== speakerOrder) {
        t32 = speakerOrder.map({
            "HorizontalTimeline[speakerOrder.map()]": (key_2)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        height: 64,
                        position: "relative",
                        borderBottom: 1,
                        borderColor: "divider"
                    },
                    children: (linesBySpeaker[key_2] || []).map({
                        "HorizontalTimeline[speakerOrder.map() > (anonymous)()]": (line_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$TimelineCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                line: line_1,
                                speaker: scriptData.speakers[line_1.speaker],
                                isSelected: selectedDialogueId === line_1.id,
                                left: line_1.timing.start * pxPerSec,
                                width: (line_1.timing.end - line_1.timing.start) * pxPerSec,
                                onClick: onSelectDialogue
                            }, line_1.id, false, {
                                fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
                                lineNumber: 450,
                                columnNumber: 79
                            }, this)
                    }["HorizontalTimeline[speakerOrder.map() > (anonymous)()]"])
                }, key_2, false, {
                    fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
                    lineNumber: 444,
                    columnNumber: 58
                }, this)
        }["HorizontalTimeline[speakerOrder.map()]"]);
        $[62] = linesBySpeaker;
        $[63] = onSelectDialogue;
        $[64] = pxPerSec;
        $[65] = scriptData;
        $[66] = selectedDialogueId;
        $[67] = speakerOrder;
        $[68] = t32;
    } else {
        t32 = $[68];
    }
    let t33;
    if ($[69] !== t29 || $[70] !== t31 || $[71] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t29,
            children: [
                t31,
                t32
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 465,
            columnNumber: 11
        }, this);
        $[69] = t29;
        $[70] = t31;
        $[71] = t32;
        $[72] = t33;
    } else {
        t33 = $[72];
    }
    let t34;
    if ($[73] !== t28 || $[74] !== t33) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            ref: containerRef,
            onWheel: handleWheel,
            sx: t25,
            children: [
                t28,
                t33
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 475,
            columnNumber: 11
        }, this);
        $[73] = t28;
        $[74] = t33;
        $[75] = t34;
    } else {
        t34 = $[75];
    }
    let t35;
    if ($[76] !== t23 || $[77] !== t34 || $[78] !== t7) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t7,
            children: [
                t23,
                t24,
                t34
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx",
            lineNumber: 484,
            columnNumber: 11
        }, this);
        $[76] = t23;
        $[77] = t34;
        $[78] = t7;
        $[79] = t35;
    } else {
        t35 = $[79];
    }
    return t35;
}
_s(HorizontalTimeline, "/84nGxrJijdiiure2fapnPKi28Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = HorizontalTimeline;
function _HorizontalTimelineScriptDataDialogueMap(d_0) {
    return d_0.timing.end;
}
var _c;
__turbopack_context__.k.register(_c, "HorizontalTimeline");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RecordingStudio3/AudioFilterPanel.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AudioFilterPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * RecordingStudio3 AudioFilterPanel
 *
 * MUI Chip toggles for audio processing presets. Each chip toggles a filter
 * on/off. Multiple filters can be active simultaneously. A tooltip on hover
 * explains what each filter targets.
 *
 * Emits `onFiltersChange(activeFilters: Set<string>)` on any toggle.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$GraphicEq$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/GraphicEq.js [app-client] (ecmascript)");
;
;
;
;
;
const FILTER_PRESETS = [
    {
        id: "derumble",
        label: "De-rumble",
        description: "Removes low-frequency vibration, desk/keyboard noise, and hum (highpass @ 80 Hz)"
    },
    {
        id: "pop",
        label: "Pop filter",
        description: "Reduces plosive blasts from \"p\" and \"b\" sounds in close-mic recordings"
    },
    {
        id: "noisecancel",
        label: "Noise cancel",
        description: "ML-powered noise suppression — removes background fans, AC, keyboard, and street noise"
    },
    {
        id: "compress",
        label: "Compress",
        description: "Evens out loud and quiet sections for consistent playback volume"
    },
    {
        id: "presence",
        label: "Presence",
        description: "Boosts speech clarity at 3 kHz — improves intelligibility for language learners"
    }
];
function AudioFilterPanel(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "7f22e20673efef0c68811516881d810236ee39a0c397220f51622c29cedbafcf") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7f22e20673efef0c68811516881d810236ee39a0c397220f51622c29cedbafcf";
    }
    const { activeFilters, onFiltersChange } = t0;
    let t1;
    if ($[1] !== activeFilters || $[2] !== onFiltersChange) {
        t1 = ({
            "AudioFilterPanel[handleToggle]": (filterId)=>{
                const next = new Set(activeFilters);
                if (next.has(filterId)) {
                    next.delete(filterId);
                } else {
                    next.add(filterId);
                }
                onFiltersChange(next);
            }
        })["AudioFilterPanel[handleToggle]"];
        $[1] = activeFilters;
        $[2] = onFiltersChange;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const handleToggle = t1;
    let t2;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            mb: 2
        };
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            sx: {
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                mb: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$GraphicEq$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/RecordingStudio3/AudioFilterPanel.jsx",
                    lineNumber: 83,
                    columnNumber: 8
                }, this),
                "Audio Filters"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/AudioFilterPanel.jsx",
            lineNumber: 78,
            columnNumber: 10
        }, this);
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            display: "flex",
            flexWrap: "wrap",
            gap: 1
        };
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== activeFilters || $[8] !== handleToggle) {
        t5 = FILTER_PRESETS.map({
            "AudioFilterPanel[FILTER_PRESETS.map()]": (preset)=>{
                const isActive = activeFilters.has(preset.id);
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                    title: preset.description,
                    arrow: true,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                        label: preset.label,
                        variant: isActive ? "filled" : "outlined",
                        color: isActive ? "primary" : "default",
                        size: "small",
                        onClick: {
                            "AudioFilterPanel[FILTER_PRESETS.map() > <Chip>.onClick]": ()=>handleToggle(preset.id)
                        }["AudioFilterPanel[FILTER_PRESETS.map() > <Chip>.onClick]"]
                    }, void 0, false, {
                        fileName: "[project]/src/components/RecordingStudio3/AudioFilterPanel.jsx",
                        lineNumber: 104,
                        columnNumber: 81
                    }, this)
                }, preset.id, false, {
                    fileName: "[project]/src/components/RecordingStudio3/AudioFilterPanel.jsx",
                    lineNumber: 104,
                    columnNumber: 16
                }, this);
            }
        }["AudioFilterPanel[FILTER_PRESETS.map()]"]);
        $[7] = activeFilters;
        $[8] = handleToggle;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t2,
            children: [
                t3,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: t4,
                    children: t5
                }, void 0, false, {
                    fileName: "[project]/src/components/RecordingStudio3/AudioFilterPanel.jsx",
                    lineNumber: 117,
                    columnNumber: 27
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3/AudioFilterPanel.jsx",
            lineNumber: 117,
            columnNumber: 10
        }, this);
        $[10] = t5;
        $[11] = t6;
    } else {
        t6 = $[11];
    }
    return t6;
}
_c = AudioFilterPanel;
var _c;
__turbopack_context__.k.register(_c, "AudioFilterPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TakeVersionHistory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * TakeVersionHistory — lazy-loading Popover with S3 version list and Restore button
 *
 * Shows all recorded versions of a take slot. Lazy-fetches the S3 version list
 * on first open. Active version is marked; user can restore any previous version.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Popover$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Popover/Popover.js [app-client] (ecmascript) <export default as Popover>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemIcon/ListItemIcon.js [app-client] (ecmascript) <export default as ListItemIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircularProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CircularProgress/CircularProgress.js [app-client] (ecmascript) <export default as CircularProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$History$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/History.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RadioButtonChecked$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RadioButtonChecked.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RadioButtonUnchecked$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RadioButtonUnchecked.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$takeVersioning$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/takeVersioning.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
function TakeVersionHistory({ identityId, dialogueId, slotId, currentVersion, currentAudioPath, takeType, onRestore, disabled = false }) {
    _s();
    const [anchorEl, setAnchorEl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [versions, setVersions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const open = Boolean(anchorEl);
    const handleOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "TakeVersionHistory.useCallback[handleOpen]": async (event)=>{
            setAnchorEl(event.currentTarget);
            // Lazy-load versions on first open
            if (versions === null) {
                setLoading(true);
                setError(null);
                try {
                    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$takeVersioning$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["listTakeVersions"])(identityId, dialogueId, slotId);
                    setVersions(result);
                } catch (err) {
                    console.error("[TakeVersionHistory] Failed to list versions:", err);
                    setError("Failed to load version history");
                } finally{
                    setLoading(false);
                }
            }
        }
    }["TakeVersionHistory.useCallback[handleOpen]"], [
        identityId,
        dialogueId,
        slotId,
        versions
    ]);
    const handleClose = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "TakeVersionHistory.useCallback[handleClose]": ()=>{
            setAnchorEl(null);
        }
    }["TakeVersionHistory.useCallback[handleClose]"], []);
    const handleRestore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "TakeVersionHistory.useCallback[handleRestore]": (versionKey)=>{
            onRestore(dialogueId, slotId, versionKey);
            handleClose();
        }
    }["TakeVersionHistory.useCallback[handleRestore]"], [
        dialogueId,
        slotId,
        onRestore,
        handleClose
    ]);
    const isActiveVersion = (versionKey_0)=>{
        return versionKey_0 === currentAudioPath;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                size: "small",
                onClick: handleOpen,
                disabled: disabled || !slotId,
                title: "Version History",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$History$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                    lineNumber: 58,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                lineNumber: 57,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Popover$3e$__["Popover"], {
                open: open,
                anchorEl: anchorEl,
                onClose: handleClose,
                anchorOrigin: {
                    vertical: "bottom",
                    horizontal: "left"
                },
                transformOrigin: {
                    vertical: "top",
                    horizontal: "left"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        p: 2,
                        minWidth: 280,
                        maxWidth: 400
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "subtitle2",
                            sx: {
                                mb: 1,
                                display: "flex",
                                alignItems: "center",
                                gap: 1
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$History$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    fontSize: "small"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                    lineNumber: 79,
                                    columnNumber: 13
                                }, this),
                                "Version History"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                            lineNumber: 73,
                            columnNumber: 11
                        }, this),
                        loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                justifyContent: "center",
                                p: 2
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircularProgress$3e$__["CircularProgress"], {
                                size: 24
                            }, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                lineNumber: 88,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                            lineNumber: 83,
                            columnNumber: 23
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "error",
                            sx: {
                                p: 1
                            },
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                            lineNumber: 91,
                            columnNumber: 21
                        }, this),
                        versions && versions.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "text.secondary",
                            sx: {
                                p: 1
                            },
                            children: "No version history available"
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                            lineNumber: 97,
                            columnNumber: 49
                        }, this),
                        versions && versions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                            dense: true,
                            disablePadding: true,
                            children: [
                                ...versions
                            ].reverse().map((v)=>{
                                const active = isActiveVersion(v.key);
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                    disablePadding: true,
                                    sx: {
                                        mb: 0.5
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                            sx: {
                                                minWidth: 32
                                            },
                                            children: active ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RadioButtonChecked$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                fontSize: "small",
                                                color: "primary"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                                lineNumber: 112,
                                                columnNumber: 33
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RadioButtonUnchecked$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                fontSize: "small"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                                lineNumber: 112,
                                                columnNumber: 95
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                            lineNumber: 109,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                            primary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                sx: {
                                                    display: "flex",
                                                    alignItems: "center",
                                                    gap: 1
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "body2",
                                                        fontWeight: active ? 600 : 400,
                                                        children: [
                                                            "v",
                                                            v.version
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                                        lineNumber: 119,
                                                        columnNumber: 27
                                                    }, this),
                                                    active && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                                        label: "active",
                                                        size: "small",
                                                        color: "primary",
                                                        variant: "outlined",
                                                        sx: {
                                                            height: 18,
                                                            fontSize: "0.65rem"
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                                        lineNumber: 122,
                                                        columnNumber: 38
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                                        label: takeType || "human",
                                                        size: "small",
                                                        variant: "outlined",
                                                        sx: {
                                                            height: 18,
                                                            fontSize: "0.65rem"
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                                        lineNumber: 126,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                                lineNumber: 114,
                                                columnNumber: 44
                                            }, this),
                                            secondary: v.lastModified ? new Date(v.lastModified).toLocaleString() : undefined
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                            lineNumber: 114,
                                            columnNumber: 21
                                        }, this),
                                        !active && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                            size: "small",
                                            variant: "text",
                                            onClick: ()=>handleRestore(v.key),
                                            sx: {
                                                ml: 1,
                                                textTransform: "none",
                                                fontSize: "0.75rem"
                                            },
                                            children: "Restore"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                            lineNumber: 131,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, v.version, true, {
                                    fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                                    lineNumber: 106,
                                    columnNumber: 20
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                            lineNumber: 103,
                            columnNumber: 47
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                    lineNumber: 68,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx",
                lineNumber: 61,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(TakeVersionHistory, "futzDGhSUDwvth8WuyPqmQl0qwM=");
_c = TakeVersionHistory;
var _c;
__turbopack_context__.k.register(_c, "TakeVersionHistory");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RecordingStudio3/parseFountainToScriptData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parseFountainToScriptData",
    ()=>parseFountainToScriptData,
    "scriptDataToFountain",
    ()=>scriptDataToFountain
]);
/**
 * @fileoverview Fountain → RS3 ScriptData parser
 *
 * Parses standard Fountain screenplay format into the scriptData shape
 * consumed by RecordingStudio3. Uses the `fountain-js` npm package for
 * tokenization, then walks the token stream to build speakers, dialogue
 * lines, timing offsets, and direction notes.
 *
 * Direction notes use Fountain's native [[double bracket]] syntax and are
 * extracted from dialogue text into the `direction` field on each line.
 *
 * Timing is estimated from text length (~150 words/minute for speech)
 * with a 0.5s gap between lines.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$fountain$2d$js$2f$dist$2e$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/fountain-js/dist.esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$fountain$2d$js$2f$dist$2e$esm$2f$fountain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/fountain-js/dist.esm/fountain.js [app-client] (ecmascript)");
;
/** Words-per-minute estimate for timing calculation */ const WORDS_PER_MINUTE = 150;
/** Minimum duration in seconds for any dialogue line */ const MIN_DURATION = 1.0;
/** Gap between consecutive dialogue lines in seconds */ const GAP_SECONDS = 0.5;
// ── Helpers ────────────────────────────────────────────────────────
/** Extract all [[note]] blocks from text and return cleaned text + notes. */ function extractNotes(raw) {
    const notePattern = /\[\[([^\]]*)\]\]/g;
    const notes = [];
    let match;
    while((match = notePattern.exec(raw)) !== null){
        notes.push(match[1].trim());
    }
    const text = raw.replace(notePattern, "").replace(/\n/g, " ").trim();
    return {
        text,
        notes: notes.join(" ")
    };
}
/** Strip parentheses wrapper from parenthetical text. */ function stripParens(raw) {
    return raw.replace(/^\(/, "").replace(/\)$/, "").trim();
}
/** Estimate speech duration in seconds from word count. */ function estimateDuration(text) {
    const wordCount = text.split(/\s+/).filter(Boolean).length;
    const seconds = wordCount / WORDS_PER_MINUTE * 60;
    return Math.max(seconds, MIN_DURATION);
}
/** Normalise a character name to a stable speaker key. */ function toSpeakerKey(name) {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
}
function parseFountainToScriptData(fountain, existingVoices = {}) {
    const parser = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$fountain$2d$js$2f$dist$2e$esm$2f$fountain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fountain"]();
    const result = parser.parse(fountain, true);
    const tokens = result.tokens || [];
    // ── Title page fields ──
    let title = "";
    let date = "";
    for (const t of tokens){
        if (t.is_title && t.type === "title") title = t.text ?? "";
        if (t.is_title && t.type === "date") date = t.text ?? "";
    }
    // ── Walk tokens to extract dialogue ──
    const speakers = {};
    const dialogue = [];
    let currentScene = "";
    let currentCharacter = "";
    let currentParenthetical = "";
    let dialogueId = 1;
    for(let i = 0; i < tokens.length; i++){
        const token = tokens[i];
        if (token.type === "scene_heading") {
            currentScene = token.text ?? "";
            continue;
        }
        if (token.type === "character") {
            currentCharacter = (token.text ?? "").trim();
            currentParenthetical = "";
            continue;
        }
        if (token.type === "parenthetical") {
            currentParenthetical = stripParens(token.text ?? "");
            continue;
        }
        if (token.type === "dialogue" && currentCharacter) {
            const { text, notes } = extractNotes(token.text ?? "");
            const speakerKey = toSpeakerKey(currentCharacter);
            // Register speaker if new
            if (!speakers[speakerKey]) {
                speakers[speakerKey] = {
                    name: currentCharacter,
                    voice: existingVoices[speakerKey] || "alloy",
                    description: currentParenthetical
                };
            }
            dialogue.push({
                id: dialogueId++,
                speaker: speakerKey,
                text,
                timing: {
                    start: 0,
                    end: 0
                },
                direction: notes,
                emotion: currentParenthetical,
                takes: [],
                activeTakeIndex: null
            });
            // Reset parenthetical after consuming it for this dialogue block
            // (next dialogue line under the same character inherits character
            //  but not parenthetical unless re-specified)
            currentParenthetical = "";
            continue;
        }
    // dialogue_begin / dialogue_end / page_break / action — skip
    }
    // ── Compute sequential timing ──
    let cursor = 0;
    for (const line of dialogue){
        const duration = estimateDuration(line.text);
        line.timing = {
            start: cursor,
            end: +(cursor + duration).toFixed(2)
        };
        cursor = +(cursor + duration + GAP_SECONDS).toFixed(2);
    }
    return {
        metadata: {
            title: title || "Untitled Screenplay",
            scene: currentScene || "",
            date: date || new Date().toISOString().split("T")[0],
            version: "1.0"
        },
        speakers,
        dialogue
    };
}
function scriptDataToFountain(data) {
    const lines = [];
    // Title page
    if (data.metadata.title) lines.push(`Title: ${data.metadata.title}`);
    if (data.metadata.date) lines.push(`Date: ${data.metadata.date}`);
    lines.push(""); // blank line ends title page
    // Group dialogue by scene (we only track the last scene in metadata,
    // so emit it once at the top of the script body)
    if (data.metadata.scene) {
        lines.push(data.metadata.scene);
        lines.push("");
    }
    for (const line of data.dialogue){
        const speaker = data.speakers[line.speaker];
        const characterName = speaker?.name?.toUpperCase() || line.speaker.toUpperCase();
        lines.push(characterName);
        if (line.emotion) {
            lines.push(`(${line.emotion})`);
        }
        let dialogueText = line.text;
        if (line.direction) {
            dialogueText += `\n[[${line.direction}]]`;
        }
        lines.push(dialogueText);
        lines.push("");
    }
    return lines.join("\n");
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_RecordingStudio3_1pk_592._.js.map