(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_components_Editor3_components_TableComponent_jsx_1fpsfe4._.js","static/chunks/src_components_Editor3_01gyw69._.js","static/chunks/src_components_DictionaryEditor2_jsx_01qv2pt._.js","static/chunks/src_components_Chat_0bhnna8._.js","static/chunks/src_components_0o41rna._.js","static/chunks/src_0ppadm3._.js","static/chunks/app_[locale]_unit_[id]_UnitEditorClient_jsx_19yzetr._.js","static/chunks/node_modules_0kjcp4i._.js"],
    source: "dynamic"
});
