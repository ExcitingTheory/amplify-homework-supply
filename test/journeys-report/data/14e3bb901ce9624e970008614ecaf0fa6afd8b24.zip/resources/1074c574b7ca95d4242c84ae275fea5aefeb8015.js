(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/DictionaryEditor2.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DictionaryEditor2",
    ()=>DictionaryEditor2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dompurify/dist/purify.es.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
// Lexical imports
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposer.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalRichTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalRichTextPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalContentEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHistoryPlugin.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$history$2f$LexicalHistory$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/history/LexicalHistory.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalOnChangePlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalErrorBoundary.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$mark$2f$LexicalMark$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/mark/LexicalMark.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$SearchHighlightPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/SearchHighlightPlugin.jsx [app-client] (ecmascript)");
// MUI imports
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Menu/Menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Portal/Portal.js [app-client] (ecmascript) <export default as Portal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript) <export default as Snackbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Delete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Description.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandLess.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandMore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MoreVert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Save.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Add.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3Modal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudio3Modal.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$recordingStudioPresets$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/recordingStudioPresets.js [app-client] (ecmascript)");
// Context imports
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/fileContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tabContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/tabContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ShowDeletedToggle$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ShowDeletedToggle.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useRecycleBin.js [app-client] (ecmascript)");
// Virtualization
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-virtual/dist/esm/index.js [app-client] (ecmascript) <locals>");
// Import VocabularyCard from VocabularyReview2
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VocabularyReview2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/VocabularyReview2.tsx [app-client] (ecmascript)");
// Gen 2 client import
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/client/apis/uploadData.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature();
"use strict";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Commands for word operations
const UPDATE_WORD_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("UPDATE_WORD");
const DELETE_WORD_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("DELETE_WORD");
const POPULATE_WORDS_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("POPULATE_WORDS");
// Helper functions
function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}
const deduplicateUrls = (urls)=>{
    const set = new Set(urls);
    return Array.from(set);
};
const debounce = (func, wait)=>{
    let timeout;
    return function executedFunction(...args) {
        const later = ()=>{
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
};
// Convert blob to base64 for serialization
const blobToBase64 = (blob)=>{
    return new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.onloadend = ()=>resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};
// Convert base64 to blob for deserialization
const base64ToBlob = (base64, mimeType = "audio/ogg")=>{
    const byteString = atob(base64.split(",")[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for(let i = 0; i < byteString.length; i++){
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([
        ab
    ], {
        type: mimeType
    });
};
// Conversion function for importing word nodes from HTML
function convertWordElement(domNode) {
    const wordId = domNode.getAttribute("data-lexical-word-id");
    const phrase = domNode.getAttribute("data-lexical-word-phrase") || "";
    const pronunciation = domNode.getAttribute("data-lexical-word-pronunciation") || "";
    const definition = domNode.getAttribute("data-lexical-word-definition") || "";
    const rubyTags = domNode.getAttribute("data-lexical-word-ruby-tags") || "";
    const version = domNode.getAttribute("data-lexical-word-version") || "1";
    // Parse audio keys
    let audio = [];
    const audioKeysAttr = domNode.getAttribute("data-lexical-audio-keys");
    if (audioKeysAttr) {
        try {
            audio = JSON.parse(audioKeysAttr);
        } catch (e) {
            console.error("Failed to parse audio keys:", e);
        }
    }
    // Parse audio URLs from script tag if present
    const audioScript = domNode.querySelector("script.lexical-word-audio-data");
    let audioData = null;
    if (audioScript) {
        try {
            audioData = JSON.parse(audioScript.textContent);
        } catch (e) {
            console.error("Failed to parse audio data:", e);
        }
    }
    // Create the node with imported data
    const node = $createWordDecoratorNode(wordId, phrase, pronunciation, definition, audio, rubyTags, parseInt(version, 10), true, // isExpanded
    false, // isSelected
    "", // searchTerm
    null, // sharedHistory - will be set by plugin
    null, // onUpdate - will be set by plugin
    null, // onDelete - will be set by plugin
    null, // onToggleExpand - will be set by plugin
    null, // onToggleSelect - will be set by plugin
    null, // onOpenRubyDialog - will be set by plugin
    {}, // audioFiles - would be populated from audioData if needed
    "", // identityId
    0 // index
    );
    return {
        node
    };
}
// Helper function for text width calculation
function getTextWidth(text) {
    const element = document.createElement("span");
    element.style.position = "absolute";
    element.style.visibility = "hidden";
    element.style.whiteSpace = "nowrap";
    element.textContent = text;
    document.body.appendChild(element);
    const style = getComputedStyle(element);
    const font = `${style.fontStyle} ${style.fontWeight} ${style.fontSize}/${style.lineHeight} ${style.fontFamily}`;
    const canvas = document.createElement("canvas");
    const context = canvas.getContext("2d");
    context.font = font;
    const metrics = context.measureText(text);
    document.body.removeChild(element);
    return metrics.width;
}
// =============================================================================
// RubyTagEditor - Text selection based interface (from original DictionaryEditor)
// =============================================================================
function RubyTagEditor({ inPhrase, inPronunciation, word }) {
    _s();
    const { bumpWordVersion } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [phrase, setPhrase] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(inPhrase ?? "");
    const [pronunciation, setPronunciation] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(inPronunciation ?? "");
    const [selectedPhrase, setSelectedPhrase] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [selectedPronunciation, setSelectedPronunciation] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [loading, setLoading] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [selectionStart, setSelectionStart] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [selectionEnd, setSelectionEnd] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [rubyTags, setRubyTags] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    const doNothing = (e)=>{
        e.preventDefault();
        e.stopPropagation();
    };
    const _escapeHtml = (str)=>str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    const _setRubyTags = (phraseText, pronunciationText)=>{
        const rubyTag = `${_escapeHtml(phraseText)}<rt>${_escapeHtml(pronunciationText)}</rt>`;
        setRubyTags([
            ...rubyTags,
            rubyTag
        ]);
    };
    const handlePhraseChange = (event)=>{
        setPhrase(event.target.value);
    };
    const handlePronunciationChange = (event_0)=>{
        setPronunciation(event_0.target.value);
    };
    const handleSelectionStart = (event_1)=>{
        setSelectionStart(event_1.target.selectionStart);
    };
    const handleSelectionEndPhrase = (event_2)=>{
        const selectionEnd_0 = event_2.target.selectionEnd;
        if (selectionStart !== null && selectionEnd_0 !== selectionStart) {
            const selectedPhrase_0 = phrase.substring(selectionStart, selectionEnd_0);
            setPhrase(phrase.replace(selectedPhrase_0, ""));
            setSelectedPhrase(selectedPhrase_0);
            setSelectionStart(null);
            if (selectedPhrase_0.length > 0 && selectedPronunciation.length > 0) {
                _setRubyTags(selectedPhrase_0, selectedPronunciation);
                setSelectedPhrase("");
                setSelectedPronunciation("");
            }
        }
    };
    const handleSelectionEndPronunciation = (event_3)=>{
        const selectionEnd_1 = event_3.target.selectionEnd;
        if (selectionStart !== null && selectionEnd_1 !== selectionStart) {
            const selectedPronunciation_0 = pronunciation.substring(selectionStart, selectionEnd_1);
            setPronunciation(pronunciation.replace(selectedPronunciation_0, ""));
            setSelectedPronunciation(selectedPronunciation_0);
            setSelectionStart(null);
            if (selectedPhrase.length > 0 && selectedPronunciation_0.length > 0) {
                _setRubyTags(selectedPhrase, selectedPronunciation_0);
                setSelectedPhrase("");
                setSelectedPronunciation("");
            }
        }
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "RubyTagEditor.useEffect": ()=>{
            // Reset all state when props change (dialog reopens)
            setPhrase(inPhrase || "");
            setPronunciation(inPronunciation || "");
            setSelectedPhrase("");
            setSelectedPronunciation("");
            setSelectionStart(null);
            setSelectionEnd(null);
            setRubyTags([]);
            setLoading(false);
        }
    }["RubyTagEditor.useEffect"], [
        inPhrase,
        inPronunciation,
        word?.id
    ]);
    const rubyTagsString = rubyTags.join(" ");
    let hideAll = false;
    if (selectedPhrase === "" && phrase === "" && selectedPronunciation === "" && pronunciation === "") {
        hideAll = true;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            width: "100%",
            textWrap: "nowrap"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                width: "100%",
                maxWidth: "900px",
                mx: "auto",
                p: 4
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                    severity: "info",
                    sx: {
                        mb: 4,
                        width: "100%",
                        whiteSpace: "normal",
                        wordWrap: "break-word"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body1",
                            sx: {
                                mb: 1.5,
                                fontSize: "1.1rem",
                                whiteSpace: "normal"
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: t("dictionaryEditor.rubyTagsTitle")
                            }, void 0, false, {
                                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                lineNumber: 283,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 278,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body1",
                            component: "div",
                            sx: {
                                fontSize: "1rem",
                                lineHeight: 1.8,
                                whiteSpace: "normal"
                            },
                            children: [
                                t("dictionaryEditor.rubyTagsStep1"),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 291,
                                    columnNumber: 13
                                }, this),
                                t("dictionaryEditor.rubyTagsStep2"),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 293,
                                    columnNumber: 13
                                }, this),
                                t("dictionaryEditor.rubyTagsStep3"),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 295,
                                    columnNumber: 13
                                }, this),
                                t("dictionaryEditor.rubyTagsStep4")
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 285,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                    lineNumber: 272,
                    columnNumber: 9
                }, this),
                !hideAll && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                            children: `
          input::selection {
            background-color: yellow;
            color: black;
          }
          input {
            user-select: text;
          }
          .selected-text {
            background-color: yellow;
            color: black;
            user-select: none;
          }
        `
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 300,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                mb: 4,
                                width: "100%"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body1",
                                    color: "text.secondary",
                                    sx: {
                                        mb: 1.5,
                                        display: "block",
                                        fontSize: "1.1rem",
                                        fontWeight: 500
                                    },
                                    children: t("dictionaryEditor.pronunciationLabel")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 320,
                                    columnNumber: 15
                                }, this),
                                selectedPronunciation !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        backgroundColor: "yellow",
                                        color: "black",
                                        userSelect: "none",
                                        display: "inline-block",
                                        fontSize: "2.5rem",
                                        padding: "8px",
                                        marginBottom: "8px"
                                    },
                                    children: selectedPronunciation
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 328,
                                    columnNumber: 50
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    style: {
                                        caretColor: "black",
                                        border: "3px solid #ccc",
                                        borderRadius: "8px",
                                        padding: "16px",
                                        margin: 0,
                                        display: "block",
                                        width: "100%",
                                        fontSize: "2.5rem",
                                        fontFamily: "inherit",
                                        textAlign: "center"
                                    },
                                    type: "text",
                                    value: pronunciation,
                                    onClick: doNothing,
                                    onChange: handlePronunciationChange,
                                    onSelect: handleSelectionStart,
                                    onBlur: handleSelectionEndPronunciation
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 339,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 316,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                mb: 4,
                                width: "100%"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body1",
                                    color: "text.secondary",
                                    sx: {
                                        mb: 1.5,
                                        display: "block",
                                        fontSize: "1.1rem",
                                        fontWeight: 500
                                    },
                                    children: t("dictionaryEditor.phraseLabel")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 356,
                                    columnNumber: 15
                                }, this),
                                selectedPhrase !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    style: {
                                        backgroundColor: "yellow",
                                        color: "black",
                                        userSelect: "none",
                                        fontSize: "2.5rem",
                                        padding: "8px",
                                        marginBottom: "8px",
                                        display: "inline-block"
                                    },
                                    children: selectedPhrase
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 364,
                                    columnNumber: 43
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    style: {
                                        caretColor: "black",
                                        border: "3px solid #ccc",
                                        borderRadius: "8px",
                                        padding: "16px",
                                        margin: 0,
                                        display: "block",
                                        width: "100%",
                                        fontSize: "2.5rem",
                                        fontFamily: "inherit",
                                        textAlign: "center"
                                    },
                                    type: "text",
                                    value: phrase,
                                    onClick: doNothing,
                                    onChange: handlePhraseChange,
                                    onSelect: handleSelectionStart,
                                    onBlur: handleSelectionEndPhrase
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 375,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 352,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        mb: 4,
                        width: "100%"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body1",
                            color: "text.secondary",
                            sx: {
                                mb: 1.5,
                                display: "block",
                                fontSize: "1.1rem",
                                fontWeight: 500
                            },
                            children: t("dictionaryEditor.rubyTagPreview")
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 393,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                p: 3,
                                border: "3px solid #e0e0e0",
                                borderRadius: 2,
                                minHeight: "120px",
                                bgcolor: "grey.100",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center"
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ruby", {
                                style: {
                                    fontSize: "2.5rem"
                                },
                                dangerouslySetInnerHTML: {
                                    __html: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].sanitize(rubyTagsString || "<em>No ruby tags yet</em>", {
                                        ALLOWED_TAGS: [
                                            "rt",
                                            "rp",
                                            "em"
                                        ],
                                        ALLOWED_ATTR: []
                                    })
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                lineNumber: 411,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 401,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                    lineNumber: 389,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: "flex",
                        gap: 2,
                        mt: 2,
                        justifyContent: "center"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                            title: "Add selection",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "large",
                                    color: "inherit",
                                    disabled: loading,
                                    onClick: (event_4)=>{
                                        event_4.preventDefault();
                                        event_4.stopPropagation();
                                    },
                                    sx: {
                                        border: "2px solid currentColor"
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "large"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                        lineNumber: 435,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 429,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                lineNumber: 428,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 427,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                            title: "Clear and reset",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "large",
                                    color: "error",
                                    disabled: loading,
                                    onClick: ()=>{
                                        setRubyTags([]);
                                        setSelectedPhrase("");
                                        setSelectedPronunciation("");
                                        setSelectionStart(null);
                                        setSelectionEnd(null);
                                    },
                                    sx: {
                                        border: "2px solid currentColor"
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "large"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                        lineNumber: 450,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 441,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                lineNumber: 440,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 439,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                            title: "Save ruby tags",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "large",
                                    color: "primary",
                                    disabled: loading,
                                    onClick: async ()=>{
                                        setLoading(true);
                                        const versionCtrl = bumpWordVersion(word.id, word._version);
                                        try {
                                            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                                            const { data: saved, errors } = await client.models.Word.update({
                                                id: word.id,
                                                rubyTags: rubyTagsString,
                                                _version: word._version
                                            });
                                            if (errors?.length) {
                                                versionCtrl.rollback();
                                            } else if (saved) {
                                                versionCtrl.confirm(saved._version);
                                            }
                                        } catch (error) {
                                            versionCtrl.rollback();
                                            console.error("Failed to save ruby tags:", error);
                                        }
                                        setRubyTags([]);
                                        setSelectedPhrase("");
                                        setSelectedPronunciation("");
                                        setSelectionStart(null);
                                        setSelectionEnd(null);
                                        setLoading(false);
                                    },
                                    sx: {
                                        border: "2px solid currentColor"
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "large"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                        lineNumber: 487,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 456,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                lineNumber: 455,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 454,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                    lineNumber: 421,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DictionaryEditor2.jsx",
            lineNumber: 263,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/DictionaryEditor2.jsx",
        lineNumber: 259,
        columnNumber: 10
    }, this);
}
_s(RubyTagEditor, "lBytYCrk+3MFgSq+KyH25Ev028c=");
_c = RubyTagEditor;
// =============================================================================
// WordDecoratorNode - Represents a single vocabulary word in the editor
// =============================================================================
class WordDecoratorNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __wordId;
    __phrase;
    __pronunciation;
    __definition;
    __audio;
    __rubyTags;
    __version;
    __isExpanded;
    __isSelected;
    __searchTerm;
    __sharedHistory;
    __onUpdate;
    __onDelete;
    __onToggleExpand;
    __onToggleSelect;
    __onOpenRubyDialog;
    __audioFiles;
    __identityId;
    __index;
    __documentID;
    __fileID;
    __filename;
    __page;
    static getType() {
        return "word-decorator";
    }
    static clone(node) {
        return new WordDecoratorNode(node.__wordId, node.__phrase, node.__pronunciation, node.__definition, node.__audio, node.__rubyTags, node.__version, node.__isExpanded, node.__isSelected, node.__searchTerm, node.__sharedHistory, node.__onUpdate, node.__onDelete, node.__onToggleExpand, node.__onToggleSelect, node.__onOpenRubyDialog, node.__audioFiles, node.__identityId, node.__index, node.__documentID, node.__fileID, node.__filename, node.__page, node.__key);
    }
    constructor(wordId, phrase, pronunciation, definition, audio, rubyTags, version, isExpanded = true, isSelected = false, searchTerm = "", sharedHistory = null, onUpdate = null, onDelete = null, onToggleExpand = null, onToggleSelect = null, onOpenRubyDialog = null, audioFiles = {}, identityId = "", index = 0, documentID = null, fileID = null, filename = null, page = null, key){
        super(key);
        this.__wordId = wordId;
        this.__phrase = phrase;
        this.__pronunciation = pronunciation;
        this.__definition = definition;
        this.__audio = audio || [];
        this.__rubyTags = rubyTags || "";
        this.__version = version;
        this.__isExpanded = isExpanded;
        this.__isSelected = isSelected;
        this.__searchTerm = searchTerm;
        this.__sharedHistory = sharedHistory;
        this.__onUpdate = onUpdate;
        this.__onDelete = onDelete;
        this.__onToggleExpand = onToggleExpand;
        this.__onToggleSelect = onToggleSelect;
        this.__onOpenRubyDialog = onOpenRubyDialog;
        this.__audioFiles = audioFiles;
        this.__identityId = identityId;
        this.__index = index;
        this.__documentID = documentID;
        this.__fileID = fileID;
        this.__filename = filename;
        this.__page = page;
    }
    static importJSON(serializedNode) {
        const { wordId, phrase, pronunciation, definition, audio, rubyTags, version, isExpanded, isSelected, index } = serializedNode;
        return $createWordDecoratorNode(wordId, phrase, pronunciation, definition, audio, rubyTags, version, isExpanded, isSelected, "", null, null, null, null, null, null, {}, "", index);
    }
    exportJSON() {
        return {
            type: "word-decorator",
            wordId: this.__wordId,
            phrase: this.__phrase,
            pronunciation: this.__pronunciation,
            definition: this.__definition,
            audio: this.__audio,
            rubyTags: this.__rubyTags,
            version: this.__version,
            isExpanded: this.__isExpanded,
            index: this.__index
        };
    }
    updateWord(updates) {
        const writable = this.getWritable();
        if (updates.phrase !== undefined) writable.__phrase = updates.phrase;
        if (updates.pronunciation !== undefined) writable.__pronunciation = updates.pronunciation;
        if (updates.definition !== undefined) writable.__definition = updates.definition;
        if (updates.audio !== undefined) writable.__audio = updates.audio;
        if (updates.rubyTags !== undefined) writable.__rubyTags = updates.rubyTags;
        if (updates._version !== undefined) writable.__version = updates._version;
    }
    setExpanded(isExpanded) {
        const writable = this.getWritable();
        writable.__isExpanded = isExpanded;
    }
    setSelected(isSelected) {
        const writable = this.getWritable();
        writable.__isSelected = isSelected;
    }
    setSearchTerm(searchTerm) {
        const writable = this.getWritable();
        writable.__searchTerm = searchTerm;
    }
    createDOM(config) {
        const div = document.createElement("div");
        div.setAttribute("data-lexical-word-id", this.__wordId);
        div.setAttribute("data-lexical-word-phrase", this.__phrase || "");
        div.setAttribute("data-lexical-word-pronunciation", this.__pronunciation || "");
        div.setAttribute("data-lexical-word-definition", this.__definition || "");
        div.setAttribute("data-lexical-word-ruby-tags", this.__rubyTags || "");
        div.setAttribute("data-lexical-word-version", this.__version || "1");
        // Audio URLs (S3 keys)
        if (this.__audio && this.__audio.length > 0) {
            div.setAttribute("data-lexical-audio-keys", JSON.stringify(this.__audio));
        }
        // Store fully formed S3 URLs if available
        if (this.__audioFiles && this.__audio && this.__audio.length > 0) {
            const audioUrls = this.__audio.map((key)=>{
                const file = this.__audioFiles[key];
                return file ? {
                    key,
                    url: file.url
                } : null;
            }).filter(Boolean);
            if (audioUrls.length > 0) {
                div.setAttribute("data-lexical-audio-urls", JSON.stringify(audioUrls));
            }
        }
        return div;
    }
    // Async method to export word with audio blobs as base64
    async exportDOMWithAudio() {
        const element = document.createElement("div");
        element.setAttribute("data-lexical-word-id", this.__wordId);
        element.setAttribute("data-lexical-word-phrase", this.__phrase || "");
        element.setAttribute("data-lexical-word-pronunciation", this.__pronunciation || "");
        element.setAttribute("data-lexical-word-definition", this.__definition || "");
        element.setAttribute("data-lexical-word-ruby-tags", this.__rubyTags || "");
        element.setAttribute("data-lexical-word-version", this.__version || "1");
        // Audio URLs (S3 keys)
        if (this.__audio && this.__audio.length > 0) {
            element.setAttribute("data-lexical-audio-keys", JSON.stringify(this.__audio));
        }
        // Store fully formed S3 URLs and base64 audio blobs
        if (this.__audioFiles && this.__audio && this.__audio.length > 0) {
            const audioUrls = [];
            const audioBlobs = [];
            for (const key of this.__audio){
                const file = this.__audioFiles[key];
                if (file) {
                    audioUrls.push({
                        key,
                        url: file.url
                    });
                    // Convert blob to base64
                    if (file.blob) {
                        const base64 = await blobToBase64(file.blob);
                        audioBlobs.push({
                            key,
                            base64,
                            url: file.url
                        });
                    }
                }
            }
            if (audioUrls.length > 0) {
                element.setAttribute("data-lexical-audio-urls", JSON.stringify(audioUrls));
            }
            if (audioBlobs.length > 0) {
                const script = document.createElement("script");
                script.type = "application/json";
                script.className = "lexical-word-audio-data";
                script.setAttribute("data-word-id", this.__wordId);
                script.textContent = JSON.stringify(audioBlobs);
                element.appendChild(script);
            }
        }
        return {
            element
        };
    }
    exportDOM() {
        const element = document.createElement("div");
        element.setAttribute("data-lexical-word-id", this.__wordId);
        element.setAttribute("data-lexical-word-phrase", this.__phrase || "");
        element.setAttribute("data-lexical-word-pronunciation", this.__pronunciation || "");
        element.setAttribute("data-lexical-word-definition", this.__definition || "");
        element.setAttribute("data-lexical-word-ruby-tags", this.__rubyTags || "");
        element.setAttribute("data-lexical-word-version", this.__version || "1");
        // Audio URLs (S3 keys)
        if (this.__audio && this.__audio.length > 0) {
            element.setAttribute("data-lexical-audio-keys", JSON.stringify(this.__audio));
        }
        // Store fully formed S3 URLs if available
        if (this.__audioFiles && this.__audio && this.__audio.length > 0) {
            const audioUrls = this.__audio.map((key)=>{
                const file = this.__audioFiles[key];
                return file ? {
                    key,
                    url: file.url
                } : null;
            }).filter(Boolean);
            if (audioUrls.length > 0) {
                element.setAttribute("data-lexical-audio-urls", JSON.stringify(audioUrls));
            }
        }
        // Note: Audio blobs are NOT included in synchronous exportDOM
        // Use exportDOMWithAudio() for complete serialization with base64 audio
        return {
            element
        };
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute("data-lexical-word-id")) {
                    return null;
                }
                return {
                    conversion: convertWordElement,
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    decorate() {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WordRowComponent, {
            wordId: this.__wordId,
            phrase: this.__phrase,
            pronunciation: this.__pronunciation,
            definition: this.__definition,
            audio: this.__audio,
            rubyTags: this.__rubyTags,
            version: this.__version,
            isExpanded: this.__isExpanded,
            isSelected: this.__isSelected,
            searchTerm: this.__searchTerm,
            sharedHistory: this.__sharedHistory,
            onUpdate: this.__onUpdate,
            onDelete: this.__onDelete,
            onToggleExpand: this.__onToggleExpand,
            onToggleSelect: this.__onToggleSelect,
            onOpenRubyDialog: this.__onOpenRubyDialog,
            audioFiles: this.__audioFiles,
            identityId: this.__identityId,
            index: this.__index,
            documentID: this.__documentID,
            fileID: this.__fileID,
            filename: this.__filename,
            page: this.__page,
            nodeKey: this.__key
        }, void 0, false, {
            fileName: "[project]/src/components/DictionaryEditor2.jsx",
            lineNumber: 742,
            columnNumber: 12
        }, this);
    }
    isInline() {
        return false;
    }
    isTopLevel() {
        return true;
    }
}
function $createWordDecoratorNode(wordId, phrase, pronunciation, definition, audio, rubyTags, version, isExpanded, isSelected, searchTerm, sharedHistory, onUpdate, onDelete, onToggleExpand, onToggleSelect, onOpenRubyDialog, audioFiles, identityId, index, documentID = null, fileID = null, filename = null, page = null) {
    return new WordDecoratorNode(wordId, phrase, pronunciation, definition, audio, rubyTags, version, isExpanded, isSelected, searchTerm, sharedHistory, onUpdate, onDelete, onToggleExpand, onToggleSelect, onOpenRubyDialog, audioFiles, identityId, index, documentID, fileID, filename, page);
}
function $isWordDecoratorNode(node) {
    return node instanceof WordDecoratorNode;
}
// =============================================================================
// WordRowComponent - The React component rendered by WordDecoratorNode
// =============================================================================
function WordRowComponent({ wordId, phrase, pronunciation, definition, audio, rubyTags, version, isExpanded, isSelected, searchTerm, sharedHistory, onUpdate, onDelete, onToggleExpand, onToggleSelect, onOpenRubyDialog, audioFiles, identityId, index, documentID, fileID, filename, page, nodeKey }) {
    _s1();
    const t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const [isDragging, setIsDragging] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [fileOperations, setFileOperations] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    const [audioFilesToUpload, setAudioFilesToUpload] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    const [recordingDialogOpen, setRecordingDialogOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [rubyDialogOpen, setRubyDialogOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const { unit } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    // Memoize word preset to avoid recreating on every render
    const wordPreset = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "WordRowComponent.useMemo[wordPreset]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$recordingStudioPresets$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createWordPreset"])({
                phrase,
                pronunciation,
                definition
            })
    }["WordRowComponent.useMemo[wordPreset]"], [
        phrase,
        pronunciation,
        definition
    ]);
    // Get the actual word object for RubyTagEditor
    const { filteredDictionary: dictionary } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const word = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "WordRowComponent.useMemo[word]": ()=>{
            return dictionary ? Object.values(dictionary).find({
                "WordRowComponent.useMemo[word]": (w)=>w.id === wordId
            }["WordRowComponent.useMemo[word]"]) : null;
        }
    }["WordRowComponent.useMemo[word]"], [
        dictionary,
        wordId
    ]);
    const isEvenRow = index % 2 === 0;
    const audioUrls = audio || [];
    const hasAudio = audioUrls.length > 0;
    // Handle audio file uploads
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "WordRowComponent.useEffect": ()=>{
            const asyncFunc = {
                "WordRowComponent.useEffect.asyncFunc": async ()=>{
                    if (audioFilesToUpload.length === 0) return;
                    const _audio = [];
                    for(let i = 0; i < audioFilesToUpload.length; i++){
                        const { file, name } = audioFilesToUpload[i];
                        try {
                            // Gen 2 API requires full path with protection level prefix
                            const s3Path = `protected/${identityId}/audio/${name}`;
                            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
                                path: s3Path,
                                data: file,
                                options: {
                                    contentType: "audio/ogg",
                                    onProgress: {
                                        "WordRowComponent.useEffect.asyncFunc": ({ transferredBytes, totalBytes })=>{
                                            if (totalBytes) {
                                                const percentage = Math.round(transferredBytes / totalBytes * 100);
                                                setFileOperations({
                                                    "WordRowComponent.useEffect.asyncFunc": (prev)=>prev.map({
                                                            "WordRowComponent.useEffect.asyncFunc": (op, idx)=>idx === i ? {
                                                                    ...op,
                                                                    progress: `${percentage}%`
                                                                } : op
                                                        }["WordRowComponent.useEffect.asyncFunc"])
                                                }["WordRowComponent.useEffect.asyncFunc"]);
                                            }
                                        }
                                    }["WordRowComponent.useEffect.asyncFunc"]
                                }
                            }).result;
                            _audio.push(result.path);
                        } catch (error) {
                            console.error("Error uploading file:", error);
                        }
                    }
                    if (_audio.length > 0 && onUpdate) {
                        const newAudio = deduplicateUrls([
                            ...audioUrls,
                            ..._audio
                        ]);
                        await onUpdate(wordId, {
                            audio: newAudio
                        }, version);
                    }
                    setAudioFilesToUpload([]);
                    setFileOperations([]);
                }
            }["WordRowComponent.useEffect.asyncFunc"];
            asyncFunc();
        }
    }["WordRowComponent.useEffect"], [
        audioFilesToUpload
    ]);
    const handleDragOver = (event)=>{
        event.preventDefault();
        event.stopPropagation();
        setIsDragging(true);
    };
    const handleDrop = async (event_0)=>{
        event_0.preventDefault();
        event_0.stopPropagation();
        const files = Array.from(event_0.dataTransfer.files);
        const _toupload = files.map((f, index_0)=>({
                file: f,
                name: `${unit.id}_${wordId}_${Date.now()}_${index_0}.ogg`
            }));
        const _fileOperations = files.map((f_0)=>({
                name: f_0.name,
                progress: "0%"
            }));
        setAudioFilesToUpload(_toupload);
        setFileOperations(_fileOperations);
        setIsDragging(false);
    };
    const handleDragLeave = (e)=>{
        if (e.currentTarget === e.target) {
            setIsDragging(false);
        }
    };
    const confirmDeleteWord = async ()=>{
        // This function is a placeholder - deletion is now handled via the passed onDelete callback
        // which will trigger the confirmation dialog in the parent component
        if (onDelete) {
            await onDelete(wordId, phrase);
        }
    };
    const matchesSearch = searchTerm && (phrase && phrase.toLowerCase().includes(searchTerm.toLowerCase()) || pronunciation && pronunciation.toLowerCase().includes(searchTerm.toLowerCase()) || definition && definition.toLowerCase().includes(searchTerm.toLowerCase()));
    const wordItemRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const tabContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tabContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabContext"])();
    const [isHighlighted, setIsHighlighted] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    // Register ref for scrolling
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "WordRowComponent.useEffect": ()=>{
            if (tabContext?.registerItemRef && wordId) {
                tabContext.registerItemRef("word", wordId, wordItemRef);
            }
            return ({
                "WordRowComponent.useEffect": ()=>{
                    if (tabContext?.unregisterItemRef && wordId) {
                        tabContext.unregisterItemRef("word", wordId);
                    }
                }
            })["WordRowComponent.useEffect"];
        }
    }["WordRowComponent.useEffect"], [
        wordId,
        tabContext
    ]);
    // Highlight when focused from search results
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "WordRowComponent.useEffect": ()=>{
            if (tabContext?.focusItem?.type === "word" && tabContext.focusItem.id === wordId) {
                setIsHighlighted(true);
                // Auto-expand when focused
                if (onToggleExpand && !isExpanded) {
                    onToggleExpand(wordId);
                }
                // Remove highlight after 3 seconds
                const timer = setTimeout({
                    "WordRowComponent.useEffect.timer": ()=>setIsHighlighted(false)
                }["WordRowComponent.useEffect.timer"], 3000);
                return ({
                    "WordRowComponent.useEffect": ()=>clearTimeout(timer)
                })["WordRowComponent.useEffect"];
            }
        }
    }["WordRowComponent.useEffect"], [
        tabContext?.focusItem,
        wordId,
        onToggleExpand,
        isExpanded
    ]);
    // Adapt word data to VocabularyItem interface
    const vocabularyItem = {
        word: phrase || "",
        definition: definition || "",
        context: pronunciation,
        // Use pronunciation field for phonetic context
        phonetic: pronunciation,
        audio: audio,
        documentID: documentID,
        fileID: fileID,
        filename: filename,
        page: page
    };
    const handleUpdateWrapper = async (itemIndex, field, newValue)=>{
        if (onUpdate) {
            // Map VocabularyCard field names to Word model field names
            const fieldMapping = {
                word: "phrase",
                definition: "definition",
                context: "pronunciation",
                phonetic: "pronunciation"
            };
            const mappedField = fieldMapping[field] || field;
            await onUpdate(wordId, {
                [mappedField]: newValue
            }, version);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        ref: wordItemRef,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VocabularyReview2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VocabularyCard"], {
                item: vocabularyItem,
                index: index,
                isSelected: isSelected,
                isExpanded: isExpanded,
                existsInDictionary: true,
                alreadyImported: true,
                searchTerm: searchTerm,
                onToggleSelect: ()=>onToggleSelect(wordId),
                onToggleExpand: ()=>onToggleExpand(wordId),
                onUpdate: handleUpdateWrapper,
                onOpenRubyEditor: ()=>setRubyDialogOpen(true),
                onOpenAudioStudio: ()=>setRecordingDialogOpen(true)
            }, void 0, false, {
                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                lineNumber: 957,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                open: rubyDialogOpen,
                onClose: ()=>setRubyDialogOpen(false),
                maxWidth: "lg",
                fullWidth: true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                        children: [
                            t1("dictionaryEditor.rubyTagEditorTitle"),
                            " - ",
                            phrase
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 961,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RubyTagEditor, {
                            inPhrase: phrase,
                            inPronunciation: pronunciation,
                            word: word
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 965,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 964,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                lineNumber: 960,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3Modal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                "data-tour": "audio-upload",
                open: recordingDialogOpen,
                onClose: ()=>setRecordingDialogOpen(false),
                onSave: async (payload)=>{
                    const { phraseAudio, definitionAudio, scriptData } = payload;
                    const updates = {};
                    // Map phrase track takes to Word.audio[]
                    if (phraseAudio?.length > 0) {
                        const newPaths = phraseAudio.map((t_0)=>t_0.audioPath).filter(Boolean);
                        const audioUrls_0 = audio || [];
                        updates.audio = deduplicateUrls([
                            ...audioUrls_0,
                            ...newPaths
                        ]);
                    }
                    // Map definition track takes to Word.definitionAudio[]
                    if (definitionAudio?.length > 0) {
                        const newPaths_0 = definitionAudio.map((t_1)=>t_1.audioPath).filter(Boolean);
                        const defUrls = word?.definitionAudio || [];
                        updates.definitionAudio = deduplicateUrls([
                            ...defUrls,
                            ...newPaths_0
                        ]);
                    }
                    // Persist full scriptData for re-opening
                    if (scriptData) {
                        updates.scriptData = JSON.stringify(scriptData);
                    }
                    if (Object.keys(updates).length > 0 && onUpdate) {
                        await onUpdate(wordId, updates, version);
                    }
                },
                title: `${t1("dictionaryEditor.audioStudioTitle")} - ${phrase}`,
                preset: "word",
                scriptData: wordPreset.scriptData,
                lockedTracks: wordPreset.lockedTracks,
                identityId: identityId
            }, void 0, false, {
                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                lineNumber: 970,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/DictionaryEditor2.jsx",
        lineNumber: 956,
        columnNumber: 10
    }, this);
}
_s1(WordRowComponent, "Uu1JEU+eVCvAPrBgFkat7ZNHca0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tabContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabContext"]
    ];
});
_c1 = WordRowComponent;
// =============================================================================
// WordsPlugin - Manages word nodes and synchronization
// =============================================================================
// NestedWordField - Individual field editor with Lexical
// =============================================================================
function NestedWordField(t0) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(40);
    if ($[0] !== "32423b0d4e848180ded78b2546ca5123711e037a2d846c779fbb915d68be5ad4") {
        for(let $i = 0; $i < 40; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "32423b0d4e848180ded78b2546ca5123711e037a2d846c779fbb915d68be5ad4";
    }
    const { value, field, wordId, version, onSave, sharedHistory, searchTerm, placeholder, label: t1 } = t0;
    const label = t1 === undefined ? "" : t1;
    const [, setLocalValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(value ?? "");
    const saveTimeoutRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    let t2;
    let t3;
    if ($[1] !== value) {
        t2 = ({
            "NestedWordField[useEffect()]": ()=>{
                setLocalValue(value);
            }
        })["NestedWordField[useEffect()]"];
        t3 = [
            value
        ];
        $[1] = value;
        $[2] = t2;
        $[3] = t3;
    } else {
        t2 = $[2];
        t3 = $[3];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t2, t3);
    const t4 = `WordField-${field}-${wordId}`;
    let t5;
    let t6;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$mark$2f$LexicalMark$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MarkNode"]
        ];
        t6 = {
            mark: "search-highlight"
        };
        $[4] = t5;
        $[5] = t6;
    } else {
        t5 = $[4];
        t6 = $[5];
    }
    let t7;
    if ($[6] !== value) {
        t7 = ()=>{
            const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
            root.clear();
            const paragraph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])();
            const text = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(value || "");
            paragraph.append(text);
            root.append(paragraph);
        };
        $[6] = value;
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    let t8;
    if ($[8] !== t4 || $[9] !== t7) {
        t8 = {
            namespace: t4,
            nodes: t5,
            theme: t6,
            onError: _temp,
            editorState: t7
        };
        $[8] = t4;
        $[9] = t7;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    const initialConfig = t8;
    let t9;
    if ($[11] !== field || $[12] !== onSave || $[13] !== value || $[14] !== version || $[15] !== wordId) {
        t9 = ({
            "NestedWordField[handleChange]": (editorState)=>{
                editorState.read({
                    "NestedWordField[handleChange > editorState.read()]": ()=>{
                        const root_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
                        const textContent = root_0.getTextContent();
                        setLocalValue(textContent);
                        if (saveTimeoutRef.current) {
                            clearTimeout(saveTimeoutRef.current);
                        }
                        saveTimeoutRef.current = setTimeout({
                            "NestedWordField[handleChange > editorState.read() > setTimeout()]": ()=>{
                                if (onSave && textContent !== value) {
                                    onSave(wordId, {
                                        [field]: textContent
                                    }, version);
                                }
                            }
                        }["NestedWordField[handleChange > editorState.read() > setTimeout()]"], 1000);
                    }
                }["NestedWordField[handleChange > editorState.read()]"]);
            }
        })["NestedWordField[handleChange]"];
        $[11] = field;
        $[12] = onSave;
        $[13] = value;
        $[14] = version;
        $[15] = wordId;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    const handleChange = t9;
    let t10;
    if ($[17] !== label) {
        t10 = {
            padding: 0,
            margin: 0,
            "& .word-field-editor": {
                cursor: "text",
                border: "3px dashed",
                borderColor: "divider",
                borderRadius: 1,
                padding: 1,
                margin: 1,
                "&::before": label ? {
                    content: `"${label}"`,
                    fontWeight: 600,
                    color: "text.secondary"
                } : {}
            }
        };
        $[17] = label;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    let t11;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentEditable"], {
            className: "word-field-editor"
        }, void 0, false, {
            fileName: "[project]/src/components/DictionaryEditor2.jsx",
            lineNumber: 1154,
            columnNumber: 11
        }, this);
        $[19] = t11;
    } else {
        t11 = $[19];
    }
    const t12 = label ? "80px" : 0;
    let t13;
    if ($[20] !== t12) {
        t13 = {
            position: "absolute",
            top: 0,
            left: t12,
            color: "text.disabled",
            pointerEvents: "none"
        };
        $[20] = t12;
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    let t14;
    if ($[22] !== placeholder || $[23] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalRichTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RichTextPlugin"], {
            contentEditable: t11,
            placeholder: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: t13,
                children: placeholder
            }, void 0, false, {
                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                lineNumber: 1176,
                columnNumber: 62
            }, this),
            ErrorBoundary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalErrorBoundary"]
        }, void 0, false, {
            fileName: "[project]/src/components/DictionaryEditor2.jsx",
            lineNumber: 1176,
            columnNumber: 11
        }, this);
        $[22] = placeholder;
        $[23] = t13;
        $[24] = t14;
    } else {
        t14 = $[24];
    }
    let t15;
    if ($[25] !== sharedHistory) {
        t15 = sharedHistory && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HistoryPlugin"], {
            externalHistoryState: sharedHistory
        }, void 0, false, {
            fileName: "[project]/src/components/DictionaryEditor2.jsx",
            lineNumber: 1185,
            columnNumber: 28
        }, this);
        $[25] = sharedHistory;
        $[26] = t15;
    } else {
        t15 = $[26];
    }
    let t16;
    if ($[27] !== handleChange) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OnChangePlugin"], {
            onChange: handleChange
        }, void 0, false, {
            fileName: "[project]/src/components/DictionaryEditor2.jsx",
            lineNumber: 1193,
            columnNumber: 11
        }, this);
        $[27] = handleChange;
        $[28] = t16;
    } else {
        t16 = $[28];
    }
    let t17;
    if ($[29] !== searchTerm) {
        t17 = searchTerm && searchTerm.length >= 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$SearchHighlightPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            searchTerm: searchTerm
        }, void 0, false, {
            fileName: "[project]/src/components/DictionaryEditor2.jsx",
            lineNumber: 1201,
            columnNumber: 51
        }, this);
        $[29] = searchTerm;
        $[30] = t17;
    } else {
        t17 = $[30];
    }
    let t18;
    if ($[31] !== initialConfig || $[32] !== t14 || $[33] !== t15 || $[34] !== t16 || $[35] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalComposer"], {
            initialConfig: initialConfig,
            children: [
                t14,
                t15,
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DictionaryEditor2.jsx",
            lineNumber: 1209,
            columnNumber: 11
        }, this);
        $[31] = initialConfig;
        $[32] = t14;
        $[33] = t15;
        $[34] = t16;
        $[35] = t17;
        $[36] = t18;
    } else {
        t18 = $[36];
    }
    let t19;
    if ($[37] !== t10 || $[38] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t10,
            children: t18
        }, void 0, false, {
            fileName: "[project]/src/components/DictionaryEditor2.jsx",
            lineNumber: 1221,
            columnNumber: 11
        }, this);
        $[37] = t10;
        $[38] = t18;
        $[39] = t19;
    } else {
        t19 = $[39];
    }
    return t19;
}
_s2(NestedWordField, "9LYiT53UdZyC/LVFPXuJvlkzlqA=");
_c2 = NestedWordField;
// =============================================================================
// WordsPlugin - Manages word nodes and synchronization
// =============================================================================
function _temp(error) {
    return console.error("Lexical error:", error);
}
function WordsPlugin({ dictionary, searchTerm, expandedItems, selectedItems, onToggleExpand, onToggleSelect, onOpenRubyDialog, sharedHistory, audioFiles, identityId, parentRef, setConfirmDialog, fullDictionary }) {
    _s3();
    const { bumpWordVersion } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { softDelete } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecycleBin"])();
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    // Setup virtualizer for performance
    const dictionaryEntries = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "WordsPlugin.useMemo[dictionaryEntries]": ()=>{
            return dictionary ? Object.entries(dictionary) : [];
        }
    }["WordsPlugin.useMemo[dictionaryEntries]"], [
        dictionary
    ]);
    const virtualizer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"])({
        count: dictionaryEntries.length,
        getScrollElement: {
            "WordsPlugin.useVirtualizer[virtualizer]": ()=>parentRef?.current
        }["WordsPlugin.useVirtualizer[virtualizer]"],
        estimateSize: {
            "WordsPlugin.useVirtualizer[virtualizer]": ()=>100
        }["WordsPlugin.useVirtualizer[virtualizer]"],
        overscan: 5
    });
    // Update words when dictionary changes
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "WordsPlugin.useEffect": ()=>{
            if (!dictionary) return;
            editor.update({
                "WordsPlugin.useEffect": ()=>{
                    const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
                    root.clear();
                    Object.entries(dictionary).forEach({
                        "WordsPlugin.useEffect": ([key, word], index)=>{
                            const node = $createWordDecoratorNode(word.id, word.phrase, word.pronunciation, word.definition, word.audio || [], word.rubyTags || "", word._version || 1, expandedItems.has(word.id), selectedItems.has(word.id), searchTerm, sharedHistory, handleUpdateWord, handleDeleteWord, onToggleExpand, onToggleSelect, onOpenRubyDialog, audioFiles, identityId, index, word.documentID, word.fileID, word.filename, word.page);
                            root.append(node);
                        }
                    }["WordsPlugin.useEffect"]);
                }
            }["WordsPlugin.useEffect"]);
        }
    }["WordsPlugin.useEffect"], [
        dictionary,
        searchTerm,
        expandedItems,
        selectedItems,
        audioFiles,
        editor
    ]);
    const handleUpdateWord = async (wordId, updates, currentVersion)=>{
        try {
            const word_0 = Object.values(dictionary).find((w)=>w.id === wordId);
            if (!word_0) return;
            // Skip DynamoDB update if no fields remain
            if (Object.keys(updates).length === 0) return;
            const versionCtrl = bumpWordVersion(word_0.id, word_0._version);
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const { data: saved, errors } = await client.models.Word.update({
                id: word_0.id,
                ...updates,
                _version: word_0._version
            });
            if (errors?.length) {
                versionCtrl.rollback();
            } else if (saved) {
                versionCtrl.confirm(saved._version);
            }
        } catch (error) {
            console.error("Failed to update word:", error);
        }
    };
    const handleDeleteWord = async (wordId_0, phrase = "")=>{
        if (!setConfirmDialog) {
            console.error("setConfirmDialog not available");
            return;
        }
        // Show confirmation dialog before soft-deleting
        setConfirmDialog({
            open: true,
            message: `Move to Recycle Bin: "${phrase}"?`,
            severity: "warning",
            onConfirm: async ()=>{
                try {
                    const word_1 = Object.values(fullDictionary).find((w_0)=>w_0.id === wordId_0);
                    if (!word_1) {
                        console.error("Word not found:", wordId_0);
                        setConfirmDialog({
                            open: false,
                            message: "",
                            onConfirm: null,
                            severity: "warning"
                        });
                        return;
                    }
                    await softDelete("Word", word_1.id);
                    setConfirmDialog({
                        open: false,
                        message: "",
                        onConfirm: null,
                        severity: "warning"
                    });
                } catch (error_0) {
                    console.error("Failed to soft delete word:", error_0);
                    setConfirmDialog({
                        open: false,
                        message: "",
                        onConfirm: null,
                        severity: "warning"
                    });
                }
            }
        });
    };
    return null;
}
_s3(WordsPlugin, "RBZ2C9bkR8rwFHUznSpYc+6aPug=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecycleBin"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"]
    ];
});
_c3 = WordsPlugin;
function DictionaryEditor2() {
    _s4();
    const t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const [open, setOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [isHelpOpen, setHelpOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [expandedItems, setExpandedItems] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(new Set());
    const [filteredDictionary, setFilteredDictionary] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [selectedItems, setSelectedItems] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(new Set());
    const [contextMenu, setContextMenu] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [confirmDialog, setConfirmDialog] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        open: false,
        message: "",
        onConfirm: null,
        severity: "warning"
    });
    const sharedHistoryState = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$history$2f$LexicalHistory$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEmptyHistoryState"])());
    const [search, setSearch] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [newPhrase, setNewPhrase] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [newPronunciation, setNewPronunciation] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [newDefinition, setNewDefinition] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [rubyDialogPhrase, setRubyDialogPhrase] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [rubyDialogPronunciation, setRubyDialogPronunciation] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [rubyDialogOpen, setRubyDialogOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [rubyDialogWord, setRubyDialogWord] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [newWordFormOpen, setNewWordFormOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const { filteredDictionary: dictionary, showDeleted, setShowDeleted, deletedWords } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { audioFiles, refreshAudioFiles, session } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { identityId } = session || {};
    const { unit } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { softDelete } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecycleBin"])();
    const parentRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    // Filter words based on search
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "DictionaryEditor2.useEffect": ()=>{
            if (!search || !dictionary) {
                setFilteredDictionary(dictionary);
                return;
            }
            const filtered = {};
            Object.entries(dictionary).forEach({
                "DictionaryEditor2.useEffect": ([key, word])=>{
                    const matchesSearch = word.phrase && word.phrase.toLowerCase().includes(search.toLowerCase()) || word.pronunciation && word.pronunciation.toLowerCase().includes(search.toLowerCase()) || word.definition && word.definition.toLowerCase().includes(search.toLowerCase());
                    if (matchesSearch) {
                        filtered[key] = word;
                    }
                }
            }["DictionaryEditor2.useEffect"]);
            setFilteredDictionary(filtered);
        }
    }["DictionaryEditor2.useEffect"], [
        search,
        dictionary
    ]);
    const handleToggleExpand = (id)=>{
        setExpandedItems((prev)=>{
            const newSet = new Set(prev);
            if (newSet.has(id)) {
                newSet.delete(id);
            } else {
                newSet.add(id);
            }
            return newSet;
        });
    };
    const handleToggleSelect = (id_0)=>{
        setSelectedItems((prev_0)=>{
            const newSet_0 = new Set(prev_0);
            if (newSet_0.has(id_0)) {
                newSet_0.delete(id_0);
            } else {
                newSet_0.add(id_0);
            }
            return newSet_0;
        });
    };
    const handleExpandAll = ()=>{
        const allIds = Object.values(filteredDictionary || {}).map((w)=>w.id);
        setExpandedItems(new Set(allIds));
    };
    const handleCollapseAll = ()=>{
        setExpandedItems(new Set());
    };
    const handleSelectAll = ()=>{
        const allIds_0 = Object.values(filteredDictionary || {}).map((w_0)=>w_0.id);
        setSelectedItems(new Set(allIds_0));
    };
    const handleDeselectAll = ()=>{
        setSelectedItems(new Set());
    };
    const handleBulkDelete = async ()=>{
        if (selectedItems.size === 0) return;
        setConfirmDialog({
            open: true,
            message: `Move ${selectedItems.size} selected word(s) to Recycle Bin?`,
            severity: "warning",
            onConfirm: async ()=>{
                try {
                    const words = Object.values(dictionary).filter((w_1)=>selectedItems.has(w_1.id));
                    const results = await Promise.allSettled(words.map((word_0)=>softDelete("Word", word_0.id)));
                    const failures = results.filter((r)=>r.status === "rejected");
                    if (failures.length > 0) {
                        console.warn(`[DictionaryEditor] ${failures.length} word(s) failed to soft delete`);
                    }
                    setSelectedItems(new Set());
                    setConfirmDialog({
                        open: false,
                        message: "",
                        onConfirm: null,
                        severity: "warning"
                    });
                } catch (error) {
                    console.error("Failed to soft delete words:", error);
                    setConfirmDialog({
                        open: false,
                        message: "",
                        onConfirm: null,
                        severity: "warning"
                    });
                }
            }
        });
    };
    const handleContextMenuClose = ()=>{
        setContextMenu(null);
    };
    const toggleNewWordFormOpen = ()=>{
        setNewWordFormOpen(!newWordFormOpen);
    };
    const handleOpenRubyDialog = (wordId, phrase, pronunciation)=>{
        const word_1 = Object.values(dictionary || {}).find((w_2)=>w_2.id === wordId);
        setRubyDialogWord(word_1);
        setRubyDialogPhrase(phrase);
        setRubyDialogPronunciation(pronunciation);
        setRubyDialogOpen(true);
    };
    const handleCloseRubyDialog = ()=>{
        setRubyDialogOpen(false);
        setRubyDialogWord(null);
        setRubyDialogPhrase("");
        setRubyDialogPronunciation("");
    };
    const handleCreateNewWord = async ()=>{
        if (!newPhrase.trim()) return;
        try {
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            await client.models.Word.create({
                phrase: newPhrase,
                pronunciation: newPronunciation,
                definition: newDefinition,
                audio: [],
                identityId: identityId
            });
            setNewPhrase("");
            setNewPronunciation("");
            setNewDefinition("");
            setNewWordFormOpen(false);
        } catch (error_0) {
            console.error("Failed to create word:", error_0);
        }
    };
    const debouncedSearch = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback(debounce({
        "DictionaryEditor2.useCallback[debouncedSearch]": (search_0)=>{
            setSearch(search_0);
        }
    }["DictionaryEditor2.useCallback[debouncedSearch]"], 500), []);
    const handleSearch = (e)=>{
        debouncedSearch(e.target.value.trim());
    };
    const initialConfig = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "DictionaryEditor2.useMemo[initialConfig]": ()=>({
                namespace: "DictionaryEditor2",
                theme: {},
                nodes: [
                    WordDecoratorNode
                ],
                onError: ({
                    "DictionaryEditor2.useMemo[initialConfig]": (error_1)=>console.error("Lexical error:", error_1)
                })["DictionaryEditor2.useMemo[initialConfig]"]
            })
    }["DictionaryEditor2.useMemo[initialConfig]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                open: contextMenu !== null,
                onClose: handleContextMenuClose,
                anchorReference: "anchorPosition",
                anchorPosition: contextMenu !== null ? {
                    top: contextMenu.mouseY,
                    left: contextMenu.mouseX
                } : undefined,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        disabled: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "caption",
                            color: "text.secondary",
                            children: [
                                selectedItems.size,
                                " selected"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 1545,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 1544,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {}, void 0, false, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 1549,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: ()=>{
                            handleContextMenuClose();
                            handleBulkDelete();
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                fontSize: "small",
                                sx: {
                                    mr: 1
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                lineNumber: 1554,
                                columnNumber: 11
                            }, this),
                            "Move to Recycle Bin"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 1550,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                lineNumber: 1540,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                "data-tour": "dictionary",
                sx: {
                    display: "flex",
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: 1,
                    padding: 1,
                    position: "sticky",
                    top: 0,
                    bgcolor: "background.paper",
                    borderBottom: "1px solid",
                    borderColor: "divider",
                    zIndex: 1
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            display: "flex",
                            alignItems: "center",
                            gap: 0.5
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                title: "Select/Deselect All",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                                    size: "small",
                                    checked: filteredDictionary && Object.keys(filteredDictionary).length > 0 && selectedItems.size === Object.keys(filteredDictionary).length,
                                    indeterminate: selectedItems.size > 0 && selectedItems.size < Object.keys(filteredDictionary || {}).length,
                                    onChange: (e_0)=>{
                                        if (selectedItems.size === Object.keys(filteredDictionary || {}).length) {
                                            handleDeselectAll();
                                        } else {
                                            handleSelectAll();
                                        }
                                    },
                                    disabled: !filteredDictionary || Object.keys(filteredDictionary).length === 0,
                                    sx: {
                                        p: 0.25
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 1582,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                lineNumber: 1581,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                title: expandedItems.size === 0 ? "Expand All" : "Collapse All",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "small",
                                    onClick: expandedItems.size === 0 ? handleExpandAll : handleCollapseAll,
                                    disabled: !filteredDictionary || Object.keys(filteredDictionary).length === 0,
                                    "aria-label": expandedItems.size === 0 ? t1("dictionaryEditor.expandAll") : t1("dictionaryEditor.collapseAll"),
                                    children: expandedItems.size === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                        lineNumber: 1595,
                                        columnNumber: 43
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                        lineNumber: 1595,
                                        columnNumber: 77
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 1594,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                lineNumber: 1593,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 1576,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                        defaultValue: search,
                        onInput: handleSearch,
                        type: "text",
                        size: "small",
                        fullWidth: true,
                        placeholder: "Search words...",
                        label: "Search"
                    }, void 0, false, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 1600,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: "New Word",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                            onClick: toggleNewWordFormOpen,
                            color: "primary",
                            size: "small",
                            "data-tour": "add-word-button",
                            "aria-label": t1("dictionaryEditor.newWordButton"),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                lineNumber: 1604,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 1603,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 1602,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: "Actions",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                            onClick: (e_1)=>setContextMenu(contextMenu ? null : {
                                    mouseX: e_1.clientX,
                                    mouseY: e_1.clientY
                                }),
                            size: "small",
                            disabled: selectedItems.size === 0,
                            "aria-label": t1("dictionaryEditor.actionsButton"),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                lineNumber: 1613,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 1609,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 1608,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ShowDeletedToggle$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        showDeleted: showDeleted,
                        setShowDeleted: setShowDeleted
                    }, void 0, false, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 1617,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                lineNumber: 1562,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                ref: parentRef,
                sx: {
                    overflowY: "auto",
                    overflowX: "hidden"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalComposer"], {
                    initialConfig: initialConfig,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalRichTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RichTextPlugin"], {
                            contentEditable: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentEditable"], {
                                style: {
                                    margin: 0,
                                    padding: 0,
                                    outline: "none",
                                    minHeight: "100%"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                lineNumber: 1626,
                                columnNumber: 44
                            }, this),
                            placeholder: null,
                            ErrorBoundary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalErrorBoundary"]
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 1626,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HistoryPlugin"], {}, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 1632,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WordsPlugin, {
                            dictionary: filteredDictionary,
                            searchTerm: search,
                            expandedItems: expandedItems,
                            selectedItems: selectedItems,
                            onToggleExpand: handleToggleExpand,
                            onToggleSelect: handleToggleSelect,
                            onOpenRubyDialog: handleOpenRubyDialog,
                            sharedHistory: sharedHistoryState.current,
                            audioFiles: audioFiles,
                            identityId: identityId,
                            parentRef: parentRef,
                            setConfirmDialog: setConfirmDialog,
                            fullDictionary: dictionary
                        }, void 0, false, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 1633,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                    lineNumber: 1625,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                lineNumber: 1621,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                open: newWordFormOpen,
                onClose: toggleNewWordFormOpen,
                maxWidth: "sm",
                fullWidth: true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                        children: t1("dictionaryEditor.createNewWordTitle")
                    }, void 0, false, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 1639,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            onSubmit: (e_2)=>{
                                e_2.preventDefault();
                                handleCreateNewWord();
                            },
                            "data-tour": "word-form",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                    value: newPhrase,
                                    required: true,
                                    onChange: (e_3)=>setNewPhrase(e_3.target.value),
                                    fullWidth: true,
                                    margin: "normal",
                                    label: "Phrase",
                                    variant: "outlined",
                                    name: "phrase"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 1645,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                    value: newPronunciation,
                                    required: true,
                                    onChange: (e_4)=>setNewPronunciation(e_4.target.value),
                                    fullWidth: true,
                                    margin: "normal",
                                    label: "Pronunciation",
                                    variant: "outlined",
                                    name: "pronunciation"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 1646,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                    value: newDefinition,
                                    required: true,
                                    onChange: (e_5)=>setNewDefinition(e_5.target.value),
                                    fullWidth: true,
                                    margin: "normal",
                                    label: "Definition",
                                    variant: "outlined",
                                    multiline: true,
                                    rows: 3,
                                    name: "definition"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 1647,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "contained",
                                    type: "submit",
                                    sx: {
                                        mt: 2
                                    },
                                    children: t1("dictionaryEditor.createWordButton")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 1648,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 1641,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 1640,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                lineNumber: 1638,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__["Portal"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
                    open: confirmDialog.open,
                    anchorOrigin: {
                        vertical: "top",
                        horizontal: "center"
                    },
                    onClose: (event, reason)=>{
                        if (reason === "clickaway") {
                            return;
                        }
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                        severity: confirmDialog.severity,
                        sx: {
                            width: "100%",
                            minWidth: "300px",
                            boxShadow: 3
                        },
                        action: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                gap: 1,
                                ml: 2
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    color: "inherit",
                                    size: "small",
                                    onClick: (e_6)=>{
                                        e_6.stopPropagation();
                                        if (confirmDialog.onConfirm) {
                                            confirmDialog.onConfirm();
                                        }
                                    },
                                    variant: "outlined",
                                    children: t1("dictionaryEditor.confirmButton")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 1676,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    color: "inherit",
                                    size: "small",
                                    onClick: (e_7)=>{
                                        e_7.stopPropagation();
                                        setConfirmDialog({
                                            open: false,
                                            message: "",
                                            onConfirm: null,
                                            severity: "warning"
                                        });
                                    },
                                    variant: "contained",
                                    children: t1("dictionaryEditor.cancel")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                                    lineNumber: 1684,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/DictionaryEditor2.jsx",
                            lineNumber: 1671,
                            columnNumber: 20
                        }, this),
                        children: confirmDialog.message
                    }, void 0, false, {
                        fileName: "[project]/src/components/DictionaryEditor2.jsx",
                        lineNumber: 1667,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/DictionaryEditor2.jsx",
                    lineNumber: 1659,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/DictionaryEditor2.jsx",
                lineNumber: 1658,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s4(DictionaryEditor2, "r2StC+xfDcdLvf1PeTRITmRPZIw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecycleBin"]
    ];
});
_c4 = DictionaryEditor2;
var _c, _c1, _c2, _c3, _c4;
__turbopack_context__.k.register(_c, "RubyTagEditor");
__turbopack_context__.k.register(_c1, "WordRowComponent");
__turbopack_context__.k.register(_c2, "NestedWordField");
__turbopack_context__.k.register(_c3, "WordsPlugin");
__turbopack_context__.k.register(_c4, "DictionaryEditor2");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_DictionaryEditor2_jsx_01qv2pt._.js.map