(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/aws-amplify/dist/esm/storage/index.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/index.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
;
;
;
;
;
;
;
;
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/getProperties.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getProperties",
    ()=>getProperties
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/Amplify.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$getProperties$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/getProperties.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function getProperties(input) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$getProperties$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProperties"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Amplify"], input);
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/copyObject.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "copyObject",
    ()=>copyObject,
    "validateCopyObjectHeaders",
    ()=>validateCopyObjectHeaders
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/parsePayload.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$integrityHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/integrityHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/IntegrityError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateObjectUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const copyObjectSerializer = async (input, endpoint)=>{
    const headers = {
        ...await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializeObjectConfigsToHeaders"])(input),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
            'x-amz-copy-source': input.CopySource,
            'x-amz-metadata-directive': input.MetadataDirective,
            'x-amz-tagging-directive': input.TaggingDirective,
            'x-amz-copy-source-if-match': input.CopySourceIfMatch,
            'x-amz-copy-source-if-unmodified-since': input.CopySourceIfUnmodifiedSince?.toUTCString(),
            'x-amz-source-expected-bucket-owner': input.ExpectedSourceBucketOwner,
            'x-amz-expected-bucket-owner': input.ExpectedBucketOwner
        })
    };
    validateCopyObjectHeaders(input, headers);
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.Key, 'Key');
    url.pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializePathnameObjectKey"])(url, input.Key);
    url.search = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrlSearchParams"]({
        'x-id': 'CopyObject'
    }).toString();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateObjectUrl"])({
        bucketName: input.Bucket,
        key: input.Key,
        objectURL: url
    });
    return {
        method: 'PUT',
        headers,
        url
    };
};
const validateCopyObjectHeaders = (input, headers)=>{
    const validations = [
        headers['x-amz-copy-source'] === input.CopySource,
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$integrityHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bothNilOrEqual"])(input.MetadataDirective, headers['x-amz-metadata-directive']),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$integrityHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bothNilOrEqual"])(input.TaggingDirective, headers['x-amz-tagging-directive']),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$integrityHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bothNilOrEqual"])(input.CopySourceIfMatch, headers['x-amz-copy-source-if-match']),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$integrityHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bothNilOrEqual"])(input.CopySourceIfUnmodifiedSince?.toUTCString(), headers['x-amz-copy-source-if-unmodified-since'])
    ];
    if (validations.some((validation)=>!validation)) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IntegrityError"]();
    }
};
const copyObjectDeserializer = async (response)=>{
    if (response.statusCode >= 300) {
        // error is always set when statusCode >= 300
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response));
    } else {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlBody"])(response);
        return {
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response)
        };
    }
};
const copyObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], copyObjectSerializer, copyObjectDeserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'text'
});
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/copy.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "copy",
    ()=>copy,
    "copyWithKey",
    ()=>copyWithKey
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$smithy$2f$md5$2d$js$2f$dist$2d$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@smithy/md5-js/dist-es/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$copyObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/copyObject.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/userAgent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveS3ConfigAndInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/utils/assertValidationError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/logger.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateBucketOwnerID.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateStorageOperationInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$isInputWithPath$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/isInputWithPath.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const isCopyInputWithPath = (input)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$isInputWithPath$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInputWithPath"])(input.source);
const storageBucketAssertion = (sourceBucket, destBucket)=>{
    /**  For multi-bucket, both source and destination bucket needs to be passed in
     *   or both can be undefined and we fallback to singleton's default value
     */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(// Both src & dest bucket option is present is acceptable
    sourceBucket !== undefined && destBucket !== undefined || !destBucket && !sourceBucket, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].InvalidCopyOperationStorageBucket);
};
const copy = async (amplify, input)=>{
    return isCopyInputWithPath(input) ? copyWithPath(amplify, input) : copyWithKey(amplify, input);
};
const copyWithPath = async (amplify, input)=>{
    const { source, destination } = input;
    storageBucketAssertion(source.bucket, destination.bucket);
    const { bucket: sourceBucket } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveS3ConfigAndInput"])(amplify, {
        path: input.source.path,
        options: {
            locationCredentialsProvider: input.options?.locationCredentialsProvider,
            ...input.source
        }
    });
    // The bucket, region, credentials of s3 client are resolved from destination.
    // Whereas the source bucket and path are a input parameter of S3 copy operation.
    const { s3Config, bucket: destBucket, identityId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveS3ConfigAndInput"])(amplify, {
        path: input.destination.path,
        options: {
            locationCredentialsProvider: input.options?.locationCredentialsProvider,
            customEndpoint: input.options?.customEndpoint,
            ...input.destination
        }
    }); // resolveS3ConfigAndInput does not make extra API calls or storage access if called repeatedly.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!!source.path, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].NoSourcePath);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!!destination.path, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].NoDestinationPath);
    const { objectKey: sourcePath } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateStorageOperationInput"])(source, identityId);
    const { objectKey: destinationPath } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateStorageOperationInput"])(destination, identityId);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateBucketOwnerID"])(source.expectedBucketOwner);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateBucketOwnerID"])(destination.expectedBucketOwner);
    const finalCopySource = `${sourceBucket}/${sourcePath}`;
    const finalCopyDestination = destinationPath;
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`copying "${finalCopySource}" to "${finalCopyDestination}".`);
    await serviceCopy({
        source: finalCopySource,
        destination: finalCopyDestination,
        bucket: destBucket,
        s3Config,
        notModifiedSince: input.source.notModifiedSince,
        eTag: input.source.eTag,
        expectedSourceBucketOwner: input.source?.expectedBucketOwner,
        expectedBucketOwner: input.destination?.expectedBucketOwner,
        tagConfig: input.tagConfig
    });
    return {
        path: finalCopyDestination
    };
};
/** @deprecated Use {@link copyWithPath} instead. */ const copyWithKey = async (amplify, input)=>{
    const { source, destination } = input;
    storageBucketAssertion(source.bucket, destination.bucket);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!!source.key, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].NoSourceKey);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!!destination.key, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].NoDestinationKey);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateBucketOwnerID"])(source.expectedBucketOwner);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateBucketOwnerID"])(destination.expectedBucketOwner);
    const { bucket: sourceBucket, keyPrefix: sourceKeyPrefix } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveS3ConfigAndInput"])(amplify, {
        ...input,
        options: {
            // @ts-expect-error: 'options' does not exist on type 'CopyInput'. In case of JS users set the location
            // credentials provider option, resolveS3ConfigAndInput will throw validation error.
            locationCredentialsProvider: input.options?.locationCredentialsProvider,
            ...input.source
        }
    });
    // The bucket, region, credentials of s3 client are resolved from destination.
    // Whereas the source bucket and path are a input parameter of S3 copy operation.
    const { s3Config, bucket: destBucket, keyPrefix: destinationKeyPrefix } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveS3ConfigAndInput"])(amplify, {
        ...input,
        options: {
            // @ts-expect-error: 'options' does not exist on type 'CopyInput'. In case of JS users set the location
            // credentials provider option, resolveS3ConfigAndInput will throw validation error.
            locationCredentialsProvider: input.options?.locationCredentialsProvider,
            ...input.destination
        }
    }); // resolveS3ConfigAndInput does not make extra API calls or storage access if called repeatedly.
    // TODO(ashwinkumar6) V6-logger: warn `You may copy files from another user if the source level is "protected", currently it's ${srcLevel}`
    const finalCopySource = `${sourceBucket}/${sourceKeyPrefix}${source.key}`;
    const finalCopyDestination = `${destinationKeyPrefix}${destination.key}`;
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`copying "${finalCopySource}" to "${finalCopyDestination}".`);
    await serviceCopy({
        source: finalCopySource,
        destination: finalCopyDestination,
        bucket: destBucket,
        s3Config,
        notModifiedSince: input.source.notModifiedSince,
        eTag: input.source.eTag,
        expectedSourceBucketOwner: input.source?.expectedBucketOwner,
        expectedBucketOwner: input.destination?.expectedBucketOwner
    });
    return {
        key: destination.key
    };
};
const serviceCopy = async ({ source, destination, bucket, s3Config, notModifiedSince, eTag, expectedSourceBucketOwner, expectedBucketOwner, tagConfig })=>{
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$copyObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copyObject"])({
        ...s3Config,
        userAgentValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageUserAgentValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].Copy)
    }, {
        Bucket: bucket,
        CopySource: source,
        Key: destination,
        MetadataDirective: 'COPY',
        TaggingDirective: tagConfig?.mode === 'remove' ? 'REPLACE' : 'COPY',
        CopySourceIfMatch: eTag,
        CopySourceIfUnmodifiedSince: notModifiedSince,
        ExpectedSourceBucketOwner: expectedSourceBucketOwner,
        ExpectedBucketOwner: expectedBucketOwner
    });
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/copy.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "copy",
    ()=>copy
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/Amplify.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$copy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/copy.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function copy(input) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$copy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copy"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Amplify"], input);
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_PART_SIZE",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PART_SIZE"],
    "StorageError",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"],
    "copy",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$copy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copy"],
    "downloadData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"],
    "getProperties",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$getProperties$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProperties"],
    "getUrl",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$getUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUrl"],
    "isCancelError",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCancelError"],
    "list",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["list"],
    "remove",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["remove"],
    "uploadData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$client$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/client/apis/uploadData.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/downloadData.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/remove.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/list.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$getProperties$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/getProperties.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$copy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/copy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$getUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/getUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/CanceledError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/StorageError.mjs [app-client] (ecmascript)");
}),
"[project]/node_modules/aws-amplify/dist/esm/storage/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_PART_SIZE",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PART_SIZE"],
    "StorageError",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"],
    "copy",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copy"],
    "downloadData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"],
    "getProperties",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProperties"],
    "getUrl",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUrl"],
    "isCancelError",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCancelError"],
    "list",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["list"],
    "remove",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["remove"],
    "uploadData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$aws$2d$amplify$2f$dist$2f$esm$2f$storage$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/aws-amplify/dist/esm/storage/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/index.mjs [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=node_modules_05kkgtf._.js.map