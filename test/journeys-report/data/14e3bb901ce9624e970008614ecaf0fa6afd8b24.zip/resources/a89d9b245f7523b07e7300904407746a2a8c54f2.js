(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Editor3/components/TableComponent.jsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_Editor3_components_TableComponent_jsx_15f34a1._.js",
  "static/chunks/node_modules_@lexical_react_LexicalNestedComposer_dev_mjs_0_fquk7._.js",
  "static/chunks/src_components_Editor3_components_TableComponent_jsx_1u983xi._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/Editor3/components/TableComponent.jsx [app-client] (ecmascript)");
    });
});
}),
]);