(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0o_06qp._.js","static/chunks/node_modules_@mui_0uk30h7._.js"],
    source: "dynamic"
});
