(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/QuestionEditor2.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "QuestionEditor2",
    ()=>QuestionEditor2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-virtual/dist/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/uploadData.mjs [app-client] (ecmascript)");
// Lexical imports
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposer.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalRichTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalRichTextPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalContentEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHistoryPlugin.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$history$2f$LexicalHistory$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/history/LexicalHistory.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalErrorBoundary.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
// MUI imports
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Menu/Menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Portal/Portal.js [app-client] (ecmascript) <export default as Portal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript) <export default as Snackbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$DeleteOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/DeleteOutline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Description.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandLess.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandMore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MoreVert.js [app-client] (ecmascript)");
// Context imports
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/fileContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tabContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/tabContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ShowDeletedToggle$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ShowDeletedToggle.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useRecycleBin.js [app-client] (ecmascript)");
// i18n
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
// Import QuestionCard from QuestionsReview2
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$QuestionsReview2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/QuestionsReview2.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
"use strict";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Commands for question operations
const UPDATE_QUESTION_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("UPDATE_QUESTION");
const DELETE_QUESTION_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("DELETE_QUESTION");
const POPULATE_QUESTIONS_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("POPULATE_QUESTIONS");
// Helper functions
function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}
const deduplicateUrls = (urls)=>{
    const set = new Set(urls);
    return Array.from(set);
};
const debounce = (func, wait)=>{
    let timeout;
    return function executedFunction(...args) {
        const later = ()=>{
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
};
// Convert blob to base64 for serialization
const blobToBase64 = (blob)=>{
    return new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.onloadend = ()=>resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};
// Convert base64 to blob for deserialization
const base64ToBlob = (base64, mimeType = "audio/ogg")=>{
    const byteString = atob(base64.split(",")[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for(let i = 0; i < byteString.length; i++){
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([
        ab
    ], {
        type: mimeType
    });
};
// Conversion function for importing question nodes from HTML
function convertQuestionElement(domNode) {
    const questionId = domNode.getAttribute("data-lexical-question-id");
    const prompt = domNode.getAttribute("data-lexical-question-prompt") || "";
    const hint = domNode.getAttribute("data-lexical-question-hint") || "";
    const answer = domNode.getAttribute("data-lexical-question-answer") || "";
    const version = domNode.getAttribute("data-lexical-question-version") || "1";
    // Parse audio keys
    let audio = [];
    const audioKeysAttr = domNode.getAttribute("data-lexical-audio-keys");
    if (audioKeysAttr) {
        try {
            audio = JSON.parse(audioKeysAttr);
        } catch (e) {
            console.error("Failed to parse audio keys:", e);
        }
    }
    // Parse audio URLs from script tag if present
    const audioScript = domNode.querySelector("script.lexical-question-audio-data");
    let audioData = null;
    if (audioScript) {
        try {
            audioData = JSON.parse(audioScript.textContent);
        } catch (e) {
            console.error("Failed to parse audio data:", e);
        }
    }
    // Create the node with imported data
    const node = $createQuestionDecoratorNode(questionId, prompt, hint, answer, audio, parseInt(version, 10), true, // isExpanded
    false, // isSelected
    "", // searchTerm
    null, // sharedHistory - will be set by plugin
    null, // onUpdate - will be set by plugin
    null, // onDelete - will be set by plugin
    null, // onToggleExpand - will be set by plugin
    null, // onToggleSelect - will be set by plugin
    {}, // audioFiles - would be populated from audioData if needed
    "", // identityId
    0 // index
    );
    return {
        node
    };
}
// =============================================================================
// QuestionDecoratorNode - Represents a single question in the editor
// =============================================================================
class QuestionDecoratorNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __questionId;
    __prompt;
    __hint;
    __answer;
    __audio;
    __isExpanded;
    __isSelected;
    __searchTerm;
    __sharedHistory;
    __onUpdate;
    __onDelete;
    __onToggleExpand;
    __onToggleSelect;
    __audioFiles;
    __identityId;
    __index;
    __documentID;
    __fileID;
    __filename;
    __page;
    static getType() {
        return "question-decorator";
    }
    static clone(node) {
        return new QuestionDecoratorNode(node.__questionId, node.__prompt, node.__hint, node.__answer, node.__audio, node.__isExpanded, node.__isSelected, node.__searchTerm, node.__sharedHistory, node.__onUpdate, node.__onDelete, node.__onToggleExpand, node.__onToggleSelect, node.__audioFiles, node.__identityId, node.__index, node.__documentID, node.__fileID, node.__filename, node.__page, node.__key);
    }
    constructor(questionId, prompt, hint, answer, audio, isExpanded = true, isSelected = false, searchTerm = "", sharedHistory = null, onUpdate = null, onDelete = null, onToggleExpand = null, onToggleSelect = null, audioFiles = {}, identityId = "", index = 0, documentID = null, fileID = null, filename = null, page = null, key){
        super(key);
        this.__questionId = questionId;
        this.__prompt = prompt;
        this.__hint = hint;
        this.__answer = answer;
        this.__audio = audio || [];
        this.__isExpanded = isExpanded;
        this.__isSelected = isSelected;
        this.__searchTerm = searchTerm;
        this.__sharedHistory = sharedHistory;
        this.__onUpdate = onUpdate;
        this.__onDelete = onDelete;
        this.__onToggleExpand = onToggleExpand;
        this.__onToggleSelect = onToggleSelect;
        this.__audioFiles = audioFiles;
        this.__identityId = identityId;
        this.__index = index;
        this.__documentID = documentID;
        this.__fileID = fileID;
        this.__filename = filename;
        this.__page = page;
    }
    static importJSON(serializedNode) {
        const { questionId, prompt, hint, answer, audio, version, isExpanded, isSelected, index } = serializedNode;
        return $createQuestionDecoratorNode(questionId, prompt, hint, answer, audio, version, isExpanded, isSelected, "", null, null, null, null, null, {}, "", index);
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            type: "question-decorator",
            questionId: this.__questionId,
            prompt: this.__prompt,
            hint: this.__hint,
            answer: this.__answer,
            audio: this.__audio,
            isExpanded: this.__isExpanded,
            isSelected: this.__isSelected,
            index: this.__index
        };
    }
    updateQuestion(updates) {
        const writable = this.getWritable();
        if (updates.prompt !== undefined) writable.__prompt = updates.prompt;
        if (updates.hint !== undefined) writable.__hint = updates.hint;
        if (updates.answer !== undefined) writable.__answer = updates.answer;
        if (updates.audio !== undefined) writable.__audio = updates.audio;
    }
    setExpanded(isExpanded) {
        const writable = this.getWritable();
        writable.__isExpanded = isExpanded;
    }
    setSelected(isSelected) {
        const writable = this.getWritable();
        writable.__isSelected = isSelected;
    }
    setSearchTerm(searchTerm) {
        const writable = this.getWritable();
        writable.__searchTerm = searchTerm;
    }
    createDOM(config) {
        const div = document.createElement("div");
        div.setAttribute("data-lexical-question-id", this.__questionId);
        div.setAttribute("data-lexical-question-prompt", this.__prompt || "");
        div.setAttribute("data-lexical-question-hint", this.__hint || "");
        div.setAttribute("data-lexical-question-answer", this.__answer || "");
        div.setAttribute("data-lexical-question-version", this.__version || "1");
        // Audio URLs (S3 keys)
        if (this.__audio && this.__audio.length > 0) {
            div.setAttribute("data-lexical-audio-keys", JSON.stringify(this.__audio));
        }
        // Store fully formed S3 URLs if available
        if (this.__audioFiles && this.__audio && this.__audio.length > 0) {
            const audioUrls = this.__audio.map((key)=>{
                const file = this.__audioFiles[key];
                return file ? {
                    key,
                    url: file.url
                } : null;
            }).filter(Boolean);
            if (audioUrls.length > 0) {
                div.setAttribute("data-lexical-audio-urls", JSON.stringify(audioUrls));
            }
        }
        return div;
    }
    // Async method to export question with audio blobs as base64
    async exportDOMWithAudio() {
        const element = document.createElement("div");
        element.setAttribute("data-lexical-question-id", this.__questionId);
        element.setAttribute("data-lexical-question-prompt", this.__prompt || "");
        element.setAttribute("data-lexical-question-hint", this.__hint || "");
        element.setAttribute("data-lexical-question-answer", this.__answer || "");
        // Audio URLs (S3 keys)
        if (this.__audio && this.__audio.length > 0) {
            element.setAttribute("data-lexical-audio-keys", JSON.stringify(this.__audio));
        }
        // Store fully formed S3 URLs if available
        if (this.__audioFiles && this.__audio && this.__audio.length > 0) {
            const audioUrls = this.__audio.map((key)=>{
                const file = this.__audioFiles[key];
                return file ? {
                    key,
                    url: file.url
                } : null;
            }).filter(Boolean);
            if (audioUrls.length > 0) {
                element.setAttribute("data-lexical-audio-urls", JSON.stringify(audioUrls));
            }
            // Convert blobs to base64 and store in script tag
            const audioBlobs = [];
            for (const key of this.__audio){
                const file = this.__audioFiles[key];
                if (file && file.blob) {
                    try {
                        const base64 = await blobToBase64(file.blob);
                        audioBlobs.push({
                            key,
                            base64,
                            mimeType: file.blob.type || "audio/ogg",
                            url: file.url
                        });
                    } catch (error) {
                        console.error("Failed to convert blob to base64:", error);
                    }
                }
            }
            if (audioBlobs.length > 0) {
                const script = document.createElement("script");
                script.type = "application/json";
                script.className = "lexical-question-audio-data";
                script.setAttribute("data-question-id", this.__questionId);
                script.textContent = JSON.stringify(audioBlobs);
                element.appendChild(script);
            }
        }
        return {
            element
        };
    }
    exportDOM() {
        const element = document.createElement("div");
        element.setAttribute("data-lexical-question-id", this.__questionId);
        element.setAttribute("data-lexical-question-prompt", this.__prompt || "");
        element.setAttribute("data-lexical-question-hint", this.__hint || "");
        element.setAttribute("data-lexical-question-answer", this.__answer || "");
        element.setAttribute("data-lexical-question-version", this.__version || "1");
        // Audio URLs (S3 keys)
        if (this.__audio && this.__audio.length > 0) {
            element.setAttribute("data-lexical-audio-keys", JSON.stringify(this.__audio));
        }
        // Store fully formed S3 URLs if available
        if (this.__audioFiles && this.__audio && this.__audio.length > 0) {
            const audioUrls = this.__audio.map((key)=>{
                const file = this.__audioFiles[key];
                return file ? {
                    key,
                    url: file.url
                } : null;
            }).filter(Boolean);
            if (audioUrls.length > 0) {
                element.setAttribute("data-lexical-audio-urls", JSON.stringify(audioUrls));
            }
        }
        // Note: Audio blobs are NOT included in synchronous exportDOM
        // Use exportDOMWithAudio() for complete serialization with base64 audio
        return {
            element
        };
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute("data-lexical-question-id")) {
                    return null;
                }
                return {
                    conversion: convertQuestionElement,
                    priority: 1
                };
            }
        };
    }
    updateDOM() {
        return false;
    }
    decorate() {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(QuestionRowComponent, {
            questionId: this.__questionId,
            prompt: this.__prompt,
            hint: this.__hint,
            answer: this.__answer,
            audio: this.__audio,
            isExpanded: this.__isExpanded,
            isSelected: this.__isSelected,
            searchTerm: this.__searchTerm,
            sharedHistory: this.__sharedHistory,
            onUpdate: this.__onUpdate,
            onDelete: this.__onDelete,
            onToggleExpand: this.__onToggleExpand,
            onToggleSelect: this.__onToggleSelect,
            audioFiles: this.__audioFiles,
            identityId: this.__identityId,
            index: this.__index,
            documentID: this.__documentID,
            fileID: this.__fileID,
            filename: this.__filename,
            page: this.__page,
            nodeKey: this.__key
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionEditor2.jsx",
            lineNumber: 389,
            columnNumber: 12
        }, this);
    }
    isInline() {
        return false;
    }
    isTopLevel() {
        return true;
    }
}
function $createQuestionDecoratorNode(questionId, prompt, hint, answer, audio, isExpanded, isSelected, searchTerm, sharedHistory, onUpdate, onDelete, onToggleExpand, onToggleSelect, audioFiles, identityId, index, documentID = null, fileID = null, filename = null, page = null) {
    return new QuestionDecoratorNode(questionId, prompt, hint, answer, audio, isExpanded, isSelected, searchTerm, sharedHistory, onUpdate, onDelete, onToggleExpand, onToggleSelect, audioFiles, identityId, index, documentID, fileID, filename, page);
}
function $isQuestionDecoratorNode(node) {
    return node instanceof QuestionDecoratorNode;
}
// =============================================================================
// QuestionRowComponent - The React component rendered by QuestionDecoratorNode
// =============================================================================
function QuestionRowComponent({ questionId, prompt, hint, answer, audio, isExpanded, isSelected, searchTerm, sharedHistory, onUpdate, onDelete, onToggleExpand, onToggleSelect, audioFiles, identityId, index, documentID, fileID, filename, page, nodeKey }) {
    _s();
    const [isDragging, setIsDragging] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [fileOperations, setFileOperations] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    const [audioFilesToUpload, setAudioFilesToUpload] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    const { unit } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const audioUrls = audio || [];
    const hasAudio = audioUrls.length > 0;
    // Handle audio file uploads
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "QuestionRowComponent.useEffect": ()=>{
            const asyncFunc = {
                "QuestionRowComponent.useEffect.asyncFunc": async ()=>{
                    if (audioFilesToUpload.length === 0) return;
                    const _fileOps = [
                        ...fileOperations
                    ];
                    for(let i = 0; i < audioFilesToUpload.length; i++){
                        const item = audioFilesToUpload[i];
                        try {
                            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$uploadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])({
                                path: `public/${item.name}`,
                                data: item.file,
                                options: {
                                    onProgress: {
                                        "QuestionRowComponent.useEffect.asyncFunc": ({ transferredBytes, totalBytes })=>{
                                            if (totalBytes) {
                                                const percentage = Math.round(transferredBytes / totalBytes * 100);
                                                _fileOps[i] = {
                                                    ..._fileOps[i],
                                                    progress: `${percentage}%`
                                                };
                                                setFileOperations([
                                                    ..._fileOps
                                                ]);
                                            }
                                        }
                                    }["QuestionRowComponent.useEffect.asyncFunc"]
                                }
                            }).result;
                            const newAudio = deduplicateUrls([
                                ...audioUrls,
                                item.name
                            ]);
                            // Update the question with new audio
                            if (onUpdate) {
                                await onUpdate(questionId, {
                                    audio: newAudio
                                });
                            }
                            _fileOps[i] = {
                                ..._fileOps[i],
                                progress: "Complete"
                            };
                            setFileOperations([
                                ..._fileOps
                            ]);
                        } catch (error) {
                            console.error("Error uploading audio:", error);
                            _fileOps[i] = {
                                ..._fileOps[i],
                                progress: "Error"
                            };
                            setFileOperations([
                                ..._fileOps
                            ]);
                        }
                    }
                    setAudioFilesToUpload([]);
                }
            }["QuestionRowComponent.useEffect.asyncFunc"];
            asyncFunc();
        }
    }["QuestionRowComponent.useEffect"], [
        audioFilesToUpload
    ]);
    const handleDragOver = (event)=>{
        event.preventDefault();
        event.stopPropagation();
        setIsDragging(true);
    };
    const handleDrop = async (event_0)=>{
        event_0.preventDefault();
        event_0.stopPropagation();
        const files = Array.from(event_0.dataTransfer.files);
        const _toupload = files.map((f, index_0)=>({
                file: f,
                name: `${unit.id}_${questionId}_${Date.now()}_${index_0}.ogg`
            }));
        const _fileOperations = files.map((f_0)=>({
                name: f_0.name,
                progress: "0%"
            }));
        setAudioFilesToUpload(_toupload);
        setFileOperations(_fileOperations);
        setIsDragging(false);
    };
    const handleDragLeave = (e)=>{
        if (e.currentTarget === e.target) {
            setIsDragging(false);
        }
    };
    const confirmDeleteQuestion = async ()=>{
        // This function is a placeholder - deletion is now handled via the passed onDelete callback
        // which will trigger the confirmation dialog in the parent component
        if (onDelete) {
            await onDelete(questionId, prompt);
        }
    };
    const matchesSearch = searchTerm && (prompt && prompt.toLowerCase().includes(searchTerm.toLowerCase()) || answer && answer.toLowerCase().includes(searchTerm.toLowerCase()) || hint && hint.toLowerCase().includes(searchTerm.toLowerCase()));
    const questionItemRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const tabContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tabContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabContext"])();
    const [isHighlighted, setIsHighlighted] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    // Register ref for scrolling
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "QuestionRowComponent.useEffect": ()=>{
            if (tabContext?.registerItemRef && questionId) {
                tabContext.registerItemRef("question", questionId, questionItemRef);
            }
            return ({
                "QuestionRowComponent.useEffect": ()=>{
                    if (tabContext?.unregisterItemRef && questionId) {
                        tabContext.unregisterItemRef("question", questionId);
                    }
                }
            })["QuestionRowComponent.useEffect"];
        }
    }["QuestionRowComponent.useEffect"], [
        questionId,
        tabContext
    ]);
    // Highlight when focused from search results
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "QuestionRowComponent.useEffect": ()=>{
            if (tabContext?.focusItem?.type === "question" && tabContext.focusItem.id === questionId) {
                setIsHighlighted(true);
                // Auto-expand when focused
                if (onToggleExpand && !isExpanded) {
                    onToggleExpand();
                }
                // Remove highlight after 3 seconds
                const timer = setTimeout({
                    "QuestionRowComponent.useEffect.timer": ()=>setIsHighlighted(false)
                }["QuestionRowComponent.useEffect.timer"], 3000);
                return ({
                    "QuestionRowComponent.useEffect": ()=>clearTimeout(timer)
                })["QuestionRowComponent.useEffect"];
            }
        }
    }["QuestionRowComponent.useEffect"], [
        tabContext?.focusItem,
        questionId,
        onToggleExpand,
        isExpanded
    ]);
    // Adapt question data to QuestionItem interface
    const questionItem = {
        prompt: prompt || "",
        answer: answer || "",
        hint: hint,
        hasAudio: hasAudio,
        documentID: documentID,
        fileID: fileID,
        filename: filename,
        page: page
    };
    const handleUpdateWrapper = async (itemIndex, field, newValue)=>{
        if (onUpdate) {
            await onUpdate(questionId, {
                [field]: newValue
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        ref: questionItemRef,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$QuestionsReview2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionCard"], {
            item: questionItem,
            index: index,
            isSelected: isSelected,
            isExpanded: isExpanded,
            existsInQuestionBank: true,
            alreadyImported: true,
            searchTerm: searchTerm,
            onToggleSelect: ()=>onToggleSelect(index),
            onToggleExpand: ()=>onToggleExpand(index),
            onUpdate: handleUpdateWrapper
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionEditor2.jsx",
            lineNumber: 577,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/QuestionEditor2.jsx",
        lineNumber: 576,
        columnNumber: 10
    }, this);
}
_s(QuestionRowComponent, "3W7EtYgQzNNjkcq8s6binJ7KrWM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$tabContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabContext"]
    ];
});
_c = QuestionRowComponent;
// =============================================================================
// QuestionsPlugin - Manages question nodes and synchronization
// =============================================================================
function QuestionsPlugin({ questionBank, searchTerm, expandedItems, selectedItems, onToggleExpand, onToggleSelect, sharedHistory, audioFiles, identityId, parentRef, setConfirmDialog, fullQuestionBank }) {
    _s1();
    const { bumpQuestionVersion } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { softDelete } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecycleBin"])();
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    // Setup virtualizer for performance
    const questionEntries = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "QuestionsPlugin.useMemo[questionEntries]": ()=>{
            return questionBank ? Object.entries(questionBank) : [];
        }
    }["QuestionsPlugin.useMemo[questionEntries]"], [
        questionBank
    ]);
    const virtualizer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"])({
        count: questionEntries.length,
        getScrollElement: {
            "QuestionsPlugin.useVirtualizer[virtualizer]": ()=>parentRef?.current
        }["QuestionsPlugin.useVirtualizer[virtualizer]"],
        estimateSize: {
            "QuestionsPlugin.useVirtualizer[virtualizer]": ()=>100
        }["QuestionsPlugin.useVirtualizer[virtualizer]"],
        overscan: 5
    });
    // Update questions when questionBank changes
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "QuestionsPlugin.useEffect": ()=>{
            if (!questionBank) return;
            editor.update({
                "QuestionsPlugin.useEffect": ()=>{
                    const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
                    root.clear();
                    const entries = Object.entries(questionBank);
                    // Render all questions - virtualization happens at render level
                    entries.forEach({
                        "QuestionsPlugin.useEffect": ([id, question], index)=>{
                            const node = $createQuestionDecoratorNode(id, question.prompt, question.hint, question.answer, question.audio, expandedItems.has(id), selectedItems.has(id), searchTerm, sharedHistory, handleUpdateQuestion, handleDeleteQuestion, {
                                "QuestionsPlugin.useEffect.node": ()=>onToggleExpand(id)
                            }["QuestionsPlugin.useEffect.node"], {
                                "QuestionsPlugin.useEffect.node": ()=>onToggleSelect(id)
                            }["QuestionsPlugin.useEffect.node"], audioFiles, identityId, index, question.documentID, question.fileID, question.filename, question.page);
                            root.append(node);
                        }
                    }["QuestionsPlugin.useEffect"]);
                }
            }["QuestionsPlugin.useEffect"]);
        }
    }["QuestionsPlugin.useEffect"], [
        questionBank,
        searchTerm,
        expandedItems,
        selectedItems,
        audioFiles,
        editor
    ]);
    const handleUpdateQuestion = async (questionId, updates)=>{
        try {
            const question_0 = fullQuestionBank?.[questionId];
            const currentVersion = question_0?._version;
            const versionCtrl = currentVersion != null ? bumpQuestionVersion(questionId, currentVersion) : null;
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const { data, errors } = await client.models.Question.update({
                id: questionId,
                ...updates,
                ...currentVersion != null && {
                    _version: currentVersion
                }
            });
            if (errors) {
                console.error("Error updating question:", errors);
                versionCtrl?.rollback();
            } else {
                versionCtrl?.confirm(data._version);
            }
        } catch (error) {
            console.error("Error updating question:", error);
        }
    };
    const handleDeleteQuestion = async (questionId_0, prompt = "")=>{
        if (!setConfirmDialog) {
            console.error("setConfirmDialog not available");
            return;
        }
        // Show confirmation dialog before soft-deleting
        setConfirmDialog({
            open: true,
            message: `Move to Recycle Bin: "${prompt}"?`,
            severity: "warning",
            onConfirm: async ()=>{
                try {
                    await softDelete("Question", questionId_0);
                    console.log("Question soft deleted:", questionId_0);
                    setConfirmDialog({
                        open: false,
                        message: "",
                        onConfirm: null,
                        severity: "warning"
                    });
                } catch (error_0) {
                    console.error("Error soft deleting question:", error_0);
                    setConfirmDialog({
                        open: false,
                        message: "",
                        onConfirm: null,
                        severity: "warning"
                    });
                }
            }
        });
    };
    return null;
}
_s1(QuestionsPlugin, "ltakG6wagINUhth/hrsJxzc3IcM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecycleBin"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"]
    ];
});
_c1 = QuestionsPlugin;
function QuestionEditor2() {
    _s2();
    var _s = __turbopack_context__.k.signature();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const [open, setOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [isHelpOpen, setHelpOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [expandedItems, setExpandedItems] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(new Set());
    const [filteredQuestionBank, setFilteredQuestionBank] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [selectedItems, setSelectedItems] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(new Set());
    const [contextMenu, setContextMenu] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const [confirmDialog, setConfirmDialog] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        open: false,
        message: "",
        onConfirm: null,
        severity: "warning"
    });
    const sharedHistoryState = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$history$2f$LexicalHistory$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEmptyHistoryState"])());
    const [search, setSearch] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [newPrompt, setNewPrompt] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [newAnswer, setNewAnswer] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [newHint, setNewHint] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState("");
    const [newQuestionFormOpen, setNewQuestionFormOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [fileOperations, setFileOperations] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([]);
    const { questionBank, showDeleted, setShowDeleted } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { audioFiles, refreshAudioFiles, session } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { identityId } = session || {};
    const { softDelete } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecycleBin"])();
    const parentRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    // Filter questions based on search
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "QuestionEditor2.useEffect": ()=>{
            if (!questionBank) {
                setFilteredQuestionBank(null);
                return;
            }
            if (!search) {
                setFilteredQuestionBank(questionBank);
                return;
            }
            const filtered = Object.fromEntries(Object.entries(questionBank).filter({
                "QuestionEditor2.useEffect.filtered": ([id, q])=>{
                    const searchLower = search.toLowerCase();
                    return q.prompt && q.prompt.toLowerCase().includes(searchLower) || q.hint && q.hint.toLowerCase().includes(searchLower) || q.answer && q.answer.toLowerCase().includes(searchLower);
                }
            }["QuestionEditor2.useEffect.filtered"]));
            setFilteredQuestionBank(filtered);
        }
    }["QuestionEditor2.useEffect"], [
        search,
        questionBank
    ]);
    const handleToggleExpand = (id_0)=>{
        setExpandedItems((prev)=>{
            const next = new Set(prev);
            if (next.has(id_0)) {
                next.delete(id_0);
            } else {
                next.add(id_0);
            }
            return next;
        });
    };
    const handleToggleSelect = (id_1)=>{
        setSelectedItems((prev_0)=>{
            const next_0 = new Set(prev_0);
            if (next_0.has(id_1)) {
                next_0.delete(id_1);
            } else {
                next_0.add(id_1);
            }
            return next_0;
        });
    };
    const handleExpandAll = ()=>{
        if (filteredQuestionBank) {
            setExpandedItems(new Set(Object.keys(filteredQuestionBank)));
        }
    };
    const handleCollapseAll = ()=>{
        setExpandedItems(new Set());
    };
    const handleSelectAll = ()=>{
        if (filteredQuestionBank) {
            setSelectedItems(new Set(Object.keys(filteredQuestionBank)));
        }
    };
    const handleDeselectAll = ()=>{
        setSelectedItems(new Set());
    };
    const handleBulkDelete = async ()=>{
        setConfirmDialog({
            open: true,
            message: `Move ${selectedItems.size} question(s) to Recycle Bin?`,
            severity: "warning",
            onConfirm: async ()=>{
                for (const id_2 of selectedItems){
                    try {
                        await softDelete("Question", id_2);
                    } catch (error) {
                        console.error("Error soft deleting question:", id_2, error);
                    }
                }
                setSelectedItems(new Set());
                setContextMenu(null);
                setConfirmDialog({
                    open: false,
                    message: "",
                    onConfirm: null,
                    severity: "warning"
                });
            }
        });
    };
    const handleContextMenuClose = ()=>{
        setContextMenu(null);
    };
    const toggleNewQuestionFormOpen = ()=>{
        setNewQuestionFormOpen(!newQuestionFormOpen);
    };
    const handleCreateQuestion = async (event)=>{
        _s();
        event.preventDefault();
        const { unit } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {};
        if (!unit?.id) {
            console.error("No unit context available");
            return;
        }
        try {
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const { data, errors } = await client.models.Question.create({
                prompt: newPrompt,
                hint: newHint,
                answer: newAnswer,
                unitID: unit.id,
                audio: []
            });
            if (errors) {
                console.error("Error creating question:", errors);
            } else {
                console.log("Question created:", data);
            }
            setNewPrompt("");
            setNewHint("");
            setNewAnswer("");
            toggleNewQuestionFormOpen();
        } catch (error_0) {
            console.error("Error creating question:", error_0);
        }
    };
    _s(handleCreateQuestion, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
    const debouncedSearch = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback(debounce({
        "QuestionEditor2.useCallback[debouncedSearch]": (search_0)=>{
            setSearch(search_0);
        }
    }["QuestionEditor2.useCallback[debouncedSearch]"], 500), []);
    const handleSearch = (e)=>{
        debouncedSearch(e.target.value);
    };
    const initialConfig = {
        namespace: "QuestionEditor2",
        theme: {},
        nodes: [
            QuestionDecoratorNode
        ],
        onError: (error_1)=>console.error("Lexical error:", error_1)
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                open: contextMenu !== null,
                onClose: handleContextMenuClose,
                anchorReference: "anchorPosition",
                anchorPosition: contextMenu !== null ? {
                    top: contextMenu.mouseY,
                    left: contextMenu.mouseX
                } : undefined,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        disabled: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "caption",
                            color: "text.secondary",
                            children: [
                                selectedItems.size,
                                " selected"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/QuestionEditor2.jsx",
                            lineNumber: 874,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                        lineNumber: 873,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {}, void 0, false, {
                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                        lineNumber: 878,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                        onClick: ()=>{
                            handleContextMenuClose();
                            handleBulkDelete();
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$DeleteOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                fontSize: "small",
                                sx: {
                                    mr: 1
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/QuestionEditor2.jsx",
                                lineNumber: 883,
                                columnNumber: 11
                            }, this),
                            "Move to Recycle Bin"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                        lineNumber: 879,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/QuestionEditor2.jsx",
                lineNumber: 869,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: 1,
                    padding: 1,
                    position: "sticky",
                    top: 0,
                    bgcolor: "background.paper",
                    borderBottom: "1px solid",
                    borderColor: "divider",
                    zIndex: 1
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            display: "flex",
                            gap: 0,
                            alignItems: "center"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                title: "Select All",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                                    size: "small",
                                    checked: filteredQuestionBank && Object.keys(filteredQuestionBank).length > 0 && selectedItems.size === Object.keys(filteredQuestionBank).length,
                                    indeterminate: selectedItems.size > 0 && selectedItems.size < Object.keys(filteredQuestionBank || {}).length,
                                    onChange: (e_0)=>{
                                        if (e_0.target.checked) {
                                            handleSelectAll();
                                        } else {
                                            handleDeselectAll();
                                        }
                                    },
                                    disabled: !filteredQuestionBank || Object.keys(filteredQuestionBank).length === 0,
                                    sx: {
                                        p: 0.25
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/QuestionEditor2.jsx",
                                    lineNumber: 911,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/QuestionEditor2.jsx",
                                lineNumber: 910,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                title: expandedItems.size === 0 ? "Expand All" : "Collapse All",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                    size: "small",
                                    onClick: expandedItems.size === 0 ? handleExpandAll : handleCollapseAll,
                                    disabled: !filteredQuestionBank || Object.keys(filteredQuestionBank).length === 0,
                                    children: expandedItems.size === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                                        lineNumber: 924,
                                        columnNumber: 43
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                                        lineNumber: 924,
                                        columnNumber: 77
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/QuestionEditor2.jsx",
                                    lineNumber: 923,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/QuestionEditor2.jsx",
                                lineNumber: 922,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                        lineNumber: 905,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                        defaultValue: search,
                        onInput: handleSearch,
                        type: "text",
                        size: "small",
                        fullWidth: true,
                        placeholder: "Search questions...",
                        label: "Search"
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                        lineNumber: 929,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: "New Question",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                            onClick: toggleNewQuestionFormOpen,
                            color: "primary",
                            size: "small",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/QuestionEditor2.jsx",
                                lineNumber: 933,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/QuestionEditor2.jsx",
                            lineNumber: 932,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                        lineNumber: 931,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: "Actions",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                            onClick: (e_1)=>setContextMenu(contextMenu ? null : {
                                    mouseX: e_1.clientX,
                                    mouseY: e_1.clientY
                                }),
                            size: "small",
                            disabled: selectedItems.size === 0,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MoreVert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/QuestionEditor2.jsx",
                                lineNumber: 942,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/QuestionEditor2.jsx",
                            lineNumber: 938,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                        lineNumber: 937,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ShowDeletedToggle$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        showDeleted: showDeleted,
                        setShowDeleted: setShowDeleted
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                        lineNumber: 946,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/QuestionEditor2.jsx",
                lineNumber: 891,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                ref: parentRef,
                sx: {
                    overflowY: "auto",
                    overflowX: "hidden"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalComposer"], {
                    initialConfig: initialConfig,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalRichTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RichTextPlugin"], {
                            contentEditable: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentEditable"], {
                                style: {
                                    margin: 0,
                                    padding: 0,
                                    outline: "none",
                                    minHeight: "100%"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/QuestionEditor2.jsx",
                                lineNumber: 955,
                                columnNumber: 44
                            }, this),
                            placeholder: null,
                            ErrorBoundary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalErrorBoundary"]
                        }, void 0, false, {
                            fileName: "[project]/src/components/QuestionEditor2.jsx",
                            lineNumber: 955,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HistoryPlugin"], {}, void 0, false, {
                            fileName: "[project]/src/components/QuestionEditor2.jsx",
                            lineNumber: 961,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(QuestionsPlugin, {
                            questionBank: filteredQuestionBank,
                            searchTerm: search,
                            expandedItems: expandedItems,
                            selectedItems: selectedItems,
                            onToggleExpand: handleToggleExpand,
                            onToggleSelect: handleToggleSelect,
                            sharedHistory: sharedHistoryState.current,
                            audioFiles: audioFiles,
                            identityId: identityId,
                            parentRef: parentRef,
                            setConfirmDialog: setConfirmDialog,
                            fullQuestionBank: questionBank
                        }, void 0, false, {
                            fileName: "[project]/src/components/QuestionEditor2.jsx",
                            lineNumber: 962,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/QuestionEditor2.jsx",
                    lineNumber: 954,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/QuestionEditor2.jsx",
                lineNumber: 950,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                open: newQuestionFormOpen,
                onClose: toggleNewQuestionFormOpen,
                maxWidth: "sm",
                fullWidth: true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                        children: t("questionEditor.dialogTitle")
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                        lineNumber: 968,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            onSubmit: handleCreateQuestion,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                    value: newPrompt,
                                    required: true,
                                    onChange: (e_2)=>setNewPrompt(e_2.target.value),
                                    fullWidth: true,
                                    margin: "normal",
                                    label: "Prompt",
                                    variant: "outlined"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/QuestionEditor2.jsx",
                                    lineNumber: 971,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                    value: newHint,
                                    required: true,
                                    onChange: (e_3)=>setNewHint(e_3.target.value),
                                    fullWidth: true,
                                    margin: "normal",
                                    label: "Hint",
                                    variant: "outlined"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/QuestionEditor2.jsx",
                                    lineNumber: 972,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                    value: newAnswer,
                                    required: true,
                                    onChange: (e_4)=>setNewAnswer(e_4.target.value),
                                    fullWidth: true,
                                    margin: "normal",
                                    label: "Answer",
                                    variant: "outlined"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/QuestionEditor2.jsx",
                                    lineNumber: 973,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "contained",
                                    type: "submit",
                                    sx: {
                                        mt: 2
                                    },
                                    children: t("questionEditor.save")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/QuestionEditor2.jsx",
                                    lineNumber: 974,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/QuestionEditor2.jsx",
                            lineNumber: 970,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                        lineNumber: 969,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/QuestionEditor2.jsx",
                lineNumber: 967,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__["Portal"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
                    open: confirmDialog.open,
                    anchorOrigin: {
                        vertical: "top",
                        horizontal: "center"
                    },
                    onClose: (event_0, reason)=>{
                        if (reason === "clickaway") {
                            return;
                        }
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                        severity: confirmDialog.severity,
                        sx: {
                            width: "100%",
                            minWidth: "300px",
                            boxShadow: 3
                        },
                        action: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                gap: 1,
                                ml: 2
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    color: "inherit",
                                    size: "small",
                                    onClick: (e_5)=>{
                                        e_5.stopPropagation();
                                        if (confirmDialog.onConfirm) {
                                            confirmDialog.onConfirm();
                                        }
                                    },
                                    variant: "outlined",
                                    children: t("chatSidebar.confirm")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/QuestionEditor2.jsx",
                                    lineNumber: 1002,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    color: "inherit",
                                    size: "small",
                                    onClick: (e_6)=>{
                                        e_6.stopPropagation();
                                        setConfirmDialog({
                                            open: false,
                                            message: "",
                                            onConfirm: null,
                                            severity: "warning"
                                        });
                                    },
                                    variant: "contained",
                                    children: t("chatSidebar.cancel")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/QuestionEditor2.jsx",
                                    lineNumber: 1010,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/QuestionEditor2.jsx",
                            lineNumber: 997,
                            columnNumber: 20
                        }, this),
                        children: confirmDialog.message
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionEditor2.jsx",
                        lineNumber: 993,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/QuestionEditor2.jsx",
                    lineNumber: 985,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/QuestionEditor2.jsx",
                lineNumber: 984,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s2(QuestionEditor2, "ebA5QbO5JygL+Vp4fFAPe2leWLg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRecycleBin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecycleBin"]
    ];
});
_c2 = QuestionEditor2;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "QuestionRowComponent");
__turbopack_context__.k.register(_c1, "QuestionsPlugin");
__turbopack_context__.k.register(_c2, "QuestionEditor2");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PermissionErrorOverlay.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PermissionErrorOverlay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Lock.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
function PermissionErrorOverlay(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(59);
    if ($[0] !== "b4cc4f43b4f62777d7070d028ef86cbaf6d05ad8082cc329a49a397a83d9cf92") {
        for(let $i = 0; $i < 59; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b4cc4f43b4f62777d7070d028ef86cbaf6d05ad8082cc329a49a397a83d9cf92";
    }
    const { open: t1, resourceType: t2, message, onClose } = t0;
    const open = t1 === undefined ? false : t1;
    const resourceType = t2 === undefined ? "unit" : t2;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    let t3;
    if ($[1] !== onClose || $[2] !== router) {
        t3 = ({
            "PermissionErrorOverlay[handleGoBack]": ()=>{
                if (onClose) {
                    onClose();
                }
                if (window.history.length > 1) {
                    router.back();
                } else {
                    router.push("/");
                }
            }
        })["PermissionErrorOverlay[handleGoBack]"];
        $[1] = onClose;
        $[2] = router;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const handleGoBack = t3;
    let t4;
    if ($[4] !== onClose || $[5] !== router) {
        t4 = ({
            "PermissionErrorOverlay[handleGoHome]": ()=>{
                if (onClose) {
                    onClose();
                }
                router.push("/");
            }
        })["PermissionErrorOverlay[handleGoHome]"];
        $[4] = onClose;
        $[5] = router;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const handleGoHome = t4;
    let t5;
    if ($[7] !== resourceType || $[8] !== t) {
        t5 = t("permissionError.defaultMessage", {
            resourceType: t(`permissionError.resourceTypes.${resourceType}`, resourceType),
            defaultValue: `You don't have permission to access this ${resourceType}.`
        });
        $[7] = resourceType;
        $[8] = t;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    const defaultMessage = t5;
    let t6;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            sx: {
                borderRadius: 2,
                boxShadow: "0 8px 32px rgba(0,0,0,0.12)"
            }
        };
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    let t7;
    if ($[11] !== handleGoBack) {
        t7 = ({
            "PermissionErrorOverlay[<Dialog>.onClose]": (event, reason)=>{
                if (reason === "backdropClick") {
                    return;
                }
                handleGoBack();
            }
        })["PermissionErrorOverlay[<Dialog>.onClose]"];
        $[11] = handleGoBack;
        $[12] = t7;
    } else {
        t7 = $[12];
    }
    let t8;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            display: "flex",
            alignItems: "center",
            gap: 2
        };
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: 40,
                color: "error.main"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
            lineNumber: 127,
            columnNumber: 10
        }, this);
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            fontWeight: 600
        };
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    let t11;
    if ($[16] !== t) {
        t11 = t("permissionError.title", "Access Denied");
        $[16] = t;
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    if ($[18] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t8,
                children: [
                    t9,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "h5",
                        component: "span",
                        sx: t10,
                        children: t11
                    }, void 0, false, {
                        fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
                        lineNumber: 154,
                        columnNumber: 41
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
                lineNumber: 154,
                columnNumber: 24
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
            lineNumber: 154,
            columnNumber: 11
        }, this);
        $[18] = t11;
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    let t13;
    if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            mb: 2
        };
        $[20] = t13;
    } else {
        t13 = $[20];
    }
    const t14 = message || defaultMessage;
    let t15;
    if ($[21] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
            severity: "error",
            sx: t13,
            children: t14
        }, void 0, false, {
            fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
            lineNumber: 172,
            columnNumber: 11
        }, this);
        $[21] = t14;
        $[22] = t15;
    } else {
        t15 = $[22];
    }
    let t16;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            mt: 2
        };
        $[23] = t16;
    } else {
        t16 = $[23];
    }
    let t17;
    if ($[24] !== t) {
        t17 = t("permissionError.explanation", "This content is restricted. You need to be the owner or have instructor permissions to access it.");
        $[24] = t;
        $[25] = t17;
    } else {
        t17 = $[25];
    }
    let t18;
    if ($[26] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body1",
            color: "text.secondary",
            sx: t16,
            children: t17
        }, void 0, false, {
            fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
            lineNumber: 197,
            columnNumber: 11
        }, this);
        $[26] = t17;
        $[27] = t18;
    } else {
        t18 = $[27];
    }
    let t19;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = {
            mt: 2
        };
        $[28] = t19;
    } else {
        t19 = $[28];
    }
    let t20;
    if ($[29] !== t) {
        t20 = t("permissionError.contactInfo", "If you believe this is an error, please contact your instructor or administrator.");
        $[29] = t;
        $[30] = t20;
    } else {
        t20 = $[30];
    }
    let t21;
    if ($[31] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            sx: t19,
            children: t20
        }, void 0, false, {
            fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
            lineNumber: 222,
            columnNumber: 11
        }, this);
        $[31] = t20;
        $[32] = t21;
    } else {
        t21 = $[32];
    }
    let t22;
    if ($[33] !== t15 || $[34] !== t18 || $[35] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
            children: [
                t15,
                t18,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
            lineNumber: 230,
            columnNumber: 11
        }, this);
        $[33] = t15;
        $[34] = t18;
        $[35] = t21;
        $[36] = t22;
    } else {
        t22 = $[36];
    }
    let t23;
    if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = {
            p: 3,
            pt: 0
        };
        $[37] = t23;
    } else {
        t23 = $[37];
    }
    let t24;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = {
            textTransform: "none",
            fontWeight: 600,
            px: 3
        };
        $[38] = t24;
    } else {
        t24 = $[38];
    }
    let t25;
    if ($[39] !== t) {
        t25 = t("permissionError.goBack", "Go Back");
        $[39] = t;
        $[40] = t25;
    } else {
        t25 = $[40];
    }
    let t26;
    if ($[41] !== handleGoBack || $[42] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            onClick: handleGoBack,
            variant: "outlined",
            sx: t24,
            children: t25
        }, void 0, false, {
            fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
            lineNumber: 269,
            columnNumber: 11
        }, this);
        $[41] = handleGoBack;
        $[42] = t25;
        $[43] = t26;
    } else {
        t26 = $[43];
    }
    let t27;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = {
            textTransform: "none",
            fontWeight: 600,
            px: 3
        };
        $[44] = t27;
    } else {
        t27 = $[44];
    }
    let t28;
    if ($[45] !== t) {
        t28 = t("permissionError.goHome", "Go to Home");
        $[45] = t;
        $[46] = t28;
    } else {
        t28 = $[46];
    }
    let t29;
    if ($[47] !== handleGoHome || $[48] !== t28) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            onClick: handleGoHome,
            variant: "contained",
            sx: t27,
            children: t28
        }, void 0, false, {
            fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
            lineNumber: 297,
            columnNumber: 11
        }, this);
        $[47] = handleGoHome;
        $[48] = t28;
        $[49] = t29;
    } else {
        t29 = $[49];
    }
    let t30;
    if ($[50] !== t26 || $[51] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
            sx: t23,
            children: [
                t26,
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
            lineNumber: 306,
            columnNumber: 11
        }, this);
        $[50] = t26;
        $[51] = t29;
        $[52] = t30;
    } else {
        t30 = $[52];
    }
    let t31;
    if ($[53] !== open || $[54] !== t12 || $[55] !== t22 || $[56] !== t30 || $[57] !== t7) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
            open: open,
            maxWidth: "sm",
            fullWidth: true,
            PaperProps: t6,
            disableEscapeKeyDown: true,
            onClose: t7,
            children: [
                t12,
                t22,
                t30
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PermissionErrorOverlay.jsx",
            lineNumber: 315,
            columnNumber: 11
        }, this);
        $[53] = open;
        $[54] = t12;
        $[55] = t22;
        $[56] = t30;
        $[57] = t7;
        $[58] = t31;
    } else {
        t31 = $[58];
    }
    return t31;
}
_s(PermissionErrorOverlay, "8/syrZO7zDXsuFe/5R0n75uQkmU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = PermissionErrorOverlay;
var _c;
__turbopack_context__.k.register(_c, "PermissionErrorOverlay");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_0vl8try._.js.map