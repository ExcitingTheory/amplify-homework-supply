(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@lexical/react/LexicalClearEditorPlugin.dev.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ClearEditorPlugin",
    ()=>ClearEditorPlugin
]);
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$extension$2f$LexicalExtension$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/extension/LexicalExtension.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ const CAN_USE_DOM = typeof window !== 'undefined' && typeof window.document !== 'undefined' && typeof window.document.createElement !== 'undefined';
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ // This workaround is no longer necessary in React 19,
// but we currently support React >=17.x
// https://github.com/facebook/react/pull/26395
const useLayoutEffectImpl = CAN_USE_DOM ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"];
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ function ClearEditorPlugin({ onClear }) {
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    useLayoutEffectImpl({
        "ClearEditorPlugin.useLayoutEffectImpl": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$extension$2f$LexicalExtension$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["registerClearEditor"])(editor, onClear)
    }["ClearEditorPlugin.useLayoutEffectImpl"], [
        editor,
        onClear
    ]);
    return null;
}
;
}),
"[project]/node_modules/dompurify/dist/purify.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/*! @license DOMPurify 3.1.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.1.6/LICENSE */ (function(global, factory) {
    ("TURBOPACK compile-time truthy", 1) ? module.exports = factory() : "TURBOPACK unreachable";
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, function() {
    'use strict';
    const { entries, setPrototypeOf, isFrozen, getPrototypeOf, getOwnPropertyDescriptor } = Object;
    let { freeze, seal, create } = Object; // eslint-disable-line import/no-mutable-exports
    let { apply, construct } = typeof Reflect !== 'undefined' && Reflect;
    if (!freeze) {
        freeze = function freeze(x) {
            return x;
        };
    }
    if (!seal) {
        seal = function seal(x) {
            return x;
        };
    }
    if (!apply) {
        apply = function apply(fun, thisValue, args) {
            return fun.apply(thisValue, args);
        };
    }
    if (!construct) {
        construct = function construct(Func, args) {
            return new Func(...args);
        };
    }
    const arrayForEach = unapply(Array.prototype.forEach);
    const arrayPop = unapply(Array.prototype.pop);
    const arrayPush = unapply(Array.prototype.push);
    const stringToLowerCase = unapply(String.prototype.toLowerCase);
    const stringToString = unapply(String.prototype.toString);
    const stringMatch = unapply(String.prototype.match);
    const stringReplace = unapply(String.prototype.replace);
    const stringIndexOf = unapply(String.prototype.indexOf);
    const stringTrim = unapply(String.prototype.trim);
    const objectHasOwnProperty = unapply(Object.prototype.hasOwnProperty);
    const regExpTest = unapply(RegExp.prototype.test);
    const typeErrorCreate = unconstruct(TypeError);
    /**
   * Creates a new function that calls the given function with a specified thisArg and arguments.
   *
   * @param {Function} func - The function to be wrapped and called.
   * @returns {Function} A new function that calls the given function with a specified thisArg and arguments.
   */ function unapply(func) {
        return function(thisArg) {
            for(var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
                args[_key - 1] = arguments[_key];
            }
            return apply(func, thisArg, args);
        };
    }
    /**
   * Creates a new function that constructs an instance of the given constructor function with the provided arguments.
   *
   * @param {Function} func - The constructor function to be wrapped and called.
   * @returns {Function} A new function that constructs an instance of the given constructor function with the provided arguments.
   */ function unconstruct(func) {
        return function() {
            for(var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++){
                args[_key2] = arguments[_key2];
            }
            return construct(func, args);
        };
    }
    /**
   * Add properties to a lookup table
   *
   * @param {Object} set - The set to which elements will be added.
   * @param {Array} array - The array containing elements to be added to the set.
   * @param {Function} transformCaseFunc - An optional function to transform the case of each element before adding to the set.
   * @returns {Object} The modified set with added elements.
   */ function addToSet(set, array) {
        let transformCaseFunc = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : stringToLowerCase;
        if (setPrototypeOf) {
            // Make 'in' and truthy checks like Boolean(set.constructor)
            // independent of any properties defined on Object.prototype.
            // Prevent prototype setters from intercepting set as a this value.
            setPrototypeOf(set, null);
        }
        let l = array.length;
        while(l--){
            let element = array[l];
            if (typeof element === 'string') {
                const lcElement = transformCaseFunc(element);
                if (lcElement !== element) {
                    // Config presets (e.g. tags.js, attrs.js) are immutable.
                    if (!isFrozen(array)) {
                        array[l] = lcElement;
                    }
                    element = lcElement;
                }
            }
            set[element] = true;
        }
        return set;
    }
    /**
   * Clean up an array to harden against CSPP
   *
   * @param {Array} array - The array to be cleaned.
   * @returns {Array} The cleaned version of the array
   */ function cleanArray(array) {
        for(let index = 0; index < array.length; index++){
            const isPropertyExist = objectHasOwnProperty(array, index);
            if (!isPropertyExist) {
                array[index] = null;
            }
        }
        return array;
    }
    /**
   * Shallow clone an object
   *
   * @param {Object} object - The object to be cloned.
   * @returns {Object} A new object that copies the original.
   */ function clone(object) {
        const newObject = create(null);
        for (const [property, value] of entries(object)){
            const isPropertyExist = objectHasOwnProperty(object, property);
            if (isPropertyExist) {
                if (Array.isArray(value)) {
                    newObject[property] = cleanArray(value);
                } else if (value && typeof value === 'object' && value.constructor === Object) {
                    newObject[property] = clone(value);
                } else {
                    newObject[property] = value;
                }
            }
        }
        return newObject;
    }
    /**
   * This method automatically checks if the prop is function or getter and behaves accordingly.
   *
   * @param {Object} object - The object to look up the getter function in its prototype chain.
   * @param {String} prop - The property name for which to find the getter function.
   * @returns {Function} The getter function found in the prototype chain or a fallback function.
   */ function lookupGetter(object, prop) {
        while(object !== null){
            const desc = getOwnPropertyDescriptor(object, prop);
            if (desc) {
                if (desc.get) {
                    return unapply(desc.get);
                }
                if (typeof desc.value === 'function') {
                    return unapply(desc.value);
                }
            }
            object = getPrototypeOf(object);
        }
        function fallbackValue() {
            return null;
        }
        return fallbackValue;
    }
    const html$1 = freeze([
        'a',
        'abbr',
        'acronym',
        'address',
        'area',
        'article',
        'aside',
        'audio',
        'b',
        'bdi',
        'bdo',
        'big',
        'blink',
        'blockquote',
        'body',
        'br',
        'button',
        'canvas',
        'caption',
        'center',
        'cite',
        'code',
        'col',
        'colgroup',
        'content',
        'data',
        'datalist',
        'dd',
        'decorator',
        'del',
        'details',
        'dfn',
        'dialog',
        'dir',
        'div',
        'dl',
        'dt',
        'element',
        'em',
        'fieldset',
        'figcaption',
        'figure',
        'font',
        'footer',
        'form',
        'h1',
        'h2',
        'h3',
        'h4',
        'h5',
        'h6',
        'head',
        'header',
        'hgroup',
        'hr',
        'html',
        'i',
        'img',
        'input',
        'ins',
        'kbd',
        'label',
        'legend',
        'li',
        'main',
        'map',
        'mark',
        'marquee',
        'menu',
        'menuitem',
        'meter',
        'nav',
        'nobr',
        'ol',
        'optgroup',
        'option',
        'output',
        'p',
        'picture',
        'pre',
        'progress',
        'q',
        'rp',
        'rt',
        'ruby',
        's',
        'samp',
        'section',
        'select',
        'shadow',
        'small',
        'source',
        'spacer',
        'span',
        'strike',
        'strong',
        'style',
        'sub',
        'summary',
        'sup',
        'table',
        'tbody',
        'td',
        'template',
        'textarea',
        'tfoot',
        'th',
        'thead',
        'time',
        'tr',
        'track',
        'tt',
        'u',
        'ul',
        'var',
        'video',
        'wbr'
    ]);
    // SVG
    const svg$1 = freeze([
        'svg',
        'a',
        'altglyph',
        'altglyphdef',
        'altglyphitem',
        'animatecolor',
        'animatemotion',
        'animatetransform',
        'circle',
        'clippath',
        'defs',
        'desc',
        'ellipse',
        'filter',
        'font',
        'g',
        'glyph',
        'glyphref',
        'hkern',
        'image',
        'line',
        'lineargradient',
        'marker',
        'mask',
        'metadata',
        'mpath',
        'path',
        'pattern',
        'polygon',
        'polyline',
        'radialgradient',
        'rect',
        'stop',
        'style',
        'switch',
        'symbol',
        'text',
        'textpath',
        'title',
        'tref',
        'tspan',
        'view',
        'vkern'
    ]);
    const svgFilters = freeze([
        'feBlend',
        'feColorMatrix',
        'feComponentTransfer',
        'feComposite',
        'feConvolveMatrix',
        'feDiffuseLighting',
        'feDisplacementMap',
        'feDistantLight',
        'feDropShadow',
        'feFlood',
        'feFuncA',
        'feFuncB',
        'feFuncG',
        'feFuncR',
        'feGaussianBlur',
        'feImage',
        'feMerge',
        'feMergeNode',
        'feMorphology',
        'feOffset',
        'fePointLight',
        'feSpecularLighting',
        'feSpotLight',
        'feTile',
        'feTurbulence'
    ]);
    // List of SVG elements that are disallowed by default.
    // We still need to know them so that we can do namespace
    // checks properly in case one wants to add them to
    // allow-list.
    const svgDisallowed = freeze([
        'animate',
        'color-profile',
        'cursor',
        'discard',
        'font-face',
        'font-face-format',
        'font-face-name',
        'font-face-src',
        'font-face-uri',
        'foreignobject',
        'hatch',
        'hatchpath',
        'mesh',
        'meshgradient',
        'meshpatch',
        'meshrow',
        'missing-glyph',
        'script',
        'set',
        'solidcolor',
        'unknown',
        'use'
    ]);
    const mathMl$1 = freeze([
        'math',
        'menclose',
        'merror',
        'mfenced',
        'mfrac',
        'mglyph',
        'mi',
        'mlabeledtr',
        'mmultiscripts',
        'mn',
        'mo',
        'mover',
        'mpadded',
        'mphantom',
        'mroot',
        'mrow',
        'ms',
        'mspace',
        'msqrt',
        'mstyle',
        'msub',
        'msup',
        'msubsup',
        'mtable',
        'mtd',
        'mtext',
        'mtr',
        'munder',
        'munderover',
        'mprescripts'
    ]);
    // Similarly to SVG, we want to know all MathML elements,
    // even those that we disallow by default.
    const mathMlDisallowed = freeze([
        'maction',
        'maligngroup',
        'malignmark',
        'mlongdiv',
        'mscarries',
        'mscarry',
        'msgroup',
        'mstack',
        'msline',
        'msrow',
        'semantics',
        'annotation',
        'annotation-xml',
        'mprescripts',
        'none'
    ]);
    const text = freeze([
        '#text'
    ]);
    const html = freeze([
        'accept',
        'action',
        'align',
        'alt',
        'autocapitalize',
        'autocomplete',
        'autopictureinpicture',
        'autoplay',
        'background',
        'bgcolor',
        'border',
        'capture',
        'cellpadding',
        'cellspacing',
        'checked',
        'cite',
        'class',
        'clear',
        'color',
        'cols',
        'colspan',
        'controls',
        'controlslist',
        'coords',
        'crossorigin',
        'datetime',
        'decoding',
        'default',
        'dir',
        'disabled',
        'disablepictureinpicture',
        'disableremoteplayback',
        'download',
        'draggable',
        'enctype',
        'enterkeyhint',
        'face',
        'for',
        'headers',
        'height',
        'hidden',
        'high',
        'href',
        'hreflang',
        'id',
        'inputmode',
        'integrity',
        'ismap',
        'kind',
        'label',
        'lang',
        'list',
        'loading',
        'loop',
        'low',
        'max',
        'maxlength',
        'media',
        'method',
        'min',
        'minlength',
        'multiple',
        'muted',
        'name',
        'nonce',
        'noshade',
        'novalidate',
        'nowrap',
        'open',
        'optimum',
        'pattern',
        'placeholder',
        'playsinline',
        'popover',
        'popovertarget',
        'popovertargetaction',
        'poster',
        'preload',
        'pubdate',
        'radiogroup',
        'readonly',
        'rel',
        'required',
        'rev',
        'reversed',
        'role',
        'rows',
        'rowspan',
        'spellcheck',
        'scope',
        'selected',
        'shape',
        'size',
        'sizes',
        'span',
        'srclang',
        'start',
        'src',
        'srcset',
        'step',
        'style',
        'summary',
        'tabindex',
        'title',
        'translate',
        'type',
        'usemap',
        'valign',
        'value',
        'width',
        'wrap',
        'xmlns',
        'slot'
    ]);
    const svg = freeze([
        'accent-height',
        'accumulate',
        'additive',
        'alignment-baseline',
        'ascent',
        'attributename',
        'attributetype',
        'azimuth',
        'basefrequency',
        'baseline-shift',
        'begin',
        'bias',
        'by',
        'class',
        'clip',
        'clippathunits',
        'clip-path',
        'clip-rule',
        'color',
        'color-interpolation',
        'color-interpolation-filters',
        'color-profile',
        'color-rendering',
        'cx',
        'cy',
        'd',
        'dx',
        'dy',
        'diffuseconstant',
        'direction',
        'display',
        'divisor',
        'dur',
        'edgemode',
        'elevation',
        'end',
        'fill',
        'fill-opacity',
        'fill-rule',
        'filter',
        'filterunits',
        'flood-color',
        'flood-opacity',
        'font-family',
        'font-size',
        'font-size-adjust',
        'font-stretch',
        'font-style',
        'font-variant',
        'font-weight',
        'fx',
        'fy',
        'g1',
        'g2',
        'glyph-name',
        'glyphref',
        'gradientunits',
        'gradienttransform',
        'height',
        'href',
        'id',
        'image-rendering',
        'in',
        'in2',
        'k',
        'k1',
        'k2',
        'k3',
        'k4',
        'kerning',
        'keypoints',
        'keysplines',
        'keytimes',
        'lang',
        'lengthadjust',
        'letter-spacing',
        'kernelmatrix',
        'kernelunitlength',
        'lighting-color',
        'local',
        'marker-end',
        'marker-mid',
        'marker-start',
        'markerheight',
        'markerunits',
        'markerwidth',
        'maskcontentunits',
        'maskunits',
        'max',
        'mask',
        'media',
        'method',
        'mode',
        'min',
        'name',
        'numoctaves',
        'offset',
        'operator',
        'opacity',
        'order',
        'orient',
        'orientation',
        'origin',
        'overflow',
        'paint-order',
        'path',
        'pathlength',
        'patterncontentunits',
        'patterntransform',
        'patternunits',
        'points',
        'preservealpha',
        'preserveaspectratio',
        'primitiveunits',
        'r',
        'rx',
        'ry',
        'radius',
        'refx',
        'refy',
        'repeatcount',
        'repeatdur',
        'restart',
        'result',
        'rotate',
        'scale',
        'seed',
        'shape-rendering',
        'specularconstant',
        'specularexponent',
        'spreadmethod',
        'startoffset',
        'stddeviation',
        'stitchtiles',
        'stop-color',
        'stop-opacity',
        'stroke-dasharray',
        'stroke-dashoffset',
        'stroke-linecap',
        'stroke-linejoin',
        'stroke-miterlimit',
        'stroke-opacity',
        'stroke',
        'stroke-width',
        'style',
        'surfacescale',
        'systemlanguage',
        'tabindex',
        'targetx',
        'targety',
        'transform',
        'transform-origin',
        'text-anchor',
        'text-decoration',
        'text-rendering',
        'textlength',
        'type',
        'u1',
        'u2',
        'unicode',
        'values',
        'viewbox',
        'visibility',
        'version',
        'vert-adv-y',
        'vert-origin-x',
        'vert-origin-y',
        'width',
        'word-spacing',
        'wrap',
        'writing-mode',
        'xchannelselector',
        'ychannelselector',
        'x',
        'x1',
        'x2',
        'xmlns',
        'y',
        'y1',
        'y2',
        'z',
        'zoomandpan'
    ]);
    const mathMl = freeze([
        'accent',
        'accentunder',
        'align',
        'bevelled',
        'close',
        'columnsalign',
        'columnlines',
        'columnspan',
        'denomalign',
        'depth',
        'dir',
        'display',
        'displaystyle',
        'encoding',
        'fence',
        'frame',
        'height',
        'href',
        'id',
        'largeop',
        'length',
        'linethickness',
        'lspace',
        'lquote',
        'mathbackground',
        'mathcolor',
        'mathsize',
        'mathvariant',
        'maxsize',
        'minsize',
        'movablelimits',
        'notation',
        'numalign',
        'open',
        'rowalign',
        'rowlines',
        'rowspacing',
        'rowspan',
        'rspace',
        'rquote',
        'scriptlevel',
        'scriptminsize',
        'scriptsizemultiplier',
        'selection',
        'separator',
        'separators',
        'stretchy',
        'subscriptshift',
        'supscriptshift',
        'symmetric',
        'voffset',
        'width',
        'xmlns'
    ]);
    const xml = freeze([
        'xlink:href',
        'xml:id',
        'xlink:title',
        'xml:space',
        'xmlns:xlink'
    ]);
    // eslint-disable-next-line unicorn/better-regex
    const MUSTACHE_EXPR = seal(/\{\{[\w\W]*|[\w\W]*\}\}/gm); // Specify template detection regex for SAFE_FOR_TEMPLATES mode
    const ERB_EXPR = seal(/<%[\w\W]*|[\w\W]*%>/gm);
    const TMPLIT_EXPR = seal(/\${[\w\W]*}/gm);
    const DATA_ATTR = seal(/^data-[\-\w.\u00B7-\uFFFF]/); // eslint-disable-line no-useless-escape
    const ARIA_ATTR = seal(/^aria-[\-\w]+$/); // eslint-disable-line no-useless-escape
    const IS_ALLOWED_URI = seal(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i // eslint-disable-line no-useless-escape
    );
    const IS_SCRIPT_OR_DATA = seal(/^(?:\w+script|data):/i);
    const ATTR_WHITESPACE = seal(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g // eslint-disable-line no-control-regex
    );
    const DOCTYPE_NAME = seal(/^html$/i);
    const CUSTOM_ELEMENT = seal(/^[a-z][.\w]*(-[.\w]+)+$/i);
    var EXPRESSIONS = /*#__PURE__*/ Object.freeze({
        __proto__: null,
        MUSTACHE_EXPR: MUSTACHE_EXPR,
        ERB_EXPR: ERB_EXPR,
        TMPLIT_EXPR: TMPLIT_EXPR,
        DATA_ATTR: DATA_ATTR,
        ARIA_ATTR: ARIA_ATTR,
        IS_ALLOWED_URI: IS_ALLOWED_URI,
        IS_SCRIPT_OR_DATA: IS_SCRIPT_OR_DATA,
        ATTR_WHITESPACE: ATTR_WHITESPACE,
        DOCTYPE_NAME: DOCTYPE_NAME,
        CUSTOM_ELEMENT: CUSTOM_ELEMENT
    });
    // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
    const NODE_TYPE = {
        element: 1,
        attribute: 2,
        text: 3,
        cdataSection: 4,
        entityReference: 5,
        // Deprecated
        entityNode: 6,
        // Deprecated
        progressingInstruction: 7,
        comment: 8,
        document: 9,
        documentType: 10,
        documentFragment: 11,
        notation: 12 // Deprecated
    };
    const getGlobal = function getGlobal() {
        return typeof window === 'undefined' ? null : window;
    };
    /**
   * Creates a no-op policy for internal use only.
   * Don't export this function outside this module!
   * @param {TrustedTypePolicyFactory} trustedTypes The policy factory.
   * @param {HTMLScriptElement} purifyHostElement The Script element used to load DOMPurify (to determine policy name suffix).
   * @return {TrustedTypePolicy} The policy created (or null, if Trusted Types
   * are not supported or creating the policy failed).
   */ const _createTrustedTypesPolicy = function _createTrustedTypesPolicy(trustedTypes, purifyHostElement) {
        if (typeof trustedTypes !== 'object' || typeof trustedTypes.createPolicy !== 'function') {
            return null;
        }
        // Allow the callers to control the unique policy name
        // by adding a data-tt-policy-suffix to the script element with the DOMPurify.
        // Policy creation with duplicate names throws in Trusted Types.
        let suffix = null;
        const ATTR_NAME = 'data-tt-policy-suffix';
        if (purifyHostElement && purifyHostElement.hasAttribute(ATTR_NAME)) {
            suffix = purifyHostElement.getAttribute(ATTR_NAME);
        }
        const policyName = 'dompurify' + (suffix ? '#' + suffix : '');
        try {
            return trustedTypes.createPolicy(policyName, {
                createHTML (html) {
                    return html;
                },
                createScriptURL (scriptUrl) {
                    return scriptUrl;
                }
            });
        } catch (_) {
            // Policy creation failed (most likely another DOMPurify script has
            // already run). Skip creating the policy, as this will only cause errors
            // if TT are enforced.
            console.warn('TrustedTypes policy ' + policyName + ' could not be created.');
            return null;
        }
    };
    function createDOMPurify() {
        let window1 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : getGlobal();
        const DOMPurify = (root)=>createDOMPurify(root);
        /**
     * Version label, exposed for easier checks
     * if DOMPurify is up to date or not
     */ DOMPurify.version = '3.1.6';
        /**
     * Array of elements that DOMPurify removed during sanitation.
     * Empty if nothing was removed.
     */ DOMPurify.removed = [];
        if (!window1 || !window1.document || window1.document.nodeType !== NODE_TYPE.document) {
            // Not running in a browser, provide a factory function
            // so that you can pass your own Window
            DOMPurify.isSupported = false;
            return DOMPurify;
        }
        let { document } = window1;
        const originalDocument = document;
        const currentScript = originalDocument.currentScript;
        const { DocumentFragment, HTMLTemplateElement, Node, Element, NodeFilter, NamedNodeMap = window1.NamedNodeMap || window1.MozNamedAttrMap, HTMLFormElement, DOMParser, trustedTypes } = window1;
        const ElementPrototype = Element.prototype;
        const cloneNode = lookupGetter(ElementPrototype, 'cloneNode');
        const remove = lookupGetter(ElementPrototype, 'remove');
        const getNextSibling = lookupGetter(ElementPrototype, 'nextSibling');
        const getChildNodes = lookupGetter(ElementPrototype, 'childNodes');
        const getParentNode = lookupGetter(ElementPrototype, 'parentNode');
        // As per issue #47, the web-components registry is inherited by a
        // new document created via createHTMLDocument. As per the spec
        // (http://w3c.github.io/webcomponents/spec/custom/#creating-and-passing-registries)
        // a new empty registry is used when creating a template contents owner
        // document, so we use that as our parent document to ensure nothing
        // is inherited.
        if (typeof HTMLTemplateElement === 'function') {
            const template = document.createElement('template');
            if (template.content && template.content.ownerDocument) {
                document = template.content.ownerDocument;
            }
        }
        let trustedTypesPolicy;
        let emptyHTML = '';
        const { implementation, createNodeIterator, createDocumentFragment, getElementsByTagName } = document;
        const { importNode } = originalDocument;
        let hooks = {};
        /**
     * Expose whether this browser supports running the full DOMPurify.
     */ DOMPurify.isSupported = typeof entries === 'function' && typeof getParentNode === 'function' && implementation && implementation.createHTMLDocument !== undefined;
        const { MUSTACHE_EXPR, ERB_EXPR, TMPLIT_EXPR, DATA_ATTR, ARIA_ATTR, IS_SCRIPT_OR_DATA, ATTR_WHITESPACE, CUSTOM_ELEMENT } = EXPRESSIONS;
        let { IS_ALLOWED_URI: IS_ALLOWED_URI$1 } = EXPRESSIONS;
        /**
     * We consider the elements and attributes below to be safe. Ideally
     * don't add any new ones but feel free to remove unwanted ones.
     */ /* allowed element names */ let ALLOWED_TAGS = null;
        const DEFAULT_ALLOWED_TAGS = addToSet({}, [
            ...html$1,
            ...svg$1,
            ...svgFilters,
            ...mathMl$1,
            ...text
        ]);
        /* Allowed attribute names */ let ALLOWED_ATTR = null;
        const DEFAULT_ALLOWED_ATTR = addToSet({}, [
            ...html,
            ...svg,
            ...mathMl,
            ...xml
        ]);
        /*
     * Configure how DOMPUrify should handle custom elements and their attributes as well as customized built-in elements.
     * @property {RegExp|Function|null} tagNameCheck one of [null, regexPattern, predicate]. Default: `null` (disallow any custom elements)
     * @property {RegExp|Function|null} attributeNameCheck one of [null, regexPattern, predicate]. Default: `null` (disallow any attributes not on the allow list)
     * @property {boolean} allowCustomizedBuiltInElements allow custom elements derived from built-ins if they pass CUSTOM_ELEMENT_HANDLING.tagNameCheck. Default: `false`.
     */ let CUSTOM_ELEMENT_HANDLING = Object.seal(create(null, {
            tagNameCheck: {
                writable: true,
                configurable: false,
                enumerable: true,
                value: null
            },
            attributeNameCheck: {
                writable: true,
                configurable: false,
                enumerable: true,
                value: null
            },
            allowCustomizedBuiltInElements: {
                writable: true,
                configurable: false,
                enumerable: true,
                value: false
            }
        }));
        /* Explicitly forbidden tags (overrides ALLOWED_TAGS/ADD_TAGS) */ let FORBID_TAGS = null;
        /* Explicitly forbidden attributes (overrides ALLOWED_ATTR/ADD_ATTR) */ let FORBID_ATTR = null;
        /* Decide if ARIA attributes are okay */ let ALLOW_ARIA_ATTR = true;
        /* Decide if custom data attributes are okay */ let ALLOW_DATA_ATTR = true;
        /* Decide if unknown protocols are okay */ let ALLOW_UNKNOWN_PROTOCOLS = false;
        /* Decide if self-closing tags in attributes are allowed.
     * Usually removed due to a mXSS issue in jQuery 3.0 */ let ALLOW_SELF_CLOSE_IN_ATTR = true;
        /* Output should be safe for common template engines.
     * This means, DOMPurify removes data attributes, mustaches and ERB
     */ let SAFE_FOR_TEMPLATES = false;
        /* Output should be safe even for XML used within HTML and alike.
     * This means, DOMPurify removes comments when containing risky content.
     */ let SAFE_FOR_XML = true;
        /* Decide if document with <html>... should be returned */ let WHOLE_DOCUMENT = false;
        /* Track whether config is already set on this instance of DOMPurify. */ let SET_CONFIG = false;
        /* Decide if all elements (e.g. style, script) must be children of
     * document.body. By default, browsers might move them to document.head */ let FORCE_BODY = false;
        /* Decide if a DOM `HTMLBodyElement` should be returned, instead of a html
     * string (or a TrustedHTML object if Trusted Types are supported).
     * If `WHOLE_DOCUMENT` is enabled a `HTMLHtmlElement` will be returned instead
     */ let RETURN_DOM = false;
        /* Decide if a DOM `DocumentFragment` should be returned, instead of a html
     * string  (or a TrustedHTML object if Trusted Types are supported) */ let RETURN_DOM_FRAGMENT = false;
        /* Try to return a Trusted Type object instead of a string, return a string in
     * case Trusted Types are not supported  */ let RETURN_TRUSTED_TYPE = false;
        /* Output should be free from DOM clobbering attacks?
     * This sanitizes markups named with colliding, clobberable built-in DOM APIs.
     */ let SANITIZE_DOM = true;
        /* Achieve full DOM Clobbering protection by isolating the namespace of named
     * properties and JS variables, mitigating attacks that abuse the HTML/DOM spec rules.
     *
     * HTML/DOM spec rules that enable DOM Clobbering:
     *   - Named Access on Window (§7.3.3)
     *   - DOM Tree Accessors (§3.1.5)
     *   - Form Element Parent-Child Relations (§4.10.3)
     *   - Iframe srcdoc / Nested WindowProxies (§4.8.5)
     *   - HTMLCollection (§4.2.10.2)
     *
     * Namespace isolation is implemented by prefixing `id` and `name` attributes
     * with a constant string, i.e., `user-content-`
     */ let SANITIZE_NAMED_PROPS = false;
        const SANITIZE_NAMED_PROPS_PREFIX = 'user-content-';
        /* Keep element content when removing element? */ let KEEP_CONTENT = true;
        /* If a `Node` is passed to sanitize(), then performs sanitization in-place instead
     * of importing it into a new Document and returning a sanitized copy */ let IN_PLACE = false;
        /* Allow usage of profiles like html, svg and mathMl */ let USE_PROFILES = {};
        /* Tags to ignore content of when KEEP_CONTENT is true */ let FORBID_CONTENTS = null;
        const DEFAULT_FORBID_CONTENTS = addToSet({}, [
            'annotation-xml',
            'audio',
            'colgroup',
            'desc',
            'foreignobject',
            'head',
            'iframe',
            'math',
            'mi',
            'mn',
            'mo',
            'ms',
            'mtext',
            'noembed',
            'noframes',
            'noscript',
            'plaintext',
            'script',
            'style',
            'svg',
            'template',
            'thead',
            'title',
            'video',
            'xmp'
        ]);
        /* Tags that are safe for data: URIs */ let DATA_URI_TAGS = null;
        const DEFAULT_DATA_URI_TAGS = addToSet({}, [
            'audio',
            'video',
            'img',
            'source',
            'image',
            'track'
        ]);
        /* Attributes safe for values like "javascript:" */ let URI_SAFE_ATTRIBUTES = null;
        const DEFAULT_URI_SAFE_ATTRIBUTES = addToSet({}, [
            'alt',
            'class',
            'for',
            'id',
            'label',
            'name',
            'pattern',
            'placeholder',
            'role',
            'summary',
            'title',
            'value',
            'style',
            'xmlns'
        ]);
        const MATHML_NAMESPACE = 'http://www.w3.org/1998/Math/MathML';
        const SVG_NAMESPACE = 'http://www.w3.org/2000/svg';
        const HTML_NAMESPACE = 'http://www.w3.org/1999/xhtml';
        /* Document namespace */ let NAMESPACE = HTML_NAMESPACE;
        let IS_EMPTY_INPUT = false;
        /* Allowed XHTML+XML namespaces */ let ALLOWED_NAMESPACES = null;
        const DEFAULT_ALLOWED_NAMESPACES = addToSet({}, [
            MATHML_NAMESPACE,
            SVG_NAMESPACE,
            HTML_NAMESPACE
        ], stringToString);
        /* Parsing of strict XHTML documents */ let PARSER_MEDIA_TYPE = null;
        const SUPPORTED_PARSER_MEDIA_TYPES = [
            'application/xhtml+xml',
            'text/html'
        ];
        const DEFAULT_PARSER_MEDIA_TYPE = 'text/html';
        let transformCaseFunc = null;
        /* Keep a reference to config to pass to hooks */ let CONFIG = null;
        /* Ideally, do not touch anything below this line */ /* ______________________________________________ */ const formElement = document.createElement('form');
        const isRegexOrFunction = function isRegexOrFunction(testValue) {
            return testValue instanceof RegExp || testValue instanceof Function;
        };
        /**
     * _parseConfig
     *
     * @param  {Object} cfg optional config literal
     */ // eslint-disable-next-line complexity
        const _parseConfig = function _parseConfig() {
            let cfg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            if (CONFIG && CONFIG === cfg) {
                return;
            }
            /* Shield configuration object from tampering */ if (!cfg || typeof cfg !== 'object') {
                cfg = {};
            }
            /* Shield configuration object from prototype pollution */ cfg = clone(cfg);
            PARSER_MEDIA_TYPE = // eslint-disable-next-line unicorn/prefer-includes
            SUPPORTED_PARSER_MEDIA_TYPES.indexOf(cfg.PARSER_MEDIA_TYPE) === -1 ? DEFAULT_PARSER_MEDIA_TYPE : cfg.PARSER_MEDIA_TYPE;
            // HTML tags and attributes are not case-sensitive, converting to lowercase. Keeping XHTML as is.
            transformCaseFunc = PARSER_MEDIA_TYPE === 'application/xhtml+xml' ? stringToString : stringToLowerCase;
            /* Set configuration parameters */ ALLOWED_TAGS = objectHasOwnProperty(cfg, 'ALLOWED_TAGS') ? addToSet({}, cfg.ALLOWED_TAGS, transformCaseFunc) : DEFAULT_ALLOWED_TAGS;
            ALLOWED_ATTR = objectHasOwnProperty(cfg, 'ALLOWED_ATTR') ? addToSet({}, cfg.ALLOWED_ATTR, transformCaseFunc) : DEFAULT_ALLOWED_ATTR;
            ALLOWED_NAMESPACES = objectHasOwnProperty(cfg, 'ALLOWED_NAMESPACES') ? addToSet({}, cfg.ALLOWED_NAMESPACES, stringToString) : DEFAULT_ALLOWED_NAMESPACES;
            URI_SAFE_ATTRIBUTES = objectHasOwnProperty(cfg, 'ADD_URI_SAFE_ATTR') ? addToSet(clone(DEFAULT_URI_SAFE_ATTRIBUTES), // eslint-disable-line indent
            cfg.ADD_URI_SAFE_ATTR, // eslint-disable-line indent
            transformCaseFunc // eslint-disable-line indent
            ) // eslint-disable-line indent
             : DEFAULT_URI_SAFE_ATTRIBUTES;
            DATA_URI_TAGS = objectHasOwnProperty(cfg, 'ADD_DATA_URI_TAGS') ? addToSet(clone(DEFAULT_DATA_URI_TAGS), // eslint-disable-line indent
            cfg.ADD_DATA_URI_TAGS, // eslint-disable-line indent
            transformCaseFunc // eslint-disable-line indent
            ) // eslint-disable-line indent
             : DEFAULT_DATA_URI_TAGS;
            FORBID_CONTENTS = objectHasOwnProperty(cfg, 'FORBID_CONTENTS') ? addToSet({}, cfg.FORBID_CONTENTS, transformCaseFunc) : DEFAULT_FORBID_CONTENTS;
            FORBID_TAGS = objectHasOwnProperty(cfg, 'FORBID_TAGS') ? addToSet({}, cfg.FORBID_TAGS, transformCaseFunc) : {};
            FORBID_ATTR = objectHasOwnProperty(cfg, 'FORBID_ATTR') ? addToSet({}, cfg.FORBID_ATTR, transformCaseFunc) : {};
            USE_PROFILES = objectHasOwnProperty(cfg, 'USE_PROFILES') ? cfg.USE_PROFILES : false;
            ALLOW_ARIA_ATTR = cfg.ALLOW_ARIA_ATTR !== false; // Default true
            ALLOW_DATA_ATTR = cfg.ALLOW_DATA_ATTR !== false; // Default true
            ALLOW_UNKNOWN_PROTOCOLS = cfg.ALLOW_UNKNOWN_PROTOCOLS || false; // Default false
            ALLOW_SELF_CLOSE_IN_ATTR = cfg.ALLOW_SELF_CLOSE_IN_ATTR !== false; // Default true
            SAFE_FOR_TEMPLATES = cfg.SAFE_FOR_TEMPLATES || false; // Default false
            SAFE_FOR_XML = cfg.SAFE_FOR_XML !== false; // Default true
            WHOLE_DOCUMENT = cfg.WHOLE_DOCUMENT || false; // Default false
            RETURN_DOM = cfg.RETURN_DOM || false; // Default false
            RETURN_DOM_FRAGMENT = cfg.RETURN_DOM_FRAGMENT || false; // Default false
            RETURN_TRUSTED_TYPE = cfg.RETURN_TRUSTED_TYPE || false; // Default false
            FORCE_BODY = cfg.FORCE_BODY || false; // Default false
            SANITIZE_DOM = cfg.SANITIZE_DOM !== false; // Default true
            SANITIZE_NAMED_PROPS = cfg.SANITIZE_NAMED_PROPS || false; // Default false
            KEEP_CONTENT = cfg.KEEP_CONTENT !== false; // Default true
            IN_PLACE = cfg.IN_PLACE || false; // Default false
            IS_ALLOWED_URI$1 = cfg.ALLOWED_URI_REGEXP || IS_ALLOWED_URI;
            NAMESPACE = cfg.NAMESPACE || HTML_NAMESPACE;
            CUSTOM_ELEMENT_HANDLING = cfg.CUSTOM_ELEMENT_HANDLING || {};
            if (cfg.CUSTOM_ELEMENT_HANDLING && isRegexOrFunction(cfg.CUSTOM_ELEMENT_HANDLING.tagNameCheck)) {
                CUSTOM_ELEMENT_HANDLING.tagNameCheck = cfg.CUSTOM_ELEMENT_HANDLING.tagNameCheck;
            }
            if (cfg.CUSTOM_ELEMENT_HANDLING && isRegexOrFunction(cfg.CUSTOM_ELEMENT_HANDLING.attributeNameCheck)) {
                CUSTOM_ELEMENT_HANDLING.attributeNameCheck = cfg.CUSTOM_ELEMENT_HANDLING.attributeNameCheck;
            }
            if (cfg.CUSTOM_ELEMENT_HANDLING && typeof cfg.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements === 'boolean') {
                CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements = cfg.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements;
            }
            if (SAFE_FOR_TEMPLATES) {
                ALLOW_DATA_ATTR = false;
            }
            if (RETURN_DOM_FRAGMENT) {
                RETURN_DOM = true;
            }
            /* Parse profile info */ if (USE_PROFILES) {
                ALLOWED_TAGS = addToSet({}, text);
                ALLOWED_ATTR = [];
                if (USE_PROFILES.html === true) {
                    addToSet(ALLOWED_TAGS, html$1);
                    addToSet(ALLOWED_ATTR, html);
                }
                if (USE_PROFILES.svg === true) {
                    addToSet(ALLOWED_TAGS, svg$1);
                    addToSet(ALLOWED_ATTR, svg);
                    addToSet(ALLOWED_ATTR, xml);
                }
                if (USE_PROFILES.svgFilters === true) {
                    addToSet(ALLOWED_TAGS, svgFilters);
                    addToSet(ALLOWED_ATTR, svg);
                    addToSet(ALLOWED_ATTR, xml);
                }
                if (USE_PROFILES.mathMl === true) {
                    addToSet(ALLOWED_TAGS, mathMl$1);
                    addToSet(ALLOWED_ATTR, mathMl);
                    addToSet(ALLOWED_ATTR, xml);
                }
            }
            /* Merge configuration parameters */ if (cfg.ADD_TAGS) {
                if (ALLOWED_TAGS === DEFAULT_ALLOWED_TAGS) {
                    ALLOWED_TAGS = clone(ALLOWED_TAGS);
                }
                addToSet(ALLOWED_TAGS, cfg.ADD_TAGS, transformCaseFunc);
            }
            if (cfg.ADD_ATTR) {
                if (ALLOWED_ATTR === DEFAULT_ALLOWED_ATTR) {
                    ALLOWED_ATTR = clone(ALLOWED_ATTR);
                }
                addToSet(ALLOWED_ATTR, cfg.ADD_ATTR, transformCaseFunc);
            }
            if (cfg.ADD_URI_SAFE_ATTR) {
                addToSet(URI_SAFE_ATTRIBUTES, cfg.ADD_URI_SAFE_ATTR, transformCaseFunc);
            }
            if (cfg.FORBID_CONTENTS) {
                if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) {
                    FORBID_CONTENTS = clone(FORBID_CONTENTS);
                }
                addToSet(FORBID_CONTENTS, cfg.FORBID_CONTENTS, transformCaseFunc);
            }
            /* Add #text in case KEEP_CONTENT is set to true */ if (KEEP_CONTENT) {
                ALLOWED_TAGS['#text'] = true;
            }
            /* Add html, head and body to ALLOWED_TAGS in case WHOLE_DOCUMENT is true */ if (WHOLE_DOCUMENT) {
                addToSet(ALLOWED_TAGS, [
                    'html',
                    'head',
                    'body'
                ]);
            }
            /* Add tbody to ALLOWED_TAGS in case tables are permitted, see #286, #365 */ if (ALLOWED_TAGS.table) {
                addToSet(ALLOWED_TAGS, [
                    'tbody'
                ]);
                delete FORBID_TAGS.tbody;
            }
            if (cfg.TRUSTED_TYPES_POLICY) {
                if (typeof cfg.TRUSTED_TYPES_POLICY.createHTML !== 'function') {
                    throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
                }
                if (typeof cfg.TRUSTED_TYPES_POLICY.createScriptURL !== 'function') {
                    throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
                }
                // Overwrite existing TrustedTypes policy.
                trustedTypesPolicy = cfg.TRUSTED_TYPES_POLICY;
                // Sign local variables required by `sanitize`.
                emptyHTML = trustedTypesPolicy.createHTML('');
            } else {
                // Uninitialized policy, attempt to initialize the internal dompurify policy.
                if (trustedTypesPolicy === undefined) {
                    trustedTypesPolicy = _createTrustedTypesPolicy(trustedTypes, currentScript);
                }
                // If creating the internal policy succeeded sign internal variables.
                if (trustedTypesPolicy !== null && typeof emptyHTML === 'string') {
                    emptyHTML = trustedTypesPolicy.createHTML('');
                }
            }
            // Prevent further manipulation of configuration.
            // Not available in IE8, Safari 5, etc.
            if (freeze) {
                freeze(cfg);
            }
            CONFIG = cfg;
        };
        const MATHML_TEXT_INTEGRATION_POINTS = addToSet({}, [
            'mi',
            'mo',
            'mn',
            'ms',
            'mtext'
        ]);
        const HTML_INTEGRATION_POINTS = addToSet({}, [
            'foreignobject',
            'annotation-xml'
        ]);
        // Certain elements are allowed in both SVG and HTML
        // namespace. We need to specify them explicitly
        // so that they don't get erroneously deleted from
        // HTML namespace.
        const COMMON_SVG_AND_HTML_ELEMENTS = addToSet({}, [
            'title',
            'style',
            'font',
            'a',
            'script'
        ]);
        /* Keep track of all possible SVG and MathML tags
     * so that we can perform the namespace checks
     * correctly. */ const ALL_SVG_TAGS = addToSet({}, [
            ...svg$1,
            ...svgFilters,
            ...svgDisallowed
        ]);
        const ALL_MATHML_TAGS = addToSet({}, [
            ...mathMl$1,
            ...mathMlDisallowed
        ]);
        /**
     * @param  {Element} element a DOM element whose namespace is being checked
     * @returns {boolean} Return false if the element has a
     *  namespace that a spec-compliant parser would never
     *  return. Return true otherwise.
     */ const _checkValidNamespace = function _checkValidNamespace(element) {
            let parent = getParentNode(element);
            // In JSDOM, if we're inside shadow DOM, then parentNode
            // can be null. We just simulate parent in this case.
            if (!parent || !parent.tagName) {
                parent = {
                    namespaceURI: NAMESPACE,
                    tagName: 'template'
                };
            }
            const tagName = stringToLowerCase(element.tagName);
            const parentTagName = stringToLowerCase(parent.tagName);
            if (!ALLOWED_NAMESPACES[element.namespaceURI]) {
                return false;
            }
            if (element.namespaceURI === SVG_NAMESPACE) {
                // The only way to switch from HTML namespace to SVG
                // is via <svg>. If it happens via any other tag, then
                // it should be killed.
                if (parent.namespaceURI === HTML_NAMESPACE) {
                    return tagName === 'svg';
                }
                // The only way to switch from MathML to SVG is via`
                // svg if parent is either <annotation-xml> or MathML
                // text integration points.
                if (parent.namespaceURI === MATHML_NAMESPACE) {
                    return tagName === 'svg' && (parentTagName === 'annotation-xml' || MATHML_TEXT_INTEGRATION_POINTS[parentTagName]);
                }
                // We only allow elements that are defined in SVG
                // spec. All others are disallowed in SVG namespace.
                return Boolean(ALL_SVG_TAGS[tagName]);
            }
            if (element.namespaceURI === MATHML_NAMESPACE) {
                // The only way to switch from HTML namespace to MathML
                // is via <math>. If it happens via any other tag, then
                // it should be killed.
                if (parent.namespaceURI === HTML_NAMESPACE) {
                    return tagName === 'math';
                }
                // The only way to switch from SVG to MathML is via
                // <math> and HTML integration points
                if (parent.namespaceURI === SVG_NAMESPACE) {
                    return tagName === 'math' && HTML_INTEGRATION_POINTS[parentTagName];
                }
                // We only allow elements that are defined in MathML
                // spec. All others are disallowed in MathML namespace.
                return Boolean(ALL_MATHML_TAGS[tagName]);
            }
            if (element.namespaceURI === HTML_NAMESPACE) {
                // The only way to switch from SVG to HTML is via
                // HTML integration points, and from MathML to HTML
                // is via MathML text integration points
                if (parent.namespaceURI === SVG_NAMESPACE && !HTML_INTEGRATION_POINTS[parentTagName]) {
                    return false;
                }
                if (parent.namespaceURI === MATHML_NAMESPACE && !MATHML_TEXT_INTEGRATION_POINTS[parentTagName]) {
                    return false;
                }
                // We disallow tags that are specific for MathML
                // or SVG and should never appear in HTML namespace
                return !ALL_MATHML_TAGS[tagName] && (COMMON_SVG_AND_HTML_ELEMENTS[tagName] || !ALL_SVG_TAGS[tagName]);
            }
            // For XHTML and XML documents that support custom namespaces
            if (PARSER_MEDIA_TYPE === 'application/xhtml+xml' && ALLOWED_NAMESPACES[element.namespaceURI]) {
                return true;
            }
            // The code should never reach this place (this means
            // that the element somehow got namespace that is not
            // HTML, SVG, MathML or allowed via ALLOWED_NAMESPACES).
            // Return false just in case.
            return false;
        };
        /**
     * _forceRemove
     *
     * @param  {Node} node a DOM node
     */ const _forceRemove = function _forceRemove(node) {
            arrayPush(DOMPurify.removed, {
                element: node
            });
            try {
                // eslint-disable-next-line unicorn/prefer-dom-node-remove
                getParentNode(node).removeChild(node);
            } catch (_) {
                remove(node);
            }
        };
        /**
     * _removeAttribute
     *
     * @param  {String} name an Attribute name
     * @param  {Node} node a DOM node
     */ const _removeAttribute = function _removeAttribute(name, node) {
            try {
                arrayPush(DOMPurify.removed, {
                    attribute: node.getAttributeNode(name),
                    from: node
                });
            } catch (_) {
                arrayPush(DOMPurify.removed, {
                    attribute: null,
                    from: node
                });
            }
            node.removeAttribute(name);
            // We void attribute values for unremovable "is"" attributes
            if (name === 'is' && !ALLOWED_ATTR[name]) {
                if (RETURN_DOM || RETURN_DOM_FRAGMENT) {
                    try {
                        _forceRemove(node);
                    } catch (_) {}
                } else {
                    try {
                        node.setAttribute(name, '');
                    } catch (_) {}
                }
            }
        };
        /**
     * _initDocument
     *
     * @param  {String} dirty a string of dirty markup
     * @return {Document} a DOM, filled with the dirty markup
     */ const _initDocument = function _initDocument(dirty) {
            /* Create a HTML document */ let doc = null;
            let leadingWhitespace = null;
            if (FORCE_BODY) {
                dirty = '<remove></remove>' + dirty;
            } else {
                /* If FORCE_BODY isn't used, leading whitespace needs to be preserved manually */ const matches = stringMatch(dirty, /^[\r\n\t ]+/);
                leadingWhitespace = matches && matches[0];
            }
            if (PARSER_MEDIA_TYPE === 'application/xhtml+xml' && NAMESPACE === HTML_NAMESPACE) {
                // Root of XHTML doc must contain xmlns declaration (see https://www.w3.org/TR/xhtml1/normative.html#strict)
                dirty = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + dirty + '</body></html>';
            }
            const dirtyPayload = trustedTypesPolicy ? trustedTypesPolicy.createHTML(dirty) : dirty;
            /*
       * Use the DOMParser API by default, fallback later if needs be
       * DOMParser not work for svg when has multiple root element.
       */ if (NAMESPACE === HTML_NAMESPACE) {
                try {
                    doc = new DOMParser().parseFromString(dirtyPayload, PARSER_MEDIA_TYPE);
                } catch (_) {}
            }
            /* Use createHTMLDocument in case DOMParser is not available */ if (!doc || !doc.documentElement) {
                doc = implementation.createDocument(NAMESPACE, 'template', null);
                try {
                    doc.documentElement.innerHTML = IS_EMPTY_INPUT ? emptyHTML : dirtyPayload;
                } catch (_) {
                // Syntax error if dirtyPayload is invalid xml
                }
            }
            const body = doc.body || doc.documentElement;
            if (dirty && leadingWhitespace) {
                body.insertBefore(document.createTextNode(leadingWhitespace), body.childNodes[0] || null);
            }
            /* Work on whole document or just its body */ if (NAMESPACE === HTML_NAMESPACE) {
                return getElementsByTagName.call(doc, WHOLE_DOCUMENT ? 'html' : 'body')[0];
            }
            return WHOLE_DOCUMENT ? doc.documentElement : body;
        };
        /**
     * Creates a NodeIterator object that you can use to traverse filtered lists of nodes or elements in a document.
     *
     * @param  {Node} root The root element or node to start traversing on.
     * @return {NodeIterator} The created NodeIterator
     */ const _createNodeIterator = function _createNodeIterator(root) {
            return createNodeIterator.call(root.ownerDocument || root, root, // eslint-disable-next-line no-bitwise
            NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_TEXT | NodeFilter.SHOW_PROCESSING_INSTRUCTION | NodeFilter.SHOW_CDATA_SECTION, null);
        };
        /**
     * _isClobbered
     *
     * @param  {Node} elm element to check for clobbering attacks
     * @return {Boolean} true if clobbered, false if safe
     */ const _isClobbered = function _isClobbered(elm) {
            return elm instanceof HTMLFormElement && (typeof elm.nodeName !== 'string' || typeof elm.textContent !== 'string' || typeof elm.removeChild !== 'function' || !(elm.attributes instanceof NamedNodeMap) || typeof elm.removeAttribute !== 'function' || typeof elm.setAttribute !== 'function' || typeof elm.namespaceURI !== 'string' || typeof elm.insertBefore !== 'function' || typeof elm.hasChildNodes !== 'function');
        };
        /**
     * Checks whether the given object is a DOM node.
     *
     * @param  {Node} object object to check whether it's a DOM node
     * @return {Boolean} true is object is a DOM node
     */ const _isNode = function _isNode(object) {
            return typeof Node === 'function' && object instanceof Node;
        };
        /**
     * _executeHook
     * Execute user configurable hooks
     *
     * @param  {String} entryPoint  Name of the hook's entry point
     * @param  {Node} currentNode node to work on with the hook
     * @param  {Object} data additional hook parameters
     */ const _executeHook = function _executeHook(entryPoint, currentNode, data) {
            if (!hooks[entryPoint]) {
                return;
            }
            arrayForEach(hooks[entryPoint], (hook)=>{
                hook.call(DOMPurify, currentNode, data, CONFIG);
            });
        };
        /**
     * _sanitizeElements
     *
     * @protect nodeName
     * @protect textContent
     * @protect removeChild
     *
     * @param   {Node} currentNode to check for permission to exist
     * @return  {Boolean} true if node was killed, false if left alive
     */ const _sanitizeElements = function _sanitizeElements(currentNode) {
            let content = null;
            /* Execute a hook if present */ _executeHook('beforeSanitizeElements', currentNode, null);
            /* Check if element is clobbered or can clobber */ if (_isClobbered(currentNode)) {
                _forceRemove(currentNode);
                return true;
            }
            /* Now let's check the element's type and name */ const tagName = transformCaseFunc(currentNode.nodeName);
            /* Execute a hook if present */ _executeHook('uponSanitizeElement', currentNode, {
                tagName,
                allowedTags: ALLOWED_TAGS
            });
            /* Detect mXSS attempts abusing namespace confusion */ if (currentNode.hasChildNodes() && !_isNode(currentNode.firstElementChild) && regExpTest(/<[/\w]/g, currentNode.innerHTML) && regExpTest(/<[/\w]/g, currentNode.textContent)) {
                _forceRemove(currentNode);
                return true;
            }
            /* Remove any occurrence of processing instructions */ if (currentNode.nodeType === NODE_TYPE.progressingInstruction) {
                _forceRemove(currentNode);
                return true;
            }
            /* Remove any kind of possibly harmful comments */ if (SAFE_FOR_XML && currentNode.nodeType === NODE_TYPE.comment && regExpTest(/<[/\w]/g, currentNode.data)) {
                _forceRemove(currentNode);
                return true;
            }
            /* Remove element if anything forbids its presence */ if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) {
                /* Check if we have a custom element to handle */ if (!FORBID_TAGS[tagName] && _isBasicCustomElement(tagName)) {
                    if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, tagName)) {
                        return false;
                    }
                    if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(tagName)) {
                        return false;
                    }
                }
                /* Keep content except for bad-listed elements */ if (KEEP_CONTENT && !FORBID_CONTENTS[tagName]) {
                    const parentNode = getParentNode(currentNode) || currentNode.parentNode;
                    const childNodes = getChildNodes(currentNode) || currentNode.childNodes;
                    if (childNodes && parentNode) {
                        const childCount = childNodes.length;
                        for(let i = childCount - 1; i >= 0; --i){
                            const childClone = cloneNode(childNodes[i], true);
                            childClone.__removalCount = (currentNode.__removalCount || 0) + 1;
                            parentNode.insertBefore(childClone, getNextSibling(currentNode));
                        }
                    }
                }
                _forceRemove(currentNode);
                return true;
            }
            /* Check whether element has a valid namespace */ if (currentNode instanceof Element && !_checkValidNamespace(currentNode)) {
                _forceRemove(currentNode);
                return true;
            }
            /* Make sure that older browsers don't get fallback-tag mXSS */ if ((tagName === 'noscript' || tagName === 'noembed' || tagName === 'noframes') && regExpTest(/<\/no(script|embed|frames)/i, currentNode.innerHTML)) {
                _forceRemove(currentNode);
                return true;
            }
            /* Sanitize element content to be template-safe */ if (SAFE_FOR_TEMPLATES && currentNode.nodeType === NODE_TYPE.text) {
                /* Get the element's text content */ content = currentNode.textContent;
                arrayForEach([
                    MUSTACHE_EXPR,
                    ERB_EXPR,
                    TMPLIT_EXPR
                ], (expr)=>{
                    content = stringReplace(content, expr, ' ');
                });
                if (currentNode.textContent !== content) {
                    arrayPush(DOMPurify.removed, {
                        element: currentNode.cloneNode()
                    });
                    currentNode.textContent = content;
                }
            }
            /* Execute a hook if present */ _executeHook('afterSanitizeElements', currentNode, null);
            return false;
        };
        /**
     * _isValidAttribute
     *
     * @param  {string} lcTag Lowercase tag name of containing element.
     * @param  {string} lcName Lowercase attribute name.
     * @param  {string} value Attribute value.
     * @return {Boolean} Returns true if `value` is valid, otherwise false.
     */ // eslint-disable-next-line complexity
        const _isValidAttribute = function _isValidAttribute(lcTag, lcName, value) {
            /* Make sure attribute cannot clobber */ if (SANITIZE_DOM && (lcName === 'id' || lcName === 'name') && (value in document || value in formElement)) {
                return false;
            }
            /* Allow valid data-* attributes: At least one character after "-"
          (https://html.spec.whatwg.org/multipage/dom.html#embedding-custom-non-visible-data-with-the-data-*-attributes)
          XML-compatible (https://html.spec.whatwg.org/multipage/infrastructure.html#xml-compatible and http://www.w3.org/TR/xml/#d0e804)
          We don't need to check the value; it's always URI safe. */ if (ALLOW_DATA_ATTR && !FORBID_ATTR[lcName] && regExpTest(DATA_ATTR, lcName)) ;
            else if (ALLOW_ARIA_ATTR && regExpTest(ARIA_ATTR, lcName)) ;
            else if (!ALLOWED_ATTR[lcName] || FORBID_ATTR[lcName]) {
                if (// First condition does a very basic check if a) it's basically a valid custom element tagname AND
                // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
                // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
                _isBasicCustomElement(lcTag) && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, lcTag) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(lcTag)) && (CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.attributeNameCheck, lcName) || CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.attributeNameCheck(lcName)) || // Alternative, second condition checks if it's an `is`-attribute, AND
                // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
                lcName === 'is' && CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, value) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(value))) ;
                else {
                    return false;
                }
            /* Check value is safe. First, is attr inert? If so, is safe */ } else if (URI_SAFE_ATTRIBUTES[lcName]) ;
            else if (regExpTest(IS_ALLOWED_URI$1, stringReplace(value, ATTR_WHITESPACE, ''))) ;
            else if ((lcName === 'src' || lcName === 'xlink:href' || lcName === 'href') && lcTag !== 'script' && stringIndexOf(value, 'data:') === 0 && DATA_URI_TAGS[lcTag]) ;
            else if (ALLOW_UNKNOWN_PROTOCOLS && !regExpTest(IS_SCRIPT_OR_DATA, stringReplace(value, ATTR_WHITESPACE, ''))) ;
            else if (value) {
                return false;
            } else ;
            return true;
        };
        /**
     * _isBasicCustomElement
     * checks if at least one dash is included in tagName, and it's not the first char
     * for more sophisticated checking see https://github.com/sindresorhus/validate-element-name
     *
     * @param {string} tagName name of the tag of the node to sanitize
     * @returns {boolean} Returns true if the tag name meets the basic criteria for a custom element, otherwise false.
     */ const _isBasicCustomElement = function _isBasicCustomElement(tagName) {
            return tagName !== 'annotation-xml' && stringMatch(tagName, CUSTOM_ELEMENT);
        };
        /**
     * _sanitizeAttributes
     *
     * @protect attributes
     * @protect nodeName
     * @protect removeAttribute
     * @protect setAttribute
     *
     * @param  {Node} currentNode to sanitize
     */ const _sanitizeAttributes = function _sanitizeAttributes(currentNode) {
            /* Execute a hook if present */ _executeHook('beforeSanitizeAttributes', currentNode, null);
            const { attributes } = currentNode;
            /* Check if we have attributes; if not we might have a text node */ if (!attributes) {
                return;
            }
            const hookEvent = {
                attrName: '',
                attrValue: '',
                keepAttr: true,
                allowedAttributes: ALLOWED_ATTR
            };
            let l = attributes.length;
            /* Go backwards over all attributes; safely remove bad ones */ while(l--){
                const attr = attributes[l];
                const { name, namespaceURI, value: attrValue } = attr;
                const lcName = transformCaseFunc(name);
                let value = name === 'value' ? attrValue : stringTrim(attrValue);
                /* Execute a hook if present */ hookEvent.attrName = lcName;
                hookEvent.attrValue = value;
                hookEvent.keepAttr = true;
                hookEvent.forceKeepAttr = undefined; // Allows developers to see this is a property they can set
                _executeHook('uponSanitizeAttribute', currentNode, hookEvent);
                value = hookEvent.attrValue;
                /* Work around a security issue with comments inside attributes */ if (SAFE_FOR_XML && regExpTest(/((--!?|])>)|<\/(style|title)/i, value)) {
                    _removeAttribute(name, currentNode);
                    continue;
                }
                /* Did the hooks approve of the attribute? */ if (hookEvent.forceKeepAttr) {
                    continue;
                }
                /* Remove attribute */ _removeAttribute(name, currentNode);
                /* Did the hooks approve of the attribute? */ if (!hookEvent.keepAttr) {
                    continue;
                }
                /* Work around a security issue in jQuery 3.0 */ if (!ALLOW_SELF_CLOSE_IN_ATTR && regExpTest(/\/>/i, value)) {
                    _removeAttribute(name, currentNode);
                    continue;
                }
                /* Sanitize attribute content to be template-safe */ if (SAFE_FOR_TEMPLATES) {
                    arrayForEach([
                        MUSTACHE_EXPR,
                        ERB_EXPR,
                        TMPLIT_EXPR
                    ], (expr)=>{
                        value = stringReplace(value, expr, ' ');
                    });
                }
                /* Is `value` valid for this attribute? */ const lcTag = transformCaseFunc(currentNode.nodeName);
                if (!_isValidAttribute(lcTag, lcName, value)) {
                    continue;
                }
                /* Full DOM Clobbering protection via namespace isolation,
         * Prefix id and name attributes with `user-content-`
         */ if (SANITIZE_NAMED_PROPS && (lcName === 'id' || lcName === 'name')) {
                    // Remove the attribute with this value
                    _removeAttribute(name, currentNode);
                    // Prefix the value and later re-create the attribute with the sanitized value
                    value = SANITIZE_NAMED_PROPS_PREFIX + value;
                }
                /* Handle attributes that require Trusted Types */ if (trustedTypesPolicy && typeof trustedTypes === 'object' && typeof trustedTypes.getAttributeType === 'function') {
                    if (namespaceURI) ;
                    else {
                        switch(trustedTypes.getAttributeType(lcTag, lcName)){
                            case 'TrustedHTML':
                                {
                                    value = trustedTypesPolicy.createHTML(value);
                                    break;
                                }
                            case 'TrustedScriptURL':
                                {
                                    value = trustedTypesPolicy.createScriptURL(value);
                                    break;
                                }
                        }
                    }
                }
                /* Handle invalid data-* attribute set by try-catching it */ try {
                    if (namespaceURI) {
                        currentNode.setAttributeNS(namespaceURI, name, value);
                    } else {
                        /* Fallback to setAttribute() for browser-unrecognized namespaces e.g. "x-schema". */ currentNode.setAttribute(name, value);
                    }
                    if (_isClobbered(currentNode)) {
                        _forceRemove(currentNode);
                    } else {
                        arrayPop(DOMPurify.removed);
                    }
                } catch (_) {}
            }
            /* Execute a hook if present */ _executeHook('afterSanitizeAttributes', currentNode, null);
        };
        /**
     * _sanitizeShadowDOM
     *
     * @param  {DocumentFragment} fragment to iterate over recursively
     */ const _sanitizeShadowDOM = function _sanitizeShadowDOM(fragment) {
            let shadowNode = null;
            const shadowIterator = _createNodeIterator(fragment);
            /* Execute a hook if present */ _executeHook('beforeSanitizeShadowDOM', fragment, null);
            while(shadowNode = shadowIterator.nextNode()){
                /* Execute a hook if present */ _executeHook('uponSanitizeShadowNode', shadowNode, null);
                /* Sanitize tags and elements */ if (_sanitizeElements(shadowNode)) {
                    continue;
                }
                /* Deep shadow DOM detected */ if (shadowNode.content instanceof DocumentFragment) {
                    _sanitizeShadowDOM(shadowNode.content);
                }
                /* Check attributes, sanitize if necessary */ _sanitizeAttributes(shadowNode);
            }
            /* Execute a hook if present */ _executeHook('afterSanitizeShadowDOM', fragment, null);
        };
        /**
     * Sanitize
     * Public method providing core sanitation functionality
     *
     * @param {String|Node} dirty string or DOM node
     * @param {Object} cfg object
     */ // eslint-disable-next-line complexity
        DOMPurify.sanitize = function(dirty) {
            let cfg = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            let body = null;
            let importedNode = null;
            let currentNode = null;
            let returnNode = null;
            /* Make sure we have a string to sanitize.
        DO NOT return early, as this will return the wrong type if
        the user has requested a DOM object rather than a string */ IS_EMPTY_INPUT = !dirty;
            if (IS_EMPTY_INPUT) {
                dirty = '<!-->';
            }
            /* Stringify, in case dirty is an object */ if (typeof dirty !== 'string' && !_isNode(dirty)) {
                if (typeof dirty.toString === 'function') {
                    dirty = dirty.toString();
                    if (typeof dirty !== 'string') {
                        throw typeErrorCreate('dirty is not a string, aborting');
                    }
                } else {
                    throw typeErrorCreate('toString is not a function');
                }
            }
            /* Return dirty HTML if DOMPurify cannot run */ if (!DOMPurify.isSupported) {
                return dirty;
            }
            /* Assign config vars */ if (!SET_CONFIG) {
                _parseConfig(cfg);
            }
            /* Clean up removed elements */ DOMPurify.removed = [];
            /* Check if dirty is correctly typed for IN_PLACE */ if (typeof dirty === 'string') {
                IN_PLACE = false;
            }
            if (IN_PLACE) {
                /* Do some early pre-sanitization to avoid unsafe root nodes */ if (dirty.nodeName) {
                    const tagName = transformCaseFunc(dirty.nodeName);
                    if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) {
                        throw typeErrorCreate('root node is forbidden and cannot be sanitized in-place');
                    }
                }
            } else if (dirty instanceof Node) {
                /* If dirty is a DOM element, append to an empty document to avoid
           elements being stripped by the parser */ body = _initDocument('<!---->');
                importedNode = body.ownerDocument.importNode(dirty, true);
                if (importedNode.nodeType === NODE_TYPE.element && importedNode.nodeName === 'BODY') {
                    /* Node is already a body, use as is */ body = importedNode;
                } else if (importedNode.nodeName === 'HTML') {
                    body = importedNode;
                } else {
                    // eslint-disable-next-line unicorn/prefer-dom-node-append
                    body.appendChild(importedNode);
                }
            } else {
                /* Exit directly if we have nothing to do */ if (!RETURN_DOM && !SAFE_FOR_TEMPLATES && !WHOLE_DOCUMENT && // eslint-disable-next-line unicorn/prefer-includes
                dirty.indexOf('<') === -1) {
                    return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? trustedTypesPolicy.createHTML(dirty) : dirty;
                }
                /* Initialize the document to work on */ body = _initDocument(dirty);
                /* Check we have a DOM node from the data */ if (!body) {
                    return RETURN_DOM ? null : RETURN_TRUSTED_TYPE ? emptyHTML : '';
                }
            }
            /* Remove first element node (ours) if FORCE_BODY is set */ if (body && FORCE_BODY) {
                _forceRemove(body.firstChild);
            }
            /* Get node iterator */ const nodeIterator = _createNodeIterator(IN_PLACE ? dirty : body);
            /* Now start iterating over the created document */ while(currentNode = nodeIterator.nextNode()){
                /* Sanitize tags and elements */ if (_sanitizeElements(currentNode)) {
                    continue;
                }
                /* Shadow DOM detected, sanitize it */ if (currentNode.content instanceof DocumentFragment) {
                    _sanitizeShadowDOM(currentNode.content);
                }
                /* Check attributes, sanitize if necessary */ _sanitizeAttributes(currentNode);
            }
            /* If we sanitized `dirty` in-place, return it. */ if (IN_PLACE) {
                return dirty;
            }
            /* Return sanitized string or DOM */ if (RETURN_DOM) {
                if (RETURN_DOM_FRAGMENT) {
                    returnNode = createDocumentFragment.call(body.ownerDocument);
                    while(body.firstChild){
                        // eslint-disable-next-line unicorn/prefer-dom-node-append
                        returnNode.appendChild(body.firstChild);
                    }
                } else {
                    returnNode = body;
                }
                if (ALLOWED_ATTR.shadowroot || ALLOWED_ATTR.shadowrootmode) {
                    /*
            AdoptNode() is not used because internal state is not reset
            (e.g. the past names map of a HTMLFormElement), this is safe
            in theory but we would rather not risk another attack vector.
            The state that is cloned by importNode() is explicitly defined
            by the specs.
          */ returnNode = importNode.call(originalDocument, returnNode, true);
                }
                return returnNode;
            }
            let serializedHTML = WHOLE_DOCUMENT ? body.outerHTML : body.innerHTML;
            /* Serialize doctype if allowed */ if (WHOLE_DOCUMENT && ALLOWED_TAGS['!doctype'] && body.ownerDocument && body.ownerDocument.doctype && body.ownerDocument.doctype.name && regExpTest(DOCTYPE_NAME, body.ownerDocument.doctype.name)) {
                serializedHTML = '<!DOCTYPE ' + body.ownerDocument.doctype.name + '>\n' + serializedHTML;
            }
            /* Sanitize final string template-safe */ if (SAFE_FOR_TEMPLATES) {
                arrayForEach([
                    MUSTACHE_EXPR,
                    ERB_EXPR,
                    TMPLIT_EXPR
                ], (expr)=>{
                    serializedHTML = stringReplace(serializedHTML, expr, ' ');
                });
            }
            return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? trustedTypesPolicy.createHTML(serializedHTML) : serializedHTML;
        };
        /**
     * Public method to set the configuration once
     * setConfig
     *
     * @param {Object} cfg configuration object
     */ DOMPurify.setConfig = function() {
            let cfg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            _parseConfig(cfg);
            SET_CONFIG = true;
        };
        /**
     * Public method to remove the configuration
     * clearConfig
     *
     */ DOMPurify.clearConfig = function() {
            CONFIG = null;
            SET_CONFIG = false;
        };
        /**
     * Public method to check if an attribute value is valid.
     * Uses last set config, if any. Otherwise, uses config defaults.
     * isValidAttribute
     *
     * @param  {String} tag Tag name of containing element.
     * @param  {String} attr Attribute name.
     * @param  {String} value Attribute value.
     * @return {Boolean} Returns true if `value` is valid. Otherwise, returns false.
     */ DOMPurify.isValidAttribute = function(tag, attr, value) {
            /* Initialize shared config vars if necessary. */ if (!CONFIG) {
                _parseConfig({});
            }
            const lcTag = transformCaseFunc(tag);
            const lcName = transformCaseFunc(attr);
            return _isValidAttribute(lcTag, lcName, value);
        };
        /**
     * AddHook
     * Public method to add DOMPurify hooks
     *
     * @param {String} entryPoint entry point for the hook to add
     * @param {Function} hookFunction function to execute
     */ DOMPurify.addHook = function(entryPoint, hookFunction) {
            if (typeof hookFunction !== 'function') {
                return;
            }
            hooks[entryPoint] = hooks[entryPoint] || [];
            arrayPush(hooks[entryPoint], hookFunction);
        };
        /**
     * RemoveHook
     * Public method to remove a DOMPurify hook at a given entryPoint
     * (pops it from the stack of hooks if more are present)
     *
     * @param {String} entryPoint entry point for the hook to remove
     * @return {Function} removed(popped) hook
     */ DOMPurify.removeHook = function(entryPoint) {
            if (hooks[entryPoint]) {
                return arrayPop(hooks[entryPoint]);
            }
        };
        /**
     * RemoveHooks
     * Public method to remove all DOMPurify hooks at a given entryPoint
     *
     * @param  {String} entryPoint entry point for the hooks to remove
     */ DOMPurify.removeHooks = function(entryPoint) {
            if (hooks[entryPoint]) {
                hooks[entryPoint] = [];
            }
        };
        /**
     * RemoveAllHooks
     * Public method to remove all DOMPurify hooks
     */ DOMPurify.removeAllHooks = function() {
            hooks = {};
        };
        return DOMPurify;
    }
    var purify = createDOMPurify();
    return purify;
});
}),
"[project]/node_modules/@mui/icons-material/esm/Assignment.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M19 3h-4.18C14.4 1.84 13.3 1 12 1s-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2m-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1m2 14H7v-2h7zm3-4H7v-2h10zm0-4H7V7h10z"
}), 'Assignment');
}),
"[project]/node_modules/@mui/icons-material/esm/QuestionMarkOutlined.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M11.07 12.85c.77-1.39 2.25-2.21 3.11-3.44.91-1.29.4-3.7-2.18-3.7-1.69 0-2.52 1.28-2.87 2.34L6.54 6.96C7.25 4.83 9.18 3 11.99 3c2.35 0 3.96 1.07 4.78 2.41.7 1.15 1.11 3.3.03 4.9-1.2 1.77-2.35 2.31-2.97 3.45-.25.46-.35.76-.35 2.24h-2.89c-.01-.78-.13-2.05.48-3.15M14 20c0 1.1-.9 2-2 2s-2-.9-2-2 .9-2 2-2 2 .9 2 2"
}), 'QuestionMarkOutlined');
}),
"[project]/node_modules/@mui/icons-material/esm/Camera.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "m9.4 10.5 4.77-8.26C13.47 2.09 12.75 2 12 2c-2.4 0-4.6.85-6.32 2.25l3.66 6.35zM21.54 9c-.92-2.92-3.15-5.26-6-6.34L11.88 9zm.26 1h-7.49l.29.5 4.76 8.25C21 16.97 22 14.61 22 12c0-.69-.07-1.35-.2-2M8.54 12l-3.9-6.75C3.01 7.03 2 9.39 2 12c0 .69.07 1.35.2 2h7.49zm-6.08 3c.92 2.92 3.15 5.26 6 6.34L12.12 15zm11.27 0-3.9 6.76c.7.15 1.42.24 2.17.24 2.4 0 4.6-.85 6.32-2.25l-3.66-6.35z"
}), 'Camera');
}),
"[project]/node_modules/@mui/material/esm/Autocomplete/Autocomplete.js [app-client] (ecmascript) <locals> <export default as Autocomplete>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Autocomplete",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Autocomplete/Autocomplete.js [app-client] (ecmascript) <locals>");
}),
"[project]/node_modules/@mui/material/esm/FormHelperText/FormHelperText.js [app-client] (ecmascript) <export default as FormHelperText>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FormHelperText",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormHelperText$2f$FormHelperText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormHelperText$2f$FormHelperText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormHelperText/FormHelperText.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@mui/material/esm/ListItemSecondaryAction/ListItemSecondaryAction.js [app-client] (ecmascript) <export default as ListItemSecondaryAction>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ListItemSecondaryAction",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemSecondaryAction$2f$ListItemSecondaryAction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemSecondaryAction$2f$ListItemSecondaryAction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemSecondaryAction/ListItemSecondaryAction.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@mui/icons-material/esm/KeyboardArrowUp.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M7.41 15.41 12 10.83l4.59 4.58L18 14l-6-6-6 6z"
}), 'KeyboardArrowUp');
}),
"[project]/node_modules/@mui/icons-material/esm/KeyboardArrowDown.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z"
}), 'KeyboardArrowDown');
}),
"[project]/node_modules/@mui/icons-material/esm/Assessment.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2M9 17H7v-7h2zm4 0h-2V7h2zm4 0h-2v-4h2z"
}), 'Assessment');
}),
"[project]/node_modules/@mui/icons-material/esm/Forum.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M21 6h-2v9H6v2c0 .55.45 1 1 1h11l4 4V7c0-.55-.45-1-1-1m-4 6V3c0-.55-.45-1-1-1H3c-.55 0-1 .45-1 1v14l4-4h10c.55 0 1-.45 1-1"
}), 'Forum');
}),
"[project]/node_modules/@mui/icons-material/esm/Preview.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.89-2-2-2m0 16H5V7h14zm-5.5-6c0 .83-.67 1.5-1.5 1.5s-1.5-.67-1.5-1.5.67-1.5 1.5-1.5 1.5.67 1.5 1.5M12 9c-2.73 0-5.06 1.66-6 4 .94 2.34 3.27 4 6 4s5.06-1.66 6-4c-.94-2.34-3.27-4-6-4m0 6.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5"
}), 'Preview');
}),
"[project]/node_modules/@mui/icons-material/esm/Subject.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M14 17H4v2h10zm6-8H4v2h16zM4 15h16v-2H4zM4 5v2h16V5z"
}), 'Subject');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatListBulleted.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M4 10.5c-.83 0-1.5.67-1.5 1.5s.67 1.5 1.5 1.5 1.5-.67 1.5-1.5-.67-1.5-1.5-1.5m0-6c-.83 0-1.5.67-1.5 1.5S3.17 7.5 4 7.5 5.5 6.83 5.5 6 4.83 4.5 4 4.5m0 12c-.83 0-1.5.68-1.5 1.5s.68 1.5 1.5 1.5 1.5-.68 1.5-1.5-.67-1.5-1.5-1.5M7 19h14v-2H7zm0-6h14v-2H7zm0-8v2h14V5z"
}), 'FormatListBulleted');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatListNumbered.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M2 17h2v.5H3v1h1v.5H2v1h3v-4H2zm1-9h1V4H2v1h1zm-1 3h1.8L2 13.1v.9h3v-1H3.2L5 10.9V10H2zm5-6v2h14V5zm0 14h14v-2H7zm0-6h14v-2H7z"
}), 'FormatListNumbered');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatQuote.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M6 17h3l2-4V7H5v6h3zm8 0h3l2-4V7h-6v6h3z"
}), 'FormatQuote');
}),
"[project]/node_modules/@mui/icons-material/esm/Code.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M9.4 16.6 4.8 12l4.6-4.6L8 6l-6 6 6 6zm5.2 0 4.6-4.6-4.6-4.6L16 6l6 6-6 6z"
}), 'Code');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatBold.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M15.6 10.79c.97-.67 1.65-1.77 1.65-2.79 0-2.26-1.75-4-4-4H7v14h7.04c2.09 0 3.71-1.7 3.71-3.79 0-1.52-.86-2.82-2.15-3.42M10 6.5h3c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5h-3zm3.5 9H10v-3h3.5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5"
}), 'FormatBold');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatItalic.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M10 4v3h2.21l-3.42 8H6v3h8v-3h-2.21l3.42-8H18V4z"
}), 'FormatItalic');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatUnderlined.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M12 17c3.31 0 6-2.69 6-6V3h-2.5v8c0 1.93-1.57 3.5-3.5 3.5S8.5 12.93 8.5 11V3H6v8c0 3.31 2.69 6 6 6m-7 2v2h14v-2z"
}), 'FormatUnderlined');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatStrikethrough.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M10 19h4v-3h-4zM5 4v3h5v3h4V7h5V4zM3 14h18v-2H3z"
}), 'FormatStrikethrough');
}),
"[project]/node_modules/@mui/icons-material/esm/AddLink.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M8 11h8v2H8zm12.1 1H22c0-2.76-2.24-5-5-5h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1M19 12h-2v3h-3v2h3v3h2v-3h3v-2h-3z"
}), 'AddLink');
}),
"[project]/node_modules/@mui/icons-material/esm/Subscript.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M22 18h-2v1h3v1h-4v-2c0-.55.45-1 1-1h2v-1h-3v-1h3c.55 0 1 .45 1 1v1c0 .55-.45 1-1 1M5.88 18h2.66l3.4-5.42h.12l3.4 5.42h2.66l-4.65-7.27L17.81 4h-2.68l-3.07 4.99h-.12L8.85 4H6.19l4.32 6.73z"
}), 'Subscript');
}),
"[project]/node_modules/@mui/icons-material/esm/Superscript.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M22 7h-2v1h3v1h-4V7c0-.55.45-1 1-1h2V5h-3V4h3c.55 0 1 .45 1 1v1c0 .55-.45 1-1 1M5.88 20h2.66l3.4-5.42h.12l3.4 5.42h2.66l-4.65-7.27L17.81 6h-2.68l-3.07 4.99h-.12L8.85 6H6.19l4.32 6.73z"
}), 'Superscript');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatClear.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M3.27 5 2 6.27l6.97 6.97L6.5 19h3l1.57-3.66L16.73 21 18 19.73 3.55 5.27zM6 5v.18L8.82 8h2.4l-.72 1.68 2.1 2.1L14.21 8H20V5z"
}), 'FormatClear');
}),
"[project]/node_modules/@mui/icons-material/esm/Audiotrack.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M12 3v9.28c-.47-.17-.97-.28-1.5-.28C8.01 12 6 14.01 6 16.5S8.01 21 10.5 21c2.31 0 4.2-1.75 4.45-4H15V6h4V3z"
}), 'Audiotrack');
}),
"[project]/node_modules/@mui/icons-material/esm/FlipToFront.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M3 13h2v-2H3zm0 4h2v-2H3zm2 4v-2H3c0 1.1.89 2 2 2M3 9h2V7H3zm12 12h2v-2h-2zm4-18H9c-1.11 0-2 .9-2 2v10c0 1.1.89 2 2 2h10c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2m0 12H9V5h10zm-8 6h2v-2h-2zm-4 0h2v-2H7z"
}), 'FlipToFront');
}),
"[project]/node_modules/@mui/icons-material/esm/ViewColumn.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M14.67 5v14H9.33V5zm1 14H21V5h-5.33zm-7.34 0V5H3v14z"
}), 'ViewColumn');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatSize.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M9 4v3h5v12h3V7h5V4zm-6 8h3v7h3v-7h3V9H3z"
}), 'FormatSize');
}),
"[project]/node_modules/@mui/icons-material/esm/FontDownload.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M9.93 13.5h4.14L12 7.98zM20 2H4c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2m-4.05 16.5-1.14-3H9.17l-1.12 3H5.96l5.11-13h1.86l5.11 13z"
}), 'FontDownload');
}),
"[project]/node_modules/@mui/icons-material/esm/ArrowDropUp.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "m7 14 5-5 5 5z"
}), 'ArrowDropUp');
}),
"[project]/node_modules/@mui/icons-material/esm/ArrowDropDown.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "m7 10 5 5 5-5z"
}), 'ArrowDropDown');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatAlignCenter.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M7 15v2h10v-2zm-4 6h18v-2H3zm0-8h18v-2H3zm4-6v2h10V7zM3 3v2h18V3z"
}), 'FormatAlignCenter');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatAlignLeft.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M15 15H3v2h12zm0-8H3v2h12zM3 13h18v-2H3zm0 8h18v-2H3zM3 3v2h18V3z"
}), 'FormatAlignLeft');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatAlignRight.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M3 21h18v-2H3zm6-4h12v-2H9zm-6-4h18v-2H3zm6-4h12V7H9zM3 3v2h18V3z"
}), 'FormatAlignRight');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatAlignJustify.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M3 21h18v-2H3zm0-4h18v-2H3zm0-4h18v-2H3zm0-4h18V7H3zm0-6v2h18V3z"
}), 'FormatAlignJustify');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatIndentDecrease.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M11 17h10v-2H11zm-8-5 4 4V8zm0 9h18v-2H3zM3 3v2h18V3zm8 6h10V7H11zm0 4h10v-2H11z"
}), 'FormatIndentDecrease');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatIndentIncrease.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M3 21h18v-2H3zM3 8v8l4-4zm8 9h10v-2H11zM3 3v2h18V3zm8 6h10V7H11zm0 4h10v-2H11z"
}), 'FormatIndentIncrease');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatColorFill.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M16.56 8.94 7.62 0 6.21 1.41l2.38 2.38-5.15 5.15c-.59.59-.59 1.54 0 2.12l5.5 5.5c.29.29.68.44 1.06.44s.77-.15 1.06-.44l5.5-5.5c.59-.58.59-1.53 0-2.12M5.21 10 10 5.21 14.79 10zM19 11.5s-2 2.17-2 3.5c0 1.1.9 2 2 2s2-.9 2-2c0-1.33-2-3.5-2-3.5M2 20h20v4H2z"
}), 'FormatColorFill');
}),
"[project]/node_modules/@mui/icons-material/esm/FormatColorText.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M2 20h20v4H2zm3.49-3h2.42l1.27-3.58h5.65L16.09 17h2.42L13.25 3h-2.5zm4.42-5.61 2.03-5.79h.12l2.03 5.79z"
}), 'FormatColorText');
}),
"[project]/node_modules/@mui/icons-material/esm/HorizontalRule.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    fillRule: "evenodd",
    d: "M4 11h16v2H4z"
}), 'HorizontalRule');
}),
"[project]/node_modules/@mui/icons-material/esm/CalendarToday.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M20 3h-1V1h-2v2H7V1H5v2H4c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2m0 18H4V8h16z"
}), 'CalendarToday');
}),
"[project]/node_modules/@mui/icons-material/esm/TableView.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M19 7H9c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2m0 2v2H9V9zm-6 6v-2h2v2zm2 2v2h-2v-2zm-4-2H9v-2h2zm6-2h2v2h-2zm-8 4h2v2H9zm8 2v-2h2v2zM6 17H5c-1.1 0-2-.9-2-2V5c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2v1h-2V5H5v10h1z"
}), 'TableView');
}),
"[project]/node_modules/next/dist/pages/_app.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return App;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/next/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _utils = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/utils.js [app-client] (ecmascript)");
/**
 * `App` component is used for initialize of pages. It allows for overwriting and full control of the `page` initialization.
 * This allows for keeping state between navigation, custom error handling, injecting additional data.
 */ async function appGetInitialProps({ Component, ctx }) {
    const pageProps = await (0, _utils.loadGetInitialProps)(Component, ctx);
    return {
        pageProps
    };
}
class App extends _react.default.Component {
    static{
        this.origGetInitialProps = appGetInitialProps;
    }
    static{
        this.getInitialProps = appGetInitialProps;
    }
    render() {
        const { Component, pageProps } = this.props;
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(Component, {
            ...pageProps
        });
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/app.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/pages/_app.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@mui/icons-material/esm/YouTube.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-1.3.07-2.49.1-3.59.1L12 19c-4.19 0-6.8-.16-7.83-.44-.9-.25-1.48-.83-1.73-1.73-.13-.47-.22-1.1-.28-1.9-.07-.8-.1-1.49-.1-2.09L2 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73-1.73.47-.13 1.33-.22 2.65-.28 1.3-.07 2.49-.1 3.59-.1L12 5c4.19 0 6.8.16 7.83.44.9.25 1.48.83 1.73 1.73z"
}), 'YouTube');
}),
"[project]/node_modules/@lexical/react/LexicalAutoLinkPlugin.dev.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AutoLinkPlugin",
    ()=>AutoLinkPlugin
]);
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$link$2f$LexicalLink$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/link/LexicalLink.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ // Do not require this module directly! Use normal `invariant` calls.
function formatDevErrorMessage(message) {
    throw new Error(message);
}
function useAutoLink(editor, matchers, onChange) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAutoLink.useEffect": ()=>{
            if (!editor.hasNodes([
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$link$2f$LexicalLink$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AutoLinkNode"]
            ])) {
                {
                    formatDevErrorMessage(`LexicalAutoLinkPlugin: AutoLinkNode not registered on editor`);
                }
            }
        }
    }["useAutoLink.useEffect"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAutoLink.useEffect": ()=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$link$2f$LexicalLink$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerAutoLink"])(editor, {
                changeHandlers: onChange ? [
                    onChange
                ] : [],
                matchers
            });
        }
    }["useAutoLink.useEffect"], [
        editor,
        matchers,
        onChange
    ]);
}
function AutoLinkPlugin({ matchers, onChange }) {
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    useAutoLink(editor, matchers, onChange);
    return null;
}
;
}),
"[project]/node_modules/@lexical/react/LexicalCollaborationContext.dev.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CollaborationContext",
    ()=>CollaborationContext,
    "LexicalCollaboration",
    ()=>LexicalCollaboration,
    "useCollaborationContext",
    ()=>useCollaborationContext
]);
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ // Do not require this module directly! Use normal `invariant` calls.
function formatDevErrorMessage(message) {
    throw new Error(message);
}
const entries = [
    [
        'Cat',
        'rgb(125, 50, 0)'
    ],
    [
        'Dog',
        'rgb(100, 0, 0)'
    ],
    [
        'Rabbit',
        'rgb(150, 0, 0)'
    ],
    [
        'Frog',
        'rgb(200, 0, 0)'
    ],
    [
        'Fox',
        'rgb(200, 75, 0)'
    ],
    [
        'Hedgehog',
        'rgb(0, 75, 0)'
    ],
    [
        'Pigeon',
        'rgb(0, 125, 0)'
    ],
    [
        'Squirrel',
        'rgb(75, 100, 0)'
    ],
    [
        'Bear',
        'rgb(125, 100, 0)'
    ],
    [
        'Tiger',
        'rgb(0, 0, 150)'
    ],
    [
        'Leopard',
        'rgb(0, 0, 200)'
    ],
    [
        'Zebra',
        'rgb(0, 0, 250)'
    ],
    [
        'Wolf',
        'rgb(0, 100, 150)'
    ],
    [
        'Owl',
        'rgb(0, 100, 100)'
    ],
    [
        'Gull',
        'rgb(100, 0, 100)'
    ],
    [
        'Squid',
        'rgb(150, 0, 150)'
    ]
];
const randomEntry = entries[Math.floor(Math.random() * entries.length)];
const CollaborationContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function newContext() {
    return {
        color: randomEntry[1],
        isCollabActive: false,
        name: randomEntry[0],
        yjsDocMap: new Map()
    };
}
// This is here to help the transition post-#7818, however should be removed in a future release as
// a shared context across editors is likely to lead to bugs.
const UNSAFE_GLOBAL_CONTEXT = newContext();
function LexicalCollaboration({ children }) {
    const collabContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "LexicalCollaboration.useMemo[collabContext]": ()=>newContext()
    }["LexicalCollaboration.useMemo[collabContext]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(CollaborationContext.Provider, {
        value: collabContext,
        children: children
    });
}
function useCollaborationContext(username, color) {
    let collabContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(CollaborationContext);
    if (!(collabContext != null)) {
        formatDevErrorMessage(`useCollaborationContext: no context provider found`);
    }
    collabContext = collabContext ?? UNSAFE_GLOBAL_CONTEXT;
    if (username != null) {
        collabContext.name = username;
    }
    if (color != null) {
        collabContext.color = color;
    }
    return collabContext;
}
;
}),
"[project]/node_modules/@lexical/react/node_modules/@lexical/offset/LexicalOffset.dev.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createChildrenArray",
    ()=>$createChildrenArray,
    "$createOffsetView",
    ()=>$createOffsetView,
    "OffsetView",
    ()=>OffsetView,
    "createChildrenArray",
    ()=>createChildrenArray
]);
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
;
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ // Do not require this module directly! Use normal `invariant` calls.
function formatDevErrorMessage(message) {
    throw new Error(message);
}
class OffsetView {
    _offsetMap;
    _firstNode;
    _blockOffsetSize;
    constructor(offsetMap, firstNode, blockOffsetSize = 1){
        this._offsetMap = offsetMap;
        this._firstNode = firstNode;
        this._blockOffsetSize = blockOffsetSize;
    }
    createSelectionFromOffsets(originalStart, originalEnd, diffOffsetView) {
        const firstNode = this._firstNode;
        if (firstNode === null) {
            return null;
        }
        let start = originalStart;
        let end = originalEnd;
        let startOffsetNode = $searchForNodeWithOffset(firstNode, start, this._blockOffsetSize);
        let endOffsetNode = $searchForNodeWithOffset(firstNode, end, this._blockOffsetSize);
        if (diffOffsetView !== undefined) {
            start = $getAdjustedOffsetFromDiff(start, startOffsetNode, diffOffsetView, this, this._blockOffsetSize);
            startOffsetNode = $searchForNodeWithOffset(firstNode, start, this._blockOffsetSize);
            end = $getAdjustedOffsetFromDiff(end, endOffsetNode, diffOffsetView, this, this._blockOffsetSize);
            endOffsetNode = $searchForNodeWithOffset(firstNode, end, this._blockOffsetSize);
        }
        if (startOffsetNode === null || endOffsetNode === null) {
            return null;
        }
        let startKey = startOffsetNode.key;
        let endKey = endOffsetNode.key;
        const startNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(startKey);
        const endNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(endKey);
        if (startNode === null || endNode === null) {
            return null;
        }
        let startOffset = 0;
        let endOffset = 0;
        let startType = 'element';
        let endType = 'element';
        if (startOffsetNode.type === 'text') {
            startOffset = start - startOffsetNode.start;
            startType = 'text';
            // If we are at the edge of a text node and we
            // don't have a collapsed selection, then let's
            // try and correct the offset node.
            const sibling = startNode.getNextSibling();
            if (start !== end && startOffset === startNode.getTextContentSize() && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(sibling)) {
                startOffset = 0;
                startKey = sibling.__key;
            }
        } else if (startOffsetNode.type === 'inline') {
            startKey = startNode.getParentOrThrow().getKey();
            startOffset = end > startOffsetNode.start ? startOffsetNode.end : startOffsetNode.start;
        }
        if (endOffsetNode.type === 'text') {
            endOffset = end - endOffsetNode.start;
            endType = 'text';
        } else if (endOffsetNode.type === 'inline') {
            endKey = endNode.getParentOrThrow().getKey();
            endOffset = end > endOffsetNode.start ? endOffsetNode.end : endOffsetNode.start;
        }
        const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createRangeSelection"])();
        if (selection === null) {
            return null;
        }
        selection.anchor.set(startKey, startOffset, startType);
        selection.focus.set(endKey, endOffset, endType);
        return selection;
    }
    getOffsetsFromSelection(selection) {
        const anchor = selection.anchor;
        const focus = selection.focus;
        const offsetMap = this._offsetMap;
        const anchorOffset = anchor.offset;
        const focusOffset = focus.offset;
        let start = -1;
        let end = -1;
        if (anchor.type === 'text') {
            const offsetNode = offsetMap.get(anchor.key);
            if (offsetNode !== undefined) {
                start = offsetNode.start + anchorOffset;
            }
        } else {
            const node = anchor.getNode().getDescendantByIndex(anchorOffset);
            if (node !== null) {
                const offsetNode = offsetMap.get(node.getKey());
                if (offsetNode !== undefined) {
                    const isAtEnd = node.getIndexWithinParent() !== anchorOffset;
                    start = isAtEnd ? offsetNode.end : offsetNode.start;
                }
            }
        }
        if (focus.type === 'text') {
            const offsetNode = offsetMap.get(focus.key);
            if (offsetNode !== undefined) {
                end = offsetNode.start + focus.offset;
            }
        } else {
            const node = focus.getNode().getDescendantByIndex(focusOffset);
            if (node !== null) {
                const offsetNode = offsetMap.get(node.getKey());
                if (offsetNode !== undefined) {
                    const isAtEnd = node.getIndexWithinParent() !== focusOffset;
                    end = isAtEnd ? offsetNode.end : offsetNode.start;
                }
            }
        }
        return [
            start,
            end
        ];
    }
}
function $getAdjustedOffsetFromDiff(offset, offsetNode, prevOffsetView, offsetView, blockOffsetSize) {
    const prevOffsetMap = prevOffsetView._offsetMap;
    const offsetMap = offsetView._offsetMap;
    const visited = new Set();
    let adjustedOffset = offset;
    let currentNode = offsetNode;
    while(currentNode !== null){
        const key = currentNode.key;
        const prevNode = prevOffsetMap.get(key);
        const diff = currentNode.end - currentNode.start;
        visited.add(key);
        if (prevNode === undefined) {
            adjustedOffset += diff;
        } else {
            const prevDiff = prevNode.end - prevNode.start;
            if (prevDiff !== diff) {
                adjustedOffset += diff - prevDiff;
            }
        }
        const sibling = currentNode.prev;
        if (sibling !== null) {
            currentNode = sibling;
            continue;
        }
        let parent = currentNode.parent;
        while(parent !== null){
            let parentSibling = parent.prev;
            if (parentSibling !== null) {
                const parentSiblingKey = parentSibling.key;
                const prevParentSibling = prevOffsetMap.get(parentSiblingKey);
                const parentDiff = parentSibling.end - parentSibling.start;
                visited.add(parentSiblingKey);
                if (prevParentSibling === undefined) {
                    adjustedOffset += parentDiff;
                } else {
                    const prevParentDiff = prevParentSibling.end - prevParentSibling.start;
                    if (prevParentDiff !== parentDiff) {
                        adjustedOffset += parentDiff - prevParentDiff;
                    }
                }
                parentSibling = parentSibling.prev;
            }
            parent = parent.parent;
        }
        break;
    }
    // Now traverse through the old offsets nodes and find any nodes we missed
    // above, because they were not in the latest offset node view (they have been
    // deleted).
    const prevFirstNode = prevOffsetView._firstNode;
    if (prevFirstNode !== null) {
        currentNode = $searchForNodeWithOffset(prevFirstNode, offset, blockOffsetSize);
        let alreadyVisitedParentOfCurrentNode = false;
        while(currentNode !== null){
            if (!visited.has(currentNode.key)) {
                alreadyVisitedParentOfCurrentNode = true;
                break;
            }
            currentNode = currentNode.parent;
        }
        if (!alreadyVisitedParentOfCurrentNode) {
            while(currentNode !== null){
                const key = currentNode.key;
                if (!visited.has(key)) {
                    const node = offsetMap.get(key);
                    const prevDiff = currentNode.end - currentNode.start;
                    if (node === undefined) {
                        adjustedOffset -= prevDiff;
                    } else {
                        const diff = node.end - node.start;
                        if (prevDiff !== diff) {
                            adjustedOffset += diff - prevDiff;
                        }
                    }
                }
                currentNode = currentNode.prev;
            }
        }
    }
    return adjustedOffset;
}
function $searchForNodeWithOffset(firstNode, offset, blockOffsetSize) {
    let currentNode = firstNode;
    while(currentNode !== null){
        const end = currentNode.end + (currentNode.type !== 'element' || blockOffsetSize === 0 ? 1 : 0);
        if (offset < end) {
            const child = currentNode.child;
            if (child !== null) {
                currentNode = child;
                continue;
            }
            return currentNode;
        }
        const sibling = currentNode.next;
        if (sibling === null) {
            break;
        }
        currentNode = sibling;
    }
    return null;
}
function $createInternalOffsetNode(child, type, start, end, key, parent) {
    return {
        child,
        end,
        key,
        next: null,
        parent,
        prev: null,
        start,
        type
    };
}
function $createOffsetNode(state, key, parent, nodeMap, offsetMap, blockOffsetSize) {
    const node = nodeMap.get(key);
    if (node === undefined) {
        {
            formatDevErrorMessage(`createOffsetModel: could not find node by key`);
        }
    }
    const start = state.offset;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(node)) {
        const childKeys = $createChildrenArray(node, nodeMap);
        const blockIsEmpty = childKeys.length === 0;
        const child = blockIsEmpty ? null : $createOffsetChild(state, childKeys, null, nodeMap, offsetMap, blockOffsetSize);
        // If the prev node was not a block or the block is empty, we should
        // account for the user being able to selection the block (due to the \n).
        if (!state.prevIsBlock || blockIsEmpty) {
            state.prevIsBlock = true;
            state.offset += blockOffsetSize;
        }
        const offsetNode = $createInternalOffsetNode(child, 'element', start, start, key, parent);
        if (child !== null) {
            child.parent = offsetNode;
        }
        const end = state.offset;
        offsetNode.end = end;
        offsetMap.set(key, offsetNode);
        return offsetNode;
    }
    state.prevIsBlock = false;
    const isText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(node);
    const length = isText ? node.__text.length : 1;
    const end = state.offset += length;
    const offsetNode = $createInternalOffsetNode(null, isText ? 'text' : 'inline', start, end, key, parent);
    offsetMap.set(key, offsetNode);
    return offsetNode;
}
function $createOffsetChild(state, children, parent, nodeMap, offsetMap, blockOffsetSize) {
    let firstNode = null;
    let currentNode = null;
    const childrenLength = children.length;
    for(let i = 0; i < childrenLength; i++){
        const childKey = children[i];
        const offsetNode = $createOffsetNode(state, childKey, parent, nodeMap, offsetMap, blockOffsetSize);
        if (currentNode === null) {
            firstNode = offsetNode;
        } else {
            offsetNode.prev = currentNode;
            currentNode.next = offsetNode;
        }
        currentNode = offsetNode;
    }
    return firstNode;
}
function $createChildrenArray(element, nodeMap) {
    const children = [];
    let nodeKey = element.__first;
    while(nodeKey !== null){
        const node = nodeMap === null ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey) : nodeMap.get(nodeKey);
        if (node === null || node === undefined) {
            {
                formatDevErrorMessage(`$createChildrenArray: node does not exist in nodeMap`);
            }
        }
        children.push(nodeKey);
        nodeKey = node.__next;
    }
    return children;
}
/** @deprecated renamed to {@link $createChildrenArray} by @lexical/eslint-plugin rules-of-lexical */ const createChildrenArray = $createChildrenArray;
function $createOffsetView(editor, blockOffsetSize = 1, editorState) {
    const targetEditorState = editorState || editor._pendingEditorState || editor._editorState;
    const nodeMap = targetEditorState._nodeMap;
    const root = nodeMap.get('root');
    const offsetMap = new Map();
    const state = {
        offset: 0,
        prevIsBlock: false
    };
    const node = $createOffsetChild(state, $createChildrenArray(root, nodeMap), null, nodeMap, offsetMap, blockOffsetSize);
    return new OffsetView(offsetMap, node, blockOffsetSize);
}
;
}),
"[project]/node_modules/@lexical/react/node_modules/@lexical/yjs/LexicalYjs.dev.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$getYChangeState",
    ()=>$getYChangeState,
    "CLEAR_DIFF_VERSIONS_COMMAND__EXPERIMENTAL",
    ()=>CLEAR_DIFF_VERSIONS_COMMAND__EXPERIMENTAL,
    "CONNECTED_COMMAND",
    ()=>CONNECTED_COMMAND,
    "DIFF_VERSIONS_COMMAND__EXPERIMENTAL",
    ()=>DIFF_VERSIONS_COMMAND__EXPERIMENTAL,
    "TOGGLE_CONNECT_COMMAND",
    ()=>TOGGLE_CONNECT_COMMAND,
    "createBinding",
    ()=>createBinding,
    "createBindingV2__EXPERIMENTAL",
    ()=>createBindingV2__EXPERIMENTAL,
    "createUndoManager",
    ()=>createUndoManager,
    "getAnchorAndFocusCollabNodesForUserState",
    ()=>getAnchorAndFocusCollabNodesForUserState,
    "initLocalState",
    ()=>initLocalState,
    "renderSnapshot__EXPERIMENTAL",
    ()=>renderSnapshot__EXPERIMENTAL,
    "setLocalStateFocus",
    ()=>setLocalStateFocus,
    "syncCursorPositions",
    ()=>syncCursorPositions,
    "syncLexicalUpdateToYjs",
    ()=>syncLexicalUpdateToYjs,
    "syncLexicalUpdateToYjsV2__EXPERIMENTAL",
    ()=>syncLexicalUpdateToYjsV2__EXPERIMENTAL,
    "syncYjsChangesToLexical",
    ()=>syncYjsChangesToLexical,
    "syncYjsChangesToLexicalV2__EXPERIMENTAL",
    ()=>syncYjsChangesToLexicalV2__EXPERIMENTAL,
    "syncYjsStateToLexicalV2__EXPERIMENTAL",
    ()=>syncYjsStateToLexicalV2__EXPERIMENTAL
]);
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/yjs/dist/yjs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$offset$2f$LexicalOffset$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/node_modules/@lexical/offset/LexicalOffset.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/selection/LexicalSelection.dev.mjs [app-client] (ecmascript) <locals>");
;
;
;
;
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ // Do not require this module directly! Use normal `invariant` calls.
function formatDevErrorMessage(message) {
    throw new Error(message);
}
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ function simpleDiffWithCursor(a, b, cursor) {
    const aLength = a.length;
    const bLength = b.length;
    let left = 0; // number of same characters counting from left
    let right = 0; // number of same characters counting from right
    // Iterate left to the right until we find a changed character
    // First iteration considers the current cursor position
    while(left < aLength && left < bLength && a[left] === b[left] && left < cursor){
        left++;
    }
    // Iterate right to the left until we find a changed character
    while(right + left < aLength && right + left < bLength && a[aLength - right - 1] === b[bLength - right - 1]){
        right++;
    }
    // Try to iterate left further to the right without caring about the current cursor position
    while(right + left < aLength && right + left < bLength && a[left] === b[left]){
        left++;
    }
    return {
        index: left,
        insert: b.slice(left, bLength - right),
        remove: aLength - left - right
    };
}
class CollabDecoratorNode {
    _xmlElem;
    _key;
    _parent;
    _type;
    constructor(xmlElem, parent, type){
        this._key = '';
        this._xmlElem = xmlElem;
        this._parent = parent;
        this._type = type;
    }
    getPrevNode(nodeMap) {
        if (nodeMap === null) {
            return null;
        }
        const node = nodeMap.get(this._key);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorNode"])(node) ? node : null;
    }
    getNode() {
        const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(this._key);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorNode"])(node) ? node : null;
    }
    getSharedType() {
        return this._xmlElem;
    }
    getType() {
        return this._type;
    }
    getKey() {
        return this._key;
    }
    getSize() {
        return 1;
    }
    getOffset() {
        const collabElementNode = this._parent;
        return collabElementNode.getChildOffset(this);
    }
    syncPropertiesFromLexical(binding, nextLexicalNode, prevNodeMap) {
        const prevLexicalNode = this.getPrevNode(prevNodeMap);
        const xmlElem = this._xmlElem;
        syncPropertiesFromLexical(binding, xmlElem, prevLexicalNode, nextLexicalNode);
    }
    syncPropertiesFromYjs(binding, keysChanged) {
        const lexicalNode = this.getNode();
        if (!(lexicalNode !== null)) {
            formatDevErrorMessage(`syncPropertiesFromYjs: could not find decorator node`);
        }
        const xmlElem = this._xmlElem;
        $syncPropertiesFromYjs(binding, xmlElem, lexicalNode, keysChanged);
    }
    destroy(binding) {
        const collabNodeMap = binding.collabNodeMap;
        if (collabNodeMap.get(this._key) === this) {
            collabNodeMap.delete(this._key);
        }
    }
}
function $createCollabDecoratorNode(xmlElem, parent, type) {
    const collabNode = new CollabDecoratorNode(xmlElem, parent, type);
    xmlElem._collabNode = collabNode;
    return collabNode;
}
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ class CollabLineBreakNode {
    _map;
    _key;
    _parent;
    _type;
    constructor(map, parent){
        this._key = '';
        this._map = map;
        this._parent = parent;
        this._type = 'linebreak';
    }
    getNode() {
        const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(this._key);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isLineBreakNode"])(node) ? node : null;
    }
    getKey() {
        return this._key;
    }
    getSharedType() {
        return this._map;
    }
    getType() {
        return this._type;
    }
    getSize() {
        return 1;
    }
    getOffset() {
        const collabElementNode = this._parent;
        return collabElementNode.getChildOffset(this);
    }
    destroy(binding) {
        const collabNodeMap = binding.collabNodeMap;
        if (collabNodeMap.get(this._key) === this) {
            collabNodeMap.delete(this._key);
        }
    }
}
function $createCollabLineBreakNode(map, parent) {
    const collabNode = new CollabLineBreakNode(map, parent);
    map._collabNode = collabNode;
    return collabNode;
}
function $diffTextContentAndApplyDelta(collabNode, key, prevText, nextText) {
    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    let cursorOffset = nextText.length;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(selection) && selection.isCollapsed()) {
        const anchor = selection.anchor;
        if (anchor.key === key) {
            cursorOffset = anchor.offset;
        }
    }
    const diff = simpleDiffWithCursor(prevText, nextText, cursorOffset);
    collabNode.spliceText(diff.index, diff.remove, diff.insert);
}
class CollabTextNode {
    _map;
    _key;
    _parent;
    _text;
    _type;
    _normalized;
    constructor(map, text, parent, type){
        this._key = '';
        this._map = map;
        this._parent = parent;
        this._text = text;
        this._type = type;
        this._normalized = false;
    }
    getPrevNode(nodeMap) {
        if (nodeMap === null) {
            return null;
        }
        const node = nodeMap.get(this._key);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(node) ? node : null;
    }
    getNode() {
        const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(this._key);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(node) ? node : null;
    }
    getSharedType() {
        return this._map;
    }
    getType() {
        return this._type;
    }
    getKey() {
        return this._key;
    }
    getSize() {
        return this._text.length + (this._normalized ? 0 : 1);
    }
    getOffset() {
        const collabElementNode = this._parent;
        return collabElementNode.getChildOffset(this);
    }
    spliceText(index, delCount, newText) {
        const collabElementNode = this._parent;
        const xmlText = collabElementNode._xmlText;
        const offset = this.getOffset() + 1 + index;
        if (delCount !== 0) {
            xmlText.delete(offset, delCount);
        }
        if (newText !== '') {
            xmlText.insert(offset, newText);
        }
    }
    syncPropertiesAndTextFromLexical(binding, nextLexicalNode, prevNodeMap) {
        const prevLexicalNode = this.getPrevNode(prevNodeMap);
        const nextText = nextLexicalNode.__text;
        syncPropertiesFromLexical(binding, this._map, prevLexicalNode, nextLexicalNode);
        if (prevLexicalNode !== null) {
            const prevText = prevLexicalNode.__text;
            if (prevText !== nextText) {
                const key = nextLexicalNode.__key;
                $diffTextContentAndApplyDelta(this, key, prevText, nextText);
                this._text = nextText;
            }
        }
    }
    syncPropertiesAndTextFromYjs(binding, keysChanged) {
        const lexicalNode = this.getNode();
        if (!(lexicalNode !== null)) {
            formatDevErrorMessage(`syncPropertiesAndTextFromYjs: could not find decorator node`);
        }
        $syncPropertiesFromYjs(binding, this._map, lexicalNode, keysChanged);
        const collabText = this._text;
        if (lexicalNode.__text !== collabText) {
            lexicalNode.setTextContent(collabText);
        }
    }
    destroy(binding) {
        const collabNodeMap = binding.collabNodeMap;
        if (collabNodeMap.get(this._key) === this) {
            collabNodeMap.delete(this._key);
        }
    }
}
function $createCollabTextNode(map, text, parent, type) {
    const collabNode = new CollabTextNode(map, text, parent, type);
    map._collabNode = collabNode;
    return collabNode;
}
class CollabElementNode {
    _key;
    _children;
    _xmlText;
    _type;
    _parent;
    constructor(xmlText, parent, type){
        this._key = '';
        this._children = [];
        this._xmlText = xmlText;
        this._type = type;
        this._parent = parent;
    }
    getPrevNode(nodeMap) {
        if (nodeMap === null) {
            return null;
        }
        const node = nodeMap.get(this._key);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(node) ? node : null;
    }
    getNode() {
        const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(this._key);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(node) ? node : null;
    }
    getSharedType() {
        return this._xmlText;
    }
    getType() {
        return this._type;
    }
    getKey() {
        return this._key;
    }
    isEmpty() {
        return this._children.length === 0;
    }
    getSize() {
        return 1;
    }
    getOffset() {
        const collabElementNode = this._parent;
        if (!(collabElementNode !== null)) {
            formatDevErrorMessage(`getOffset: could not find collab element node`);
        }
        return collabElementNode.getChildOffset(this);
    }
    syncPropertiesFromYjs(binding, keysChanged) {
        const lexicalNode = this.getNode();
        if (!(lexicalNode !== null)) {
            formatDevErrorMessage(`syncPropertiesFromYjs: could not find element node`);
        }
        $syncPropertiesFromYjs(binding, this._xmlText, lexicalNode, keysChanged);
    }
    applyChildrenYjsDelta(binding, deltas) {
        const children = this._children;
        let currIndex = 0;
        let pendingSplitText = null;
        for(let i = 0; i < deltas.length; i++){
            const delta = deltas[i];
            const insertDelta = delta.insert;
            const deleteDelta = delta.delete;
            if (delta.retain != null) {
                currIndex += delta.retain;
            } else if (typeof deleteDelta === 'number') {
                let deletionSize = deleteDelta;
                while(deletionSize > 0){
                    const { node, nodeIndex, offset, length } = getPositionFromElementAndOffset(this, currIndex, false);
                    if (node instanceof CollabElementNode || node instanceof CollabLineBreakNode || node instanceof CollabDecoratorNode) {
                        children.splice(nodeIndex, 1);
                        deletionSize -= 1;
                    } else if (node instanceof CollabTextNode) {
                        const delCount = Math.min(deletionSize, length);
                        const prevCollabNode = nodeIndex !== 0 ? children[nodeIndex - 1] : null;
                        const nodeSize = node.getSize();
                        if (offset === 0 && length === nodeSize) {
                            // Text node has been deleted.
                            children.splice(nodeIndex, 1);
                            // If this was caused by an undo from YJS, there could be dangling text.
                            const danglingText = spliceString(node._text, offset, delCount - 1, '');
                            if (danglingText.length > 0) {
                                if (prevCollabNode instanceof CollabTextNode) {
                                    // Merge the text node with previous.
                                    prevCollabNode._text += danglingText;
                                } else {
                                    // No previous text node to merge into, just delete the text.
                                    this._xmlText.delete(offset, danglingText.length);
                                }
                            }
                        } else {
                            node._text = spliceString(node._text, offset, delCount, '');
                        }
                        deletionSize -= delCount;
                    } else {
                        break;
                    }
                }
            } else if (insertDelta != null) {
                if (typeof insertDelta === 'string') {
                    const { node, offset } = getPositionFromElementAndOffset(this, currIndex, true);
                    if (node instanceof CollabTextNode) {
                        node._text = spliceString(node._text, offset, 0, insertDelta);
                    } else {
                        // TODO: maybe we can improve this by keeping around a redundant
                        // text node map, rather than removing all the text nodes, so there
                        // never can be dangling text.
                        // We have a conflict where there was likely a CollabTextNode and
                        // an Lexical TextNode too, but they were removed in a merge. So
                        // let's just ignore the text and trigger a removal for it from our
                        // shared type.
                        this._xmlText.delete(offset, insertDelta.length);
                    }
                    currIndex += insertDelta.length;
                } else {
                    const sharedType = insertDelta;
                    const { node, nodeIndex, length } = getPositionFromElementAndOffset(this, currIndex, false);
                    const collabNode = $getOrInitCollabNodeFromSharedType(binding, sharedType, this);
                    if (node instanceof CollabTextNode && length > 0 && length < node._text.length) {
                        // Trying to insert in the middle of a text node; split the text.
                        const text = node._text;
                        const splitIdx = text.length - length;
                        node._text = spliceString(text, splitIdx, length, '');
                        children.splice(nodeIndex + 1, 0, collabNode);
                        // The insert that triggers the text split might not be a text node. Need to keep a
                        // reference to the remaining text so that it can be added when we do create one.
                        pendingSplitText = spliceString(text, 0, splitIdx, '');
                    } else {
                        children.splice(nodeIndex, 0, collabNode);
                    }
                    if (pendingSplitText !== null && collabNode instanceof CollabTextNode) {
                        // Found a text node to insert the pending text into.
                        collabNode._text = pendingSplitText + collabNode._text;
                        pendingSplitText = null;
                    }
                    currIndex += 1;
                }
            } else {
                throw new Error('Unexpected delta format');
            }
        }
    }
    syncChildrenFromYjs(binding) {
        // Now diff the children of the collab node with that of our existing Lexical node.
        const lexicalNode = this.getNode();
        if (!(lexicalNode !== null)) {
            formatDevErrorMessage(`syncChildrenFromYjs: could not find element node`);
        }
        const key = lexicalNode.__key;
        const prevLexicalChildrenKeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$offset$2f$LexicalOffset$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createChildrenArray"])(lexicalNode, null);
        const lexicalChildrenKeysLength = prevLexicalChildrenKeys.length;
        const collabChildren = this._children;
        const collabChildrenLength = collabChildren.length;
        const collabNodeMap = binding.collabNodeMap;
        const visitedKeys = new Set();
        let collabKeys;
        let writableLexicalNode;
        let prevIndex = 0;
        let prevChildNode = null;
        if (collabChildrenLength !== lexicalChildrenKeysLength) {
            writableLexicalNode = lexicalNode.getWritable();
        }
        for(let i = 0; i < collabChildrenLength; i++){
            const lexicalChildKey = prevLexicalChildrenKeys[prevIndex];
            const childCollabNode = collabChildren[i];
            const collabLexicalChildNode = childCollabNode.getNode();
            const collabKey = childCollabNode._key;
            if (collabLexicalChildNode !== null && lexicalChildKey === collabKey) {
                const childNeedsUpdating = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(collabLexicalChildNode);
                // Update
                visitedKeys.add(lexicalChildKey);
                if (childNeedsUpdating) {
                    childCollabNode._key = lexicalChildKey;
                    if (childCollabNode instanceof CollabElementNode) {
                        const xmlText = childCollabNode._xmlText;
                        childCollabNode.syncPropertiesFromYjs(binding, null);
                        childCollabNode.applyChildrenYjsDelta(binding, xmlText.toDelta());
                        childCollabNode.syncChildrenFromYjs(binding);
                    } else if (childCollabNode instanceof CollabTextNode) {
                        childCollabNode.syncPropertiesAndTextFromYjs(binding, null);
                    } else if (childCollabNode instanceof CollabDecoratorNode) {
                        childCollabNode.syncPropertiesFromYjs(binding, null);
                    } else if (!(childCollabNode instanceof CollabLineBreakNode)) {
                        {
                            formatDevErrorMessage(`syncChildrenFromYjs: expected text, element, decorator, or linebreak collab node`);
                        }
                    }
                }
                prevChildNode = collabLexicalChildNode;
                prevIndex++;
            } else {
                if (collabKeys === undefined) {
                    collabKeys = new Set();
                    for(let s = 0; s < collabChildrenLength; s++){
                        const child = collabChildren[s];
                        const childKey = child._key;
                        if (childKey !== '') {
                            collabKeys.add(childKey);
                        }
                    }
                }
                if (collabLexicalChildNode !== null && lexicalChildKey !== undefined && !collabKeys.has(lexicalChildKey)) {
                    const nodeToRemove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKeyOrThrow"])(lexicalChildKey);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeFromParent"])(nodeToRemove);
                    i--;
                    prevIndex++;
                    continue;
                }
                writableLexicalNode = lexicalNode.getWritable();
                // Create/Replace
                const lexicalChildNode = createLexicalNodeFromCollabNode(binding, childCollabNode, key);
                const childKey = lexicalChildNode.__key;
                collabNodeMap.set(childKey, childCollabNode);
                if (prevChildNode === null) {
                    const nextSibling = writableLexicalNode.getFirstChild();
                    writableLexicalNode.__first = childKey;
                    if (nextSibling !== null) {
                        const writableNextSibling = nextSibling.getWritable();
                        writableNextSibling.__prev = childKey;
                        lexicalChildNode.__next = writableNextSibling.__key;
                    }
                } else {
                    const writablePrevChildNode = prevChildNode.getWritable();
                    const nextSibling = prevChildNode.getNextSibling();
                    writablePrevChildNode.__next = childKey;
                    lexicalChildNode.__prev = prevChildNode.__key;
                    if (nextSibling !== null) {
                        const writableNextSibling = nextSibling.getWritable();
                        writableNextSibling.__prev = childKey;
                        lexicalChildNode.__next = writableNextSibling.__key;
                    }
                }
                if (i === collabChildrenLength - 1) {
                    writableLexicalNode.__last = childKey;
                }
                writableLexicalNode.__size++;
                prevChildNode = lexicalChildNode;
            }
        }
        for(let i = 0; i < lexicalChildrenKeysLength; i++){
            const lexicalChildKey = prevLexicalChildrenKeys[i];
            if (!visitedKeys.has(lexicalChildKey)) {
                // Remove
                const lexicalChildNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKeyOrThrow"])(lexicalChildKey);
                const collabNode = binding.collabNodeMap.get(lexicalChildKey);
                if (collabNode !== undefined) {
                    collabNode.destroy(binding);
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeFromParent"])(lexicalChildNode);
            }
        }
    }
    syncPropertiesFromLexical(binding, nextLexicalNode, prevNodeMap) {
        syncPropertiesFromLexical(binding, this._xmlText, this.getPrevNode(prevNodeMap), nextLexicalNode);
    }
    _syncChildFromLexical(binding, index, key, prevNodeMap, dirtyElements, dirtyLeaves) {
        const childCollabNode = this._children[index];
        // Update
        const nextChildNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKeyOrThrow"])(key);
        if (childCollabNode instanceof CollabElementNode && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(nextChildNode)) {
            childCollabNode.syncPropertiesFromLexical(binding, nextChildNode, prevNodeMap);
            childCollabNode.syncChildrenFromLexical(binding, nextChildNode, prevNodeMap, dirtyElements, dirtyLeaves);
        } else if (childCollabNode instanceof CollabTextNode && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(nextChildNode)) {
            childCollabNode.syncPropertiesAndTextFromLexical(binding, nextChildNode, prevNodeMap);
        } else if (childCollabNode instanceof CollabDecoratorNode && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorNode"])(nextChildNode)) {
            childCollabNode.syncPropertiesFromLexical(binding, nextChildNode, prevNodeMap);
        }
    }
    syncChildrenFromLexical(binding, nextLexicalNode, prevNodeMap, dirtyElements, dirtyLeaves) {
        const prevLexicalNode = this.getPrevNode(prevNodeMap);
        const prevChildren = prevLexicalNode === null ? [] : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$offset$2f$LexicalOffset$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createChildrenArray"])(prevLexicalNode, prevNodeMap);
        const nextChildren = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$offset$2f$LexicalOffset$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createChildrenArray"])(nextLexicalNode, null);
        const prevEndIndex = prevChildren.length - 1;
        const nextEndIndex = nextChildren.length - 1;
        const collabNodeMap = binding.collabNodeMap;
        let prevChildrenSet;
        let nextChildrenSet;
        let prevIndex = 0;
        let nextIndex = 0;
        while(prevIndex <= prevEndIndex && nextIndex <= nextEndIndex){
            const prevKey = prevChildren[prevIndex];
            const nextKey = nextChildren[nextIndex];
            if (prevKey === nextKey) {
                // Nove move, create or remove
                this._syncChildFromLexical(binding, nextIndex, nextKey, prevNodeMap, dirtyElements, dirtyLeaves);
                prevIndex++;
                nextIndex++;
            } else {
                if (prevChildrenSet === undefined) {
                    prevChildrenSet = new Set(prevChildren);
                }
                if (nextChildrenSet === undefined) {
                    nextChildrenSet = new Set(nextChildren);
                }
                const nextHasPrevKey = nextChildrenSet.has(prevKey);
                const prevHasNextKey = prevChildrenSet.has(nextKey);
                if (!nextHasPrevKey) {
                    // Remove
                    this.splice(binding, nextIndex, 1);
                    prevIndex++;
                } else {
                    // Create or replace
                    const nextChildNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKeyOrThrow"])(nextKey);
                    const collabNode = $createCollabNodeFromLexicalNode(binding, nextChildNode, this);
                    collabNodeMap.set(nextKey, collabNode);
                    if (prevHasNextKey) {
                        this.splice(binding, nextIndex, 1, collabNode);
                        prevIndex++;
                        nextIndex++;
                    } else {
                        this.splice(binding, nextIndex, 0, collabNode);
                        nextIndex++;
                    }
                }
            }
        }
        const appendNewChildren = prevIndex > prevEndIndex;
        const removeOldChildren = nextIndex > nextEndIndex;
        if (appendNewChildren && !removeOldChildren) {
            for(; nextIndex <= nextEndIndex; ++nextIndex){
                const key = nextChildren[nextIndex];
                const nextChildNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKeyOrThrow"])(key);
                const collabNode = $createCollabNodeFromLexicalNode(binding, nextChildNode, this);
                this.append(collabNode);
                collabNodeMap.set(key, collabNode);
            }
        } else if (removeOldChildren && !appendNewChildren) {
            for(let i = this._children.length - 1; i >= nextIndex; i--){
                this.splice(binding, i, 1);
            }
        }
    }
    append(collabNode) {
        const xmlText = this._xmlText;
        const children = this._children;
        const lastChild = children[children.length - 1];
        const offset = lastChild !== undefined ? lastChild.getOffset() + lastChild.getSize() : 0;
        if (collabNode instanceof CollabElementNode) {
            xmlText.insertEmbed(offset, collabNode._xmlText);
        } else if (collabNode instanceof CollabTextNode) {
            const map = collabNode._map;
            if (map.parent === null) {
                xmlText.insertEmbed(offset, map);
            }
            xmlText.insert(offset + 1, collabNode._text);
        } else if (collabNode instanceof CollabLineBreakNode) {
            xmlText.insertEmbed(offset, collabNode._map);
        } else if (collabNode instanceof CollabDecoratorNode) {
            xmlText.insertEmbed(offset, collabNode._xmlElem);
        }
        this._children.push(collabNode);
    }
    splice(binding, index, delCount, collabNode) {
        const children = this._children;
        const child = children[index];
        if (child === undefined) {
            if (!(collabNode !== undefined)) {
                formatDevErrorMessage(`splice: could not find collab element node`);
            }
            this.append(collabNode);
            return;
        }
        const offset = child.getOffset();
        if (!(offset !== -1)) {
            formatDevErrorMessage(`splice: expected offset to be greater than zero`);
        }
        const xmlText = this._xmlText;
        if (delCount !== 0) {
            // What if we delete many nodes, don't we need to get all their
            // sizes?
            xmlText.delete(offset, child.getSize());
        }
        if (collabNode instanceof CollabElementNode) {
            xmlText.insertEmbed(offset, collabNode._xmlText);
        } else if (collabNode instanceof CollabTextNode) {
            const map = collabNode._map;
            if (map.parent === null) {
                xmlText.insertEmbed(offset, map);
            }
            xmlText.insert(offset + 1, collabNode._text);
        } else if (collabNode instanceof CollabLineBreakNode) {
            xmlText.insertEmbed(offset, collabNode._map);
        } else if (collabNode instanceof CollabDecoratorNode) {
            xmlText.insertEmbed(offset, collabNode._xmlElem);
        }
        if (delCount !== 0) {
            const childrenToDelete = children.slice(index, index + delCount);
            for(let i = 0; i < childrenToDelete.length; i++){
                childrenToDelete[i].destroy(binding);
            }
        }
        if (collabNode !== undefined) {
            children.splice(index, delCount, collabNode);
        } else {
            children.splice(index, delCount);
        }
    }
    getChildOffset(collabNode) {
        let offset = 0;
        const children = this._children;
        for(let i = 0; i < children.length; i++){
            const child = children[i];
            if (child === collabNode) {
                return offset;
            }
            offset += child.getSize();
        }
        return -1;
    }
    destroy(binding) {
        const collabNodeMap = binding.collabNodeMap;
        const children = this._children;
        for(let i = 0; i < children.length; i++){
            children[i].destroy(binding);
        }
        if (collabNodeMap.get(this._key) === this) {
            collabNodeMap.delete(this._key);
        }
    }
}
function $createCollabElementNode(xmlText, parent, type) {
    const collabNode = new CollabElementNode(xmlText, parent, type);
    xmlText._collabNode = collabNode;
    return collabNode;
}
// Stores mappings between Yjs shared types and the Lexical nodes they were last associated with.
class CollabV2Mapping {
    _nodeMap = new Map();
    _sharedTypeToNodeKeys = new Map();
    _nodeKeyToSharedType = new Map();
    set(sharedType, node) {
        const isArray = node instanceof Array;
        // Clear all existing associations for this key.
        this.delete(sharedType);
        // If nodes were associated with other shared types, remove those associations.
        const nodes = isArray ? node : [
            node
        ];
        for (const n of nodes){
            const key = n.getKey();
            if (this._nodeKeyToSharedType.has(key)) {
                const otherSharedType = this._nodeKeyToSharedType.get(key);
                const keyIndex = this._sharedTypeToNodeKeys.get(otherSharedType).indexOf(key);
                if (keyIndex !== -1) {
                    this._sharedTypeToNodeKeys.get(otherSharedType).splice(keyIndex, 1);
                }
                this._nodeKeyToSharedType.delete(key);
                this._nodeMap.delete(key);
            }
        }
        if (sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"]) {
            if (!isArray) {
                formatDevErrorMessage(`Text nodes must be mapped as an array`);
            }
            if (node.length === 0) {
                return;
            }
            this._sharedTypeToNodeKeys.set(sharedType, node.map((n)=>n.getKey()));
            for (const n of node){
                this._nodeMap.set(n.getKey(), n);
                this._nodeKeyToSharedType.set(n.getKey(), sharedType);
            }
        } else {
            if (!!isArray) {
                formatDevErrorMessage(`Element nodes must be mapped as a single node`);
            }
            if (!!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(node)) {
                formatDevErrorMessage(`Text nodes must be mapped to XmlText`);
            }
            this._sharedTypeToNodeKeys.set(sharedType, [
                node.getKey()
            ]);
            this._nodeMap.set(node.getKey(), node);
            this._nodeKeyToSharedType.set(node.getKey(), sharedType);
        }
    }
    get(sharedType) {
        const nodes = this._sharedTypeToNodeKeys.get(sharedType);
        if (nodes === undefined) {
            return undefined;
        }
        if (sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"]) {
            const arr = Array.from(nodes.map((nodeKey)=>this._nodeMap.get(nodeKey)));
            return arr.length > 0 ? arr : undefined;
        }
        return this._nodeMap.get(nodes[0]);
    }
    getSharedType(node) {
        return this._nodeKeyToSharedType.get(node.getKey());
    }
    delete(sharedType) {
        const nodeKeys = this._sharedTypeToNodeKeys.get(sharedType);
        if (nodeKeys === undefined) {
            return;
        }
        for (const nodeKey of nodeKeys){
            this._nodeMap.delete(nodeKey);
            this._nodeKeyToSharedType.delete(nodeKey);
        }
        this._sharedTypeToNodeKeys.delete(sharedType);
    }
    deleteNode(nodeKey) {
        const sharedType = this._nodeKeyToSharedType.get(nodeKey);
        if (sharedType) {
            this.delete(sharedType);
        }
        this._nodeMap.delete(nodeKey);
    }
    has(sharedType) {
        return this._sharedTypeToNodeKeys.has(sharedType);
    }
    clear() {
        this._nodeMap.clear();
        this._sharedTypeToNodeKeys.clear();
        this._nodeKeyToSharedType.clear();
    }
}
function createBaseBinding(editor, id, doc, docMap, excludedProperties) {
    if (!(doc !== undefined && doc !== null)) {
        formatDevErrorMessage(`createBinding: doc is null or undefined`);
    }
    const binding = {
        clientID: doc.clientID,
        cursors: new Map(),
        cursorsContainer: null,
        doc,
        docMap,
        editor,
        excludedProperties: excludedProperties || new Map(),
        id,
        nodeProperties: new Map()
    };
    initializeNodeProperties(binding);
    return binding;
}
function createBinding(editor, provider, id, doc, docMap, excludedProperties) {
    if (!(doc !== undefined && doc !== null)) {
        formatDevErrorMessage(`createBinding: doc is null or undefined`);
    }
    const rootXmlText = doc.get('root', __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"]);
    const root = $createCollabElementNode(rootXmlText, null, 'root');
    root._key = 'root';
    return {
        ...createBaseBinding(editor, id, doc, docMap, excludedProperties),
        collabNodeMap: new Map(),
        root
    };
}
function createBindingV2__EXPERIMENTAL(editor, id, doc, docMap, options = {}) {
    if (!(doc !== undefined && doc !== null)) {
        formatDevErrorMessage(`createBinding: doc is null or undefined`);
    }
    const { excludedProperties, rootName = 'root-v2' } = options;
    return {
        ...createBaseBinding(editor, id, doc, docMap, excludedProperties),
        mapping: new CollabV2Mapping(),
        root: doc.get(rootName, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"])
    };
}
function isBindingV1(binding) {
    return Object.hasOwn(binding, 'collabNodeMap');
}
const baseExcludedProperties = new Set([
    '__key',
    '__parent',
    '__next',
    '__prev',
    '__state'
]);
const elementExcludedProperties = new Set([
    '__first',
    '__last',
    '__size'
]);
const rootExcludedProperties = new Set([
    '__cachedText'
]);
const textExcludedProperties = new Set([
    '__text'
]);
function isExcludedProperty(name, node, binding) {
    if (baseExcludedProperties.has(name) || typeof node[name] === 'function') {
        return true;
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(node)) {
        if (textExcludedProperties.has(name)) {
            return true;
        }
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(node)) {
        if (elementExcludedProperties.has(name) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRootNode"])(node) && rootExcludedProperties.has(name)) {
            return true;
        }
    }
    const nodeKlass = node.constructor;
    const excludedProperties = binding.excludedProperties.get(nodeKlass);
    return excludedProperties != null && excludedProperties.has(name);
}
function initializeNodeProperties(binding) {
    const { editor, nodeProperties } = binding;
    editor.update(()=>{
        editor._nodes.forEach((nodeInfo)=>{
            const node = new nodeInfo.klass();
            const defaultProperties = {};
            for (const [property, value] of Object.entries(node)){
                if (!isExcludedProperty(property, node, binding)) {
                    defaultProperties[property] = value;
                }
            }
            nodeProperties.set(node.__type, Object.freeze(defaultProperties));
        });
    });
}
function getDefaultNodeProperties(node, binding) {
    const type = node.__type;
    const { nodeProperties } = binding;
    const properties = nodeProperties.get(type);
    if (!(properties !== undefined)) {
        formatDevErrorMessage(`Node properties for ${type} not initialized for sync`);
    }
    return properties;
}
function $createCollabNodeFromLexicalNode(binding, lexicalNode, parent) {
    const nodeType = lexicalNode.__type;
    let collabNode;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(lexicalNode)) {
        const xmlText = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"]();
        collabNode = $createCollabElementNode(xmlText, parent, nodeType);
        collabNode.syncPropertiesFromLexical(binding, lexicalNode, null);
        collabNode.syncChildrenFromLexical(binding, lexicalNode, null, null, null);
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(lexicalNode)) {
        // TODO create a token text node for token, segmented nodes.
        const map = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Map"]();
        collabNode = $createCollabTextNode(map, lexicalNode.__text, parent, nodeType);
        collabNode.syncPropertiesAndTextFromLexical(binding, lexicalNode, null);
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isLineBreakNode"])(lexicalNode)) {
        const map = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Map"]();
        map.set('__type', 'linebreak');
        collabNode = $createCollabLineBreakNode(map, parent);
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorNode"])(lexicalNode)) {
        const xmlElem = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"]();
        collabNode = $createCollabDecoratorNode(xmlElem, parent, nodeType);
        collabNode.syncPropertiesFromLexical(binding, lexicalNode, null);
    } else {
        {
            formatDevErrorMessage(`Expected text, element, decorator, or linebreak node`);
        }
    }
    collabNode._key = lexicalNode.__key;
    return collabNode;
}
function getNodeTypeFromSharedType(sharedType) {
    const type = sharedTypeGet(sharedType, '__type');
    if (!(typeof type === 'string' || typeof type === 'undefined')) {
        formatDevErrorMessage(`Expected shared type to include type attribute`);
    }
    return type;
}
function $getOrInitCollabNodeFromSharedType(binding, sharedType, parent) {
    const collabNode = sharedType._collabNode;
    if (collabNode === undefined) {
        const registeredNodes = binding.editor._nodes;
        const type = getNodeTypeFromSharedType(sharedType);
        if (!(typeof type === 'string')) {
            formatDevErrorMessage(`Expected shared type to include type attribute`);
        }
        const nodeInfo = registeredNodes.get(type);
        if (!(nodeInfo !== undefined)) {
            formatDevErrorMessage(`Node ${type} is not registered`);
        }
        const sharedParent = sharedType.parent;
        const targetParent = parent === undefined && sharedParent !== null ? $getOrInitCollabNodeFromSharedType(binding, sharedParent) : parent || null;
        if (!(targetParent instanceof CollabElementNode)) {
            formatDevErrorMessage(`Expected parent to be a collab element node`);
        }
        if (sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"]) {
            return $createCollabElementNode(sharedType, targetParent, type);
        } else if (sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Map"]) {
            if (type === 'linebreak') {
                return $createCollabLineBreakNode(sharedType, targetParent);
            }
            return $createCollabTextNode(sharedType, '', targetParent, type);
        } else if (sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"]) {
            return $createCollabDecoratorNode(sharedType, targetParent, type);
        }
    }
    return collabNode;
}
function createLexicalNodeFromCollabNode(binding, collabNode, parentKey) {
    const type = collabNode.getType();
    const registeredNodes = binding.editor._nodes;
    const nodeInfo = registeredNodes.get(type);
    if (!(nodeInfo !== undefined)) {
        formatDevErrorMessage(`Node ${type} is not registered`);
    }
    const lexicalNode = new nodeInfo.klass();
    lexicalNode.__parent = parentKey;
    collabNode._key = lexicalNode.__key;
    if (collabNode instanceof CollabElementNode) {
        const xmlText = collabNode._xmlText;
        collabNode.syncPropertiesFromYjs(binding, null);
        collabNode.applyChildrenYjsDelta(binding, xmlText.toDelta());
        collabNode.syncChildrenFromYjs(binding);
    } else if (collabNode instanceof CollabTextNode) {
        collabNode.syncPropertiesAndTextFromYjs(binding, null);
    } else if (collabNode instanceof CollabDecoratorNode) {
        collabNode.syncPropertiesFromYjs(binding, null);
    }
    binding.collabNodeMap.set(lexicalNode.__key, collabNode);
    return lexicalNode;
}
function $syncPropertiesFromYjs(binding, sharedType, lexicalNode, keysChanged) {
    const properties = keysChanged === null ? sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Map"] ? Array.from(sharedType.keys()) : sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"] || sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"] ? Object.keys(sharedType.getAttributes()) : Object.keys(sharedType) : Array.from(keysChanged);
    let writableNode;
    for(let i = 0; i < properties.length; i++){
        const property = properties[i];
        if (isExcludedProperty(property, lexicalNode, binding)) {
            if (property === '__state' && isBindingV1(binding)) {
                if (!writableNode) {
                    writableNode = lexicalNode.getWritable();
                }
                $syncNodeStateToLexical(sharedType, writableNode);
            }
            continue;
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const prevValue = lexicalNode[property];
        let nextValue = sharedTypeGet(sharedType, property);
        if (prevValue !== nextValue) {
            if (nextValue instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Doc"]) {
                const yjsDocMap = binding.docMap;
                if (prevValue instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Doc"]) {
                    yjsDocMap.delete(prevValue.guid);
                }
                const nestedEditor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEditor"])();
                const key = nextValue.guid;
                nestedEditor._key = key;
                yjsDocMap.set(key, nextValue);
                nextValue = nestedEditor;
            }
            if (writableNode === undefined) {
                writableNode = lexicalNode.getWritable();
            }
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            writableNode[property] = nextValue;
        }
    }
}
function sharedTypeGet(sharedType, property) {
    if (sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Map"]) {
        return sharedType.get(property);
    } else if (sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"] || sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"]) {
        return sharedType.getAttribute(property);
    } else {
        return sharedType[property];
    }
}
function sharedTypeSet(sharedType, property, nextValue) {
    if (sharedType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Map"]) {
        sharedType.set(property, nextValue);
    } else {
        sharedType.setAttribute(property, nextValue);
    }
}
function $syncNodeStateToLexical(sharedType, lexicalNode) {
    const existingState = sharedTypeGet(sharedType, '__state');
    if (!(existingState instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Map"])) {
        return;
    }
    // This should only called when creating the node initially,
    // incremental updates to state come in through YMapEvent
    // with the __state as the target.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getWritableNodeState"])(lexicalNode).updateFromJSON(existingState.toJSON());
}
function syncNodeStateFromLexical(binding, sharedType, prevLexicalNode, nextLexicalNode) {
    const nextState = nextLexicalNode.__state;
    const existingState = sharedTypeGet(sharedType, '__state');
    if (!nextState) {
        return;
    }
    const [unknown, known] = nextState.getInternalState();
    const prevState = prevLexicalNode && prevLexicalNode.__state;
    const stateMap = existingState instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Map"] ? existingState : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Map"]();
    if (prevState === nextState) {
        return;
    }
    const [prevUnknown, prevKnown] = prevState && stateMap.doc ? prevState.getInternalState() : [
        undefined,
        new Map()
    ];
    if (unknown) {
        for (const [k, v] of Object.entries(unknown)){
            if (prevUnknown && v !== prevUnknown[k]) {
                stateMap.set(k, v);
            }
        }
    }
    for (const [stateConfig, v] of known){
        if (prevKnown.get(stateConfig) !== v) {
            stateMap.set(stateConfig.key, stateConfig.unparse(v));
        }
    }
    if (!existingState) {
        sharedTypeSet(sharedType, '__state', stateMap);
    }
}
function syncPropertiesFromLexical(binding, sharedType, prevLexicalNode, nextLexicalNode) {
    const properties = Object.keys(getDefaultNodeProperties(nextLexicalNode, binding));
    const EditorClass = binding.editor.constructor;
    syncNodeStateFromLexical(binding, sharedType, prevLexicalNode, nextLexicalNode);
    for(let i = 0; i < properties.length; i++){
        const property = properties[i];
        const prevValue = // eslint-disable-next-line @typescript-eslint/no-explicit-any
        prevLexicalNode === null ? undefined : prevLexicalNode[property];
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let nextValue = nextLexicalNode[property];
        if (prevValue !== nextValue) {
            if (nextValue instanceof EditorClass) {
                const yjsDocMap = binding.docMap;
                let prevDoc;
                if (prevValue instanceof EditorClass) {
                    const prevKey = prevValue._key;
                    prevDoc = yjsDocMap.get(prevKey);
                    yjsDocMap.delete(prevKey);
                }
                // If we already have a document, use it.
                const doc = prevDoc || new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Doc"]();
                const key = doc.guid;
                nextValue._key = key;
                yjsDocMap.set(key, doc);
                nextValue = doc;
                // Mark the node dirty as we've assigned a new key to it
                binding.editor.update(()=>{
                    nextLexicalNode.markDirty();
                });
            }
            sharedTypeSet(sharedType, property, nextValue);
        }
    }
}
function spliceString(str, index, delCount, newText) {
    return str.slice(0, index) + newText + str.slice(index + delCount);
}
function getPositionFromElementAndOffset(node, offset, boundaryIsEdge) {
    let index = 0;
    let i = 0;
    const children = node._children;
    const childrenLength = children.length;
    for(; i < childrenLength; i++){
        const child = children[i];
        const childOffset = index;
        const size = child.getSize();
        index += size;
        const exceedsBoundary = boundaryIsEdge ? index >= offset : index > offset;
        if (exceedsBoundary && child instanceof CollabTextNode) {
            let textOffset = offset - childOffset - 1;
            if (textOffset < 0) {
                textOffset = 0;
            }
            const diffLength = index - offset;
            return {
                length: diffLength,
                node: child,
                nodeIndex: i,
                offset: textOffset
            };
        }
        if (index > offset) {
            return {
                length: 0,
                node: child,
                nodeIndex: i,
                offset: childOffset
            };
        } else if (i === childrenLength - 1) {
            return {
                length: 0,
                node: null,
                nodeIndex: i + 1,
                offset: childOffset + 1
            };
        }
    }
    return {
        length: 0,
        node: null,
        nodeIndex: 0,
        offset: 0
    };
}
function doesSelectionNeedRecovering(selection) {
    const anchor = selection.anchor;
    const focus = selection.focus;
    let recoveryNeeded = false;
    try {
        const anchorNode = anchor.getNode();
        const focusNode = focus.getNode();
        if (// We might have removed a node that no longer exists
        !anchorNode.isAttached() || !focusNode.isAttached() || // If we've split a node, then the offset might not be right
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(anchorNode) && anchor.offset > anchorNode.getTextContentSize() || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(focusNode) && focus.offset > focusNode.getTextContentSize()) {
            recoveryNeeded = true;
        }
    } catch (_e) {
        // Sometimes checking nor a node via getNode might trigger
        // an error, so we need recovery then too.
        recoveryNeeded = true;
    }
    return recoveryNeeded;
}
function syncWithTransaction(binding, fn) {
    binding.doc.transact(fn, binding);
}
function $moveSelectionToPreviousNode(anchorNodeKey, currentEditorState) {
    const anchorNode = currentEditorState._nodeMap.get(anchorNodeKey);
    if (!anchorNode) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().selectStart();
        return;
    }
    // Get previous node
    const prevNodeKey = anchorNode.__prev;
    let prevNode = null;
    if (prevNodeKey) {
        prevNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(prevNodeKey);
    }
    // If previous node not found, get parent node
    if (prevNode === null && anchorNode.__parent !== null) {
        prevNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(anchorNode.__parent);
    }
    if (prevNode === null) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().selectStart();
        return;
    }
    if (prevNode !== null && prevNode.isAttached()) {
        prevNode.selectEnd();
        return;
    } else {
        // If the found node is also deleted, select the next one
        $moveSelectionToPreviousNode(prevNode.__key, currentEditorState);
    }
}
// https://docs.yjs.dev/api/shared-types/y.xmlelement
// "Define a top-level type; Note that the nodeName is always "undefined""
const isRootElement = (el)=>el.nodeName === 'UNDEFINED';
const $createOrUpdateNodeFromYElement = (el, binding, keysChanged, childListChanged, snapshot, prevSnapshot, computeYChange)=>{
    let node = binding.mapping.get(el);
    if (node && keysChanged && keysChanged.size === 0 && !childListChanged) {
        return node;
    }
    const type = isRootElement(el) ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RootNode"].getType() : el.nodeName;
    const registeredNodes = binding.editor._nodes;
    const nodeInfo = registeredNodes.get(type);
    if (nodeInfo === undefined) {
        throw new Error(`$createOrUpdateNodeFromYElement: Node ${type} is not registered`);
    }
    if (!node) {
        node = new nodeInfo.klass();
        keysChanged = null;
        childListChanged = true;
    }
    if (childListChanged && node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementNode"]) {
        const children = [];
        const $createChildren = (childType)=>{
            if (childType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"]) {
                const n = $createOrUpdateNodeFromYElement(childType, binding, new Set(), false, snapshot, prevSnapshot, computeYChange);
                if (n !== null) {
                    children.push(n);
                }
            } else if (childType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"]) {
                const ns = $createOrUpdateTextNodesFromYText(childType, binding, snapshot, prevSnapshot, computeYChange);
                if (ns !== null) {
                    ns.forEach((textchild)=>{
                        if (textchild !== null) {
                            children.push(textchild);
                        }
                    });
                }
            } else {
                {
                    formatDevErrorMessage(`XmlHook is not supported`);
                }
            }
        };
        if (snapshot === undefined || prevSnapshot === undefined) {
            el.toArray().forEach($createChildren);
        } else {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["typeListToArraySnapshot"])(el, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Snapshot"](prevSnapshot.ds, snapshot.sv)).filter((childType)=>!childType._item.deleted || isItemVisible(childType._item, snapshot) || isItemVisible(childType._item, prevSnapshot)).forEach($createChildren);
        }
        $spliceChildren(node, children);
    }
    // TODO(collab-v2): typing for XmlElement generic
    const attrs = el.getAttributes(snapshot);
    if (!isRootElement(el) && snapshot !== undefined) {
        if (!isItemVisible(el._item, snapshot)) {
            attrs[stateKeyToAttrKey('ychange')] = computeYChange ? computeYChange('removed', el._item.id) : {
                type: 'removed'
            };
        } else if (!isItemVisible(el._item, prevSnapshot)) {
            attrs[stateKeyToAttrKey('ychange')] = computeYChange ? computeYChange('added', el._item.id) : {
                type: 'added'
            };
        }
    }
    const properties = {
        ...getDefaultNodeProperties(node, binding)
    };
    const state = {};
    for(const k in attrs){
        if (k.startsWith(STATE_KEY_PREFIX)) {
            state[attrKeyToStateKey(k)] = attrs[k];
        } else {
            properties[k] = attrs[k];
        }
    }
    $syncPropertiesFromYjs(binding, properties, node, keysChanged);
    if (!keysChanged) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getWritableNodeState"])(node).updateFromJSON(state);
    } else {
        const stateKeysChanged = Object.keys(state).filter((k)=>keysChanged.has(stateKeyToAttrKey(k)));
        if (stateKeysChanged.length > 0) {
            const writableState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getWritableNodeState"])(node);
            for (const k of stateKeysChanged){
                writableState.updateFromUnknown(k, state[k]);
            }
        }
    }
    const latestNode = node.getLatest();
    binding.mapping.set(el, latestNode);
    return latestNode;
};
const $spliceChildren = (node, nextChildren)=>{
    const prevChildren = node.getChildren();
    const prevChildrenKeySet = new Set(prevChildren.map((child)=>child.getKey()));
    const nextChildrenKeySet = new Set(nextChildren.map((child)=>child.getKey()));
    const prevEndIndex = prevChildren.length - 1;
    const nextEndIndex = nextChildren.length - 1;
    let prevIndex = 0;
    let nextIndex = 0;
    while(prevIndex <= prevEndIndex && nextIndex <= nextEndIndex){
        const prevKey = prevChildren[prevIndex].getKey();
        const nextKey = nextChildren[nextIndex].getKey();
        if (prevKey === nextKey) {
            prevIndex++;
            nextIndex++;
            continue;
        }
        const nextHasPrevKey = nextChildrenKeySet.has(prevKey);
        const prevHasNextKey = prevChildrenKeySet.has(nextKey);
        if (!nextHasPrevKey) {
            // If removing the last node, insert remaining new nodes immediately, otherwise if the node
            // cannot be empty, it will remove itself from its parent.
            if (nextIndex === 0 && node.getChildrenSize() === 1) {
                node.splice(nextIndex, 1, nextChildren.slice(nextIndex));
                return;
            }
            // Remove
            node.splice(nextIndex, 1, []);
            prevIndex++;
            continue;
        }
        // Create or replace
        const nextChildNode = nextChildren[nextIndex];
        if (prevHasNextKey) {
            node.splice(nextIndex, 1, [
                nextChildNode
            ]);
            prevIndex++;
            nextIndex++;
        } else {
            node.splice(nextIndex, 0, [
                nextChildNode
            ]);
            nextIndex++;
        }
    }
    const appendNewChildren = prevIndex > prevEndIndex;
    const removeOldChildren = nextIndex > nextEndIndex;
    if (appendNewChildren && !removeOldChildren) {
        node.append(...nextChildren.slice(nextIndex));
    } else if (removeOldChildren && !appendNewChildren) {
        node.splice(nextChildren.length, node.getChildrenSize() - nextChildren.length, []);
    }
};
const isItemVisible = (item, snapshot)=>snapshot === undefined ? !item.deleted : snapshot.sv.has(item.id.client) && snapshot.sv.get(item.id.client) > item.id.clock && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDeleted"])(snapshot.ds, item.id);
const $createOrUpdateTextNodesFromYText = (text, binding, snapshot, prevSnapshot, computeYChange)=>{
    const deltas = toDelta(text, snapshot, prevSnapshot, computeYChange);
    // Use existing text nodes if the count and types all align, otherwise throw out the existing
    // nodes and create new ones.
    let nodes = binding.mapping.get(text) ?? [];
    const nodeTypes = deltas.map((delta)=>delta.attributes.t ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextNode"].getType());
    const canReuseNodes = nodes.length === nodeTypes.length && nodes.every((node, i)=>node.getType() === nodeTypes[i]);
    if (!canReuseNodes) {
        const registeredNodes = binding.editor._nodes;
        nodes = nodeTypes.map((type)=>{
            const nodeInfo = registeredNodes.get(type);
            if (nodeInfo === undefined) {
                throw new Error(`$createTextNodesFromYText: Node ${type} is not registered`);
            }
            const node = new nodeInfo.klass();
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(node)) {
                throw new Error(`$createTextNodesFromYText: Node ${type} is not a TextNode`);
            }
            return node;
        });
    }
    // Sync text, properties and state to the text nodes.
    for(let i = 0; i < deltas.length; i++){
        const node = nodes[i];
        const delta = deltas[i];
        const { attributes, insert } = delta;
        if (node.__text !== insert) {
            node.setTextContent(insert);
        }
        const properties = {
            ...getDefaultNodeProperties(node, binding),
            ...attributes.p
        };
        const state = Object.fromEntries(Object.entries(attributes).filter(([k])=>k.startsWith(STATE_KEY_PREFIX)).map(([k, v])=>[
                attrKeyToStateKey(k),
                v
            ]));
        $syncPropertiesFromYjs(binding, properties, node, null);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getWritableNodeState"])(node).updateFromJSON(state);
    }
    const latestNodes = nodes.map((node)=>node.getLatest());
    binding.mapping.set(text, latestNodes);
    return latestNodes;
};
const $createTypeFromTextNodes = (nodes, binding)=>{
    const type = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"]();
    $updateYText(type, nodes, binding);
    return type;
};
const createTypeFromElementNode = (node, binding)=>{
    const type = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"](node.getType());
    const attrs = {
        ...propertiesToAttributes(node, binding),
        ...stateToAttributes(node)
    };
    for(const key in attrs){
        const val = attrs[key];
        if (val !== null) {
            // TODO(collab-v2): typing for XmlElement generic
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            type.setAttribute(key, val);
        }
    }
    if (!(node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementNode"])) {
        return type;
    }
    type.insert(0, normalizeNodeContent(node).map((n)=>$createTypeFromTextOrElementNode(n, binding)));
    binding.mapping.set(type, node);
    return type;
};
const $createTypeFromTextOrElementNode = (node, meta)=>node instanceof Array ? $createTypeFromTextNodes(node, meta) : createTypeFromElementNode(node, meta);
const isObject = (val)=>typeof val === 'object' && val != null;
const equalAttrs = (pattrs, yattrs)=>{
    const keys = Object.keys(pattrs).filter((key)=>pattrs[key] !== null);
    if (yattrs == null) {
        return keys.length === 0;
    }
    let eq = keys.length === Object.keys(yattrs).filter((key)=>yattrs[key] !== null).length;
    for(let i = 0; i < keys.length && eq; i++){
        const key = keys[i];
        const l = pattrs[key];
        const r = yattrs[key];
        eq = key === 'ychange' || l === r || isObject(l) && isObject(r) && equalAttrs(l, r);
    }
    return eq;
};
const normalizeNodeContent = (node)=>{
    if (!(node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementNode"])) {
        return [];
    }
    const c = node.getChildren();
    const res = [];
    for(let i = 0; i < c.length; i++){
        const n = c[i];
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(n)) {
            const textNodes = [];
            for(let maybeTextNode = c[i]; i < c.length && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(maybeTextNode); maybeTextNode = c[++i]){
                textNodes.push(maybeTextNode);
            }
            i--;
            res.push(textNodes);
        } else {
            res.push(n);
        }
    }
    return res;
};
const equalYTextLText = (ytext, ltexts, binding)=>{
    const deltas = toDelta(ytext);
    return deltas.length === ltexts.length && deltas.every((d, i)=>{
        const ltext = ltexts[i];
        const type = d.attributes.t ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextNode"].getType();
        const propertyAttrs = d.attributes.p ?? {};
        const stateAttrs = Object.fromEntries(Object.entries(d.attributes).filter(([k])=>k.startsWith(STATE_KEY_PREFIX)));
        return d.insert === ltext.getTextContent() && type === ltext.getType() && equalAttrs(propertyAttrs, propertiesToAttributes(ltext, binding)) && equalAttrs(stateAttrs, stateToAttributes(ltext));
    });
};
const equalYTypePNode = (ytype, lnode, binding)=>{
    if (ytype instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"] && !(lnode instanceof Array) && matchNodeName(ytype, lnode)) {
        const normalizedContent = normalizeNodeContent(lnode);
        return ytype._length === normalizedContent.length && equalAttrs(ytype.getAttributes(), {
            ...propertiesToAttributes(lnode, binding),
            ...stateToAttributes(lnode)
        }) && ytype.toArray().every((ychild, i)=>equalYTypePNode(ychild, normalizedContent[i], binding));
    }
    return ytype instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"] && lnode instanceof Array && equalYTextLText(ytype, lnode, binding);
};
const mappedIdentity = (mapped, lcontent)=>mapped === lcontent || mapped instanceof Array && lcontent instanceof Array && mapped.length === lcontent.length && mapped.every((a, i)=>lcontent[i] === a);
const computeChildEqualityFactor = (ytype, lnode, binding)=>{
    const yChildren = ytype.toArray();
    const pChildren = normalizeNodeContent(lnode);
    const pChildCnt = pChildren.length;
    const yChildCnt = yChildren.length;
    const minCnt = Math.min(yChildCnt, pChildCnt);
    let left = 0;
    let right = 0;
    let foundMappedChild = false;
    for(; left < minCnt; left++){
        const leftY = yChildren[left];
        const leftP = pChildren[left];
        if (leftY instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlHook"]) {
            break;
        } else if (mappedIdentity(binding.mapping.get(leftY), leftP)) {
            foundMappedChild = true; // definite (good) match!
        } else if (!equalYTypePNode(leftY, leftP, binding)) {
            break;
        }
    }
    for(; left + right < minCnt; right++){
        const rightY = yChildren[yChildCnt - right - 1];
        const rightP = pChildren[pChildCnt - right - 1];
        if (rightY instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlHook"]) {
            break;
        } else if (mappedIdentity(binding.mapping.get(rightY), rightP)) {
            foundMappedChild = true;
        } else if (!equalYTypePNode(rightY, rightP, binding)) {
            break;
        }
    }
    return {
        equalityFactor: left + right,
        foundMappedChild
    };
};
const ytextTrans = (ytext)=>{
    let str = '';
    let n = ytext._start;
    const nAttrs = {};
    while(n !== null){
        if (!n.deleted) {
            if (n.countable && n.content instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentString"]) {
                str += n.content.str;
            } else if (n.content instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentFormat"]) {
                nAttrs[n.content.key] = null;
            }
        }
        n = n.right;
    }
    return {
        nAttrs,
        str
    };
};
const $updateYText = (ytext, ltexts, binding)=>{
    binding.mapping.set(ytext, ltexts);
    const { nAttrs, str } = ytextTrans(ytext);
    const content = ltexts.map((node, i)=>{
        const nodeType = node.getType();
        let p = propertiesToAttributes(node, binding);
        if (Object.keys(p).length === 0) {
            p = null;
        }
        return {
            attributes: Object.assign({}, nAttrs, {
                ...nodeType !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextNode"].getType() && {
                    t: nodeType
                },
                p,
                ...stateToAttributes(node),
                ...i > 0 && {
                    i
                }
            }),
            insert: node.getTextContent(),
            nodeKey: node.getKey()
        };
    });
    const nextText = content.map((c)=>c.insert).join('');
    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    let cursorOffset;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(selection) && selection.isCollapsed()) {
        cursorOffset = 0;
        for (const c of content){
            if (c.nodeKey === selection.anchor.key) {
                cursorOffset += selection.anchor.offset;
                break;
            }
            cursorOffset += c.insert.length;
        }
    } else {
        cursorOffset = nextText.length;
    }
    const { insert, remove, index } = simpleDiffWithCursor(str, nextText, cursorOffset);
    ytext.delete(index, remove);
    ytext.insert(index, insert);
    ytext.applyDelta(content.map((c)=>({
            attributes: c.attributes,
            retain: c.insert.length
        })));
};
const toDelta = (ytext, snapshot, prevSnapshot, computeYChange)=>{
    return ytext.toDelta(snapshot, prevSnapshot, computeYChange).map((delta)=>{
        const attributes = delta.attributes ?? {};
        if ('ychange' in attributes) {
            attributes[stateKeyToAttrKey('ychange')] = attributes.ychange;
            delete attributes.ychange;
        }
        return {
            ...delta,
            attributes
        };
    });
};
const propertiesToAttributes = (node, meta)=>{
    const defaultProperties = getDefaultNodeProperties(node, meta);
    const attrs = {};
    Object.entries(defaultProperties).forEach(([property, defaultValue])=>{
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const value = node[property];
        if (value !== defaultValue) {
            attrs[property] = value;
        }
    });
    return attrs;
};
const STATE_KEY_PREFIX = 's_';
const stateKeyToAttrKey = (key)=>`s_${key}`;
const attrKeyToStateKey = (key)=>{
    if (!key.startsWith(STATE_KEY_PREFIX)) {
        throw new Error(`Invalid state key: ${key}`);
    }
    return key.slice(STATE_KEY_PREFIX.length);
};
const stateToAttributes = (node)=>{
    const state = node.__state;
    if (!state) {
        return {};
    }
    const [unknown = {}, known] = state.getInternalState();
    const attrs = {};
    for (const [k, v] of Object.entries(unknown)){
        attrs[stateKeyToAttrKey(k)] = v;
    }
    for (const [stateConfig, v] of known){
        attrs[stateKeyToAttrKey(stateConfig.key)] = stateConfig.unparse(v);
    }
    return attrs;
};
const $updateYFragment = (y, yDomFragment, node, binding, dirtyElements)=>{
    if (yDomFragment instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"] && yDomFragment.nodeName !== node.getType() && !(isRootElement(yDomFragment) && node.getType() === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RootNode"].getType())) {
        throw new Error('node name mismatch!');
    }
    binding.mapping.set(yDomFragment, node);
    // update attributes
    if (yDomFragment instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"]) {
        const yDomAttrs = yDomFragment.getAttributes();
        const lexicalAttrs = {
            ...propertiesToAttributes(node, binding),
            ...stateToAttributes(node)
        };
        for(const key in lexicalAttrs){
            if (lexicalAttrs[key] != null) {
                const isEqual = yDomAttrs[key] === lexicalAttrs[key] || // deep equality check so we don't sync properties/state with object values every update
                isObject(yDomAttrs[key]) && isObject(lexicalAttrs[key]) && equalAttrs(yDomAttrs[key], lexicalAttrs[key]);
                if (!isEqual && key !== 'ychange') {
                    // TODO(collab-v2): typing for XmlElement generic
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    yDomFragment.setAttribute(key, lexicalAttrs[key]);
                }
            } else {
                yDomFragment.removeAttribute(key);
            }
        }
        // remove all keys that are no longer in pAttrs
        for(const key in yDomAttrs){
            if (lexicalAttrs[key] === undefined) {
                yDomFragment.removeAttribute(key);
            }
        }
    }
    // update children
    const lChildren = normalizeNodeContent(node);
    const lChildCnt = lChildren.length;
    const yChildren = yDomFragment.toArray();
    const yChildCnt = yChildren.length;
    const minCnt = Math.min(lChildCnt, yChildCnt);
    let left = 0;
    let right = 0;
    // find number of matching elements from left
    for(; left < minCnt; left++){
        const leftY = yChildren[left];
        const leftL = lChildren[left];
        if (leftY instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlHook"]) {
            break;
        } else if (mappedIdentity(binding.mapping.get(leftY), leftL)) {
            if (leftL instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementNode"] && dirtyElements.has(leftL.getKey())) {
                $updateYFragment(y, leftY, leftL, binding, dirtyElements);
            }
        } else if (equalYTypePNode(leftY, leftL, binding)) {
            // update mapping
            binding.mapping.set(leftY, leftL);
        } else {
            break;
        }
    }
    // find number of matching elements from right
    for(; right + left < minCnt; right++){
        const rightY = yChildren[yChildCnt - right - 1];
        const rightL = lChildren[lChildCnt - right - 1];
        if (rightY instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlHook"]) {
            break;
        } else if (mappedIdentity(binding.mapping.get(rightY), rightL)) {
            if (rightL instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementNode"] && dirtyElements.has(rightL.getKey())) {
                $updateYFragment(y, rightY, rightL, binding, dirtyElements);
            }
        } else if (equalYTypePNode(rightY, rightL, binding)) {
            // update mapping
            binding.mapping.set(rightY, rightL);
        } else {
            break;
        }
    }
    // try to compare and update
    while(yChildCnt - left - right > 0 && lChildCnt - left - right > 0){
        const leftY = yChildren[left];
        const leftL = lChildren[left];
        const rightY = yChildren[yChildCnt - right - 1];
        const rightL = lChildren[lChildCnt - right - 1];
        if (leftY instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"] && leftL instanceof Array) {
            if (!equalYTextLText(leftY, leftL, binding)) {
                $updateYText(leftY, leftL, binding);
            }
            left += 1;
        } else {
            let updateLeft = leftY instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"] && matchNodeName(leftY, leftL);
            let updateRight = rightY instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"] && matchNodeName(rightY, rightL);
            if (updateLeft && updateRight) {
                // decide which which element to update
                const equalityLeft = computeChildEqualityFactor(leftY, leftL, binding);
                const equalityRight = computeChildEqualityFactor(rightY, rightL, binding);
                if (equalityLeft.foundMappedChild && !equalityRight.foundMappedChild) {
                    updateRight = false;
                } else if (!equalityLeft.foundMappedChild && equalityRight.foundMappedChild) {
                    updateLeft = false;
                } else if (equalityLeft.equalityFactor < equalityRight.equalityFactor) {
                    updateLeft = false;
                } else {
                    updateRight = false;
                }
            }
            if (updateLeft) {
                $updateYFragment(y, leftY, leftL, binding, dirtyElements);
                left += 1;
            } else if (updateRight) {
                $updateYFragment(y, rightY, rightL, binding, dirtyElements);
                right += 1;
            } else {
                binding.mapping.delete(yDomFragment.get(left));
                yDomFragment.delete(left, 1);
                yDomFragment.insert(left, [
                    $createTypeFromTextOrElementNode(leftL, binding)
                ]);
                left += 1;
            }
        }
    }
    const yDelLen = yChildCnt - left - right;
    if (yChildCnt === 1 && lChildCnt === 0 && yChildren[0] instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"]) {
        binding.mapping.delete(yChildren[0]);
        // Edge case handling https://github.com/yjs/y-prosemirror/issues/108
        // Only delete the content of the Y.Text to retain remote changes on the same Y.Text object
        yChildren[0].delete(0, yChildren[0].length);
    } else if (yDelLen > 0) {
        yDomFragment.slice(left, left + yDelLen).forEach((type)=>binding.mapping.delete(type));
        yDomFragment.delete(left, yDelLen);
    }
    if (left + right < lChildCnt) {
        const ins = [];
        for(let i = left; i < lChildCnt - right; i++){
            ins.push($createTypeFromTextOrElementNode(lChildren[i], binding));
        }
        yDomFragment.insert(left, ins);
    }
};
const matchNodeName = (yElement, lnode)=>!(lnode instanceof Array) && yElement.nodeName === lnode.getType();
const STATE_KEY = 'ychange';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const ychangeState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createState"])(STATE_KEY, {
    isEqual: (a, b)=>a === b,
    parse: (value)=>value ?? null
});
function $getYChangeState(node) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getState"])(node, ychangeState);
}
// Not exposing $setState because it should only be created by SyncV2.ts.
/**
 * Replaces the editor content with a view that compares the state between two given snapshots.
 * Any added or removed nodes between the two snapshots will have {@link YChange} attached to them.
 *
 * @param binding Yjs binding
 * @param snapshot Ending snapshot state (default: current state of the Yjs document)
 * @param prevSnapshot Starting snapshot state (default: empty snapshot)
 */ const renderSnapshot__EXPERIMENTAL = (binding, snapshot$1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["snapshot"])(binding.doc), prevSnapshot = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptySnapshot"])=>{
    // The document that contains the full history of this document.
    const { doc } = binding;
    if (!!doc.gc) {
        formatDevErrorMessage(`GC must be disabled to render snapshot`);
    }
    doc.transact((transaction)=>{
        // Before rendering, we are going to sanitize ops and split deleted ops
        // if they were deleted by seperate users.
        const pud = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PermanentUserData"](doc);
        if (pud) {
            pud.dss.forEach((ds)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["iterateDeletedStructs"])(transaction, ds, (_item)=>{});
            });
        }
        const computeYChange = (type, id)=>{
            const user = type === 'added' ? pud.getUserByClientId(id.client) : pud.getUserByDeletedId(id);
            return {
                id,
                type,
                user: user ?? null
            };
        };
        binding.mapping.clear();
        binding.editor.update(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().clear();
            $createOrUpdateNodeFromYElement(binding.root, binding, null, true, snapshot$1, prevSnapshot, computeYChange);
        });
    }, binding);
};
function createRelativePosition(point, binding) {
    const collabNodeMap = binding.collabNodeMap;
    const collabNode = collabNodeMap.get(point.key);
    if (collabNode === undefined) {
        return null;
    }
    let offset = point.offset;
    let sharedType = collabNode.getSharedType();
    if (collabNode instanceof CollabTextNode) {
        sharedType = collabNode._parent._xmlText;
        const currentOffset = collabNode.getOffset();
        if (currentOffset === -1) {
            return null;
        }
        offset = currentOffset + 1 + offset;
    } else if (collabNode instanceof CollabElementNode && point.type === 'element') {
        const parent = point.getNode();
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(parent)) {
            formatDevErrorMessage(`Element point must be an element node`);
        }
        let accumulatedOffset = 0;
        let i = 0;
        let node = parent.getFirstChild();
        while(node !== null && i++ < offset){
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(node)) {
                accumulatedOffset += node.getTextContentSize() + 1;
            } else {
                accumulatedOffset++;
            }
            node = node.getNextSibling();
        }
        offset = accumulatedOffset;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRelativePositionFromTypeIndex"])(sharedType, offset);
}
function createRelativePositionV2(point, binding) {
    const { mapping } = binding;
    const { offset } = point;
    const node = point.getNode();
    const yType = mapping.getSharedType(node);
    if (yType === undefined) {
        return null;
    }
    if (point.type === 'text') {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(node)) {
            formatDevErrorMessage(`Text point must be a text node`);
        }
        let prevSibling = node.getPreviousSibling();
        let adjustedOffset = offset;
        while((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(prevSibling)){
            adjustedOffset += prevSibling.getTextContentSize();
            prevSibling = prevSibling.getPreviousSibling();
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRelativePositionFromTypeIndex"])(yType, adjustedOffset);
    } else if (point.type === 'element') {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(node)) {
            formatDevErrorMessage(`Element point must be an element node`);
        }
        let i = 0;
        let child = node.getFirstChild();
        while(child !== null && i < offset){
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(child)) {
                let nextSibling = child.getNextSibling();
                while((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(nextSibling)){
                    nextSibling = nextSibling.getNextSibling();
                }
            }
            i++;
            child = child.getNextSibling();
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRelativePositionFromTypeIndex"])(yType, i);
    }
    return null;
}
function createAbsolutePosition(relativePosition, binding) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAbsolutePositionFromRelativePosition"])(relativePosition, binding.doc);
}
function shouldUpdatePosition(currentPos, pos) {
    if (currentPos == null) {
        if (pos != null) {
            return true;
        }
    } else if (pos == null || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compareRelativePositions"])(currentPos, pos)) {
        return true;
    }
    return false;
}
function createCursor(name, color) {
    return {
        color: color,
        name: name,
        selection: null
    };
}
function destroySelection(binding, selection) {
    const cursorsContainer = binding.cursorsContainer;
    if (cursorsContainer !== null) {
        const selections = selection.selections;
        const selectionsLength = selections.length;
        for(let i = 0; i < selectionsLength; i++){
            cursorsContainer.removeChild(selections[i]);
        }
    }
}
function destroyCursor(binding, cursor) {
    const selection = cursor.selection;
    if (selection !== null) {
        destroySelection(binding, selection);
    }
}
function createCursorSelection(cursor, anchorKey, anchorOffset, focusKey, focusOffset) {
    const color = cursor.color;
    const caret = document.createElement('span');
    caret.style.cssText = `position:absolute;top:0;bottom:0;right:-1px;width:1px;background-color:${color};z-index:10;`;
    const name = document.createElement('span');
    name.textContent = cursor.name;
    name.style.cssText = `position:absolute;left:-2px;top:-16px;background-color:${color};color:#fff;line-height:12px;font-size:12px;padding:2px;font-family:Arial;font-weight:bold;white-space:nowrap;`;
    caret.appendChild(name);
    return {
        anchor: {
            key: anchorKey,
            offset: anchorOffset
        },
        caret,
        color,
        focus: {
            key: focusKey,
            offset: focusOffset
        },
        name,
        selections: []
    };
}
function updateCursor(binding, cursor, nextSelection, nodeMap) {
    const editor = binding.editor;
    const rootElement = editor.getRootElement();
    const cursorsContainer = binding.cursorsContainer;
    if (cursorsContainer === null || rootElement === null) {
        return;
    }
    const cursorsContainerOffsetParent = cursorsContainer.offsetParent;
    if (cursorsContainerOffsetParent === null) {
        return;
    }
    const containerRect = cursorsContainerOffsetParent.getBoundingClientRect();
    const prevSelection = cursor.selection;
    if (nextSelection === null) {
        if (prevSelection === null) {
            return;
        } else {
            cursor.selection = null;
            destroySelection(binding, prevSelection);
            return;
        }
    } else {
        cursor.selection = nextSelection;
    }
    const caret = nextSelection.caret;
    const color = nextSelection.color;
    const selections = nextSelection.selections;
    const anchor = nextSelection.anchor;
    const focus = nextSelection.focus;
    const anchorKey = anchor.key;
    const focusKey = focus.key;
    const anchorNode = nodeMap.get(anchorKey);
    const focusNode = nodeMap.get(focusKey);
    if (anchorNode == null || focusNode == null) {
        return;
    }
    let selectionRects;
    // In the case of a collapsed selection on a linebreak, we need
    // to improvise as the browser will return nothing here as <br>
    // apparently take up no visual space :/
    // This won't work in all cases, but it's better than just showing
    // nothing all the time.
    if (anchorNode === focusNode && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isLineBreakNode"])(anchorNode)) {
        const brRect = editor.getElementByKey(anchorKey).getBoundingClientRect();
        selectionRects = [
            brRect
        ];
    } else {
        const range = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createDOMRange"])(editor, anchorNode, anchor.offset, focusNode, focus.offset);
        if (range === null) {
            return;
        }
        selectionRects = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createRectsFromDOMRange"])(editor, range);
    }
    const selectionsLength = selections.length;
    const selectionRectsLength = selectionRects.length;
    for(let i = 0; i < selectionRectsLength; i++){
        const selectionRect = selectionRects[i];
        let selection = selections[i];
        if (selection === undefined) {
            selection = document.createElement('span');
            selections[i] = selection;
            const selectionBg = document.createElement('span');
            selection.appendChild(selectionBg);
            cursorsContainer.appendChild(selection);
        }
        const top = selectionRect.top - containerRect.top;
        const left = selectionRect.left - containerRect.left;
        const style = `position:absolute;top:${top}px;left:${left}px;height:${selectionRect.height}px;width:${selectionRect.width}px;pointer-events:none;z-index:5;`;
        selection.style.cssText = style;
        selection.firstChild.style.cssText = `${style}left:0;top:0;background-color:${color};opacity:0.3;`;
        if (i === selectionRectsLength - 1) {
            if (caret.parentNode !== selection) {
                selection.appendChild(caret);
            }
        }
    }
    for(let i = selectionsLength - 1; i >= selectionRectsLength; i--){
        const selection = selections[i];
        cursorsContainer.removeChild(selection);
        selections.pop();
    }
}
/**
 * @deprecated Use `$getAnchorAndFocusForUserState` instead.
 */ function getAnchorAndFocusCollabNodesForUserState(binding, userState) {
    const { anchorPos, focusPos } = userState;
    let anchorCollabNode = null;
    let anchorOffset = 0;
    let focusCollabNode = null;
    let focusOffset = 0;
    if (anchorPos !== null && focusPos !== null) {
        const anchorAbsPos = createAbsolutePosition(anchorPos, binding);
        const focusAbsPos = createAbsolutePosition(focusPos, binding);
        if (anchorAbsPos !== null && focusAbsPos !== null) {
            [anchorCollabNode, anchorOffset] = getCollabNodeAndOffset(anchorAbsPos.type, anchorAbsPos.index);
            [focusCollabNode, focusOffset] = getCollabNodeAndOffset(focusAbsPos.type, focusAbsPos.index);
        }
    }
    return {
        anchorCollabNode,
        anchorOffset,
        focusCollabNode,
        focusOffset
    };
}
function $getAnchorAndFocusForUserState(binding, userState) {
    const { anchorPos, focusPos } = userState;
    const anchorAbsPos = anchorPos ? createAbsolutePosition(anchorPos, binding) : null;
    const focusAbsPos = focusPos ? createAbsolutePosition(focusPos, binding) : null;
    if (anchorAbsPos === null || focusAbsPos === null) {
        return {
            anchorKey: null,
            anchorOffset: 0,
            focusKey: null,
            focusOffset: 0
        };
    }
    if (isBindingV1(binding)) {
        const [anchorCollabNode, anchorOffset] = getCollabNodeAndOffset(anchorAbsPos.type, anchorAbsPos.index);
        const [focusCollabNode, focusOffset] = getCollabNodeAndOffset(focusAbsPos.type, focusAbsPos.index);
        return {
            anchorKey: anchorCollabNode !== null ? anchorCollabNode.getKey() : null,
            anchorOffset,
            focusKey: focusCollabNode !== null ? focusCollabNode.getKey() : null,
            focusOffset
        };
    }
    let [anchorNode, anchorOffset] = $getNodeAndOffsetV2(binding.mapping, anchorAbsPos);
    let [focusNode, focusOffset] = $getNodeAndOffsetV2(binding.mapping, focusAbsPos);
    // For a non-collapsed selection, if the start of the selection is as the end of a text node,
    // move it to the beginning of the next text node (if one exists).
    if (focusNode && anchorNode && (focusNode !== anchorNode || focusOffset !== anchorOffset)) {
        const isBackwards = focusNode.isBefore(anchorNode);
        const startNode = isBackwards ? focusNode : anchorNode;
        const startOffset = isBackwards ? focusOffset : anchorOffset;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(startNode) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(startNode.getNextSibling()) && startOffset === startNode.getTextContentSize()) {
            if (isBackwards) {
                focusNode = startNode.getNextSibling();
                focusOffset = 0;
            } else {
                anchorNode = startNode.getNextSibling();
                anchorOffset = 0;
            }
        }
    }
    return {
        anchorKey: anchorNode !== null ? anchorNode.getKey() : null,
        anchorOffset,
        focusKey: focusNode !== null ? focusNode.getKey() : null,
        focusOffset
    };
}
function $syncLocalCursorPosition(binding, provider) {
    const awareness = provider.awareness;
    const localState = awareness.getLocalState();
    if (localState === null) {
        return;
    }
    const { anchorKey, anchorOffset, focusKey, focusOffset } = $getAnchorAndFocusForUserState(binding, localState);
    if (anchorKey !== null && focusKey !== null) {
        const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(selection)) {
            return;
        }
        $setPoint(selection.anchor, anchorKey, anchorOffset);
        $setPoint(selection.focus, focusKey, focusOffset);
    }
}
function $setPoint(point, key, offset) {
    if (point.key !== key || point.offset !== offset) {
        let anchorNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(key);
        if (anchorNode !== null && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(anchorNode) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(anchorNode)) {
            const parent = anchorNode.getParentOrThrow();
            key = parent.getKey();
            offset = anchorNode.getIndexWithinParent();
            anchorNode = parent;
        }
        point.set(key, offset, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(anchorNode) ? 'element' : 'text');
    }
}
function getCollabNodeAndOffset(// eslint-disable-next-line @typescript-eslint/no-explicit-any
sharedType, offset) {
    const collabNode = sharedType._collabNode;
    if (collabNode === undefined) {
        return [
            null,
            0
        ];
    }
    if (collabNode instanceof CollabElementNode) {
        const { node, offset: collabNodeOffset } = getPositionFromElementAndOffset(collabNode, offset, true);
        if (node === null) {
            return [
                collabNode,
                0
            ];
        } else {
            return [
                node,
                collabNodeOffset
            ];
        }
    }
    return [
        null,
        0
    ];
}
function $getNodeAndOffsetV2(mapping, absolutePosition) {
    const yType = absolutePosition.type;
    const yOffset = absolutePosition.index;
    if (yType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"]) {
        const node = mapping.get(yType);
        if (node === undefined) {
            return [
                null,
                0
            ];
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(node)) {
            return [
                node,
                yOffset
            ];
        }
        let remainingYOffset = yOffset;
        let lexicalOffset = 0;
        const children = node.getChildren();
        while(remainingYOffset > 0 && lexicalOffset < children.length){
            const child = children[lexicalOffset];
            remainingYOffset -= 1;
            lexicalOffset += 1;
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(child)) {
                while(lexicalOffset < children.length && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(children[lexicalOffset])){
                    lexicalOffset += 1;
                }
            }
        }
        return [
            node,
            lexicalOffset
        ];
    } else {
        const nodes = mapping.get(yType);
        if (nodes === undefined) {
            return [
                null,
                0
            ];
        }
        let i = 0;
        let adjustedOffset = yOffset;
        while(adjustedOffset > nodes[i].getTextContentSize() && i + 1 < nodes.length){
            adjustedOffset -= nodes[i].getTextContentSize();
            i++;
        }
        const textNode = nodes[i];
        return [
            textNode,
            Math.min(adjustedOffset, textNode.getTextContentSize())
        ];
    }
}
function getAwarenessStatesDefault(_binding, provider) {
    return provider.awareness.getStates();
}
function syncCursorPositions(binding, provider, options) {
    const { getAwarenessStates = getAwarenessStatesDefault } = options ?? {};
    const awarenessStates = Array.from(getAwarenessStates(binding, provider));
    const localClientID = binding.clientID;
    const cursors = binding.cursors;
    const editor = binding.editor;
    const nodeMap = editor._editorState._nodeMap;
    const visitedClientIDs = new Set();
    for(let i = 0; i < awarenessStates.length; i++){
        const awarenessState = awarenessStates[i];
        const [clientID, awareness] = awarenessState;
        if (clientID !== 0 && clientID !== localClientID) {
            visitedClientIDs.add(clientID);
            const { name, color, focusing } = awareness;
            let selection = null;
            let cursor = cursors.get(clientID);
            if (cursor === undefined) {
                cursor = createCursor(name, color);
                cursors.set(clientID, cursor);
            }
            if (focusing) {
                const { anchorKey, anchorOffset, focusKey, focusOffset } = editor.read(()=>$getAnchorAndFocusForUserState(binding, awareness));
                if (anchorKey !== null && focusKey !== null) {
                    selection = cursor.selection;
                    if (selection === null) {
                        selection = createCursorSelection(cursor, anchorKey, anchorOffset, focusKey, focusOffset);
                    } else {
                        const anchor = selection.anchor;
                        const focus = selection.focus;
                        anchor.key = anchorKey;
                        anchor.offset = anchorOffset;
                        focus.key = focusKey;
                        focus.offset = focusOffset;
                    }
                }
            }
            updateCursor(binding, cursor, selection, nodeMap);
        }
    }
    const allClientIDs = Array.from(cursors.keys());
    for(let i = 0; i < allClientIDs.length; i++){
        const clientID = allClientIDs[i];
        if (!visitedClientIDs.has(clientID)) {
            const cursor = cursors.get(clientID);
            if (cursor !== undefined) {
                destroyCursor(binding, cursor);
                cursors.delete(clientID);
            }
        }
    }
}
function syncLexicalSelectionToYjs(binding, provider, prevSelection, nextSelection) {
    const awareness = provider.awareness;
    const localState = awareness.getLocalState();
    if (localState === null) {
        return;
    }
    const { anchorPos: currentAnchorPos, focusPos: currentFocusPos, name, color, focusing, awarenessData } = localState;
    let anchorPos = null;
    let focusPos = null;
    if (nextSelection === null || currentAnchorPos !== null && !nextSelection.is(prevSelection)) {
        if (prevSelection === null) {
            return;
        }
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(nextSelection)) {
        if (isBindingV1(binding)) {
            anchorPos = createRelativePosition(nextSelection.anchor, binding);
            focusPos = createRelativePosition(nextSelection.focus, binding);
        } else {
            anchorPos = createRelativePositionV2(nextSelection.anchor, binding);
            focusPos = createRelativePositionV2(nextSelection.focus, binding);
        }
    }
    if (shouldUpdatePosition(currentAnchorPos, anchorPos) || shouldUpdatePosition(currentFocusPos, focusPos)) {
        awareness.setLocalState({
            ...localState,
            anchorPos,
            awarenessData,
            color,
            focusPos,
            focusing,
            name
        });
    }
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function $syncStateEvent(binding, event) {
    const { target } = event;
    if (!(target._item && target._item.parentSub === '__state' && getNodeTypeFromSharedType(target) === undefined && (target.parent instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"] || target.parent instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"] || target.parent instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Map"]))) {
        // TODO there might be a case to handle in here when a YMap
        // is used as a value  of __state? It would probably be desirable
        // to mark the node as dirty when that happens.
        return false;
    }
    const collabNode = $getOrInitCollabNodeFromSharedType(binding, target.parent);
    const node = collabNode.getNode();
    if (node) {
        const state = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getWritableNodeState"])(node.getWritable());
        for (const k of event.keysChanged){
            state.updateFromUnknown(k, target.get(k));
        }
    }
    return true;
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function $syncEvent(binding, event) {
    if (event instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YMapEvent"] && $syncStateEvent(binding, event)) {
        return;
    }
    const { target } = event;
    const collabNode = $getOrInitCollabNodeFromSharedType(binding, target);
    if (collabNode instanceof CollabElementNode && event instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YTextEvent"]) {
        // @ts-expect-error We need to access the private childListChanged property of the class
        const { keysChanged, childListChanged, delta } = event;
        // Update
        if (keysChanged.size > 0) {
            collabNode.syncPropertiesFromYjs(binding, keysChanged);
        }
        if (childListChanged) {
            collabNode.applyChildrenYjsDelta(binding, delta);
            collabNode.syncChildrenFromYjs(binding);
        }
    } else if (collabNode instanceof CollabTextNode && event instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YMapEvent"]) {
        const { keysChanged } = event;
        // Update
        if (keysChanged.size > 0) {
            collabNode.syncPropertiesAndTextFromYjs(binding, keysChanged);
        }
    } else if (collabNode instanceof CollabDecoratorNode && event instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YXmlEvent"]) {
        const { attributesChanged } = event;
        // Update
        if (attributesChanged.size > 0) {
            collabNode.syncPropertiesFromYjs(binding, attributesChanged);
        }
    } else {
        {
            formatDevErrorMessage(`Expected text, element, or decorator event`);
        }
    }
}
function syncYjsChangesToLexical(binding, provider, events, isFromUndoManger, syncCursorPositionsFn = syncCursorPositions) {
    const editor = binding.editor;
    const currentEditorState = editor._editorState;
    // This line precompute the delta before editor update. The reason is
    // delta is computed when it is accessed. Note that this can only be
    // safely computed during the event call. If it is accessed after event
    // call it might result in unexpected behavior.
    // https://github.com/yjs/yjs/blob/00ef472d68545cb260abd35c2de4b3b78719c9e4/src/utils/YEvent.js#L132
    events.forEach((event)=>event.delta);
    editor.update(()=>{
        for(let i = 0; i < events.length; i++){
            const event = events[i];
            $syncEvent(binding, event);
        }
        $syncCursorFromYjs(currentEditorState, binding, provider);
        if (!isFromUndoManger) {
            // If it is an external change, we don't want the current scroll position to get changed
            // since the user might've intentionally scrolled somewhere else in the document.
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$addUpdateTag"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SKIP_SCROLL_INTO_VIEW_TAG"]);
        }
    }, {
        onUpdate: ()=>{
            syncCursorPositionsFn(binding, provider);
            editor.update(()=>$ensureEditorNotEmpty());
        },
        skipTransforms: true,
        tag: isFromUndoManger ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HISTORIC_TAG"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLLABORATION_TAG"]
    });
}
function $syncCursorFromYjs(editorState, binding, provider) {
    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(selection)) {
        if (doesSelectionNeedRecovering(selection)) {
            const prevSelection = editorState._selection;
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(prevSelection)) {
                $syncLocalCursorPosition(binding, provider);
                if (doesSelectionNeedRecovering(selection)) {
                    // If the selected node is deleted, move the selection to the previous or parent node.
                    const anchorNodeKey = selection.anchor.key;
                    $moveSelectionToPreviousNode(anchorNodeKey, editorState);
                }
            }
            syncLexicalSelectionToYjs(binding, provider, prevSelection, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])());
        } else {
            $syncLocalCursorPosition(binding, provider);
        }
    }
}
function $handleNormalizationMergeConflicts(binding, normalizedNodes) {
    // We handle the merge operations here
    const normalizedNodesKeys = Array.from(normalizedNodes);
    const collabNodeMap = binding.collabNodeMap;
    const mergedNodes = [];
    const removedNodes = [];
    for(let i = 0; i < normalizedNodesKeys.length; i++){
        const nodeKey = normalizedNodesKeys[i];
        const lexicalNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
        const collabNode = collabNodeMap.get(nodeKey);
        if (collabNode instanceof CollabTextNode) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(lexicalNode)) {
                // We mutate the text collab nodes after removing
                // all the dead nodes first, otherwise offsets break.
                mergedNodes.push([
                    collabNode,
                    lexicalNode.__text
                ]);
            } else {
                const offset = collabNode.getOffset();
                if (offset === -1) {
                    continue;
                }
                const parent = collabNode._parent;
                collabNode._normalized = true;
                parent._xmlText.delete(offset, 1);
                removedNodes.push(collabNode);
            }
        }
    }
    for(let i = 0; i < removedNodes.length; i++){
        const collabNode = removedNodes[i];
        const nodeKey = collabNode.getKey();
        collabNodeMap.delete(nodeKey);
        const parentChildren = collabNode._parent._children;
        const index = parentChildren.indexOf(collabNode);
        parentChildren.splice(index, 1);
    }
    for(let i = 0; i < mergedNodes.length; i++){
        const [collabNode, text] = mergedNodes[i];
        collabNode._text = text;
    }
}
// If there was a collision on the top level paragraph
// we need to re-add a paragraph. To ensure this insertion properly syncs with other clients,
// it must be placed outside of the update block above that has tags 'collaboration' or 'historic'.
function $ensureEditorNotEmpty() {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().getChildrenSize() === 0) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().append((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])());
    }
}
function syncLexicalUpdateToYjs(binding, provider, prevEditorState, currEditorState, dirtyElements, dirtyLeaves, normalizedNodes, tags) {
    syncWithTransaction(binding, ()=>{
        currEditorState.read(()=>{
            // We check if the update has come from a origin where the origin
            // was the collaboration binding previously. This can help us
            // prevent unnecessarily re-diffing and possible re-applying
            // the same change editor state again. For example, if a user
            // types a character and we get it, we don't want to then insert
            // the same character again. The exception to this heuristic is
            // when we need to handle normalization merge conflicts.
            if (tags.has(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLLABORATION_TAG"]) || tags.has(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HISTORIC_TAG"])) {
                if (normalizedNodes.size > 0) {
                    $handleNormalizationMergeConflicts(binding, normalizedNodes);
                }
                return;
            }
            if (dirtyElements.has('root')) {
                const prevNodeMap = prevEditorState._nodeMap;
                const nextLexicalRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
                const collabRoot = binding.root;
                collabRoot.syncPropertiesFromLexical(binding, nextLexicalRoot, prevNodeMap);
                collabRoot.syncChildrenFromLexical(binding, nextLexicalRoot, prevNodeMap, dirtyElements, dirtyLeaves);
            }
            const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
            const prevSelection = prevEditorState._selection;
            syncLexicalSelectionToYjs(binding, provider, prevSelection, selection);
        });
    });
}
function $syncEventV2(binding, event) {
    const { target } = event;
    if (target instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"] && event instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YXmlEvent"]) {
        $createOrUpdateNodeFromYElement(target, binding, event.attributesChanged, // @ts-expect-error childListChanged is private
        event.childListChanged);
    } else if (target instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlText"] && event instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YTextEvent"]) {
        const parent = target.parent;
        if (parent instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XmlElement"]) {
            // Need to sync via parent element in order to attach new next nodes.
            $createOrUpdateNodeFromYElement(parent, binding, new Set(), true);
        } else {
            {
                formatDevErrorMessage(`Expected XmlElement parent for XmlText`);
            }
        }
    } else {
        {
            formatDevErrorMessage(`Expected xml or text event`);
        }
    }
}
function syncYjsChangesToLexicalV2__EXPERIMENTAL(binding, provider, events, transaction, isFromUndoManger) {
    const editor = binding.editor;
    const editorState = editor._editorState;
    // Remove deleted nodes from the mapping
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["iterateDeletedStructs"])(transaction, transaction.deleteSet, (struct)=>{
        if (struct.constructor === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Item"]) {
            const content = struct.content;
            const type = content.type;
            if (type) {
                binding.mapping.delete(type);
            }
        }
    });
    // This line precompute the delta before editor update. The reason is
    // delta is computed when it is accessed. Note that this can only be
    // safely computed during the event call. If it is accessed after event
    // call it might result in unexpected behavior.
    // https://github.com/yjs/yjs/blob/00ef472d68545cb260abd35c2de4b3b78719c9e4/src/utils/YEvent.js#L132
    events.forEach((event)=>event.delta);
    editor.update(()=>{
        for(let i = 0; i < events.length; i++){
            const event = events[i];
            $syncEventV2(binding, event);
        }
        $syncCursorFromYjs(editorState, binding, provider);
        if (!isFromUndoManger) {
            // If it is an external change, we don't want the current scroll position to get changed
            // since the user might've intentionally scrolled somewhere else in the document.
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$addUpdateTag"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SKIP_SCROLL_INTO_VIEW_TAG"]);
        }
    }, {
        // Need any text node normalization to be synchronously updated back to Yjs, otherwise the
        // binding.mapping will get out of sync.
        discrete: true,
        onUpdate: ()=>{
            syncCursorPositions(binding, provider);
            editor.update(()=>$ensureEditorNotEmpty());
        },
        skipTransforms: true,
        tag: isFromUndoManger ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HISTORIC_TAG"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLLABORATION_TAG"]
    });
}
function syncYjsStateToLexicalV2__EXPERIMENTAL(binding, provider) {
    binding.mapping.clear();
    const editor = binding.editor;
    editor.update(()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().clear();
        $createOrUpdateNodeFromYElement(binding.root, binding, null, true);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$addUpdateTag"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLLABORATION_TAG"]);
    }, {
        // Need any text node normalization to be synchronously updated back to Yjs, otherwise the
        // binding.mapping will get out of sync.
        discrete: true,
        onUpdate: ()=>{
            syncCursorPositions(binding, provider);
            editor.update(()=>$ensureEditorNotEmpty());
        },
        skipTransforms: true,
        tag: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLLABORATION_TAG"]
    });
}
function syncLexicalUpdateToYjsV2__EXPERIMENTAL(binding, provider, prevEditorState, currEditorState, dirtyElements, normalizedNodes, tags) {
    const isFromYjs = tags.has(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLLABORATION_TAG"]) || tags.has(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HISTORIC_TAG"]);
    if (isFromYjs && normalizedNodes.size === 0) {
        return;
    }
    // Nodes are normalized synchronously (`discrete: true` above), so the mapping may now be
    // incorrect for these nodes, as they point to `getLatest` which is mutable within an update.
    normalizedNodes.forEach((nodeKey)=>{
        binding.mapping.deleteNode(nodeKey);
    });
    syncWithTransaction(binding, ()=>{
        currEditorState.read(()=>{
            if (dirtyElements.has('root')) {
                $updateYFragment(binding.doc, binding.root, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])(), binding, new Set(dirtyElements.keys()));
            }
            const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
            const prevSelection = prevEditorState._selection;
            syncLexicalSelectionToYjs(binding, provider, prevSelection, selection);
        });
    });
}
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ const CONNECTED_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('CONNECTED_COMMAND');
const TOGGLE_CONNECT_COMMAND = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('TOGGLE_CONNECT_COMMAND');
const DIFF_VERSIONS_COMMAND__EXPERIMENTAL = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('DIFF_VERSIONS_COMMAND');
const CLEAR_DIFF_VERSIONS_COMMAND__EXPERIMENTAL = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])('CLEAR_DIFF_VERSIONS_COMMAND');
function createUndoManager(binding, root) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UndoManager"](root, {
        trackedOrigins: new Set([
            binding,
            null
        ])
    });
}
function initLocalState(provider, name, color, focusing, awarenessData) {
    provider.awareness.setLocalState({
        anchorPos: null,
        awarenessData,
        color,
        focusPos: null,
        focusing: focusing,
        name
    });
}
function setLocalStateFocus(provider, name, color, focusing, awarenessData) {
    const { awareness } = provider;
    let localState = awareness.getLocalState();
    if (localState === null) {
        localState = {
            anchorPos: null,
            awarenessData,
            color,
            focusPos: null,
            focusing: focusing,
            name
        };
    }
    localState.focusing = focusing;
    awareness.setLocalState(localState);
}
;
}),
"[project]/node_modules/@lexical/react/LexicalCollaborationPlugin.dev.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CollaborationPlugin",
    ()=>CollaborationPlugin,
    "CollaborationPluginV2__EXPERIMENTAL",
    ()=>CollaborationPluginV2__EXPERIMENTAL
]);
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalCollaborationContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalCollaborationContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/node_modules/@lexical/yjs/LexicalYjs.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/yjs/dist/yjs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ function useYjsCollaboration(editor, id, provider, docMap, name, color, shouldBootstrap, binding, setDoc, cursorsContainerRef, initialEditorState, awarenessData, syncCursorPositionsFn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["syncCursorPositions"]) {
    const isReloadingDoc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const onBootstrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useYjsCollaboration.useCallback[onBootstrap]": ()=>{
            const { root } = binding;
            if (shouldBootstrap && root.isEmpty() && root._xmlText._length === 0) {
                initializeEditor(editor, initialEditorState);
            }
        }
    }["useYjsCollaboration.useCallback[onBootstrap]"], [
        binding,
        editor,
        initialEditorState,
        shouldBootstrap
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsCollaboration.useEffect": ()=>{
            const { root } = binding;
            const onYjsTreeChanges = {
                "useYjsCollaboration.useEffect.onYjsTreeChanges": (events, transaction)=>{
                    const origin = transaction.origin;
                    if (origin !== binding) {
                        const isFromUndoManger = origin instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UndoManager"];
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["syncYjsChangesToLexical"])(binding, provider, events, isFromUndoManger, syncCursorPositionsFn);
                    }
                }
            }["useYjsCollaboration.useEffect.onYjsTreeChanges"];
            // This updates the local editor state when we receive updates from other clients
            root.getSharedType().observeDeep(onYjsTreeChanges);
            const removeListener = editor.registerUpdateListener({
                "useYjsCollaboration.useEffect.removeListener": ({ prevEditorState, editorState, dirtyLeaves, dirtyElements, normalizedNodes, tags })=>{
                    if (!tags.has(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SKIP_COLLAB_TAG"])) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["syncLexicalUpdateToYjs"])(binding, provider, prevEditorState, editorState, dirtyElements, dirtyLeaves, normalizedNodes, tags);
                    }
                }
            }["useYjsCollaboration.useEffect.removeListener"]);
            return ({
                "useYjsCollaboration.useEffect": ()=>{
                    root.getSharedType().unobserveDeep(onYjsTreeChanges);
                    removeListener();
                }
            })["useYjsCollaboration.useEffect"];
        }
    }["useYjsCollaboration.useEffect"], [
        binding,
        provider,
        editor,
        setDoc,
        docMap,
        id,
        syncCursorPositionsFn
    ]);
    // Note: 'reload' is not an actual Yjs event type. Included here for legacy support (#1409).
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsCollaboration.useEffect": ()=>{
            const onProviderDocReload = {
                "useYjsCollaboration.useEffect.onProviderDocReload": (ydoc)=>{
                    clearEditorSkipCollab(editor, binding);
                    setDoc(ydoc);
                    docMap.set(id, ydoc);
                    isReloadingDoc.current = true;
                }
            }["useYjsCollaboration.useEffect.onProviderDocReload"];
            const onSync = {
                "useYjsCollaboration.useEffect.onSync": ()=>{
                    isReloadingDoc.current = false;
                }
            }["useYjsCollaboration.useEffect.onSync"];
            provider.on('reload', onProviderDocReload);
            provider.on('sync', onSync);
            return ({
                "useYjsCollaboration.useEffect": ()=>{
                    provider.off('reload', onProviderDocReload);
                    provider.off('sync', onSync);
                }
            })["useYjsCollaboration.useEffect"];
        }
    }["useYjsCollaboration.useEffect"], [
        binding,
        provider,
        editor,
        setDoc,
        docMap,
        id
    ]);
    useProvider(editor, provider, name, color, isReloadingDoc, awarenessData, onBootstrap);
    useAwareness(binding, provider);
    return useYjsCursors(binding, cursorsContainerRef);
}
function useYjsCollaborationV2__EXPERIMENTAL(editor, id, doc, provider, docMap, name, color, options = {}) {
    const { awarenessData, excludedProperties, rootName, __shouldBootstrapUnsafe: shouldBootstrap } = options;
    // Note: v2 does not support 'reload' event, which is not an actual Yjs event type.
    const isReloadingDoc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useYjsCollaborationV2__EXPERIMENTAL.useMemo[isReloadingDoc]": ()=>({
                current: false
            })
    }["useYjsCollaborationV2__EXPERIMENTAL.useMemo[isReloadingDoc]"], []);
    const binding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useYjsCollaborationV2__EXPERIMENTAL.useMemo[binding]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBindingV2__EXPERIMENTAL"])(editor, id, doc, docMap, {
                excludedProperties,
                rootName
            })
    }["useYjsCollaborationV2__EXPERIMENTAL.useMemo[binding]"], [
        editor,
        id,
        doc,
        docMap,
        excludedProperties,
        rootName
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsCollaborationV2__EXPERIMENTAL.useEffect": ()=>{
            docMap.set(id, doc);
            return ({
                "useYjsCollaborationV2__EXPERIMENTAL.useEffect": ()=>{
                    docMap.delete(id);
                }
            })["useYjsCollaborationV2__EXPERIMENTAL.useEffect"];
        }
    }["useYjsCollaborationV2__EXPERIMENTAL.useEffect"], [
        doc,
        docMap,
        id
    ]);
    const onBootstrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useYjsCollaborationV2__EXPERIMENTAL.useCallback[onBootstrap]": ()=>{
            const { root } = binding;
            if (shouldBootstrap && root._length === 0) {
                initializeEditor(editor);
            }
        }
    }["useYjsCollaborationV2__EXPERIMENTAL.useCallback[onBootstrap]"], [
        binding,
        editor,
        shouldBootstrap
    ]);
    const [diffSnapshots, setDiffSnapshots] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsCollaborationV2__EXPERIMENTAL.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CLEAR_DIFF_VERSIONS_COMMAND__EXPERIMENTAL"], {
                "useYjsCollaborationV2__EXPERIMENTAL.useEffect": ()=>{
                    setDiffSnapshots(null);
                    // Ensure that any state already in Yjs is loaded into the editor (eg: after clearing diff view).
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["syncYjsStateToLexicalV2__EXPERIMENTAL"])(binding, provider);
                    return true;
                }
            }["useYjsCollaborationV2__EXPERIMENTAL.useEffect"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DIFF_VERSIONS_COMMAND__EXPERIMENTAL"], {
                "useYjsCollaborationV2__EXPERIMENTAL.useEffect": ({ prevSnapshot, snapshot })=>{
                    setDiffSnapshots({
                        prevSnapshot,
                        snapshot
                    });
                    return true;
                }
            }["useYjsCollaborationV2__EXPERIMENTAL.useEffect"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]));
        }
    }["useYjsCollaborationV2__EXPERIMENTAL.useEffect"], [
        editor,
        binding,
        provider
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsCollaborationV2__EXPERIMENTAL.useEffect": ()=>{
            const { root } = binding;
            if (diffSnapshots) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderSnapshot__EXPERIMENTAL"])(binding, diffSnapshots.snapshot, diffSnapshots.prevSnapshot);
                return;
            }
            const onYjsTreeChanges = {
                "useYjsCollaborationV2__EXPERIMENTAL.useEffect.onYjsTreeChanges": (events, transaction)=>{
                    const origin = transaction.origin;
                    if (origin !== binding) {
                        const isFromUndoManger = origin instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UndoManager"];
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["syncYjsChangesToLexicalV2__EXPERIMENTAL"])(binding, provider, events, transaction, isFromUndoManger);
                    }
                }
            }["useYjsCollaborationV2__EXPERIMENTAL.useEffect.onYjsTreeChanges"];
            // This updates the local editor state when we receive updates from other clients
            root.observeDeep(onYjsTreeChanges);
            const removeListener = editor.registerUpdateListener({
                "useYjsCollaborationV2__EXPERIMENTAL.useEffect.removeListener": ({ prevEditorState, editorState, dirtyElements, normalizedNodes, tags })=>{
                    if (!tags.has(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SKIP_COLLAB_TAG"])) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["syncLexicalUpdateToYjsV2__EXPERIMENTAL"])(binding, provider, prevEditorState, editorState, dirtyElements, normalizedNodes, tags);
                    }
                }
            }["useYjsCollaborationV2__EXPERIMENTAL.useEffect.removeListener"]);
            return ({
                "useYjsCollaborationV2__EXPERIMENTAL.useEffect": ()=>{
                    root.unobserveDeep(onYjsTreeChanges);
                    removeListener();
                }
            })["useYjsCollaborationV2__EXPERIMENTAL.useEffect"];
        }
    }["useYjsCollaborationV2__EXPERIMENTAL.useEffect"], [
        binding,
        provider,
        editor,
        diffSnapshots
    ]);
    useProvider(editor, provider, name, color, isReloadingDoc, awarenessData, onBootstrap);
    useAwareness(binding, provider);
    return binding;
}
function useProvider(editor, provider, name, color, isReloadingDoc, awarenessData, onBootstrap) {
    const connect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useProvider.useCallback[connect]": ()=>provider.connect()
    }["useProvider.useCallback[connect]"], [
        provider
    ]);
    const disconnect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useProvider.useCallback[disconnect]": ()=>{
            try {
                provider.disconnect();
            } catch (_e) {
            // Do nothing
            }
        }
    }["useProvider.useCallback[disconnect]"], [
        provider
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useProvider.useEffect": ()=>{
            const onStatus = {
                "useProvider.useEffect.onStatus": ({ status })=>{
                    editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONNECTED_COMMAND"], status === 'connected');
                }
            }["useProvider.useEffect.onStatus"];
            const onSync = {
                "useProvider.useEffect.onSync": (isSynced)=>{
                    if (isSynced && isReloadingDoc.current === false && onBootstrap) {
                        onBootstrap();
                    }
                }
            }["useProvider.useEffect.onSync"];
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initLocalState"])(provider, name, color, document.activeElement === editor.getRootElement(), awarenessData || {});
            provider.on('status', onStatus);
            provider.on('sync', onSync);
            const connectionPromise = connect();
            return ({
                "useProvider.useEffect": ()=>{
                    // eslint-disable-next-line react-hooks/exhaustive-deps -- expected that isReloadingDoc.current may change
                    if (isReloadingDoc.current === false) {
                        if (connectionPromise) {
                            connectionPromise.then(disconnect);
                        } else {
                            // Workaround for race condition in StrictMode. It's possible there
                            // is a different race for the above case where connect returns a
                            // promise, but we don't have an example of that in-repo.
                            // It's possible that there is a similar issue with
                            // TOGGLE_CONNECT_COMMAND below when the provider connect returns a
                            // promise.
                            // https://github.com/facebook/lexical/issues/6640
                            disconnect();
                        }
                    }
                    provider.off('sync', onSync);
                    provider.off('status', onStatus);
                }
            })["useProvider.useEffect"];
        }
    }["useProvider.useEffect"], [
        editor,
        provider,
        name,
        color,
        isReloadingDoc,
        awarenessData,
        onBootstrap,
        connect,
        disconnect
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useProvider.useEffect": ()=>{
            return editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TOGGLE_CONNECT_COMMAND"], {
                "useProvider.useEffect": (payload)=>{
                    const shouldConnect = payload;
                    if (shouldConnect) {
                        // eslint-disable-next-line no-console
                        console.log('Collaboration connected!');
                        connect();
                    } else {
                        // eslint-disable-next-line no-console
                        console.log('Collaboration disconnected!');
                        disconnect();
                    }
                    return true;
                }
            }["useProvider.useEffect"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
        }
    }["useProvider.useEffect"], [
        connect,
        disconnect,
        editor
    ]);
}
function useAwareness(binding, provider) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAwareness.useEffect": ()=>{
            const { awareness } = provider;
            const onAwarenessUpdate = {
                "useAwareness.useEffect.onAwarenessUpdate": ()=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["syncCursorPositions"])(binding, provider);
                }
            }["useAwareness.useEffect.onAwarenessUpdate"];
            awareness.on('update', onAwarenessUpdate);
            return ({
                "useAwareness.useEffect": ()=>{
                    awareness.off('update', onAwarenessUpdate);
                }
            })["useAwareness.useEffect"];
        }
    }["useAwareness.useEffect"], [
        binding,
        provider
    ]);
}
function useYjsCursors(binding, cursorsContainerRef) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useYjsCursors.useMemo": ()=>{
            const ref = {
                "useYjsCursors.useMemo.ref": (element)=>{
                    binding.cursorsContainer = element;
                }
            }["useYjsCursors.useMemo.ref"];
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                ref: ref
            }), cursorsContainerRef && cursorsContainerRef.current || document.body);
        }
    }["useYjsCursors.useMemo"], [
        binding,
        cursorsContainerRef
    ]);
}
function useYjsFocusTracking(editor, provider, name, color, awarenessData) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsFocusTracking.useEffect": ()=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FOCUS_COMMAND"], {
                "useYjsFocusTracking.useEffect": ()=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setLocalStateFocus"])(provider, name, color, true, awarenessData || {});
                    return false;
                }
            }["useYjsFocusTracking.useEffect"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BLUR_COMMAND"], {
                "useYjsFocusTracking.useEffect": ()=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setLocalStateFocus"])(provider, name, color, false, awarenessData || {});
                    return false;
                }
            }["useYjsFocusTracking.useEffect"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]));
        }
    }["useYjsFocusTracking.useEffect"], [
        color,
        editor,
        name,
        provider,
        awarenessData
    ]);
}
function useYjsHistory(editor, binding) {
    const undoManager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useYjsHistory.useMemo[undoManager]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUndoManager"])(binding, binding.root.getSharedType())
    }["useYjsHistory.useMemo[undoManager]"], [
        binding
    ]);
    return useYjsUndoManager(editor, undoManager);
}
function useYjsHistoryV2(editor, binding) {
    const undoManager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useYjsHistoryV2.useMemo[undoManager]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUndoManager"])(binding, binding.root)
    }["useYjsHistoryV2.useMemo[undoManager]"], [
        binding
    ]);
    return useYjsUndoManager(editor, undoManager);
}
function useYjsUndoManager(editor, undoManager) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsUndoManager.useEffect": ()=>{
            const undo = {
                "useYjsUndoManager.useEffect.undo": ()=>{
                    undoManager.undo();
                }
            }["useYjsUndoManager.useEffect.undo"];
            const redo = {
                "useYjsUndoManager.useEffect.redo": ()=>{
                    undoManager.redo();
                }
            }["useYjsUndoManager.useEffect.redo"];
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNDO_COMMAND"], {
                "useYjsUndoManager.useEffect": ()=>{
                    undo();
                    return true;
                }
            }["useYjsUndoManager.useEffect"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REDO_COMMAND"], {
                "useYjsUndoManager.useEffect": ()=>{
                    redo();
                    return true;
                }
            }["useYjsUndoManager.useEffect"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]));
        }
    }["useYjsUndoManager.useEffect"]);
    const clearHistory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useYjsUndoManager.useCallback[clearHistory]": ()=>{
            undoManager.clear();
        }
    }["useYjsUndoManager.useCallback[clearHistory]"], [
        undoManager
    ]);
    // Exposing undo and redo states
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "useYjsUndoManager.useEffect": ()=>{
            const updateUndoRedoStates = {
                "useYjsUndoManager.useEffect.updateUndoRedoStates": ()=>{
                    editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CAN_UNDO_COMMAND"], undoManager.undoStack.length > 0);
                    editor.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CAN_REDO_COMMAND"], undoManager.redoStack.length > 0);
                }
            }["useYjsUndoManager.useEffect.updateUndoRedoStates"];
            undoManager.on('stack-item-added', updateUndoRedoStates);
            undoManager.on('stack-item-popped', updateUndoRedoStates);
            undoManager.on('stack-cleared', updateUndoRedoStates);
            return ({
                "useYjsUndoManager.useEffect": ()=>{
                    undoManager.off('stack-item-added', updateUndoRedoStates);
                    undoManager.off('stack-item-popped', updateUndoRedoStates);
                    undoManager.off('stack-cleared', updateUndoRedoStates);
                }
            })["useYjsUndoManager.useEffect"];
        }
    }["useYjsUndoManager.useEffect"], [
        editor,
        undoManager
    ]);
    return clearHistory;
}
function initializeEditor(editor, initialEditorState) {
    editor.update(()=>{
        const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
        if (root.isEmpty()) {
            if (initialEditorState) {
                switch(typeof initialEditorState){
                    case 'string':
                        {
                            const parsedEditorState = editor.parseEditorState(initialEditorState);
                            editor.setEditorState(parsedEditorState, {
                                tag: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HISTORY_MERGE_TAG"]
                            });
                            break;
                        }
                    case 'object':
                        {
                            editor.setEditorState(initialEditorState, {
                                tag: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HISTORY_MERGE_TAG"]
                            });
                            break;
                        }
                    case 'function':
                        {
                            editor.update(()=>{
                                const root1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
                                if (root1.isEmpty()) {
                                    initialEditorState(editor);
                                }
                            }, {
                                tag: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HISTORY_MERGE_TAG"]
                            });
                            break;
                        }
                }
            } else {
                const paragraph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])();
                root.append(paragraph);
                const { activeElement } = document;
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])() !== null || activeElement !== null && activeElement === editor.getRootElement()) {
                    paragraph.select();
                }
            }
        }
    }, {
        tag: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HISTORY_MERGE_TAG"]
    });
}
function clearEditorSkipCollab(editor, binding) {
    // reset editor state
    editor.update(()=>{
        const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
        root.clear();
        root.select();
    }, {
        tag: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SKIP_COLLAB_TAG"]
    });
    if (binding.cursors == null) {
        return;
    }
    const cursors = binding.cursors;
    if (cursors == null) {
        return;
    }
    const cursorsContainer = binding.cursorsContainer;
    if (cursorsContainer == null) {
        return;
    }
    // reset cursors in dom
    const cursorsArr = Array.from(cursors.values());
    for(let i = 0; i < cursorsArr.length; i++){
        const cursor = cursorsArr[i];
        const selection = cursor.selection;
        if (selection && selection.selections != null) {
            const selections = selection.selections;
            for(let j = 0; j < selections.length; j++){
                cursorsContainer.removeChild(selections[i]);
            }
        }
    }
}
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ function CollaborationPlugin({ id, providerFactory, shouldBootstrap, username, cursorColor, cursorsContainerRef, initialEditorState, excludedProperties, awarenessData, syncCursorPositionsFn }) {
    const isBindingInitialized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const isProviderInitialized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const collabContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalCollaborationContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCollaborationContext"])(username, cursorColor);
    const { yjsDocMap, name, color } = collabContext;
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    useCollabActive(collabContext, editor);
    const [provider, setProvider] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    const [doc, setDoc] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CollaborationPlugin.useEffect": ()=>{
            if (isProviderInitialized.current) {
                return;
            }
            isProviderInitialized.current = true;
            const newProvider = providerFactory(id, yjsDocMap);
            setProvider(newProvider);
            setDoc(yjsDocMap.get(id));
            return ({
                "CollaborationPlugin.useEffect": ()=>{
                    newProvider.disconnect();
                }
            })["CollaborationPlugin.useEffect"];
        }
    }["CollaborationPlugin.useEffect"], [
        id,
        providerFactory,
        yjsDocMap
    ]);
    const [binding, setBinding] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CollaborationPlugin.useEffect": ()=>{
            if (!provider) {
                return;
            }
            if (isBindingInitialized.current) {
                return;
            }
            isBindingInitialized.current = true;
            const newBinding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$node_modules$2f40$lexical$2f$yjs$2f$LexicalYjs$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBinding"])(editor, provider, id, doc || yjsDocMap.get(id), yjsDocMap, excludedProperties);
            setBinding(newBinding);
            return ({
                "CollaborationPlugin.useEffect": ()=>{
                    newBinding.root.destroy(newBinding);
                }
            })["CollaborationPlugin.useEffect"];
        }
    }["CollaborationPlugin.useEffect"], [
        editor,
        provider,
        id,
        yjsDocMap,
        doc,
        excludedProperties
    ]);
    if (!provider || !binding) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {});
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(YjsCollaborationCursors, {
        awarenessData: awarenessData,
        binding: binding,
        collabContext: collabContext,
        color: color,
        cursorsContainerRef: cursorsContainerRef,
        editor: editor,
        id: id,
        initialEditorState: initialEditorState,
        name: name,
        provider: provider,
        setDoc: setDoc,
        shouldBootstrap: shouldBootstrap,
        yjsDocMap: yjsDocMap,
        syncCursorPositionsFn: syncCursorPositionsFn
    });
}
function YjsCollaborationCursors({ editor, id, provider, yjsDocMap, name, color, shouldBootstrap, cursorsContainerRef, initialEditorState, awarenessData, collabContext, binding, setDoc, syncCursorPositionsFn }) {
    const cursors = useYjsCollaboration(editor, id, provider, yjsDocMap, name, color, shouldBootstrap, binding, setDoc, cursorsContainerRef, initialEditorState, awarenessData, syncCursorPositionsFn);
    useYjsHistory(editor, binding);
    useYjsFocusTracking(editor, provider, name, color, awarenessData);
    return cursors;
}
function CollaborationPluginV2__EXPERIMENTAL({ id, doc, provider, __shouldBootstrapUnsafe, username, cursorColor, cursorsContainerRef, excludedProperties, awarenessData }) {
    const collabContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalCollaborationContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCollaborationContext"])(username, cursorColor);
    const { yjsDocMap, name, color } = collabContext;
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    useCollabActive(collabContext, editor);
    const binding = useYjsCollaborationV2__EXPERIMENTAL(editor, id, doc, provider, yjsDocMap, name, color, {
        __shouldBootstrapUnsafe,
        awarenessData,
        excludedProperties
    });
    useYjsHistoryV2(editor, binding);
    useYjsFocusTracking(editor, provider, name, color, awarenessData);
    return useYjsCursors(binding, cursorsContainerRef);
}
const useCollabActive = (collabContext, editor)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useCollabActive.useEffect": ()=>{
            collabContext.isCollabActive = true;
            return ({
                "useCollabActive.useEffect": ()=>{
                    // Resetting flag only when unmount top level editor collab plugin. Nested
                    // editors (e.g. image caption) should unmount without affecting it
                    if (editor._parentEditor == null) {
                        collabContext.isCollabActive = false;
                    }
                }
            })["useCollabActive.useEffect"];
        }
    }["useCollabActive.useEffect"], [
        collabContext,
        editor
    ]);
};
;
}),
"[project]/node_modules/@mui/icons-material/esm/Lock.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2m-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2m3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1s3.1 1.39 3.1 3.1z"
}), 'Lock');
}),
"[project]/node_modules/@mui/icons-material/esm/PushPin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    fillRule: "evenodd",
    d: "M16 9V4h1c.55 0 1-.45 1-1s-.45-1-1-1H7c-.55 0-1 .45-1 1s.45 1 1 1h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3"
}), 'PushPin');
}),
"[project]/node_modules/@mui/icons-material/esm/EmojiEmotions.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2M8.5 8c.83 0 1.5.67 1.5 1.5S9.33 11 8.5 11 7 10.33 7 9.5 7.67 8 8.5 8M12 18c-2.28 0-4.22-1.66-5-4h10c-.78 2.34-2.72 4-5 4m3.5-7c-.83 0-1.5-.67-1.5-1.5S14.67 8 15.5 8s1.5.67 1.5 1.5-.67 1.5-1.5 1.5"
}), 'EmojiEmotions');
}),
"[project]/node_modules/@mui/icons-material/esm/SmartToy.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon> <export createSvgIcon as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__$3c$export__createSvgIcon__as__default$3e$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M20 9V7c0-1.1-.9-2-2-2h-3c0-1.66-1.34-3-3-3S9 3.34 9 5H6c-1.1 0-2 .9-2 2v2c-1.66 0-3 1.34-3 3s1.34 3 3 3v4c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-4c1.66 0 3-1.34 3-3s-1.34-3-3-3M7.5 11.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5S9.83 13 9 13s-1.5-.67-1.5-1.5M16 17H8v-2h8zm-1-4c-.83 0-1.5-.67-1.5-1.5S14.17 10 15 10s1.5.67 1.5 1.5S15.83 13 15 13"
}), 'SmartToy');
}),
"[project]/node_modules/@mui/material/esm/Popper/Popper.js [app-client] (ecmascript) <export default as Popper>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Popper",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popper$2f$Popper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popper$2f$Popper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Popper/Popper.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=node_modules_13ijt_i._.js.map