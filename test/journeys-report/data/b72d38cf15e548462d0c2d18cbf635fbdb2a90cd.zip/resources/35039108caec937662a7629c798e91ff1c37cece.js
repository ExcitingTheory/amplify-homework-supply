(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/utils/tabStateUtils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildTabStateQuery",
    ()=>buildTabStateQuery,
    "clearTabState",
    ()=>clearTabState,
    "loadTabState",
    ()=>loadTabState,
    "mergeTabState",
    ()=>mergeTabState,
    "parseTabStateFromURL",
    ()=>parseTabStateFromURL,
    "saveTabState",
    ()=>saveTabState
]);
/**
 * Utility functions for syncing vertical tab state with localStorage and URL
 * 
 * Storage format in localStorage:
 * {
 *   leftTab: number,
 *   rightTab: number,
 *   leftOpen: boolean,
 *   rightOpen: boolean,
 *   leftWidth: number,
 *   rightWidth: number
 * }
 * 
 * URL format:
 * ?sidebars=files,chat (both open with specific tabs)
 * ?sidebars=files (only left open)
 * ?sidebars=chat (only right open)  
 * ?sidebars= or omitted (both closed)
 * 
 * Tab names:
 * - Left: assignments, toc, dictionary, questions, files, config
 * - Right: history, chat, settings
 */ const STORAGE_KEY = 'editor-tab-state';
const DEFAULT_WIDTH = 350;
// Tab name mappings
// Left tabs: 0=assignments, 1=toc, 2=dictionary, 3=questions, 4=files, 6=config
const LEFT_TAB_NAMES = [
    'assignments',
    'toc',
    'dictionary',
    'questions',
    'files',
    '',
    'config'
];
// Right tabs: 5=chat, 7=suggestions, 8=grades, 9=cohortChat
const RIGHT_TAB_NAMES = [
    '',
    '',
    '',
    '',
    '',
    'chat',
    '',
    'suggestions',
    'grades',
    'cohortChat'
];
const DEFAULT_LEFT_TAB = 4; // files
const DEFAULT_RIGHT_TAB = 5; // chat
/**
 * Convert tab index to name
 * @param {number} index - Tab index
 * @param {string} side - 'left' or 'right'
 * @returns {string} Tab name
 */ function tabIndexToName(index, side) {
    const names = side === 'left' ? LEFT_TAB_NAMES : RIGHT_TAB_NAMES;
    return names[index] || names[side === 'left' ? DEFAULT_LEFT_TAB : DEFAULT_RIGHT_TAB];
}
/**
 * Convert tab name to index
 * @param {string} name - Tab name
 * @param {string} side - 'left' or 'right'
 * @returns {number} Tab index
 */ function tabNameToIndex(name, side) {
    const names = side === 'left' ? LEFT_TAB_NAMES : RIGHT_TAB_NAMES;
    const index = names.indexOf(name);
    return index >= 0 ? index : side === 'left' ? DEFAULT_LEFT_TAB : DEFAULT_RIGHT_TAB;
}
/**
 * Encode sidebar state with tab names
 * @param {number} leftTab - Left tab index
 * @param {number} rightTab - Right tab index
 * @param {boolean} leftOpen - Left sidebar open
 * @param {boolean} rightOpen - Right sidebar open
 * @returns {string} Encoded state (e.g., 'files,chat', 'files', 'chat', or '')
 */ function encodeSidebarState(leftTab, rightTab, leftOpen, rightOpen) {
    const parts = [];
    if (leftOpen) {
        parts.push(tabIndexToName(leftTab, 'left'));
    }
    if (rightOpen) {
        parts.push(tabIndexToName(rightTab, 'right'));
    }
    return parts.join(',');
}
/**
 * Decode sidebar state from tab names
 * @param {string} state - Encoded state (e.g., 'files,chat', 'files', 'chat')
 * @returns {object} { leftTab: number|null, rightTab: number|null, leftOpen: boolean, rightOpen: boolean }
 */ function decodeSidebarState(state) {
    if (!state) return {
        leftTab: null,
        rightTab: null,
        leftOpen: false,
        rightOpen: false
    };
    const parts = state.split(',').filter((p)=>p.trim());
    const result = {
        leftTab: null,
        rightTab: null,
        leftOpen: false,
        rightOpen: false
    };
    for (const part of parts){
        const trimmed = part.trim();
        // Check if it's a left tab name
        if (LEFT_TAB_NAMES.includes(trimmed)) {
            result.leftTab = tabNameToIndex(trimmed, 'left');
            result.leftOpen = true;
        } else if (RIGHT_TAB_NAMES.includes(trimmed)) {
            result.rightTab = tabNameToIndex(trimmed, 'right');
            result.rightOpen = true;
        }
    }
    return result;
}
function loadTabState() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : null;
    } catch (error) {
        console.error('Error loading tab state from localStorage:', error);
        return null;
    }
}
function saveTabState(state) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (error) {
        console.error('Error saving tab state to localStorage:', error);
    }
}
function parseTabStateFromURL(query) {
    const state = {};
    if (query.sidebars !== undefined) {
        const decoded = decodeSidebarState(query.sidebars);
        if (decoded.leftTab !== null) state.leftTab = decoded.leftTab;
        if (decoded.rightTab !== null) state.rightTab = decoded.rightTab;
        state.leftOpen = decoded.leftOpen;
        state.rightOpen = decoded.rightOpen;
    }
    if (query.leftWidth !== undefined) {
        state.leftWidth = parseInt(query.leftWidth, 10);
    }
    if (query.rightWidth !== undefined) {
        state.rightWidth = parseInt(query.rightWidth, 10);
    }
    return state;
}
function buildTabStateQuery(state) {
    const query = {};
    const sidebarState = encodeSidebarState(state.leftTab ?? DEFAULT_LEFT_TAB, state.rightTab ?? DEFAULT_RIGHT_TAB, state.leftOpen ?? false, state.rightOpen ?? false);
    if (sidebarState) {
        query.sidebars = sidebarState;
    }
    if (state.leftWidth !== undefined && state.leftWidth !== DEFAULT_WIDTH) {
        query.leftWidth = state.leftWidth.toString();
    }
    if (state.rightWidth !== undefined && state.rightWidth !== DEFAULT_WIDTH) {
        query.rightWidth = state.rightWidth.toString();
    }
    return query;
}
function mergeTabState(urlState, localState) {
    return {
        leftTab: urlState.leftTab ?? localState?.leftTab ?? DEFAULT_LEFT_TAB,
        rightTab: urlState.rightTab ?? localState?.rightTab ?? DEFAULT_RIGHT_TAB,
        leftOpen: urlState.leftOpen ?? localState?.leftOpen ?? false,
        rightOpen: urlState.rightOpen ?? localState?.rightOpen ?? false,
        leftWidth: urlState.leftWidth ?? localState?.leftWidth ?? DEFAULT_WIDTH,
        rightWidth: urlState.rightWidth ?? localState?.rightWidth ?? DEFAULT_WIDTH
    };
}
function clearTabState() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        localStorage.removeItem(STORAGE_KEY);
    } catch (error) {
        console.error('Error clearing tab state from localStorage:', error);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/chatMentions.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Chat mention parsing and resolution utilities.
 *
 * Handles:
 * - @kai — AI bot trigger
 * - @"Display Name" — user with spaces in name
 * - @username — simple user mention
 * - #topic — topic reference (for auto-linking)
 *
 * @module chatMentions
 */ // ============================================================================
// Types
// ============================================================================
__turbopack_context__.s([
    "extractBotPrompt",
    ()=>extractBotPrompt,
    "getAutocompleteSuggestions",
    ()=>getAutocompleteSuggestions,
    "parseContent",
    ()=>parseContent,
    "resolveMentions",
    ()=>resolveMentions
]);
// ============================================================================
// Parsing
// ============================================================================
const MENTION_REGEX = /@"([^"]+)"|@(\w[\w.-]*)/g;
const TOPIC_REGEX = /#([\w-]+)/g;
const BOT_NAME = "kai";
function parseContent(content) {
    const mentions = [];
    let hasBotMention = false;
    // Parse @mentions
    let match;
    MENTION_REGEX.lastIndex = 0;
    while((match = MENTION_REGEX.exec(content)) !== null){
        const value = match[1] || match[2]; // Quoted name or plain username
        const isBotMention = value.toLowerCase() === BOT_NAME;
        if (isBotMention) {
            hasBotMention = true;
        }
        mentions.push({
            type: isBotMention ? "bot" : "user",
            raw: match[0],
            value,
            startIndex: match.index,
            endIndex: match.index + match[0].length
        });
    }
    // Parse #topics
    TOPIC_REGEX.lastIndex = 0;
    while((match = TOPIC_REGEX.exec(content)) !== null){
        mentions.push({
            type: "topic",
            raw: match[0],
            value: match[1],
            startIndex: match.index,
            endIndex: match.index + match[0].length
        });
    }
    // Sort by position
    mentions.sort((a, b)=>a.startIndex - b.startIndex);
    return {
        text: content,
        mentions,
        hasBotMention
    };
}
function extractBotPrompt(content) {
    return content.replace(/@kai\b/gi, "").trim();
}
function getAutocompleteSuggestions(query, members, maxResults = 8) {
    const lowerQuery = query.toLowerCase();
    const suggestions = [];
    // Check if @kai matches
    if (BOT_NAME.startsWith(lowerQuery) || lowerQuery === "") {
        suggestions.push({
            label: "Kai (AI Assistant)",
            value: "@kai",
            type: "bot"
        });
    }
    // Filter members
    for (const member of members){
        if (suggestions.length >= maxResults) break;
        const matchesUsername = member.username.toLowerCase().startsWith(lowerQuery);
        const matchesDisplay = member.displayName.toLowerCase().startsWith(lowerQuery);
        if (matchesUsername || matchesDisplay) {
            const hasSpaces = member.displayName.includes(" ");
            suggestions.push({
                label: member.displayName,
                value: hasSpaces ? `@"${member.displayName}"` : `@${member.username}`,
                type: "user"
            });
        }
    }
    return suggestions;
}
function resolveMentions(mentions, members) {
    const resolved = [];
    for (const mention of mentions){
        if (mention.type !== "user") continue;
        const found = members.find((m)=>m.username.toLowerCase() === mention.value.toLowerCase() || m.displayName.toLowerCase() === mention.value.toLowerCase());
        if (found && !resolved.some((r)=>r.username === found.username)) {
            resolved.push(found);
        }
    }
    return resolved;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useTabState.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTabState",
    ()=>useTabState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tabStateUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/tabStateUtils.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
/**
 * Reducer for tab state management
 */ const tabStateReducer = (state, action)=>{
    switch(action.type){
        case 'OPEN_LEFT_SIDEBAR':
            return {
                ...state,
                leftTab: action.tab ?? state.leftTab,
                leftOpen: true
            };
        case 'OPEN_RIGHT_SIDEBAR':
            return {
                ...state,
                rightTab: action.tab ?? state.rightTab,
                rightOpen: true
            };
        case 'CLOSE_LEFT_SIDEBAR':
            return {
                ...state,
                leftOpen: false
            };
        case 'CLOSE_RIGHT_SIDEBAR':
            return {
                ...state,
                rightOpen: false
            };
        case 'TOGGLE_LEFT_SIDEBAR':
            return {
                ...state,
                leftOpen: !state.leftOpen
            };
        case 'TOGGLE_RIGHT_SIDEBAR':
            return {
                ...state,
                rightOpen: !state.rightOpen
            };
        case 'SET_LEFT_TAB':
            return {
                ...state,
                leftTab: action.tab
            };
        case 'SET_RIGHT_TAB':
            return {
                ...state,
                rightTab: action.tab
            };
        case 'SET_LEFT_WIDTH':
            return {
                ...state,
                leftWidth: action.width
            };
        case 'SET_RIGHT_WIDTH':
            return {
                ...state,
                rightWidth: action.width
            };
        case 'SET_WIDTHS':
            return {
                ...state,
                leftWidth: action.leftWidth,
                rightWidth: action.rightWidth
            };
        case 'RESTORE_FROM_URL':
            return {
                ...state,
                ...action.payload
            };
        case 'UPDATE_STATE':
            return {
                ...state,
                ...action.payload
            };
        default:
            return state;
    }
};
function useTabState(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(49);
    if ($[0] !== "40f89fb517c96ad8cca49ddf2fa4cb7a777a3e5fe61d7374458c396ce050a06a") {
        for(let $i = 0; $i < 49; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "40f89fb517c96ad8cca49ddf2fa4cb7a777a3e5fe61d7374458c396ce050a06a";
    }
    let t1;
    if ($[1] !== t0) {
        t1 = t0 === undefined ? {} : t0;
        $[1] = t0;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const options = t1;
    const { defaultLeftTab: t2, defaultRightTab: t3, defaultLeftWidth: t4, defaultRightWidth: t5, syncToURL: t6, syncToLocalStorage: t7 } = options;
    const defaultLeftTab = t2 === undefined ? 4 : t2;
    const defaultRightTab = t3 === undefined ? 1 : t3;
    const defaultLeftWidth = t4 === undefined ? 350 : t4;
    const defaultRightWidth = t5 === undefined ? 350 : t5;
    const syncToURL = t6 === undefined ? true : t6;
    const syncToLocalStorage = t7 === undefined ? true : t7;
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const isInitialized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const isUpdatingURL = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    let obj;
    if ($[3] !== searchParams) {
        obj = {};
        searchParams.forEach({
            "useTabState[searchParams.forEach()]": (value, key)=>{
                obj[key] = value;
            }
        }["useTabState[searchParams.forEach()]"]);
        $[3] = searchParams;
        $[4] = obj;
    } else {
        obj = $[4];
    }
    const queryObject = obj;
    let t8;
    if ($[5] !== defaultLeftTab || $[6] !== defaultLeftWidth || $[7] !== defaultRightTab || $[8] !== defaultRightWidth || $[9] !== syncToLocalStorage) {
        t8 = ({
            "useTabState[useReducer()]": ()=>{
                if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
                ;
                const currentParams = {};
                if ("TURBOPACK compile-time truthy", 1) {
                    const sp = new URLSearchParams(window.location.search);
                    sp.forEach({
                        "useTabState[useReducer() > sp.forEach()]": (value_0, key_0)=>{
                            currentParams[key_0] = value_0;
                        }
                    }["useTabState[useReducer() > sp.forEach()]"]);
                }
                const urlState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tabStateUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseTabStateFromURL"])(currentParams);
                const localState = syncToLocalStorage ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tabStateUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadTabState"])() : null;
                const merged = {
                    leftTab: urlState.leftTab ?? defaultLeftTab ?? localState?.leftTab,
                    rightTab: urlState.rightTab ?? defaultRightTab ?? localState?.rightTab,
                    leftOpen: urlState.leftOpen ?? localState?.leftOpen ?? false,
                    rightOpen: urlState.rightOpen ?? localState?.rightOpen ?? false,
                    leftWidth: urlState.leftWidth ?? defaultLeftWidth ?? localState?.leftWidth,
                    rightWidth: urlState.rightWidth ?? defaultRightWidth ?? localState?.rightWidth
                };
                console.log("[useTabState] Initialized with:", merged, "from URL:", urlState, "localStorage:", localState, "defaults:", {
                    defaultLeftTab,
                    defaultRightTab
                });
                return merged;
            }
        })["useTabState[useReducer()]"];
        $[5] = defaultLeftTab;
        $[6] = defaultLeftWidth;
        $[7] = defaultRightTab;
        $[8] = defaultRightWidth;
        $[9] = syncToLocalStorage;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(tabStateReducer, null, t8);
    let t10;
    let t9;
    if ($[11] !== state || $[12] !== syncToLocalStorage) {
        t9 = ({
            "useTabState[useEffect()]": ()=>{
                if (!syncToLocalStorage || !isInitialized.current) {
                    return;
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tabStateUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveTabState"])(state);
            }
        })["useTabState[useEffect()]"];
        t10 = [
            state,
            syncToLocalStorage
        ];
        $[11] = state;
        $[12] = syncToLocalStorage;
        $[13] = t10;
        $[14] = t9;
    } else {
        t10 = $[13];
        t9 = $[14];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t9, t10);
    let t11;
    if ($[15] !== pathname || $[16] !== queryObject || $[17] !== router || $[18] !== state || $[19] !== syncToURL) {
        t11 = ({
            "useTabState[useEffect()]": ()=>{
                if (!syncToURL || !isInitialized.current || isUpdatingURL.current) {
                    return;
                }
                const timeoutId = setTimeout({
                    "useTabState[useEffect() > setTimeout()]": ()=>{
                        const tabQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tabStateUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTabStateQuery"])(state);
                        const currentTabQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tabStateUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTabStateQuery"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tabStateUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseTabStateFromURL"])(queryObject));
                        const newTabQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tabStateUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTabStateQuery"])(state);
                        if (JSON.stringify(currentTabQuery) !== JSON.stringify(newTabQuery)) {
                            isUpdatingURL.current = true;
                            const queryString = new URLSearchParams(tabQuery).toString();
                            const newUrl = queryString ? `${pathname}?${queryString}` : pathname;
                            router.replace(newUrl);
                            setTimeout({
                                "useTabState[useEffect() > setTimeout() > setTimeout()]": ()=>{
                                    isUpdatingURL.current = false;
                                }
                            }["useTabState[useEffect() > setTimeout() > setTimeout()]"], 100);
                        }
                    }
                }["useTabState[useEffect() > setTimeout()]"], 300);
                return ()=>clearTimeout(timeoutId);
            }
        })["useTabState[useEffect()]"];
        $[15] = pathname;
        $[16] = queryObject;
        $[17] = router;
        $[18] = state;
        $[19] = syncToURL;
        $[20] = t11;
    } else {
        t11 = $[20];
    }
    let t12;
    if ($[21] !== pathname || $[22] !== queryObject || $[23] !== state || $[24] !== syncToURL) {
        t12 = [
            state,
            syncToURL,
            pathname,
            queryObject
        ];
        $[21] = pathname;
        $[22] = queryObject;
        $[23] = state;
        $[24] = syncToURL;
        $[25] = t12;
    } else {
        t12 = $[25];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t11, t12);
    let t13;
    let t14;
    if ($[26] !== defaultLeftTab || $[27] !== defaultLeftWidth || $[28] !== defaultRightTab || $[29] !== defaultRightWidth || $[30] !== queryObject || $[31] !== syncToLocalStorage || $[32] !== syncToURL) {
        t13 = ({
            "useTabState[useEffect()]": ()=>{
                if (!syncToURL || isUpdatingURL.current) {
                    return;
                }
                const urlState_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tabStateUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseTabStateFromURL"])(queryObject);
                const localState_0 = syncToLocalStorage ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tabStateUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadTabState"])() : null;
                const merged_0 = {
                    leftTab: urlState_0.leftTab ?? localState_0?.leftTab ?? defaultLeftTab,
                    rightTab: urlState_0.rightTab ?? localState_0?.rightTab ?? defaultRightTab,
                    leftOpen: urlState_0.leftOpen ?? localState_0?.leftOpen ?? false,
                    rightOpen: urlState_0.rightOpen ?? localState_0?.rightOpen ?? false,
                    leftWidth: urlState_0.leftWidth ?? localState_0?.leftWidth ?? defaultLeftWidth,
                    rightWidth: urlState_0.rightWidth ?? localState_0?.rightWidth ?? defaultRightWidth
                };
                if (!isInitialized.current) {
                    isInitialized.current = true;
                    dispatch({
                        type: "RESTORE_FROM_URL",
                        payload: merged_0
                    });
                } else {
                    dispatch({
                        type: "RESTORE_FROM_URL",
                        payload: merged_0
                    });
                }
            }
        })["useTabState[useEffect()]"];
        t14 = [
            queryObject,
            syncToURL,
            syncToLocalStorage,
            defaultLeftTab,
            defaultRightTab,
            defaultLeftWidth,
            defaultRightWidth
        ];
        $[26] = defaultLeftTab;
        $[27] = defaultLeftWidth;
        $[28] = defaultRightTab;
        $[29] = defaultRightWidth;
        $[30] = queryObject;
        $[31] = syncToLocalStorage;
        $[32] = syncToURL;
        $[33] = t13;
        $[34] = t14;
    } else {
        t13 = $[33];
        t14 = $[34];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t13, t14);
    let t15;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = ({
            "useTabState[setLeftTab]": (value_1)=>{
                dispatch({
                    type: "SET_LEFT_TAB",
                    tab: value_1
                });
            }
        })["useTabState[setLeftTab]"];
        $[35] = t15;
    } else {
        t15 = $[35];
    }
    const setLeftTab = t15;
    let t16;
    if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = ({
            "useTabState[setRightTab]": (value_2)=>{
                dispatch({
                    type: "SET_RIGHT_TAB",
                    tab: value_2
                });
            }
        })["useTabState[setRightTab]"];
        $[36] = t16;
    } else {
        t16 = $[36];
    }
    const setRightTab = t16;
    let t17;
    if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = ({
            "useTabState[setLeftOpen]": (value_3)=>{
                dispatch({
                    type: value_3 ? "OPEN_LEFT_SIDEBAR" : "CLOSE_LEFT_SIDEBAR"
                });
            }
        })["useTabState[setLeftOpen]"];
        $[37] = t17;
    } else {
        t17 = $[37];
    }
    const setLeftOpen = t17;
    let t18;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = ({
            "useTabState[setRightOpen]": (value_4)=>{
                dispatch({
                    type: value_4 ? "OPEN_RIGHT_SIDEBAR" : "CLOSE_RIGHT_SIDEBAR"
                });
            }
        })["useTabState[setRightOpen]"];
        $[38] = t18;
    } else {
        t18 = $[38];
    }
    const setRightOpen = t18;
    let t19;
    if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = ({
            "useTabState[setLeftWidth]": (value_5)=>{
                dispatch({
                    type: "SET_LEFT_WIDTH",
                    width: value_5
                });
            }
        })["useTabState[setLeftWidth]"];
        $[39] = t19;
    } else {
        t19 = $[39];
    }
    const setLeftWidth = t19;
    let t20;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = ({
            "useTabState[setRightWidth]": (value_6)=>{
                dispatch({
                    type: "SET_RIGHT_WIDTH",
                    width: value_6
                });
            }
        })["useTabState[setRightWidth]"];
        $[40] = t20;
    } else {
        t20 = $[40];
    }
    const setRightWidth = t20;
    let t21;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = ({
            "useTabState[updateState]": (updates)=>{
                dispatch({
                    type: "UPDATE_STATE",
                    payload: updates
                });
            }
        })["useTabState[updateState]"];
        $[41] = t21;
    } else {
        t21 = $[41];
    }
    const updateState = t21;
    let t22;
    if ($[42] !== state.leftOpen || $[43] !== state.leftTab || $[44] !== state.leftWidth || $[45] !== state.rightOpen || $[46] !== state.rightTab || $[47] !== state.rightWidth) {
        t22 = {
            leftTab: state.leftTab,
            rightTab: state.rightTab,
            leftOpen: state.leftOpen,
            rightOpen: state.rightOpen,
            leftWidth: state.leftWidth,
            rightWidth: state.rightWidth,
            setLeftTab,
            setRightTab,
            setLeftOpen,
            setRightOpen,
            setLeftWidth,
            setRightWidth,
            updateState
        };
        $[42] = state.leftOpen;
        $[43] = state.leftTab;
        $[44] = state.leftWidth;
        $[45] = state.rightOpen;
        $[46] = state.rightTab;
        $[47] = state.rightWidth;
        $[48] = t22;
    } else {
        t22 = $[48];
    }
    return t22;
}
_s(useTabState, "UXQ104flwniRCvg9cpX7m5neYD0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useChatPageContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useChatPageContext",
    ()=>useChatPageContext
]);
/**
 * useChatPageContext - Register page-specific context with ChatContext
 * 
 * This hook allows pages to register their available context (unit, files, sections, etc.)
 * with the global ChatContext, making that context available to the chat sidebar.
 * 
 * @example
 * // In Unit Editor page
 * function UnitEditorPage() {
 *   const { unit, files, dictionary, questions } = useContext(UnitContext);
 *   const { sections } = useContext(SectionContext);
 *   const { vectorStoreSearch } = useContext(VectorStoreContext);
 *   const editorRef = useRef(null);
 *   
 *   useChatPageContext({
 *     unit,
 *     files,
 *     dictionary,
 *     questions,
 *     sections,
 *     editorRef,
 *     vectorStoreSearch,
 *   });
 *   
 *   return <...>
 * }
 * 
 * @see docs/GLOBAL_CHAT_INTEGRATION_PLAN.md
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/chatContext.jsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useChatPageContext(context = {}) {
    _s();
    const { setPageContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { unit = null, files = [], dictionary = [], questions = [], sections = [], editorRef = null, vectorStoreSearch = null } = context;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChatPageContext.useEffect": ()=>{
            console.log('[useChatPageContext] Registering page context:', {
                hasUnit: !!unit,
                filesCount: files?.length || 0,
                dictionaryCount: dictionary?.length || 0,
                questionsCount: questions?.length || 0,
                sectionsCount: sections?.length || 0,
                hasEditorRef: !!editorRef,
                hasVectorStoreSearch: !!vectorStoreSearch
            });
            setPageContext({
                unit,
                files,
                dictionary,
                questions,
                sections,
                editorRef,
                vectorStoreSearch
            });
            // Cleanup: reset to empty context when component unmounts
            return ({
                "useChatPageContext.useEffect": ()=>{
                    console.log('[useChatPageContext] Cleaning up page context');
                    setPageContext({
                        unit: null,
                        files: [],
                        dictionary: [],
                        questions: [],
                        sections: [],
                        editorRef: null,
                        vectorStoreSearch: null
                    });
                }
            })["useChatPageContext.useEffect"];
        }
    }["useChatPageContext.useEffect"], [
        // Dependencies - update when any context changes
        unit?.id,
        files?.length,
        dictionary?.length,
        questions?.length,
        sections?.length,
        editorRef?.current,
        vectorStoreSearch,
        setPageContext
    ]);
}
_s(useChatPageContext, "0aGcDEhsgvDsw4KhinDnLq0Ig9M=");
const __TURBOPACK__default__export__ = useChatPageContext;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useYjsUnit.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useYjsUnit",
    ()=>useYjsUnit
]);
/**
 * useYjsUnit - Real-time collaborative unit editing hook
 *
 * Integrates Yjs CRDT for real-time collaboration with Amplify DataStore
 * for cross-device persistence.
 *
 * @example
 * ```typescript
 * const { provider, unit, isSynced, ytext } = useYjsUnit({ unitId: 'unit-1' });
 *
 * // Yjs handles real-time sync automatically
 * // Debounced saves to DataStore every 5 seconds
 * ```
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$hooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/hooks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$unitContentStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/unitContentStorage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/yjs/dist/yjs.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function useYjsUnit(config) {
    _s();
    const { unitId, enableWebSocket = true, enablePersistence = true, saveDebounceMs = 5000 } = config;
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
    const [unit, setUnit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const nextVersionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(1);
    const saveTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Initialize Yjs provider only if we have a unitId
    const { provider, isSynced, isConnected } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$hooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useYjsProvider"])({
        docName: unitId ? `unit-${unitId}` : "unit-null",
        connect: enableWebSocket && !!unitId,
        persistence: enablePersistence && !!unitId
    });
    // Load initial state from Amplify
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsUnit.useEffect": ()=>{
            if (!unitId) {
                setIsLoading(false);
                return;
            }
            async function loadUnit() {
                try {
                    setIsLoading(true);
                    // TypeScript type guard - unitId is guaranteed to be string here
                    const { data } = await client.models.Unit.get({
                        id: unitId
                    });
                    if (!data) {
                        throw new Error(`Unit ${unitId} not found`);
                    }
                    // Unit record — content is loaded from S3 separately
                    const parsedUnit = {
                        ...data
                    };
                    setUnit(parsedUnit);
                    nextVersionRef.current = (data._version || 0) + 1;
                    // Load Yjs snapshot from S3
                    if (data.identityId && provider) {
                        try {
                            const yjsBytes = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$unitContentStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadYjsSnapshot"])(data.identityId, unitId);
                            if (yjsBytes) {
                                const applied = provider.applyUpdate(yjsBytes);
                                if (applied) {
                                    console.log(`[useYjsUnit] Applied Yjs snapshot from S3 for unit ${unitId}`);
                                } else {
                                    console.warn(`[useYjsUnit] S3 snapshot for unit ${unitId} was corrupt — skipped`);
                                }
                            }
                        } catch (err_0) {
                            console.warn("[useYjsUnit] Failed to load snapshot from S3:", err_0);
                        }
                    }
                    setIsLoading(false);
                } catch (err) {
                    console.error("[useYjsUnit] Failed to load unit:", err);
                    setError(err);
                    setIsLoading(false);
                }
            }
            if (provider) {
                loadUnit();
            }
        }
    }["useYjsUnit.useEffect"], [
        unitId,
        provider,
        client
    ]);
    // Debounced save to DataStore
    const saveToDataStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useYjsUnit.useCallback[saveToDataStore]": async ()=>{
            if (!unitId || !provider || !unit) {
                console.warn("[useYjsUnit] No unitId, provider, or unit available for save");
                return;
            }
            try {
                const ytext = provider.getText("editorContent");
                const ymetadata = provider.getMap("metadata");
                // Extract state
                const editorContent = ytext.toString();
                const yjsState = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeStateAsUpdate"](provider.getDoc());
                // Extract metadata
                const metadata = {};
                ymetadata.forEach({
                    "useYjsUnit.useCallback[saveToDataStore]": (value, key)=>{
                        metadata[key] = value;
                    }
                }["useYjsUnit.useCallback[saveToDataStore]"]);
                const identityId_0 = unit.identityId;
                if (!identityId_0) {
                    console.warn("[useYjsUnit] Unit has no identityId, cannot save to S3");
                    return;
                }
                console.log(`[useYjsUnit] Saving unit ${unitId} to S3 + DynamoDB (version ${nextVersionRef.current})`);
                // Upload content + snapshot to S3 in parallel (private — owner only)
                const saveResults = await Promise.allSettled([
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$unitContentStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveDraftContent"])(identityId_0, unitId, JSON.stringify({
                        content: editorContent
                    })),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$unitContentStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveYjsSnapshot"])(identityId_0, unitId, yjsState)
                ]);
                const saveFailures = saveResults.filter({
                    "useYjsUnit.useCallback[saveToDataStore].saveFailures": (r)=>r.status === "rejected"
                }["useYjsUnit.useCallback[saveToDataStore].saveFailures"]);
                if (saveFailures.length > 0) {
                    console.error("[useYjsUnit] S3 save partially failed:", saveFailures.map({
                        "useYjsUnit.useCallback[saveToDataStore]": (f)=>f.reason
                    }["useYjsUnit.useCallback[saveToDataStore]"]));
                // Continue with DynamoDB update even if S3 partially failed
                }
                // Bump contentVersion in DynamoDB (lightweight, no content payload)
                const currentContentVersion = unit.contentVersion || 0;
                const nextContentVersion = currentContentVersion + 1;
                await client.models.Unit.update({
                    id: unitId,
                    contentVersion: nextContentVersion,
                    ...metadata,
                    _version: nextVersionRef.current
                });
                // Optimistically increment version
                nextVersionRef.current += 1;
                setUnit({
                    "useYjsUnit.useCallback[saveToDataStore]": (prev)=>prev ? {
                            ...prev,
                            contentVersion: nextContentVersion
                        } : prev
                }["useYjsUnit.useCallback[saveToDataStore]"]);
                console.log(`[useYjsUnit] Successfully saved unit ${unitId}`);
            } catch (err_1) {
                if (err_1.message?.includes("version") || err_1.message?.includes("ConditionalCheck")) {
                    console.warn("[useYjsUnit] Version conflict detected, reloading from DataStore...");
                    try {
                        // Reload from DataStore
                        const { data: data_0 } = await client.models.Unit.get({
                            id: unitId
                        });
                        if (data_0) {
                            nextVersionRef.current = (data_0._version || 0) + 1;
                            // Re-apply snapshot from S3
                            const identityId = data_0.identityId;
                            if (identityId) {
                                const yjsBytes_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$unitContentStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadYjsSnapshot"])(identityId, unitId);
                                if (yjsBytes_0) {
                                    provider.applyUpdate(yjsBytes_0);
                                    console.log("[useYjsUnit] Re-applied snapshot from S3 after version conflict");
                                }
                            }
                        }
                    } catch (reloadErr) {
                        console.error("[useYjsUnit] Failed to reload after version conflict:", reloadErr);
                        setError(reloadErr);
                    }
                } else {
                    console.error("[useYjsUnit] Failed to save to DataStore:", err_1);
                    setError(err_1);
                }
                throw err_1;
            }
        }
    }["useYjsUnit.useCallback[saveToDataStore]"], [
        provider,
        unitId,
        unit,
        client
    ]);
    // Schedule debounced save on Y.Doc changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsUnit.useEffect": ()=>{
            if (!provider) return;
            const updateHandler = {
                "useYjsUnit.useEffect.updateHandler": ()=>{
                    // Clear existing timer
                    if (saveTimerRef.current) {
                        clearTimeout(saveTimerRef.current);
                    }
                    // Schedule new save
                    saveTimerRef.current = setTimeout({
                        "useYjsUnit.useEffect.updateHandler": ()=>{
                            saveToDataStore().catch({
                                "useYjsUnit.useEffect.updateHandler": (err_2)=>{
                                    console.error("[useYjsUnit] Debounced save failed:", err_2);
                                }
                            }["useYjsUnit.useEffect.updateHandler"]);
                        }
                    }["useYjsUnit.useEffect.updateHandler"], saveDebounceMs);
                }
            }["useYjsUnit.useEffect.updateHandler"];
            const unsubscribe = provider.onUpdate(updateHandler);
            return ({
                "useYjsUnit.useEffect": ()=>{
                    unsubscribe();
                    if (saveTimerRef.current) {
                        clearTimeout(saveTimerRef.current);
                    }
                }
            })["useYjsUnit.useEffect"];
        }
    }["useYjsUnit.useEffect"], [
        provider,
        saveToDataStore,
        saveDebounceMs
    ]);
    // Update metadata helper
    const updateMetadata = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useYjsUnit.useCallback[updateMetadata]": (updates)=>{
            if (!unitId || !provider) {
                console.warn("[useYjsUnit] Cannot update metadata: no unitId or provider");
                return;
            }
            const ymetadata_0 = provider.getMap("metadata");
            Object.entries(updates).forEach({
                "useYjsUnit.useCallback[updateMetadata]": ([key_0, value_0])=>{
                    ymetadata_0.set(key_0, value_0);
                }
            }["useYjsUnit.useCallback[updateMetadata]"]);
            console.log("[useYjsUnit] Updated metadata:", updates);
        }
    }["useYjsUnit.useCallback[updateMetadata]"], [
        provider
    ]);
    // Force save helper
    const forceSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useYjsUnit.useCallback[forceSave]": async ()=>{
            if (saveTimerRef.current) {
                clearTimeout(saveTimerRef.current);
            }
            await saveToDataStore();
        }
    }["useYjsUnit.useCallback[forceSave]"], [
        saveToDataStore
    ]);
    return {
        provider: provider || null,
        unit,
        isLoading,
        error,
        isSynced,
        isConnected,
        updateMetadata,
        forceSave,
        ytext: provider ? provider.getText("editorContent") : null,
        ymetadata: provider ? provider.getMap("metadata") : null
    };
}
_s(useYjsUnit, "T0S+c3koFP36VAACuXIMlXBz7e0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$hooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useYjsProvider"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/yjs/ChatCollaborationProvider.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * ChatCollaborationProvider — Specialized Yjs provider for collaborative chat rooms.
 *
 * Supports two room types:
 * - Section chat (`chat-section-{sectionId}`) — shared by all section members,
 *   with topics scoped to section/unit/workbook contexts
 * - Squad chat (`chat-squad-{squadId}`) — squad members only
 *
 * Y.Doc structure:
 * - `meta` Y.Map — room metadata (name, type, createdAt)
 * - `topics` Y.Map — topic objects keyed by topicId
 * - `threads` Y.Map — each key is a topicId, value references a Y.Array of messages
 * - Awareness — online/typing presence
 *
 * @module ChatCollaborationProvider
 */ __turbopack_context__.s([
    "ChatCollaborationProvider",
    ()=>ChatCollaborationProvider,
    "extractMentions",
    ()=>extractMentions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/YjsProvider.ts [app-client] (ecmascript)");
;
class ChatCollaborationProvider extends __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YjsDocProvider"] {
    roomType;
    roomId;
    user;
    metaMap;
    topicsMap;
    constructor(config){
        const docName = `chat-${config.roomType}-${config.roomId}`;
        super({
            ...config,
            docName
        });
        this.roomType = config.roomType;
        this.roomId = config.roomId;
        this.user = config.user;
        this.metaMap = this.getMap("meta");
        this.topicsMap = this.getMap("topics");
        this.initializeAwareness();
    }
    // ========================================================================
    // Awareness
    // ========================================================================
    initializeAwareness() {
        const awareness = this.getAwareness();
        awareness.setLocalState({
            user: this.user,
            typing: false,
            activeTopic: null
        });
    }
    setTyping(typing) {
        const awareness = this.getAwareness();
        const currentState = awareness.getLocalState();
        awareness.setLocalState({
            ...currentState,
            typing
        });
    }
    setActiveTopic(topicId) {
        const awareness = this.getAwareness();
        const currentState = awareness.getLocalState();
        awareness.setLocalState({
            ...currentState,
            activeTopic: topicId
        });
    }
    // ========================================================================
    // Room Meta
    // ========================================================================
    initializeRoom(name) {
        if (this.metaMap.get("createdAt")) return; // Already initialized
        this.metaMap.set("name", name);
        this.metaMap.set("roomType", this.roomType);
        this.metaMap.set("roomId", this.roomId);
        this.metaMap.set("createdAt", new Date().toISOString());
    }
    getRoomMeta() {
        return {
            name: this.metaMap.get("name") || "",
            roomType: this.metaMap.get("roomType") || this.roomType,
            roomId: this.metaMap.get("roomId") || this.roomId,
            createdAt: this.metaMap.get("createdAt") || ""
        };
    }
    // ========================================================================
    // Topics
    // ========================================================================
    createTopic(name, scope) {
        const topic = {
            id: crypto.randomUUID(),
            name: name.startsWith("#") ? name : `#${name}`,
            scope,
            createdBy: this.user.username,
            createdByName: this.user.displayName,
            createdAt: new Date().toISOString(),
            pinned: false,
            archived: false
        };
        this.topicsMap.set(topic.id, topic);
        // Initialize the thread array for this topic
        this.getDoc().getArray(`thread-${topic.id}`);
        return topic;
    }
    getTopic(topicId) {
        return this.topicsMap.get(topicId) || null;
    }
    getTopics() {
        const topics = [];
        this.topicsMap.forEach((value)=>{
            if (value && !value.archived) {
                topics.push(value);
            }
        });
        return topics;
    }
    getTopicsByScope(scope) {
        return this.getTopics().filter((t)=>t.scope === scope);
    }
    pinTopic(topicId, pinned) {
        const topic = this.topicsMap.get(topicId);
        if (topic) {
            this.topicsMap.set(topicId, {
                ...topic,
                pinned
            });
        }
    }
    archiveTopic(topicId) {
        const topic = this.topicsMap.get(topicId);
        if (topic) {
            this.topicsMap.set(topicId, {
                ...topic,
                archived: true
            });
        }
    }
    // ========================================================================
    // Messages / Threads
    // ========================================================================
    getThreadArray(topicId) {
        return this.getDoc().getArray(`thread-${topicId}`);
    }
    sendMessage(topicId, content, parentId) {
        const mentions = extractMentions(content);
        const message = {
            id: crypto.randomUUID(),
            parentId: parentId || null,
            authorId: this.user.username,
            authorName: this.user.displayName,
            content,
            contentJson: null,
            mentions,
            createdAt: new Date().toISOString(),
            editedAt: null,
            reactions: {},
            isStreaming: false
        };
        const threadArray = this.getThreadArray(topicId);
        threadArray.push([
            message
        ]);
        return message;
    }
    editMessage(topicId, messageId, newContent, contentJson) {
        const threadArray = this.getThreadArray(topicId);
        const items = Array.from(threadArray);
        const index = items.findIndex((m)=>m.id === messageId);
        if (index === -1) return;
        if (items[index].authorId !== this.user.username) return; // Can only edit own messages
        const updated = {
            ...items[index],
            content: newContent,
            contentJson: contentJson ?? items[index].contentJson,
            mentions: extractMentions(newContent),
            editedAt: new Date().toISOString()
        };
        this.getDoc().transact(()=>{
            threadArray.delete(index, 1);
            threadArray.insert(index, [
                updated
            ]);
        });
    }
    deleteMessage(topicId, messageId) {
        const threadArray = this.getThreadArray(topicId);
        const items = Array.from(threadArray);
        const index = items.findIndex((m)=>m.id === messageId);
        if (index === -1) return;
        if (items[index].authorId !== this.user.username) return; // Can only delete own messages
        threadArray.delete(index, 1);
    }
    addReaction(topicId, messageId, emoji) {
        const threadArray = this.getThreadArray(topicId);
        const items = Array.from(threadArray);
        const index = items.findIndex((m)=>m.id === messageId);
        if (index === -1) return;
        const message = items[index];
        const reactions = {
            ...message.reactions
        };
        const users = reactions[emoji] || [];
        if (users.includes(this.user.username)) {
            // Remove reaction
            reactions[emoji] = users.filter((u)=>u !== this.user.username);
            if (reactions[emoji].length === 0) delete reactions[emoji];
        } else {
            // Add reaction
            reactions[emoji] = [
                ...users,
                this.user.username
            ];
        }
        const updated = {
            ...message,
            reactions
        };
        this.getDoc().transact(()=>{
            threadArray.delete(index, 1);
            threadArray.insert(index, [
                updated
            ]);
        });
    }
    getMessages(topicId) {
        return Array.from(this.getThreadArray(topicId));
    }
    getThreadReplies(topicId, parentId) {
        return this.getMessages(topicId).filter((m)=>m.parentId === parentId);
    }
    getTopLevelMessages(topicId) {
        return this.getMessages(topicId).filter((m)=>m.parentId === null);
    }
    // ========================================================================
    // Accessors
    // ========================================================================
    getMetaMap() {
        return this.metaMap;
    }
    getTopicsMap() {
        return this.topicsMap;
    }
    getRoomId() {
        return this.roomId;
    }
    getRoomType() {
        return this.roomType;
    }
    getUser() {
        return this.user;
    }
}
function extractMentions(content) {
    const mentions = [];
    // Match @kai
    const kaiMatch = content.match(/@kai\b/gi);
    if (kaiMatch) mentions.push("@kai");
    // Match @"Name With Spaces" or @username
    const userMatches = content.matchAll(/@"([^"]+)"|@(\w+)/g);
    for (const match of userMatches){
        const name = match[1] || match[2];
        if (name.toLowerCase() !== "kai") {
            mentions.push(`@${name}`);
        }
    }
    return [
        ...new Set(mentions)
    ];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/yjs/chatHooks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useChatPresence",
    ()=>useChatPresence,
    "useChatRoom",
    ()=>useChatRoom,
    "useChatThread",
    ()=>useChatThread,
    "useChatTopics",
    ()=>useChatTopics
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * React hooks for collaborative chat rooms.
 *
 * Provides reactive state bindings for topics, threads, messages,
 * and presence from a ChatCollaborationProvider.
 *
 * @module chatHooks
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$ChatCollaborationProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/ChatCollaborationProvider.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
;
;
;
function useChatRoom(options) {
    _s();
    const { roomType, roomId, user, wsUrl, connect = true, persistence = true } = options || {};
    const providerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isConnected, setIsConnected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isSynced, setIsSynced] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChatRoom.useEffect": ()=>{
            if (!options || !roomId || !user?.username) return;
            const provider = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$ChatCollaborationProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChatCollaborationProvider"]({
                roomType,
                roomId,
                user,
                wsUrl,
                connect,
                persistence
            });
            providerRef.current = provider;
            // Track connection & sync status
            const wsProvider = provider.wsProvider;
            if (wsProvider) {
                wsProvider.on("status", {
                    "useChatRoom.useEffect": ({ status })=>{
                        setIsConnected(status === "connected");
                    }
                }["useChatRoom.useEffect"]);
                wsProvider.on("sync", {
                    "useChatRoom.useEffect": (synced)=>{
                        setIsSynced(synced);
                    }
                }["useChatRoom.useEffect"]);
            }
            return ({
                "useChatRoom.useEffect": ()=>{
                    provider.destroy();
                    providerRef.current = null;
                    setIsConnected(false);
                    setIsSynced(false);
                }
            })["useChatRoom.useEffect"];
        }
    }["useChatRoom.useEffect"], [
        roomType,
        roomId,
        user?.username
    ]);
    return {
        provider: providerRef.current,
        isConnected,
        isSynced
    };
}
_s(useChatRoom, "9tDjhjCOhEc5S8IFYrLfDcYxPb8=");
function useChatTopics(provider, scope) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [topics, setTopics] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== provider || $[3] !== scope) {
        t1 = ({
            "useChatTopics[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const topicsMap = provider.getTopicsMap();
                const handleChange = {
                    "useChatTopics[useEffect() > handleChange]": ()=>{
                        const allTopics = provider.getTopics();
                        if (scope) {
                            setTopics(allTopics.filter({
                                "useChatTopics[useEffect() > handleChange > allTopics.filter()]": (t)=>t.scope === "section" || t.scope === scope
                            }["useChatTopics[useEffect() > handleChange > allTopics.filter()]"]));
                        } else {
                            setTopics(allTopics);
                        }
                    }
                }["useChatTopics[useEffect() > handleChange]"];
                handleChange();
                topicsMap.observeDeep(handleChange);
                return ()=>{
                    topicsMap.unobserveDeep(handleChange);
                };
            }
        })["useChatTopics[useEffect()]"];
        t2 = [
            provider,
            scope
        ];
        $[2] = provider;
        $[3] = scope;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[6] !== provider) {
        t3 = ({
            "useChatTopics[createTopic]": (name, topicScope)=>{
                if (!provider) {
                    return null;
                }
                return provider.createTopic(name, topicScope);
            }
        })["useChatTopics[createTopic]"];
        $[6] = provider;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    const createTopic = t3;
    let t4;
    if ($[8] !== provider) {
        t4 = ({
            "useChatTopics[pinTopic]": (topicId, pinned)=>{
                provider?.pinTopic(topicId, pinned);
            }
        })["useChatTopics[pinTopic]"];
        $[8] = provider;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    const pinTopic = t4;
    let t5;
    if ($[10] !== provider) {
        t5 = ({
            "useChatTopics[archiveTopic]": (topicId_0)=>{
                provider?.archiveTopic(topicId_0);
            }
        })["useChatTopics[archiveTopic]"];
        $[10] = provider;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    const archiveTopic = t5;
    let t6;
    if ($[12] !== archiveTopic || $[13] !== createTopic || $[14] !== pinTopic || $[15] !== topics) {
        t6 = {
            topics,
            createTopic,
            pinTopic,
            archiveTopic
        };
        $[12] = archiveTopic;
        $[13] = createTopic;
        $[14] = pinTopic;
        $[15] = topics;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    return t6;
}
_s1(useChatTopics, "Z4rPjMfp4RLx3ToDgpfq685D3kI=");
function useChatThread(provider, topicId) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(30);
    if ($[0] !== "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d") {
        for(let $i = 0; $i < 30; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== provider || $[3] !== topicId) {
        t1 = ({
            "useChatThread[useEffect()]": ()=>{
                if (!provider || !topicId) {
                    setMessages([]);
                    return;
                }
                const threadArray = provider.getThreadArray(topicId);
                const handleChange = {
                    "useChatThread[useEffect() > handleChange]": ()=>{
                        setMessages(Array.from(threadArray));
                    }
                }["useChatThread[useEffect() > handleChange]"];
                handleChange();
                threadArray.observe(handleChange);
                provider.setActiveTopic(topicId);
                return ()=>{
                    threadArray.unobserve(handleChange);
                    provider.setActiveTopic(null);
                };
            }
        })["useChatThread[useEffect()]"];
        t2 = [
            provider,
            topicId
        ];
        $[2] = provider;
        $[3] = topicId;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[6] !== messages) {
        t3 = messages.filter(_useChatThreadMessagesFilter);
        $[6] = messages;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    const topLevelMessages = t3;
    let t4;
    if ($[8] !== provider || $[9] !== topicId) {
        t4 = ({
            "useChatThread[sendMessage]": (content, parentId)=>{
                if (!provider || !topicId) {
                    return null;
                }
                return provider.sendMessage(topicId, content, parentId);
            }
        })["useChatThread[sendMessage]"];
        $[8] = provider;
        $[9] = topicId;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    const sendMessage = t4;
    let t5;
    if ($[11] !== provider || $[12] !== topicId) {
        t5 = ({
            "useChatThread[editMessage]": (messageId, content_0, contentJson)=>{
                if (!provider || !topicId) {
                    return;
                }
                provider.editMessage(topicId, messageId, content_0, contentJson);
            }
        })["useChatThread[editMessage]"];
        $[11] = provider;
        $[12] = topicId;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    const editMessage = t5;
    let t6;
    if ($[14] !== provider || $[15] !== topicId) {
        t6 = ({
            "useChatThread[deleteMessage]": (messageId_0)=>{
                if (!provider || !topicId) {
                    return;
                }
                provider.deleteMessage(topicId, messageId_0);
            }
        })["useChatThread[deleteMessage]"];
        $[14] = provider;
        $[15] = topicId;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    const deleteMessage = t6;
    let t7;
    if ($[17] !== provider || $[18] !== topicId) {
        t7 = ({
            "useChatThread[addReaction]": (messageId_1, emoji)=>{
                if (!provider || !topicId) {
                    return;
                }
                provider.addReaction(topicId, messageId_1, emoji);
            }
        })["useChatThread[addReaction]"];
        $[17] = provider;
        $[18] = topicId;
        $[19] = t7;
    } else {
        t7 = $[19];
    }
    const addReaction = t7;
    let t8;
    if ($[20] !== messages) {
        t8 = ({
            "useChatThread[getReplies]": (parentId_0)=>messages.filter({
                    "useChatThread[getReplies > messages.filter()]": (m_0)=>m_0.parentId === parentId_0
                }["useChatThread[getReplies > messages.filter()]"])
        })["useChatThread[getReplies]"];
        $[20] = messages;
        $[21] = t8;
    } else {
        t8 = $[21];
    }
    const getReplies = t8;
    let t9;
    if ($[22] !== addReaction || $[23] !== deleteMessage || $[24] !== editMessage || $[25] !== getReplies || $[26] !== messages || $[27] !== sendMessage || $[28] !== topLevelMessages) {
        t9 = {
            messages,
            topLevelMessages,
            sendMessage,
            editMessage,
            deleteMessage,
            addReaction,
            getReplies
        };
        $[22] = addReaction;
        $[23] = deleteMessage;
        $[24] = editMessage;
        $[25] = getReplies;
        $[26] = messages;
        $[27] = sendMessage;
        $[28] = topLevelMessages;
        $[29] = t9;
    } else {
        t9 = $[29];
    }
    return t9;
}
_s2(useChatThread, "dMiLn6t5LC6b/+LW9v6mSM5lssk=");
/**
 * Hook for chat room presence — online users, typing indicators, active topics.
 */ function _useChatThreadMessagesFilter(m) {
    return m.parentId === null;
}
function useChatPresence(provider, topicId) {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [onlineUsers, setOnlineUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [typingUsers, setTypingUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const [usersInTopic, setUsersInTopic] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    let t4;
    if ($[4] !== provider || $[5] !== topicId) {
        t3 = ({
            "useChatPresence[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const awareness = provider.getAwareness();
                const handleChange = {
                    "useChatPresence[useEffect() > handleChange]": ()=>{
                        const online = [];
                        const typing = [];
                        const inTopic = [];
                        awareness.getStates().forEach({
                            "useChatPresence[useEffect() > handleChange > (anonymous)()]": (state, clientId)=>{
                                if (clientId === awareness.clientID) {
                                    return;
                                }
                                const peerUser = state.user;
                                if (!peerUser) {
                                    return;
                                }
                                online.push(peerUser);
                                if (state.typing) {
                                    typing.push(peerUser);
                                }
                                if (topicId && state.activeTopic === topicId) {
                                    inTopic.push(peerUser);
                                }
                            }
                        }["useChatPresence[useEffect() > handleChange > (anonymous)()]"]);
                        setOnlineUsers(online);
                        setTypingUsers(typing);
                        setUsersInTopic(inTopic);
                    }
                }["useChatPresence[useEffect() > handleChange]"];
                handleChange();
                awareness.on("change", handleChange);
                return ()=>{
                    awareness.off("change", handleChange);
                };
            }
        })["useChatPresence[useEffect()]"];
        t4 = [
            provider,
            topicId
        ];
        $[4] = provider;
        $[5] = topicId;
        $[6] = t3;
        $[7] = t4;
    } else {
        t3 = $[6];
        t4 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    let t5;
    if ($[8] !== onlineUsers || $[9] !== typingUsers || $[10] !== usersInTopic) {
        t5 = {
            onlineUsers,
            typingUsers,
            usersInTopic
        };
        $[8] = onlineUsers;
        $[9] = typingUsers;
        $[10] = usersInTopic;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    return t5;
}
_s3(useChatPresence, "895iuv1s1S0fDfDisjcEyQGP4Dc=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0en-atg._.js.map