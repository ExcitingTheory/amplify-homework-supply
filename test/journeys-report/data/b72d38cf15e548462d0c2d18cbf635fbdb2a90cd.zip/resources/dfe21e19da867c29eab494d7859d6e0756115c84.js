(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_components_Editor3_components_TableComponent_jsx_00tjggy._.js","static/chunks/src_components_Editor3_00wz9d.._.js","static/chunks/src_components_DictionaryEditor2_jsx_00~wd-~._.js","static/chunks/src_components_Chat_06kw_71._.js","static/chunks/src_components_0vl8try._.js","static/chunks/src_0en-atg._.js","static/chunks/app_[locale]_unit_[id]_UnitEditorClient_jsx_0raae4_._.js","static/chunks/node_modules_13ijt_i._.js"],
    source: "dynamic"
});
