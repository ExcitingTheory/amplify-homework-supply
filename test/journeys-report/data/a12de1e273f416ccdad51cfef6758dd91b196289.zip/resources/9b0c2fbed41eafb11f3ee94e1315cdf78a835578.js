(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * OfflineDataStore — IndexedDB persistence layer for offline student data.
 *
 * Stores units, words, questions, files (as blobs), grades, student memory,
 * and a sync queue for deferred mutations. Uses the `idb` library that is
 * already a project dependency via VectorStoreDB.
 */ __turbopack_context__.s([
    "cacheFile",
    ()=>cacheFile,
    "cacheGrade",
    ()=>cacheGrade,
    "cacheQuestion",
    ()=>cacheQuestion,
    "cacheStudentMemory",
    ()=>cacheStudentMemory,
    "cacheUnit",
    ()=>cacheUnit,
    "cacheWord",
    ()=>cacheWord,
    "clearStore",
    ()=>clearStore,
    "clearUnitCache",
    ()=>clearUnitCache,
    "deleteRecord",
    ()=>deleteRecord,
    "getAllPrefetchStatuses",
    ()=>getAllPrefetchStatuses,
    "getAllRecords",
    ()=>getAllRecords,
    "getCachedFileBlob",
    ()=>getCachedFileBlob,
    "getCachedFilesForUnit",
    ()=>getCachedFilesForUnit,
    "getCachedGrade",
    ()=>getCachedGrade,
    "getCachedQuestionsForUnit",
    ()=>getCachedQuestionsForUnit,
    "getCachedStudentMemory",
    ()=>getCachedStudentMemory,
    "getCachedUnit",
    ()=>getCachedUnit,
    "getCachedWordsForUnit",
    ()=>getCachedWordsForUnit,
    "getPrefetchStatus",
    ()=>getPrefetchStatus,
    "getRecord",
    ()=>getRecord,
    "getRecordsByIndex",
    ()=>getRecordsByIndex,
    "getStorageEstimate",
    ()=>getStorageEstimate,
    "getUnsyncedGrades",
    ()=>getUnsyncedGrades,
    "putRecord",
    ()=>putRecord,
    "setPrefetchStatus",
    ()=>setPrefetchStatus
]);
// ── DB Setup ──────────────────────────────────────────────────────────────────
const DB_NAME = 'OfflineDataStore';
const DB_VERSION = 1;
let openDB;
let _depsLoaded = false;
async function loadDeps() {
    if (_depsLoaded || ("TURBOPACK compile-time value", "object") === 'undefined') return;
    ({ openDB } = await __turbopack_context__.A("[project]/node_modules/idb/build/index.js [app-client] (ecmascript, async loader)"));
    _depsLoaded = true;
}
let _dbPromise = null;
async function getDB() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    await loadDeps();
    if (!_dbPromise) {
        _dbPromise = openDB(DB_NAME, DB_VERSION, {
            upgrade (db) {
                // Units store
                if (!db.objectStoreNames.contains('units')) {
                    db.createObjectStore('units', {
                        keyPath: 'id'
                    });
                }
                // Words store
                if (!db.objectStoreNames.contains('words')) {
                    const words = db.createObjectStore('words', {
                        keyPath: 'id'
                    });
                    words.createIndex('unitId', 'unitId', {
                        unique: false
                    });
                }
                // Questions store
                if (!db.objectStoreNames.contains('questions')) {
                    const questions = db.createObjectStore('questions', {
                        keyPath: 'id'
                    });
                    questions.createIndex('unitId', 'unitId', {
                        unique: false
                    });
                }
                // Files store (blobs)
                if (!db.objectStoreNames.contains('files')) {
                    const files = db.createObjectStore('files', {
                        keyPath: 'id'
                    });
                    files.createIndex('unitId', 'unitId', {
                        unique: false
                    });
                }
                // Grades store
                if (!db.objectStoreNames.contains('grades')) {
                    const grades = db.createObjectStore('grades', {
                        keyPath: 'id'
                    });
                    grades.createIndex('unitId', 'unitId', {
                        unique: false
                    });
                    grades.createIndex('synced', 'synced', {
                        unique: false
                    });
                }
                // Student memory
                if (!db.objectStoreNames.contains('studentMemory')) {
                    db.createObjectStore('studentMemory', {
                        keyPath: 'id'
                    });
                }
                // Sync queue
                if (!db.objectStoreNames.contains('syncQueue')) {
                    const sq = db.createObjectStore('syncQueue', {
                        keyPath: 'id',
                        autoIncrement: true
                    });
                    sq.createIndex('createdAt', 'createdAt', {
                        unique: false
                    });
                }
                // Prefetch status
                if (!db.objectStoreNames.contains('prefetchStatus')) {
                    db.createObjectStore('prefetchStatus', {
                        keyPath: 'unitId'
                    });
                }
            }
        });
    }
    return _dbPromise;
}
async function putRecord(store, value) {
    const db = await getDB();
    await db.put(store, value);
}
async function getRecord(store, key) {
    const db = await getDB();
    return db.get(store, key);
}
async function getAllRecords(store) {
    const db = await getDB();
    return db.getAll(store);
}
async function getRecordsByIndex(store, indexName, key) {
    const db = await getDB();
    return db.getAllFromIndex(store, indexName, key);
}
async function deleteRecord(store, key) {
    const db = await getDB();
    await db.delete(store, key);
}
async function clearStore(store) {
    const db = await getDB();
    await db.clear(store);
}
async function cacheUnit(unit) {
    await putRecord('units', {
        ...unit,
        cachedAt: Date.now()
    });
}
async function getCachedUnit(unitId) {
    return getRecord('units', unitId);
}
async function cacheWord(word) {
    await putRecord('words', {
        ...word,
        cachedAt: Date.now()
    });
}
async function getCachedWordsForUnit(unitId) {
    return getRecordsByIndex('words', 'unitId', unitId);
}
async function cacheQuestion(question) {
    await putRecord('questions', {
        ...question,
        cachedAt: Date.now()
    });
}
async function getCachedQuestionsForUnit(unitId) {
    return getRecordsByIndex('questions', 'unitId', unitId);
}
async function cacheFile(file) {
    await putRecord('files', {
        ...file,
        cachedAt: Date.now()
    });
}
async function getCachedFilesForUnit(unitId) {
    return getRecordsByIndex('files', 'unitId', unitId);
}
async function getCachedFileBlob(fileId) {
    const record = await getRecord('files', fileId);
    return record?.blob;
}
async function cacheGrade(grade) {
    await putRecord('grades', grade);
}
async function getCachedGrade(gradeId) {
    return getRecord('grades', gradeId);
}
async function getUnsyncedGrades() {
    return getRecordsByIndex('grades', 'synced', 0);
}
async function cacheStudentMemory(memory) {
    await putRecord('studentMemory', {
        ...memory,
        cachedAt: Date.now()
    });
}
async function getCachedStudentMemory(id) {
    return getRecord('studentMemory', id);
}
async function setPrefetchStatus(status) {
    await putRecord('prefetchStatus', status);
}
async function getPrefetchStatus(unitId) {
    return getRecord('prefetchStatus', unitId);
}
async function getAllPrefetchStatuses() {
    return getAllRecords('prefetchStatus');
}
async function getStorageEstimate() {
    if (typeof navigator !== 'undefined' && navigator.storage?.estimate) {
        const est = await navigator.storage.estimate();
        return {
            usage: est.usage ?? 0,
            quota: est.quota ?? 0
        };
    }
    return {
        usage: 0,
        quota: 0
    };
}
async function clearUnitCache(unitId) {
    const db = await getDB();
    const stores = [
        'words',
        'questions',
        'files'
    ];
    for (const storeName of stores){
        const tx = db.transaction(storeName, 'readwrite');
        const index = tx.store.index('unitId');
        let cursor = await index.openCursor(unitId);
        while(cursor){
            await cursor.delete();
            cursor = await cursor.continue();
        }
        await tx.done;
    }
    await db.delete('units', unitId);
    await db.delete('prefetchStatus', unitId);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_offline_OfflineDataStore_ts_0b_0oq9._.js.map