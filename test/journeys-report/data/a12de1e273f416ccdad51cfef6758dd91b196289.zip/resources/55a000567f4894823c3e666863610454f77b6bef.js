(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@mlc-ai/web-llm/lib/index.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@mlc-ai_web-llm_lib_index_0zf.q.~.js",
  "static/chunks/node_modules_next_dist_compiled_0qxq5ab._.js",
  "static/chunks/node_modules_@mlc-ai_web-llm_lib_index_0rl4-9o.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@mlc-ai/web-llm/lib/index.js [app-client] (ecmascript)");
    });
});
}),
]);