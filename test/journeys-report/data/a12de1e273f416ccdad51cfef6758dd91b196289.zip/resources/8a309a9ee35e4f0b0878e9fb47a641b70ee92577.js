(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_@mlc-ai_web-llm_lib_index_0_m2kkk.js","static/chunks/src_offline_ModelManager_ts_0fxml30._.js"],
    source: "dynamic"
});
