(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/offline/ModelManager.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * ModelManager — Manages download, storage, and lifecycle of on-device AI models.
 *
 * Handles storage budget checks, download progress, and cleanup for
 * the WebLLM model cache. Chrome Built-in AI requires no management
 * as the model is pre-installed.
 */ // ── Types ─────────────────────────────────────────────────────────────────────
__turbopack_context__.s([
    "deleteWebLLMModel",
    ()=>deleteWebLLMModel,
    "downloadWebLLMModel",
    ()=>downloadWebLLMModel,
    "formatBytes",
    ()=>formatBytes,
    "getAvailableModels",
    ()=>getAvailableModels,
    "getStorageBudget",
    ()=>getStorageBudget,
    "isWebLLMModelReady",
    ()=>isWebLLMModelReady
]);
// ── Constants ─────────────────────────────────────────────────────────────────
const WEBLLM_MODEL_ID = 'Phi-3.5-mini-instruct-q4f16_1-MLC';
const WEBLLM_MODEL_SIZE_BYTES = 2.4 * 1024 * 1024 * 1024; // ~2.4 GB
async function getStorageBudget() {
    if (typeof navigator === 'undefined' || !navigator.storage?.estimate) {
        return {
            used: 0,
            quota: 0,
            percentUsed: 0
        };
    }
    const est = await navigator.storage.estimate();
    const used = est.usage ?? 0;
    const quota = est.quota ?? 0;
    return {
        used,
        quota,
        percentUsed: quota > 0 ? Math.round(used / quota * 100) : 0
    };
}
async function isWebLLMModelReady() {
    try {
        // WebLLM stores models in Cache API under 'webllm/model'
        const cacheNames = await caches.keys();
        return cacheNames.some((name)=>name.includes('webllm') || name.includes('mlc'));
    } catch  {
        return false;
    }
}
async function getAvailableModels() {
    const models = [];
    // Chrome Built-in AI
    if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.ai?.languageModel) {
        try {
            const status = await window.ai.languageModel.canCreate();
            models.push({
                id: 'chrome-gemini-nano',
                name: 'Gemini Nano (Built-in)',
                sizeBytes: 0,
                backend: 'chrome-ai',
                ready: status === 'readily'
            });
        } catch  {
        // Not available
        }
    }
    // WebLLM
    if (typeof navigator !== 'undefined' && 'gpu' in navigator) {
        const ready = await isWebLLMModelReady();
        models.push({
            id: WEBLLM_MODEL_ID,
            name: 'Phi-3.5 Mini (WebLLM)',
            sizeBytes: WEBLLM_MODEL_SIZE_BYTES,
            backend: 'webllm',
            ready
        });
    }
    return models;
}
async function downloadWebLLMModel(onProgress) {
    // Check storage budget first
    const budget = await getStorageBudget();
    const availableBytes = budget.quota - budget.used;
    if (availableBytes < WEBLLM_MODEL_SIZE_BYTES) {
        throw new Error(`Insufficient storage. Need ${formatBytes(WEBLLM_MODEL_SIZE_BYTES)} but only ${formatBytes(availableBytes)} available.`);
    }
    try {
        const { CreateMLCEngine } = await __turbopack_context__.A("[project]/node_modules/@mlc-ai/web-llm/lib/index.js [app-client] (ecmascript, async loader)");
        const engine = await CreateMLCEngine(WEBLLM_MODEL_ID, {
            initProgressCallback: (report)=>{
                onProgress?.(Math.round(report.progress * 100));
            }
        });
        // Engine created successfully — model is now cached
        // We don't keep the engine running, just wanted to trigger the download
        await engine.unload();
        return true;
    } catch (err) {
        console.error('[ModelManager] WebLLM download failed:', err);
        return false;
    }
}
async function deleteWebLLMModel() {
    const cacheNames = await caches.keys();
    for (const name of cacheNames){
        if (name.includes('webllm') || name.includes('mlc')) {
            await caches.delete(name);
        }
    }
}
function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const units = [
        'B',
        'KB',
        'MB',
        'GB',
        'TB'
    ];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_offline_ModelManager_ts_0fxml30._.js.map