(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_offline_ModelManager_ts_0oqc04w._.js","static/chunks/_02pykjz._.js","static/chunks/node_modules_0ncybfr._.js"],
    source: "dynamic"
});
