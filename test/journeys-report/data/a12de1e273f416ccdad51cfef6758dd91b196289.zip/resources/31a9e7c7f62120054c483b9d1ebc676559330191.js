(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/offline/ModelManager.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@mlc-ai_web-llm_lib_index_0_m2kkk.js",
  "static/chunks/src_offline_ModelManager_ts_0fxml30._.js",
  "static/chunks/src_offline_ModelManager_ts_0rl4-9o._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/offline/ModelManager.ts [app-client] (ecmascript)");
    });
});
}),
]);