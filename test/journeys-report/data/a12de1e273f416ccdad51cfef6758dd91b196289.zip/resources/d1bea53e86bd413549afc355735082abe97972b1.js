(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/storageManagementReducer.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * storageManagementReducer — State for StorageManagement component.
 *
 * Manages data loading (storage budget, models, prefetch statuses)
 * and download state machine (idle → downloading → idle).
 */ // ============================================================================
// Types
// ============================================================================
__turbopack_context__.s([
    "initialStorageManagementState",
    ()=>initialStorageManagementState,
    "storageManagementReducer",
    ()=>storageManagementReducer
]);
const initialStorageManagementState = {
    storageBudget: {
        used: 0,
        quota: 0,
        percentUsed: 0
    },
    models: [],
    prefetchStatuses: [],
    downloadStatus: "idle",
    downloadProgress: 0
};
function storageManagementReducer(state, action) {
    switch(action.type){
        case "SET_DATA":
            return {
                ...state,
                ...action.storageBudget !== undefined && {
                    storageBudget: action.storageBudget
                },
                ...action.models !== undefined && {
                    models: action.models
                },
                ...action.prefetchStatuses !== undefined && {
                    prefetchStatuses: action.prefetchStatuses
                }
            };
        case "DOWNLOAD_START":
            return {
                ...state,
                downloadStatus: "downloading",
                downloadProgress: 0
            };
        case "DOWNLOAD_PROGRESS":
            return {
                ...state,
                downloadProgress: action.progress
            };
        case "DOWNLOAD_COMPLETE":
            return {
                ...state,
                downloadStatus: "idle",
                downloadProgress: 0
            };
        case "DOWNLOAD_ERROR":
            return {
                ...state,
                downloadStatus: "idle",
                downloadProgress: 0
            };
        default:
            return state;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/StorageManagement.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StorageManagement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript) <export default as CardContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemSecondaryAction$2f$ListItemSecondaryAction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemSecondaryAction$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemSecondaryAction/ListItemSecondaryAction.js [app-client] (ecmascript) <export default as ListItemSecondaryAction>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Delete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudDownload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CloudDownload.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Storage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SmartToy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/SmartToy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$storageManagementReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/storageManagementReducer.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
function StorageManagement() {
    _s();
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$storageManagementReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storageManagementReducer"], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$storageManagementReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialStorageManagementState"]);
    const { storageBudget, models, prefetchStatuses, downloadStatus, downloadProgress } = state;
    const downloading = downloadStatus === 'downloading';
    const refresh = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StorageManagement.useCallback[refresh]": async ()=>{
            try {
                const { getStorageBudget, getAvailableModels } = await __turbopack_context__.A("[project]/src/offline/ModelManager.ts [app-client] (ecmascript, async loader)");
                const { getAllPrefetchStatuses } = await __turbopack_context__.A("[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript, async loader)");
                const results = await Promise.allSettled([
                    getStorageBudget(),
                    getAvailableModels(),
                    getAllPrefetchStatuses()
                ]);
                dispatch({
                    type: 'SET_DATA',
                    storageBudget: results[0].status === 'fulfilled' ? results[0].value : undefined,
                    models: results[1].status === 'fulfilled' ? results[1].value : undefined,
                    prefetchStatuses: results[2].status === 'fulfilled' ? results[2].value : undefined
                });
            } catch  {
            // Modules not loaded
            }
        }
    }["StorageManagement.useCallback[refresh]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StorageManagement.useEffect": ()=>{
            refresh();
        }
    }["StorageManagement.useEffect"], [
        refresh
    ]);
    const handleDownloadModel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StorageManagement.useCallback[handleDownloadModel]": async ()=>{
            dispatch({
                type: 'DOWNLOAD_START'
            });
            try {
                const { downloadWebLLMModel } = await __turbopack_context__.A("[project]/src/offline/ModelManager.ts [app-client] (ecmascript, async loader)");
                await downloadWebLLMModel({
                    "StorageManagement.useCallback[handleDownloadModel]": (p)=>dispatch({
                            type: 'DOWNLOAD_PROGRESS',
                            progress: p
                        })
                }["StorageManagement.useCallback[handleDownloadModel]"]);
                dispatch({
                    type: 'DOWNLOAD_COMPLETE'
                });
                await refresh();
            } catch (err) {
                console.error('Model download failed:', err);
                dispatch({
                    type: 'DOWNLOAD_ERROR'
                });
            }
        }
    }["StorageManagement.useCallback[handleDownloadModel]"], [
        refresh
    ]);
    const handleDeleteModel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StorageManagement.useCallback[handleDeleteModel]": async ()=>{
            try {
                const { deleteWebLLMModel } = await __turbopack_context__.A("[project]/src/offline/ModelManager.ts [app-client] (ecmascript, async loader)");
                await deleteWebLLMModel();
                await refresh();
            } catch (err_0) {
                console.error('Model deletion failed:', err_0);
            }
        }
    }["StorageManagement.useCallback[handleDeleteModel]"], [
        refresh
    ]);
    const handleClearUnitCache = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StorageManagement.useCallback[handleClearUnitCache]": async (unitId)=>{
            try {
                const { clearUnitCache } = await __turbopack_context__.A("[project]/src/offline/OfflineDataStore.ts [app-client] (ecmascript, async loader)");
                await clearUnitCache(unitId);
                await refresh();
            } catch (err_1) {
                console.error('Cache clear failed:', err_1);
            }
        }
    }["StorageManagement.useCallback[handleClearUnitCache]"], [
        refresh
    ]);
    const formatBytes = (bytes)=>{
        if (bytes === 0) return '0 B';
        const units = [
            'B',
            'KB',
            'MB',
            'GB'
        ];
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            display: 'flex',
            flexDirection: 'column',
            gap: 3
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                            direction: "row",
                            alignItems: "center",
                            spacing: 1,
                            mb: 2,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    color: "primary"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                    lineNumber: 103,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "h6",
                                    children: "Offline Storage"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                    lineNumber: 104,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/StorageManagement.tsx",
                            lineNumber: 102,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                            variant: "determinate",
                            value: storageBudget.percentUsed,
                            sx: {
                                height: 8,
                                borderRadius: 4,
                                mb: 1
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/StorageManagement.tsx",
                            lineNumber: 106,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "text.secondary",
                            children: [
                                formatBytes(storageBudget.used),
                                " of ",
                                formatBytes(storageBudget.quota),
                                " used (",
                                storageBudget.percentUsed,
                                "%)"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/StorageManagement.tsx",
                            lineNumber: 111,
                            columnNumber: 11
                        }, this),
                        storageBudget.percentUsed > 80 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                            severity: "warning",
                            sx: {
                                mt: 1
                            },
                            children: "Storage is getting full. Consider removing cached assignments or the AI model to free space."
                        }, void 0, false, {
                            fileName: "[project]/src/components/StorageManagement.tsx",
                            lineNumber: 115,
                            columnNumber: 46
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/StorageManagement.tsx",
                    lineNumber: 101,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/StorageManagement.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                            direction: "row",
                            alignItems: "center",
                            spacing: 1,
                            mb: 2,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SmartToy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    color: "primary"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                    lineNumber: 128,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "h6",
                                    children: "AI Model for Offline Use"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                    lineNumber: 129,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/StorageManagement.tsx",
                            lineNumber: 127,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                            dense: true,
                            children: models.map((model)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                            primary: model.name,
                                            secondary: model.sizeBytes > 0 ? `${formatBytes(model.sizeBytes)} · ${model.ready ? 'Downloaded' : 'Not downloaded'}` : 'Pre-installed — no download needed'
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/StorageManagement.tsx",
                                            lineNumber: 133,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemSecondaryAction$2f$ListItemSecondaryAction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemSecondaryAction$3e$__["ListItemSecondaryAction"], {
                                            children: model.backend === 'chrome-ai' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                                    lineNumber: 135,
                                                    columnNumber: 64
                                                }, this),
                                                label: "Built-in",
                                                color: "success",
                                                size: "small"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/StorageManagement.tsx",
                                                lineNumber: 135,
                                                columnNumber: 52
                                            }, this) : model.ready ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                edge: "end",
                                                onClick: handleDeleteModel,
                                                title: "Remove model",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                                    lineNumber: 136,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/StorageManagement.tsx",
                                                lineNumber: 135,
                                                columnNumber: 146
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                size: "small",
                                                variant: "outlined",
                                                startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudDownload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                                    lineNumber: 137,
                                                    columnNumber: 88
                                                }, this),
                                                onClick: handleDownloadModel,
                                                disabled: downloading,
                                                children: "Download"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/StorageManagement.tsx",
                                                lineNumber: 137,
                                                columnNumber: 37
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/StorageManagement.tsx",
                                            lineNumber: 134,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, model.id, true, {
                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                    lineNumber: 132,
                                    columnNumber: 34
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/StorageManagement.tsx",
                            lineNumber: 131,
                            columnNumber: 11
                        }, this),
                        downloading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                mt: 1
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                                    variant: "determinate",
                                    value: downloadProgress
                                }, void 0, false, {
                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                    lineNumber: 146,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "caption",
                                    color: "text.secondary",
                                    children: [
                                        "Downloading AI model... ",
                                        downloadProgress,
                                        "%"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                    lineNumber: 147,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/StorageManagement.tsx",
                            lineNumber: 143,
                            columnNumber: 27
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/StorageManagement.tsx",
                    lineNumber: 126,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/StorageManagement.tsx",
                lineNumber: 125,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "h6",
                            gutterBottom: true,
                            children: "Cached Assignments"
                        }, void 0, false, {
                            fileName: "[project]/src/components/StorageManagement.tsx",
                            lineNumber: 157,
                            columnNumber: 11
                        }, this),
                        prefetchStatuses.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "text.secondary",
                            children: "No assignments cached for offline use yet. Open an assignment to cache it automatically."
                        }, void 0, false, {
                            fileName: "[project]/src/components/StorageManagement.tsx",
                            lineNumber: 160,
                            columnNumber: 44
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                            dense: true,
                            children: prefetchStatuses.map((status)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                            primary: `Unit: ${status.unitId.slice(0, 8)}...`,
                                            secondary: `${status.status} · Last updated ${new Date(status.lastUpdated).toLocaleDateString()}`
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/StorageManagement.tsx",
                                            lineNumber: 165,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemSecondaryAction$2f$ListItemSecondaryAction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemSecondaryAction$3e$__["ListItemSecondaryAction"], {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                edge: "end",
                                                onClick: ()=>handleClearUnitCache(status.unitId),
                                                title: "Remove offline data",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                                    lineNumber: 168,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/StorageManagement.tsx",
                                                lineNumber: 167,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/StorageManagement.tsx",
                                            lineNumber: 166,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, status.unitId, true, {
                                    fileName: "[project]/src/components/StorageManagement.tsx",
                                    lineNumber: 164,
                                    columnNumber: 47
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/StorageManagement.tsx",
                            lineNumber: 163,
                            columnNumber: 29
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/StorageManagement.tsx",
                    lineNumber: 156,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/StorageManagement.tsx",
                lineNumber: 155,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/StorageManagement.tsx",
        lineNumber: 94,
        columnNumber: 10
    }, this);
}
_s(StorageManagement, "FMnKrx5qnvKr6H5/sdDJ4pIFlBk=");
_c = StorageManagement;
var _c;
__turbopack_context__.k.register(_c, "StorageManagement");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/AvatarCustomizer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AvatarCustomizer",
    ()=>AvatarCustomizer,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * AvatarCustomizer — Progressive customization dialog for DiceBear avatars.
 * Unlocks features based on student level:
 *   L1: Background color, skin tone, basic face (eyebrows, eyes, mouth)
 *   L2: + hair color, clothes color, hair/top, clothing
 *   L3: + facial hair, accessories, full toon head features, style selector
 *
 * Color customization is ALWAYS available from L1. Detail features unlock
 * progressively within each style.
 *
 * Options are limited to the documented DiceBear API for each style.
 *
 * @module AvatarCustomizer
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Lock.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RestartAlt$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RestartAlt.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Switch/Switch.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/DiceBearAvatar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$AvatarGlowRing$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/AvatarGlowRing.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// ============================================================================
// Documented option constants (from DiceBear v9.x docs)
// ============================================================================
const BACKGROUND_COLORS = [
    'b6e3f4',
    'c0aede',
    'd1d4f9',
    'ffd5dc',
    'ffdfbf',
    'd1f4d1',
    'fff3b0',
    'f0f0f0'
];
// -- Avataaars Neutral (simple) --
const NEUTRAL_EYEBROWS = [
    {
        id: 'angry',
        label: 'Angry'
    },
    {
        id: 'angryNatural',
        label: 'Angry Natural'
    },
    {
        id: 'default',
        label: 'Default'
    },
    {
        id: 'defaultNatural',
        label: 'Default Natural'
    },
    {
        id: 'flatNatural',
        label: 'Flat Natural'
    },
    {
        id: 'frownNatural',
        label: 'Frown Natural'
    },
    {
        id: 'raisedExcited',
        label: 'Raised Excited'
    },
    {
        id: 'raisedExcitedNatural',
        label: 'Raised Excited Natural'
    },
    {
        id: 'sadConcerned',
        label: 'Sad Concerned'
    },
    {
        id: 'sadConcernedNatural',
        label: 'Sad Concerned Natural'
    },
    {
        id: 'unibrowNatural',
        label: 'Unibrow Natural'
    },
    {
        id: 'upDown',
        label: 'Up Down'
    },
    {
        id: 'upDownNatural',
        label: 'Up Down Natural'
    }
];
const NEUTRAL_EYES = [
    {
        id: 'closed',
        label: 'Closed'
    },
    {
        id: 'cry',
        label: 'Cry'
    },
    {
        id: 'default',
        label: 'Default'
    },
    {
        id: 'eyeRoll',
        label: 'Eye Roll'
    },
    {
        id: 'happy',
        label: 'Happy'
    },
    {
        id: 'hearts',
        label: 'Hearts'
    },
    {
        id: 'side',
        label: 'Side'
    },
    {
        id: 'squint',
        label: 'Squint'
    },
    {
        id: 'surprised',
        label: 'Surprised'
    },
    {
        id: 'wink',
        label: 'Wink'
    },
    {
        id: 'winkWacky',
        label: 'Wink Wacky'
    },
    {
        id: 'xDizzy',
        label: 'X Dizzy'
    }
];
const NEUTRAL_MOUTH = [
    {
        id: 'concerned',
        label: 'Concerned'
    },
    {
        id: 'default',
        label: 'Default'
    },
    {
        id: 'disbelief',
        label: 'Disbelief'
    },
    {
        id: 'eating',
        label: 'Eating'
    },
    {
        id: 'grimace',
        label: 'Grimace'
    },
    {
        id: 'sad',
        label: 'Sad'
    },
    {
        id: 'screamOpen',
        label: 'Scream'
    },
    {
        id: 'serious',
        label: 'Serious'
    },
    {
        id: 'smile',
        label: 'Smile'
    },
    {
        id: 'tongue',
        label: 'Tongue'
    },
    {
        id: 'twinkle',
        label: 'Twinkle'
    },
    {
        id: 'vomit',
        label: 'Vomit'
    }
];
// -- Avataaars (detailed) — same face options + clothing/hair/accessories --
const DETAILED_SKIN_COLORS = [
    '614335',
    'ae5d29',
    'd08b5b',
    'edb98a',
    'f8d25c',
    'fd9841',
    'ffdbb4'
];
const DETAILED_HAIR_COLORS = [
    '2c1b18',
    '4a312c',
    '724133',
    'a55728',
    'b58143',
    'c93305',
    'd6b370',
    'e8e1e1',
    'ecdcbf',
    'f59797'
];
const DETAILED_CLOTHES_COLORS = [
    '3c4f5c',
    '65c9ff',
    '262e33',
    '5199e4',
    '25557c',
    '929598',
    'a7ffc4',
    'b1e2ff',
    'e6e6e6',
    'ff5c5c',
    'ff488e',
    'ffafb9',
    'ffdeb5',
    'ffffb1',
    'ffffff'
];
const DETAILED_TOP = [
    {
        id: 'bigHair',
        label: 'Big Hair'
    },
    {
        id: 'bob',
        label: 'Bob'
    },
    {
        id: 'bun',
        label: 'Bun'
    },
    {
        id: 'curly',
        label: 'Curly'
    },
    {
        id: 'curvy',
        label: 'Curvy'
    },
    {
        id: 'dreads',
        label: 'Dreads'
    },
    {
        id: 'dreads01',
        label: 'Dreads 01'
    },
    {
        id: 'dreads02',
        label: 'Dreads 02'
    },
    {
        id: 'frida',
        label: 'Frida'
    },
    {
        id: 'frizzle',
        label: 'Frizzle'
    },
    {
        id: 'fro',
        label: 'Fro'
    },
    {
        id: 'froBand',
        label: 'Fro Band'
    },
    {
        id: 'hat',
        label: 'Hat'
    },
    {
        id: 'hijab',
        label: 'Hijab'
    },
    {
        id: 'longButNotTooLong',
        label: 'Long'
    },
    {
        id: 'miaWallace',
        label: 'Mia Wallace'
    },
    {
        id: 'shaggy',
        label: 'Shaggy'
    },
    {
        id: 'shaggyMullet',
        label: 'Shaggy Mullet'
    },
    {
        id: 'shavedSides',
        label: 'Shaved Sides'
    },
    {
        id: 'shortCurly',
        label: 'Short Curly'
    },
    {
        id: 'shortFlat',
        label: 'Short Flat'
    },
    {
        id: 'shortRound',
        label: 'Short Round'
    },
    {
        id: 'shortWaved',
        label: 'Short Waved'
    },
    {
        id: 'sides',
        label: 'Sides'
    },
    {
        id: 'straight01',
        label: 'Straight 01'
    },
    {
        id: 'straight02',
        label: 'Straight 02'
    },
    {
        id: 'straightAndStrand',
        label: 'Straight & Strand'
    },
    {
        id: 'theCaesar',
        label: 'The Caesar'
    },
    {
        id: 'theCaesarAndSidePart',
        label: 'Caesar & Side Part'
    },
    {
        id: 'turban',
        label: 'Turban'
    },
    {
        id: 'winterHat1',
        label: 'Winter Hat 1'
    },
    {
        id: 'winterHat02',
        label: 'Winter Hat 2'
    },
    {
        id: 'winterHat03',
        label: 'Winter Hat 3'
    },
    {
        id: 'winterHat04',
        label: 'Winter Hat 4'
    }
];
const DETAILED_CLOTHING = [
    {
        id: 'blazerAndShirt',
        label: 'Blazer & Shirt'
    },
    {
        id: 'blazerAndSweater',
        label: 'Blazer & Sweater'
    },
    {
        id: 'collarAndSweater',
        label: 'Collar & Sweater'
    },
    {
        id: 'graphicShirt',
        label: 'Graphic Shirt'
    },
    {
        id: 'hoodie',
        label: 'Hoodie'
    },
    {
        id: 'overall',
        label: 'Overall'
    },
    {
        id: 'shirtCrewNeck',
        label: 'Crew Neck'
    },
    {
        id: 'shirtScoopNeck',
        label: 'Scoop Neck'
    },
    {
        id: 'shirtVNeck',
        label: 'V-Neck'
    }
];
const DETAILED_FACIAL_HAIR = [
    {
        id: 'beardLight',
        label: 'Light Beard'
    },
    {
        id: 'beardMajestic',
        label: 'Majestic Beard'
    },
    {
        id: 'beardMedium',
        label: 'Medium Beard'
    },
    {
        id: 'moustacheFancy',
        label: 'Fancy Moustache'
    },
    {
        id: 'moustacheMagnum',
        label: 'Magnum Moustache'
    }
];
const DETAILED_ACCESSORIES = [
    {
        id: 'eyepatch',
        label: 'Eyepatch'
    },
    {
        id: 'kurt',
        label: 'Kurt'
    },
    {
        id: 'prescription01',
        label: 'Glasses 01'
    },
    {
        id: 'prescription02',
        label: 'Glasses 02'
    },
    {
        id: 'round',
        label: 'Round Glasses'
    },
    {
        id: 'sunglasses',
        label: 'Sunglasses'
    },
    {
        id: 'wayfarers',
        label: 'Wayfarers'
    }
];
// -- Toon Head --
const TOONHEAD_SKIN_COLORS = [
    '5c3829',
    'a36b4f',
    'b98e6a',
    'c68e7a',
    'f1c3a5'
];
const TOONHEAD_HAIR_COLORS = [
    '2c1b18',
    '724133',
    'a55728',
    'b58143',
    'd6b370'
];
const TOONHEAD_CLOTHES_COLORS = [
    '0b3286',
    '147f3c',
    '731ac3',
    '151613',
    '545454',
    'b11f1f',
    'e8e9e6',
    'eab308',
    'ec4899',
    'f97316'
];
const TOONHEAD_EYEBROWS = [
    {
        id: 'angry',
        label: 'Angry'
    },
    {
        id: 'happy',
        label: 'Happy'
    },
    {
        id: 'neutral',
        label: 'Neutral'
    },
    {
        id: 'raised',
        label: 'Raised'
    },
    {
        id: 'sad',
        label: 'Sad'
    }
];
const TOONHEAD_EYES = [
    {
        id: 'bow',
        label: 'Bow'
    },
    {
        id: 'happy',
        label: 'Happy'
    },
    {
        id: 'humble',
        label: 'Humble'
    },
    {
        id: 'wide',
        label: 'Wide'
    },
    {
        id: 'wink',
        label: 'Wink'
    }
];
const TOONHEAD_HAIR = [
    {
        id: 'bun',
        label: 'Bun'
    },
    {
        id: 'sideComed',
        label: 'Side Combed'
    },
    {
        id: 'spiky',
        label: 'Spiky'
    },
    {
        id: 'undercut',
        label: 'Undercut'
    }
];
const TOONHEAD_MOUTH = [
    {
        id: 'agape',
        label: 'Agape'
    },
    {
        id: 'angry',
        label: 'Angry'
    },
    {
        id: 'laugh',
        label: 'Laugh'
    },
    {
        id: 'sad',
        label: 'Sad'
    },
    {
        id: 'smile',
        label: 'Smile'
    }
];
const TOONHEAD_BEARD = [
    {
        id: 'chin',
        label: 'Chin'
    },
    {
        id: 'chinMoustache',
        label: 'Chin + Moustache'
    },
    {
        id: 'fullBeard',
        label: 'Full Beard'
    },
    {
        id: 'longBeard',
        label: 'Long Beard'
    },
    {
        id: 'moustacheTwirl',
        label: 'Moustache Twirl'
    }
];
const TOONHEAD_CLOTHES = [
    {
        id: 'dress',
        label: 'Dress'
    },
    {
        id: 'openJacket',
        label: 'Open Jacket'
    },
    {
        id: 'shirt',
        label: 'Shirt'
    },
    {
        id: 'tShirt',
        label: 'T-Shirt'
    },
    {
        id: 'turtleNeck',
        label: 'Turtleneck'
    }
];
const TOONHEAD_REAR_HAIR = [
    {
        id: 'longStraight',
        label: 'Long Straight'
    },
    {
        id: 'longWavy',
        label: 'Long Wavy'
    },
    {
        id: 'neckHigh',
        label: 'Neck High'
    },
    {
        id: 'shoulderHigh',
        label: 'Shoulder High'
    }
];
// ============================================================================
// Sub-components
// ============================================================================
function ColorPalette(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "8540641a19e37a15edf2a03d4dd3ec953d263a6249257792e9b2872e31d5dcef") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8540641a19e37a15edf2a03d4dd3ec953d263a6249257792e9b2872e31d5dcef";
    }
    const { colors, selected, onSelect, label } = t0;
    let t1;
    if ($[1] !== label) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            gutterBottom: true,
            children: label
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 490,
            columnNumber: 10
        }, this);
        $[1] = label;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            mt: 0.5
        };
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] !== colors || $[5] !== onSelect || $[6] !== selected) {
        let t4;
        if ($[8] !== onSelect || $[9] !== selected) {
            t4 = ({
                "ColorPalette[colors.map()]": (color)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onClick: {
                            "ColorPalette[colors.map() > <Box>.onClick]": ()=>onSelect(color)
                        }["ColorPalette[colors.map() > <Box>.onClick]"],
                        sx: {
                            width: 28,
                            height: 28,
                            borderRadius: "50%",
                            bgcolor: `#${color}`,
                            cursor: "pointer",
                            border: selected === color ? "3px solid" : "2px solid transparent",
                            borderColor: selected === color ? "primary.main" : "transparent",
                            outline: "1px solid rgba(0,0,0,0.1)",
                            transition: "border-color 0.15s",
                            "&:hover": {
                                transform: "scale(1.15)"
                            }
                        }
                    }, color, false, {
                        fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                        lineNumber: 510,
                        columnNumber: 48
                    }, this)
            })["ColorPalette[colors.map()]"];
            $[8] = onSelect;
            $[9] = selected;
            $[10] = t4;
        } else {
            t4 = $[10];
        }
        t3 = colors.map(t4);
        $[4] = colors;
        $[5] = onSelect;
        $[6] = selected;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    let t4;
    if ($[11] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            flexWrap: "wrap",
            gap: 0.5,
            sx: t2,
            children: t3
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 543,
            columnNumber: 10
        }, this);
        $[11] = t3;
        $[12] = t4;
    } else {
        t4 = $[12];
    }
    let t5;
    if ($[13] !== t1 || $[14] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t1,
                t4
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 551,
            columnNumber: 10
        }, this);
        $[13] = t1;
        $[14] = t4;
        $[15] = t5;
    } else {
        t5 = $[15];
    }
    return t5;
}
_c = ColorPalette;
function OptionGrid(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23);
    if ($[0] !== "8540641a19e37a15edf2a03d4dd3ec953d263a6249257792e9b2872e31d5dcef") {
        for(let $i = 0; $i < 23; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8540641a19e37a15edf2a03d4dd3ec953d263a6249257792e9b2872e31d5dcef";
    }
    const { options, selected, onSelect, label } = t0;
    let t1;
    if ($[1] !== label) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            gutterBottom: true,
            children: label
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 576,
            columnNumber: 10
        }, this);
        $[1] = label;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            mt: 0.5
        };
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const t3 = !selected || selected.length === 0 ? "filled" : "outlined";
    const t4 = !selected || selected.length === 0 ? "primary" : "default";
    let t5;
    if ($[4] !== onSelect) {
        t5 = ({
            "OptionGrid[<Chip>.onClick]": ()=>onSelect("")
        })["OptionGrid[<Chip>.onClick]"];
        $[4] = onSelect;
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    let t6;
    if ($[6] !== t3 || $[7] !== t4 || $[8] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Random",
            size: "small",
            variant: t3,
            color: t4,
            onClick: t5
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 605,
            columnNumber: 10
        }, this);
        $[6] = t3;
        $[7] = t4;
        $[8] = t5;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] !== onSelect || $[11] !== options || $[12] !== selected) {
        let t8;
        if ($[14] !== onSelect || $[15] !== selected) {
            t8 = ({
                "OptionGrid[options.map()]": (opt)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        label: opt.label,
                        size: "small",
                        variant: selected?.includes(opt.id) ? "filled" : "outlined",
                        color: selected?.includes(opt.id) ? "primary" : "default",
                        onClick: {
                            "OptionGrid[options.map() > <Chip>.onClick]": ()=>onSelect(opt.id)
                        }["OptionGrid[options.map() > <Chip>.onClick]"]
                    }, opt.id, false, {
                        fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                        lineNumber: 618,
                        columnNumber: 45
                    }, this)
            })["OptionGrid[options.map()]"];
            $[14] = onSelect;
            $[15] = selected;
            $[16] = t8;
        } else {
            t8 = $[16];
        }
        t7 = options.map(t8);
        $[10] = onSelect;
        $[11] = options;
        $[12] = selected;
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[17] !== t6 || $[18] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            flexWrap: "wrap",
            gap: 0.5,
            sx: t2,
            children: [
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 638,
            columnNumber: 10
        }, this);
        $[17] = t6;
        $[18] = t7;
        $[19] = t8;
    } else {
        t8 = $[19];
    }
    let t9;
    if ($[20] !== t1 || $[21] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t1,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 647,
            columnNumber: 10
        }, this);
        $[20] = t1;
        $[21] = t8;
        $[22] = t9;
    } else {
        t9 = $[22];
    }
    return t9;
}
_c1 = OptionGrid;
function AvatarCustomizer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(89);
    if ($[0] !== "8540641a19e37a15edf2a03d4dd3ec953d263a6249257792e9b2872e31d5dcef") {
        for(let $i = 0; $i < 89; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8540641a19e37a15edf2a03d4dd3ec953d263a6249257792e9b2872e31d5dcef";
    }
    const { open, onClose, level, seed, selectedStyle, overrides: t1, onSave, avatarUnlockConfig, glowRing } = t0;
    let t2;
    if ($[1] !== t1) {
        t2 = t1 === undefined ? {} : t1;
        $[1] = t1;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const overrides = t2;
    let t3;
    if ($[3] !== avatarUnlockConfig || $[4] !== level) {
        t3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUnlockedStyleTier"])(level, avatarUnlockConfig);
        $[3] = avatarUnlockConfig;
        $[4] = level;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const highestTier = t3;
    let t4;
    if ($[6] !== avatarUnlockConfig || $[7] !== level) {
        t4 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUnlockedStyles"])(level, avatarUnlockConfig);
        $[6] = avatarUnlockConfig;
        $[7] = level;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const unlockedStyles = t4;
    const [style, setStyle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(selectedStyle || highestTier);
    const [draft, setDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(overrides);
    const [glowDraft, setGlowDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(glowRing ?? null);
    let t5;
    let t6;
    if ($[9] !== glowRing || $[10] !== highestTier || $[11] !== open || $[12] !== overrides || $[13] !== selectedStyle) {
        t5 = ({
            "AvatarCustomizer[useEffect()]": ()=>{
                if (open) {
                    setDraft(overrides);
                    setStyle(selectedStyle || highestTier);
                    setGlowDraft(glowRing ?? null);
                }
            }
        })["AvatarCustomizer[useEffect()]"];
        t6 = [
            open,
            overrides,
            selectedStyle,
            highestTier,
            glowRing
        ];
        $[9] = glowRing;
        $[10] = highestTier;
        $[11] = open;
        $[12] = overrides;
        $[13] = selectedStyle;
        $[14] = t5;
        $[15] = t6;
    } else {
        t5 = $[14];
        t6 = $[15];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t5, t6);
    let t7;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = ({
            "AvatarCustomizer[handleColorSelect]": (field, color)=>{
                setDraft({
                    "AvatarCustomizer[handleColorSelect > setDraft()]": (prev)=>({
                            ...prev,
                            [field]: [
                                color
                            ]
                        })
                }["AvatarCustomizer[handleColorSelect > setDraft()]"]);
            }
        })["AvatarCustomizer[handleColorSelect]"];
        $[16] = t7;
    } else {
        t7 = $[16];
    }
    const handleColorSelect = t7;
    let t8;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = ({
            "AvatarCustomizer[handleOptionSelect]": (field_0, id)=>{
                setDraft({
                    "AvatarCustomizer[handleOptionSelect > setDraft()]": (prev_0)=>{
                        if (!id) {
                            const next = {
                                ...prev_0
                            };
                            delete next[field_0];
                            if (field_0 === "facialHair") {
                                delete next.facialHairProbability;
                            }
                            if (field_0 === "beard") {
                                delete next.beardProbability;
                            }
                            if (field_0 === "rearHair") {
                                delete next.rearHairProbability;
                            }
                            if (field_0 === "accessories") {
                                delete next.accessoriesProbability;
                            }
                            return next;
                        }
                        return {
                            ...prev_0,
                            [field_0]: [
                                id
                            ],
                            ...field_0 === "facialHair" ? {
                                facialHairProbability: 100
                            } : {},
                            ...field_0 === "beard" ? {
                                beardProbability: 100
                            } : {},
                            ...field_0 === "rearHair" ? {
                                rearHairProbability: 100
                            } : {},
                            ...field_0 === "accessories" ? {
                                accessoriesProbability: 100
                            } : {}
                        };
                    }
                }["AvatarCustomizer[handleOptionSelect > setDraft()]"]);
            }
        })["AvatarCustomizer[handleOptionSelect]"];
        $[17] = t8;
    } else {
        t8 = $[17];
    }
    const handleOptionSelect = t8;
    let t9;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = ({
            "AvatarCustomizer[handleReset]": ()=>{
                setDraft({});
            }
        })["AvatarCustomizer[handleReset]"];
        $[18] = t9;
    } else {
        t9 = $[18];
    }
    const handleReset = t9;
    let t10;
    if ($[19] !== draft || $[20] !== glowDraft || $[21] !== onClose || $[22] !== onSave || $[23] !== style) {
        t10 = ({
            "AvatarCustomizer[handleSave]": ()=>{
                onSave(draft, style, glowDraft);
                onClose();
            }
        })["AvatarCustomizer[handleSave]"];
        $[19] = draft;
        $[20] = glowDraft;
        $[21] = onClose;
        $[22] = onSave;
        $[23] = style;
        $[24] = t10;
    } else {
        t10 = $[24];
    }
    const handleSave = t10;
    let t11;
    bb0: {
        const unlocks = avatarUnlockConfig?.unlocks;
        if (!unlocks?.length) {
            t11 = 1;
            break bb0;
        }
        let t12;
        if ($[25] !== style || $[26] !== unlocks) {
            let t13;
            if ($[28] !== style) {
                t13 = ({
                    "AvatarCustomizer[unlocks.find()]": (e)=>e.tier === style
                })["AvatarCustomizer[unlocks.find()]"];
                $[28] = style;
                $[29] = t13;
            } else {
                t13 = $[29];
            }
            t12 = unlocks.find(t13);
            $[25] = style;
            $[26] = unlocks;
            $[27] = t12;
        } else {
            t12 = $[27];
        }
        const entry = t12;
        t11 = entry?.minLevel ?? 1;
    }
    const styleMinLevel = t11;
    const hairClothesOffset = avatarUnlockConfig?.featureUnlockLevels?.hairAndClothing ?? 2;
    const accessoriesOffset = avatarUnlockConfig?.featureUnlockLevels?.accessories ?? 3;
    const hairClothesLevel = styleMinLevel + hairClothesOffset;
    const accessoriesLevel = styleMinLevel + accessoriesOffset;
    const canCustomizeHairClothes = level >= hairClothesLevel;
    const canCustomizeAccessories = level >= accessoriesLevel;
    let t12;
    if ($[30] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between"
        };
        $[30] = t12;
    } else {
        t12 = $[30];
    }
    let t13;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t12,
            children: [
                "Customize Avatar",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    title: "Reset to random",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onClick: handleReset,
                        size: "small",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RestartAlt$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 883,
                            columnNumber: 129
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                        lineNumber: 883,
                        columnNumber: 82
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 883,
                    columnNumber: 49
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 883,
            columnNumber: 11
        }, this);
        $[31] = t13;
    } else {
        t13 = $[31];
    }
    let t14;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = {
            mt: 1
        };
        $[32] = t14;
    } else {
        t14 = $[32];
    }
    let t15;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            display: "flex",
            justifyContent: "center"
        };
        $[33] = t15;
    } else {
        t15 = $[33];
    }
    let t16;
    if ($[34] !== draft || $[35] !== glowDraft || $[36] !== seed || $[37] !== style) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t15,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DiceBearAvatar"], {
                seed: seed,
                style: style,
                size: 96,
                overrides: draft,
                glowRing: glowDraft
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                lineNumber: 909,
                columnNumber: 25
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 909,
            columnNumber: 11
        }, this);
        $[34] = draft;
        $[35] = glowDraft;
        $[36] = seed;
        $[37] = style;
        $[38] = t16;
    } else {
        t16 = $[38];
    }
    let t17;
    if ($[39] !== style || $[40] !== unlockedStyles) {
        t17 = unlockedStyles.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    sx: {
                        mb: 1
                    },
                    children: "Avatar Style"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 920,
                    columnNumber: 45
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    direction: "row",
                    flexWrap: "wrap",
                    gap: 0.5,
                    children: [
                        "simple",
                        "detailed",
                        "toonhead"
                    ].map({
                        "AvatarCustomizer[(anonymous)()]": (tier)=>{
                            const isUnlocked = unlockedStyles.includes(tier);
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                label: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STYLE_CONFIG"][tier].displayName,
                                size: "small",
                                variant: style === tier ? "filled" : "outlined",
                                color: style === tier ? "primary" : "default",
                                disabled: !isUnlocked,
                                icon: !isUnlocked ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    sx: {
                                        fontSize: 14
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                                    lineNumber: 925,
                                    columnNumber: 228
                                }, this) : undefined,
                                onClick: {
                                    "AvatarCustomizer[(anonymous)() > <Chip>.onClick]": ()=>isUnlocked && setStyle(tier)
                                }["AvatarCustomizer[(anonymous)() > <Chip>.onClick]"]
                            }, tier, false, {
                                fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                                lineNumber: 925,
                                columnNumber: 20
                            }, this);
                        }
                    }["AvatarCustomizer[(anonymous)()]"])
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 922,
                    columnNumber: 35
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 920,
            columnNumber: 40
        }, this);
        $[39] = style;
        $[40] = unlockedStyles;
        $[41] = t17;
    } else {
        t17 = $[41];
    }
    let t18;
    if ($[42] !== canCustomizeHairClothes || $[43] !== draft || $[44] !== hairClothesLevel || $[45] !== style) {
        t18 = style === "simple" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            spacing: 1.5,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    children: "Colors"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 940,
                    columnNumber: 54
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorPalette, {
                    colors: BACKGROUND_COLORS,
                    selected: draft.backgroundColor?.[0],
                    onSelect: {
                        "AvatarCustomizer[<ColorPalette>.onSelect]": (c)=>handleColorSelect("backgroundColor", c)
                    }["AvatarCustomizer[<ColorPalette>.onSelect]"],
                    label: "Background"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 940,
                    columnNumber: 105
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorPalette, {
                    colors: DETAILED_SKIN_COLORS,
                    selected: draft.skinColor?.[0],
                    onSelect: {
                        "AvatarCustomizer[<ColorPalette>.onSelect]": (c_0)=>handleColorSelect("skinColor", c_0)
                    }["AvatarCustomizer[<ColorPalette>.onSelect]"],
                    label: "Skin Tone"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 942,
                    columnNumber: 76
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    sx: {
                        mt: 1
                    },
                    children: "Face"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 944,
                    columnNumber: 75
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: NEUTRAL_EYEBROWS,
                    selected: draft.eyebrows,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_0)=>handleOptionSelect("eyebrows", id_0)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Eyebrows"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 946,
                    columnNumber: 27
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: NEUTRAL_EYES,
                    selected: draft.eyes,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_1)=>handleOptionSelect("eyes", id_1)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Eyes"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 948,
                    columnNumber: 72
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: NEUTRAL_MOUTH,
                    selected: draft.mouth,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_2)=>handleOptionSelect("mouth", id_2)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Mouth"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 950,
                    columnNumber: 68
                }, this),
                !canCustomizeHairClothes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "body2",
                    color: "text.secondary",
                    sx: {
                        mt: 1
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                fontSize: 14,
                                verticalAlign: "middle",
                                mr: 0.5
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 954,
                            columnNumber: 10
                        }, this),
                        "Reach Level ",
                        hairClothesLevel,
                        " to unlock hair, clothing, and more color options"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 952,
                    columnNumber: 98
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 940,
            columnNumber: 33
        }, this);
        $[42] = canCustomizeHairClothes;
        $[43] = draft;
        $[44] = hairClothesLevel;
        $[45] = style;
        $[46] = t18;
    } else {
        t18 = $[46];
    }
    let t19;
    if ($[47] !== accessoriesLevel || $[48] !== canCustomizeAccessories || $[49] !== canCustomizeHairClothes || $[50] !== draft || $[51] !== hairClothesLevel || $[52] !== style) {
        t19 = style === "detailed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            spacing: 1.5,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    children: "Colors"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 969,
                    columnNumber: 56
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorPalette, {
                    colors: BACKGROUND_COLORS,
                    selected: draft.backgroundColor?.[0],
                    onSelect: {
                        "AvatarCustomizer[<ColorPalette>.onSelect]": (c_1)=>handleColorSelect("backgroundColor", c_1)
                    }["AvatarCustomizer[<ColorPalette>.onSelect]"],
                    label: "Background"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 969,
                    columnNumber: 107
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorPalette, {
                    colors: DETAILED_SKIN_COLORS,
                    selected: draft.skinColor?.[0],
                    onSelect: {
                        "AvatarCustomizer[<ColorPalette>.onSelect]": (c_2)=>handleColorSelect("skinColor", c_2)
                    }["AvatarCustomizer[<ColorPalette>.onSelect]"],
                    label: "Skin Tone"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 971,
                    columnNumber: 76
                }, this),
                canCustomizeHairClothes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorPalette, {
                            colors: DETAILED_HAIR_COLORS,
                            selected: draft.hairColor?.[0],
                            onSelect: {
                                "AvatarCustomizer[<ColorPalette>.onSelect]": (c_3)=>handleColorSelect("hairColor", c_3)
                            }["AvatarCustomizer[<ColorPalette>.onSelect]"],
                            label: "Hair Color"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 973,
                            columnNumber: 105
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorPalette, {
                            colors: DETAILED_CLOTHES_COLORS,
                            selected: draft.clothesColor?.[0],
                            onSelect: {
                                "AvatarCustomizer[<ColorPalette>.onSelect]": (c_4)=>handleColorSelect("clothesColor", c_4)
                            }["AvatarCustomizer[<ColorPalette>.onSelect]"],
                            label: "Clothes Color"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 975,
                            columnNumber: 78
                        }, this)
                    ]
                }, void 0, true),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    sx: {
                        mt: 1
                    },
                    children: "Face"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 977,
                    columnNumber: 85
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: NEUTRAL_EYEBROWS,
                    selected: draft.eyebrows,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_3)=>handleOptionSelect("eyebrows", id_3)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Eyebrows"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 979,
                    columnNumber: 27
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: NEUTRAL_EYES,
                    selected: draft.eyes,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_4)=>handleOptionSelect("eyes", id_4)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Eyes"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 981,
                    columnNumber: 72
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: NEUTRAL_MOUTH,
                    selected: draft.mouth,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_5)=>handleOptionSelect("mouth", id_5)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Mouth"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 983,
                    columnNumber: 68
                }, this),
                canCustomizeHairClothes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "subtitle2",
                            sx: {
                                mt: 1
                            },
                            children: "Hair & Clothing"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 985,
                            columnNumber: 99
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                            options: DETAILED_TOP,
                            selected: draft.top,
                            onSelect: {
                                "AvatarCustomizer[<OptionGrid>.onSelect]": (id_6)=>handleOptionSelect("top", id_6)
                            }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                            label: "Hair / Top"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 987,
                            columnNumber: 44
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                            options: DETAILED_CLOTHING,
                            selected: draft.clothing,
                            onSelect: {
                                "AvatarCustomizer[<OptionGrid>.onSelect]": (id_7)=>handleOptionSelect("clothing", id_7)
                            }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                            label: "Clothing"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 989,
                            columnNumber: 76
                        }, this)
                    ]
                }, void 0, true),
                canCustomizeAccessories && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "subtitle2",
                            sx: {
                                mt: 1
                            },
                            children: "Accessories & Extras"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 991,
                            columnNumber: 108
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                            options: DETAILED_FACIAL_HAIR,
                            selected: draft.facialHair,
                            onSelect: {
                                "AvatarCustomizer[<OptionGrid>.onSelect]": (id_8)=>handleOptionSelect("facialHair", id_8)
                            }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                            label: "Facial Hair"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 993,
                            columnNumber: 49
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                            options: DETAILED_ACCESSORIES,
                            selected: draft.accessories,
                            onSelect: {
                                "AvatarCustomizer[<OptionGrid>.onSelect]": (id_9)=>handleOptionSelect("accessories", id_9)
                            }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                            label: "Accessories"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 995,
                            columnNumber: 77
                        }, this)
                    ]
                }, void 0, true),
                !canCustomizeHairClothes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "body2",
                    color: "text.secondary",
                    sx: {
                        mt: 1
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                fontSize: 14,
                                verticalAlign: "middle",
                                mr: 0.5
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 999,
                            columnNumber: 10
                        }, this),
                        "Reach Level ",
                        hairClothesLevel,
                        " to unlock hair, clothing, and more colors"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 997,
                    columnNumber: 110
                }, this),
                canCustomizeHairClothes && !canCustomizeAccessories && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "body2",
                    color: "text.secondary",
                    sx: {
                        mt: 1
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                fontSize: 14,
                                verticalAlign: "middle",
                                mr: 0.5
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 1005,
                            columnNumber: 10
                        }, this),
                        "Reach Level ",
                        accessoriesLevel,
                        " to unlock facial hair and accessories"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1003,
                    columnNumber: 156
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 969,
            columnNumber: 35
        }, this);
        $[47] = accessoriesLevel;
        $[48] = canCustomizeAccessories;
        $[49] = canCustomizeHairClothes;
        $[50] = draft;
        $[51] = hairClothesLevel;
        $[52] = style;
        $[53] = t19;
    } else {
        t19 = $[53];
    }
    let t20;
    if ($[54] !== draft || $[55] !== style) {
        t20 = style === "toonhead" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            spacing: 1.5,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    children: "Colors"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1022,
                    columnNumber: 56
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorPalette, {
                    colors: BACKGROUND_COLORS,
                    selected: draft.backgroundColor?.[0],
                    onSelect: {
                        "AvatarCustomizer[<ColorPalette>.onSelect]": (c_5)=>handleColorSelect("backgroundColor", c_5)
                    }["AvatarCustomizer[<ColorPalette>.onSelect]"],
                    label: "Background"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1022,
                    columnNumber: 107
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorPalette, {
                    colors: TOONHEAD_SKIN_COLORS,
                    selected: draft.skinColor?.[0],
                    onSelect: {
                        "AvatarCustomizer[<ColorPalette>.onSelect]": (c_6)=>handleColorSelect("skinColor", c_6)
                    }["AvatarCustomizer[<ColorPalette>.onSelect]"],
                    label: "Skin Tone"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1024,
                    columnNumber: 76
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorPalette, {
                    colors: TOONHEAD_HAIR_COLORS,
                    selected: draft.hairColor?.[0],
                    onSelect: {
                        "AvatarCustomizer[<ColorPalette>.onSelect]": (c_7)=>handleColorSelect("hairColor", c_7)
                    }["AvatarCustomizer[<ColorPalette>.onSelect]"],
                    label: "Hair Color"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1026,
                    columnNumber: 75
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorPalette, {
                    colors: TOONHEAD_CLOTHES_COLORS,
                    selected: draft.clothesColor?.[0],
                    onSelect: {
                        "AvatarCustomizer[<ColorPalette>.onSelect]": (c_8)=>handleColorSelect("clothesColor", c_8)
                    }["AvatarCustomizer[<ColorPalette>.onSelect]"],
                    label: "Clothes Color"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1028,
                    columnNumber: 76
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    sx: {
                        mt: 1
                    },
                    children: "Face"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1030,
                    columnNumber: 79
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: TOONHEAD_EYES,
                    selected: draft.eyes,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_10)=>handleOptionSelect("eyes", id_10)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Eyes"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1032,
                    columnNumber: 27
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: TOONHEAD_EYEBROWS,
                    selected: draft.eyebrows,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_11)=>handleOptionSelect("eyebrows", id_11)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Eyebrows"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1034,
                    columnNumber: 68
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: TOONHEAD_MOUTH,
                    selected: draft.mouth,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_12)=>handleOptionSelect("mouth", id_12)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Mouth"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1036,
                    columnNumber: 72
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    sx: {
                        mt: 1
                    },
                    children: "Hair & Clothing"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1038,
                    columnNumber: 69
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: TOONHEAD_HAIR,
                    selected: draft.hair,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_13)=>handleOptionSelect("hair", id_13)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Hair"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1040,
                    columnNumber: 42
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: TOONHEAD_REAR_HAIR,
                    selected: draft.rearHair,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_14)=>handleOptionSelect("rearHair", id_14)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Rear Hair"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1042,
                    columnNumber: 68
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: TOONHEAD_CLOTHES,
                    selected: draft.clothes,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_15)=>handleOptionSelect("clothes", id_15)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Clothes"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1044,
                    columnNumber: 73
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    sx: {
                        mt: 1
                    },
                    children: "Extras"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1046,
                    columnNumber: 71
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionGrid, {
                    options: TOONHEAD_BEARD,
                    selected: draft.beard,
                    onSelect: {
                        "AvatarCustomizer[<OptionGrid>.onSelect]": (id_16)=>handleOptionSelect("beard", id_16)
                    }["AvatarCustomizer[<OptionGrid>.onSelect]"],
                    label: "Beard"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1048,
                    columnNumber: 29
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 1022,
            columnNumber: 35
        }, this);
        $[54] = draft;
        $[55] = style;
        $[56] = t20;
    } else {
        t20 = $[56];
    }
    const t21 = glowDraft?.active ?? false;
    let t22;
    if ($[57] !== glowDraft) {
        t22 = ({
            "AvatarCustomizer[<Switch>.onChange]": (_, checked)=>{
                if (checked) {
                    setGlowDraft({
                        colors: glowDraft?.colors ?? [
                            ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$AvatarGlowRing$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_GLOW_COLORS"]
                        ],
                        speed: glowDraft?.speed ?? 4,
                        thickness: glowDraft?.thickness ?? 3,
                        active: true,
                        expiresAt: null
                    });
                } else {
                    setGlowDraft(glowDraft ? {
                        ...glowDraft,
                        active: false
                    } : null);
                }
            }
        })["AvatarCustomizer[<Switch>.onChange]"];
        $[57] = glowDraft;
        $[58] = t22;
    } else {
        t22 = $[58];
    }
    let t23;
    if ($[59] !== t21 || $[60] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            checked: t21,
            onChange: t22
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 1085,
            columnNumber: 11
        }, this);
        $[59] = t21;
        $[60] = t22;
        $[61] = t23;
    } else {
        t23 = $[61];
    }
    let t24;
    if ($[62] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle2",
            children: "Gradient Ring"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 1094,
            columnNumber: 11
        }, this);
        $[62] = t24;
    } else {
        t24 = $[62];
    }
    let t25;
    if ($[63] !== t23) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            control: t23,
            label: t24
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 1101,
            columnNumber: 11
        }, this);
        $[63] = t23;
        $[64] = t25;
    } else {
        t25 = $[64];
    }
    let t26;
    if ($[65] !== glowDraft) {
        t26 = glowDraft?.active && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            spacing: 1.5,
            sx: {
                mt: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "caption",
                    color: "text.secondary",
                    children: "Choose a preset or pick custom colors"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1111,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    direction: "row",
                    flexWrap: "wrap",
                    gap: 0.5,
                    children: Object.entries(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$AvatarGlowRing$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GLOW_COLOR_PRESETS"]).map({
                        "AvatarCustomizer[(anonymous)()]": (t27)=>{
                            const [name, colors] = t27;
                            const isSelected = glowDraft.colors.join(",") === colors.join(",");
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                label: name.charAt(0).toUpperCase() + name.slice(1),
                                size: "small",
                                variant: isSelected ? "filled" : "outlined",
                                color: isSelected ? "primary" : "default",
                                onClick: {
                                    "AvatarCustomizer[(anonymous)() > <Chip>.onClick]": ()=>setGlowDraft({
                                            ...glowDraft,
                                            colors: [
                                                ...colors
                                            ]
                                        })
                                }["AvatarCustomizer[(anonymous)() > <Chip>.onClick]"],
                                avatar: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    sx: {
                                        width: 16,
                                        height: 16,
                                        borderRadius: "50%",
                                        background: `conic-gradient(${colors.slice(0, 4).join(", ")})`
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                                    lineNumber: 1120,
                                    columnNumber: 76
                                }, this)
                            }, name, false, {
                                fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                                lineNumber: 1115,
                                columnNumber: 20
                            }, this);
                        }
                    }["AvatarCustomizer[(anonymous)()]"])
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1111,
                    columnNumber: 111
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "caption",
                            color: "text.secondary",
                            children: "Custom color stops"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 1127,
                            columnNumber: 60
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            direction: "row",
                            gap: 0.5,
                            sx: {
                                mt: 0.5,
                                flexWrap: "wrap"
                            },
                            children: [
                                glowDraft.colors.map({
                                    "AvatarCustomizer[glowDraft.colors.map()]": (color_0, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            sx: {
                                                position: "relative",
                                                width: 32,
                                                height: 32
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                component: "input",
                                                type: "color",
                                                value: color_0,
                                                onChange: {
                                                    "AvatarCustomizer[glowDraft.colors.map() > <Box>.onChange]": (e_0)=>{
                                                        const newColors = [
                                                            ...glowDraft.colors
                                                        ];
                                                        newColors[i] = e_0.target.value;
                                                        setGlowDraft({
                                                            ...glowDraft,
                                                            colors: newColors
                                                        });
                                                    }
                                                }["AvatarCustomizer[glowDraft.colors.map() > <Box>.onChange]"],
                                                sx: {
                                                    width: 32,
                                                    height: 32,
                                                    border: "2px solid",
                                                    borderColor: "divider",
                                                    borderRadius: "50%",
                                                    cursor: "pointer",
                                                    padding: 0,
                                                    appearance: "none",
                                                    "&::-webkit-color-swatch-wrapper": {
                                                        padding: 0
                                                    },
                                                    "&::-webkit-color-swatch": {
                                                        borderRadius: "50%",
                                                        border: "none"
                                                    }
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                                                lineNumber: 1135,
                                                columnNumber: 16
                                            }, this)
                                        }, i, false, {
                                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                                            lineNumber: 1131,
                                            columnNumber: 73
                                        }, this)
                                }["AvatarCustomizer[glowDraft.colors.map()]"]),
                                glowDraft.colors.length < 8 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    size: "small",
                                    onClick: {
                                        "AvatarCustomizer[<IconButton>.onClick]": ()=>setGlowDraft({
                                                ...glowDraft,
                                                colors: [
                                                    ...glowDraft.colors,
                                                    "#ffffff"
                                                ]
                                            })
                                    }["AvatarCustomizer[<IconButton>.onClick]"],
                                    sx: {
                                        width: 32,
                                        height: 32
                                    },
                                    children: "+"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                                    lineNumber: 1161,
                                    columnNumber: 90
                                }, this),
                                glowDraft.colors.length > 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    size: "small",
                                    onClick: {
                                        "AvatarCustomizer[<IconButton>.onClick]": ()=>setGlowDraft({
                                                ...glowDraft,
                                                colors: glowDraft.colors.slice(0, -1)
                                            })
                                    }["AvatarCustomizer[<IconButton>.onClick]"],
                                    sx: {
                                        width: 32,
                                        height: 32
                                    },
                                    children: "−"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                                    lineNumber: 1169,
                                    columnNumber: 61
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                            lineNumber: 1127,
                            columnNumber: 144
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                    lineNumber: 1127,
                    columnNumber: 55
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 1109,
            columnNumber: 32
        }, this);
        $[65] = glowDraft;
        $[66] = t26;
    } else {
        t26 = $[66];
    }
    let t27;
    if ($[67] !== t25 || $[68] !== t26) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t25,
                t26
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 1185,
            columnNumber: 11
        }, this);
        $[67] = t25;
        $[68] = t26;
        $[69] = t27;
    } else {
        t27 = $[69];
    }
    let t28;
    if ($[70] !== t16 || $[71] !== t17 || $[72] !== t18 || $[73] !== t19 || $[74] !== t20 || $[75] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                spacing: 3,
                sx: t14,
                children: [
                    t16,
                    t17,
                    t18,
                    t19,
                    t20,
                    t27
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
                lineNumber: 1194,
                columnNumber: 26
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 1194,
            columnNumber: 11
        }, this);
        $[70] = t16;
        $[71] = t17;
        $[72] = t18;
        $[73] = t19;
        $[74] = t20;
        $[75] = t27;
        $[76] = t28;
    } else {
        t28 = $[76];
    }
    let t29;
    if ($[77] !== onClose) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: onClose,
            children: "Cancel"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 1207,
            columnNumber: 11
        }, this);
        $[77] = onClose;
        $[78] = t29;
    } else {
        t29 = $[78];
    }
    let t30;
    if ($[79] !== handleSave) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: handleSave,
            variant: "contained",
            children: "Save"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 1215,
            columnNumber: 11
        }, this);
        $[79] = handleSave;
        $[80] = t30;
    } else {
        t30 = $[80];
    }
    let t31;
    if ($[81] !== t29 || $[82] !== t30) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t29,
                t30
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 1223,
            columnNumber: 11
        }, this);
        $[81] = t29;
        $[82] = t30;
        $[83] = t31;
    } else {
        t31 = $[83];
    }
    let t32;
    if ($[84] !== onClose || $[85] !== open || $[86] !== t28 || $[87] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            onClose: onClose,
            maxWidth: "sm",
            fullWidth: true,
            children: [
                t13,
                t28,
                t31
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarCustomizer.tsx",
            lineNumber: 1232,
            columnNumber: 11
        }, this);
        $[84] = onClose;
        $[85] = open;
        $[86] = t28;
        $[87] = t31;
        $[88] = t32;
    } else {
        t32 = $[88];
    }
    return t32;
}
_s(AvatarCustomizer, "+wG3+1G44vJd17EarkgEuMi5kNE=");
_c2 = AvatarCustomizer;
const __TURBOPACK__default__export__ = AvatarCustomizer;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ColorPalette");
__turbopack_context__.k.register(_c1, "OptionGrid");
__turbopack_context__.k.register(_c2, "AvatarCustomizer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/CosmeticSelector.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CosmeticSelector",
    ()=>CosmeticSelector,
    "DEFAULT_EDITOR_THEMES",
    ()=>DEFAULT_EDITOR_THEMES,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * CosmeticSelector — Picker for choosing avatar style and editor themes.
 *
 * @module CosmeticSelector
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Check.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Palette$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Palette.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Face$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Face.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/DiceBearAvatar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$AvatarCustomizer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/AvatarCustomizer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ThemeMixer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/ThemeMixer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const DEFAULT_EDITOR_THEMES = [
    {
        id: 'default',
        name: 'Default',
        minLevel: 1,
        preview: {
            bg: '#ffffff',
            text: '#333333',
            accent: '#1976d2'
        }
    },
    {
        id: 'midnight',
        name: 'Midnight',
        minLevel: 2,
        preview: {
            bg: '#1a1a2e',
            text: '#e0e0e0',
            accent: '#00bcd4'
        }
    },
    {
        id: 'forest',
        name: 'Forest',
        minLevel: 3,
        preview: {
            bg: '#1b2d1b',
            text: '#c8e6c9',
            accent: '#66bb6a'
        }
    },
    {
        id: 'sunset',
        name: 'Sunset',
        minLevel: 4,
        preview: {
            bg: '#2d1b1b',
            text: '#ffccbc',
            accent: '#ff7043'
        }
    },
    {
        id: 'aurora',
        name: 'Aurora',
        minLevel: 5,
        preview: {
            bg: '#0d1b2a',
            text: '#e0f7fa',
            accent: '#ab47bc'
        }
    },
    {
        id: 'custom',
        name: 'Custom',
        minLevel: 2,
        preview: {
            bg: '#f5f5f5',
            text: '#333333',
            accent: '#ff4081'
        }
    }
];
function CosmeticSelector(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(72);
    if ($[0] !== "030a80a90df35a33587fccacb48a152ec2ef914f6e3787d41f0bea0c2c559006") {
        for(let $i = 0; $i < 72; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "030a80a90df35a33587fccacb48a152ec2ef914f6e3787d41f0bea0c2c559006";
    }
    const { level, selectedThemeId, editorThemes: t1, onThemeSelect, customThemePalette, onCustomPaletteSave, avatarSeed: t2, selectedAvatarTier, onAvatarTierSelect, avatarOverrides, onAvatarOverridesSave, avatarUnlockConfig } = t0;
    const editorThemes = t1 === undefined ? DEFAULT_EDITOR_THEMES : t1;
    const avatarSeed = t2 === undefined ? "student" : t2;
    const [customizerOpen, setCustmizerOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let T0;
    let T1;
    let T2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[1] !== avatarSeed || $[2] !== avatarUnlockConfig || $[3] !== level || $[4] !== onAvatarTierSelect || $[5] !== selectedAvatarTier) {
        const tierStatuses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStyleTierStatus"])(level, avatarUnlockConfig);
        T2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        t9 = 3;
        T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        let t10;
        if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = {
                display: "flex",
                alignItems: "center",
                gap: 0.5
            };
            $[16] = t10;
        } else {
            t10 = $[16];
        }
        if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "subtitle2",
                gutterBottom: true,
                sx: t10,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Face$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 18
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                        lineNumber: 177,
                        columnNumber: 73
                    }, this),
                    " Avatar Style"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                lineNumber: 177,
                columnNumber: 12
            }, this);
            $[17] = t8;
        } else {
            t8 = $[17];
        }
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        t3 = "row";
        t4 = "wrap";
        t5 = 1.5;
        if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = {
                mb: 2
            };
            $[18] = t6;
        } else {
            t6 = $[18];
        }
        let t11;
        if ($[19] !== avatarSeed || $[20] !== onAvatarTierSelect || $[21] !== selectedAvatarTier) {
            t11 = ({
                "CosmeticSelector[tierStatuses.map()]": (t12)=>{
                    const { tier, unlocked, displayName } = t12;
                    const selected = selectedAvatarTier === tier;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "outlined",
                        sx: {
                            width: 90,
                            cursor: unlocked ? "pointer" : "not-allowed",
                            opacity: unlocked ? 1 : 0.4,
                            border: selected ? "2px solid" : "1px solid",
                            borderColor: selected ? "primary.main" : "divider",
                            transition: "border-color 0.2s",
                            textAlign: "center",
                            py: 1
                        },
                        onClick: unlocked ? ()=>onAvatarTierSelect?.(tier) : undefined,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                sx: {
                                    display: "flex",
                                    justifyContent: "center",
                                    mb: 0.5
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DiceBearAvatar"], {
                                    seed: avatarSeed,
                                    style: tier,
                                    size: 40,
                                    locked: !unlocked
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                                    lineNumber: 219,
                                    columnNumber: 16
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                                lineNumber: 215,
                                columnNumber: 80
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "caption",
                                noWrap: true,
                                children: [
                                    !unlocked && "\uD83D\uDD12 ",
                                    displayName
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                                lineNumber: 219,
                                columnNumber: 100
                            }, this),
                            selected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                sx: {
                                    fontSize: 12,
                                    color: "primary.main"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                                lineNumber: 219,
                                columnNumber: 213
                            }, this)
                        ]
                    }, tier, true, {
                        fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                        lineNumber: 206,
                        columnNumber: 18
                    }, this);
                }
            })["CosmeticSelector[tierStatuses.map()]"];
            $[19] = avatarSeed;
            $[20] = onAvatarTierSelect;
            $[21] = selectedAvatarTier;
            $[22] = t11;
        } else {
            t11 = $[22];
        }
        t7 = tierStatuses.map(t11);
        $[1] = avatarSeed;
        $[2] = avatarUnlockConfig;
        $[3] = level;
        $[4] = onAvatarTierSelect;
        $[5] = selectedAvatarTier;
        $[6] = T0;
        $[7] = T1;
        $[8] = T2;
        $[9] = t3;
        $[10] = t4;
        $[11] = t5;
        $[12] = t6;
        $[13] = t7;
        $[14] = t8;
        $[15] = t9;
    } else {
        T0 = $[6];
        T1 = $[7];
        T2 = $[8];
        t3 = $[9];
        t4 = $[10];
        t5 = $[11];
        t6 = $[12];
        t7 = $[13];
        t8 = $[14];
        t9 = $[15];
    }
    let t10;
    if ($[23] !== T0 || $[24] !== t3 || $[25] !== t4 || $[26] !== t5 || $[27] !== t6 || $[28] !== t7) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            direction: t3,
            flexWrap: t4,
            gap: t5,
            sx: t6,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
            lineNumber: 262,
            columnNumber: 11
        }, this);
        $[23] = T0;
        $[24] = t3;
        $[25] = t4;
        $[26] = t5;
        $[27] = t6;
        $[28] = t7;
        $[29] = t10;
    } else {
        t10 = $[29];
    }
    let t11;
    if ($[30] !== level) {
        t11 = level >= 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            variant: "outlined",
            onClick: {
                "CosmeticSelector[<Button>.onClick]": ()=>setCustmizerOpen(true)
            }["CosmeticSelector[<Button>.onClick]"],
            children: "Customize Avatar"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
            lineNumber: 275,
            columnNumber: 25
        }, this);
        $[30] = level;
        $[31] = t11;
    } else {
        t11 = $[31];
    }
    let t12;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = ({
            "CosmeticSelector[<AvatarCustomizer>.onClose]": ()=>setCustmizerOpen(false)
        })["CosmeticSelector[<AvatarCustomizer>.onClose]"];
        $[32] = t12;
    } else {
        t12 = $[32];
    }
    let t13;
    if ($[33] !== onAvatarOverridesSave) {
        t13 = ({
            "CosmeticSelector[<AvatarCustomizer>.onSave]": (overrides, style)=>onAvatarOverridesSave?.(overrides, style)
        })["CosmeticSelector[<AvatarCustomizer>.onSave]"];
        $[33] = onAvatarOverridesSave;
        $[34] = t13;
    } else {
        t13 = $[34];
    }
    let t14;
    if ($[35] !== avatarOverrides || $[36] !== avatarSeed || $[37] !== avatarUnlockConfig || $[38] !== customizerOpen || $[39] !== level || $[40] !== selectedAvatarTier || $[41] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$AvatarCustomizer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AvatarCustomizer"], {
            open: customizerOpen,
            onClose: t12,
            level: level,
            seed: avatarSeed,
            selectedStyle: selectedAvatarTier,
            overrides: avatarOverrides,
            onSave: t13,
            avatarUnlockConfig: avatarUnlockConfig
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
            lineNumber: 304,
            columnNumber: 11
        }, this);
        $[35] = avatarOverrides;
        $[36] = avatarSeed;
        $[37] = avatarUnlockConfig;
        $[38] = customizerOpen;
        $[39] = level;
        $[40] = selectedAvatarTier;
        $[41] = t13;
        $[42] = t14;
    } else {
        t14 = $[42];
    }
    let t15;
    if ($[43] !== T1 || $[44] !== t10 || $[45] !== t11 || $[46] !== t14 || $[47] !== t8) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
            children: [
                t8,
                t10,
                t11,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
            lineNumber: 318,
            columnNumber: 11
        }, this);
        $[43] = T1;
        $[44] = t10;
        $[45] = t11;
        $[46] = t14;
        $[47] = t8;
        $[48] = t15;
    } else {
        t15 = $[48];
    }
    let t16;
    if ($[49] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            display: "flex",
            alignItems: "center",
            gap: 0.5
        };
        $[49] = t16;
    } else {
        t16 = $[49];
    }
    let t17;
    if ($[50] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle2",
            gutterBottom: true,
            sx: t16,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Palette$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        fontSize: 18
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                    lineNumber: 341,
                    columnNumber: 72
                }, this),
                " Editor Theme"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
            lineNumber: 341,
            columnNumber: 11
        }, this);
        $[50] = t17;
    } else {
        t17 = $[50];
    }
    let t18;
    if ($[51] !== editorThemes || $[52] !== level || $[53] !== onThemeSelect || $[54] !== selectedThemeId) {
        let t19;
        if ($[56] !== level || $[57] !== onThemeSelect || $[58] !== selectedThemeId) {
            t19 = ({
                "CosmeticSelector[editorThemes.map()]": (theme)=>{
                    const unlocked_0 = level >= theme.minLevel;
                    const selected_0 = selectedThemeId === theme.id;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "outlined",
                        sx: {
                            width: 100,
                            cursor: unlocked_0 ? "pointer" : "not-allowed",
                            opacity: unlocked_0 ? 1 : 0.4,
                            border: selected_0 ? "2px solid" : "1px solid",
                            borderColor: selected_0 ? "primary.main" : "divider",
                            transition: "border-color 0.2s"
                        },
                        onClick: unlocked_0 ? ()=>onThemeSelect?.(theme.id) : undefined,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                sx: {
                                    height: 36,
                                    bgcolor: theme.preview.bg,
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    gap: 0.5,
                                    px: 1
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        sx: {
                                            width: 8,
                                            height: 8,
                                            borderRadius: "50%",
                                            bgcolor: theme.preview.accent
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                                        lineNumber: 371,
                                        columnNumber: 16
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        sx: {
                                            flex: 1,
                                            height: 3,
                                            bgcolor: theme.preview.text,
                                            borderRadius: 1,
                                            opacity: 0.5
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                                        lineNumber: 376,
                                        columnNumber: 20
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                                lineNumber: 363,
                                columnNumber: 81
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                sx: {
                                    py: "4px !important",
                                    px: 1,
                                    textAlign: "center"
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    variant: "caption",
                                    noWrap: true,
                                    children: [
                                        !unlocked_0 && "\uD83D\uDD12 ",
                                        theme.name
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                                    lineNumber: 386,
                                    columnNumber: 16
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                                lineNumber: 382,
                                columnNumber: 26
                            }, this)
                        ]
                    }, theme.id, true, {
                        fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                        lineNumber: 356,
                        columnNumber: 18
                    }, this);
                }
            })["CosmeticSelector[editorThemes.map()]"];
            $[56] = level;
            $[57] = onThemeSelect;
            $[58] = selectedThemeId;
            $[59] = t19;
        } else {
            t19 = $[59];
        }
        t18 = editorThemes.map(t19);
        $[51] = editorThemes;
        $[52] = level;
        $[53] = onThemeSelect;
        $[54] = selectedThemeId;
        $[55] = t18;
    } else {
        t18 = $[55];
    }
    let t19;
    if ($[60] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t17,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    direction: "row",
                    flexWrap: "wrap",
                    gap: 1,
                    children: t18
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                    lineNumber: 407,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
            lineNumber: 407,
            columnNumber: 11
        }, this);
        $[60] = t18;
        $[61] = t19;
    } else {
        t19 = $[61];
    }
    let t20;
    if ($[62] !== customThemePalette || $[63] !== onCustomPaletteSave || $[64] !== selectedThemeId) {
        t20 = selectedThemeId === "custom" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                mt: 1
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ThemeMixer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeMixer"], {
                value: customThemePalette,
                onSave: {
                    "CosmeticSelector[<ThemeMixer>.onSave]": (palette)=>onCustomPaletteSave?.(palette)
                }["CosmeticSelector[<ThemeMixer>.onSave]"]
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
                lineNumber: 417,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
            lineNumber: 415,
            columnNumber: 43
        }, this);
        $[62] = customThemePalette;
        $[63] = onCustomPaletteSave;
        $[64] = selectedThemeId;
        $[65] = t20;
    } else {
        t20 = $[65];
    }
    let t21;
    if ($[66] !== T2 || $[67] !== t15 || $[68] !== t19 || $[69] !== t20 || $[70] !== t9) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T2, {
            spacing: t9,
            children: [
                t15,
                t19,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/CosmeticSelector.tsx",
            lineNumber: 429,
            columnNumber: 11
        }, this);
        $[66] = T2;
        $[67] = t15;
        $[68] = t19;
        $[69] = t20;
        $[70] = t9;
        $[71] = t21;
    } else {
        t21 = $[71];
    }
    return t21;
}
_s(CosmeticSelector, "FXqxUplk9qKgIsW6VYLv6bo77Z4=");
_c = CosmeticSelector;
const __TURBOPACK__default__export__ = CosmeticSelector;
var _c;
__turbopack_context__.k.register(_c, "CosmeticSelector");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/BotCustomizer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BotCustomizer",
    ()=>BotCustomizer,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * BotCustomizer — Allows students to customize the AI assistant's avatar appearance.
 * Unlocked progressively via "Bot Whisperer" achievement badges.
 *
 * - Bot Whisperer I: Unlock background color
 * - Bot Whisperer II: Unlock style tier (detailed)
 * - Bot Whisperer III: Unlock eyes & mouth options
 * - Bot Whisperer IV: Full customization (toonhead style + all options)
 *
 * @module BotCustomizer
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ToggleButton/ToggleButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButtonGroup$2f$ToggleButtonGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ToggleButtonGroup/ToggleButtonGroup.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Lock.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BotAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/BotAvatar.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
// ============================================================================
// Constants
// ============================================================================
const BG_COLORS = [
    {
        label: 'Sky',
        value: 'b6e3f4'
    },
    {
        label: 'Mint',
        value: 'c0ffd4'
    },
    {
        label: 'Lavender',
        value: 'd1c4e9'
    },
    {
        label: 'Peach',
        value: 'ffd8b1'
    },
    {
        label: 'Rose',
        value: 'ffcdd2'
    },
    {
        label: 'Gold',
        value: 'fff9c4'
    }
];
const STYLE_OPTIONS = [
    {
        value: 'simple',
        label: 'Simple',
        minTier: 0
    },
    {
        value: 'detailed',
        label: 'Detailed',
        minTier: 2
    },
    {
        value: 'toonhead',
        label: 'Toon',
        minTier: 4
    }
];
function BotCustomizer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(41);
    if ($[0] !== "6828b94c352c93e1ca0a7dfdd18722f8dddeb3089e7d4ae0e2b6a82dde856509") {
        for(let $i = 0; $i < 41; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6828b94c352c93e1ca0a7dfdd18722f8dddeb3089e7d4ae0e2b6a82dde856509";
    }
    const { botWhispererTier, onChange, initialConfig } = t0;
    const [style, setStyle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialConfig?.style || "simple");
    const [bgColor, setBgColor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialConfig?.backgroundColor || "b6e3f4");
    let t1;
    if ($[1] !== bgColor) {
        t1 = {
            backgroundColor: [
                bgColor
            ]
        };
        $[1] = bgColor;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const overrides = t1;
    let t2;
    if ($[3] !== bgColor || $[4] !== onChange) {
        t2 = ({
            "BotCustomizer[handleStyleChange]": (_, newStyle)=>{
                if (!newStyle) {
                    return;
                }
                setStyle(newStyle);
                onChange?.({
                    style: newStyle,
                    backgroundColor: bgColor
                });
            }
        })["BotCustomizer[handleStyleChange]"];
        $[3] = bgColor;
        $[4] = onChange;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    const handleStyleChange = t2;
    let t3;
    if ($[6] !== onChange || $[7] !== style) {
        t3 = ({
            "BotCustomizer[handleBgChange]": (color)=>{
                setBgColor(color);
                onChange?.({
                    style,
                    backgroundColor: color
                });
            }
        })["BotCustomizer[handleBgChange]"];
        $[6] = onChange;
        $[7] = style;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    const handleBgChange = t3;
    let t4;
    let t5;
    if ($[9] !== initialConfig) {
        t4 = ({
            "BotCustomizer[useEffect()]": ()=>{
                if (initialConfig) {
                    setStyle(initialConfig.style || "simple");
                    setBgColor(initialConfig.backgroundColor || "b6e3f4");
                }
            }
        })["BotCustomizer[useEffect()]"];
        t5 = [
            initialConfig
        ];
        $[9] = initialConfig;
        $[10] = t4;
        $[11] = t5;
    } else {
        t4 = $[10];
        t5 = $[11];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t4, t5);
    if (botWhispererTier < 1) {
        let t6;
        if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = {
                textAlign: "center",
                py: 2,
                opacity: 0.6
            };
            $[12] = t6;
        } else {
            t6 = $[12];
        }
        let t7;
        if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t6,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 32,
                            mb: 1,
                            color: "text.disabled"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/BotCustomizer.tsx",
                        lineNumber: 185,
                        columnNumber: 25
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "body2",
                        color: "text.secondary",
                        children: "Earn the Bot Whisperer I badge to customize your AI assistant."
                    }, void 0, false, {
                        fileName: "[project]/src/components/BotCustomizer.tsx",
                        lineNumber: 189,
                        columnNumber: 14
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/BotCustomizer.tsx",
                lineNumber: 185,
                columnNumber: 12
            }, this);
            $[13] = t7;
        } else {
            t7 = $[13];
        }
        return t7;
    }
    let t6;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            display: "flex",
            alignItems: "center",
            gap: 2,
            mb: 3
        };
        $[14] = t6;
    } else {
        t6 = $[14];
    }
    let t7;
    if ($[15] !== overrides || $[16] !== style) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BotAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BotAvatar"], {
            size: 64,
            style: style,
            overrides: overrides
        }, void 0, false, {
            fileName: "[project]/src/components/BotCustomizer.tsx",
            lineNumber: 210,
            columnNumber: 10
        }, this);
        $[15] = overrides;
        $[16] = style;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    let t8;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle1",
            fontWeight: 600,
            children: "Your AI Assistant"
        }, void 0, false, {
            fileName: "[project]/src/components/BotCustomizer.tsx",
            lineNumber: 219,
            columnNumber: 10
        }, this);
        $[18] = t8;
    } else {
        t8 = $[18];
    }
    let t9;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = [
            "I",
            "II",
            "III",
            "IV"
        ];
        $[19] = t9;
    } else {
        t9 = $[19];
    }
    const t10 = `Bot Whisperer ${t9[botWhispererTier - 1]}`;
    let t11;
    if ($[20] !== t10) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t8,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    label: t10,
                    size: "small",
                    color: "primary",
                    variant: "outlined"
                }, void 0, false, {
                    fileName: "[project]/src/components/BotCustomizer.tsx",
                    lineNumber: 234,
                    columnNumber: 20
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/BotCustomizer.tsx",
            lineNumber: 234,
            columnNumber: 11
        }, this);
        $[20] = t10;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    let t12;
    if ($[22] !== t11 || $[23] !== t7) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t6,
            children: [
                t7,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/BotCustomizer.tsx",
            lineNumber: 242,
            columnNumber: 11
        }, this);
        $[22] = t11;
        $[23] = t7;
        $[24] = t12;
    } else {
        t12 = $[24];
    }
    let t13;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            fontWeight: 600,
            sx: {
                mb: 1
            },
            children: "Style"
        }, void 0, false, {
            fileName: "[project]/src/components/BotCustomizer.tsx",
            lineNumber: 251,
            columnNumber: 11
        }, this);
        $[25] = t13;
    } else {
        t13 = $[25];
    }
    let t14;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = {
            mb: 2
        };
        $[26] = t14;
    } else {
        t14 = $[26];
    }
    let t15;
    if ($[27] !== botWhispererTier) {
        t15 = STYLE_OPTIONS.map({
            "BotCustomizer[STYLE_OPTIONS.map()]": (opt)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    value: opt.value,
                    disabled: botWhispererTier < opt.minTier,
                    children: [
                        botWhispererTier < opt.minTier && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                fontSize: 14,
                                mr: 0.5
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/BotCustomizer.tsx",
                            lineNumber: 270,
                            columnNumber: 177
                        }, this),
                        opt.label
                    ]
                }, opt.value, true, {
                    fileName: "[project]/src/components/BotCustomizer.tsx",
                    lineNumber: 270,
                    columnNumber: 52
                }, this)
        }["BotCustomizer[STYLE_OPTIONS.map()]"]);
        $[27] = botWhispererTier;
        $[28] = t15;
    } else {
        t15 = $[28];
    }
    let t16;
    if ($[29] !== handleStyleChange || $[30] !== style || $[31] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButtonGroup$2f$ToggleButtonGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            value: style,
            exclusive: true,
            onChange: handleStyleChange,
            size: "small",
            sx: t14,
            children: t15
        }, void 0, false, {
            fileName: "[project]/src/components/BotCustomizer.tsx",
            lineNumber: 282,
            columnNumber: 11
        }, this);
        $[29] = handleStyleChange;
        $[30] = style;
        $[31] = t15;
        $[32] = t16;
    } else {
        t16 = $[32];
    }
    let t17;
    if ($[33] !== bgColor || $[34] !== botWhispererTier || $[35] !== handleBgChange) {
        t17 = botWhispererTier >= 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "body2",
                    fontWeight: 600,
                    sx: {
                        mb: 1
                    },
                    children: "Background Color"
                }, void 0, false, {
                    fileName: "[project]/src/components/BotCustomizer.tsx",
                    lineNumber: 292,
                    columnNumber: 38
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        display: "flex",
                        gap: 1,
                        flexWrap: "wrap"
                    },
                    children: BG_COLORS.map({
                        "BotCustomizer[BG_COLORS.map()]": (c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                onClick: {
                                    "BotCustomizer[BG_COLORS.map() > <Box>.onClick]": ()=>handleBgChange(c.value)
                                }["BotCustomizer[BG_COLORS.map() > <Box>.onClick]"],
                                sx: {
                                    width: 32,
                                    height: 32,
                                    borderRadius: "50%",
                                    backgroundColor: `#${c.value}`,
                                    cursor: "pointer",
                                    border: bgColor === c.value ? "3px solid" : "2px solid transparent",
                                    borderColor: bgColor === c.value ? "primary.main" : "transparent",
                                    transition: "border-color 0.2s",
                                    "&:hover": {
                                        transform: "scale(1.1)"
                                    }
                                },
                                title: c.label
                            }, c.value, false, {
                                fileName: "[project]/src/components/BotCustomizer.tsx",
                                lineNumber: 299,
                                columnNumber: 50
                            }, this)
                    }["BotCustomizer[BG_COLORS.map()]"])
                }, void 0, false, {
                    fileName: "[project]/src/components/BotCustomizer.tsx",
                    lineNumber: 294,
                    columnNumber: 39
                }, this)
            ]
        }, void 0, true);
        $[33] = bgColor;
        $[34] = botWhispererTier;
        $[35] = handleBgChange;
        $[36] = t17;
    } else {
        t17 = $[36];
    }
    let t18;
    if ($[37] !== t12 || $[38] !== t16 || $[39] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t12,
                t13,
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/BotCustomizer.tsx",
            lineNumber: 324,
            columnNumber: 11
        }, this);
        $[37] = t12;
        $[38] = t16;
        $[39] = t17;
        $[40] = t18;
    } else {
        t18 = $[40];
    }
    return t18;
}
_s(BotCustomizer, "3ebVgHVYSR//p4dmRwx+9p2tfsc=");
_c = BotCustomizer;
const __TURBOPACK__default__export__ = BotCustomizer;
var _c;
__turbopack_context__.k.register(_c, "BotCustomizer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/RankChangeToast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RankChangeToast",
    ()=>RankChangeToast,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TrendingUp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TrendingDown.js [app-client] (ecmascript)");
;
;
;
;
;
;
function RankChangeToast(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18);
    if ($[0] !== "f54591abbf7d01b3eed979d94218737398e7dbf9ec637eac6519b29230b6c0f2") {
        for(let $i = 0; $i < 18; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f54591abbf7d01b3eed979d94218737398e7dbf9ec637eac6519b29230b6c0f2";
    }
    const { open, positionsChanged, newRank, onClose, autoHideDuration: t1 } = t0;
    const autoHideDuration = t1 === undefined ? 3000 : t1;
    const movedUp = positionsChanged > 0;
    let t2;
    if ($[1] !== movedUp) {
        t2 = movedUp ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 40,
            columnNumber: 20
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 40,
            columnNumber: 41
        }, this);
        $[1] = movedUp;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const icon = t2;
    const severity = movedUp ? "success" : "info";
    let t3;
    if ($[3] !== movedUp || $[4] !== newRank || $[5] !== positionsChanged) {
        t3 = movedUp ? `+${positionsChanged} positions on leaderboard! Now #${newRank} 🚀` : `Dropped ${Math.abs(positionsChanged)} position${Math.abs(positionsChanged) > 1 ? "s" : ""} — now #${newRank}`;
        $[3] = movedUp;
        $[4] = newRank;
        $[5] = positionsChanged;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const message = t3;
    let t4;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            vertical: "bottom",
            horizontal: "left"
        };
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            fontWeight: 600
        };
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] !== icon || $[10] !== message || $[11] !== severity) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            severity: severity,
            icon: icon,
            sx: t5,
            children: message
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        $[9] = icon;
        $[10] = message;
        $[11] = severity;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    let t7;
    if ($[13] !== autoHideDuration || $[14] !== onClose || $[15] !== open || $[16] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            autoHideDuration: autoHideDuration,
            anchorOrigin: t4,
            onClose: onClose,
            children: t6
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/RankChangeToast.tsx",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[13] = autoHideDuration;
        $[14] = onClose;
        $[15] = open;
        $[16] = t6;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    return t7;
}
_c = RankChangeToast;
const __TURBOPACK__default__export__ = RankChangeToast;
var _c;
__turbopack_context__.k.register(_c, "RankChangeToast");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/BadgeCoinFlip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BadgeCoinFlip",
    ()=>BadgeCoinFlip,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * BadgeCoinFlip — CSS 3D coin-flip animation for badge awards.
 *
 * Shows a spinning coin that resolves to the badge emoji.
 *
 * @module BadgeCoinFlip
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BadgeIcon.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function BadgeCoinFlip(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(36);
    if ($[0] !== "0133f0923054bcc9dfb946f1a5dc16979320d1316602d61f9b2d5e504857e7f7") {
        for(let $i = 0; $i < 36; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0133f0923054bcc9dfb946f1a5dc16979320d1316602d61f9b2d5e504857e7f7";
    }
    const { open, badgeEmoji, badgeType, badgeName, badgeDescription, onClose } = t0;
    const [flipped, setFlipped] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    let t2;
    if ($[1] !== open) {
        t1 = ({
            "BadgeCoinFlip[useEffect()]": ()=>{
                if (open) {
                    setFlipped(false);
                    const timer = setTimeout({
                        "BadgeCoinFlip[useEffect() > setTimeout()]": ()=>setFlipped(true)
                    }["BadgeCoinFlip[useEffect() > setTimeout()]"], 100);
                    return ()=>clearTimeout(timer);
                }
            }
        })["BadgeCoinFlip[useEffect()]"];
        t2 = [
            open
        ];
        $[1] = open;
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            textAlign: "center",
            p: 4
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            perspective: "600px",
            mb: 2
        };
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const t5 = flipped ? "rotateY(720deg)" : "rotateY(0deg)";
    let t6;
    if ($[6] !== t5) {
        t6 = {
            width: 80,
            height: 80,
            mx: "auto",
            position: "relative",
            transformStyle: "preserve-3d",
            transition: "transform 0.8s ease-out",
            transform: t5
        };
        $[6] = t5;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            position: "absolute",
            width: "100%",
            height: "100%",
            borderRadius: "50%",
            bgcolor: "warning.light",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backfaceVisibility: "hidden",
            fontSize: "2.5rem"
        };
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] !== badgeEmoji || $[10] !== badgeType || $[11] !== flipped) {
        t8 = badgeType ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeIcon"], {
            badgeType: badgeType,
            size: 64,
            earned: true,
            animate: flipped,
            drawIcon: flipped
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 124,
            columnNumber: 22
        }, this) : badgeEmoji;
        $[9] = badgeEmoji;
        $[10] = badgeType;
        $[11] = flipped;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t7,
            children: t8
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 134,
            columnNumber: 10
        }, this);
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== t6 || $[16] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t4,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t6,
                children: t9
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
                lineNumber: 142,
                columnNumber: 24
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 142,
            columnNumber: 11
        }, this);
        $[15] = t6;
        $[16] = t9;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h6",
            fontWeight: 700,
            sx: {
                mt: 2
            },
            children: "Badge Earned!"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 151,
            columnNumber: 11
        }, this);
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] !== badgeName) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle1",
            fontWeight: 600,
            color: "primary.main",
            children: badgeName
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 160,
            columnNumber: 11
        }, this);
        $[19] = badgeName;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            mt: 1
        };
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    let t14;
    if ($[22] !== badgeDescription) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: t13,
            children: badgeDescription
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 177,
            columnNumber: 11
        }, this);
        $[22] = badgeDescription;
        $[23] = t14;
    } else {
        t14 = $[23];
    }
    let t15;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            mt: 3
        };
        $[24] = t15;
    } else {
        t15 = $[24];
    }
    let t16;
    if ($[25] !== onClose) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "contained",
            onClick: onClose,
            sx: t15,
            children: "Awesome!"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 194,
            columnNumber: 11
        }, this);
        $[25] = onClose;
        $[26] = t16;
    } else {
        t16 = $[26];
    }
    let t17;
    if ($[27] !== t10 || $[28] !== t12 || $[29] !== t14 || $[30] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t10,
                t11,
                t12,
                t14,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 202,
            columnNumber: 11
        }, this);
        $[27] = t10;
        $[28] = t12;
        $[29] = t14;
        $[30] = t16;
        $[31] = t17;
    } else {
        t17 = $[31];
    }
    let t18;
    if ($[32] !== onClose || $[33] !== open || $[34] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            maxWidth: "xs",
            fullWidth: true,
            onClose: onClose,
            children: t17
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeCoinFlip.tsx",
            lineNumber: 213,
            columnNumber: 11
        }, this);
        $[32] = onClose;
        $[33] = open;
        $[34] = t17;
        $[35] = t18;
    } else {
        t18 = $[35];
    }
    return t18;
}
_s(BadgeCoinFlip, "AET8kBs2SyxC4Y+I5l5KZF+HKtk=");
_c = BadgeCoinFlip;
const __TURBOPACK__default__export__ = BadgeCoinFlip;
var _c;
__turbopack_context__.k.register(_c, "BadgeCoinFlip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/ContentUnlockAnimation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContentUnlockAnimation",
    ()=>ContentUnlockAnimation,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * ContentUnlockAnimation — Shows a padlock-open + shimmer animation
 * when content transitions from locked to unlocked.
 *
 * @module ContentUnlockAnimation
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LockOpen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/LockOpen.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ContentUnlockAnimation(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "879883009fc7268f972d4a73bc498985b943f8397e3421ec723284abb5cfa2c6") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "879883009fc7268f972d4a73bc498985b943f8397e3421ec723284abb5cfa2c6";
    }
    const { show, title, onComplete } = t0;
    const [phase, setPhase] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    let t1;
    let t2;
    if ($[1] !== onComplete || $[2] !== show) {
        t1 = ({
            "ContentUnlockAnimation[useEffect()]": ()=>{
                if (!show) {
                    setPhase("idle");
                    return;
                }
                setPhase("shake");
                const t1$0 = setTimeout({
                    "ContentUnlockAnimation[useEffect() > setTimeout()]": ()=>setPhase("open")
                }["ContentUnlockAnimation[useEffect() > setTimeout()]"], 600);
                const t2$0 = setTimeout({
                    "ContentUnlockAnimation[useEffect() > setTimeout()]": ()=>setPhase("shimmer")
                }["ContentUnlockAnimation[useEffect() > setTimeout()]"], 1200);
                const t3 = setTimeout({
                    "ContentUnlockAnimation[useEffect() > setTimeout()]": ()=>{
                        setPhase("done");
                        onComplete?.();
                    }
                }["ContentUnlockAnimation[useEffect() > setTimeout()]"], 2400);
                return ()=>{
                    clearTimeout(t1$0);
                    clearTimeout(t2$0);
                    clearTimeout(t3);
                };
            }
        })["ContentUnlockAnimation[useEffect()]"];
        t2 = [
            show,
            onComplete
        ];
        $[1] = onComplete;
        $[2] = show;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    if (phase === "idle" || phase === "done") {
        return null;
    }
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 2000,
            bgcolor: "rgba(0,0,0,0.5)",
            backdropFilter: "blur(4px)",
            pointerEvents: "none"
        };
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const t4 = phase === "shake" ? "unlockShake 0.5s ease-in-out" : phase === "open" ? "unlockOpen 0.5s ease-out forwards" : phase === "shimmer" ? "unlockShimmer 1s ease-out forwards" : "none";
    let t5;
    let t6;
    let t7;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            "0%, 100%": {
                transform: "rotate(0deg)"
            },
            "20%": {
                transform: "rotate(-10deg)"
            },
            "40%": {
                transform: "rotate(10deg)"
            },
            "60%": {
                transform: "rotate(-10deg)"
            },
            "80%": {
                transform: "rotate(10deg)"
            }
        };
        t6 = {
            "0%": {
                transform: "scale(1)",
                opacity: 1
            },
            "50%": {
                transform: "scale(1.3)",
                opacity: 1
            },
            "100%": {
                transform: "scale(1.5)",
                opacity: 0.8
            }
        };
        t7 = {
            "0%": {
                transform: "scale(1.5)",
                opacity: 0.8,
                filter: "brightness(1)"
            },
            "50%": {
                transform: "scale(2)",
                opacity: 1,
                filter: "brightness(2)"
            },
            "100%": {
                transform: "scale(1)",
                opacity: 0,
                filter: "brightness(1)"
            }
        };
        $[6] = t5;
        $[7] = t6;
        $[8] = t7;
    } else {
        t5 = $[6];
        t6 = $[7];
        t7 = $[8];
    }
    let t8;
    if ($[9] !== t4) {
        t8 = {
            fontSize: "4rem",
            animation: t4,
            "@keyframes unlockShake": t5,
            "@keyframes unlockOpen": t6,
            "@keyframes unlockShimmer": t7
        };
        $[9] = t4;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LockOpen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: "inherit",
                color: "warning.main"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 176,
            columnNumber: 10
        }, this);
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    let t10;
    if ($[12] !== t8) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t8,
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        $[12] = t8;
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] !== phase || $[15] !== title) {
        t11 = (phase === "open" || phase === "shimmer") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h4",
            sx: {
                color: "white",
                fontWeight: 700,
                mt: 2,
                textAlign: "center",
                animation: "fadeInUp 0.6s ease-out",
                "@keyframes fadeInUp": {
                    "0%": {
                        opacity: 0,
                        transform: "translateY(20px)"
                    },
                    "100%": {
                        opacity: 1,
                        transform: "translateY(0)"
                    }
                }
            },
            children: [
                "🔓 ",
                title,
                " Unlocked!"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 194,
            columnNumber: 56
        }, this);
        $[14] = phase;
        $[15] = title;
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    let t12;
    if ($[17] !== t10 || $[18] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t10,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ContentUnlockAnimation.tsx",
            lineNumber: 219,
            columnNumber: 11
        }, this);
        $[17] = t10;
        $[18] = t11;
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    return t12;
}
_s(ContentUnlockAnimation, "K+JLQG7QosnBzljigzAIGs/3QEU=");
_c = ContentUnlockAnimation;
const __TURBOPACK__default__export__ = ContentUnlockAnimation;
var _c;
__turbopack_context__.k.register(_c, "ContentUnlockAnimation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/GamificationToastLayer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GamificationToastLayer",
    ()=>GamificationToastLayer,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * GamificationToastLayer — Global overlay that renders event-driven
 * micro-interaction toasts: RankChangeToast, BadgeCoinFlip, EasterEggToast,
 * ContentUnlockAnimation, and AnimatedXPCounter.
 *
 * Mount once inside GamificationProviderWrapper in _app.jsx.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$RankChangeToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/RankChangeToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeCoinFlip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BadgeCoinFlip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/EasterEggToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ContentUnlockAnimation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/ContentUnlockAnimation.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
// Badge metadata (mirrors BadgeShelf definitions)
const BADGE_META = {
    FIRST_SUBMISSION: {
        emoji: '📝',
        name: 'First Steps',
        description: 'Submitted your first assignment'
    },
    GOOD_EYE: {
        emoji: '👁️',
        name: 'Good Eye',
        description: 'Found an error others missed'
    },
    QUICK_DRAW: {
        emoji: '⚡',
        name: 'Quick Draw',
        description: 'First to submit in your section'
    },
    SHARPSHOOTER: {
        emoji: '🎯',
        name: 'Sharpshooter',
        description: '3 perfect scores in a row'
    },
    CONSISTENT: {
        emoji: '🔥',
        name: 'Consistent',
        description: '14-day streak'
    },
    TEAM_PLAYER: {
        emoji: '🤝',
        name: 'Team Player',
        description: 'Completed 5 peer reviews'
    },
    DEEP_THINKER: {
        emoji: '🧠',
        name: 'Deep Thinker',
        description: 'Revised after AI feedback 3 times'
    },
    TOP_OF_CLASS: {
        emoji: '🏆',
        name: 'Top of Class',
        description: 'Reached #1 on leaderboard'
    },
    PERFECTIONIST: {
        emoji: '💎',
        name: 'Perfectionist',
        description: '100% on every workbook in a module'
    }
};
function GamificationToastLayer() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(37);
    if ($[0] !== "c2497af0e7c2f3b9613b747180c741686dc88d221a4b5885da94290ad264a18f") {
        for(let $i = 0; $i < 37; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c2497af0e7c2f3b9613b747180c741686dc88d221a4b5885da94290ad264a18f";
    }
    const { xpLogs } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"])();
    const { locks } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContentLock"])();
    const prevXpLogsCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(xpLogs.length);
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const prevLocksRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            open: false,
            positionsChanged: 0,
            newRank: 0
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [rankToast, setRankToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            open: false,
            emoji: "",
            name: "",
            description: ""
        };
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const [badgeFlip, setBadgeFlip] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            open: false,
            message: "",
            xpReward: 0
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const [easterEgg, setEasterEgg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3);
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            show: false,
            title: ""
        };
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const [unlock, setUnlock] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t4);
    let t5;
    let t6;
    if ($[6] !== xpLogs) {
        t5 = ({
            "GamificationToastLayer[useEffect()]": ()=>{
                const prevCount = prevXpLogsCountRef.current;
                if (xpLogs.length <= prevCount) {
                    prevXpLogsCountRef.current = xpLogs.length;
                    return;
                }
                const newEntries = xpLogs.slice(0, xpLogs.length - prevCount);
                prevXpLogsCountRef.current = xpLogs.length;
                for (const entry of newEntries){
                    const reason = entry.xpReason || "";
                    if (reason === "EASTER_EGG") {
                        setEasterEgg({
                            open: true,
                            message: entry.description || "You found a secret!",
                            xpReward: entry.xpAmount || 0
                        });
                    }
                    if (reason === "BADGE_AWARDED") {
                        const badgeType = entry.metadata?.badgeType || "";
                        const meta = BADGE_META[badgeType] || {
                            emoji: "\uD83C\uDFC5",
                            name: "Badge",
                            description: "Achievement unlocked!"
                        };
                        setBadgeFlip({
                            open: true,
                            ...meta
                        });
                    }
                    if (reason === "RANK_CHANGE" || entry.metadata?.rankChange) {
                        const meta_0 = entry.metadata || {};
                        if (meta_0.positionsChanged && meta_0.newRank) {
                            setRankToast({
                                open: true,
                                positionsChanged: meta_0.positionsChanged,
                                newRank: meta_0.newRank
                            });
                        }
                    }
                }
            }
        })["GamificationToastLayer[useEffect()]"];
        t6 = [
            xpLogs
        ];
        $[6] = xpLogs;
        $[7] = t5;
        $[8] = t6;
    } else {
        t5 = $[7];
        t6 = $[8];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7;
    let t8;
    if ($[9] !== locks) {
        t7 = ({
            "GamificationToastLayer[useEffect()]": ()=>{
                const currentLockedIds = locks.filter(_GamificationToastLayerUseEffectLocksFilter).map(_GamificationToastLayerUseEffectAnonymous);
                const prevLockedIds = prevLocksRef.current;
                if (prevLockedIds.length > 0) {
                    const newlyUnlocked = prevLockedIds.filter({
                        "GamificationToastLayer[useEffect() > prevLockedIds.filter()]": (id)=>!currentLockedIds.includes(id)
                    }["GamificationToastLayer[useEffect() > prevLockedIds.filter()]"]);
                    if (newlyUnlocked.length > 0) {
                        const unlockedLock = locks.find({
                            "GamificationToastLayer[useEffect() > locks.find()]": (l_1)=>l_1.contentId === newlyUnlocked[0]
                        }["GamificationToastLayer[useEffect() > locks.find()]"]);
                        setUnlock({
                            show: true,
                            title: unlockedLock?.title || "Content Unlocked!"
                        });
                    }
                }
                prevLocksRef.current = currentLockedIds;
            }
        })["GamificationToastLayer[useEffect()]"];
        t8 = [
            locks
        ];
        $[9] = locks;
        $[10] = t7;
        $[11] = t8;
    } else {
        t7 = $[10];
        t8 = $[11];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t7, t8);
    let t9;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = ({
            "GamificationToastLayer[closeRank]": ()=>setRankToast(_GamificationToastLayerCloseRankSetRankToast)
        })["GamificationToastLayer[closeRank]"];
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    const closeRank = t9;
    let t10;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = ({
            "GamificationToastLayer[closeBadge]": ()=>setBadgeFlip(_GamificationToastLayerCloseBadgeSetBadgeFlip)
        })["GamificationToastLayer[closeBadge]"];
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    const closeBadge = t10;
    let t11;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = ({
            "GamificationToastLayer[closeEgg]": ()=>setEasterEgg(_GamificationToastLayerCloseEggSetEasterEgg)
        })["GamificationToastLayer[closeEgg]"];
        $[14] = t11;
    } else {
        t11 = $[14];
    }
    const closeEgg = t11;
    let t12;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = ({
            "GamificationToastLayer[closeUnlock]": ()=>setUnlock({
                    show: false,
                    title: ""
                })
        })["GamificationToastLayer[closeUnlock]"];
        $[15] = t12;
    } else {
        t12 = $[15];
    }
    const closeUnlock = t12;
    let t13;
    if ($[16] !== rankToast.newRank || $[17] !== rankToast.open || $[18] !== rankToast.positionsChanged) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$RankChangeToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RankChangeToast"], {
            open: rankToast.open,
            positionsChanged: rankToast.positionsChanged,
            newRank: rankToast.newRank,
            onClose: closeRank
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 294,
            columnNumber: 11
        }, this);
        $[16] = rankToast.newRank;
        $[17] = rankToast.open;
        $[18] = rankToast.positionsChanged;
        $[19] = t13;
    } else {
        t13 = $[19];
    }
    let t14;
    if ($[20] !== badgeFlip.description || $[21] !== badgeFlip.emoji || $[22] !== badgeFlip.name || $[23] !== badgeFlip.open) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeCoinFlip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeCoinFlip"], {
            open: badgeFlip.open,
            badgeEmoji: badgeFlip.emoji,
            badgeName: badgeFlip.name,
            badgeDescription: badgeFlip.description,
            onClose: closeBadge
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 304,
            columnNumber: 11
        }, this);
        $[20] = badgeFlip.description;
        $[21] = badgeFlip.emoji;
        $[22] = badgeFlip.name;
        $[23] = badgeFlip.open;
        $[24] = t14;
    } else {
        t14 = $[24];
    }
    let t15;
    if ($[25] !== easterEgg.message || $[26] !== easterEgg.open || $[27] !== easterEgg.xpReward) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EasterEggToast"], {
            open: easterEgg.open,
            message: easterEgg.message,
            xpReward: easterEgg.xpReward,
            onClose: closeEgg
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 315,
            columnNumber: 11
        }, this);
        $[25] = easterEgg.message;
        $[26] = easterEgg.open;
        $[27] = easterEgg.xpReward;
        $[28] = t15;
    } else {
        t15 = $[28];
    }
    let t16;
    if ($[29] !== unlock.show || $[30] !== unlock.title) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ContentUnlockAnimation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentUnlockAnimation"], {
            show: unlock.show,
            title: unlock.title,
            onComplete: closeUnlock
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/GamificationToastLayer.tsx",
            lineNumber: 325,
            columnNumber: 11
        }, this);
        $[29] = unlock.show;
        $[30] = unlock.title;
        $[31] = t16;
    } else {
        t16 = $[31];
    }
    let t17;
    if ($[32] !== t13 || $[33] !== t14 || $[34] !== t15 || $[35] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t13,
                t14,
                t15,
                t16
            ]
        }, void 0, true);
        $[32] = t13;
        $[33] = t14;
        $[34] = t15;
        $[35] = t16;
        $[36] = t17;
    } else {
        t17 = $[36];
    }
    return t17;
}
_s(GamificationToastLayer, "GUyfkCLISoaMzEQ9fdGupt+uzWo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContentLock"]
    ];
});
_c = GamificationToastLayer;
function _GamificationToastLayerCloseEggSetEasterEgg(s_1) {
    return {
        ...s_1,
        open: false
    };
}
function _GamificationToastLayerCloseBadgeSetBadgeFlip(s_0) {
    return {
        ...s_0,
        open: false
    };
}
function _GamificationToastLayerCloseRankSetRankToast(s) {
    return {
        ...s,
        open: false
    };
}
function _GamificationToastLayerUseEffectAnonymous(l_0) {
    return l_0.contentId;
}
function _GamificationToastLayerUseEffectLocksFilter(l) {
    return l.isLocked;
}
const __TURBOPACK__default__export__ = GamificationToastLayer;
var _c;
__turbopack_context__.k.register(_c, "GamificationToastLayer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/gamificationProviderWrapper.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GamificationProviderWrapper",
    ()=>GamificationProviderWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$GamificationToastLayer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/GamificationToastLayer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function GamificationProviderWrapper(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "7151689139be499929ce124491916299acef4963acc9fed72473e0c8f3c8605b") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7151689139be499929ce124491916299acef4963acc9fed72473e0c8f3c8605b";
    }
    const { children, cohortId: cohortIdProp } = t0;
    const { user, session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const client = t1;
    const isInstructor = session?.groups?.includes("Instructors") || session?.groups?.includes("Admins");
    const studentId = isInstructor ? "" : user?.username || user?.attributes?.sub || "";
    const { sections, assignments } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {};
    session?.groups;
    let t2;
    if ($[2] !== cohortIdProp || $[3] !== session?.groups) {
        bb0: {
            if (cohortIdProp) {
                t2 = cohortIdProp;
                break bb0;
            }
            const groups = session?.groups || [];
            for (const group of groups){
                const match = group.match(/^section-(.+?)-(learners|instructors)$/);
                if (match) {
                    t2 = match[1];
                    break bb0;
                }
            }
            t2 = undefined;
        }
        $[2] = cohortIdProp;
        $[3] = session?.groups;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const cohortId = t2;
    let t3;
    if ($[5] !== studentId) {
        t3 = studentId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$GamificationToastLayer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationToastLayer"], {}, void 0, false, {
            fileName: "[project]/src/context/gamificationProviderWrapper.jsx",
            lineNumber: 76,
            columnNumber: 23
        }, this);
        $[5] = studentId;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== assignments || $[8] !== children || $[9] !== cohortId || $[10] !== sections || $[11] !== studentId || $[12] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationProvider"], {
            client: client,
            studentId: studentId,
            cohortId: cohortId,
            sections: sections,
            assignments: assignments,
            children: [
                children,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/src/context/gamificationProviderWrapper.jsx",
            lineNumber: 84,
            columnNumber: 10
        }, this);
        $[7] = assignments;
        $[8] = children;
        $[9] = cohortId;
        $[10] = sections;
        $[11] = studentId;
        $[12] = t3;
        $[13] = t4;
    } else {
        t4 = $[13];
    }
    return t4;
}
_s(GamificationProviderWrapper, "KAg+X7S5wlQvcXKzXEV+lune0l8=");
_c = GamificationProviderWrapper;
var _c;
__turbopack_context__.k.register(_c, "GamificationProviderWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useChatPageContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useChatPageContext",
    ()=>useChatPageContext
]);
/**
 * useChatPageContext - Register page-specific context with ChatContext
 * 
 * This hook allows pages to register their available context (unit, files, sections, etc.)
 * with the global ChatContext, making that context available to the chat sidebar.
 * 
 * @example
 * // In Unit Editor page
 * function UnitEditorPage() {
 *   const { unit, files, dictionary, questions } = useContext(UnitContext);
 *   const { sections } = useContext(SectionContext);
 *   const { vectorStoreSearch } = useContext(VectorStoreContext);
 *   const editorRef = useRef(null);
 *   
 *   useChatPageContext({
 *     unit,
 *     files,
 *     dictionary,
 *     questions,
 *     sections,
 *     editorRef,
 *     vectorStoreSearch,
 *   });
 *   
 *   return <...>
 * }
 * 
 * @see docs/GLOBAL_CHAT_INTEGRATION_PLAN.md
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/chatContext.jsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useChatPageContext(context = {}) {
    _s();
    const { setPageContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { unit = null, files = [], dictionary = [], questions = [], sections = [], editorRef = null, vectorStoreSearch = null } = context;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChatPageContext.useEffect": ()=>{
            console.log('[useChatPageContext] Registering page context:', {
                hasUnit: !!unit,
                filesCount: files?.length || 0,
                dictionaryCount: dictionary?.length || 0,
                questionsCount: questions?.length || 0,
                sectionsCount: sections?.length || 0,
                hasEditorRef: !!editorRef,
                hasVectorStoreSearch: !!vectorStoreSearch
            });
            setPageContext({
                unit,
                files,
                dictionary,
                questions,
                sections,
                editorRef,
                vectorStoreSearch
            });
            // Cleanup: reset to empty context when component unmounts
            return ({
                "useChatPageContext.useEffect": ()=>{
                    console.log('[useChatPageContext] Cleaning up page context');
                    setPageContext({
                        unit: null,
                        files: [],
                        dictionary: [],
                        questions: [],
                        sections: [],
                        editorRef: null,
                        vectorStoreSearch: null
                    });
                }
            })["useChatPageContext.useEffect"];
        }
    }["useChatPageContext.useEffect"], [
        // Dependencies - update when any context changes
        unit?.id,
        files?.length,
        dictionary?.length,
        questions?.length,
        sections?.length,
        editorRef?.current,
        vectorStoreSearch,
        setPageContext
    ]);
}
_s(useChatPageContext, "0aGcDEhsgvDsw4KhinDnLq0Ig9M=");
const __TURBOPACK__default__export__ = useChatPageContext;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[locale]/settings/page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WrappedPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$aws$2d$amplify$2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$fetchUserAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/aws-amplify/node_modules/@aws-amplify/auth/dist/esm/providers/cognito/apis/fetchUserAttributes.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$aws$2d$amplify$2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$updateUserAttribute$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/aws-amplify/node_modules/@aws-amplify/auth/dist/esm/providers/cognito/apis/updateUserAttribute.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$aws$2d$amplify$2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$updatePassword$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/aws-amplify/node_modules/@aws-amplify/auth/dist/esm/providers/cognito/apis/updatePassword.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/apis/fetchAuthSession.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControl/FormControl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$StorageManagement$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/StorageManagement.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$CosmeticSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/CosmeticSelector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BotCustomizer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/BotCustomizer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationProviderWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/gamificationProviderWrapper.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useChatPageContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Modal/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContentText$2f$DialogContentText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContentText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContentText/DialogContentText.js [app-client] (ecmascript) <export default as DialogContentText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Select/Select.js [app-client] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputLabel/InputLabel.js [app-client] (ecmascript) <export default as InputLabel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/settingsContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Switch/Switch.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/use-intl/dist/esm/development/react.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function Settings() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(351);
    if ($[0] !== "f8134736c5d44f27a6b6f1952f9e931e568da0c6ca6c53208d4e55e8e45cf98c") {
        for(let $i = 0; $i < 351; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f8134736c5d44f27a6b6f1952f9e931e568da0c6ca6c53208d4e55e8e45cf98c";
    }
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("pages");
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const locale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLocale"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {};
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [user, setUser] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](t0);
    const [oldPassword, setOldPassword] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const [newPassword, setNewPassword] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const [confirmNewPassword, setConfirmNewPassword] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const [email, setEmail] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const [, setName] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const [username, setUsername] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const [selectedLocale, setSelectedLocale] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](locale || "en");
    const [isWorking, setIsWorking] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [needsConfirmation, setNeedsConfirmation] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [confirmationCode, setConfirmationCode] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const [identityId, setIdentityId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const [successMessage, setSuccessMessage] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const [clearDataStoreDialogOpen, setClearDataStoreDialogOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const { settings, updateSettings } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {};
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {};
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPageContext"])(t1);
    const { level } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"])();
    const { badges: earnedBadges } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBadges"])();
    let maxTier;
    if ($[3] !== earnedBadges) {
        const bwBadges = earnedBadges.filter(_SettingsEarnedBadgesFilter);
        maxTier = 0;
        for (const b_0 of bwBadges){
            if (b_0.badgeType === "BOT_WHISPERER_IV") {
                maxTier = Math.max(maxTier, 4);
            } else {
                if (b_0.badgeType === "BOT_WHISPERER_III") {
                    maxTier = Math.max(maxTier, 3);
                } else {
                    if (b_0.badgeType === "BOT_WHISPERER_II") {
                        maxTier = Math.max(maxTier, 2);
                    } else {
                        if (b_0.badgeType === "BOT_WHISPERER_I") {
                            maxTier = Math.max(maxTier, 1);
                        }
                    }
                }
            }
        }
        $[3] = earnedBadges;
        $[4] = maxTier;
    } else {
        maxTier = $[4];
    }
    const botWhispererTier = maxTier;
    let t2;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [
            {
                code: "en",
                name: "English"
            },
            {
                code: "es",
                name: "Espa\xF1ol"
            },
            {
                code: "fr",
                name: "Fran\xE7ais"
            },
            {
                code: "de",
                name: "Deutsch"
            },
            {
                code: "ja",
                name: "\u65E5\u672C\u8A9E"
            },
            {
                code: "zh",
                name: "\u4E2D\u6587"
            }
        ];
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    const availableLocales = t2;
    let t3;
    if ($[6] !== confirmationCode) {
        t3 = ({
            "Settings[updateEmailConfirmation]": async (event)=>{
                setIsWorking(true);
                event.preventDefault();
                ;
                try {
                    await confirmUserAttribute({
                        userAttributeKey: "email",
                        confirmationCode
                    });
                    setIsWorking(false);
                    setNeedsConfirmation(false);
                    setSuccessMessage("Email updated successfully");
                } catch (t4) {
                    const error = t4;
                    alert(error.message);
                    setIsWorking(false);
                }
            }
        })["Settings[updateEmailConfirmation]"];
        $[6] = confirmationCode;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    const updateEmailConfirmation = t3;
    let t4;
    if ($[8] !== email || $[9] !== user?.email) {
        const updateEmail = {
            "Settings[updateEmail]": async (event_0)=>{
                setIsWorking(true);
                event_0.preventDefault();
                if (email !== user?.email) {
                    ;
                    try {
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$aws$2d$amplify$2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$updateUserAttribute$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateUserAttribute"])({
                            userAttribute: {
                                attributeKey: "email",
                                value: email
                            }
                        });
                        setNeedsConfirmation(true);
                    } catch (t5) {
                        const error_0 = t5;
                        alert(error_0.message);
                    }
                }
            }
        }["Settings[updateEmail]"];
        t4 = ({
            "Settings[updateUser]": async (event_1)=>{
                setIsWorking(true);
                event_1.preventDefault();
                await updateEmail(event_1);
                setIsWorking(false);
                setSuccessMessage("User updated successfully");
            }
        })["Settings[updateUser]"];
        $[8] = email;
        $[9] = user?.email;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    const updateUser = t4;
    let t5;
    if ($[11] !== newPassword || $[12] !== oldPassword) {
        t5 = ({
            "Settings[changePassword]": async (event_2)=>{
                setIsWorking(true);
                event_2.preventDefault();
                ;
                try {
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$aws$2d$amplify$2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$updatePassword$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updatePassword"])({
                        oldPassword,
                        newPassword
                    });
                    setIsWorking(false);
                    setSuccessMessage("Password changed successfully");
                } catch (t6) {
                    const error_1 = t6;
                    alert(error_1.message);
                }
                setOldPassword("");
                setNewPassword("");
                setConfirmNewPassword("");
            }
        })["Settings[changePassword]"];
        $[11] = newPassword;
        $[12] = oldPassword;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    const changePassword = t5;
    let t6;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "Settings[handleClearDataStore]": async ()=>{
                setIsWorking(true);
                setClearDataStoreDialogOpen(false);
                ;
                try {
                    console.log("Reloading page to clear cache...");
                    setSuccessMessage("Clearing cache and reloading...");
                    sessionStorage.clear();
                    setTimeout(_SettingsHandleClearDataStoreSetTimeout, 1000);
                } catch (t7) {
                    const error_2 = t7;
                    alert("Error clearing cache: " + error_2.message);
                    setIsWorking(false);
                }
            }
        })["Settings[handleClearDataStore]"];
        $[14] = t6;
    } else {
        t6 = $[14];
    }
    const handleClearDataStore = t6;
    let t7;
    if ($[15] !== pathname || $[16] !== router || $[17] !== t) {
        t7 = ({
            "Settings[handleLocaleChange]": async (event_3)=>{
                const newLocale = event_3.target.value;
                setSelectedLocale(newLocale);
                ;
                try {
                    localStorage.setItem("preferredLocale", newLocale);
                    await router.push(`/${newLocale}${pathname}`);
                    setSuccessMessage(t("profile.languagePreference.changeSuccess"));
                } catch (t8) {
                    const error_3 = t8;
                    console.error("Error changing locale:", error_3);
                    alert("Error changing language: " + error_3.message);
                }
            }
        })["Settings[handleLocaleChange]"];
        $[15] = pathname;
        $[16] = router;
        $[17] = t;
        $[18] = t7;
    } else {
        t7 = $[18];
    }
    const handleLocaleChange = t7;
    let t8;
    if ($[19] !== locale) {
        t8 = ({
            "Settings[useEffect()]": ()=>{
                fetchUser();
                async function fetchUser() {
                    const userAttributes = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$aws$2d$amplify$2f$node_modules$2f40$aws$2d$amplify$2f$auth$2f$dist$2f$esm$2f$providers$2f$cognito$2f$apis$2f$fetchUserAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchUserAttributes"])();
                    const { identityId: identityId_0 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAuthSession"])();
                    setUser(userAttributes);
                    setName(userAttributes?.name || "");
                    setEmail(userAttributes?.email || "");
                    setUsername(userAttributes?.sub || "");
                    setIdentityId(identityId_0);
                    const savedLocale = localStorage.getItem("preferredLocale");
                    if (savedLocale && locale !== savedLocale) {
                        setSelectedLocale(savedLocale);
                    } else {
                        setSelectedLocale(locale || "en");
                    }
                }
            }
        })["Settings[useEffect()]"];
        $[19] = locale;
        $[20] = t8;
    } else {
        t8 = $[20];
    }
    let t9;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = [];
        $[21] = t9;
    } else {
        t9 = $[21];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t8, t9);
    let t10;
    let t11;
    if ($[22] !== successMessage) {
        t10 = ({
            "Settings[useEffect()]": ()=>{
                if (successMessage) {
                    setTimeout({
                        "Settings[useEffect() > setTimeout()]": ()=>{
                            setSuccessMessage("");
                        }
                    }["Settings[useEffect() > setTimeout()]"], 10000);
                }
            }
        })["Settings[useEffect()]"];
        t11 = [
            successMessage
        ];
        $[22] = successMessage;
        $[23] = t10;
        $[24] = t11;
    } else {
        t10 = $[23];
        t11 = $[24];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t10, t11);
    let t12;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            marginTop: "1rem",
            marginBottom: "3rem",
            padding: "1rem",
            maxWidth: "60rem",
            marginLeft: "auto",
            marginRight: "auto",
            overflow: "auto"
        };
        $[25] = t12;
    } else {
        t12 = $[25];
    }
    let t13;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            padding: "2rem 1rem",
            margin: "1rem auto",
            height: "fit-content",
            maxWidth: "60rem"
        };
        $[26] = t13;
    } else {
        t13 = $[26];
    }
    let t14;
    if ($[27] !== t) {
        t14 = t("settings.profileInfo.heading");
        $[27] = t;
        $[28] = t14;
    } else {
        t14 = $[28];
    }
    let t15;
    if ($[29] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            children: t14
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 375,
            columnNumber: 11
        }, this);
        $[29] = t14;
        $[30] = t15;
    } else {
        t15 = $[30];
    }
    let t16;
    if ($[31] !== t) {
        t16 = t("settings.profileInfo.description");
        $[31] = t;
        $[32] = t16;
    } else {
        t16 = $[32];
    }
    let t17;
    if ($[33] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: t16
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 391,
            columnNumber: 11
        }, this);
        $[33] = t16;
        $[34] = t17;
    } else {
        t17 = $[34];
    }
    const t18 = username || "";
    let t19;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = {
            display: "none"
        };
        $[35] = t19;
    } else {
        t19 = $[35];
    }
    let t20;
    if ($[36] !== t18) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "text",
            name: "username",
            value: t18,
            autoComplete: "username",
            style: t19,
            readOnly: true,
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 409,
            columnNumber: 11
        }, this);
        $[36] = t18;
        $[37] = t20;
    } else {
        t20 = $[37];
    }
    let t21;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = ({
            "Settings[<TextField>.onChange]": (event_4)=>{
                setEmail(event_4.target.value);
            }
        })["Settings[<TextField>.onChange]"];
        $[38] = t21;
    } else {
        t21 = $[38];
    }
    let t22;
    if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = {
            mb: 2
        };
        $[39] = t22;
    } else {
        t22 = $[39];
    }
    let t23;
    if ($[40] !== email) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Email",
            type: "email",
            value: email,
            onChange: t21,
            required: true,
            sx: t22,
            autoComplete: "email"
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 437,
            columnNumber: 11
        }, this);
        $[40] = email;
        $[41] = t23;
    } else {
        t23 = $[41];
    }
    let t24;
    if ($[42] !== t) {
        t24 = t("profile.userId");
        $[42] = t;
        $[43] = t24;
    } else {
        t24 = $[43];
    }
    let t25;
    if ($[44] !== t24) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            children: t24
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 453,
            columnNumber: 11
        }, this);
        $[44] = t24;
        $[45] = t25;
    } else {
        t25 = $[45];
    }
    const t26 = user?.sub || "";
    let t27;
    if ($[46] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = {
            mb: 2
        };
        $[46] = t27;
    } else {
        t27 = $[46];
    }
    let t28;
    if ($[47] !== t26) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            type: "text",
            value: t26,
            disabled: true,
            sx: t27
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 471,
            columnNumber: 11
        }, this);
        $[47] = t26;
        $[48] = t28;
    } else {
        t28 = $[48];
    }
    let t29;
    if ($[49] !== t) {
        t29 = t("profile.identityId");
        $[49] = t;
        $[50] = t29;
    } else {
        t29 = $[50];
    }
    let t30;
    if ($[51] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            children: t29
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 487,
            columnNumber: 11
        }, this);
        $[51] = t29;
        $[52] = t30;
    } else {
        t30 = $[52];
    }
    const t31 = identityId || "";
    let t32;
    if ($[53] === Symbol.for("react.memo_cache_sentinel")) {
        t32 = {
            mb: 2
        };
        $[53] = t32;
    } else {
        t32 = $[53];
    }
    let t33;
    if ($[54] !== t31) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            type: "text",
            value: t31,
            disabled: true,
            sx: t32
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 505,
            columnNumber: 11
        }, this);
        $[54] = t31;
        $[55] = t33;
    } else {
        t33 = $[55];
    }
    let t34;
    if ($[56] === Symbol.for("react.memo_cache_sentinel")) {
        t34 = {
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between"
        };
        $[56] = t34;
    } else {
        t34 = $[56];
    }
    let t35;
    if ($[57] !== user?.email || $[58] !== user?.name) {
        t35 = ({
            "Settings[<Button>.onClick]": ()=>{
                setName(user?.name || "");
                setEmail(user?.email || "");
            }
        })["Settings[<Button>.onClick]"];
        $[57] = user?.email;
        $[58] = user?.name;
        $[59] = t35;
    } else {
        t35 = $[59];
    }
    let t36;
    if ($[60] !== t) {
        t36 = t("profile.cancel");
        $[60] = t;
        $[61] = t36;
    } else {
        t36 = $[61];
    }
    let t37;
    if ($[62] !== isWorking || $[63] !== t35 || $[64] !== t36) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "contained",
            color: "error",
            disabled: isWorking,
            onClick: t35,
            children: t36
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 546,
            columnNumber: 11
        }, this);
        $[62] = isWorking;
        $[63] = t35;
        $[64] = t36;
        $[65] = t37;
    } else {
        t37 = $[65];
    }
    let t38;
    if ($[66] !== isWorking) {
        t38 = isWorking && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
            variant: "circular",
            width: 24,
            height: 24
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 556,
            columnNumber: 24
        }, this);
        $[66] = isWorking;
        $[67] = t38;
    } else {
        t38 = $[67];
    }
    let t39;
    if ($[68] !== t) {
        t39 = t("profile.updateProfile");
        $[68] = t;
        $[69] = t39;
    } else {
        t39 = $[69];
    }
    let t40;
    if ($[70] !== isWorking || $[71] !== t38 || $[72] !== t39) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "contained",
            color: "primary",
            disabled: isWorking,
            type: "submit",
            children: [
                t38,
                " ",
                t39
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 572,
            columnNumber: 11
        }, this);
        $[70] = isWorking;
        $[71] = t38;
        $[72] = t39;
        $[73] = t40;
    } else {
        t40 = $[73];
    }
    let t41;
    if ($[74] !== t37 || $[75] !== t40) {
        t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: t34,
            children: [
                t37,
                t40
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 582,
            columnNumber: 11
        }, this);
        $[74] = t37;
        $[75] = t40;
        $[76] = t41;
    } else {
        t41 = $[76];
    }
    let t42;
    if ($[77] !== t20 || $[78] !== t23 || $[79] !== t25 || $[80] !== t28 || $[81] !== t30 || $[82] !== t33 || $[83] !== t41) {
        t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fullWidth: true,
            children: [
                t20,
                t23,
                t25,
                t28,
                t30,
                t33,
                t41
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 591,
            columnNumber: 11
        }, this);
        $[77] = t20;
        $[78] = t23;
        $[79] = t25;
        $[80] = t28;
        $[81] = t30;
        $[82] = t33;
        $[83] = t41;
        $[84] = t42;
    } else {
        t42 = $[84];
    }
    let t43;
    if ($[85] !== t42 || $[86] !== updateUser) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: updateUser,
            children: t42
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 605,
            columnNumber: 11
        }, this);
        $[85] = t42;
        $[86] = updateUser;
        $[87] = t43;
    } else {
        t43 = $[87];
    }
    let t44;
    if ($[88] === Symbol.for("react.memo_cache_sentinel")) {
        t44 = ({
            "Settings[<Modal>.onClose]": ()=>{
                setNeedsConfirmation(false);
            }
        })["Settings[<Modal>.onClose]"];
        $[88] = t44;
    } else {
        t44 = $[88];
    }
    let t45;
    if ($[89] === Symbol.for("react.memo_cache_sentinel")) {
        t45 = {
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: 400,
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 4
        };
        $[89] = t45;
    } else {
        t45 = $[89];
    }
    let t46;
    if ($[90] !== t) {
        t46 = t("profile.confirmEmail.title");
        $[90] = t;
        $[91] = t46;
    } else {
        t46 = $[91];
    }
    let t47;
    if ($[92] !== t46) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            id: "modal-modal-title",
            variant: "h6",
            component: "h2",
            children: t46
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 649,
            columnNumber: 11
        }, this);
        $[92] = t46;
        $[93] = t47;
    } else {
        t47 = $[93];
    }
    let t48;
    if ($[94] === Symbol.for("react.memo_cache_sentinel")) {
        t48 = {
            mt: 2
        };
        $[94] = t48;
    } else {
        t48 = $[94];
    }
    let t49;
    if ($[95] !== t) {
        t49 = t("profile.confirmEmail.message");
        $[95] = t;
        $[96] = t49;
    } else {
        t49 = $[96];
    }
    let t50;
    if ($[97] !== t49) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            id: "modal-modal-description",
            sx: t48,
            children: t49
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 674,
            columnNumber: 11
        }, this);
        $[97] = t49;
        $[98] = t50;
    } else {
        t50 = $[98];
    }
    let t51;
    if ($[99] === Symbol.for("react.memo_cache_sentinel")) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 682,
            columnNumber: 11
        }, this);
        $[99] = t51;
    } else {
        t51 = $[99];
    }
    let t52;
    if ($[100] === Symbol.for("react.memo_cache_sentinel")) {
        t52 = ({
            "Settings[<TextField>.onChange]": (event_5)=>{
                setConfirmationCode(event_5.target.value);
            }
        })["Settings[<TextField>.onChange]"];
        $[100] = t52;
    } else {
        t52 = $[100];
    }
    let t53;
    if ($[101] === Symbol.for("react.memo_cache_sentinel")) {
        t53 = {
            mb: 2
        };
        $[101] = t53;
    } else {
        t53 = $[101];
    }
    let t54;
    if ($[102] !== confirmationCode) {
        t54 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Confirmation Code",
            type: "text",
            value: confirmationCode,
            onChange: t52,
            required: true,
            sx: t53
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 709,
            columnNumber: 11
        }, this);
        $[102] = confirmationCode;
        $[103] = t54;
    } else {
        t54 = $[103];
    }
    let t55;
    if ($[104] === Symbol.for("react.memo_cache_sentinel")) {
        t55 = {
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between"
        };
        $[104] = t55;
    } else {
        t55 = $[104];
    }
    let t56;
    if ($[105] !== isWorking) {
        t56 = isWorking && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
            variant: "circular",
            width: 24,
            height: 24
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 728,
            columnNumber: 24
        }, this);
        $[105] = isWorking;
        $[106] = t56;
    } else {
        t56 = $[106];
    }
    let t57;
    if ($[107] !== t) {
        t57 = t("profile.confirmEmail.button");
        $[107] = t;
        $[108] = t57;
    } else {
        t57 = $[108];
    }
    let t58;
    if ($[109] !== isWorking || $[110] !== t56 || $[111] !== t57) {
        t58 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: t55,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "contained",
                color: "primary",
                disabled: isWorking,
                type: "submit",
                children: [
                    t56,
                    " ",
                    t57
                ]
            }, void 0, true, {
                fileName: "[project]/app/[locale]/settings/page.jsx",
                lineNumber: 744,
                columnNumber: 28
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 744,
            columnNumber: 11
        }, this);
        $[109] = isWorking;
        $[110] = t56;
        $[111] = t57;
        $[112] = t58;
    } else {
        t58 = $[112];
    }
    let t59;
    if ($[113] !== t54 || $[114] !== t58) {
        t59 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fullWidth: true,
            children: [
                t54,
                t58
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 754,
            columnNumber: 11
        }, this);
        $[113] = t54;
        $[114] = t58;
        $[115] = t59;
    } else {
        t59 = $[115];
    }
    let t60;
    if ($[116] !== t59 || $[117] !== updateEmailConfirmation) {
        t60 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: updateEmailConfirmation,
            children: t59
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 763,
            columnNumber: 11
        }, this);
        $[116] = t59;
        $[117] = updateEmailConfirmation;
        $[118] = t60;
    } else {
        t60 = $[118];
    }
    let t61;
    if ($[119] !== t47 || $[120] !== t50 || $[121] !== t60) {
        t61 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t45,
            children: [
                t47,
                t50,
                t51,
                t60
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 772,
            columnNumber: 11
        }, this);
        $[119] = t47;
        $[120] = t50;
        $[121] = t60;
        $[122] = t61;
    } else {
        t61 = $[122];
    }
    let t62;
    if ($[123] !== needsConfirmation || $[124] !== t61) {
        t62 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
            open: needsConfirmation,
            onClose: t44,
            "aria-labelledby": "modal-modal-title",
            "aria-describedby": "modal-modal-description",
            children: t61
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 782,
            columnNumber: 11
        }, this);
        $[123] = needsConfirmation;
        $[124] = t61;
        $[125] = t62;
    } else {
        t62 = $[125];
    }
    let t63;
    if ($[126] !== t15 || $[127] !== t17 || $[128] !== t43 || $[129] !== t62) {
        t63 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t13,
            children: [
                t15,
                t17,
                t43,
                t62
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 791,
            columnNumber: 11
        }, this);
        $[126] = t15;
        $[127] = t17;
        $[128] = t43;
        $[129] = t62;
        $[130] = t63;
    } else {
        t63 = $[130];
    }
    let t64;
    if ($[131] === Symbol.for("react.memo_cache_sentinel")) {
        t64 = {
            padding: "2rem 1rem",
            margin: "1rem auto",
            height: "fit-content",
            maxWidth: "60rem"
        };
        $[131] = t64;
    } else {
        t64 = $[131];
    }
    let t65;
    if ($[132] !== t) {
        t65 = t("profile.changePassword.heading");
        $[132] = t;
        $[133] = t65;
    } else {
        t65 = $[133];
    }
    let t66;
    if ($[134] !== t65) {
        t66 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            children: t65
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 822,
            columnNumber: 11
        }, this);
        $[134] = t65;
        $[135] = t66;
    } else {
        t66 = $[135];
    }
    let t67;
    if ($[136] !== t) {
        t67 = t("profile.changePassword.description");
        $[136] = t;
        $[137] = t67;
    } else {
        t67 = $[137];
    }
    let t68;
    if ($[138] !== t67) {
        t68 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: t67
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 838,
            columnNumber: 11
        }, this);
        $[138] = t67;
        $[139] = t68;
    } else {
        t68 = $[139];
    }
    const t69 = username || "";
    let t70;
    if ($[140] === Symbol.for("react.memo_cache_sentinel")) {
        t70 = {
            display: "none"
        };
        $[140] = t70;
    } else {
        t70 = $[140];
    }
    let t71;
    if ($[141] !== t69) {
        t71 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "text",
            name: "username",
            value: t69,
            autoComplete: "username",
            style: t70,
            readOnly: true,
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 856,
            columnNumber: 11
        }, this);
        $[141] = t69;
        $[142] = t71;
    } else {
        t71 = $[142];
    }
    let t72;
    if ($[143] === Symbol.for("react.memo_cache_sentinel")) {
        t72 = ({
            "Settings[<TextField>.onChange]": (event_6)=>{
                setOldPassword(event_6.target.value);
            }
        })["Settings[<TextField>.onChange]"];
        $[143] = t72;
    } else {
        t72 = $[143];
    }
    let t73;
    if ($[144] === Symbol.for("react.memo_cache_sentinel")) {
        t73 = {
            mb: 2
        };
        $[144] = t73;
    } else {
        t73 = $[144];
    }
    let t74;
    if ($[145] !== oldPassword) {
        t74 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Old Password",
            type: "password",
            value: oldPassword,
            onChange: t72,
            required: true,
            sx: t73,
            autoComplete: "current-password"
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 884,
            columnNumber: 11
        }, this);
        $[145] = oldPassword;
        $[146] = t74;
    } else {
        t74 = $[146];
    }
    let t75;
    if ($[147] === Symbol.for("react.memo_cache_sentinel")) {
        t75 = ({
            "Settings[<TextField>.onChange]": (event_7)=>{
                setNewPassword(event_7.target.value);
            }
        })["Settings[<TextField>.onChange]"];
        $[147] = t75;
    } else {
        t75 = $[147];
    }
    let t76;
    if ($[148] === Symbol.for("react.memo_cache_sentinel")) {
        t76 = {
            mb: 2
        };
        $[148] = t76;
    } else {
        t76 = $[148];
    }
    let t77;
    if ($[149] !== newPassword) {
        t77 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "New Password",
            type: "password",
            value: newPassword,
            onChange: t75,
            required: true,
            sx: t76,
            autoComplete: "new-password"
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 912,
            columnNumber: 11
        }, this);
        $[149] = newPassword;
        $[150] = t77;
    } else {
        t77 = $[150];
    }
    let t78;
    if ($[151] === Symbol.for("react.memo_cache_sentinel")) {
        t78 = ({
            "Settings[<TextField>.onChange]": (event_8)=>{
                setConfirmNewPassword(event_8.target.value);
            }
        })["Settings[<TextField>.onChange]"];
        $[151] = t78;
    } else {
        t78 = $[151];
    }
    let t79;
    if ($[152] === Symbol.for("react.memo_cache_sentinel")) {
        t79 = {
            mb: 2
        };
        $[152] = t79;
    } else {
        t79 = $[152];
    }
    let t80;
    if ($[153] !== confirmNewPassword) {
        t80 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Confirm New Password",
            type: "password",
            value: confirmNewPassword,
            onChange: t78,
            required: true,
            sx: t79,
            autoComplete: "new-password"
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 940,
            columnNumber: 11
        }, this);
        $[153] = confirmNewPassword;
        $[154] = t80;
    } else {
        t80 = $[154];
    }
    let t81;
    if ($[155] !== isWorking) {
        t81 = isWorking && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
            variant: "circular",
            width: 24,
            height: 24
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 948,
            columnNumber: 24
        }, this);
        $[155] = isWorking;
        $[156] = t81;
    } else {
        t81 = $[156];
    }
    let t82;
    if ($[157] !== t) {
        t82 = t("profile.changePassword.button");
        $[157] = t;
        $[158] = t82;
    } else {
        t82 = $[158];
    }
    let t83;
    if ($[159] !== isWorking || $[160] !== t81 || $[161] !== t82) {
        t83 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "contained",
            color: "primary",
            disabled: isWorking,
            type: "submit",
            children: [
                t81,
                " ",
                t82
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 964,
            columnNumber: 11
        }, this);
        $[159] = isWorking;
        $[160] = t81;
        $[161] = t82;
        $[162] = t83;
    } else {
        t83 = $[162];
    }
    let t84;
    if ($[163] !== t71 || $[164] !== t74 || $[165] !== t77 || $[166] !== t80 || $[167] !== t83) {
        t84 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fullWidth: true,
            children: [
                t71,
                t74,
                t77,
                t80,
                t83
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 974,
            columnNumber: 11
        }, this);
        $[163] = t71;
        $[164] = t74;
        $[165] = t77;
        $[166] = t80;
        $[167] = t83;
        $[168] = t84;
    } else {
        t84 = $[168];
    }
    let t85;
    if ($[169] !== changePassword || $[170] !== t84) {
        t85 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: changePassword,
            children: t84
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 986,
            columnNumber: 11
        }, this);
        $[169] = changePassword;
        $[170] = t84;
        $[171] = t85;
    } else {
        t85 = $[171];
    }
    let t86;
    if ($[172] !== t66 || $[173] !== t68 || $[174] !== t85) {
        t86 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t64,
            children: [
                t66,
                t68,
                t85
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 995,
            columnNumber: 11
        }, this);
        $[172] = t66;
        $[173] = t68;
        $[174] = t85;
        $[175] = t86;
    } else {
        t86 = $[175];
    }
    let t87;
    if ($[176] === Symbol.for("react.memo_cache_sentinel")) {
        t87 = {
            padding: "2rem 1rem",
            margin: "1rem auto",
            height: "fit-content",
            maxWidth: "60rem"
        };
        $[176] = t87;
    } else {
        t87 = $[176];
    }
    let t88;
    if ($[177] !== t) {
        t88 = t("profile.languagePreference.heading");
        $[177] = t;
        $[178] = t88;
    } else {
        t88 = $[178];
    }
    let t89;
    if ($[179] !== t88) {
        t89 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            children: t88
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1025,
            columnNumber: 11
        }, this);
        $[179] = t88;
        $[180] = t89;
    } else {
        t89 = $[180];
    }
    let t90;
    if ($[181] !== t) {
        t90 = t("profile.languagePreference.description");
        $[181] = t;
        $[182] = t90;
    } else {
        t90 = $[182];
    }
    let t91;
    if ($[183] !== t90) {
        t91 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: t90
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1041,
            columnNumber: 11
        }, this);
        $[183] = t90;
        $[184] = t91;
    } else {
        t91 = $[184];
    }
    let t92;
    if ($[185] === Symbol.for("react.memo_cache_sentinel")) {
        t92 = {
            mt: 2
        };
        $[185] = t92;
    } else {
        t92 = $[185];
    }
    let t93;
    if ($[186] !== t) {
        t93 = t("profile.languagePreference.selectLanguage");
        $[186] = t;
        $[187] = t93;
    } else {
        t93 = $[187];
    }
    let t94;
    if ($[188] !== t93) {
        t94 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__["InputLabel"], {
            id: "locale-select-label",
            children: t93
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1066,
            columnNumber: 11
        }, this);
        $[188] = t93;
        $[189] = t94;
    } else {
        t94 = $[189];
    }
    let t95;
    if ($[190] !== t) {
        t95 = t("profile.languagePreference.selectLanguage");
        $[190] = t;
        $[191] = t95;
    } else {
        t95 = $[191];
    }
    let t96;
    if ($[192] === Symbol.for("react.memo_cache_sentinel")) {
        t96 = availableLocales.map(_SettingsAvailableLocalesMap);
        $[192] = t96;
    } else {
        t96 = $[192];
    }
    let t97;
    if ($[193] !== handleLocaleChange || $[194] !== selectedLocale || $[195] !== t95) {
        t97 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
            labelId: "locale-select-label",
            id: "locale-select",
            value: selectedLocale,
            label: t95,
            onChange: handleLocaleChange,
            children: t96
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1089,
            columnNumber: 11
        }, this);
        $[193] = handleLocaleChange;
        $[194] = selectedLocale;
        $[195] = t95;
        $[196] = t97;
    } else {
        t97 = $[196];
    }
    let t98;
    if ($[197] !== t94 || $[198] !== t97) {
        t98 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fullWidth: true,
            sx: t92,
            children: [
                t94,
                t97
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1099,
            columnNumber: 11
        }, this);
        $[197] = t94;
        $[198] = t97;
        $[199] = t98;
    } else {
        t98 = $[199];
    }
    let t99;
    if ($[200] !== t89 || $[201] !== t91 || $[202] !== t98) {
        t99 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t87,
            children: [
                t89,
                t91,
                t98
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1108,
            columnNumber: 11
        }, this);
        $[200] = t89;
        $[201] = t91;
        $[202] = t98;
        $[203] = t99;
    } else {
        t99 = $[203];
    }
    let t100;
    if ($[204] === Symbol.for("react.memo_cache_sentinel")) {
        t100 = {
            padding: "2rem 1rem",
            margin: "1rem auto",
            height: "fit-content",
            maxWidth: "60rem"
        };
        $[204] = t100;
    } else {
        t100 = $[204];
    }
    let t101;
    if ($[205] !== t) {
        t101 = t("profile.advanced.heading");
        $[205] = t;
        $[206] = t101;
    } else {
        t101 = $[206];
    }
    let t102;
    if ($[207] !== t101) {
        t102 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            children: t101
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1138,
            columnNumber: 12
        }, this);
        $[207] = t101;
        $[208] = t102;
    } else {
        t102 = $[208];
    }
    let t103;
    if ($[209] !== t) {
        t103 = t("profile.advanced.description");
        $[209] = t;
        $[210] = t103;
    } else {
        t103 = $[210];
    }
    let t104;
    if ($[211] !== t103) {
        t104 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: t103
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1154,
            columnNumber: 12
        }, this);
        $[211] = t103;
        $[212] = t104;
    } else {
        t104 = $[212];
    }
    let t105;
    let t106;
    if ($[213] === Symbol.for("react.memo_cache_sentinel")) {
        t105 = ({
            "Settings[<Button>.onClick]": ()=>setClearDataStoreDialogOpen(true)
        })["Settings[<Button>.onClick]"];
        t106 = {
            mt: 2
        };
        $[213] = t105;
        $[214] = t106;
    } else {
        t105 = $[213];
        t106 = $[214];
    }
    let t107;
    if ($[215] !== t) {
        t107 = t("profile.advanced.clearCache");
        $[215] = t;
        $[216] = t107;
    } else {
        t107 = $[216];
    }
    let t108;
    if ($[217] !== isWorking || $[218] !== t107) {
        t108 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "outlined",
            color: "warning",
            disabled: isWorking,
            onClick: t105,
            sx: t106,
            children: t107
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1185,
            columnNumber: 12
        }, this);
        $[217] = isWorking;
        $[218] = t107;
        $[219] = t108;
    } else {
        t108 = $[219];
    }
    let t109;
    if ($[220] !== t102 || $[221] !== t104 || $[222] !== t108) {
        t109 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t100,
            children: [
                t102,
                t104,
                t108
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1194,
            columnNumber: 12
        }, this);
        $[220] = t102;
        $[221] = t104;
        $[222] = t108;
        $[223] = t109;
    } else {
        t109 = $[223];
    }
    let t110;
    if ($[224] === Symbol.for("react.memo_cache_sentinel")) {
        t110 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$StorageManagement$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1204,
            columnNumber: 12
        }, this);
        $[224] = t110;
    } else {
        t110 = $[224];
    }
    let t111;
    if ($[225] === Symbol.for("react.memo_cache_sentinel")) {
        t111 = {
            padding: "2rem 1rem",
            margin: "1rem auto",
            height: "fit-content",
            maxWidth: "60rem"
        };
        $[225] = t111;
    } else {
        t111 = $[225];
    }
    let t112;
    if ($[226] !== t) {
        t112 = t("settings.privacy.heading");
        $[226] = t;
        $[227] = t112;
    } else {
        t112 = $[227];
    }
    let t113;
    if ($[228] !== t112) {
        t113 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h5",
            gutterBottom: true,
            children: t112
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1231,
            columnNumber: 12
        }, this);
        $[228] = t112;
        $[229] = t113;
    } else {
        t113 = $[229];
    }
    const t114 = settings?.leaderboardOptIn !== false;
    let t115;
    if ($[230] !== updateSettings) {
        t115 = ({
            "Settings[<Switch>.onChange]": (e)=>{
                if (updateSettings) {
                    updateSettings({
                        leaderboardOptIn: e.target.checked
                    });
                }
            }
        })["Settings[<Switch>.onChange]"];
        $[230] = updateSettings;
        $[231] = t115;
    } else {
        t115 = $[231];
    }
    let t116;
    if ($[232] !== t114 || $[233] !== t115) {
        t116 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            checked: t114,
            onChange: t115
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1256,
            columnNumber: 12
        }, this);
        $[232] = t114;
        $[233] = t115;
        $[234] = t116;
    } else {
        t116 = $[234];
    }
    let t117;
    if ($[235] !== t) {
        t117 = t("settings.privacy.leaderboardOptIn");
        $[235] = t;
        $[236] = t117;
    } else {
        t117 = $[236];
    }
    let t118;
    if ($[237] !== t116 || $[238] !== t117) {
        t118 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            control: t116,
            label: t117
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1273,
            columnNumber: 12
        }, this);
        $[237] = t116;
        $[238] = t117;
        $[239] = t118;
    } else {
        t118 = $[239];
    }
    let t119;
    if ($[240] === Symbol.for("react.memo_cache_sentinel")) {
        t119 = {
            ml: 4
        };
        $[240] = t119;
    } else {
        t119 = $[240];
    }
    let t120;
    if ($[241] !== t) {
        t120 = t("settings.privacy.leaderboardOptInHint");
        $[241] = t;
        $[242] = t120;
    } else {
        t120 = $[242];
    }
    let t121;
    if ($[243] !== t120) {
        t121 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: t119,
            children: t120
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1299,
            columnNumber: 12
        }, this);
        $[243] = t120;
        $[244] = t121;
    } else {
        t121 = $[244];
    }
    let t122;
    if ($[245] !== t113 || $[246] !== t118 || $[247] !== t121) {
        t122 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t111,
            children: [
                t113,
                t118,
                t121
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1307,
            columnNumber: 12
        }, this);
        $[245] = t113;
        $[246] = t118;
        $[247] = t121;
        $[248] = t122;
    } else {
        t122 = $[248];
    }
    let t123;
    let t124;
    if ($[249] === Symbol.for("react.memo_cache_sentinel")) {
        t123 = {
            padding: "2rem 1rem",
            margin: "1rem auto",
            height: "fit-content",
            maxWidth: "60rem"
        };
        t124 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h5",
            gutterBottom: true,
            children: "Profile Visibility"
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1324,
            columnNumber: 12
        }, this);
        $[249] = t123;
        $[250] = t124;
    } else {
        t123 = $[249];
        t124 = $[250];
    }
    let t125;
    if ($[251] === Symbol.for("react.memo_cache_sentinel")) {
        t125 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: {
                mb: 2
            },
            children: "Choose what others can see on your profile page."
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1333,
            columnNumber: 12
        }, this);
        $[251] = t125;
    } else {
        t125 = $[251];
    }
    const t126 = settings?.showBadgesOnProfile !== false;
    let t127;
    if ($[252] !== updateSettings) {
        t127 = ({
            "Settings[<Switch>.onChange]": (e_0)=>{
                if (updateSettings) {
                    updateSettings({
                        showBadgesOnProfile: e_0.target.checked
                    });
                }
            }
        })["Settings[<Switch>.onChange]"];
        $[252] = updateSettings;
        $[253] = t127;
    } else {
        t127 = $[253];
    }
    let t128;
    if ($[254] !== t126 || $[255] !== t127) {
        t128 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                checked: t126,
                onChange: t127
            }, void 0, false, {
                fileName: "[project]/app/[locale]/settings/page.jsx",
                lineNumber: 1359,
                columnNumber: 39
            }, this),
            label: "Show badges on profile"
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1359,
            columnNumber: 12
        }, this);
        $[254] = t126;
        $[255] = t127;
        $[256] = t128;
    } else {
        t128 = $[256];
    }
    let t129;
    if ($[257] === Symbol.for("react.memo_cache_sentinel")) {
        t129 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: {
                ml: 4,
                mb: 1
            },
            children: "Display your earned achievement badges on your public profile."
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1368,
            columnNumber: 12
        }, this);
        $[257] = t129;
    } else {
        t129 = $[257];
    }
    const t130 = settings?.showAntiBadgesOnProfile === true;
    let t131;
    if ($[258] !== updateSettings) {
        t131 = ({
            "Settings[<Switch>.onChange]": (e_1)=>{
                if (updateSettings) {
                    updateSettings({
                        showAntiBadgesOnProfile: e_1.target.checked
                    });
                }
            }
        })["Settings[<Switch>.onChange]"];
        $[258] = updateSettings;
        $[259] = t131;
    } else {
        t131 = $[259];
    }
    let t132;
    if ($[260] !== t130 || $[261] !== t131) {
        t132 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                checked: t130,
                onChange: t131
            }, void 0, false, {
                fileName: "[project]/app/[locale]/settings/page.jsx",
                lineNumber: 1395,
                columnNumber: 39
            }, this),
            label: "Show anti-badges on profile"
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1395,
            columnNumber: 12
        }, this);
        $[260] = t130;
        $[261] = t131;
        $[262] = t132;
    } else {
        t132 = $[262];
    }
    let t133;
    if ($[263] === Symbol.for("react.memo_cache_sentinel")) {
        t133 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: {
                ml: 4
            },
            children: "Display anti-badges on your profile. These are humorous, not punitive — show them off if you want!"
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1404,
            columnNumber: 12
        }, this);
        $[263] = t133;
    } else {
        t133 = $[263];
    }
    let t134;
    if ($[264] !== t128 || $[265] !== t132) {
        t134 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t123,
            children: [
                t124,
                t125,
                t128,
                t129,
                t132,
                t133
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1413,
            columnNumber: 12
        }, this);
        $[264] = t128;
        $[265] = t132;
        $[266] = t134;
    } else {
        t134 = $[266];
    }
    let t135;
    if ($[267] === Symbol.for("react.memo_cache_sentinel")) {
        t135 = {
            padding: "2rem 1rem",
            margin: "1rem auto",
            height: "fit-content",
            maxWidth: "60rem"
        };
        $[267] = t135;
    } else {
        t135 = $[267];
    }
    let t136;
    if ($[268] !== t) {
        t136 = t("settings.customization.heading");
        $[268] = t;
        $[269] = t136;
    } else {
        t136 = $[269];
    }
    let t137;
    if ($[270] !== t136) {
        t137 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h5",
            gutterBottom: true,
            children: t136
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1442,
            columnNumber: 12
        }, this);
        $[270] = t136;
        $[271] = t137;
    } else {
        t137 = $[271];
    }
    let t138;
    if ($[272] === Symbol.for("react.memo_cache_sentinel")) {
        t138 = {
            mb: 2
        };
        $[272] = t138;
    } else {
        t138 = $[272];
    }
    let t139;
    if ($[273] !== t) {
        t139 = t("settings.customization.description");
        $[273] = t;
        $[274] = t139;
    } else {
        t139 = $[274];
    }
    let t140;
    if ($[275] !== t139) {
        t140 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: t138,
            children: t139
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1467,
            columnNumber: 12
        }, this);
        $[275] = t139;
        $[276] = t140;
    } else {
        t140 = $[276];
    }
    const t141 = level?.level || 1;
    const t142 = settings?.profileThemeId || settings?.editorTheme || "default";
    let t143;
    if ($[277] !== updateSettings) {
        t143 = ({
            "Settings[<CosmeticSelector>.onThemeSelect]": (themeId)=>{
                if (updateSettings) {
                    updateSettings({
                        profileThemeId: themeId
                    });
                }
            }
        })["Settings[<CosmeticSelector>.onThemeSelect]"];
        $[277] = updateSettings;
        $[278] = t143;
    } else {
        t143 = $[278];
    }
    let t144;
    if ($[279] !== settings) {
        t144 = settings?.customThemePalette ? typeof settings.customThemePalette === "string" ? JSON.parse(settings.customThemePalette) : settings.customThemePalette : null;
        $[279] = settings;
        $[280] = t144;
    } else {
        t144 = $[280];
    }
    let t145;
    if ($[281] !== updateSettings) {
        t145 = ({
            "Settings[<CosmeticSelector>.onCustomPaletteSave]": (palette)=>{
                if (updateSettings) {
                    updateSettings({
                        profileThemeId: "custom",
                        customThemePalette: JSON.stringify(palette)
                    });
                }
            }
        })["Settings[<CosmeticSelector>.onCustomPaletteSave]"];
        $[281] = updateSettings;
        $[282] = t145;
    } else {
        t145 = $[282];
    }
    let t146;
    if ($[283] !== t141 || $[284] !== t142 || $[285] !== t143 || $[286] !== t144 || $[287] !== t145) {
        t146 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$CosmeticSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CosmeticSelector"], {
            level: t141,
            selectedThemeId: t142,
            onThemeSelect: t143,
            customThemePalette: t144,
            onCustomPaletteSave: t145
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1518,
            columnNumber: 12
        }, this);
        $[283] = t141;
        $[284] = t142;
        $[285] = t143;
        $[286] = t144;
        $[287] = t145;
        $[288] = t146;
    } else {
        t146 = $[288];
    }
    let t147;
    if ($[289] === Symbol.for("react.memo_cache_sentinel")) {
        t147 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: {
                mt: 1
            },
            children: "Your selected theme will also be applied to your public profile page."
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1530,
            columnNumber: 12
        }, this);
        $[289] = t147;
    } else {
        t147 = $[289];
    }
    let t148;
    if ($[290] !== t137 || $[291] !== t140 || $[292] !== t146) {
        t148 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t135,
            children: [
                t137,
                t140,
                t146,
                t147
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1539,
            columnNumber: 12
        }, this);
        $[290] = t137;
        $[291] = t140;
        $[292] = t146;
        $[293] = t148;
    } else {
        t148 = $[293];
    }
    let t149;
    if ($[294] === Symbol.for("react.memo_cache_sentinel")) {
        t149 = {
            padding: "2rem 1rem",
            margin: "1rem auto",
            height: "fit-content",
            maxWidth: "60rem"
        };
        $[294] = t149;
    } else {
        t149 = $[294];
    }
    let t150;
    if ($[295] !== t) {
        t150 = t("settings.botCustomizer.heading");
        $[295] = t;
        $[296] = t150;
    } else {
        t150 = $[296];
    }
    let t151;
    if ($[297] !== t150) {
        t151 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h5",
            gutterBottom: true,
            children: t150
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1569,
            columnNumber: 12
        }, this);
        $[297] = t150;
        $[298] = t151;
    } else {
        t151 = $[298];
    }
    let t152;
    if ($[299] === Symbol.for("react.memo_cache_sentinel")) {
        t152 = {
            mb: 2
        };
        $[299] = t152;
    } else {
        t152 = $[299];
    }
    let t153;
    if ($[300] !== t) {
        t153 = t("settings.botCustomizer.description");
        $[300] = t;
        $[301] = t153;
    } else {
        t153 = $[301];
    }
    let t154;
    if ($[302] !== t153) {
        t154 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: t152,
            children: t153
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1594,
            columnNumber: 12
        }, this);
        $[302] = t153;
        $[303] = t154;
    } else {
        t154 = $[303];
    }
    let t155;
    if ($[304] !== botWhispererTier) {
        t155 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BotCustomizer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BotCustomizer"], {
            botWhispererTier: botWhispererTier
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1602,
            columnNumber: 12
        }, this);
        $[304] = botWhispererTier;
        $[305] = t155;
    } else {
        t155 = $[305];
    }
    let t156;
    if ($[306] !== t151 || $[307] !== t154 || $[308] !== t155) {
        t156 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t149,
            children: [
                t151,
                t154,
                t155
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1610,
            columnNumber: 12
        }, this);
        $[306] = t151;
        $[307] = t154;
        $[308] = t155;
        $[309] = t156;
    } else {
        t156 = $[309];
    }
    let t157;
    if ($[310] === Symbol.for("react.memo_cache_sentinel")) {
        t157 = ({
            "Settings[<Dialog>.onClose]": ()=>setClearDataStoreDialogOpen(false)
        })["Settings[<Dialog>.onClose]"];
        $[310] = t157;
    } else {
        t157 = $[310];
    }
    let t158;
    if ($[311] !== t) {
        t158 = t("profile.advanced.clearCacheDialog.title");
        $[311] = t;
        $[312] = t158;
    } else {
        t158 = $[312];
    }
    let t159;
    if ($[313] !== t158) {
        t159 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
            id: "clear-datastore-dialog-title",
            children: t158
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1637,
            columnNumber: 12
        }, this);
        $[313] = t158;
        $[314] = t159;
    } else {
        t159 = $[314];
    }
    let t160;
    if ($[315] !== t) {
        t160 = t("profile.advanced.clearCacheDialog.message");
        $[315] = t;
        $[316] = t160;
    } else {
        t160 = $[316];
    }
    let t161;
    if ($[317] !== t160) {
        t161 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContentText$2f$DialogContentText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContentText$3e$__["DialogContentText"], {
                id: "clear-datastore-dialog-description",
                children: t160
            }, void 0, false, {
                fileName: "[project]/app/[locale]/settings/page.jsx",
                lineNumber: 1653,
                columnNumber: 27
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1653,
            columnNumber: 12
        }, this);
        $[317] = t160;
        $[318] = t161;
    } else {
        t161 = $[318];
    }
    let t162;
    if ($[319] === Symbol.for("react.memo_cache_sentinel")) {
        t162 = ({
            "Settings[<Button>.onClick]": ()=>setClearDataStoreDialogOpen(false)
        })["Settings[<Button>.onClick]"];
        $[319] = t162;
    } else {
        t162 = $[319];
    }
    let t163;
    if ($[320] !== t) {
        t163 = t("profile.advanced.clearCacheDialog.cancel");
        $[320] = t;
        $[321] = t163;
    } else {
        t163 = $[321];
    }
    let t164;
    if ($[322] !== t163) {
        t164 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: t162,
            color: "primary",
            children: t163
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1678,
            columnNumber: 12
        }, this);
        $[322] = t163;
        $[323] = t164;
    } else {
        t164 = $[323];
    }
    let t165;
    if ($[324] !== t) {
        t165 = t("profile.advanced.clearCacheDialog.confirm");
        $[324] = t;
        $[325] = t165;
    } else {
        t165 = $[325];
    }
    let t166;
    if ($[326] !== t165) {
        t166 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: handleClearDataStore,
            color: "warning",
            variant: "contained",
            autoFocus: true,
            children: t165
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1694,
            columnNumber: 12
        }, this);
        $[326] = t165;
        $[327] = t166;
    } else {
        t166 = $[327];
    }
    let t167;
    if ($[328] !== t164 || $[329] !== t166) {
        t167 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
            children: [
                t164,
                t166
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1702,
            columnNumber: 12
        }, this);
        $[328] = t164;
        $[329] = t166;
        $[330] = t167;
    } else {
        t167 = $[330];
    }
    let t168;
    if ($[331] !== clearDataStoreDialogOpen || $[332] !== t159 || $[333] !== t161 || $[334] !== t167) {
        t168 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
            open: clearDataStoreDialogOpen,
            onClose: t157,
            "aria-labelledby": "clear-datastore-dialog-title",
            "aria-describedby": "clear-datastore-dialog-description",
            children: [
                t159,
                t161,
                t167
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1711,
            columnNumber: 12
        }, this);
        $[331] = clearDataStoreDialogOpen;
        $[332] = t159;
        $[333] = t161;
        $[334] = t167;
        $[335] = t168;
    } else {
        t168 = $[335];
    }
    const t169 = successMessage !== "";
    let t170;
    if ($[336] === Symbol.for("react.memo_cache_sentinel")) {
        t170 = ({
            "Settings[<Snackbar>.onClose]": ()=>setSuccessMessage("")
        })["Settings[<Snackbar>.onClose]"];
        $[336] = t170;
    } else {
        t170 = $[336];
    }
    let t171;
    if ($[337] !== successMessage || $[338] !== t169) {
        t171 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: t169,
            autoHideDuration: 6000,
            onClose: t170,
            message: successMessage
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1732,
            columnNumber: 12
        }, this);
        $[337] = successMessage;
        $[338] = t169;
        $[339] = t171;
    } else {
        t171 = $[339];
    }
    let t172;
    if ($[340] !== t109 || $[341] !== t122 || $[342] !== t134 || $[343] !== t148 || $[344] !== t156 || $[345] !== t168 || $[346] !== t171 || $[347] !== t63 || $[348] !== t86 || $[349] !== t99) {
        t172 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t12,
                children: [
                    t63,
                    t86,
                    t99,
                    t109,
                    t110,
                    t122,
                    t134,
                    t148,
                    t156,
                    t168,
                    t171
                ]
            }, void 0, true, {
                fileName: "[project]/app/[locale]/settings/page.jsx",
                lineNumber: 1741,
                columnNumber: 14
            }, this)
        }, void 0, false);
        $[340] = t109;
        $[341] = t122;
        $[342] = t134;
        $[343] = t148;
        $[344] = t156;
        $[345] = t168;
        $[346] = t171;
        $[347] = t63;
        $[348] = t86;
        $[349] = t99;
        $[350] = t172;
    } else {
        t172 = $[350];
    }
    return t172;
}
_s(Settings, "wlImY8019wtR7ZK37b8z0579z6A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLocale"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPageContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXP"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBadges"]
    ];
});
_c = Settings;
function _SettingsAvailableLocalesMap(locale_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
        value: locale_0.code,
        children: locale_0.name
    }, locale_0.code, false, {
        fileName: "[project]/app/[locale]/settings/page.jsx",
        lineNumber: 1759,
        columnNumber: 10
    }, this);
}
function _SettingsHandleClearDataStoreSetTimeout() {
    window.location.reload();
}
function _SettingsEarnedBadgesFilter(b) {
    return b.badgeType?.startsWith("BOT_WHISPERER");
}
function WrappedPage() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "f8134736c5d44f27a6b6f1952f9e931e568da0c6ca6c53208d4e55e8e45cf98c") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f8134736c5d44f27a6b6f1952f9e931e568da0c6ca6c53208d4e55e8e45cf98c";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$gamificationProviderWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GamificationProviderWrapper"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Settings, {}, void 0, false, {
                fileName: "[project]/app/[locale]/settings/page.jsx",
                lineNumber: 1777,
                columnNumber: 39
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/settings/page.jsx",
            lineNumber: 1777,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c1 = WrappedPage;
var _c, _c1;
__turbopack_context__.k.register(_c, "Settings");
__turbopack_context__.k.register(_c1, "WrappedPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_02pykjz._.js.map