(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Editor3/WorkbookSSRSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WorkbookSSRSkeleton",
    ()=>WorkbookSSRSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * WorkbookSSRSkeleton — Server-rendered HTML skeleton for the Workbook.
 *
 * Displays the pre-rendered Lexical HTML immediately on page load (via SSR)
 * while the full interactive client-side Workbook component is loading.
 * This gives users instant content visibility and provides SEO-friendly HTML.
 *
 * Pattern from: https://github.com/2wheeh/lexical-nextjs-ssr
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
;
;
;
function WorkbookSSRSkeleton(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "7618b6789232802d1d0bb1980bfa4bae3df579cb10dc4dd958c5649b3ba1c2cc") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7618b6789232802d1d0bb1980bfa4bae3df579cb10dc4dd958c5649b3ba1c2cc";
    }
    const { html } = t0;
    if (!html) {
        let t1;
        if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
            t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    minHeight: "200px",
                    opacity: 0.5
                },
                children: "Loading content..."
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/WorkbookSSRSkeleton.tsx",
                lineNumber: 31,
                columnNumber: 12
            }, this);
            $[1] = t1;
        } else {
            t1 = $[1];
        }
        return t1;
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            "& .editor-paragraph": {
                margin: "0 0 8px"
            },
            "& h1, & h2, & h3, & h4, & h5, & h6": {
                margin: "16px 0 8px"
            },
            "& ul, & ol": {
                paddingLeft: "24px"
            },
            "& img": {
                maxWidth: "100%",
                height: "auto"
            },
            "& a": {
                color: "primary.main",
                textDecoration: "underline"
            }
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== html) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: "workbook-ssr-skeleton",
            sx: t1,
            dangerouslySetInnerHTML: {
                __html: html
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/WorkbookSSRSkeleton.tsx",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[3] = html;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    return t2;
}
_c = WorkbookSSRSkeleton;
var _c;
__turbopack_context__.k.register(_c, "WorkbookSSRSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/SecretLinkIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SecretLinkIcon",
    ()=>SecretLinkIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$api$2f$dist$2f$esm$2f$API$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/api/dist/esm/API.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/apis/fetchAuthSession.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Search.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/EasterEggToast.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$api$2f$dist$2f$esm$2f$API$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateClient"])();
function SecretLinkIcon({ unitId }) {
    _s();
    const [eggs, setEggs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [studentId, setStudentId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [toast, setToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        open: false,
        message: '',
        xpReward: 0
    });
    const discoveredRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Set());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SecretLinkIcon.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAuthSession"])().then({
                "SecretLinkIcon.useEffect": (session)=>{
                    const username = session?.tokens?.idToken?.payload?.['cognito:username'] || session?.tokens?.idToken?.payload?.sub || '';
                    if (username) setStudentId(username);
                }
            }["SecretLinkIcon.useEffect"]).catch({
                "SecretLinkIcon.useEffect": ()=>{}
            }["SecretLinkIcon.useEffect"]);
        }
    }["SecretLinkIcon.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SecretLinkIcon.useEffect": ()=>{
            if (!studentId || !unitId) return;
            client.models?.EasterEgg?.list?.().then({
                "SecretLinkIcon.useEffect": ({ data })=>{
                    const secretLinks = (data || []).filter({
                        "SecretLinkIcon.useEffect.secretLinks": (e)=>e != null && e.trigger === 'SECRET_LINK' && e.triggerValue === unitId && e.active !== false
                    }["SecretLinkIcon.useEffect.secretLinks"]);
                    // Filter out already discovered
                    const undiscovered = secretLinks.filter({
                        "SecretLinkIcon.useEffect.undiscovered": (e_0)=>{
                            const discoveries = e_0.discoveries || [];
                            const found = discoveries.some({
                                "SecretLinkIcon.useEffect.undiscovered.found": (d)=>d.studentId === studentId
                            }["SecretLinkIcon.useEffect.undiscovered.found"]);
                            if (found) discoveredRef.current.add(e_0.id);
                            return !found;
                        }
                    }["SecretLinkIcon.useEffect.undiscovered"]);
                    setEggs(undiscovered.map({
                        "SecretLinkIcon.useEffect": (e_1)=>({
                                id: e_1.id,
                                message: e_1.revealMessage || 'You found a secret!',
                                xpReward: e_1.xpReward || 0
                            })
                    }["SecretLinkIcon.useEffect"]));
                }
            }["SecretLinkIcon.useEffect"]).catch({
                "SecretLinkIcon.useEffect": (err)=>console.warn('[SecretLinkIcon] fetch error:', err)
            }["SecretLinkIcon.useEffect"]);
        }
    }["SecretLinkIcon.useEffect"], [
        studentId,
        unitId
    ]);
    const handleClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SecretLinkIcon.useCallback[handleClick]": async (egg)=>{
            if (!studentId || discoveredRef.current.has(egg.id)) return;
            discoveredRef.current.add(egg.id);
            setToast({
                open: true,
                message: egg.message,
                xpReward: egg.xpReward
            });
            setEggs({
                "SecretLinkIcon.useCallback[handleClick]": (prev)=>prev.filter({
                        "SecretLinkIcon.useCallback[handleClick]": (e_2)=>e_2.id !== egg.id
                    }["SecretLinkIcon.useCallback[handleClick]"])
            }["SecretLinkIcon.useCallback[handleClick]"]);
            try {
                await client.mutations?.discoverEasterEgg?.({
                    studentId,
                    eggId: egg.id
                });
            } catch (err_0) {
                console.error('[SecretLinkIcon] discoverEasterEgg error:', err_0);
            }
        }
    }["SecretLinkIcon.useCallback[handleClick]"], [
        studentId
    ]);
    if (eggs.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            eggs.map((egg_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    onClick: ()=>handleClick(egg_0),
                    size: "small",
                    sx: {
                        position: 'fixed',
                        bottom: 16,
                        right: 16,
                        opacity: 0.15,
                        transition: 'opacity 0.3s',
                        '&:hover': {
                            opacity: 0.8
                        },
                        zIndex: 10
                    },
                    "aria-label": "hidden secret",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        fontSize: "small"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/SecretLinkIcon.tsx",
                        lineNumber: 92,
                        columnNumber: 11
                    }, this)
                }, egg_0.id, false, {
                    fileName: "[project]/src/components/Gamification/SecretLinkIcon.tsx",
                    lineNumber: 81,
                    columnNumber: 26
                }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EasterEggToast"], {
                open: toast.open,
                message: toast.message,
                xpReward: toast.xpReward,
                onClose: ()=>setToast((t)=>({
                            ...t,
                            open: false
                        }))
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/SecretLinkIcon.tsx",
                lineNumber: 94,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(SecretLinkIcon, "Zmwu9odnILp1wFHR5yVF3yMeI68=");
_c = SecretLinkIcon;
var _c;
__turbopack_context__.k.register(_c, "SecretLinkIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useChatPageContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useChatPageContext",
    ()=>useChatPageContext
]);
/**
 * useChatPageContext - Register page-specific context with ChatContext
 * 
 * This hook allows pages to register their available context (unit, files, sections, etc.)
 * with the global ChatContext, making that context available to the chat sidebar.
 * 
 * @example
 * // In Unit Editor page
 * function UnitEditorPage() {
 *   const { unit, files, dictionary, questions } = useContext(UnitContext);
 *   const { sections } = useContext(SectionContext);
 *   const { vectorStoreSearch } = useContext(VectorStoreContext);
 *   const editorRef = useRef(null);
 *   
 *   useChatPageContext({
 *     unit,
 *     files,
 *     dictionary,
 *     questions,
 *     sections,
 *     editorRef,
 *     vectorStoreSearch,
 *   });
 *   
 *   return <...>
 * }
 * 
 * @see docs/GLOBAL_CHAT_INTEGRATION_PLAN.md
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/chatContext.jsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useChatPageContext(context = {}) {
    _s();
    const { setPageContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { unit = null, files = [], dictionary = [], questions = [], sections = [], editorRef = null, vectorStoreSearch = null } = context;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChatPageContext.useEffect": ()=>{
            console.log('[useChatPageContext] Registering page context:', {
                hasUnit: !!unit,
                filesCount: files?.length || 0,
                dictionaryCount: dictionary?.length || 0,
                questionsCount: questions?.length || 0,
                sectionsCount: sections?.length || 0,
                hasEditorRef: !!editorRef,
                hasVectorStoreSearch: !!vectorStoreSearch
            });
            setPageContext({
                unit,
                files,
                dictionary,
                questions,
                sections,
                editorRef,
                vectorStoreSearch
            });
            // Cleanup: reset to empty context when component unmounts
            return ({
                "useChatPageContext.useEffect": ()=>{
                    console.log('[useChatPageContext] Cleaning up page context');
                    setPageContext({
                        unit: null,
                        files: [],
                        dictionary: [],
                        questions: [],
                        sections: [],
                        editorRef: null,
                        vectorStoreSearch: null
                    });
                }
            })["useChatPageContext.useEffect"];
        }
    }["useChatPageContext.useEffect"], [
        // Dependencies - update when any context changes
        unit?.id,
        files?.length,
        dictionary?.length,
        questions?.length,
        sections?.length,
        editorRef?.current,
        vectorStoreSearch,
        setPageContext
    ]);
}
_s(useChatPageContext, "0aGcDEhsgvDsw4KhinDnLq0Ig9M=");
const __TURBOPACK__default__export__ = useChatPageContext;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/yjs/ChatCollaborationProvider.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * ChatCollaborationProvider — Specialized Yjs provider for collaborative chat rooms.
 *
 * Supports two room types:
 * - Section chat (`chat-section-{sectionId}`) — shared by all section members,
 *   with topics scoped to section/unit/workbook contexts
 * - Squad chat (`chat-squad-{squadId}`) — squad members only
 *
 * Y.Doc structure:
 * - `meta` Y.Map — room metadata (name, type, createdAt)
 * - `topics` Y.Map — topic objects keyed by topicId
 * - `threads` Y.Map — each key is a topicId, value references a Y.Array of messages
 * - Awareness — online/typing presence
 *
 * @module ChatCollaborationProvider
 */ __turbopack_context__.s([
    "ChatCollaborationProvider",
    ()=>ChatCollaborationProvider,
    "extractMentions",
    ()=>extractMentions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/YjsProvider.ts [app-client] (ecmascript)");
;
class ChatCollaborationProvider extends __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YjsDocProvider"] {
    roomType;
    roomId;
    user;
    metaMap;
    topicsMap;
    constructor(config){
        const docName = `chat-${config.roomType}-${config.roomId}`;
        super({
            ...config,
            docName
        });
        this.roomType = config.roomType;
        this.roomId = config.roomId;
        this.user = config.user;
        this.metaMap = this.getMap("meta");
        this.topicsMap = this.getMap("topics");
        this.initializeAwareness();
    }
    // ========================================================================
    // Awareness
    // ========================================================================
    initializeAwareness() {
        const awareness = this.getAwareness();
        awareness.setLocalState({
            user: this.user,
            typing: false,
            activeTopic: null
        });
    }
    setTyping(typing) {
        const awareness = this.getAwareness();
        const currentState = awareness.getLocalState();
        awareness.setLocalState({
            ...currentState,
            typing
        });
    }
    setActiveTopic(topicId) {
        const awareness = this.getAwareness();
        const currentState = awareness.getLocalState();
        awareness.setLocalState({
            ...currentState,
            activeTopic: topicId
        });
    }
    // ========================================================================
    // Room Meta
    // ========================================================================
    initializeRoom(name) {
        if (this.metaMap.get("createdAt")) return; // Already initialized
        this.metaMap.set("name", name);
        this.metaMap.set("roomType", this.roomType);
        this.metaMap.set("roomId", this.roomId);
        this.metaMap.set("createdAt", new Date().toISOString());
    }
    getRoomMeta() {
        return {
            name: this.metaMap.get("name") || "",
            roomType: this.metaMap.get("roomType") || this.roomType,
            roomId: this.metaMap.get("roomId") || this.roomId,
            createdAt: this.metaMap.get("createdAt") || ""
        };
    }
    // ========================================================================
    // Topics
    // ========================================================================
    createTopic(name, scope) {
        const topic = {
            id: crypto.randomUUID(),
            name: name.startsWith("#") ? name : `#${name}`,
            scope,
            createdBy: this.user.username,
            createdByName: this.user.displayName,
            createdAt: new Date().toISOString(),
            pinned: false,
            archived: false
        };
        this.topicsMap.set(topic.id, topic);
        // Initialize the thread array for this topic
        this.getDoc().getArray(`thread-${topic.id}`);
        return topic;
    }
    getTopic(topicId) {
        return this.topicsMap.get(topicId) || null;
    }
    getTopics() {
        const topics = [];
        this.topicsMap.forEach((value)=>{
            if (value && !value.archived) {
                topics.push(value);
            }
        });
        return topics;
    }
    getTopicsByScope(scope) {
        return this.getTopics().filter((t)=>t.scope === scope);
    }
    pinTopic(topicId, pinned) {
        const topic = this.topicsMap.get(topicId);
        if (topic) {
            this.topicsMap.set(topicId, {
                ...topic,
                pinned
            });
        }
    }
    archiveTopic(topicId) {
        const topic = this.topicsMap.get(topicId);
        if (topic) {
            this.topicsMap.set(topicId, {
                ...topic,
                archived: true
            });
        }
    }
    // ========================================================================
    // Messages / Threads
    // ========================================================================
    getThreadArray(topicId) {
        return this.getDoc().getArray(`thread-${topicId}`);
    }
    sendMessage(topicId, content, parentId) {
        const mentions = extractMentions(content);
        const message = {
            id: crypto.randomUUID(),
            parentId: parentId || null,
            authorId: this.user.username,
            authorName: this.user.displayName,
            content,
            contentJson: null,
            mentions,
            createdAt: new Date().toISOString(),
            editedAt: null,
            reactions: {},
            isStreaming: false
        };
        const threadArray = this.getThreadArray(topicId);
        threadArray.push([
            message
        ]);
        return message;
    }
    editMessage(topicId, messageId, newContent, contentJson) {
        const threadArray = this.getThreadArray(topicId);
        const items = Array.from(threadArray);
        const index = items.findIndex((m)=>m.id === messageId);
        if (index === -1) return;
        if (items[index].authorId !== this.user.username) return; // Can only edit own messages
        const updated = {
            ...items[index],
            content: newContent,
            contentJson: contentJson ?? items[index].contentJson,
            mentions: extractMentions(newContent),
            editedAt: new Date().toISOString()
        };
        this.getDoc().transact(()=>{
            threadArray.delete(index, 1);
            threadArray.insert(index, [
                updated
            ]);
        });
    }
    deleteMessage(topicId, messageId) {
        const threadArray = this.getThreadArray(topicId);
        const items = Array.from(threadArray);
        const index = items.findIndex((m)=>m.id === messageId);
        if (index === -1) return;
        if (items[index].authorId !== this.user.username) return; // Can only delete own messages
        threadArray.delete(index, 1);
    }
    addReaction(topicId, messageId, emoji) {
        const threadArray = this.getThreadArray(topicId);
        const items = Array.from(threadArray);
        const index = items.findIndex((m)=>m.id === messageId);
        if (index === -1) return;
        const message = items[index];
        const reactions = {
            ...message.reactions
        };
        const users = reactions[emoji] || [];
        if (users.includes(this.user.username)) {
            // Remove reaction
            reactions[emoji] = users.filter((u)=>u !== this.user.username);
            if (reactions[emoji].length === 0) delete reactions[emoji];
        } else {
            // Add reaction
            reactions[emoji] = [
                ...users,
                this.user.username
            ];
        }
        const updated = {
            ...message,
            reactions
        };
        this.getDoc().transact(()=>{
            threadArray.delete(index, 1);
            threadArray.insert(index, [
                updated
            ]);
        });
    }
    getMessages(topicId) {
        return Array.from(this.getThreadArray(topicId));
    }
    getThreadReplies(topicId, parentId) {
        return this.getMessages(topicId).filter((m)=>m.parentId === parentId);
    }
    getTopLevelMessages(topicId) {
        return this.getMessages(topicId).filter((m)=>m.parentId === null);
    }
    // ========================================================================
    // Accessors
    // ========================================================================
    getMetaMap() {
        return this.metaMap;
    }
    getTopicsMap() {
        return this.topicsMap;
    }
    getRoomId() {
        return this.roomId;
    }
    getRoomType() {
        return this.roomType;
    }
    getUser() {
        return this.user;
    }
}
function extractMentions(content) {
    const mentions = [];
    // Match @kai
    const kaiMatch = content.match(/@kai\b/gi);
    if (kaiMatch) mentions.push("@kai");
    // Match @"Name With Spaces" or @username
    const userMatches = content.matchAll(/@"([^"]+)"|@(\w+)/g);
    for (const match of userMatches){
        const name = match[1] || match[2];
        if (name.toLowerCase() !== "kai") {
            mentions.push(`@${name}`);
        }
    }
    return [
        ...new Set(mentions)
    ];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/yjs/chatHooks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useChatPresence",
    ()=>useChatPresence,
    "useChatRoom",
    ()=>useChatRoom,
    "useChatThread",
    ()=>useChatThread,
    "useChatTopics",
    ()=>useChatTopics
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * React hooks for collaborative chat rooms.
 *
 * Provides reactive state bindings for topics, threads, messages,
 * and presence from a ChatCollaborationProvider.
 *
 * @module chatHooks
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$ChatCollaborationProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/ChatCollaborationProvider.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
;
;
;
function useChatRoom(options) {
    _s();
    const { roomType, roomId, user, wsUrl, connect = true, persistence = true } = options || {};
    const providerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isConnected, setIsConnected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isSynced, setIsSynced] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChatRoom.useEffect": ()=>{
            if (!options || !roomId || !user?.username) return;
            const provider = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$ChatCollaborationProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChatCollaborationProvider"]({
                roomType,
                roomId,
                user,
                wsUrl,
                connect,
                persistence
            });
            providerRef.current = provider;
            // Track connection & sync status
            const wsProvider = provider.wsProvider;
            if (wsProvider) {
                wsProvider.on("status", {
                    "useChatRoom.useEffect": ({ status })=>{
                        setIsConnected(status === "connected");
                    }
                }["useChatRoom.useEffect"]);
                wsProvider.on("sync", {
                    "useChatRoom.useEffect": (synced)=>{
                        setIsSynced(synced);
                    }
                }["useChatRoom.useEffect"]);
            }
            return ({
                "useChatRoom.useEffect": ()=>{
                    provider.destroy();
                    providerRef.current = null;
                    setIsConnected(false);
                    setIsSynced(false);
                }
            })["useChatRoom.useEffect"];
        }
    }["useChatRoom.useEffect"], [
        roomType,
        roomId,
        user?.username
    ]);
    return {
        provider: providerRef.current,
        isConnected,
        isSynced
    };
}
_s(useChatRoom, "9tDjhjCOhEc5S8IFYrLfDcYxPb8=");
function useChatTopics(provider, scope) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [topics, setTopics] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== provider || $[3] !== scope) {
        t1 = ({
            "useChatTopics[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const topicsMap = provider.getTopicsMap();
                const handleChange = {
                    "useChatTopics[useEffect() > handleChange]": ()=>{
                        const allTopics = provider.getTopics();
                        if (scope) {
                            setTopics(allTopics.filter({
                                "useChatTopics[useEffect() > handleChange > allTopics.filter()]": (t)=>t.scope === "section" || t.scope === scope
                            }["useChatTopics[useEffect() > handleChange > allTopics.filter()]"]));
                        } else {
                            setTopics(allTopics);
                        }
                    }
                }["useChatTopics[useEffect() > handleChange]"];
                handleChange();
                topicsMap.observeDeep(handleChange);
                return ()=>{
                    topicsMap.unobserveDeep(handleChange);
                };
            }
        })["useChatTopics[useEffect()]"];
        t2 = [
            provider,
            scope
        ];
        $[2] = provider;
        $[3] = scope;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[6] !== provider) {
        t3 = ({
            "useChatTopics[createTopic]": (name, topicScope)=>{
                if (!provider) {
                    return null;
                }
                return provider.createTopic(name, topicScope);
            }
        })["useChatTopics[createTopic]"];
        $[6] = provider;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    const createTopic = t3;
    let t4;
    if ($[8] !== provider) {
        t4 = ({
            "useChatTopics[pinTopic]": (topicId, pinned)=>{
                provider?.pinTopic(topicId, pinned);
            }
        })["useChatTopics[pinTopic]"];
        $[8] = provider;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    const pinTopic = t4;
    let t5;
    if ($[10] !== provider) {
        t5 = ({
            "useChatTopics[archiveTopic]": (topicId_0)=>{
                provider?.archiveTopic(topicId_0);
            }
        })["useChatTopics[archiveTopic]"];
        $[10] = provider;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    const archiveTopic = t5;
    let t6;
    if ($[12] !== archiveTopic || $[13] !== createTopic || $[14] !== pinTopic || $[15] !== topics) {
        t6 = {
            topics,
            createTopic,
            pinTopic,
            archiveTopic
        };
        $[12] = archiveTopic;
        $[13] = createTopic;
        $[14] = pinTopic;
        $[15] = topics;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    return t6;
}
_s1(useChatTopics, "Z4rPjMfp4RLx3ToDgpfq685D3kI=");
function useChatThread(provider, topicId) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(30);
    if ($[0] !== "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d") {
        for(let $i = 0; $i < 30; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== provider || $[3] !== topicId) {
        t1 = ({
            "useChatThread[useEffect()]": ()=>{
                if (!provider || !topicId) {
                    setMessages([]);
                    return;
                }
                const threadArray = provider.getThreadArray(topicId);
                const handleChange = {
                    "useChatThread[useEffect() > handleChange]": ()=>{
                        setMessages(Array.from(threadArray));
                    }
                }["useChatThread[useEffect() > handleChange]"];
                handleChange();
                threadArray.observe(handleChange);
                provider.setActiveTopic(topicId);
                return ()=>{
                    threadArray.unobserve(handleChange);
                    provider.setActiveTopic(null);
                };
            }
        })["useChatThread[useEffect()]"];
        t2 = [
            provider,
            topicId
        ];
        $[2] = provider;
        $[3] = topicId;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[6] !== messages) {
        t3 = messages.filter(_useChatThreadMessagesFilter);
        $[6] = messages;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    const topLevelMessages = t3;
    let t4;
    if ($[8] !== provider || $[9] !== topicId) {
        t4 = ({
            "useChatThread[sendMessage]": (content, parentId)=>{
                if (!provider || !topicId) {
                    return null;
                }
                return provider.sendMessage(topicId, content, parentId);
            }
        })["useChatThread[sendMessage]"];
        $[8] = provider;
        $[9] = topicId;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    const sendMessage = t4;
    let t5;
    if ($[11] !== provider || $[12] !== topicId) {
        t5 = ({
            "useChatThread[editMessage]": (messageId, content_0, contentJson)=>{
                if (!provider || !topicId) {
                    return;
                }
                provider.editMessage(topicId, messageId, content_0, contentJson);
            }
        })["useChatThread[editMessage]"];
        $[11] = provider;
        $[12] = topicId;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    const editMessage = t5;
    let t6;
    if ($[14] !== provider || $[15] !== topicId) {
        t6 = ({
            "useChatThread[deleteMessage]": (messageId_0)=>{
                if (!provider || !topicId) {
                    return;
                }
                provider.deleteMessage(topicId, messageId_0);
            }
        })["useChatThread[deleteMessage]"];
        $[14] = provider;
        $[15] = topicId;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    const deleteMessage = t6;
    let t7;
    if ($[17] !== provider || $[18] !== topicId) {
        t7 = ({
            "useChatThread[addReaction]": (messageId_1, emoji)=>{
                if (!provider || !topicId) {
                    return;
                }
                provider.addReaction(topicId, messageId_1, emoji);
            }
        })["useChatThread[addReaction]"];
        $[17] = provider;
        $[18] = topicId;
        $[19] = t7;
    } else {
        t7 = $[19];
    }
    const addReaction = t7;
    let t8;
    if ($[20] !== messages) {
        t8 = ({
            "useChatThread[getReplies]": (parentId_0)=>messages.filter({
                    "useChatThread[getReplies > messages.filter()]": (m_0)=>m_0.parentId === parentId_0
                }["useChatThread[getReplies > messages.filter()]"])
        })["useChatThread[getReplies]"];
        $[20] = messages;
        $[21] = t8;
    } else {
        t8 = $[21];
    }
    const getReplies = t8;
    let t9;
    if ($[22] !== addReaction || $[23] !== deleteMessage || $[24] !== editMessage || $[25] !== getReplies || $[26] !== messages || $[27] !== sendMessage || $[28] !== topLevelMessages) {
        t9 = {
            messages,
            topLevelMessages,
            sendMessage,
            editMessage,
            deleteMessage,
            addReaction,
            getReplies
        };
        $[22] = addReaction;
        $[23] = deleteMessage;
        $[24] = editMessage;
        $[25] = getReplies;
        $[26] = messages;
        $[27] = sendMessage;
        $[28] = topLevelMessages;
        $[29] = t9;
    } else {
        t9 = $[29];
    }
    return t9;
}
_s2(useChatThread, "dMiLn6t5LC6b/+LW9v6mSM5lssk=");
/**
 * Hook for chat room presence — online users, typing indicators, active topics.
 */ function _useChatThreadMessagesFilter(m) {
    return m.parentId === null;
}
function useChatPresence(provider, topicId) {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5d0c11de75449e8c8c99d499a71e8dffd0029841f5c4b0d59de7e1306d6b272d";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [onlineUsers, setOnlineUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [typingUsers, setTypingUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const [usersInTopic, setUsersInTopic] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    let t4;
    if ($[4] !== provider || $[5] !== topicId) {
        t3 = ({
            "useChatPresence[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const awareness = provider.getAwareness();
                const handleChange = {
                    "useChatPresence[useEffect() > handleChange]": ()=>{
                        const online = [];
                        const typing = [];
                        const inTopic = [];
                        awareness.getStates().forEach({
                            "useChatPresence[useEffect() > handleChange > (anonymous)()]": (state, clientId)=>{
                                if (clientId === awareness.clientID) {
                                    return;
                                }
                                const peerUser = state.user;
                                if (!peerUser) {
                                    return;
                                }
                                online.push(peerUser);
                                if (state.typing) {
                                    typing.push(peerUser);
                                }
                                if (topicId && state.activeTopic === topicId) {
                                    inTopic.push(peerUser);
                                }
                            }
                        }["useChatPresence[useEffect() > handleChange > (anonymous)()]"]);
                        setOnlineUsers(online);
                        setTypingUsers(typing);
                        setUsersInTopic(inTopic);
                    }
                }["useChatPresence[useEffect() > handleChange]"];
                handleChange();
                awareness.on("change", handleChange);
                return ()=>{
                    awareness.off("change", handleChange);
                };
            }
        })["useChatPresence[useEffect()]"];
        t4 = [
            provider,
            topicId
        ];
        $[4] = provider;
        $[5] = topicId;
        $[6] = t3;
        $[7] = t4;
    } else {
        t3 = $[6];
        t4 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    let t5;
    if ($[8] !== onlineUsers || $[9] !== typingUsers || $[10] !== usersInTopic) {
        t5 = {
            onlineUsers,
            typingUsers,
            usersInTopic
        };
        $[8] = onlineUsers;
        $[9] = typingUsers;
        $[10] = usersInTopic;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    return t5;
}
_s3(useChatPresence, "895iuv1s1S0fDfDisjcEyQGP4Dc=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/TopicList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TopicList",
    ()=>TopicList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * TopicList — Displays #topics with create, pin, and archive actions.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemButton/ListItemButton.js [app-client] (ecmascript) <export default as ListItemButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Add.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PushPin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PushPin.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function TopicList(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(45);
    if ($[0] !== "b0a3d6662286d90f8c1e1a25fb35dc8c769e23666b7b4ad2466c97a831eaab3a") {
        for(let $i = 0; $i < 45; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b0a3d6662286d90f8c1e1a25fb35dc8c769e23666b7b4ad2466c97a831eaab3a";
    }
    const { topics, activeTopicId, onSelectTopic, onCreateTopic, onPinTopic } = t0;
    const [showInput, setShowInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [newTopicName, setNewTopicName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let T0;
    let T1;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    if ($[1] !== activeTopicId || $[2] !== newTopicName || $[3] !== onCreateTopic || $[4] !== onPinTopic || $[5] !== onSelectTopic || $[6] !== showInput || $[7] !== topics) {
        const sortedTopics = [
            ...topics
        ].sort(_TopicListAnonymous);
        let t8;
        if ($[17] !== newTopicName || $[18] !== onCreateTopic) {
            const handleCreate = {
                "TopicList[handleCreate]": ()=>{
                    const name = newTopicName.trim();
                    if (!name) {
                        return;
                    }
                    onCreateTopic(name);
                    setNewTopicName("");
                    setShowInput(false);
                }
            }["TopicList[handleCreate]"];
            t8 = ({
                "TopicList[handleKeyDown]": (e)=>{
                    if (e.key === "Enter") {
                        e.preventDefault();
                        handleCreate();
                    }
                    if (e.key === "Escape") {
                        setShowInput(false);
                        setNewTopicName("");
                    }
                }
            })["TopicList[handleKeyDown]"];
            $[17] = newTopicName;
            $[18] = onCreateTopic;
            $[19] = t8;
        } else {
            t8 = $[19];
        }
        const handleKeyDown = t8;
        T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"];
        if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = {
                display: "flex",
                flexDirection: "column",
                height: "100%"
            };
            $[20] = t5;
        } else {
            t5 = $[20];
        }
        let t10;
        let t9;
        if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = {
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                p: 1,
                px: 2
            };
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "subtitle2",
                color: "text.secondary",
                children: "Topics"
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/TopicList.tsx",
                lineNumber: 111,
                columnNumber: 13
            }, this);
            $[21] = t10;
            $[22] = t9;
        } else {
            t10 = $[21];
            t9 = $[22];
        }
        if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t9,
                children: [
                    t10,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                        size: "small",
                        onClick: {
                            "TopicList[<IconButton>.onClick]": ()=>setShowInput(true)
                        }["TopicList[<IconButton>.onClick]"],
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            fontSize: "small"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Chat/TopicList.tsx",
                            lineNumber: 121,
                            columnNumber: 47
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/TopicList.tsx",
                        lineNumber: 119,
                        columnNumber: 30
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Chat/TopicList.tsx",
                lineNumber: 119,
                columnNumber: 12
            }, this);
            $[23] = t6;
        } else {
            t6 = $[23];
        }
        if ($[24] !== handleKeyDown || $[25] !== newTopicName || $[26] !== showInput) {
            t7 = showInput && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    px: 2,
                    pb: 1
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                    size: "small",
                    fullWidth: true,
                    autoFocus: true,
                    placeholder: "#new-topic",
                    value: newTopicName,
                    onChange: {
                        "TopicList[<TextField>.onChange]": (e_0)=>setNewTopicName(e_0.target.value)
                    }["TopicList[<TextField>.onChange]"],
                    onKeyDown: handleKeyDown,
                    onBlur: {
                        "TopicList[<TextField>.onBlur]": ()=>{
                            if (!newTopicName.trim()) {
                                setShowInput(false);
                            }
                        }
                    }["TopicList[<TextField>.onBlur]"],
                    slotProps: {
                        input: {
                            sx: {
                                fontSize: "0.875rem"
                            }
                        }
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/TopicList.tsx",
                    lineNumber: 130,
                    columnNumber: 10
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/TopicList.tsx",
                lineNumber: 127,
                columnNumber: 25
            }, this);
            $[24] = handleKeyDown;
            $[25] = newTopicName;
            $[26] = showInput;
            $[27] = t7;
        } else {
            t7 = $[27];
        }
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"];
        t1 = true;
        if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = {
                flex: 1,
                overflow: "auto",
                py: 0
            };
            $[28] = t2;
        } else {
            t2 = $[28];
        }
        t3 = sortedTopics.length === 0 && !showInput && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                secondary: "No topics yet. Create one to start chatting.",
                secondaryTypographyProps: {
                    variant: "caption"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/TopicList.tsx",
                lineNumber: 164,
                columnNumber: 63
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/TopicList.tsx",
            lineNumber: 164,
            columnNumber: 53
        }, this);
        let t11;
        if ($[29] !== activeTopicId || $[30] !== onPinTopic || $[31] !== onSelectTopic) {
            t11 = ({
                "TopicList[sortedTopics.map()]": (topic)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                        disablePadding: true,
                        secondaryAction: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                gap: 0
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                size: "small",
                                onClick: {
                                    "TopicList[sortedTopics.map() > <IconButton>.onClick]": (e_1)=>{
                                        e_1.stopPropagation();
                                        onPinTopic(topic.id, !topic.pinned);
                                    }
                                }["TopicList[sortedTopics.map() > <IconButton>.onClick]"],
                                sx: {
                                    opacity: topic.pinned ? 1 : 0.3
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PushPin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    sx: {
                                        fontSize: 14
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Chat/TopicList.tsx",
                                    lineNumber: 180,
                                    columnNumber: 14
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Chat/TopicList.tsx",
                                lineNumber: 173,
                                columnNumber: 12
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Chat/TopicList.tsx",
                            lineNumber: 170,
                            columnNumber: 115
                        }, this),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__["ListItemButton"], {
                            selected: topic.id === activeTopicId,
                            onClick: {
                                "TopicList[sortedTopics.map() > <ListItemButton>.onClick]": ()=>onSelectTopic(topic.id)
                            }["TopicList[sortedTopics.map() > <ListItemButton>.onClick]"],
                            sx: {
                                py: 0.5
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                primary: topic.name,
                                primaryTypographyProps: {
                                    variant: "body2",
                                    fontWeight: topic.pinned ? 600 : 400
                                },
                                secondary: topic.scope !== "section" && topic.scope !== "squad" ? topic.scope.split(":")[0] : undefined,
                                secondaryTypographyProps: {
                                    variant: "caption"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Chat/TopicList.tsx",
                                lineNumber: 186,
                                columnNumber: 14
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Chat/TopicList.tsx",
                            lineNumber: 182,
                            columnNumber: 39
                        }, this)
                    }, topic.id, false, {
                        fileName: "[project]/src/components/Chat/TopicList.tsx",
                        lineNumber: 170,
                        columnNumber: 51
                    }, this)
            })["TopicList[sortedTopics.map()]"];
            $[29] = activeTopicId;
            $[30] = onPinTopic;
            $[31] = onSelectTopic;
            $[32] = t11;
        } else {
            t11 = $[32];
        }
        t4 = sortedTopics.map(t11);
        $[1] = activeTopicId;
        $[2] = newTopicName;
        $[3] = onCreateTopic;
        $[4] = onPinTopic;
        $[5] = onSelectTopic;
        $[6] = showInput;
        $[7] = topics;
        $[8] = T0;
        $[9] = T1;
        $[10] = t1;
        $[11] = t2;
        $[12] = t3;
        $[13] = t4;
        $[14] = t5;
        $[15] = t6;
        $[16] = t7;
    } else {
        T0 = $[8];
        T1 = $[9];
        t1 = $[10];
        t2 = $[11];
        t3 = $[12];
        t4 = $[13];
        t5 = $[14];
        t6 = $[15];
        t7 = $[16];
    }
    let t8;
    if ($[33] !== T0 || $[34] !== t1 || $[35] !== t2 || $[36] !== t3 || $[37] !== t4) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            dense: t1,
            sx: t2,
            children: [
                t3,
                t4
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/TopicList.tsx",
            lineNumber: 230,
            columnNumber: 10
        }, this);
        $[33] = T0;
        $[34] = t1;
        $[35] = t2;
        $[36] = t3;
        $[37] = t4;
        $[38] = t8;
    } else {
        t8 = $[38];
    }
    let t9;
    if ($[39] !== T1 || $[40] !== t5 || $[41] !== t6 || $[42] !== t7 || $[43] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
            sx: t5,
            children: [
                t6,
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/TopicList.tsx",
            lineNumber: 242,
            columnNumber: 10
        }, this);
        $[39] = T1;
        $[40] = t5;
        $[41] = t6;
        $[42] = t7;
        $[43] = t8;
        $[44] = t9;
    } else {
        t9 = $[44];
    }
    return t9;
}
_s(TopicList, "mmq1Q2eQkPqFyTC+ARaFQpTg5jc=");
_c = TopicList;
function _TopicListAnonymous(a, b) {
    if (a.pinned && !b.pinned) {
        return -1;
    }
    if (!a.pinned && b.pinned) {
        return 1;
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
}
var _c;
__turbopack_context__.k.register(_c, "TopicList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/MentionChip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MentionChip",
    ()=>MentionChip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SmartToy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/SmartToy.js [app-client] (ecmascript)");
;
;
;
;
function MentionChip(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "6b9d16b42aedf19e54e20ac85c3e19dcd9a594e6c3902e9254c7f66935f15db1") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6b9d16b42aedf19e54e20ac85c3e19dcd9a594e6c3902e9254c7f66935f15db1";
    }
    const { name, onClick } = t0;
    let t1;
    if ($[1] !== name) {
        t1 = name.toLowerCase();
        $[1] = name;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const isBot = t1 === "kai";
    const t2 = `@${name}`;
    let t3;
    if ($[3] !== isBot) {
        t3 = isBot ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SmartToy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Chat/MentionChip.tsx",
            lineNumber: 37,
            columnNumber: 18
        }, this) : undefined;
        $[3] = isBot;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const t4 = isBot ? "secondary" : "primary";
    const t5 = !!onClick;
    const t6 = onClick ? "pointer" : "default";
    let t7;
    if ($[5] !== t6) {
        t7 = {
            height: 20,
            fontSize: "0.8rem",
            verticalAlign: "middle",
            mx: 0.25,
            cursor: t6
        };
        $[5] = t6;
        $[6] = t7;
    } else {
        t7 = $[6];
    }
    let t8;
    if ($[7] !== onClick || $[8] !== t2 || $[9] !== t3 || $[10] !== t4 || $[11] !== t5 || $[12] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            component: "span",
            label: t2,
            size: "small",
            icon: t3,
            color: t4,
            variant: "outlined",
            onClick: onClick,
            clickable: t5,
            sx: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/MentionChip.tsx",
            lineNumber: 62,
            columnNumber: 10
        }, this);
        $[7] = onClick;
        $[8] = t2;
        $[9] = t3;
        $[10] = t4;
        $[11] = t5;
        $[12] = t7;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    return t8;
}
_c = MentionChip;
var _c;
__turbopack_context__.k.register(_c, "MentionChip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/ThreadView.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThreadView",
    ()=>ThreadView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * ThreadView — Displays messages in a topic with threading support.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript) <export default as Avatar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Collapse/Collapse.js [app-client] (ecmascript) <export default as Collapse>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Reply$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Reply.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiEmotions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/EmojiEmotions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Edit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Delete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$MentionChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/MentionChip.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
function ThreadView(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(32);
    if ($[0] !== "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24") {
        for(let $i = 0; $i < 32; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24";
    }
    const { messages, getReplies, onReact, onEdit, onDelete, onReply, currentUser, typingUsers } = t0;
    const scrollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = new Set();
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const [expandedThreads, setExpandedThreads] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "ThreadView[useEffect()]": ()=>{
                if (scrollRef.current) {
                    scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
                }
            }
        })["ThreadView[useEffect()]"];
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== messages.length) {
        t3 = [
            messages.length
        ];
        $[3] = messages.length;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "ThreadView[toggleThread]": (messageId)=>{
                setExpandedThreads({
                    "ThreadView[toggleThread > setExpandedThreads()]": (prev)=>{
                        const next = new Set(prev);
                        if (next.has(messageId)) {
                            next.delete(messageId);
                        } else {
                            next.add(messageId);
                        }
                        return next;
                    }
                }["ThreadView[toggleThread > setExpandedThreads()]"]);
            }
        })["ThreadView[toggleThread]"];
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const toggleThread = t4;
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            flex: 1,
            overflow: "auto",
            p: 2,
            display: "flex",
            flexDirection: "column",
            gap: 1
        };
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] !== messages.length) {
        t6 = messages.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                textAlign: "center",
                py: 4,
                color: "text.secondary"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                children: "No messages yet. Start the conversation!"
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                lineNumber: 125,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 121,
            columnNumber: 35
        }, this);
        $[7] = messages.length;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] !== currentUser || $[10] !== expandedThreads || $[11] !== getReplies || $[12] !== messages || $[13] !== onDelete || $[14] !== onEdit || $[15] !== onReact || $[16] !== onReply) {
        let t8;
        if ($[18] !== currentUser || $[19] !== expandedThreads || $[20] !== getReplies || $[21] !== onDelete || $[22] !== onEdit || $[23] !== onReact || $[24] !== onReply) {
            t8 = ({
                "ThreadView[messages.map()]": (message)=>{
                    const replies = getReplies(message.id);
                    const isExpanded = expandedThreads.has(message.id);
                    const isOwn = message.authorId === currentUser.username;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MessageBubble, {
                                message: message,
                                isOwn: isOwn,
                                replyCount: replies.length,
                                onToggleReplies: {
                                    "ThreadView[messages.map() > <MessageBubble>.onToggleReplies]": ()=>toggleThread(message.id)
                                }["ThreadView[messages.map() > <MessageBubble>.onToggleReplies]"],
                                onReact: onReact,
                                onEdit: isOwn ? onEdit : undefined,
                                onDelete: isOwn ? onDelete : undefined,
                                onReply: onReply
                            }, void 0, false, {
                                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                                lineNumber: 140,
                                columnNumber: 40
                            }, this),
                            replies.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__["Collapse"], {
                                in: isExpanded,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        ml: 4,
                                        borderLeft: 2,
                                        borderColor: "divider",
                                        pl: 1
                                    },
                                    children: replies.map({
                                        "ThreadView[messages.map() > replies.map()]": (reply)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MessageBubble, {
                                                message: reply,
                                                isOwn: reply.authorId === currentUser.username,
                                                onReact: onReact,
                                                onEdit: reply.authorId === currentUser.username ? onEdit : undefined,
                                                onDelete: reply.authorId === currentUser.username ? onDelete : undefined,
                                                compact: true
                                            }, reply.id, false, {
                                                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                                                lineNumber: 148,
                                                columnNumber: 74
                                            }, this)
                                    }["ThreadView[messages.map() > replies.map()]"])
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                                    lineNumber: 142,
                                    columnNumber: 243
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                                lineNumber: 142,
                                columnNumber: 217
                            }, this)
                        ]
                    }, message.id, true, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 140,
                        columnNumber: 18
                    }, this);
                }
            })["ThreadView[messages.map()]"];
            $[18] = currentUser;
            $[19] = expandedThreads;
            $[20] = getReplies;
            $[21] = onDelete;
            $[22] = onEdit;
            $[23] = onReact;
            $[24] = onReply;
            $[25] = t8;
        } else {
            t8 = $[25];
        }
        t7 = messages.map(t8);
        $[9] = currentUser;
        $[10] = expandedThreads;
        $[11] = getReplies;
        $[12] = messages;
        $[13] = onDelete;
        $[14] = onEdit;
        $[15] = onReact;
        $[16] = onReply;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    let t8;
    if ($[26] !== typingUsers) {
        t8 = typingUsers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                alignItems: "center",
                gap: 1,
                opacity: 0.6
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "caption",
                children: [
                    typingUsers.map(_ThreadViewTypingUsersMap).join(", "),
                    " ",
                    typingUsers.length === 1 ? "is" : "are",
                    " typing..."
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                lineNumber: 183,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 178,
            columnNumber: 36
        }, this);
        $[26] = typingUsers;
        $[27] = t8;
    } else {
        t8 = $[27];
    }
    let t9;
    if ($[28] !== t6 || $[29] !== t7 || $[30] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            ref: scrollRef,
            sx: t5,
            children: [
                t6,
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 191,
            columnNumber: 10
        }, this);
        $[28] = t6;
        $[29] = t7;
        $[30] = t8;
        $[31] = t9;
    } else {
        t9 = $[31];
    }
    return t9;
}
_s(ThreadView, "v4/PpG8f9+o+Jom7TeNotUZVLRs=");
_c = ThreadView;
// ============================================================================
// MessageBubble (internal)
// ============================================================================
function _ThreadViewTypingUsersMap(u) {
    return u.displayName;
}
function MessageBubble(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(47);
    if ($[0] !== "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24") {
        for(let $i = 0; $i < 47; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24";
    }
    const { message, replyCount: t1, onToggleReplies, onReact, onEdit, onDelete, onReply, compact: t2 } = t0;
    const replyCount = t1 === undefined ? 0 : t1;
    const compact = t2 === undefined ? false : t2;
    const [hovered, setHovered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t3;
    if ($[1] !== message.authorName) {
        t3 = message.authorName.split(" ").map(_MessageBubbleAnonymous).join("").slice(0, 2).toUpperCase();
        $[1] = message.authorName;
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    const initials = t3;
    const isBot = message.authorId === "kai-bot";
    let t4;
    let t5;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "MessageBubble[<Box>.onMouseEnter]": ()=>setHovered(true)
        })["MessageBubble[<Box>.onMouseEnter]"];
        t5 = ({
            "MessageBubble[<Box>.onMouseLeave]": ()=>setHovered(false)
        })["MessageBubble[<Box>.onMouseLeave]"];
        $[3] = t4;
        $[4] = t5;
    } else {
        t4 = $[3];
        t5 = $[4];
    }
    const t6 = compact ? 0.5 : 1;
    let t7;
    if ($[5] !== t6) {
        t7 = {
            display: "flex",
            gap: 1,
            py: t6,
            alignItems: "flex-start",
            position: "relative"
        };
        $[5] = t6;
        $[6] = t7;
    } else {
        t7 = $[6];
    }
    let t8;
    if ($[7] !== compact || $[8] !== initials || $[9] !== isBot) {
        t8 = !compact && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__["Avatar"], {
            sx: {
                width: 32,
                height: 32,
                fontSize: "0.75rem",
                bgcolor: isBot ? "secondary.main" : "primary.main"
            },
            children: isBot ? "\uD83E\uDD16" : initials
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 282,
            columnNumber: 22
        }, this);
        $[7] = compact;
        $[8] = initials;
        $[9] = isBot;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            flex: 1,
            minWidth: 0
        };
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    let t10;
    if ($[12] !== compact || $[13] !== isBot || $[14] !== message.authorName || $[15] !== message.createdAt || $[16] !== message.editedAt) {
        t10 = !compact && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                alignItems: "baseline",
                gap: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "subtitle2",
                    component: "span",
                    children: [
                        message.authorName,
                        isBot && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                            label: "AI",
                            size: "small",
                            color: "secondary",
                            sx: {
                                ml: 0.5,
                                height: 18
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Chat/ThreadView.tsx",
                            lineNumber: 311,
                            columnNumber: 87
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 311,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "caption",
                    color: "text.secondary",
                    children: [
                        formatTime(message.createdAt),
                        message.editedAt && " (edited)"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 314,
                    columnNumber: 28
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 307,
            columnNumber: 23
        }, this);
        $[12] = compact;
        $[13] = isBot;
        $[14] = message.authorName;
        $[15] = message.createdAt;
        $[16] = message.editedAt;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            whiteSpace: "pre-wrap",
            wordBreak: "break-word"
        };
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] !== message.content) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            sx: t11,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RenderContent, {
                content: message.content
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                lineNumber: 336,
                columnNumber: 48
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 336,
            columnNumber: 11
        }, this);
        $[19] = message.content;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] !== message.id || $[22] !== message.reactions || $[23] !== onReact) {
        t13 = Object.keys(message.reactions).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                gap: 0.5,
                mt: 0.5,
                flexWrap: "wrap"
            },
            children: Object.entries(message.reactions).map({
                "MessageBubble[(anonymous)()]": (t14)=>{
                    const [emoji, users] = t14;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                        label: `${emoji} ${users.length}`,
                        size: "small",
                        variant: "outlined",
                        onClick: {
                            "MessageBubble[(anonymous)() > <Chip>.onClick]": ()=>onReact(message.id, emoji)
                        }["MessageBubble[(anonymous)() > <Chip>.onClick]"],
                        sx: {
                            height: 22,
                            fontSize: "0.75rem"
                        }
                    }, emoji, false, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 352,
                        columnNumber: 18
                    }, this);
                }
            }["MessageBubble[(anonymous)()]"])
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 344,
            columnNumber: 56
        }, this);
        $[21] = message.id;
        $[22] = message.reactions;
        $[23] = onReact;
        $[24] = t13;
    } else {
        t13 = $[24];
    }
    let t14;
    if ($[25] !== onToggleReplies || $[26] !== replyCount) {
        t14 = replyCount > 0 && onToggleReplies && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "primary",
            sx: {
                cursor: "pointer",
                mt: 0.5,
                display: "block"
            },
            onClick: onToggleReplies,
            children: [
                replyCount,
                " ",
                replyCount === 1 ? "reply" : "replies"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 369,
            columnNumber: 48
        }, this);
        $[25] = onToggleReplies;
        $[26] = replyCount;
        $[27] = t14;
    } else {
        t14 = $[27];
    }
    let t15;
    if ($[28] !== t10 || $[29] !== t12 || $[30] !== t13 || $[31] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t9,
            children: [
                t10,
                t12,
                t13,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 382,
            columnNumber: 11
        }, this);
        $[28] = t10;
        $[29] = t12;
        $[30] = t13;
        $[31] = t14;
        $[32] = t15;
    } else {
        t15 = $[32];
    }
    let t16;
    if ($[33] !== hovered || $[34] !== message.content || $[35] !== message.id || $[36] !== message.parentId || $[37] !== onDelete || $[38] !== onEdit || $[39] !== onReact || $[40] !== onReply) {
        t16 = hovered && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                position: "absolute",
                top: 0,
                right: 0,
                display: "flex",
                bgcolor: "background.paper",
                borderRadius: 1,
                boxShadow: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                    size: "small",
                    onClick: {
                        "MessageBubble[<IconButton>.onClick]": ()=>onReact(message.id, "\uD83D\uDC4D")
                    }["MessageBubble[<IconButton>.onClick]"],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiEmotions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 16
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 403,
                        columnNumber: 49
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 401,
                    columnNumber: 8
                }, this),
                onReply && !message.parentId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                    size: "small",
                    onClick: {
                        "MessageBubble[<IconButton>.onClick]": ()=>onReply(message.id)
                    }["MessageBubble[<IconButton>.onClick]"],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Reply$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 16
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 407,
                        columnNumber: 49
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 405,
                    columnNumber: 60
                }, this),
                onEdit && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                    size: "small",
                    onClick: {
                        "MessageBubble[<IconButton>.onClick]": ()=>onEdit(message.id, message.content)
                    }["MessageBubble[<IconButton>.onClick]"],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 16
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 411,
                        columnNumber: 49
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 409,
                    columnNumber: 39
                }, this),
                onDelete && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                    size: "small",
                    onClick: {
                        "MessageBubble[<IconButton>.onClick]": ()=>onDelete(message.id)
                    }["MessageBubble[<IconButton>.onClick]"],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 16
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/ThreadView.tsx",
                        lineNumber: 415,
                        columnNumber: 49
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ThreadView.tsx",
                    lineNumber: 413,
                    columnNumber: 41
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 393,
            columnNumber: 22
        }, this);
        $[33] = hovered;
        $[34] = message.content;
        $[35] = message.id;
        $[36] = message.parentId;
        $[37] = onDelete;
        $[38] = onEdit;
        $[39] = onReact;
        $[40] = onReply;
        $[41] = t16;
    } else {
        t16 = $[41];
    }
    let t17;
    if ($[42] !== t15 || $[43] !== t16 || $[44] !== t7 || $[45] !== t8) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            onMouseEnter: t4,
            onMouseLeave: t5,
            sx: t7,
            children: [
                t8,
                t15,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ThreadView.tsx",
            lineNumber: 432,
            columnNumber: 11
        }, this);
        $[42] = t15;
        $[43] = t16;
        $[44] = t7;
        $[45] = t8;
        $[46] = t17;
    } else {
        t17 = $[46];
    }
    return t17;
}
_s1(MessageBubble, "V8YbV+gTZxGliGj1g0fftBlvsq4=");
_c1 = MessageBubble;
// ============================================================================
// Helpers
// ============================================================================
function _MessageBubbleAnonymous(n) {
    return n[0];
}
function RenderContent(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e77ca853f7ef0f34e57923d3cbcc967f6951e842ec0f58a5f995305aeebeda24";
    }
    const { content } = t0;
    let t1;
    if ($[1] !== content) {
        const parts = [];
        let t2;
        if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = /@"([^"]+)"|@(\w[\w.-]*)/g;
            $[3] = t2;
        } else {
            t2 = $[3];
        }
        const mentionRegex = t2;
        let lastIndex = 0;
        let match;
        mentionRegex.lastIndex = 0;
        while((match = mentionRegex.exec(content)) !== null){
            if (match.index > lastIndex) {
                parts.push(content.slice(lastIndex, match.index));
            }
            const name = match[1] || match[2];
            parts.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$MentionChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MentionChip"], {
                name: name
            }, match.index, false, {
                fileName: "[project]/src/components/Chat/ThreadView.tsx",
                lineNumber: 480,
                columnNumber: 18
            }, this));
            lastIndex = match.index + match[0].length;
        }
        if (lastIndex < content.length) {
            let t3;
            if ($[4] !== content || $[5] !== lastIndex) {
                t3 = content.slice(lastIndex);
                $[4] = content;
                $[5] = lastIndex;
                $[6] = t3;
            } else {
                t3 = $[6];
            }
            parts.push(t3);
        }
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: parts
        }, void 0, false);
        $[1] = content;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    return t1;
}
_c2 = RenderContent;
function formatTime(isoString) {
    try {
        const date = new Date(isoString);
        const now = new Date();
        const diffMs = now.getTime() - date.getTime();
        const diffMins = Math.floor(diffMs / 60000);
        if (diffMins < 1) return 'just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        const diffHours = Math.floor(diffMins / 60);
        if (diffHours < 24) return `${diffHours}h ago`;
        return date.toLocaleDateString(undefined, {
            month: 'short',
            day: 'numeric'
        });
    } catch  {
        return '';
    }
}
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ThreadView");
__turbopack_context__.k.register(_c1, "MessageBubble");
__turbopack_context__.k.register(_c2, "RenderContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/chatMentions.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Chat mention parsing and resolution utilities.
 *
 * Handles:
 * - @kai — AI bot trigger
 * - @"Display Name" — user with spaces in name
 * - @username — simple user mention
 * - #topic — topic reference (for auto-linking)
 *
 * @module chatMentions
 */ // ============================================================================
// Types
// ============================================================================
__turbopack_context__.s([
    "extractBotPrompt",
    ()=>extractBotPrompt,
    "getAutocompleteSuggestions",
    ()=>getAutocompleteSuggestions,
    "parseContent",
    ()=>parseContent,
    "resolveMentions",
    ()=>resolveMentions
]);
// ============================================================================
// Parsing
// ============================================================================
const MENTION_REGEX = /@"([^"]+)"|@(\w[\w.-]*)/g;
const TOPIC_REGEX = /#([\w-]+)/g;
const BOT_NAME = "kai";
function parseContent(content) {
    const mentions = [];
    let hasBotMention = false;
    // Parse @mentions
    let match;
    MENTION_REGEX.lastIndex = 0;
    while((match = MENTION_REGEX.exec(content)) !== null){
        const value = match[1] || match[2]; // Quoted name or plain username
        const isBotMention = value.toLowerCase() === BOT_NAME;
        if (isBotMention) {
            hasBotMention = true;
        }
        mentions.push({
            type: isBotMention ? "bot" : "user",
            raw: match[0],
            value,
            startIndex: match.index,
            endIndex: match.index + match[0].length
        });
    }
    // Parse #topics
    TOPIC_REGEX.lastIndex = 0;
    while((match = TOPIC_REGEX.exec(content)) !== null){
        mentions.push({
            type: "topic",
            raw: match[0],
            value: match[1],
            startIndex: match.index,
            endIndex: match.index + match[0].length
        });
    }
    // Sort by position
    mentions.sort((a, b)=>a.startIndex - b.startIndex);
    return {
        text: content,
        mentions,
        hasBotMention
    };
}
function extractBotPrompt(content) {
    return content.replace(/@kai\b/gi, "").trim();
}
function getAutocompleteSuggestions(query, members, maxResults = 8) {
    const lowerQuery = query.toLowerCase();
    const suggestions = [];
    // Check if @kai matches
    if (BOT_NAME.startsWith(lowerQuery) || lowerQuery === "") {
        suggestions.push({
            label: "Kai (AI Assistant)",
            value: "@kai",
            type: "bot"
        });
    }
    // Filter members
    for (const member of members){
        if (suggestions.length >= maxResults) break;
        const matchesUsername = member.username.toLowerCase().startsWith(lowerQuery);
        const matchesDisplay = member.displayName.toLowerCase().startsWith(lowerQuery);
        if (matchesUsername || matchesDisplay) {
            const hasSpaces = member.displayName.includes(" ");
            suggestions.push({
                label: member.displayName,
                value: hasSpaces ? `@"${member.displayName}"` : `@${member.username}`,
                type: "user"
            });
        }
    }
    return suggestions;
}
function resolveMentions(mentions, members) {
    const resolved = [];
    for (const mention of mentions){
        if (mention.type !== "user") continue;
        const found = members.find((m)=>m.username.toLowerCase() === mention.value.toLowerCase() || m.displayName.toLowerCase() === mention.value.toLowerCase());
        if (found && !resolved.some((r)=>r.username === found.username)) {
            resolved.push(found);
        }
    }
    return resolved;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/MessageComposer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MessageComposer",
    ()=>MessageComposer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * MessageComposer — Input with @mention autocomplete and typing indicators.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript) <export default as Paper>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemButton/ListItemButton.js [app-client] (ecmascript) <export default as ListItemButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemIcon/ListItemIcon.js [app-client] (ecmascript) <export default as ListItemIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popper$2f$Popper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Popper$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Popper/Popper.js [app-client] (ecmascript) <export default as Popper>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Send.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SmartToy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/SmartToy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Person$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Person.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatMentions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/chatMentions.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
function MessageComposer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(62);
    if ($[0] !== "095adf84ccaff5050c804b31bc55f03dfb438fa4525d376049b914c49d705db4") {
        for(let $i = 0; $i < 62; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "095adf84ccaff5050c804b31bc55f03dfb438fa4525d376049b914c49d705db4";
    }
    const { onSend, members, onTyping, replyTo, onCancelReply, placeholder: t1 } = t0;
    const placeholder = t1 === undefined ? "Type a message... (@kai for AI)" : t1;
    const [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [mentionQuery, setMentionQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [mentionAnchor, setMentionAnchor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedIndex, setSelectedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const typingTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t2;
    if ($[1] !== members || $[2] !== mentionQuery) {
        t2 = mentionQuery !== null ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$chatMentions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAutocompleteSuggestions"])(mentionQuery, members) : [];
        $[1] = members;
        $[2] = mentionQuery;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const suggestions = t2;
    let t3;
    if ($[4] !== onTyping) {
        t3 = ({
            "MessageComposer[handleTyping]": ()=>{
                onTyping?.(true);
                if (typingTimeoutRef.current) {
                    clearTimeout(typingTimeoutRef.current);
                }
                typingTimeoutRef.current = setTimeout({
                    "MessageComposer[handleTyping > setTimeout()]": ()=>{
                        onTyping?.(false);
                    }
                }["MessageComposer[handleTyping > setTimeout()]"], 2000);
            }
        })["MessageComposer[handleTyping]"];
        $[4] = onTyping;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const handleTyping = t3;
    let t4;
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "MessageComposer[useEffect()]": ()=>()=>{
                    if (typingTimeoutRef.current) {
                        clearTimeout(typingTimeoutRef.current);
                    }
                }
        })["MessageComposer[useEffect()]"];
        t5 = [];
        $[6] = t4;
        $[7] = t5;
    } else {
        t4 = $[6];
        t5 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t4, t5);
    let t6;
    if ($[8] !== handleTyping) {
        t6 = ({
            "MessageComposer[handleChange]": (e)=>{
                const newValue = e.target.value;
                setValue(newValue);
                handleTyping();
                const cursorPos = e.target.selectionStart || newValue.length;
                const textBefore = newValue.slice(0, cursorPos);
                const atMatch = textBefore.match(/@(\w*)$/);
                if (atMatch) {
                    setMentionQuery(atMatch[1]);
                    setMentionAnchor(e.target);
                    setSelectedIndex(0);
                } else {
                    setMentionQuery(null);
                    setMentionAnchor(null);
                }
            }
        })["MessageComposer[handleChange]"];
        $[8] = handleTyping;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    const handleChange = t6;
    let t7;
    if ($[10] !== value) {
        t7 = ({
            "MessageComposer[insertMention]": (mentionValue)=>{
                const cursorPos_0 = inputRef.current?.selectionStart || value.length;
                const textBefore_0 = value.slice(0, cursorPos_0);
                const textAfter = value.slice(cursorPos_0);
                const atIndex = textBefore_0.lastIndexOf("@");
                const newText = textBefore_0.slice(0, atIndex) + mentionValue + " " + textAfter;
                setValue(newText);
                setMentionQuery(null);
                setMentionAnchor(null);
                setTimeout({
                    "MessageComposer[insertMention > setTimeout()]": ()=>inputRef.current?.focus()
                }["MessageComposer[insertMention > setTimeout()]"], 0);
            }
        })["MessageComposer[insertMention]"];
        $[10] = value;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    const insertMention = t7;
    let handleKeyDown;
    let handleSend;
    if ($[12] !== insertMention || $[13] !== mentionQuery || $[14] !== onSend || $[15] !== onTyping || $[16] !== replyTo?.id || $[17] !== selectedIndex || $[18] !== suggestions || $[19] !== value) {
        handleKeyDown = ({
            "MessageComposer[handleKeyDown]": (e_0)=>{
                if (mentionQuery !== null && suggestions.length > 0) {
                    if (e_0.key === "ArrowDown") {
                        e_0.preventDefault();
                        setSelectedIndex({
                            "MessageComposer[handleKeyDown > setSelectedIndex()]": (i)=>Math.min(i + 1, suggestions.length - 1)
                        }["MessageComposer[handleKeyDown > setSelectedIndex()]"]);
                        return;
                    }
                    if (e_0.key === "ArrowUp") {
                        e_0.preventDefault();
                        setSelectedIndex(_MessageComposerHandleKeyDownSetSelectedIndex);
                        return;
                    }
                    if (e_0.key === "Enter" || e_0.key === "Tab") {
                        e_0.preventDefault();
                        insertMention(suggestions[selectedIndex].value);
                        return;
                    }
                    if (e_0.key === "Escape") {
                        setMentionQuery(null);
                        setMentionAnchor(null);
                        return;
                    }
                }
                if (e_0.key === "Enter" && !e_0.shiftKey) {
                    e_0.preventDefault();
                    handleSend();
                }
            }
        })["MessageComposer[handleKeyDown]"];
        handleSend = ({
            "MessageComposer[handleSend]": ()=>{
                const content = value.trim();
                if (!content) {
                    return;
                }
                onSend(content, replyTo?.id);
                setValue("");
                setMentionQuery(null);
                onTyping?.(false);
                if (typingTimeoutRef.current) {
                    clearTimeout(typingTimeoutRef.current);
                }
            }
        })["MessageComposer[handleSend]"];
        $[12] = insertMention;
        $[13] = mentionQuery;
        $[14] = onSend;
        $[15] = onTyping;
        $[16] = replyTo?.id;
        $[17] = selectedIndex;
        $[18] = suggestions;
        $[19] = value;
        $[20] = handleKeyDown;
        $[21] = handleSend;
    } else {
        handleKeyDown = $[20];
        handleSend = $[21];
    }
    let t8;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            p: 2,
            borderTop: 1,
            borderColor: "divider"
        };
        $[22] = t8;
    } else {
        t8 = $[22];
    }
    let t9;
    if ($[23] !== onCancelReply || $[24] !== replyTo) {
        t9 = replyTo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                mb: 1,
                px: 1,
                py: 0.5,
                bgcolor: "action.hover",
                borderRadius: 1,
                borderLeft: 3,
                borderColor: "primary.main"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "caption",
                    noWrap: true,
                    sx: {
                        flex: 1
                    },
                    children: [
                        "Replying to ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                            children: replyTo.authorName
                        }, void 0, false, {
                            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                            lineNumber: 245,
                            columnNumber: 22
                        }, this),
                        ": ",
                        replyTo.content
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                    lineNumber: 243,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                    size: "small",
                    onClick: onCancelReply,
                    children: "×"
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                    lineNumber: 245,
                    columnNumber: 91
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 232,
            columnNumber: 21
        }, this);
        $[23] = onCancelReply;
        $[24] = replyTo;
        $[25] = t9;
    } else {
        t9 = $[25];
    }
    let t10;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            display: "flex",
            gap: 1,
            alignItems: "flex-end"
        };
        $[26] = t10;
    } else {
        t10 = $[26];
    }
    let t11;
    if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            input: {
                sx: {
                    fontSize: "0.875rem"
                }
            }
        };
        $[27] = t11;
    } else {
        t11 = $[27];
    }
    let t12;
    if ($[28] !== handleChange || $[29] !== handleKeyDown || $[30] !== placeholder || $[31] !== value) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
            inputRef: inputRef,
            fullWidth: true,
            multiline: true,
            maxRows: 4,
            size: "small",
            value: value,
            onChange: handleChange,
            onKeyDown: handleKeyDown,
            placeholder: placeholder,
            slotProps: t11
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 278,
            columnNumber: 11
        }, this);
        $[28] = handleChange;
        $[29] = handleKeyDown;
        $[30] = placeholder;
        $[31] = value;
        $[32] = t12;
    } else {
        t12 = $[32];
    }
    let t13;
    if ($[33] !== value) {
        t13 = value.trim();
        $[33] = value;
        $[34] = t13;
    } else {
        t13 = $[34];
    }
    const t14 = !t13;
    let t15;
    let t16;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            mb: 0.5
        };
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 302,
            columnNumber: 11
        }, this);
        $[35] = t15;
        $[36] = t16;
    } else {
        t15 = $[35];
        t16 = $[36];
    }
    let t17;
    if ($[37] !== handleSend || $[38] !== t14) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            color: "primary",
            onClick: handleSend,
            disabled: t14,
            sx: t15,
            children: t16
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 311,
            columnNumber: 11
        }, this);
        $[37] = handleSend;
        $[38] = t14;
        $[39] = t17;
    } else {
        t17 = $[39];
    }
    let t18;
    if ($[40] !== t12 || $[41] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t10,
            children: [
                t12,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 320,
            columnNumber: 11
        }, this);
        $[40] = t12;
        $[41] = t17;
        $[42] = t18;
    } else {
        t18 = $[42];
    }
    const t19 = mentionQuery !== null && suggestions.length > 0;
    let t20;
    if ($[43] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = {
            zIndex: 1400
        };
        $[43] = t20;
    } else {
        t20 = $[43];
    }
    let t21;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = {
            maxHeight: 200,
            overflow: "auto",
            minWidth: 200
        };
        $[44] = t21;
    } else {
        t21 = $[44];
    }
    let t22;
    if ($[45] !== insertMention || $[46] !== selectedIndex || $[47] !== suggestions) {
        let t23;
        if ($[49] !== insertMention || $[50] !== selectedIndex) {
            t23 = ({
                "MessageComposer[suggestions.map()]": (suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                        disablePadding: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__["ListItemButton"], {
                            selected: index === selectedIndex,
                            onClick: {
                                "MessageComposer[suggestions.map() > <ListItemButton>.onClick]": ()=>insertMention(suggestion.value)
                            }["MessageComposer[suggestions.map() > <ListItemButton>.onClick]"],
                            dense: true,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                    sx: {
                                        minWidth: 32
                                    },
                                    children: suggestion.type === "bot" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$SmartToy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small",
                                        color: "secondary"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                                        lineNumber: 357,
                                        columnNumber: 45
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Person$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        fontSize: "small"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                                        lineNumber: 357,
                                        columnNumber: 99
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                                    lineNumber: 355,
                                    columnNumber: 92
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                    primary: suggestion.label,
                                    primaryTypographyProps: {
                                        variant: "body2"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                                    lineNumber: 357,
                                    columnNumber: 146
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                            lineNumber: 353,
                            columnNumber: 125
                        }, this)
                    }, suggestion.value, false, {
                        fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                        lineNumber: 353,
                        columnNumber: 70
                    }, this)
            })["MessageComposer[suggestions.map()]"];
            $[49] = insertMention;
            $[50] = selectedIndex;
            $[51] = t23;
        } else {
            t23 = $[51];
        }
        t22 = suggestions.map(t23);
        $[45] = insertMention;
        $[46] = selectedIndex;
        $[47] = suggestions;
        $[48] = t22;
    } else {
        t22 = $[48];
    }
    let t23;
    if ($[52] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
            elevation: 4,
            sx: t21,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                dense: true,
                children: t22
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/MessageComposer.tsx",
                lineNumber: 377,
                columnNumber: 41
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 377,
            columnNumber: 11
        }, this);
        $[52] = t22;
        $[53] = t23;
    } else {
        t23 = $[53];
    }
    let t24;
    if ($[54] !== mentionAnchor || $[55] !== t19 || $[56] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popper$2f$Popper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Popper$3e$__["Popper"], {
            open: t19,
            anchorEl: mentionAnchor,
            placement: "top-start",
            sx: t20,
            children: t23
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 385,
            columnNumber: 11
        }, this);
        $[54] = mentionAnchor;
        $[55] = t19;
        $[56] = t23;
        $[57] = t24;
    } else {
        t24 = $[57];
    }
    let t25;
    if ($[58] !== t18 || $[59] !== t24 || $[60] !== t9) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t8,
            children: [
                t9,
                t18,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/MessageComposer.tsx",
            lineNumber: 395,
            columnNumber: 11
        }, this);
        $[58] = t18;
        $[59] = t24;
        $[60] = t9;
        $[61] = t25;
    } else {
        t25 = $[61];
    }
    return t25;
}
_s(MessageComposer, "jAuBndA4gS4NLlzQvHEyHBlfQMY=");
_c = MessageComposer;
function _MessageComposerHandleKeyDownSetSelectedIndex(i_0) {
    return Math.max(i_0 - 1, 0);
}
var _c;
__turbopack_context__.k.register(_c, "MessageComposer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/ChatPanel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChatPanel",
    ()=>ChatPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * ChatPanel — Main container for collaborative peer chat.
 *
 * Renders a topic sidebar + active thread view. Connects to the
 * ChatCollaborationProvider based on the current section/squad context.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Drawer$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Drawer/Drawer.js [app-client] (ecmascript) <export default as Drawer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Badge/Badge.js [app-client] (ecmascript) <export default as Badge>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/useMediaQuery/index.js [app-client] (ecmascript) <export default as useMediaQuery>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/useTheme.js [app-client] (ecmascript) <export default as useTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Forum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Forum.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/chatHooks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$TopicList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/TopicList.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$ThreadView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/ThreadView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$MessageComposer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/MessageComposer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
function ChatPanel(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(79);
    if ($[0] !== "7b6ddf8518ef3f0e1e2a0ff815b249ca44e5f66badb8e755865ff39d7323ca50") {
        for(let $i = 0; $i < 79; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7b6ddf8518ef3f0e1e2a0ff815b249ca44e5f66badb8e755865ff39d7323ca50";
    }
    const { roomType, roomId, user, scope, members: t1, wsUrl } = t0;
    let t2;
    if ($[1] !== t1) {
        t2 = t1 === undefined ? [] : t1;
        $[1] = t1;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const members = t2;
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"])();
    let t3;
    if ($[3] !== theme.breakpoints) {
        t3 = theme.breakpoints.down("md");
        $[3] = theme.breakpoints;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const isMobile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__["useMediaQuery"])(t3);
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeTopicId, setActiveTopicId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t4;
    if ($[5] !== roomId || $[6] !== roomType || $[7] !== user || $[8] !== wsUrl) {
        t4 = roomId ? {
            roomType,
            roomId,
            user,
            wsUrl,
            connect: true,
            persistence: true
        } : null;
        $[5] = roomId;
        $[6] = roomType;
        $[7] = user;
        $[8] = wsUrl;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    const { provider, isConnected } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatRoom"])(t4);
    const { topics, createTopic, pinTopic, archiveTopic } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatTopics"])(provider, scope);
    const { topLevelMessages, sendMessage, editMessage, deleteMessage, addReaction, getReplies } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatThread"])(provider, activeTopicId);
    const { onlineUsers, typingUsers } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPresence"])(provider, activeTopicId);
    const defaultScope = scope || (roomType === "squad" ? "squad" : "section");
    let t5;
    if ($[10] !== activeTopicId || $[11] !== topics) {
        t5 = topics.find({
            "ChatPanel[topics.find()]": (t)=>t.id === activeTopicId
        }["ChatPanel[topics.find()]"]) || null;
        $[10] = activeTopicId;
        $[11] = topics;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    const activeTopic = t5;
    let t6;
    if ($[13] !== createTopic || $[14] !== defaultScope) {
        t6 = ({
            "ChatPanel[handleCreateTopic]": (name)=>{
                const topic = createTopic(name, defaultScope);
                if (topic) {
                    setActiveTopicId(topic.id);
                }
            }
        })["ChatPanel[handleCreateTopic]"];
        $[13] = createTopic;
        $[14] = defaultScope;
        $[15] = t6;
    } else {
        t6 = $[15];
    }
    const handleCreateTopic = t6;
    let t7;
    if ($[16] !== sendMessage) {
        t7 = ({
            "ChatPanel[handleSendMessage]": (content, parentId)=>{
                sendMessage(content, parentId);
            }
        })["ChatPanel[handleSendMessage]"];
        $[16] = sendMessage;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    const handleSendMessage = t7;
    const drawerWidth = isMobile ? "100%" : 420;
    let t8;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = ({
            "ChatPanel[<IconButton>.onClick]": ()=>setOpen(true)
        })["ChatPanel[<IconButton>.onClick]"];
        $[18] = t8;
    } else {
        t8 = $[18];
    }
    let t9;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            bgcolor: "primary.dark"
        };
        $[19] = t9;
    } else {
        t9 = $[19];
    }
    let t10;
    if ($[20] !== theme.zIndex.fab) {
        t10 = {
            position: "fixed",
            bottom: 24,
            right: 24,
            bgcolor: "primary.main",
            color: "primary.contrastText",
            width: 56,
            height: 56,
            "&:hover": t9,
            zIndex: theme.zIndex.fab
        };
        $[20] = theme.zIndex.fab;
        $[21] = t10;
    } else {
        t10 = $[21];
    }
    const t11 = !isConnected;
    let t12;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Forum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 203,
            columnNumber: 11
        }, this);
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    let t13;
    if ($[23] !== t11) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__["Badge"], {
            color: "success",
            variant: "dot",
            invisible: t11,
            children: t12
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 210,
            columnNumber: 11
        }, this);
        $[23] = t11;
        $[24] = t13;
    } else {
        t13 = $[24];
    }
    let t14;
    if ($[25] !== t10 || $[26] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            onClick: t8,
            "data-testid": "collaborative-chat-button",
            sx: t10,
            children: t13
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 218,
            columnNumber: 11
        }, this);
        $[25] = t10;
        $[26] = t13;
        $[27] = t14;
    } else {
        t14 = $[27];
    }
    let t15;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = ({
            "ChatPanel[<Drawer>.onClose]": ()=>setOpen(false)
        })["ChatPanel[<Drawer>.onClose]"];
        $[28] = t15;
    } else {
        t15 = $[28];
    }
    const t16 = isMobile ? "temporary" : "persistent";
    let t17;
    if ($[29] !== drawerWidth) {
        t17 = {
            "& .MuiDrawer-paper": {
                width: drawerWidth,
                maxWidth: "100vw"
            }
        };
        $[29] = drawerWidth;
        $[30] = t17;
    } else {
        t17 = $[30];
    }
    let t18;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = {
            display: "flex",
            flexDirection: "column",
            height: "100%"
        };
        $[31] = t18;
    } else {
        t18 = $[31];
    }
    let t19;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            p: 2,
            borderBottom: 1,
            borderColor: "divider"
        };
        $[32] = t19;
    } else {
        t19 = $[32];
    }
    const t20 = activeTopic ? activeTopic.name : "Chat";
    let t21;
    if ($[33] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "h6",
            children: t20
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 276,
            columnNumber: 11
        }, this);
        $[33] = t20;
        $[34] = t21;
    } else {
        t21 = $[34];
    }
    let t22;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = {
            display: "flex",
            alignItems: "center",
            gap: 1
        };
        $[35] = t22;
    } else {
        t22 = $[35];
    }
    let t23;
    if ($[36] !== onlineUsers.length) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            children: [
                onlineUsers.length,
                " online"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 295,
            columnNumber: 11
        }, this);
        $[36] = onlineUsers.length;
        $[37] = t23;
    } else {
        t23 = $[37];
    }
    let t24;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            size: "small",
            onClick: {
                "ChatPanel[<IconButton>.onClick]": ()=>setOpen(false)
            }["ChatPanel[<IconButton>.onClick]"],
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                lineNumber: 305,
                columnNumber: 43
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 303,
            columnNumber: 11
        }, this);
        $[38] = t24;
    } else {
        t24 = $[38];
    }
    let t25;
    if ($[39] !== t23) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t22,
            children: [
                t23,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 312,
            columnNumber: 11
        }, this);
        $[39] = t23;
        $[40] = t25;
    } else {
        t25 = $[40];
    }
    let t26;
    if ($[41] !== t21 || $[42] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t19,
            children: [
                t21,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 320,
            columnNumber: 11
        }, this);
        $[41] = t21;
        $[42] = t25;
        $[43] = t26;
    } else {
        t26 = $[43];
    }
    let t27;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = {
            display: "flex",
            flex: 1,
            overflow: "hidden"
        };
        $[44] = t27;
    } else {
        t27 = $[44];
    }
    let t28;
    if ($[45] !== activeTopicId || $[46] !== archiveTopic || $[47] !== handleCreateTopic || $[48] !== isMobile || $[49] !== pinTopic || $[50] !== topics) {
        t28 = (!activeTopicId || !isMobile) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                width: activeTopicId ? 180 : "100%",
                borderRight: activeTopicId ? 1 : 0,
                borderColor: "divider",
                overflow: "auto"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$TopicList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TopicList"], {
                topics: topics,
                activeTopicId: activeTopicId,
                onSelectTopic: setActiveTopicId,
                onCreateTopic: handleCreateTopic,
                onPinTopic: pinTopic,
                onArchiveTopic: archiveTopic
            }, void 0, false, {
                fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                lineNumber: 345,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 340,
            columnNumber: 44
        }, this);
        $[45] = activeTopicId;
        $[46] = archiveTopic;
        $[47] = handleCreateTopic;
        $[48] = isMobile;
        $[49] = pinTopic;
        $[50] = topics;
        $[51] = t28;
    } else {
        t28 = $[51];
    }
    let t29;
    if ($[52] !== activeTopicId || $[53] !== addReaction || $[54] !== deleteMessage || $[55] !== editMessage || $[56] !== getReplies || $[57] !== handleSendMessage || $[58] !== isMobile || $[59] !== members || $[60] !== provider || $[61] !== topLevelMessages || $[62] !== typingUsers || $[63] !== user) {
        t29 = activeTopicId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                flexDirection: "column",
                flex: 1,
                overflow: "hidden"
            },
            children: [
                isMobile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        p: 1,
                        borderBottom: 1,
                        borderColor: "divider"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                        size: "small",
                        onClick: {
                            "ChatPanel[<IconButton>.onClick]": ()=>setActiveTopicId(null)
                        }["ChatPanel[<IconButton>.onClick]"],
                        children: "← Topics"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                        lineNumber: 367,
                        columnNumber: 10
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                    lineNumber: 363,
                    columnNumber: 21
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$ThreadView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThreadView"], {
                    messages: topLevelMessages,
                    getReplies: getReplies,
                    onReact: addReaction,
                    onEdit: editMessage,
                    onDelete: deleteMessage,
                    currentUser: user,
                    typingUsers: typingUsers
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                    lineNumber: 369,
                    columnNumber: 75
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$MessageComposer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageComposer"], {
                    onSend: handleSendMessage,
                    members: members,
                    onTyping: {
                        "ChatPanel[<MessageComposer>.onTyping]": (typing)=>provider?.setTyping(typing)
                    }["ChatPanel[<MessageComposer>.onTyping]"]
                }, void 0, false, {
                    fileName: "[project]/src/components/Chat/ChatPanel.tsx",
                    lineNumber: 369,
                    columnNumber: 254
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 358,
            columnNumber: 28
        }, this);
        $[52] = activeTopicId;
        $[53] = addReaction;
        $[54] = deleteMessage;
        $[55] = editMessage;
        $[56] = getReplies;
        $[57] = handleSendMessage;
        $[58] = isMobile;
        $[59] = members;
        $[60] = provider;
        $[61] = topLevelMessages;
        $[62] = typingUsers;
        $[63] = user;
        $[64] = t29;
    } else {
        t29 = $[64];
    }
    let t30;
    if ($[65] !== t28 || $[66] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t27,
            children: [
                t28,
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 390,
            columnNumber: 11
        }, this);
        $[65] = t28;
        $[66] = t29;
        $[67] = t30;
    } else {
        t30 = $[67];
    }
    let t31;
    if ($[68] !== t26 || $[69] !== t30) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t18,
            children: [
                t26,
                t30
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 399,
            columnNumber: 11
        }, this);
        $[68] = t26;
        $[69] = t30;
        $[70] = t31;
    } else {
        t31 = $[70];
    }
    let t32;
    if ($[71] !== open || $[72] !== t16 || $[73] !== t17 || $[74] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Drawer$3e$__["Drawer"], {
            anchor: "right",
            open: open,
            onClose: t15,
            variant: t16,
            sx: t17,
            children: t31
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/ChatPanel.tsx",
            lineNumber: 408,
            columnNumber: 11
        }, this);
        $[71] = open;
        $[72] = t16;
        $[73] = t17;
        $[74] = t31;
        $[75] = t32;
    } else {
        t32 = $[75];
    }
    let t33;
    if ($[76] !== t14 || $[77] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t14,
                t32
            ]
        }, void 0, true);
        $[76] = t14;
        $[77] = t32;
        $[78] = t33;
    } else {
        t33 = $[78];
    }
    return t33;
}
_s(ChatPanel, "d9HyrPP2CjUomoj+sTx+hSq+DpM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__["useMediaQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatRoom"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatTopics"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatThread"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$chatHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPresence"]
    ];
});
_c = ChatPanel;
var _c;
__turbopack_context__.k.register(_c, "ChatPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Chat/CollaborativeChatWrapper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CollaborativeChatWrapper",
    ()=>CollaborativeChatWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$ChatPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/ChatPanel.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
/**
 * CollaborativeChatWrapper — Connects ChatPanel to app context.
 *
 * This component bridges SectionContext/GamificationContext with the ChatPanel.
 * Place it inside any page that has SectionProvider to enable collaborative chat.
 */ 'use client';
;
;
;
;
;
;
function CollaborativeChatWrapper(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "0f258f51196b2d374985d07896e71477a7ddd310d9bc6eecaa7cddc42d1acf9f") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0f258f51196b2d374985d07896e71477a7ddd310d9bc6eecaa7cddc42d1acf9f";
    }
    let t1;
    if ($[1] !== t0) {
        t1 = t0 === undefined ? {} : t0;
        $[1] = t0;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const { roomType: roomTypeProp, roomId: roomIdProp, scope: scopeProp, members: membersProp } = t1;
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { sections } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t2;
    bb0: {
        if (!user?.attributes?.sub) {
            t2 = null;
            break bb0;
        }
        const t3 = user.attributes?.name || user.attributes?.preferred_username || user.username || "Anonymous";
        const t4 = user.attributes?.["custom:role"] || "learner";
        let t5;
        if ($[3] !== t3 || $[4] !== t4 || $[5] !== user.attributes.sub) {
            t5 = {
                username: user.attributes.sub,
                displayName: t3,
                role: t4
            };
            $[3] = t3;
            $[4] = t4;
            $[5] = user.attributes.sub;
            $[6] = t5;
        } else {
            t5 = $[6];
        }
        t2 = t5;
    }
    const chatUser = t2;
    let t3;
    bb1: {
        if (scopeProp) {
            t3 = scopeProp;
            break bb1;
        }
        const id = params?.id;
        if (pathname?.includes("/unit/") && id) {
            t3 = `unit:${id}`;
            break bb1;
        }
        if (pathname?.includes("/workbook/") && id) {
            t3 = `workbook:${id}`;
            break bb1;
        }
        if (pathname?.includes("/squad")) {
            t3 = "squad";
            break bb1;
        }
        t3 = "section";
    }
    const detectedScope = t3;
    const roomType = roomTypeProp || (detectedScope === "squad" ? "squad" : "section");
    let t4;
    bb2: {
        if (roomIdProp) {
            t4 = roomIdProp;
            break bb2;
        }
        if (roomType === "section" && sections?.length > 0) {
            t4 = sections[0].id;
            break bb2;
        }
        t4 = null;
    }
    const roomId = t4;
    let t5;
    bb3: {
        if (membersProp) {
            t5 = membersProp;
            break bb3;
        }
        let t6;
        if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = [];
            $[7] = t6;
        } else {
            t6 = $[7];
        }
        t5 = t6;
    }
    const members = t5;
    if (!chatUser || !roomId) {
        return null;
    }
    let t6;
    if ($[8] !== chatUser || $[9] !== detectedScope || $[10] !== members || $[11] !== roomId || $[12] !== roomType) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$ChatPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChatPanel"], {
            roomType: roomType,
            roomId: roomId,
            user: chatUser,
            scope: detectedScope,
            members: members
        }, void 0, false, {
            fileName: "[project]/src/components/Chat/CollaborativeChatWrapper.tsx",
            lineNumber: 150,
            columnNumber: 10
        }, this);
        $[8] = chatUser;
        $[9] = detectedScope;
        $[10] = members;
        $[11] = roomId;
        $[12] = roomType;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    return t6;
}
_s(CollaborativeChatWrapper, "T+S4Z43CM4T4xv1fU4/Md5JulQ0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = CollaborativeChatWrapper;
var _c;
__turbopack_context__.k.register(_c, "CollaborativeChatWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WorkbookClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
/**
 * WorkbookClient — Full interactive workbook with SSR HTML skeleton.
 *
 * Receives pre-rendered HTML from the server component and displays it
 * immediately while the full interactive Lexical editor loads.
 * Once Lexical is ready, it replaces the static HTML seamlessly.
 *
 * Pattern from: https://github.com/2wheeh/lexical-nextjs-ssr
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$Workbook$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/Workbook.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$WorkbookSSRSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/WorkbookSSRSkeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$SecretLinkIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/SecretLinkIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/fileContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useChatPageContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$CollaborativeChatWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Chat/CollaborativeChatWrapper.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
/**
 * TimerWrappedEditor — Inner content that handles the timer gate and renders workbook.
 */ function TimerWrappedEditor(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(24);
    if ($[0] !== "6b4d4956c1b873e2996a5aaf08cac4f8b7bb7647a4d9d54b2cbc6901883c1f42") {
        for(let $i = 0; $i < 24; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6b4d4956c1b873e2996a5aaf08cac4f8b7bb7647a4d9d54b2cbc6901883c1f42";
    }
    const { ssrHtml } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("pages");
    const { unit, grade, createGrade, recentGrades, files, dictionary, questionBank } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t1;
    if ($[1] !== files) {
        t1 = Object.values(files || {});
        $[1] = files;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const filesArray = t1;
    let t2;
    if ($[3] !== dictionary || $[4] !== filesArray || $[5] !== questionBank || $[6] !== unit) {
        t2 = {
            unit,
            files: filesArray,
            dictionary,
            questions: questionBank
        };
        $[3] = dictionary;
        $[4] = filesArray;
        $[5] = questionBank;
        $[6] = unit;
        $[7] = t2;
    } else {
        t2 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPageContext"])(t2);
    const unitTimeLimitSeconds = unit?.timeLimitSeconds || 0;
    const needsTimer = unitTimeLimitSeconds > 0;
    const timerStarted = grade?.timerStarted;
    let t3;
    if ($[8] !== createGrade || $[9] !== needsTimer || $[10] !== recentGrades || $[11] !== t || $[12] !== timerStarted || $[13] !== unit?.description || $[14] !== unit?.name) {
        t3 = needsTimer && !timerStarted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                recentGrades.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    elevation: 5,
                    sx: {
                        padding: "1rem",
                        width: "97vw",
                        margin: "1rem auto",
                        textAlign: "center"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "h4",
                            component: "h4",
                            sx: {
                                flexGrow: 1,
                                textAlign: "center",
                                margin: "2rem 0.5rem 0.5rem"
                            },
                            children: unit?.name
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                            lineNumber: 94,
                            columnNumber: 10
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "h6",
                            component: "h6",
                            sx: {
                                flexGrow: 1,
                                textAlign: "center"
                            },
                            children: unit?.description
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                            lineNumber: 98,
                            columnNumber: 37
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "h6",
                            component: "h6",
                            sx: {
                                flexGrow: 1,
                                textAlign: "center",
                                margin: "2rem"
                            },
                            children: t("workbook.timerInstructions")
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                            lineNumber: 101,
                            columnNumber: 44
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "contained",
                            onClick: {
                                "TimerWrappedEditor[<Button>.onClick]": async ()=>{
                                    await createGrade();
                                }
                            }["TimerWrappedEditor[<Button>.onClick]"],
                            children: t("workbook.start")
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                            lineNumber: 105,
                            columnNumber: 58
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                    lineNumber: 89,
                    columnNumber: 73
                }, this),
                recentGrades.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        position: "absolute",
                        top: "50%",
                        left: "50%",
                        transform: "translate(-50%, -50%)",
                        width: "70vw",
                        bgcolor: "background.paper",
                        boxShadow: "0 0 10px 3px rgba(0, 0, 0, .3)",
                        backdropFilter: "blur(5px)",
                        overflow: "auto"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "h4",
                            component: "h4",
                            sx: {
                                flexGrow: 1,
                                textAlign: "center",
                                margin: "2rem 0.5rem 0.5rem"
                            },
                            children: unit?.name
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                            lineNumber: 119,
                            columnNumber: 10
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "h6",
                            component: "h6",
                            sx: {
                                flexGrow: 1,
                                textAlign: "center"
                            },
                            children: unit?.description
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                            lineNumber: 123,
                            columnNumber: 37
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            id: "5c829cdf68bd57ea",
                            children: "ol.recent-grades{counter-reset:my-counter;list-style-type:none}ol.recent-grades li:before{content:counter(my-counter);counter-increment:my-counter;margin-right:-.5em;font-size:1.5em;font-weight:700;position:relative;top:2rem;left:-1.5rem}"
                        }, void 0, false, void 0, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                            style: {
                                padding: "0 2rem",
                                margin: "1rem 2rem",
                                maxHeight: "50vh",
                                overflow: "auto"
                            },
                            className: "jsx-5c829cdf68bd57ea" + " " + "recent-grades",
                            children: recentGrades.map(_TimerWrappedEditorRecentGradesMap)
                        }, void 0, false, {
                            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                            lineNumber: 126,
                            columnNumber: 631
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "h6",
                            component: "h6",
                            sx: {
                                flexGrow: 1,
                                textAlign: "center",
                                margin: "2rem"
                            },
                            children: [
                                t("workbook.timerInstructions"),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {
                                    className: "jsx-5c829cdf68bd57ea"
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                                    lineNumber: 135,
                                    columnNumber: 45
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {
                                    className: "jsx-5c829cdf68bd57ea"
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                                    lineNumber: 135,
                                    columnNumber: 51
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    variant: "contained",
                                    onClick: {
                                        "TimerWrappedEditor[<Button>.onClick]": async ()=>{
                                            await createGrade();
                                        }
                                    }["TimerWrappedEditor[<Button>.onClick]"],
                                    children: t("workbook.start")
                                }, void 0, false, {
                                    fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                                    lineNumber: 135,
                                    columnNumber: 57
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                            lineNumber: 131,
                            columnNumber: 71
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                    lineNumber: 109,
                    columnNumber: 118
                }, this)
            ]
        }, void 0, true);
        $[8] = createGrade;
        $[9] = needsTimer;
        $[10] = recentGrades;
        $[11] = t;
        $[12] = timerStarted;
        $[13] = unit?.description;
        $[14] = unit?.name;
        $[15] = t3;
    } else {
        t3 = $[15];
    }
    let t4;
    if ($[16] !== needsTimer || $[17] !== ssrHtml || $[18] !== timerStarted || $[19] !== unit) {
        t4 = (!needsTimer || needsTimer && timerStarted) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            "data-tour": "workbook-content",
            children: unit ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$Workbook$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Workbook"], {}, void 0, false, {
                        fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                        lineNumber: 153,
                        columnNumber: 101
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$SecretLinkIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SecretLinkIcon"], {
                        unitId: unit?.id || ""
                    }, void 0, false, {
                        fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                        lineNumber: 153,
                        columnNumber: 113
                    }, this)
                ]
            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$WorkbookSSRSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WorkbookSSRSkeleton"], {
                html: ssrHtml || ""
            }, void 0, false, {
                fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                lineNumber: 153,
                columnNumber: 161
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
            lineNumber: 153,
            columnNumber: 57
        }, this);
        $[16] = needsTimer;
        $[17] = ssrHtml;
        $[18] = timerStarted;
        $[19] = unit;
        $[20] = t4;
    } else {
        t4 = $[20];
    }
    let t5;
    if ($[21] !== t3 || $[22] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t3,
                t4
            ]
        }, void 0, true);
        $[21] = t3;
        $[22] = t4;
        $[23] = t5;
    } else {
        t5 = $[23];
    }
    return t5;
}
_s(TimerWrappedEditor, "NK5XRaQFgM52J35Rd42iIza2UZU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useChatPageContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatPageContext"]
    ];
});
_c = TimerWrappedEditor;
/**
 * WorkbookClient — Exported default for dynamic import.
 * Wraps the full workbook with auth + providers.
 */ function _TimerWrappedEditorRecentGradesMap(g, index) {
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const localTime = new Date(g?.createdAt).toLocaleString(undefined, {
        timeZone
    });
    const roundedAccuracy = Math.round(g?.accuracy * 100) / 100;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                display: "flex",
                justifyContent: "center",
                margin: "0"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "h6",
                    component: "div",
                    sx: {
                        textAlign: "left",
                        paddingLeft: "2rem"
                    },
                    children: localTime
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                    lineNumber: 188,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        flex: 1,
                        textAlign: "center",
                        flexGrow: 1,
                        borderBottom: "1px dashed currentColor",
                        margin: "0 0.4rem",
                        position: "relative",
                        top: "-0.5rem"
                    }
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                    lineNumber: 191,
                    columnNumber: 34
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "h6",
                    component: "div",
                    sx: {
                        textAlign: "right",
                        margin: "0"
                    },
                    children: `${roundedAccuracy}%`
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                    lineNumber: 199,
                    columnNumber: 12
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
            lineNumber: 184,
            columnNumber: 26
        }, this)
    }, index, false, {
        fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
        lineNumber: 184,
        columnNumber: 10
    }, this);
}
function WorkbookClient(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "6b4d4956c1b873e2996a5aaf08cac4f8b7bb7647a4d9d54b2cbc6901883c1f42") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6b4d4956c1b873e2996a5aaf08cac4f8b7bb7647a4d9d54b2cbc6901883c1f42";
    }
    const { ssrHtml } = t0;
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    let t1;
    if ($[1] !== ssrHtml) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TimerWrappedEditor, {
            ssrHtml: ssrHtml
        }, void 0, false, {
            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
            lineNumber: 222,
            columnNumber: 10
        }, this);
        $[1] = ssrHtml;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== id || $[4] !== t1) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilesProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DictionaryProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnitProvider"], {
                    id: id,
                    children: t1
                }, void 0, false, {
                    fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                    lineNumber: 230,
                    columnNumber: 45
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
                lineNumber: 230,
                columnNumber: 25
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
            lineNumber: 230,
            columnNumber: 10
        }, this);
        $[3] = id;
        $[4] = t1;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    let t3;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Chat$2f$CollaborativeChatWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CollaborativeChatWrapper"], {}, void 0, false, {
            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
            lineNumber: 239,
            columnNumber: 10
        }, this);
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== id || $[8] !== t2) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionProvider"], {
            unitId: id,
            children: [
                t2,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/app/[locale]/workbook/[id]/WorkbookClient.tsx",
            lineNumber: 246,
            columnNumber: 10
        }, this);
        $[7] = id;
        $[8] = t2;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    return t4;
}
_s1(WorkbookClient, "0FkmEimyPcMhLUh7je9gv1ZLpaY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c1 = WorkbookClient;
var _c, _c1;
__turbopack_context__.k.register(_c, "TimerWrappedEditor");
__turbopack_context__.k.register(_c1, "WorkbookClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_0zq94p6._.js.map