(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0zq94p6._.js","static/chunks/node_modules_@mui_0i__g7u._.js"],
    source: "dynamic"
});
