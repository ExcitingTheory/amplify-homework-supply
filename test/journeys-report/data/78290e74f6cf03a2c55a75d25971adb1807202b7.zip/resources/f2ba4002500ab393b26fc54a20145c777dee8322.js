(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0049jo2._.js","static/chunks/node_modules_@mui_0xa6t69._.js"],
    source: "dynamic"
});
