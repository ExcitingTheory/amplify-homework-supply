(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/DebugPanel/StateInspector.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StateInspector",
    ()=>StateInspector,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * StateInspector - Detailed state visualization component
 * 
 * Displays application state snapshot with expandable sections
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Accordion/Accordion.js [app-client] (ecmascript) <export default as Accordion>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AccordionSummary/AccordionSummary.js [app-client] (ecmascript) <export default as AccordionSummary>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AccordionDetails/AccordionDetails.js [app-client] (ecmascript) <export default as AccordionDetails>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandMore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Refresh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Refresh.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Download.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Send.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ContentCopy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ContentCopy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$debug$2f$discordWebhook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/debug/discordWebhook.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
/**
 * Format bytes to human-readable size
 */ function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = [
        'B',
        'KB',
        'MB',
        'GB'
    ];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${(bytes / Math.pow(k, i)).toFixed(2)} ${sizes[i]}`;
}
function StateInspector(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(164);
    if ($[0] !== "ba34d665d160d88d66dfdfb395651f7b33d54fce82d04ea99fc2ffa747560e89") {
        for(let $i = 0; $i < 164; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "ba34d665d160d88d66dfdfb395651f7b33d54fce82d04ea99fc2ffa747560e89";
    }
    const { snapshot, onRefresh, onExport, onSendToDiscord } = t0;
    const [copiedSection, setCopiedSection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$debug$2f$discordWebhook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDiscordWebhookConfigured"])();
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const discordEnabled = t1;
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "StateInspector[handleCopySection]": (sectionName, data)=>{
                const json = JSON.stringify(data, null, 2);
                navigator.clipboard.writeText(json);
                setCopiedSection(sectionName);
                setTimeout({
                    "StateInspector[handleCopySection > setTimeout()]": ()=>setCopiedSection(null)
                }["StateInspector[handleCopySection > setTimeout()]"], 2000);
            }
        })["StateInspector[handleCopySection]"];
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const handleCopySection = t2;
    if (!snapshot) {
        let t3;
        let t4;
        if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = {
                textAlign: "center",
                py: 4
            };
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body1",
                color: "text.secondary",
                gutterBottom: true,
                children: "No state snapshot available"
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 80,
                columnNumber: 12
            }, this);
            $[3] = t3;
            $[4] = t4;
        } else {
            t3 = $[3];
            t4 = $[4];
        }
        let t5;
        if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Refresh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 89,
                columnNumber: 12
            }, this);
            $[5] = t5;
        } else {
            t5 = $[5];
        }
        let t6;
        if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = {
                mt: 2
            };
            $[6] = t6;
        } else {
            t6 = $[6];
        }
        let t7;
        if ($[7] !== onRefresh) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t3,
                children: [
                    t4,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        variant: "contained",
                        startIcon: t5,
                        onClick: onRefresh,
                        sx: t6,
                        children: "Capture State"
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                        lineNumber: 105,
                        columnNumber: 29
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 105,
                columnNumber: 12
            }, this);
            $[7] = onRefresh;
            $[8] = t7;
        } else {
            t7 = $[8];
        }
        return t7;
    }
    let T0;
    let T1;
    let T2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    if ($[9] !== snapshot) {
        const snapshotSize = new Blob([
            JSON.stringify(snapshot)
        ]).size;
        T2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"];
        T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"];
        t4 = "row";
        t5 = 1;
        if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = {
                mb: 2
            };
            $[19] = t6;
        } else {
            t6 = $[19];
        }
        t7 = "center";
        let t9;
        if ($[20] !== snapshot.timestamp) {
            t9 = new Date(snapshot.timestamp).toLocaleString();
            $[20] = snapshot.timestamp;
            $[21] = t9;
        } else {
            t9 = $[21];
        }
        const t10 = `Captured: ${t9}`;
        if ($[22] !== t10) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                label: t10,
                size: "small",
                variant: "outlined"
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 147,
                columnNumber: 12
            }, this);
            $[22] = t10;
            $[23] = t8;
        } else {
            t8 = $[23];
        }
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"];
        t3 = formatBytes(snapshotSize);
        $[9] = snapshot;
        $[10] = T0;
        $[11] = T1;
        $[12] = T2;
        $[13] = t3;
        $[14] = t4;
        $[15] = t5;
        $[16] = t6;
        $[17] = t7;
        $[18] = t8;
    } else {
        T0 = $[10];
        T1 = $[11];
        T2 = $[12];
        t3 = $[13];
        t4 = $[14];
        t5 = $[15];
        t6 = $[16];
        t7 = $[17];
        t8 = $[18];
    }
    let t9;
    if ($[24] !== T0 || $[25] !== t3) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            label: t3,
            size: "small",
            color: "primary"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 178,
            columnNumber: 10
        }, this);
        $[24] = T0;
        $[25] = t3;
        $[26] = t9;
    } else {
        t9 = $[26];
    }
    let t10;
    if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                flexGrow: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 187,
            columnNumber: 11
        }, this);
        $[27] = t10;
    } else {
        t10 = $[27];
    }
    let t11;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Refresh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 196,
            columnNumber: 11
        }, this);
        $[28] = t11;
    } else {
        t11 = $[28];
    }
    let t12;
    if ($[29] !== onRefresh) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: "Refresh snapshot",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                size: "small",
                onClick: onRefresh,
                children: t11
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 203,
                columnNumber: 45
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 203,
            columnNumber: 11
        }, this);
        $[29] = onRefresh;
        $[30] = t12;
    } else {
        t12 = $[30];
    }
    let t13;
    if ($[31] !== onSendToDiscord || $[32] !== snapshot) {
        t13 = discordEnabled && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: "Send to Discord support channel",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                size: "small",
                onClick: {
                    "StateInspector[<IconButton>.onClick]": ()=>onSendToDiscord?.(snapshot)
                }["StateInspector[<IconButton>.onClick]"],
                color: "primary",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fontSize: "small"
                }, void 0, false, {
                    fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                    lineNumber: 213,
                    columnNumber: 66
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 211,
                columnNumber: 78
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 211,
            columnNumber: 29
        }, this);
        $[31] = onSendToDiscord;
        $[32] = snapshot;
        $[33] = t13;
    } else {
        t13 = $[33];
    }
    let t14;
    if ($[34] !== onExport || $[35] !== snapshot) {
        t14 = ({
            "StateInspector[<IconButton>.onClick]": ()=>onExport?.(snapshot)
        })["StateInspector[<IconButton>.onClick]"];
        $[34] = onExport;
        $[35] = snapshot;
        $[36] = t14;
    } else {
        t14 = $[36];
    }
    let t15;
    if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 233,
            columnNumber: 11
        }, this);
        $[37] = t15;
    } else {
        t15 = $[37];
    }
    let t16;
    if ($[38] !== t14) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: "Export snapshot",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                size: "small",
                onClick: t14,
                children: t15
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 240,
                columnNumber: 44
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 240,
            columnNumber: 11
        }, this);
        $[38] = t14;
        $[39] = t16;
    } else {
        t16 = $[39];
    }
    let t17;
    if ($[40] !== T1 || $[41] !== t12 || $[42] !== t13 || $[43] !== t16 || $[44] !== t4 || $[45] !== t5 || $[46] !== t6 || $[47] !== t7 || $[48] !== t8 || $[49] !== t9) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
            direction: t4,
            spacing: t5,
            sx: t6,
            alignItems: t7,
            children: [
                t8,
                t9,
                t10,
                t12,
                t13,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 248,
            columnNumber: 11
        }, this);
        $[40] = T1;
        $[41] = t12;
        $[42] = t13;
        $[43] = t16;
        $[44] = t4;
        $[45] = t5;
        $[46] = t6;
        $[47] = t7;
        $[48] = t8;
        $[49] = t9;
        $[50] = t17;
    } else {
        t17 = $[50];
    }
    let t18;
    if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
            expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 265,
                columnNumber: 41
            }, this),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "subtitle2",
                children: "Environment"
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 265,
                columnNumber: 61
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 265,
            columnNumber: 11
        }, this);
        $[51] = t18;
    } else {
        t18 = $[51];
    }
    let t19;
    if ($[52] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
            children: "Version:"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 272,
            columnNumber: 11
        }, this);
        $[52] = t19;
    } else {
        t19 = $[52];
    }
    let t20;
    if ($[53] !== snapshot.version) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            children: [
                t19,
                " ",
                snapshot.version
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 279,
            columnNumber: 11
        }, this);
        $[53] = snapshot.version;
        $[54] = t20;
    } else {
        t20 = $[54];
    }
    let t21;
    if ($[55] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
            children: "User Agent:"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 287,
            columnNumber: 11
        }, this);
        $[55] = t21;
    } else {
        t21 = $[55];
    }
    let t22;
    if ($[56] !== snapshot.environment.userAgent) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            children: [
                t21,
                " ",
                snapshot.environment.userAgent
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 294,
            columnNumber: 11
        }, this);
        $[56] = snapshot.environment.userAgent;
        $[57] = t22;
    } else {
        t22 = $[57];
    }
    let t23;
    if ($[58] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
            children: "URL:"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 302,
            columnNumber: 11
        }, this);
        $[58] = t23;
    } else {
        t23 = $[58];
    }
    let t24;
    if ($[59] !== snapshot.environment.url) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            children: [
                t23,
                " ",
                snapshot.environment.url
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 309,
            columnNumber: 11
        }, this);
        $[59] = snapshot.environment.url;
        $[60] = t24;
    } else {
        t24 = $[60];
    }
    let t25;
    if ($[61] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
            children: "Viewport:"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 317,
            columnNumber: 11
        }, this);
        $[61] = t25;
    } else {
        t25 = $[61];
    }
    let t26;
    if ($[62] !== snapshot.environment.viewport.height || $[63] !== snapshot.environment.viewport.width) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            children: [
                t25,
                " ",
                snapshot.environment.viewport.width,
                " × ",
                snapshot.environment.viewport.height
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 324,
            columnNumber: 11
        }, this);
        $[62] = snapshot.environment.viewport.height;
        $[63] = snapshot.environment.viewport.width;
        $[64] = t26;
    } else {
        t26 = $[64];
    }
    let t27;
    if ($[65] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
            children: "Platform:"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 333,
            columnNumber: 11
        }, this);
        $[65] = t27;
    } else {
        t27 = $[65];
    }
    let t28;
    if ($[66] !== snapshot.environment.platform) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            children: [
                t27,
                " ",
                snapshot.environment.platform
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 340,
            columnNumber: 11
        }, this);
        $[66] = snapshot.environment.platform;
        $[67] = t28;
    } else {
        t28 = $[67];
    }
    let t29;
    if ($[68] === Symbol.for("react.memo_cache_sentinel")) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
            children: "Language:"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 348,
            columnNumber: 11
        }, this);
        $[68] = t29;
    } else {
        t29 = $[68];
    }
    let t30;
    if ($[69] !== snapshot.environment.language) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            children: [
                t29,
                " ",
                snapshot.environment.language
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 355,
            columnNumber: 11
        }, this);
        $[69] = snapshot.environment.language;
        $[70] = t30;
    } else {
        t30 = $[70];
    }
    let t31;
    if ($[71] !== t20 || $[72] !== t22 || $[73] !== t24 || $[74] !== t26 || $[75] !== t28 || $[76] !== t30) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
            defaultExpanded: true,
            children: [
                t18,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                        spacing: 1,
                        children: [
                            t20,
                            t22,
                            t24,
                            t26,
                            t28,
                            t30
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                        lineNumber: 363,
                        columnNumber: 68
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                    lineNumber: 363,
                    columnNumber: 50
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 363,
            columnNumber: 11
        }, this);
        $[71] = t20;
        $[72] = t22;
        $[73] = t24;
        $[74] = t26;
        $[75] = t28;
        $[76] = t30;
        $[77] = t31;
    } else {
        t31 = $[77];
    }
    let t32;
    if ($[78] === Symbol.for("react.memo_cache_sentinel")) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 376,
            columnNumber: 11
        }, this);
        $[78] = t32;
    } else {
        t32 = $[78];
    }
    let t33;
    if ($[79] === Symbol.for("react.memo_cache_sentinel")) {
        t33 = {
            width: "100%"
        };
        $[79] = t33;
    } else {
        t33 = $[79];
    }
    let t34;
    if ($[80] !== snapshot.localStorage) {
        t34 = Object.keys(snapshot.localStorage);
        $[80] = snapshot.localStorage;
        $[81] = t34;
    } else {
        t34 = $[81];
    }
    let t35;
    if ($[82] !== t34.length) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "subtitle2",
            children: [
                "Local Storage (",
                t34.length,
                ")"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 400,
            columnNumber: 11
        }, this);
        $[82] = t34.length;
        $[83] = t35;
    } else {
        t35 = $[83];
    }
    let t36;
    if ($[84] === Symbol.for("react.memo_cache_sentinel")) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                flexGrow: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 408,
            columnNumber: 11
        }, this);
        $[84] = t36;
    } else {
        t36 = $[84];
    }
    let t37;
    if ($[85] !== snapshot.localStorage) {
        t37 = ({
            "StateInspector[<IconButton>.onClick]": (e)=>{
                e.stopPropagation();
                handleCopySection("localStorage", snapshot.localStorage);
            }
        })["StateInspector[<IconButton>.onClick]"];
        $[85] = snapshot.localStorage;
        $[86] = t37;
    } else {
        t37 = $[86];
    }
    let t38;
    let t39;
    if ($[87] === Symbol.for("react.memo_cache_sentinel")) {
        t38 = {
            mr: -1
        };
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ContentCopy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 434,
            columnNumber: 11
        }, this);
        $[87] = t38;
        $[88] = t39;
    } else {
        t38 = $[87];
        t39 = $[88];
    }
    let t40;
    if ($[89] !== t37) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            component: "span",
            size: "small",
            onClick: t37,
            sx: t38,
            children: t39
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 443,
            columnNumber: 11
        }, this);
        $[89] = t37;
        $[90] = t40;
    } else {
        t40 = $[90];
    }
    let t41;
    if ($[91] !== t35 || $[92] !== t40) {
        t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
            expandIcon: t32,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                direction: "row",
                alignItems: "center",
                sx: t33,
                children: [
                    t35,
                    t36,
                    t40
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 451,
                columnNumber: 46
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 451,
            columnNumber: 11
        }, this);
        $[91] = t35;
        $[92] = t40;
        $[93] = t41;
    } else {
        t41 = $[93];
    }
    let t42;
    if ($[94] === Symbol.for("react.memo_cache_sentinel")) {
        t42 = {
            fontSize: 11,
            margin: 0,
            overflow: "auto",
            maxHeight: 300
        };
        $[94] = t42;
    } else {
        t42 = $[94];
    }
    let t43;
    if ($[95] !== snapshot.localStorage) {
        t43 = JSON.stringify(snapshot.localStorage, null, 2);
        $[95] = snapshot.localStorage;
        $[96] = t43;
    } else {
        t43 = $[96];
    }
    let t44;
    if ($[97] !== t43) {
        t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
            style: t42,
            children: t43
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 480,
            columnNumber: 11
        }, this);
        $[97] = t43;
        $[98] = t44;
    } else {
        t44 = $[98];
    }
    let t45;
    if ($[99] !== copiedSection) {
        t45 = copiedSection === "localStorage" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "success.main",
            children: "Copied!"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 488,
            columnNumber: 47
        }, this);
        $[99] = copiedSection;
        $[100] = t45;
    } else {
        t45 = $[100];
    }
    let t46;
    if ($[101] !== t44 || $[102] !== t45) {
        t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
            children: [
                t44,
                t45
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 496,
            columnNumber: 11
        }, this);
        $[101] = t44;
        $[102] = t45;
        $[103] = t46;
    } else {
        t46 = $[103];
    }
    let t47;
    if ($[104] !== t41 || $[105] !== t46) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
            children: [
                t41,
                t46
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 505,
            columnNumber: 11
        }, this);
        $[104] = t41;
        $[105] = t46;
        $[106] = t47;
    } else {
        t47 = $[106];
    }
    let t48;
    if ($[107] === Symbol.for("react.memo_cache_sentinel")) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 514,
            columnNumber: 11
        }, this);
        $[107] = t48;
    } else {
        t48 = $[107];
    }
    let t49;
    if ($[108] !== snapshot.sessionStorage) {
        t49 = Object.keys(snapshot.sessionStorage);
        $[108] = snapshot.sessionStorage;
        $[109] = t49;
    } else {
        t49 = $[109];
    }
    let t50;
    if ($[110] !== t49.length) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
            expandIcon: t48,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "subtitle2",
                children: [
                    "Session Storage (",
                    t49.length,
                    ")"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 529,
                columnNumber: 46
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 529,
            columnNumber: 11
        }, this);
        $[110] = t49.length;
        $[111] = t50;
    } else {
        t50 = $[111];
    }
    let t51;
    if ($[112] === Symbol.for("react.memo_cache_sentinel")) {
        t51 = {
            fontSize: 11,
            margin: 0,
            overflow: "auto",
            maxHeight: 300
        };
        $[112] = t51;
    } else {
        t51 = $[112];
    }
    let t52;
    if ($[113] !== snapshot.sessionStorage) {
        t52 = JSON.stringify(snapshot.sessionStorage, null, 2);
        $[113] = snapshot.sessionStorage;
        $[114] = t52;
    } else {
        t52 = $[114];
    }
    let t53;
    if ($[115] !== t52) {
        t53 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                style: t51,
                children: t52
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 557,
                columnNumber: 29
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 557,
            columnNumber: 11
        }, this);
        $[115] = t52;
        $[116] = t53;
    } else {
        t53 = $[116];
    }
    let t54;
    if ($[117] !== t50 || $[118] !== t53) {
        t54 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
            children: [
                t50,
                t53
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 565,
            columnNumber: 11
        }, this);
        $[117] = t50;
        $[118] = t53;
        $[119] = t54;
    } else {
        t54 = $[119];
    }
    let t55;
    if ($[120] === Symbol.for("react.memo_cache_sentinel")) {
        t55 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 574,
            columnNumber: 11
        }, this);
        $[120] = t55;
    } else {
        t55 = $[120];
    }
    let t56;
    if ($[121] !== snapshot.componentTree) {
        t56 = snapshot.componentTree ? JSON.parse(snapshot.componentTree).length : 0;
        $[121] = snapshot.componentTree;
        $[122] = t56;
    } else {
        t56 = $[122];
    }
    let t57;
    if ($[123] !== t56) {
        t57 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
            expandIcon: t55,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "subtitle2",
                children: [
                    "Component Tree (",
                    t56,
                    ")"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 589,
                columnNumber: 46
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 589,
            columnNumber: 11
        }, this);
        $[123] = t56;
        $[124] = t57;
    } else {
        t57 = $[124];
    }
    let t58;
    if ($[125] === Symbol.for("react.memo_cache_sentinel")) {
        t58 = {
            fontSize: 11,
            margin: 0,
            overflow: "auto",
            maxHeight: 300
        };
        $[125] = t58;
    } else {
        t58 = $[125];
    }
    const t59 = snapshot.componentTree || "No component tree data";
    let t60;
    if ($[126] !== t59) {
        t60 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                style: t58,
                children: t59
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 610,
                columnNumber: 29
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 610,
            columnNumber: 11
        }, this);
        $[126] = t59;
        $[127] = t60;
    } else {
        t60 = $[127];
    }
    let t61;
    if ($[128] !== t57 || $[129] !== t60) {
        t61 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
            children: [
                t57,
                t60
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 618,
            columnNumber: 11
        }, this);
        $[128] = t57;
        $[129] = t60;
        $[130] = t61;
    } else {
        t61 = $[130];
    }
    let t62;
    if ($[131] === Symbol.for("react.memo_cache_sentinel")) {
        t62 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 627,
            columnNumber: 11
        }, this);
        $[131] = t62;
    } else {
        t62 = $[131];
    }
    let t63;
    if ($[132] !== snapshot.logs) {
        t63 = snapshot.logs ? JSON.parse(snapshot.logs).length : 0;
        $[132] = snapshot.logs;
        $[133] = t63;
    } else {
        t63 = $[133];
    }
    let t64;
    if ($[134] !== t63) {
        t64 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
            expandIcon: t62,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "subtitle2",
                children: [
                    "Logs (",
                    t63,
                    ")"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 642,
                columnNumber: 46
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 642,
            columnNumber: 11
        }, this);
        $[134] = t63;
        $[135] = t64;
    } else {
        t64 = $[135];
    }
    let t65;
    if ($[136] === Symbol.for("react.memo_cache_sentinel")) {
        t65 = {
            fontSize: 11,
            margin: 0,
            overflow: "auto",
            maxHeight: 300
        };
        $[136] = t65;
    } else {
        t65 = $[136];
    }
    const t66 = snapshot.logs || "No log data";
    let t67;
    if ($[137] !== t66) {
        t67 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                style: t65,
                children: t66
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 663,
                columnNumber: 29
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 663,
            columnNumber: 11
        }, this);
        $[137] = t66;
        $[138] = t67;
    } else {
        t67 = $[138];
    }
    let t68;
    if ($[139] !== t64 || $[140] !== t67) {
        t68 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
            children: [
                t64,
                t67
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 671,
            columnNumber: 11
        }, this);
        $[139] = t64;
        $[140] = t67;
        $[141] = t68;
    } else {
        t68 = $[141];
    }
    let t69;
    if ($[142] === Symbol.for("react.memo_cache_sentinel")) {
        t69 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
            expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 680,
                columnNumber: 41
            }, this),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "subtitle2",
                children: "DataStore Models"
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 680,
                columnNumber: 61
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 680,
            columnNumber: 11
        }, this);
        $[142] = t69;
    } else {
        t69 = $[142];
    }
    let t70;
    if ($[143] !== snapshot.dataStore) {
        t70 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
            children: [
                t69,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                        spacing: 1,
                        children: Object.entries(snapshot.dataStore).map(_StateInspectorAnonymous)
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                        lineNumber: 687,
                        columnNumber: 45
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                    lineNumber: 687,
                    columnNumber: 27
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 687,
            columnNumber: 11
        }, this);
        $[143] = snapshot.dataStore;
        $[144] = t70;
    } else {
        t70 = $[144];
    }
    let t71;
    if ($[145] === Symbol.for("react.memo_cache_sentinel")) {
        t71 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
            expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 695,
                columnNumber: 41
            }, this),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "subtitle2",
                children: "Performance Metrics"
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 695,
                columnNumber: 61
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 695,
            columnNumber: 11
        }, this);
        $[145] = t71;
    } else {
        t71 = $[145];
    }
    let t72;
    if ($[146] === Symbol.for("react.memo_cache_sentinel")) {
        t72 = {
            fontSize: 11,
            margin: 0,
            overflow: "auto",
            maxHeight: 300
        };
        $[146] = t72;
    } else {
        t72 = $[146];
    }
    let t73;
    if ($[147] !== snapshot.performance) {
        t73 = JSON.stringify(snapshot.performance, null, 2);
        $[147] = snapshot.performance;
        $[148] = t73;
    } else {
        t73 = $[148];
    }
    let t74;
    if ($[149] !== t73) {
        t74 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
            children: [
                t71,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                        style: t72,
                        children: t73
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                        lineNumber: 722,
                        columnNumber: 45
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                    lineNumber: 722,
                    columnNumber: 27
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 722,
            columnNumber: 11
        }, this);
        $[149] = t73;
        $[150] = t74;
    } else {
        t74 = $[150];
    }
    let t75;
    if ($[151] !== snapshot.errors) {
        t75 = snapshot.errors.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
                    expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                        lineNumber: 730,
                        columnNumber: 82
                    }, this),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "subtitle2",
                        color: "error",
                        children: [
                            "Errors (",
                            snapshot.errors.length,
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                        lineNumber: 730,
                        columnNumber: 102
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                    lineNumber: 730,
                    columnNumber: 52
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                        style: {
                            fontSize: 11,
                            margin: 0,
                            overflow: "auto",
                            maxHeight: 300
                        },
                        children: JSON.stringify(snapshot.errors, null, 2)
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                        lineNumber: 730,
                        columnNumber: 231
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                    lineNumber: 730,
                    columnNumber: 213
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 730,
            columnNumber: 41
        }, this);
        $[151] = snapshot.errors;
        $[152] = t75;
    } else {
        t75 = $[152];
    }
    let t76;
    if ($[153] !== T2 || $[154] !== t17 || $[155] !== t31 || $[156] !== t47 || $[157] !== t54 || $[158] !== t61 || $[159] !== t68 || $[160] !== t70 || $[161] !== t74 || $[162] !== t75) {
        t76 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T2, {
            children: [
                t17,
                t31,
                t47,
                t54,
                t61,
                t68,
                t70,
                t74,
                t75
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
            lineNumber: 743,
            columnNumber: 11
        }, this);
        $[153] = T2;
        $[154] = t17;
        $[155] = t31;
        $[156] = t47;
        $[157] = t54;
        $[158] = t61;
        $[159] = t68;
        $[160] = t70;
        $[161] = t74;
        $[162] = t75;
        $[163] = t76;
    } else {
        t76 = $[163];
    }
    return t76;
}
_s(StateInspector, "ZEgN/jhF2SUmSfK5Fm4OCqjTKG4=");
_c = StateInspector;
function _StateInspectorAnonymous(t0) {
    const [modelName, models] = t0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "caption",
                fontWeight: "bold",
                children: [
                    modelName,
                    " (",
                    models.length,
                    ")"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 762,
                columnNumber: 31
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                style: {
                    fontSize: 10,
                    margin: 0,
                    overflow: "auto",
                    maxHeight: 200
                },
                children: JSON.stringify(models, null, 2)
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
                lineNumber: 762,
                columnNumber: 136
            }, this)
        ]
    }, modelName, true, {
        fileName: "[project]/src/components/DebugPanel/StateInspector.tsx",
        lineNumber: 762,
        columnNumber: 10
    }, this);
}
const __TURBOPACK__default__export__ = StateInspector;
var _c;
__turbopack_context__.k.register(_c, "StateInspector");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/DebugPanel/ComponentTreeView.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ComponentTreeView",
    ()=>ComponentTreeView,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * ComponentTreeView - Hierarchical component tree visualization
 * 
 * Displays registered React components with expandable details
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemButton/ListItemButton.js [app-client] (ecmascript) <export default as ListItemButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Collapse/Collapse.js [app-client] (ecmascript) <export default as Collapse>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandMore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ChevronRight.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
function ComponentItem(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(36);
    if ($[0] !== "5991530e7498f0469b0343054023550c60797520b89d8dcbba5dc0bce06afe1b") {
        for(let $i = 0; $i < 36; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5991530e7498f0469b0343054023550c60797520b89d8dcbba5dc0bce06afe1b";
    }
    const { component, isSelected, onSelect } = t0;
    const [expanded, setExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const hasChildren = component.children && component.children.length > 0;
    let t1;
    if ($[1] !== component || $[2] !== expanded || $[3] !== onSelect) {
        t1 = ({
            "ComponentItem[<ListItemButton>.onClick]": ()=>{
                onSelect(component);
                setExpanded(!expanded);
            }
        })["ComponentItem[<ListItemButton>.onClick]"];
        $[1] = component;
        $[2] = expanded;
        $[3] = onSelect;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    let t2;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            pl: 2
        };
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    let t3;
    if ($[6] !== expanded || $[7] !== hasChildren) {
        t3 = hasChildren && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                mr: 1
            },
            children: expanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fontSize: "small"
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                lineNumber: 66,
                columnNumber: 20
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fontSize: "small"
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                lineNumber: 66,
                columnNumber: 58
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
            lineNumber: 64,
            columnNumber: 25
        }, this);
        $[6] = expanded;
        $[7] = hasChildren;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== component.name) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            fontWeight: "medium",
            children: component.name
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
            lineNumber: 75,
            columnNumber: 10
        }, this);
        $[9] = component.name;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    const t5 = `×${component.renderCount}`;
    let t6;
    if ($[11] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            label: t5,
            size: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
            lineNumber: 84,
            columnNumber: 10
        }, this);
        $[11] = t5;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    let t7;
    if ($[13] !== t4 || $[14] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
            direction: "row",
            spacing: 1,
            alignItems: "center",
            children: [
                t4,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
            lineNumber: 92,
            columnNumber: 10
        }, this);
        $[13] = t4;
        $[14] = t6;
        $[15] = t7;
    } else {
        t7 = $[15];
    }
    let t8;
    if ($[16] !== component.mountTime) {
        t8 = new Date(component.mountTime).toLocaleTimeString();
        $[16] = component.mountTime;
        $[17] = t8;
    } else {
        t8 = $[17];
    }
    let t9;
    if ($[18] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            children: t8
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
            lineNumber: 109,
            columnNumber: 10
        }, this);
        $[18] = t8;
        $[19] = t9;
    } else {
        t9 = $[19];
    }
    let t10;
    if ($[20] !== t7 || $[21] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
            primary: t7,
            secondary: t9
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
            lineNumber: 117,
            columnNumber: 11
        }, this);
        $[20] = t7;
        $[21] = t9;
        $[22] = t10;
    } else {
        t10 = $[22];
    }
    let t11;
    if ($[23] !== isSelected || $[24] !== t1 || $[25] !== t10 || $[26] !== t3) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemButton$3e$__["ListItemButton"], {
            selected: isSelected,
            onClick: t1,
            sx: t2,
            children: [
                t3,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
            lineNumber: 126,
            columnNumber: 11
        }, this);
        $[23] = isSelected;
        $[24] = t1;
        $[25] = t10;
        $[26] = t3;
        $[27] = t11;
    } else {
        t11 = $[27];
    }
    let t12;
    if ($[28] !== component.lastRenderTime || $[29] !== component.props || $[30] !== component.state || $[31] !== isSelected) {
        t12 = isSelected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__["Collapse"], {
            in: isSelected,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    pl: 4,
                    pr: 2,
                    py: 1,
                    bgcolor: "action.hover"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        fontWeight: "bold",
                        display: "block",
                        gutterBottom: true,
                        children: "Props"
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                        lineNumber: 142,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                        style: {
                            fontSize: 10,
                            margin: 0,
                            overflow: "auto",
                            maxHeight: 150
                        },
                        children: JSON.stringify(component.props, null, 2)
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                        lineNumber: 142,
                        columnNumber: 112
                    }, this),
                    component.state && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "caption",
                                fontWeight: "bold",
                                display: "block",
                                sx: {
                                    mt: 1
                                },
                                gutterBottom: true,
                                children: "State"
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                                lineNumber: 147,
                                columnNumber: 82
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                                style: {
                                    fontSize: 10,
                                    margin: 0,
                                    overflow: "auto",
                                    maxHeight: 150
                                },
                                children: JSON.stringify(component.state, null, 2)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                                lineNumber: 149,
                                columnNumber: 52
                            }, this)
                        ]
                    }, void 0, true),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        color: "text.secondary",
                        display: "block",
                        sx: {
                            mt: 1
                        },
                        children: [
                            "Last render: ",
                            new Date(component.lastRenderTime).toLocaleTimeString()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                        lineNumber: 154,
                        columnNumber: 66
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                lineNumber: 137,
                columnNumber: 51
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
            lineNumber: 137,
            columnNumber: 25
        }, this);
        $[28] = component.lastRenderTime;
        $[29] = component.props;
        $[30] = component.state;
        $[31] = isSelected;
        $[32] = t12;
    } else {
        t12 = $[32];
    }
    let t13;
    if ($[33] !== t11 || $[34] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t11,
                t12
            ]
        }, void 0, true);
        $[33] = t11;
        $[34] = t12;
        $[35] = t13;
    } else {
        t13 = $[35];
    }
    return t13;
}
_s(ComponentItem, "DuL5jiiQQFgbn7gBKAyxwS/H4Ek=");
_c = ComponentItem;
function ComponentTreeView(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(30);
    if ($[0] !== "5991530e7498f0469b0343054023550c60797520b89d8dcbba5dc0bce06afe1b") {
        for(let $i = 0; $i < 30; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5991530e7498f0469b0343054023550c60797520b89d8dcbba5dc0bce06afe1b";
    }
    const { tree, onSelectComponent, selectedId } = t0;
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(selectedId || null);
    let t1;
    if ($[1] !== onSelectComponent) {
        t1 = ({
            "ComponentTreeView[handleSelect]": (component)=>{
                setSelected(component.id);
                onSelectComponent?.(component);
            }
        })["ComponentTreeView[handleSelect]"];
        $[1] = onSelectComponent;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const handleSelect = t1;
    if (tree.length === 0) {
        let t2;
        let t3;
        if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = {
                textAlign: "center",
                py: 4
            };
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                color: "text.secondary",
                children: "No components registered"
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                lineNumber: 216,
                columnNumber: 12
            }, this);
            $[3] = t2;
            $[4] = t3;
        } else {
            t2 = $[3];
            t3 = $[4];
        }
        let t4;
        if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: t2,
                children: [
                    t3,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        color: "text.secondary",
                        display: "block",
                        sx: {
                            mt: 1
                        },
                        children: "Use useComponentInspector() hook to register components"
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                        lineNumber: 225,
                        columnNumber: 29
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                lineNumber: 225,
                columnNumber: 12
            }, this);
            $[5] = t4;
        } else {
            t4 = $[5];
        }
        return t4;
    }
    let T0;
    let T1;
    let t2;
    let t3;
    let t4;
    if ($[6] !== handleSelect || $[7] !== selected || $[8] !== tree) {
        const groupedComponents = tree.reduce(_ComponentTreeViewTreeReduce, {});
        T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"];
        let t5;
        if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = {
                mb: 2
            };
            $[14] = t5;
        } else {
            t5 = $[14];
        }
        const t6 = `${tree.length} components`;
        let t7;
        if ($[15] !== t6) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                label: t6,
                size: "small",
                color: "primary"
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                lineNumber: 254,
                columnNumber: 12
            }, this);
            $[15] = t6;
            $[16] = t7;
        } else {
            t7 = $[16];
        }
        const t8 = `${Object.keys(groupedComponents).length} types`;
        let t9;
        if ($[17] !== t8) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                label: t8,
                size: "small",
                variant: "outlined"
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                lineNumber: 263,
                columnNumber: 12
            }, this);
            $[17] = t8;
            $[18] = t9;
        } else {
            t9 = $[18];
        }
        if ($[19] !== t7 || $[20] !== t9) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                direction: "row",
                spacing: 1,
                sx: t5,
                children: [
                    t7,
                    t9
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                lineNumber: 270,
                columnNumber: 12
            }, this);
            $[19] = t7;
            $[20] = t9;
            $[21] = t4;
        } else {
            t4 = $[21];
        }
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"];
        t2 = true;
        t3 = Object.entries(groupedComponents).map({
            "ComponentTreeView[(anonymous)()]": (t10, groupIndex)=>{
                const [componentName, components] = t10;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    children: [
                        groupIndex > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {}, void 0, false, {
                            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                            lineNumber: 282,
                            columnNumber: 60
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                primary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "subtitle2",
                                    children: [
                                        componentName,
                                        components.length > 1 && ` (${components.length} instances)`
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                                    lineNumber: 282,
                                    columnNumber: 105
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                                lineNumber: 282,
                                columnNumber: 82
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                            lineNumber: 282,
                            columnNumber: 72
                        }, this),
                        components.map({
                            "ComponentTreeView[(anonymous)() > components.map()]": (component_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ComponentItem, {
                                    component: component_1,
                                    isSelected: selected === component_1.id,
                                    onSelect: handleSelect
                                }, component_1.id, false, {
                                    fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                                    lineNumber: 283,
                                    columnNumber: 83
                                }, this)
                        }["ComponentTreeView[(anonymous)() > components.map()]"])
                    ]
                }, componentName, true, {
                    fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
                    lineNumber: 282,
                    columnNumber: 16
                }, this);
            }
        }["ComponentTreeView[(anonymous)()]"]);
        $[6] = handleSelect;
        $[7] = selected;
        $[8] = tree;
        $[9] = T0;
        $[10] = T1;
        $[11] = t2;
        $[12] = t3;
        $[13] = t4;
    } else {
        T0 = $[9];
        T1 = $[10];
        t2 = $[11];
        t3 = $[12];
        t4 = $[13];
    }
    let t5;
    if ($[22] !== T0 || $[23] !== t2 || $[24] !== t3) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            dense: t2,
            children: t3
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
            lineNumber: 304,
            columnNumber: 10
        }, this);
        $[22] = T0;
        $[23] = t2;
        $[24] = t3;
        $[25] = t5;
    } else {
        t5 = $[25];
    }
    let t6;
    if ($[26] !== T1 || $[27] !== t4 || $[28] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
            children: [
                t4,
                t5
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/ComponentTreeView.tsx",
            lineNumber: 314,
            columnNumber: 10
        }, this);
        $[26] = T1;
        $[27] = t4;
        $[28] = t5;
        $[29] = t6;
    } else {
        t6 = $[29];
    }
    return t6;
}
_s1(ComponentTreeView, "FSQ+WxMcmAk0b+j2ZD2+CI9ni+0=");
_c1 = ComponentTreeView;
function _ComponentTreeViewTreeReduce(acc, component_0) {
    if (!acc[component_0.name]) {
        acc[component_0.name] = [];
    }
    acc[component_0.name].push(component_0);
    return acc;
}
const __TURBOPACK__default__export__ = ComponentTreeView;
var _c, _c1;
__turbopack_context__.k.register(_c, "ComponentItem");
__turbopack_context__.k.register(_c1, "ComponentTreeView");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/DebugPanel/LogViewer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LogViewer",
    ()=>LogViewer,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * LogViewer - Console log viewer component with filtering
 * 
 * Displays captured console logs with color-coding and search
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Select/Select.js [app-client] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControl/FormControl.js [app-client] (ecmascript) <export default as FormControl>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputLabel/InputLabel.js [app-client] (ecmascript) <export default as InputLabel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Clear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Clear.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Error.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Warning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Info.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
/**
 * Get icon for log level
 */ function LogLevelIcon(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "c2b5629ae181f21fe1a808cd2b5f89f8edf129f7343d8a863ea8942c5eaaa06b") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c2b5629ae181f21fe1a808cd2b5f89f8edf129f7343d8a863ea8942c5eaaa06b";
    }
    const { level } = t0;
    switch(level){
        case "error":
            {
                let t1;
                if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
                    t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        fontSize: "small",
                        color: "error"
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                        lineNumber: 37,
                        columnNumber: 16
                    }, this);
                    $[1] = t1;
                } else {
                    t1 = $[1];
                }
                return t1;
            }
        case "warn":
            {
                let t1;
                if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
                    t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        fontSize: "small",
                        color: "warning"
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                        lineNumber: 48,
                        columnNumber: 16
                    }, this);
                    $[2] = t1;
                } else {
                    t1 = $[2];
                }
                return t1;
            }
        case "info":
            {
                let t1;
                if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
                    t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        fontSize: "small",
                        color: "info"
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                        lineNumber: 59,
                        columnNumber: 16
                    }, this);
                    $[3] = t1;
                } else {
                    t1 = $[3];
                }
                return t1;
            }
        default:
            {
                return null;
            }
    }
}
_c = LogLevelIcon;
/**
 * Get background color for log level
 */ function getLogColor(level) {
    switch(level){
        case 'error':
            return 'rgba(211, 47, 47, 0.1)';
        case 'warn':
            return 'rgba(237, 108, 2, 0.1)';
        case 'info':
            return 'rgba(2, 136, 209, 0.1)';
        default:
            return 'transparent';
    }
}
function LogViewer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(72);
    if ($[0] !== "c2b5629ae181f21fe1a808cd2b5f89f8edf129f7343d8a863ea8942c5eaaa06b") {
        for(let $i = 0; $i < 72; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c2b5629ae181f21fe1a808cd2b5f89f8edf129f7343d8a863ea8942c5eaaa06b";
    }
    const { logs, onClear, autoScroll: t1 } = t0;
    const autoScroll = t1 === undefined ? true : t1;
    const [searchTerm, setSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [levelFilter, setLevelFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    const scrollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t2;
    if ($[1] !== autoScroll) {
        t2 = ({
            "LogViewer[useEffect()]": ()=>{
                if (autoScroll && scrollRef.current) {
                    scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
                }
            }
        })["LogViewer[useEffect()]"];
        $[1] = autoScroll;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== autoScroll || $[4] !== logs) {
        t3 = [
            logs,
            autoScroll
        ];
        $[3] = autoScroll;
        $[4] = logs;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    let t4;
    if ($[6] !== levelFilter || $[7] !== logs || $[8] !== searchTerm) {
        let t5;
        if ($[10] !== levelFilter || $[11] !== searchTerm) {
            t5 = ({
                "LogViewer[logs.filter()]": (log)=>{
                    const matchesLevel = levelFilter === "all" || log.level === levelFilter;
                    const matchesSearch = searchTerm === "" || log.message.toLowerCase().includes(searchTerm.toLowerCase());
                    return matchesLevel && matchesSearch;
                }
            })["LogViewer[logs.filter()]"];
            $[10] = levelFilter;
            $[11] = searchTerm;
            $[12] = t5;
        } else {
            t5 = $[12];
        }
        t4 = logs.filter(t5);
        $[6] = levelFilter;
        $[7] = logs;
        $[8] = searchTerm;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    const filteredLogs = t4;
    let t5;
    if ($[13] !== logs) {
        t5 = logs.reduce(_LogViewerLogsReduce, {});
        $[13] = logs;
        $[14] = t5;
    } else {
        t5 = $[14];
    }
    const counts = t5;
    let t6;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            display: "flex",
            flexDirection: "column",
            height: "100%"
        };
        $[15] = t6;
    } else {
        t6 = $[15];
    }
    let t7;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            mb: 2
        };
        $[16] = t7;
    } else {
        t7 = $[16];
    }
    let t8;
    let t9;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            minWidth: 120
        };
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__["InputLabel"], {
            id: "log-level-filter-label",
            children: "Level"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 194,
            columnNumber: 10
        }, this);
        $[17] = t8;
        $[18] = t9;
    } else {
        t8 = $[17];
        t9 = $[18];
    }
    let t10;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = ({
            "LogViewer[<Select>.onChange]": (e)=>setLevelFilter(e.target.value)
        })["LogViewer[<Select>.onChange]"];
        $[19] = t10;
    } else {
        t10 = $[19];
    }
    let t11;
    if ($[20] !== logs.length) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            value: "all",
            children: [
                "All (",
                logs.length,
                ")"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 212,
            columnNumber: 11
        }, this);
        $[20] = logs.length;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    const t12 = counts.log || 0;
    let t13;
    if ($[22] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            value: "log",
            children: [
                "Log (",
                t12,
                ")"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 221,
            columnNumber: 11
        }, this);
        $[22] = t12;
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    const t14 = counts.info || 0;
    let t15;
    if ($[24] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            value: "info",
            children: [
                "Info (",
                t14,
                ")"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 230,
            columnNumber: 11
        }, this);
        $[24] = t14;
        $[25] = t15;
    } else {
        t15 = $[25];
    }
    const t16 = counts.warn || 0;
    let t17;
    if ($[26] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            value: "warn",
            children: [
                "Warn (",
                t16,
                ")"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 239,
            columnNumber: 11
        }, this);
        $[26] = t16;
        $[27] = t17;
    } else {
        t17 = $[27];
    }
    const t18 = counts.error || 0;
    let t19;
    if ($[28] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            value: "error",
            children: [
                "Error (",
                t18,
                ")"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 248,
            columnNumber: 11
        }, this);
        $[28] = t18;
        $[29] = t19;
    } else {
        t19 = $[29];
    }
    const t20 = counts.debug || 0;
    let t21;
    if ($[30] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
            value: "debug",
            children: [
                "Debug (",
                t20,
                ")"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 257,
            columnNumber: 11
        }, this);
        $[30] = t20;
        $[31] = t21;
    } else {
        t21 = $[31];
    }
    let t22;
    if ($[32] !== levelFilter || $[33] !== t11 || $[34] !== t13 || $[35] !== t15 || $[36] !== t17 || $[37] !== t19 || $[38] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__["FormControl"], {
            size: "small",
            sx: t8,
            children: [
                t9,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                    labelId: "log-level-filter-label",
                    id: "log-level-filter",
                    value: levelFilter,
                    label: "Level",
                    onChange: t10,
                    children: [
                        t11,
                        t13,
                        t15,
                        t17,
                        t19,
                        t21
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                    lineNumber: 265,
                    columnNumber: 49
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 265,
            columnNumber: 11
        }, this);
        $[32] = levelFilter;
        $[33] = t11;
        $[34] = t13;
        $[35] = t15;
        $[36] = t17;
        $[37] = t19;
        $[38] = t21;
        $[39] = t22;
    } else {
        t22 = $[39];
    }
    let t23;
    let t24;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = ({
            "LogViewer[<TextField>.onChange]": (e_0)=>setSearchTerm(e_0.target.value)
        })["LogViewer[<TextField>.onChange]"];
        t24 = {
            flexGrow: 1,
            minWidth: 200
        };
        $[40] = t23;
        $[41] = t24;
    } else {
        t23 = $[40];
        t24 = $[41];
    }
    let t25;
    if ($[42] !== searchTerm) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
            size: "small",
            placeholder: "Search logs...",
            value: searchTerm,
            onChange: t23,
            sx: t24
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 295,
            columnNumber: 11
        }, this);
        $[42] = searchTerm;
        $[43] = t25;
    } else {
        t25 = $[43];
    }
    let t26;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Clear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 303,
            columnNumber: 11
        }, this);
        $[44] = t26;
    } else {
        t26 = $[44];
    }
    let t27;
    if ($[45] !== onClear) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: "Clear all logs",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                size: "small",
                onClick: onClear,
                color: "error",
                children: t26
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                lineNumber: 310,
                columnNumber: 43
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 310,
            columnNumber: 11
        }, this);
        $[45] = onClear;
        $[46] = t27;
    } else {
        t27 = $[46];
    }
    let t28;
    if ($[47] !== t22 || $[48] !== t25 || $[49] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
            direction: "row",
            spacing: 1,
            sx: t7,
            flexWrap: "wrap",
            children: [
                t22,
                t25,
                t27
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 318,
            columnNumber: 11
        }, this);
        $[47] = t22;
        $[48] = t25;
        $[49] = t27;
        $[50] = t28;
    } else {
        t28 = $[50];
    }
    let t29;
    if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
        t29 = {
            mb: 1
        };
        $[51] = t29;
    } else {
        t29 = $[51];
    }
    let t30;
    if ($[52] !== counts.error) {
        t30 = counts.error > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                lineNumber: 337,
                columnNumber: 43
            }, this),
            label: counts.error,
            size: "small",
            color: "error",
            variant: "outlined"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 337,
            columnNumber: 31
        }, this);
        $[52] = counts.error;
        $[53] = t30;
    } else {
        t30 = $[53];
    }
    let t31;
    if ($[54] !== counts.warn) {
        t31 = counts.warn > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                lineNumber: 345,
                columnNumber: 42
            }, this),
            label: counts.warn,
            size: "small",
            color: "warning",
            variant: "outlined"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 345,
            columnNumber: 30
        }, this);
        $[54] = counts.warn;
        $[55] = t31;
    } else {
        t31 = $[55];
    }
    const t32 = `${filteredLogs.length} / ${logs.length} shown`;
    let t33;
    if ($[56] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            label: t32,
            size: "small",
            variant: "outlined"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 354,
            columnNumber: 11
        }, this);
        $[56] = t32;
        $[57] = t33;
    } else {
        t33 = $[57];
    }
    let t34;
    if ($[58] !== t30 || $[59] !== t31 || $[60] !== t33) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
            direction: "row",
            spacing: 1,
            sx: t29,
            children: [
                t30,
                t31,
                t33
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 362,
            columnNumber: 11
        }, this);
        $[58] = t30;
        $[59] = t31;
        $[60] = t33;
        $[61] = t34;
    } else {
        t34 = $[61];
    }
    let t35;
    if ($[62] === Symbol.for("react.memo_cache_sentinel")) {
        t35 = {
            flexGrow: 1,
            overflow: "auto",
            border: 1,
            borderColor: "divider",
            borderRadius: 1,
            p: 1
        };
        $[62] = t35;
    } else {
        t35 = $[62];
    }
    let t36;
    if ($[63] !== filteredLogs || $[64] !== logs.length) {
        t36 = filteredLogs.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            textAlign: "center",
            sx: {
                py: 4
            },
            children: logs.length === 0 ? "No logs captured yet" : "No logs match filters"
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 386,
            columnNumber: 39
        }, this) : filteredLogs.map(_LogViewerFilteredLogsMap);
        $[63] = filteredLogs;
        $[64] = logs.length;
        $[65] = t36;
    } else {
        t36 = $[65];
    }
    let t37;
    if ($[66] !== t36) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            ref: scrollRef,
            sx: t35,
            children: t36
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 397,
            columnNumber: 11
        }, this);
        $[66] = t36;
        $[67] = t37;
    } else {
        t37 = $[67];
    }
    let t38;
    if ($[68] !== t28 || $[69] !== t34 || $[70] !== t37) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t6,
            children: [
                t28,
                t34,
                t37
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
            lineNumber: 405,
            columnNumber: 11
        }, this);
        $[68] = t28;
        $[69] = t34;
        $[70] = t37;
        $[71] = t38;
    } else {
        t38 = $[71];
    }
    return t38;
}
_s(LogViewer, "/bQ1eYdA0ffGtCafoxrjeS6fKZ8=");
_c1 = LogViewer;
function _LogViewerFilteredLogsMap(log_1, index) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            p: 1,
            mb: 0.5,
            borderLeft: 3,
            borderColor: log_1.level === "error" ? "error.main" : log_1.level === "warn" ? "warning.main" : log_1.level === "info" ? "info.main" : "divider",
            bgcolor: getLogColor(log_1.level),
            borderRadius: 0.5
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                direction: "row",
                spacing: 1,
                alignItems: "center",
                sx: {
                    mb: 0.5
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LogLevelIcon, {
                        level: log_1.level
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                        lineNumber: 425,
                        columnNumber: 8
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        color: "text.secondary",
                        sx: {
                            fontFamily: "monospace"
                        },
                        children: new Date(log_1.timestamp).toLocaleTimeString()
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                        lineNumber: 425,
                        columnNumber: 44
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                        label: log_1.level.toUpperCase(),
                        size: "small",
                        sx: {
                            fontSize: 9,
                            height: 18
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                        lineNumber: 427,
                        columnNumber: 71
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                lineNumber: 423,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                sx: {
                    fontFamily: "monospace",
                    fontSize: 11,
                    whiteSpace: "pre-wrap",
                    wordBreak: "break-word"
                },
                children: log_1.message
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                lineNumber: 430,
                columnNumber: 20
            }, this),
            log_1.stack && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "caption",
                sx: {
                    display: "block",
                    mt: 0.5,
                    fontFamily: "monospace",
                    fontSize: 9,
                    color: "text.secondary",
                    whiteSpace: "pre-wrap"
                },
                children: log_1.stack
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
                lineNumber: 435,
                columnNumber: 52
            }, this)
        ]
    }, `${log_1.timestamp}-${index}`, true, {
        fileName: "[project]/src/components/DebugPanel/LogViewer.tsx",
        lineNumber: 416,
        columnNumber: 10
    }, this);
}
function _LogViewerLogsReduce(acc, log_0) {
    acc[log_0.level] = (acc[log_0.level] || 0) + 1;
    return acc;
}
const __TURBOPACK__default__export__ = LogViewer;
var _c, _c1;
__turbopack_context__.k.register(_c, "LogLevelIcon");
__turbopack_context__.k.register(_c1, "LogViewer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/DebugPanel/DebugPanel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DebugPanel",
    ()=>DebugPanel,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * DebugPanel - Main debug panel component
 * 
 * A drawer-based UI for debugging application state, components, and logs.
 * Uses Material-UI for styling and layout.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Drawer$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Drawer/Drawer.js [app-client] (ecmascript) <export default as Drawer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tabs/Tabs.js [app-client] (ecmascript) <export default as Tabs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tab/Tab.js [app-client] (ecmascript) <export default as Tab>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Toolbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Toolbar/Toolbar.js [app-client] (ecmascript) <export default as Toolbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript) <export default as Snackbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AccountTree$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AccountTree.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ListAlt$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ListAlt.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Storage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Speed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Speed.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DebugPanel$2f$StateInspector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/DebugPanel/StateInspector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DebugPanel$2f$ComponentTreeView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/DebugPanel/ComponentTreeView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DebugPanel$2f$LogViewer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/DebugPanel/LogViewer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$debug$2f$discordWebhook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/debug/discordWebhook.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$debug$2f$uploadDebugArtifact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/debug/uploadDebugArtifact.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function TabPanel(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "d3d63bf0de7459281225bc46d201544ee8608aef354fcacca77dce805ffca1ff") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d3d63bf0de7459281225bc46d201544ee8608aef354fcacca77dce805ffca1ff";
    }
    const { children, value, currentValue } = t0;
    const t1 = value !== currentValue;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            height: "100%",
            overflow: "auto"
        };
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    let t3;
    if ($[2] !== children || $[3] !== currentValue || $[4] !== value) {
        t3 = value === currentValue && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                p: 2,
                height: "100%"
            },
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
            lineNumber: 61,
            columnNumber: 36
        }, this);
        $[2] = children;
        $[3] = currentValue;
        $[4] = value;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== t1 || $[7] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            role: "tabpanel",
            hidden: t1,
            style: t2,
            children: t3
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
            lineNumber: 74,
            columnNumber: 10
        }, this);
        $[6] = t1;
        $[7] = t3;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    return t4;
}
_c = TabPanel;
function DebugPanel({ open, onClose, defaultTab = 'components', position = 'right', width = 600, height = '100%' }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('common');
    const [currentTab, setCurrentTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultTab);
    const [componentTree, setComponentTree] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [logs, setLogs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [stateSnapshot, setStateSnapshot] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [snackbar, setSnackbar] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        open: false,
        message: '',
        severity: 'info'
    });
    const [discordDialog, setDiscordDialog] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [userDescription, setUserDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [userContact, setUserContact] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // Subscribe to component tree updates
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DebugPanel.useEffect": ()=>{
            if (!open || ("TURBOPACK compile-time value", "object") === 'undefined') return;
            const store = window.__COMPONENT_TREE__;
            if (!store) return;
            const unsubscribe = store.subscribe({
                "DebugPanel.useEffect.unsubscribe": (tree)=>{
                    setComponentTree(tree);
                }
            }["DebugPanel.useEffect.unsubscribe"]);
            // Initial load
            setComponentTree(store.getTree());
            return unsubscribe;
        }
    }["DebugPanel.useEffect"], [
        open
    ]);
    // Subscribe to log updates
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DebugPanel.useEffect": ()=>{
            if (!open || ("TURBOPACK compile-time value", "object") === 'undefined') return;
            const logger = window.__DEBUG_LOGGER__;
            if (!logger) return;
            const unsubscribe_0 = logger.subscribe({
                "DebugPanel.useEffect.unsubscribe_0": (newLog)=>{
                    if (newLog) {
                        setLogs({
                            "DebugPanel.useEffect.unsubscribe_0": (prev)=>[
                                    ...prev,
                                    newLog
                                ]
                        }["DebugPanel.useEffect.unsubscribe_0"]);
                    } else {
                        // Clear event
                        setLogs([]);
                    }
                }
            }["DebugPanel.useEffect.unsubscribe_0"]);
            // Initial load
            setLogs(logger.getLogs());
            return unsubscribe_0;
        }
    }["DebugPanel.useEffect"], [
        open
    ]);
    const handleTabChange = (_event, newValue)=>{
        setCurrentTab(newValue);
    };
    const handleClearLogs = ()=>{
        if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.__DEBUG_LOGGER__) {
            window.__DEBUG_LOGGER__.clear();
        }
    };
    const handleRefreshState = async ()=>{
        const { captureStateSnapshot } = await __turbopack_context__.A("[project]/src/utils/debug/StateSnapshot.ts [app-client] (ecmascript, async loader)");
        const snapshot = await captureStateSnapshot();
        setStateSnapshot(snapshot);
    };
    const handleExportState = async (snapshot_0)=>{
        const json = JSON.stringify(snapshot_0, null, 2);
        const blob = new Blob([
            json
        ], {
            type: 'application/json'
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `state-snapshot-${snapshot_0.timestamp}.json`;
        a.click();
        URL.revokeObjectURL(url);
        setSnackbar({
            open: true,
            message: 'Diagnostic snapshot downloaded',
            severity: 'success'
        });
    };
    const handleSendToDiscord = async (snapshot_1)=>{
        setDiscordDialog(true);
    };
    const handleConfirmSendToDiscord = async ()=>{
        if (!stateSnapshot) return;
        setDiscordDialog(false);
        setSnackbar({
            open: true,
            message: 'Uploading diagnostic artifact to S3...',
            severity: 'info'
        });
        const webhookUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$debug$2f$discordWebhook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDiscordWebhookUrl"])();
        if (!webhookUrl) {
            setSnackbar({
                open: true,
                message: 'Discord webhook not configured',
                severity: 'error'
            });
            return;
        }
        try {
            // Upload artifact to S3 and get signed URL
            const { url: artifactUrl, key } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$debug$2f$uploadDebugArtifact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadDebugArtifact"])(stateSnapshot);
            console.log('[DebugPanel] Artifact uploaded to S3:', key);
            setSnackbar({
                open: true,
                message: 'Sending to Discord...',
                severity: 'info'
            });
            // Send to Discord with S3 URL
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$debug$2f$discordWebhook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sendToDiscord"])({
                snapshot: stateSnapshot,
                description: userDescription || undefined,
                userContact: userContact || undefined,
                artifactUrl
            }, {
                webhookUrl
            });
            if (result.success) {
                setSnackbar({
                    open: true,
                    message: '✅ Diagnostic sent to support team! (S3 link expires in 30 days)',
                    severity: 'success'
                });
                setUserDescription('');
                setUserContact('');
            } else {
                setSnackbar({
                    open: true,
                    message: `Failed to send: ${result.error}`,
                    severity: 'error'
                });
            }
        } catch (error) {
            console.error('[DebugPanel] Error uploading/sending diagnostic:', error);
            setSnackbar({
                open: true,
                message: `Upload failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
                severity: 'error'
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Drawer$3e$__["Drawer"], {
                anchor: position === 'bottom' ? 'bottom' : position,
                open: open,
                onClose: onClose,
                variant: "persistent",
                sx: {
                    '& .MuiDrawer-paper': {
                        width: position !== 'bottom' ? width : '100%',
                        height: position === 'bottom' ? height : '100%',
                        display: 'flex',
                        flexDirection: 'column'
                    }
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Toolbar$3e$__["Toolbar"], {
                        sx: {
                            minHeight: 48
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "h6",
                                sx: {
                                    flexGrow: 1
                                },
                                children: "Debug Panel"
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 256,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                edge: "end",
                                onClick: onClose,
                                "aria-label": t('actions.close'),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                    lineNumber: 262,
                                    columnNumber: 11
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 261,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                        lineNumber: 253,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {}, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                        lineNumber: 266,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__["Tabs"], {
                        value: currentTab,
                        onChange: handleTabChange,
                        variant: "scrollable",
                        scrollButtons: "auto",
                        sx: {
                            borderBottom: 1,
                            borderColor: 'divider',
                            minHeight: 40
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                value: "components",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AccountTree$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                    lineNumber: 274,
                                    columnNumber: 39
                                }, this),
                                label: "Components",
                                iconPosition: "start",
                                sx: {
                                    minHeight: 40
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 274,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                value: "logs",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ListAlt$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                    lineNumber: 277,
                                    columnNumber: 33
                                }, this),
                                label: `Logs (${logs.length})`,
                                iconPosition: "start",
                                sx: {
                                    minHeight: 40
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 277,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                value: "state",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                    lineNumber: 280,
                                    columnNumber: 34
                                }, this),
                                label: "State",
                                iconPosition: "start",
                                sx: {
                                    minHeight: 40
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 280,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                value: "performance",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Speed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                    lineNumber: 283,
                                    columnNumber: 40
                                }, this),
                                label: "Performance",
                                iconPosition: "start",
                                sx: {
                                    minHeight: 40
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 283,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                        lineNumber: 269,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            flexGrow: 1,
                            overflow: 'hidden',
                            display: 'flex',
                            flexDirection: 'column'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
                                value: "components",
                                currentValue: currentTab,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DebugPanel$2f$ComponentTreeView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ComponentTreeView"], {
                                    tree: componentTree
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                    lineNumber: 296,
                                    columnNumber: 11
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 295,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
                                value: "logs",
                                currentValue: currentTab,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DebugPanel$2f$LogViewer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogViewer"], {
                                    logs: logs,
                                    onClear: handleClearLogs
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                    lineNumber: 300,
                                    columnNumber: 11
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 299,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
                                value: "state",
                                currentValue: currentTab,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DebugPanel$2f$StateInspector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StateInspector"], {
                                    snapshot: stateSnapshot,
                                    onRefresh: handleRefreshState,
                                    onExport: handleExportState,
                                    onSendToDiscord: handleSendToDiscord
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                    lineNumber: 304,
                                    columnNumber: 11
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 303,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
                                value: "performance",
                                currentValue: currentTab,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    color: "text.secondary",
                                    children: "Performance metrics coming soon..."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                    lineNumber: 308,
                                    columnNumber: 11
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 307,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                        lineNumber: 289,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                lineNumber: 244,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                open: discordDialog,
                onClose: ()=>setDiscordDialog(false),
                maxWidth: "sm",
                fullWidth: true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                        children: "Send Diagnostic to Support"
                    }, void 0, false, {
                        fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                        lineNumber: 317,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                color: "text.secondary",
                                sx: {
                                    mb: 2
                                },
                                children: "This will send your diagnostic snapshot to our support team via Discord. Your data will be sanitized to remove sensitive information."
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 319,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                fullWidth: true,
                                label: "Describe the issue (optional)",
                                multiline: true,
                                rows: 3,
                                value: userDescription,
                                onChange: (e)=>setUserDescription(e.target.value),
                                placeholder: "What were you doing when the problem occurred?",
                                sx: {
                                    mb: 2,
                                    mt: 1
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 325,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                fullWidth: true,
                                label: "Your email or contact (optional)",
                                value: userContact,
                                onChange: (e_0)=>setUserContact(e_0.target.value),
                                placeholder: "So we can follow up with you"
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 329,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                        lineNumber: 318,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                onClick: ()=>setDiscordDialog(false),
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 332,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                onClick: handleConfirmSendToDiscord,
                                variant: "contained",
                                color: "primary",
                                children: "Send to Support"
                            }, void 0, false, {
                                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                                lineNumber: 333,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                        lineNumber: 331,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                lineNumber: 316,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
                open: snackbar.open,
                autoHideDuration: 4000,
                onClose: ()=>setSnackbar({
                        ...snackbar,
                        open: false
                    }),
                anchorOrigin: {
                    vertical: 'bottom',
                    horizontal: 'right'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                    severity: snackbar.severity,
                    onClose: ()=>setSnackbar({
                            ...snackbar,
                            open: false
                        }),
                    children: snackbar.message
                }, void 0, false, {
                    fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                    lineNumber: 347,
                    columnNumber: 7
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/DebugPanel/DebugPanel.tsx",
                lineNumber: 340,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true);
}
_s(DebugPanel, "j4gWiUY75lQLtm9gf1Iuf6WYhHA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c1 = DebugPanel;
const __TURBOPACK__default__export__ = DebugPanel;
var _c, _c1;
__turbopack_context__.k.register(_c, "TabPanel");
__turbopack_context__.k.register(_c1, "DebugPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/DebugPanel/useDebugPanel.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "disableDebugMode",
    ()=>disableDebugMode,
    "enableDebugMode",
    ()=>enableDebugMode,
    "isDebugModeEnabled",
    ()=>isDebugModeEnabled,
    "useDebugPanel",
    ()=>useDebugPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * useDebugPanel hook
 * 
 * Provides easy access to debug panel state and controls
 * 
 * Debug panel can be enabled in production via:
 * - localStorage flag: localStorage.setItem('debug-mode-enabled', 'true')
 * - Keyboard shortcut: Cmd/Ctrl + Shift + D
 * - Secret trigger: Click menu icon 7 times within 3 seconds
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const DEBUG_MODE_KEY = 'debug-mode-enabled';
function isDebugModeEnabled() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return localStorage.getItem(DEBUG_MODE_KEY) === 'true';
}
function enableDebugMode() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    localStorage.setItem(DEBUG_MODE_KEY, 'true');
    console.log('🐛 Debug mode enabled. Refresh page to activate debug panel.');
}
function disableDebugMode() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    localStorage.removeItem(DEBUG_MODE_KEY);
    console.log('🐛 Debug mode disabled.');
}
function useDebugPanel() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "8dc8ba97b6603a74887086fe3eed30735b6a06e699d3a37623dc3dca74f7e037") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8dc8ba97b6603a74887086fe3eed30735b6a06e699d3a37623dc3dca74f7e037";
    }
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [debugModeEnabled, setDebugModeEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = ({
            "useDebugPanel[useEffect()]": ()=>{
                setDebugModeEnabled(isDebugModeEnabled());
            }
        })["useDebugPanel[useEffect()]"];
        t1 = [];
        $[1] = t0;
        $[2] = t1;
    } else {
        t0 = $[1];
        t1 = $[2];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "useDebugPanel[open]": ()=>setIsOpen(true)
        })["useDebugPanel[open]"];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const open = t2;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "useDebugPanel[close]": ()=>setIsOpen(false)
        })["useDebugPanel[close]"];
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const close = t3;
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "useDebugPanel[toggle]": ()=>setIsOpen(_useDebugPanelToggleSetIsOpen)
        })["useDebugPanel[toggle]"];
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const toggle = t4;
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "useDebugPanel[handleEnableDebugMode]": ()=>{
                enableDebugMode();
                setDebugModeEnabled(true);
            }
        })["useDebugPanel[handleEnableDebugMode]"];
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    const handleEnableDebugMode = t5;
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "useDebugPanel[handleDisableDebugMode]": ()=>{
                disableDebugMode();
                setDebugModeEnabled(false);
                setIsOpen(false);
            }
        })["useDebugPanel[handleDisableDebugMode]"];
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    const handleDisableDebugMode = t6;
    let t7;
    let t8;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = ({
            "useDebugPanel[useEffect()]": ()=>{
                const handleKeyDown = {
                    "useDebugPanel[useEffect() > handleKeyDown]": (event)=>{
                        if ((event.metaKey || event.ctrlKey) && event.shiftKey && event.key === "D") {
                            event.preventDefault();
                            toggle();
                        }
                    }
                }["useDebugPanel[useEffect() > handleKeyDown]"];
                window.addEventListener("keydown", handleKeyDown);
                return ()=>window.removeEventListener("keydown", handleKeyDown);
            }
        })["useDebugPanel[useEffect()]"];
        t8 = [
            toggle
        ];
        $[8] = t7;
        $[9] = t8;
    } else {
        t7 = $[8];
        t8 = $[9];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t7, t8);
    let t9;
    if ($[10] !== debugModeEnabled || $[11] !== isOpen) {
        t9 = {
            isOpen,
            open,
            close,
            toggle,
            isDebugModeEnabled: debugModeEnabled,
            enableDebugMode: handleEnableDebugMode,
            disableDebugMode: handleDisableDebugMode
        };
        $[10] = debugModeEnabled;
        $[11] = isOpen;
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    return t9;
}
_s(useDebugPanel, "GXm9QxqYyq4N9UgzLFP0FCOsheY=");
function _useDebugPanelToggleSetIsOpen(prev) {
    return !prev;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/DebugPanel/DebugPanelProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DebugPanelProvider",
    ()=>DebugPanelProvider,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * Global DebugPanel provider
 * 
 * Wraps the application and provides debug panel access
 * 
 * Debug panel is enabled:
 * - Always in development mode
 * - In production when localStorage 'debug-mode-enabled' is 'true'
 * 
 * To enable in production:
 * - Click menu icon 7 times within 3 seconds
 * - Or set localStorage: localStorage.setItem('debug-mode-enabled', 'true')
 * - Then use keyboard shortcut: Cmd/Ctrl + Shift + D to open
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DebugPanel$2f$DebugPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/DebugPanel/DebugPanel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DebugPanel$2f$useDebugPanel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/DebugPanel/useDebugPanel.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function DebugPanelProvider(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "e7a222566ca769dc69ab9ec12eb2c7347991333e3aec9f0992203b2eb50cab73") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e7a222566ca769dc69ab9ec12eb2c7347991333e3aec9f0992203b2eb50cab73";
    }
    const { children, enabled } = t0;
    const { isOpen, close } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DebugPanel$2f$useDebugPanel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebugPanel"])();
    const [mounted, setMounted] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [shouldEnable, setShouldEnable] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(enabled ?? ("TURBOPACK compile-time value", "development") === "development");
    let t1;
    let t2;
    if ($[1] !== enabled) {
        t1 = ({
            "DebugPanelProvider[useEffect()]": ()=>{
                setMounted(true);
                if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
                ;
            }
        })["DebugPanelProvider[useEffect()]"];
        t2 = [
            enabled
        ];
        $[1] = enabled;
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t1, t2);
    if (!shouldEnable || !mounted) {
        let t3;
        if ($[4] !== children) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: children
            }, void 0, false);
            $[4] = children;
            $[5] = t3;
        } else {
            t3 = $[5];
        }
        return t3;
    }
    let t3;
    if ($[6] !== close || $[7] !== isOpen) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DebugPanel$2f$DebugPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DebugPanel"], {
            open: isOpen,
            onClose: close
        }, void 0, false, {
            fileName: "[project]/src/components/DebugPanel/DebugPanelProvider.tsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[6] = close;
        $[7] = isOpen;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== children || $[10] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                children,
                t3
            ]
        }, void 0, true);
        $[9] = children;
        $[10] = t3;
        $[11] = t4;
    } else {
        t4 = $[11];
    }
    return t4;
}
_s(DebugPanelProvider, "3lM6+H1OKy/0jNA2OBoTShrRnHQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DebugPanel$2f$useDebugPanel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebugPanel"]
    ];
});
_c = DebugPanelProvider;
const __TURBOPACK__default__export__ = DebugPanelProvider;
var _c;
__turbopack_context__.k.register(_c, "DebugPanelProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_DebugPanel_092o0wd._.js.map