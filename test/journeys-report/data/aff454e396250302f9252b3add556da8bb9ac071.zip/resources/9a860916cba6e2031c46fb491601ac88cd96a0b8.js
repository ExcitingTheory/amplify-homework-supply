(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Workbook/JoinWorkbookDialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>JoinWorkbookDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview JoinWorkbookDialog — Dialog for instructors to join a student's
 * workbook session by entering the student's Grade ID or workbook link.
 * Navigates to /workbook/{unitId} on success.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tabs/Tabs.js [app-client] (ecmascript) <export default as Tabs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tab/Tab.js [app-client] (ecmascript) <export default as Tab>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EditNote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/EditNote.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Notifications$2f$NotificationInvitations$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Notifications/NotificationInvitations.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function JoinWorkbookDialog({ open, onClose, onJoin }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('components');
    const tCommon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('common');
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [tab, setTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const handleInputChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "JoinWorkbookDialog.useCallback[handleInputChange]": (e)=>{
            setInput(e.target.value.trim());
            setError(null);
        }
    }["JoinWorkbookDialog.useCallback[handleInputChange]"], []);
    const handleJoin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "JoinWorkbookDialog.useCallback[handleJoin]": async ()=>{
            if (!input) {
                setError(t('workbook.joinDialog.emptyInput'));
                return;
            }
            setLoading(true);
            setError(null);
            try {
                // Extract ID from URL or use directly
                let unitId = input;
                const urlMatch = input.match(/\/workbook\/([a-zA-Z0-9-]+)/);
                if (urlMatch) {
                    unitId = urlMatch[1];
                }
                // Verify the unit exists
                const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const { data: unit, errors } = await client.models.Unit.get({
                    id: unitId
                });
                if (errors?.length || !unit) {
                    setError(t('workbook.joinDialog.notFound'));
                    setLoading(false);
                    return;
                }
                onJoin({
                    unitId: unit.id,
                    gradeId: ''
                });
                setInput('');
                setError(null);
            } catch (err) {
                console.error('[JoinWorkbookDialog] Error:', err);
                setError(err.message || t('workbook.joinDialog.error'));
            } finally{
                setLoading(false);
            }
        }
    }["JoinWorkbookDialog.useCallback[handleJoin]"], [
        input,
        onJoin,
        t
    ]);
    const handleKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "JoinWorkbookDialog.useCallback[handleKeyDown]": (e_0)=>{
            if (e_0.key === 'Enter' && input && !loading) {
                handleJoin();
            }
        }
    }["JoinWorkbookDialog.useCallback[handleKeyDown]"], [
        handleJoin,
        input,
        loading
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
        open: open,
        onClose: onClose,
        maxWidth: "xs",
        fullWidth: true,
        "aria-labelledby": "join-workbook-dialog-title",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                id: "join-workbook-dialog-title",
                sx: {
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EditNote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        color: "primary"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                        lineNumber: 99,
                        columnNumber: 9
                    }, this),
                    t('workbook.joinDialog.title')
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                lineNumber: 94,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__["Tabs"], {
                        value: tab,
                        onChange: (_, v)=>setTab(v),
                        sx: {
                            mb: 2,
                            borderBottom: 1,
                            borderColor: 'divider'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                label: t('workbook.joinDialog.tabLink')
                            }, void 0, false, {
                                fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                                lineNumber: 109,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                label: t('workbook.joinDialog.tabInvitations')
                            }, void 0, false, {
                                fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                                lineNumber: 110,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this),
                    tab === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                color: "text.secondary",
                                sx: {
                                    mb: 2
                                },
                                children: t('workbook.joinDialog.description')
                            }, void 0, false, {
                                fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                                lineNumber: 114,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                autoFocus: true,
                                fullWidth: true,
                                label: t('workbook.joinDialog.inputLabel'),
                                value: input,
                                onChange: handleInputChange,
                                onKeyDown: handleKeyDown,
                                placeholder: "https://...workbook/abc-123 or abc-123",
                                disabled: loading,
                                sx: {
                                    mb: 1
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                                lineNumber: 120,
                                columnNumber: 13
                            }, this),
                            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                severity: "error",
                                sx: {
                                    mt: 1
                                },
                                children: error
                            }, void 0, false, {
                                fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                                lineNumber: 124,
                                columnNumber: 23
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                        lineNumber: 113,
                        columnNumber: 23
                    }, this),
                    tab === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Notifications$2f$NotificationInvitations$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        types: [
                            'WORKBOOK_SESSION_INVITE'
                        ],
                        onJoin: (notification)=>{
                            if (notification.linkPath) {
                                const match = notification.linkPath.match(/\/workbook\/([a-zA-Z0-9-]+)/);
                                if (match) {
                                    onJoin({
                                        unitId: match[1],
                                        gradeId: ''
                                    });
                                    onClose();
                                }
                            }
                        },
                        joinLabel: t('workbook.joinDialog.joinButton'),
                        emptyMessage: t('workbook.joinDialog.noInvitations')
                    }, void 0, false, {
                        fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                        lineNumber: 131,
                        columnNumber: 23
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                lineNumber: 103,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                sx: {
                    px: 3,
                    pb: 2
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        onClick: onClose,
                        disabled: loading,
                        children: tCommon('actions.cancel')
                    }, void 0, false, {
                        fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                        lineNumber: 149,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        variant: "contained",
                        onClick: handleJoin,
                        disabled: !input || loading,
                        startIcon: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                            variant: "circular",
                            width: 16,
                            height: 16
                        }, void 0, false, {
                            fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                            lineNumber: 152,
                            columnNumber: 108
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EditNote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                            lineNumber: 152,
                            columnNumber: 165
                        }, this),
                        children: loading ? t('workbook.joinDialog.joining') : t('workbook.joinDialog.joinButton')
                    }, void 0, false, {
                        fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                        lineNumber: 152,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
                lineNumber: 145,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Workbook/JoinWorkbookDialog.tsx",
        lineNumber: 93,
        columnNumber: 10
    }, this);
}
_s(JoinWorkbookDialog, "pamp1EKl7tKMjkI4U/5K/FRxhZo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = JoinWorkbookDialog;
var _c;
__turbopack_context__.k.register(_c, "JoinWorkbookDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Workbook/JoinWorkbookDialog.tsx [app-client] (ecmascript) <export default as JoinWorkbookDialog>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "JoinWorkbookDialog",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$JoinWorkbookDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$JoinWorkbookDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Workbook/JoinWorkbookDialog.tsx [app-client] (ecmascript)");
}),
"[project]/src/components/Workbook/CommentGutterIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CommentGutterIcon",
    ()=>CommentGutterIcon,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Badge/Badge.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChatBubbleOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ChatBubbleOutline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChatBubble$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ChatBubble.js [app-client] (ecmascript)");
;
;
;
;
;
;
function CommentGutterIcon(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "ff3e25b1686da434330dc5bf53d95538ec81469ee2212a66c105910769f3e3e7") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "ff3e25b1686da434330dc5bf53d95538ec81469ee2212a66c105910769f3e3e7";
    }
    const { commentCount, unresolvedCount, onClick } = t0;
    if (commentCount === 0) {
        let t1;
        if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
            t1 = {
                opacity: 0.3,
                "&:hover": {
                    opacity: 1
                }
            };
            $[1] = t1;
        } else {
            t1 = $[1];
        }
        let t2;
        if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChatBubbleOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fontSize: "small"
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/CommentGutterIcon.tsx",
                lineNumber: 48,
                columnNumber: 12
            }, this);
            $[2] = t2;
        } else {
            t2 = $[2];
        }
        let t3;
        if ($[3] !== onClick) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                size: "small",
                onClick: onClick,
                sx: t1,
                title: "Add comment",
                children: t2
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/CommentGutterIcon.tsx",
                lineNumber: 55,
                columnNumber: 12
            }, this);
            $[3] = onClick;
            $[4] = t3;
        } else {
            t3 = $[4];
        }
        return t3;
    }
    const t1 = `${unresolvedCount} unresolved comments`;
    let t2;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChatBubble$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentGutterIcon.tsx",
            lineNumber: 66,
            columnNumber: 10
        }, this);
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    let t3;
    if ($[6] !== unresolvedCount) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            badgeContent: unresolvedCount,
            color: "primary",
            max: 9,
            children: t2
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentGutterIcon.tsx",
            lineNumber: 73,
            columnNumber: 10
        }, this);
        $[6] = unresolvedCount;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    let t4;
    if ($[8] !== onClick || $[9] !== t1 || $[10] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            onClick: onClick,
            color: "primary",
            title: t1,
            children: t3
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentGutterIcon.tsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[8] = onClick;
        $[9] = t1;
        $[10] = t3;
        $[11] = t4;
    } else {
        t4 = $[11];
    }
    return t4;
}
_c = CommentGutterIcon;
const __TURBOPACK__default__export__ = CommentGutterIcon;
var _c;
__turbopack_context__.k.register(_c, "CommentGutterIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Workbook/CommentThreadDrawer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CommentThreadDrawer",
    ()=>CommentThreadDrawer,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * CommentThreadDrawer — Side drawer for viewing and adding comment threads on a block.
 *
 * Uses useWorkbookComments hook for live data.
 *
 * @module CommentThreadDrawer
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Drawer/Drawer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Collapse/Collapse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircleOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircleOutline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Reply$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Reply.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Send.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// ============================================================================
// Sub-components
// ============================================================================
function ReplyItem(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(25);
    if ($[0] !== "6c510f9c45bdb0adcb94155c254b454ce7efd6fc07ee809e77b54969e6e7df01") {
        for(let $i = 0; $i < 25; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6c510f9c45bdb0adcb94155c254b454ce7efd6fc07ee809e77b54969e6e7df01";
    }
    const { reply } = t0;
    let t1;
    if ($[1] !== reply.createdAt) {
        t1 = new Date(reply.createdAt).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
        });
        $[1] = reply.createdAt;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const time = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            display: "flex",
            gap: 1,
            pl: 4,
            py: 0.5
        };
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            width: 24,
            height: 24,
            fontSize: 12
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== reply.author || $[6] !== reply.displayName) {
        t4 = (reply.displayName || reply.author)?.[0]?.toUpperCase() || "?";
        $[5] = reply.author;
        $[6] = reply.displayName;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: t4
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 105,
            columnNumber: 10
        }, this);
        $[8] = t4;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            flex: 1
        };
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    const t7 = reply.displayName || reply.author;
    let t8;
    if ($[11] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            fontWeight: "bold",
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 123,
            columnNumber: 10
        }, this);
        $[11] = t7;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            ml: 1
        };
        $[13] = t9;
    } else {
        t9 = $[13];
    }
    let t10;
    if ($[14] !== time) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            sx: t9,
            children: time
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 140,
            columnNumber: 11
        }, this);
        $[14] = time;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    let t11;
    if ($[16] !== reply.text) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            children: reply.text
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 148,
            columnNumber: 11
        }, this);
        $[16] = reply.text;
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    if ($[18] !== t10 || $[19] !== t11 || $[20] !== t8) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t6,
            children: [
                t8,
                t10,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 156,
            columnNumber: 11
        }, this);
        $[18] = t10;
        $[19] = t11;
        $[20] = t8;
        $[21] = t12;
    } else {
        t12 = $[21];
    }
    let t13;
    if ($[22] !== t12 || $[23] !== t5) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t2,
            children: [
                t5,
                t12
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 166,
            columnNumber: 11
        }, this);
        $[22] = t12;
        $[23] = t5;
        $[24] = t13;
    } else {
        t13 = $[24];
    }
    return t13;
}
_c = ReplyItem;
function ThreadItem(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(59);
    if ($[0] !== "6c510f9c45bdb0adcb94155c254b454ce7efd6fc07ee809e77b54969e6e7df01") {
        for(let $i = 0; $i < 59; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6c510f9c45bdb0adcb94155c254b454ce7efd6fc07ee809e77b54969e6e7df01";
    }
    const { thread, threadKey, onReply, onResolve } = t0;
    const [replyOpen, setReplyOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [replyText, setReplyText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let t1;
    if ($[1] !== onReply || $[2] !== replyText || $[3] !== threadKey) {
        t1 = ({
            "ThreadItem[handleSendReply]": ()=>{
                if (!replyText.trim()) {
                    return;
                }
                onReply(threadKey, replyText.trim());
                setReplyText("");
                setReplyOpen(false);
            }
        })["ThreadItem[handleSendReply]"];
        $[1] = onReply;
        $[2] = replyText;
        $[3] = threadKey;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    const handleSendReply = t1;
    let t2;
    if ($[5] !== thread.createdAt) {
        t2 = new Date(thread.createdAt).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
        });
        $[5] = thread.createdAt;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    const time = t2;
    const t3 = thread.resolved ? "action.disabledBackground" : "background.paper";
    const t4 = thread.resolved ? "divider" : "primary.light";
    const t5 = thread.resolved ? 0.7 : 1;
    let t6;
    if ($[7] !== t3 || $[8] !== t4 || $[9] !== t5) {
        t6 = {
            p: 1.5,
            mb: 1,
            borderRadius: 1,
            bgcolor: t3,
            border: 1,
            borderColor: t4,
            opacity: t5
        };
        $[7] = t3;
        $[8] = t4;
        $[9] = t5;
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    let t7;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            display: "flex",
            alignItems: "center",
            gap: 1,
            mb: 0.5
        };
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            width: 28,
            height: 28,
            fontSize: 13
        };
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] !== thread.author || $[14] !== thread.displayName) {
        t9 = (thread.displayName || thread.author)?.[0]?.toUpperCase() || "?";
        $[13] = thread.author;
        $[14] = thread.displayName;
        $[15] = t9;
    } else {
        t9 = $[15];
    }
    let t10;
    if ($[16] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t8,
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 278,
            columnNumber: 11
        }, this);
        $[16] = t9;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            flex: 1
        };
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    const t12 = thread.displayName || thread.author;
    let t13;
    if ($[19] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            fontWeight: "bold",
            children: t12
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 296,
            columnNumber: 11
        }, this);
        $[19] = t12;
        $[20] = t13;
    } else {
        t13 = $[20];
    }
    let t14;
    if ($[21] !== time) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            children: time
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 304,
            columnNumber: 11
        }, this);
        $[21] = time;
        $[22] = t14;
    } else {
        t14 = $[22];
    }
    let t15;
    if ($[23] !== t13 || $[24] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t11,
            children: [
                t13,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 312,
            columnNumber: 11
        }, this);
        $[23] = t13;
        $[24] = t14;
        $[25] = t15;
    } else {
        t15 = $[25];
    }
    let t16;
    if ($[26] !== onResolve || $[27] !== thread.resolved || $[28] !== threadKey) {
        t16 = ({
            "ThreadItem[<IconButton>.onClick]": ()=>onResolve(threadKey, !thread.resolved)
        })["ThreadItem[<IconButton>.onClick]"];
        $[26] = onResolve;
        $[27] = thread.resolved;
        $[28] = threadKey;
        $[29] = t16;
    } else {
        t16 = $[29];
    }
    const t17 = thread.resolved ? "Unresolve" : "Resolve";
    let t18;
    if ($[30] !== thread.resolved) {
        t18 = thread.resolved ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            color: "success",
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 334,
            columnNumber: 29
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircleOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 334,
            columnNumber: 84
        }, this);
        $[30] = thread.resolved;
        $[31] = t18;
    } else {
        t18 = $[31];
    }
    let t19;
    if ($[32] !== t16 || $[33] !== t17 || $[34] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            onClick: t16,
            title: t17,
            children: t18
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 342,
            columnNumber: 11
        }, this);
        $[32] = t16;
        $[33] = t17;
        $[34] = t18;
        $[35] = t19;
    } else {
        t19 = $[35];
    }
    let t20;
    if ($[36] !== t10 || $[37] !== t15 || $[38] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t7,
            children: [
                t10,
                t15,
                t19
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 352,
            columnNumber: 11
        }, this);
        $[36] = t10;
        $[37] = t15;
        $[38] = t19;
        $[39] = t20;
    } else {
        t20 = $[39];
    }
    let t21;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = {
            pl: 4.5,
            mb: 0.5
        };
        $[40] = t21;
    } else {
        t21 = $[40];
    }
    let t22;
    if ($[41] !== thread.text) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            sx: t21,
            children: thread.text
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 372,
            columnNumber: 11
        }, this);
        $[41] = thread.text;
        $[42] = t22;
    } else {
        t22 = $[42];
    }
    let t23;
    if ($[43] !== thread.resolved) {
        t23 = thread.resolved && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Resolved",
            size: "small",
            color: "success",
            variant: "outlined",
            sx: {
                ml: 4.5,
                mb: 0.5
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 380,
            columnNumber: 30
        }, this);
        $[43] = thread.resolved;
        $[44] = t23;
    } else {
        t23 = $[44];
    }
    let t24;
    if ($[45] !== thread.replies) {
        t24 = thread.replies.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                mt: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        mb: 0.5
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
                    lineNumber: 393,
                    columnNumber: 8
                }, this),
                thread.replies.map(_ThreadItemThreadRepliesMap)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 391,
            columnNumber: 40
        }, this);
        $[45] = thread.replies;
        $[46] = t24;
    } else {
        t24 = $[46];
    }
    let t25;
    if ($[47] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = {
            mt: 0.5,
            pl: 4
        };
        $[47] = t25;
    } else {
        t25 = $[47];
    }
    let t26;
    if ($[48] !== handleSendReply || $[49] !== replyOpen || $[50] !== replyText) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t25,
            children: !replyOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                size: "small",
                startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Reply$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
                    lineNumber: 413,
                    columnNumber: 71
                }, this),
                onClick: {
                    "ThreadItem[<Button>.onClick]": ()=>setReplyOpen(true)
                }["ThreadItem[<Button>.onClick]"],
                children: "Reply"
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
                lineNumber: 413,
                columnNumber: 39
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                in: replyOpen,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    direction: "row",
                    spacing: 1,
                    alignItems: "flex-end",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            size: "small",
                            placeholder: "Write a reply...",
                            value: replyText,
                            onChange: {
                                "ThreadItem[<TextField>.onChange]": (e)=>setReplyText(e.target.value)
                            }["ThreadItem[<TextField>.onChange]"],
                            onKeyDown: {
                                "ThreadItem[<TextField>.onKeyDown]": (e_0)=>{
                                    if (e_0.key === "Enter" && !e_0.shiftKey) {
                                        e_0.preventDefault();
                                        handleSendReply();
                                    }
                                }
                            }["ThreadItem[<TextField>.onKeyDown]"],
                            multiline: true,
                            maxRows: 3,
                            fullWidth: true,
                            autoFocus: true
                        }, void 0, false, {
                            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
                            lineNumber: 415,
                            columnNumber: 141
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            color: "primary",
                            onClick: handleSendReply,
                            disabled: !replyText.trim(),
                            size: "small",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                fontSize: "small"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
                                lineNumber: 424,
                                columnNumber: 212
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
                            lineNumber: 424,
                            columnNumber: 116
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
                    lineNumber: 415,
                    columnNumber: 84
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
                lineNumber: 415,
                columnNumber: 59
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 413,
            columnNumber: 11
        }, this);
        $[48] = handleSendReply;
        $[49] = replyOpen;
        $[50] = replyText;
        $[51] = t26;
    } else {
        t26 = $[51];
    }
    let t27;
    if ($[52] !== t20 || $[53] !== t22 || $[54] !== t23 || $[55] !== t24 || $[56] !== t26 || $[57] !== t6) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t6,
            children: [
                t20,
                t22,
                t23,
                t24,
                t26
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 434,
            columnNumber: 11
        }, this);
        $[52] = t20;
        $[53] = t22;
        $[54] = t23;
        $[55] = t24;
        $[56] = t26;
        $[57] = t6;
        $[58] = t27;
    } else {
        t27 = $[58];
    }
    return t27;
}
_s(ThreadItem, "9sbU2tcn5nL0JOZUvRGaC3kcQt4=");
_c1 = ThreadItem;
// ============================================================================
// Main Component
// ============================================================================
function _ThreadItemThreadRepliesMap(reply, i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ReplyItem, {
        reply: reply
    }, i, false, {
        fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
        lineNumber: 452,
        columnNumber: 10
    }, this);
}
function CommentThreadDrawer(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(47);
    if ($[0] !== "6c510f9c45bdb0adcb94155c254b454ce7efd6fc07ee809e77b54969e6e7df01") {
        for(let $i = 0; $i < 47; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6c510f9c45bdb0adcb94155c254b454ce7efd6fc07ee809e77b54969e6e7df01";
    }
    const { open, onClose, blockId, threads, onAddComment, onReply, onResolve } = t0;
    const [newCommentText, setNewCommentText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let t1;
    if ($[1] !== newCommentText || $[2] !== onAddComment) {
        t1 = ({
            "CommentThreadDrawer[handleAddComment]": ()=>{
                if (!newCommentText.trim()) {
                    return;
                }
                onAddComment(newCommentText.trim());
                setNewCommentText("");
            }
        })["CommentThreadDrawer[handleAddComment]"];
        $[1] = newCommentText;
        $[2] = onAddComment;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const handleAddComment = t1;
    let t2;
    if ($[4] !== threads) {
        t2 = threads.filter(_CommentThreadDrawerThreadsFilter);
        $[4] = threads;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    const unresolvedCount = t2.length;
    let t3;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            sx: {
                width: 380,
                p: 2
            }
        };
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            display: "flex",
            alignItems: "center",
            mb: 2
        };
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h6",
            sx: {
                flex: 1
            },
            children: "Comments"
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 524,
            columnNumber: 10
        }, this);
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] !== unresolvedCount) {
        t6 = unresolvedCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: `${unresolvedCount} open`,
            size: "small",
            color: "primary",
            sx: {
                mr: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 533,
            columnNumber: 33
        }, this);
        $[9] = unresolvedCount;
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    let t7;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 543,
            columnNumber: 10
        }, this);
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] !== onClose) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: onClose,
            size: "small",
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 550,
            columnNumber: 10
        }, this);
        $[12] = onClose;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] !== t6 || $[15] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t4,
            children: [
                t5,
                t6,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 558,
            columnNumber: 10
        }, this);
        $[14] = t6;
        $[15] = t8;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    let t10;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            flex: 1,
            overflowY: "auto",
            mb: 2
        };
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] !== blockId || $[19] !== onReply || $[20] !== onResolve || $[21] !== threads) {
        t11 = threads.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: {
                textAlign: "center",
                py: 4
            },
            children: "No comments on this block yet"
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 578,
            columnNumber: 34
        }, this) : threads.map({
            "CommentThreadDrawer[threads.map()]": (thread)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ThreadItem, {
                    thread: thread,
                    threadKey: `${blockId}:${thread.id}`,
                    onReply: onReply,
                    onResolve: onResolve
                }, thread.id, false, {
                    fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
                    lineNumber: 582,
                    columnNumber: 55
                }, this)
        }["CommentThreadDrawer[threads.map()]"]);
        $[18] = blockId;
        $[19] = onReply;
        $[20] = onResolve;
        $[21] = threads;
        $[22] = t11;
    } else {
        t11 = $[22];
    }
    let t12;
    if ($[23] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t10,
            children: t11
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 594,
            columnNumber: 11
        }, this);
        $[23] = t11;
        $[24] = t12;
    } else {
        t12 = $[24];
    }
    let t13;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                mb: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 602,
            columnNumber: 11
        }, this);
        $[25] = t13;
    } else {
        t13 = $[25];
    }
    let t14;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = ({
            "CommentThreadDrawer[<TextField>.onChange]": (e)=>setNewCommentText(e.target.value)
        })["CommentThreadDrawer[<TextField>.onChange]"];
        $[26] = t14;
    } else {
        t14 = $[26];
    }
    let t15;
    if ($[27] !== handleAddComment) {
        t15 = ({
            "CommentThreadDrawer[<TextField>.onKeyDown]": (e_0)=>{
                if (e_0.key === "Enter" && !e_0.shiftKey) {
                    e_0.preventDefault();
                    handleAddComment();
                }
            }
        })["CommentThreadDrawer[<TextField>.onKeyDown]"];
        $[27] = handleAddComment;
        $[28] = t15;
    } else {
        t15 = $[28];
    }
    let t16;
    if ($[29] !== newCommentText || $[30] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            placeholder: "Add a comment...",
            value: newCommentText,
            onChange: t14,
            onKeyDown: t15,
            multiline: true,
            maxRows: 3,
            fullWidth: true
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 635,
            columnNumber: 11
        }, this);
        $[29] = newCommentText;
        $[30] = t15;
        $[31] = t16;
    } else {
        t16 = $[31];
    }
    let t17;
    if ($[32] !== newCommentText) {
        t17 = newCommentText.trim();
        $[32] = newCommentText;
        $[33] = t17;
    } else {
        t17 = $[33];
    }
    const t18 = !t17;
    let t19;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 653,
            columnNumber: 11
        }, this);
        $[34] = t19;
    } else {
        t19 = $[34];
    }
    let t20;
    if ($[35] !== handleAddComment || $[36] !== t18) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            color: "primary",
            onClick: handleAddComment,
            disabled: t18,
            children: t19
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 660,
            columnNumber: 11
        }, this);
        $[35] = handleAddComment;
        $[36] = t18;
        $[37] = t20;
    } else {
        t20 = $[37];
    }
    let t21;
    if ($[38] !== t16 || $[39] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            spacing: 1,
            alignItems: "flex-end",
            children: [
                t16,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 669,
            columnNumber: 11
        }, this);
        $[38] = t16;
        $[39] = t20;
        $[40] = t21;
    } else {
        t21 = $[40];
    }
    let t22;
    if ($[41] !== onClose || $[42] !== open || $[43] !== t12 || $[44] !== t21 || $[45] !== t9) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            anchor: "right",
            open: open,
            onClose: onClose,
            PaperProps: t3,
            children: [
                t9,
                t12,
                t13,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/CommentThreadDrawer.tsx",
            lineNumber: 678,
            columnNumber: 11
        }, this);
        $[41] = onClose;
        $[42] = open;
        $[43] = t12;
        $[44] = t21;
        $[45] = t9;
        $[46] = t22;
    } else {
        t22 = $[46];
    }
    return t22;
}
_s1(CommentThreadDrawer, "2KHNoWaJpOF5eoiVMuq90H2S89M=");
_c2 = CommentThreadDrawer;
function _CommentThreadDrawerThreadsFilter(t) {
    return !t.resolved;
}
const __TURBOPACK__default__export__ = CommentThreadDrawer;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ReplyItem");
__turbopack_context__.k.register(_c1, "ThreadItem");
__turbopack_context__.k.register(_c2, "CommentThreadDrawer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Workbook/BlockHistoryTimeline.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BlockHistoryTimeline",
    ()=>BlockHistoryTimeline,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * BlockHistoryTimeline — Collapsible timeline showing change history for a block.
 *
 * Uses useBlockHistory hook for live data from the Yjs history array.
 *
 * @module BlockHistoryTimeline
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Collapse/Collapse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$History$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/History.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Edit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Grade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Grade.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
const fieldIcons = {
    userAnswer: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "small"
    }, void 0, false, {
        fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
        lineNumber: 26,
        columnNumber: 15
    }, ("TURBOPACK compile-time value", void 0)),
    complete: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "small"
    }, void 0, false, {
        fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
        lineNumber: 27,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0)),
    accuracy: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Grade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "small"
    }, void 0, false, {
        fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
        lineNumber: 28,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0))
};
function formatTime(iso) {
    const date = new Date(iso);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 1) return 'just now';
    if (diffMin < 60) return `${diffMin}m ago`;
    const diffHrs = Math.floor(diffMin / 60);
    if (diffHrs < 24) return `${diffHrs}h ago`;
    return date.toLocaleDateString();
}
function formatFieldChange(entry) {
    const { fieldChanged, newValue } = entry;
    if (fieldChanged === 'complete') {
        return newValue ? 'Marked complete' : 'Marked incomplete';
    }
    if (fieldChanged === 'accuracy') {
        return `Accuracy: ${newValue}%`;
    }
    if (fieldChanged === 'userAnswer') {
        const preview = typeof newValue === 'string' ? newValue.slice(0, 60) : String(newValue);
        return `Answer updated: "${preview}${String(newValue).length > 60 ? '...' : ''}"`;
    }
    return `${fieldChanged} changed`;
}
function BlockHistoryTimeline(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(37);
    if ($[0] !== "a337817877a50fa2a6b3da56282d0f41f4fbb867ccf1ad79a859ddfcdba8bcb7") {
        for(let $i = 0; $i < 37; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a337817877a50fa2a6b3da56282d0f41f4fbb867ccf1ad79a859ddfcdba8bcb7";
    }
    const { entries, maxVisible: t1 } = t0;
    const maxVisible = t1 === undefined ? 10 : t1;
    const [expanded, setExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    if (entries.length === 0) {
        return null;
    }
    let t2;
    if ($[1] !== entries || $[2] !== expanded || $[3] !== maxVisible) {
        t2 = expanded ? entries : entries.slice(0, maxVisible);
        $[1] = entries;
        $[2] = expanded;
        $[3] = maxVisible;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const visibleEntries = t2;
    const hasMore = entries.length > maxVisible;
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            display: "flex",
            alignItems: "center",
            gap: 0.5,
            mb: 0.5
        };
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== expanded) {
        t4 = ({
            "BlockHistoryTimeline[<IconButton>.onClick]": ()=>setExpanded(!expanded)
        })["BlockHistoryTimeline[<IconButton>.onClick]"];
        $[6] = expanded;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    const t5 = expanded ? "Collapse history" : "Show history";
    let t6;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$History$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
            lineNumber: 112,
            columnNumber: 10
        }, this);
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] !== t4 || $[10] !== t5) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            onClick: t4,
            title: t5,
            children: t6
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
            lineNumber: 119,
            columnNumber: 10
        }, this);
        $[9] = t4;
        $[10] = t5;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    const t8 = entries.length !== 1 ? "s" : "";
    let t9;
    if ($[12] !== entries.length || $[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            children: [
                entries.length,
                " change",
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
            lineNumber: 129,
            columnNumber: 10
        }, this);
        $[12] = entries.length;
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== t7 || $[16] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t7,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
            lineNumber: 138,
            columnNumber: 11
        }, this);
        $[15] = t7;
        $[16] = t9;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    const t11 = expanded || entries.length <= 3;
    let t12;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            pl: 1
        };
        $[18] = t12;
    } else {
        t12 = $[18];
    }
    let t13;
    if ($[19] !== visibleEntries) {
        let t14;
        if ($[21] !== visibleEntries.length) {
            t14 = ({
                "BlockHistoryTimeline[visibleEntries.map()]": (entry, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            display: "flex",
                            gap: 1,
                            minHeight: 48,
                            position: "relative"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                sx: {
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "center",
                                    minWidth: 32
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        variant: "rounded",
                                        sx: {
                                            width: 28,
                                            height: 28,
                                            bgcolor: entry.fieldChanged === "complete" ? "success.main" : "primary.main",
                                            color: "white"
                                        },
                                        children: fieldIcons[entry.fieldChanged] || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Edit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            fontSize: "small"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
                                            lineNumber: 175,
                                            columnNumber: 51
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
                                        lineNumber: 170,
                                        columnNumber: 14
                                    }, this),
                                    i < visibleEntries.length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        sx: {
                                            width: 2,
                                            flexGrow: 1,
                                            bgcolor: "divider",
                                            my: 0.5
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
                                        lineNumber: 175,
                                        columnNumber: 124
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
                                lineNumber: 165,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                sx: {
                                    pt: 0.3,
                                    pb: 1,
                                    minWidth: 0
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        variant: "body2",
                                        fontSize: 13,
                                        children: formatFieldChange(entry)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
                                        lineNumber: 184,
                                        columnNumber: 14
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        variant: "caption",
                                        color: "text.secondary",
                                        children: [
                                            entry.displayName || entry.userId,
                                            " · ",
                                            formatTime(entry.timestamp)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
                                        lineNumber: 184,
                                        columnNumber: 95
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
                                lineNumber: 180,
                                columnNumber: 25
                            }, this)
                        ]
                    }, i, true, {
                        fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
                        lineNumber: 160,
                        columnNumber: 69
                    }, this)
            })["BlockHistoryTimeline[visibleEntries.map()]"];
            $[21] = visibleEntries.length;
            $[22] = t14;
        } else {
            t14 = $[22];
        }
        t13 = visibleEntries.map(t14);
        $[19] = visibleEntries;
        $[20] = t13;
    } else {
        t13 = $[20];
    }
    let t14;
    if ($[23] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t12,
            children: t13
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
            lineNumber: 199,
            columnNumber: 11
        }, this);
        $[23] = t13;
        $[24] = t14;
    } else {
        t14 = $[24];
    }
    let t15;
    if ($[25] !== entries.length || $[26] !== expanded || $[27] !== hasMore || $[28] !== maxVisible) {
        t15 = hasMore && !expanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "primary",
            sx: {
                cursor: "pointer",
                pl: 1
            },
            onClick: {
                "BlockHistoryTimeline[<Typography>.onClick]": ()=>setExpanded(true)
            }["BlockHistoryTimeline[<Typography>.onClick]"],
            children: [
                "Show ",
                entries.length - maxVisible,
                " more..."
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
            lineNumber: 207,
            columnNumber: 35
        }, this);
        $[25] = entries.length;
        $[26] = expanded;
        $[27] = hasMore;
        $[28] = maxVisible;
        $[29] = t15;
    } else {
        t15 = $[29];
    }
    let t16;
    if ($[30] !== t11 || $[31] !== t14 || $[32] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            in: t11,
            children: [
                t14,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
            lineNumber: 223,
            columnNumber: 11
        }, this);
        $[30] = t11;
        $[31] = t14;
        $[32] = t15;
        $[33] = t16;
    } else {
        t16 = $[33];
    }
    let t17;
    if ($[34] !== t10 || $[35] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t10,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/BlockHistoryTimeline.tsx",
            lineNumber: 233,
            columnNumber: 11
        }, this);
        $[34] = t10;
        $[35] = t16;
        $[36] = t17;
    } else {
        t17 = $[36];
    }
    return t17;
}
_s(BlockHistoryTimeline, "DuL5jiiQQFgbn7gBKAyxwS/H4Ek=");
_c = BlockHistoryTimeline;
const __TURBOPACK__default__export__ = BlockHistoryTimeline;
var _c;
__turbopack_context__.k.register(_c, "BlockHistoryTimeline");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Workbook/ConnectionStatus.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ConnectionStatus",
    ()=>ConnectionStatus,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * Connection Status Indicator
 * 
 * Shows the real-time collaboration connection status.
 * Clicking copies a join code that tutors can use to connect.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript) <export default as Snackbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Wifi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Wifi.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$WifiOff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/WifiOff.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Sync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Sync.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
/**
 * Derive a short 6-char uppercase join code from a grade ID.
 * Deterministic: same gradeId always produces the same code.
 */ function deriveJoinCode(gradeId) {
    if (!gradeId) return '';
    // Use last 6 alphanumeric chars of the ID, uppercased
    const alphanumeric = gradeId.replace(/[^a-zA-Z0-9]/g, '');
    return alphanumeric.slice(-6).toUpperCase();
}
function ConnectionStatus(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(58);
    if ($[0] !== "a3435a81e09f5f526ff07ae4249d2d4caf5f273e1d7cea0ed2840689ca441ed7") {
        for(let $i = 0; $i < 58; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a3435a81e09f5f526ff07ae4249d2d4caf5f273e1d7cea0ed2840689ca441ed7";
    }
    const { size: t1, showLabel: t2 } = t0;
    const size = t1 === undefined ? "small" : t1;
    const showLabel = t2 === undefined ? true : t2;
    const { workbook, workbookEnabled, grade } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const [snackOpen, setSnackOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    grade?.id;
    const t3 = grade?.id;
    let t4;
    if ($[1] !== t3) {
        t4 = deriveJoinCode(t3);
        $[1] = t3;
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    const joinCode = t4;
    let t5;
    if ($[3] !== joinCode) {
        t5 = ({
            "ConnectionStatus[handleClick]": async ()=>{
                if (!joinCode) {
                    return;
                }
                try {
                    await navigator.clipboard.writeText(joinCode);
                    setSnackOpen(true);
                } catch  {
                    setSnackOpen(true);
                }
            }
        })["ConnectionStatus[handleClick]"];
        $[3] = joinCode;
        $[4] = t5;
    } else {
        t5 = $[4];
    }
    const handleClick = t5;
    if (!workbookEnabled || !workbook?.provider) {
        return null;
    }
    const t6 = size === "small" ? 16 : 20;
    let t7;
    if ($[5] !== t6) {
        t7 = {
            fontSize: t6
        };
        $[5] = t6;
        $[6] = t7;
    } else {
        t7 = $[6];
    }
    const t8 = showLabel ? "auto" : "32px";
    let t9;
    if ($[7] !== t7 || $[8] !== t8) {
        t9 = {
            "& .MuiChip-icon": t7,
            minWidth: t8,
            cursor: "pointer"
        };
        $[7] = t7;
        $[8] = t8;
        $[9] = t9;
    } else {
        t9 = $[9];
    }
    const chipSx = t9;
    const tooltipTitle = joinCode ? `Join code: ${joinCode} — click to copy` : "";
    if (!workbook.isConnected) {
        let t10;
        if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$WifiOff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
                lineNumber: 122,
                columnNumber: 13
            }, this);
            $[10] = t10;
        } else {
            t10 = $[10];
        }
        const t11 = showLabel ? "Offline" : undefined;
        let t12;
        if ($[11] !== chipSx || $[12] !== handleClick || $[13] !== size || $[14] !== t11) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                icon: t10,
                label: t11,
                variant: "outlined",
                size: size,
                onClick: handleClick,
                sx: chipSx
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
                lineNumber: 130,
                columnNumber: 13
            }, this);
            $[11] = chipSx;
            $[12] = handleClick;
            $[13] = size;
            $[14] = t11;
            $[15] = t12;
        } else {
            t12 = $[15];
        }
        let t13;
        if ($[16] !== t12 || $[17] !== tooltipTitle) {
            t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                title: tooltipTitle,
                arrow: true,
                children: t12
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
                lineNumber: 141,
                columnNumber: 13
            }, this);
            $[16] = t12;
            $[17] = tooltipTitle;
            $[18] = t13;
        } else {
            t13 = $[18];
        }
        let t14;
        if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
            t14 = ({
                "ConnectionStatus[<Snackbar>.onClose]": ()=>setSnackOpen(false)
            })["ConnectionStatus[<Snackbar>.onClose]"];
            $[19] = t14;
        } else {
            t14 = $[19];
        }
        const t15 = `Join code copied: ${joinCode}`;
        let t16;
        if ($[20] !== snackOpen || $[21] !== t15) {
            t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
                open: snackOpen,
                autoHideDuration: 2000,
                onClose: t14,
                message: t15
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
                lineNumber: 160,
                columnNumber: 13
            }, this);
            $[20] = snackOpen;
            $[21] = t15;
            $[22] = t16;
        } else {
            t16 = $[22];
        }
        let t17;
        if ($[23] !== t13 || $[24] !== t16) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    t13,
                    t16
                ]
            }, void 0, true);
            $[23] = t13;
            $[24] = t16;
            $[25] = t17;
        } else {
            t17 = $[25];
        }
        return t17;
    }
    if (!workbook.isSynced) {
        let t10;
        if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Sync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    animation: "spin 1s linear infinite",
                    "@keyframes spin": {
                        "0%": {
                            transform: "rotate(0deg)"
                        },
                        "100%": {
                            transform: "rotate(360deg)"
                        }
                    }
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
                lineNumber: 181,
                columnNumber: 13
            }, this);
            $[26] = t10;
        } else {
            t10 = $[26];
        }
        const t11 = showLabel ? "Syncing..." : undefined;
        let t12;
        if ($[27] !== chipSx || $[28] !== handleClick || $[29] !== size || $[30] !== t11) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                icon: t10,
                label: t11,
                variant: "outlined",
                size: size,
                onClick: handleClick,
                sx: chipSx
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
                lineNumber: 199,
                columnNumber: 13
            }, this);
            $[27] = chipSx;
            $[28] = handleClick;
            $[29] = size;
            $[30] = t11;
            $[31] = t12;
        } else {
            t12 = $[31];
        }
        let t13;
        if ($[32] !== t12 || $[33] !== tooltipTitle) {
            t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                title: tooltipTitle,
                arrow: true,
                children: t12
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
                lineNumber: 210,
                columnNumber: 13
            }, this);
            $[32] = t12;
            $[33] = tooltipTitle;
            $[34] = t13;
        } else {
            t13 = $[34];
        }
        let t14;
        if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
            t14 = ({
                "ConnectionStatus[<Snackbar>.onClose]": ()=>setSnackOpen(false)
            })["ConnectionStatus[<Snackbar>.onClose]"];
            $[35] = t14;
        } else {
            t14 = $[35];
        }
        const t15 = `Join code copied: ${joinCode}`;
        let t16;
        if ($[36] !== snackOpen || $[37] !== t15) {
            t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
                open: snackOpen,
                autoHideDuration: 2000,
                onClose: t14,
                message: t15
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
                lineNumber: 229,
                columnNumber: 13
            }, this);
            $[36] = snackOpen;
            $[37] = t15;
            $[38] = t16;
        } else {
            t16 = $[38];
        }
        let t17;
        if ($[39] !== t13 || $[40] !== t16) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    t13,
                    t16
                ]
            }, void 0, true);
            $[39] = t13;
            $[40] = t16;
            $[41] = t17;
        } else {
            t17 = $[41];
        }
        return t17;
    }
    let t10;
    if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Wifi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
            lineNumber: 249,
            columnNumber: 11
        }, this);
        $[42] = t10;
    } else {
        t10 = $[42];
    }
    const t11 = showLabel ? "Connected" : undefined;
    let t12;
    if ($[43] !== chipSx || $[44] !== handleClick || $[45] !== size || $[46] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            icon: t10,
            label: t11,
            variant: "outlined",
            size: size,
            onClick: handleClick,
            sx: chipSx
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
            lineNumber: 257,
            columnNumber: 11
        }, this);
        $[43] = chipSx;
        $[44] = handleClick;
        $[45] = size;
        $[46] = t11;
        $[47] = t12;
    } else {
        t12 = $[47];
    }
    let t13;
    if ($[48] !== t12 || $[49] !== tooltipTitle) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: tooltipTitle,
            arrow: true,
            children: t12
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
            lineNumber: 268,
            columnNumber: 11
        }, this);
        $[48] = t12;
        $[49] = tooltipTitle;
        $[50] = t13;
    } else {
        t13 = $[50];
    }
    let t14;
    if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = ({
            "ConnectionStatus[<Snackbar>.onClose]": ()=>setSnackOpen(false)
        })["ConnectionStatus[<Snackbar>.onClose]"];
        $[51] = t14;
    } else {
        t14 = $[51];
    }
    const t15 = `Join code copied: ${joinCode}`;
    let t16;
    if ($[52] !== snackOpen || $[53] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
            open: snackOpen,
            autoHideDuration: 2000,
            onClose: t14,
            message: t15
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/ConnectionStatus.tsx",
            lineNumber: 287,
            columnNumber: 11
        }, this);
        $[52] = snackOpen;
        $[53] = t15;
        $[54] = t16;
    } else {
        t16 = $[54];
    }
    let t17;
    if ($[55] !== t13 || $[56] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t13,
                t16
            ]
        }, void 0, true);
        $[55] = t13;
        $[56] = t16;
        $[57] = t17;
    } else {
        t17 = $[57];
    }
    return t17;
}
_s(ConnectionStatus, "23ejR8z0+7amHOZYieQ++dd4v8g=");
_c = ConnectionStatus;
const __TURBOPACK__default__export__ = ConnectionStatus;
var _c;
__turbopack_context__.k.register(_c, "ConnectionStatus");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Workbook/TutorPresenceBanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TutorPresenceBanner",
    ()=>TutorPresenceBanner,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * Tutor Presence Banner
 * 
 * Displays a notification when tutors join to help with the workbook
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript) <export default as Avatar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AvatarGroup$2f$AvatarGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AvatarGroup$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AvatarGroup/AvatarGroup.js [app-client] (ecmascript) <export default as AvatarGroup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Info.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function TutorPresenceBanner() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(38);
    if ($[0] !== "0f9740b66f72359211267539891c976838596418a65450e86f40f3d6c8bd350a") {
        for(let $i = 0; $i < 38; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0f9740b66f72359211267539891c976838596418a65450e86f40f3d6c8bd350a";
    }
    const { workbook, workbookEnabled } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    if (!workbookEnabled || !workbook?.provider) {
        return null;
    }
    if (!workbook.hasTutorPresent) {
        return null;
    }
    let T0;
    let T1;
    let T2;
    let t0;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let tutors;
    if ($[1] !== workbook.activeTutors) {
        tutors = workbook.activeTutors || [];
        T2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"];
        t6 = "info";
        if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/Workbook/TutorPresenceBanner.tsx",
                lineNumber: 48,
                columnNumber: 12
            }, this);
            $[15] = t7;
        } else {
            t7 = $[15];
        }
        if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
            t8 = {
                mb: 2,
                "& .MuiAlert-message": {
                    width: "100%"
                }
            };
            $[16] = t8;
        } else {
            t8 = $[16];
        }
        T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"];
        t2 = "flex";
        t3 = "center";
        t4 = 2;
        let t9;
        if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = {
                "& .MuiAvatar-root": {
                    width: 32,
                    height: 32
                }
            };
            $[17] = t9;
        } else {
            t9 = $[17];
        }
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AvatarGroup$2f$AvatarGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AvatarGroup$3e$__["AvatarGroup"], {
            max: 3,
            sx: t9,
            children: tutors.map(_TutorPresenceBannerTutorsMap)
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/TutorPresenceBanner.tsx",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"];
        t1 = "body2";
        t0 = tutors.map(_TutorPresenceBannerTutorsMap2).join(", ");
        $[1] = workbook.activeTutors;
        $[2] = T0;
        $[3] = T1;
        $[4] = T2;
        $[5] = t0;
        $[6] = t1;
        $[7] = t2;
        $[8] = t3;
        $[9] = t4;
        $[10] = t5;
        $[11] = t6;
        $[12] = t7;
        $[13] = t8;
        $[14] = tutors;
    } else {
        T0 = $[2];
        T1 = $[3];
        T2 = $[4];
        t0 = $[5];
        t1 = $[6];
        t2 = $[7];
        t3 = $[8];
        t4 = $[9];
        t5 = $[10];
        t6 = $[11];
        t7 = $[12];
        t8 = $[13];
        tutors = $[14];
    }
    let t9;
    if ($[18] !== t0) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
            children: t0
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/TutorPresenceBanner.tsx",
            lineNumber: 115,
            columnNumber: 10
        }, this);
        $[18] = t0;
        $[19] = t9;
    } else {
        t9 = $[19];
    }
    const t10 = tutors.length === 1 ? "is" : "are";
    let t11;
    if ($[20] !== T0 || $[21] !== t1 || $[22] !== t10 || $[23] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            variant: t1,
            children: [
                t9,
                " ",
                t10,
                " here to help you"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/TutorPresenceBanner.tsx",
            lineNumber: 124,
            columnNumber: 11
        }, this);
        $[20] = T0;
        $[21] = t1;
        $[22] = t10;
        $[23] = t9;
        $[24] = t11;
    } else {
        t11 = $[24];
    }
    let t12;
    if ($[25] !== T1 || $[26] !== t11 || $[27] !== t2 || $[28] !== t3 || $[29] !== t4 || $[30] !== t5) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
            display: t2,
            alignItems: t3,
            gap: t4,
            children: [
                t5,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/TutorPresenceBanner.tsx",
            lineNumber: 135,
            columnNumber: 11
        }, this);
        $[25] = T1;
        $[26] = t11;
        $[27] = t2;
        $[28] = t3;
        $[29] = t4;
        $[30] = t5;
        $[31] = t12;
    } else {
        t12 = $[31];
    }
    let t13;
    if ($[32] !== T2 || $[33] !== t12 || $[34] !== t6 || $[35] !== t7 || $[36] !== t8) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T2, {
            severity: t6,
            icon: t7,
            sx: t8,
            children: t12
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/TutorPresenceBanner.tsx",
            lineNumber: 148,
            columnNumber: 11
        }, this);
        $[32] = T2;
        $[33] = t12;
        $[34] = t6;
        $[35] = t7;
        $[36] = t8;
        $[37] = t13;
    } else {
        t13 = $[37];
    }
    return t13;
}
_s(TutorPresenceBanner, "rV4mFLc+qZVBeVJBx3s1FF6mIZY=");
_c = TutorPresenceBanner;
function _TutorPresenceBannerTutorsMap2(tutor_0) {
    return tutor_0.displayName;
}
function _TutorPresenceBannerTutorsMap(tutor, i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__["Avatar"], {
        sx: {
            bgcolor: tutor.color || "#f59e0b"
        },
        title: tutor.displayName,
        children: (tutor.displayName?.[0] || "T").toUpperCase()
    }, i, false, {
        fileName: "[project]/src/components/Workbook/TutorPresenceBanner.tsx",
        lineNumber: 164,
        columnNumber: 10
    }, this);
}
const __TURBOPACK__default__export__ = TutorPresenceBanner;
var _c;
__turbopack_context__.k.register(_c, "TutorPresenceBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Workbook/WorkbookProgress.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WorkbookProgress",
    ()=>WorkbookProgress,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * Workbook Progress Indicator
 * 
 * Shows completion and accuracy stats from collaborative workbook
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript) <export default as Paper>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TrendingUp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
function WorkbookProgress(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(68);
    if ($[0] !== "0f3424f43a82d53cde13c0fb35d3970239e36a17b8d1db13a4e92cea32575655") {
        for(let $i = 0; $i < 68; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0f3424f43a82d53cde13c0fb35d3970239e36a17b8d1db13a4e92cea32575655";
    }
    const { detailed: t1, variant: t2 } = t0;
    const detailed = t1 === undefined ? false : t1;
    const variant = t2 === undefined ? "default" : t2;
    const { workbookStats, workbookEnabled, workbook } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    if (!workbookEnabled || !workbook?.provider) {
        return null;
    }
    let t3;
    if ($[1] !== workbookStats) {
        t3 = workbookStats || {
            completion: 0,
            accuracy: 0,
            totalBlocks: 0,
            completeBlocks: 0
        };
        $[1] = workbookStats;
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    const { completion, accuracy, totalBlocks, completeBlocks } = t3;
    if (variant === "compact") {
        const t4 = completion === 100 ? "success.main" : "text.secondary";
        let t5;
        if ($[3] !== t4) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    fontSize: 16,
                    color: t4
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 70,
                columnNumber: 12
            }, this);
            $[3] = t4;
            $[4] = t5;
        } else {
            t5 = $[4];
        }
        let t6;
        if ($[5] !== completeBlocks || $[6] !== totalBlocks) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "caption",
                color: "text.secondary",
                children: [
                    completeBlocks,
                    "/",
                    totalBlocks,
                    " complete"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 81,
                columnNumber: 12
            }, this);
            $[5] = completeBlocks;
            $[6] = totalBlocks;
            $[7] = t6;
        } else {
            t6 = $[7];
        }
        let t7;
        if ($[8] !== t5 || $[9] !== t6) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                display: "flex",
                alignItems: "center",
                gap: 1,
                children: [
                    t5,
                    t6
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 90,
                columnNumber: 12
            }, this);
            $[8] = t5;
            $[9] = t6;
            $[10] = t7;
        } else {
            t7 = $[10];
        }
        return t7;
    }
    if (variant === "detailed") {
        let t4;
        let t5;
        if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = {
                p: 2
            };
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "subtitle2",
                gutterBottom: true,
                children: "Progress"
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 106,
                columnNumber: 12
            }, this);
            $[11] = t4;
            $[12] = t5;
        } else {
            t4 = $[11];
            t5 = $[12];
        }
        let t6;
        if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "caption",
                color: "text.secondary",
                children: "Completion"
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 115,
                columnNumber: 12
            }, this);
            $[13] = t6;
        } else {
            t6 = $[13];
        }
        let t7;
        if ($[14] !== completion) {
            t7 = Math.round(completion);
            $[14] = completion;
            $[15] = t7;
        } else {
            t7 = $[15];
        }
        let t8;
        if ($[16] !== t7) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                display: "flex",
                justifyContent: "space-between",
                mb: 0.5,
                children: [
                    t6,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        fontWeight: "medium",
                        children: [
                            t7,
                            "%"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                        lineNumber: 130,
                        columnNumber: 76
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 130,
                columnNumber: 12
            }, this);
            $[16] = t7;
            $[17] = t8;
        } else {
            t8 = $[17];
        }
        let t9;
        if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = {
                height: 8,
                borderRadius: 4
            };
            $[18] = t9;
        } else {
            t9 = $[18];
        }
        let t10;
        if ($[19] !== completion) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                variant: "determinate",
                value: completion,
                sx: t9
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 148,
                columnNumber: 13
            }, this);
            $[19] = completion;
            $[20] = t10;
        } else {
            t10 = $[20];
        }
        let t11;
        if ($[21] !== t10 || $[22] !== t8) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                mb: 2,
                children: [
                    t8,
                    t10
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 156,
                columnNumber: 13
            }, this);
            $[21] = t10;
            $[22] = t8;
            $[23] = t11;
        } else {
            t11 = $[23];
        }
        let t12;
        if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "caption",
                color: "text.secondary",
                children: "Accuracy"
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 165,
                columnNumber: 13
            }, this);
            $[24] = t12;
        } else {
            t12 = $[24];
        }
        let t13;
        if ($[25] !== accuracy) {
            t13 = Math.round(accuracy);
            $[25] = accuracy;
            $[26] = t13;
        } else {
            t13 = $[26];
        }
        let t14;
        if ($[27] !== t13) {
            t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                display: "flex",
                justifyContent: "space-between",
                mb: 0.5,
                children: [
                    t12,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        fontWeight: "medium",
                        children: [
                            t13,
                            "%"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                        lineNumber: 180,
                        columnNumber: 78
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 180,
                columnNumber: 13
            }, this);
            $[27] = t13;
            $[28] = t14;
        } else {
            t14 = $[28];
        }
        const t15 = accuracy >= 80 ? "success" : accuracy >= 60 ? "warning" : "error";
        let t16;
        if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
            t16 = {
                height: 8,
                borderRadius: 4
            };
            $[29] = t16;
        } else {
            t16 = $[29];
        }
        let t17;
        if ($[30] !== accuracy || $[31] !== t15) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                variant: "determinate",
                value: accuracy,
                color: t15,
                sx: t16
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 199,
                columnNumber: 13
            }, this);
            $[30] = accuracy;
            $[31] = t15;
            $[32] = t17;
        } else {
            t17 = $[32];
        }
        let t18;
        if ($[33] !== t14 || $[34] !== t17) {
            t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                children: [
                    t14,
                    t17
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 208,
                columnNumber: 13
            }, this);
            $[33] = t14;
            $[34] = t17;
            $[35] = t18;
        } else {
            t18 = $[35];
        }
        let t19;
        if ($[36] !== completeBlocks || $[37] !== totalBlocks) {
            t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "caption",
                color: "text.secondary",
                children: [
                    completeBlocks,
                    " of ",
                    totalBlocks,
                    " questions"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 217,
                columnNumber: 13
            }, this);
            $[36] = completeBlocks;
            $[37] = totalBlocks;
            $[38] = t19;
        } else {
            t19 = $[38];
        }
        let t20;
        if ($[39] !== completion) {
            t20 = completion === 100 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 16,
                            color: "success.main"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                        lineNumber: 226,
                        columnNumber: 85
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        color: "success.main",
                        fontWeight: "medium",
                        children: "Complete!"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                        lineNumber: 229,
                        columnNumber: 14
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 226,
                columnNumber: 35
            }, this);
            $[39] = completion;
            $[40] = t20;
        } else {
            t20 = $[40];
        }
        let t21;
        if ($[41] !== t19 || $[42] !== t20) {
            t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                mt: 2,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                children: [
                    t19,
                    t20
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 237,
                columnNumber: 13
            }, this);
            $[41] = t19;
            $[42] = t20;
            $[43] = t21;
        } else {
            t21 = $[43];
        }
        let t22;
        if ($[44] !== t11 || $[45] !== t18 || $[46] !== t21) {
            t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
                variant: "outlined",
                sx: t4,
                children: [
                    t5,
                    t11,
                    t18,
                    t21
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                lineNumber: 246,
                columnNumber: 13
            }, this);
            $[44] = t11;
            $[45] = t18;
            $[46] = t21;
            $[47] = t22;
        } else {
            t22 = $[47];
        }
        return t22;
    }
    let t4;
    if ($[48] !== completeBlocks || $[49] !== totalBlocks) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            fontWeight: "medium",
            children: [
                "Progress: ",
                completeBlocks,
                "/",
                totalBlocks
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
            lineNumber: 258,
            columnNumber: 10
        }, this);
        $[48] = completeBlocks;
        $[49] = totalBlocks;
        $[50] = t4;
    } else {
        t4 = $[50];
    }
    let t5;
    if ($[51] !== completion) {
        t5 = Math.round(completion);
        $[51] = completion;
        $[52] = t5;
    } else {
        t5 = $[52];
    }
    let t6;
    if ($[53] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            children: [
                t5,
                "%"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
            lineNumber: 275,
            columnNumber: 10
        }, this);
        $[53] = t5;
        $[54] = t6;
    } else {
        t6 = $[54];
    }
    let t7;
    if ($[55] !== t4 || $[56] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            display: "flex",
            justifyContent: "space-between",
            mb: 1,
            children: [
                t4,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
            lineNumber: 283,
            columnNumber: 10
        }, this);
        $[55] = t4;
        $[56] = t6;
        $[57] = t7;
    } else {
        t7 = $[57];
    }
    let t8;
    if ($[58] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            height: 6,
            borderRadius: 3
        };
        $[58] = t8;
    } else {
        t8 = $[58];
    }
    let t9;
    if ($[59] !== completion) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
            variant: "determinate",
            value: completion,
            sx: t8
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
            lineNumber: 302,
            columnNumber: 10
        }, this);
        $[59] = completion;
        $[60] = t9;
    } else {
        t9 = $[60];
    }
    let t10;
    if ($[61] !== accuracy || $[62] !== detailed) {
        t10 = detailed && accuracy > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            display: "flex",
            alignItems: "center",
            gap: 0.5,
            mt: 1,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TrendingUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        fontSize: 16,
                        color: "text.secondary"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                    lineNumber: 310,
                    columnNumber: 96
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "caption",
                    color: "text.secondary",
                    children: [
                        "Accuracy: ",
                        Math.round(accuracy),
                        "%"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
                    lineNumber: 313,
                    columnNumber: 12
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
            lineNumber: 310,
            columnNumber: 39
        }, this);
        $[61] = accuracy;
        $[62] = detailed;
        $[63] = t10;
    } else {
        t10 = $[63];
    }
    let t11;
    if ($[64] !== t10 || $[65] !== t7 || $[66] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            children: [
                t7,
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/WorkbookProgress.tsx",
            lineNumber: 322,
            columnNumber: 11
        }, this);
        $[64] = t10;
        $[65] = t7;
        $[66] = t9;
        $[67] = t11;
    } else {
        t11 = $[67];
    }
    return t11;
}
_s(WorkbookProgress, "FQ5xcAJ9ndCj2uoV23/Lk9X7d6Q=");
_c = WorkbookProgress;
const __TURBOPACK__default__export__ = WorkbookProgress;
var _c;
__turbopack_context__.k.register(_c, "WorkbookProgress");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Workbook/TutorCursorOverlay.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TutorCursorOverlay",
    ()=>TutorCursorOverlay,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * Tutor Cursor Overlay
 * 
 * Renders floating colored indicators showing which blocks
 * tutors are currently viewing in the workbook.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript) <export default as Avatar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/workbookHooks.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
function TutorCursorOverlay() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "9643a7ed5f9e42e3a70e5e9a337393fd639196864346be279f53209cdf07a6a2") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9643a7ed5f9e42e3a70e5e9a337393fd639196864346be279f53209cdf07a6a2";
    }
    const { workbook, workbookEnabled } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const tutors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTutorPresence"])(workbook?.provider ?? null);
    if (!workbookEnabled || !workbook?.provider || tutors.length === 0) {
        return null;
    }
    let grouped;
    if ($[1] !== tutors) {
        grouped = {};
        for (const tutor of tutors){
            const blockId = tutor.cursor?.blockId;
            if (!blockId) {
                continue;
            }
            if (!grouped[blockId]) {
                grouped[blockId] = [];
            }
            grouped[blockId].push(tutor);
        }
        $[1] = tutors;
        $[2] = grouped;
    } else {
        grouped = $[2];
    }
    const tutorsByBlock = grouped;
    let t0;
    if ($[3] !== tutorsByBlock) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: Object.entries(tutorsByBlock).map(_TutorCursorOverlayAnonymous)
        }, void 0, false);
        $[3] = tutorsByBlock;
        $[4] = t0;
    } else {
        t0 = $[4];
    }
    return t0;
}
_s(TutorCursorOverlay, "EjOqYoyKoUKAjgl5Y4N0TjgLkqE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTutorPresence"]
    ];
});
_c = TutorCursorOverlay;
/**
 * Renders a floating tutor avatar marker next to a specific block in the DOM
 */ function _TutorCursorOverlayAnonymous(t0) {
    const [blockId_0, blockTutors] = t0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TutorBlockMarker, {
        blockId: blockId_0,
        tutors: blockTutors
    }, blockId_0, false, {
        fileName: "[project]/src/components/Workbook/TutorCursorOverlay.tsx",
        lineNumber: 64,
        columnNumber: 10
    }, this);
}
function TutorBlockMarker(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "9643a7ed5f9e42e3a70e5e9a337393fd639196864346be279f53209cdf07a6a2") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9643a7ed5f9e42e3a70e5e9a337393fd639196864346be279f53209cdf07a6a2";
    }
    const { blockId, tutors } = t0;
    const [position, setPosition] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const markerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    let t1;
    let t2;
    if ($[1] !== blockId) {
        t1 = ({
            "TutorBlockMarker[useEffect()]": ()=>{
                const findBlockElement = {
                    "TutorBlockMarker[useEffect() > findBlockElement]": ()=>{
                        const el = document.querySelector(`[data-lexical-key="${blockId}"]`) || document.getElementById(blockId);
                        if (!el) {
                            setPosition(null);
                            return;
                        }
                        const scrollContainer = el.closest(".editor");
                        if (!scrollContainer) {
                            setPosition(null);
                            return;
                        }
                        const containerRect = scrollContainer.getBoundingClientRect();
                        const elRect = el.getBoundingClientRect();
                        setPosition({
                            top: elRect.top - containerRect.top + scrollContainer.scrollTop,
                            left: -28
                        });
                    }
                }["TutorBlockMarker[useEffect() > findBlockElement]"];
                findBlockElement();
                const scrollContainer_0 = document.querySelector(".editor[data-tour=\"workbook\"]");
                if (scrollContainer_0) {
                    scrollContainer_0.addEventListener("scroll", findBlockElement, {
                        passive: true
                    });
                }
                window.addEventListener("resize", findBlockElement, {
                    passive: true
                });
                return ()=>{
                    if (scrollContainer_0) {
                        scrollContainer_0.removeEventListener("scroll", findBlockElement);
                    }
                    window.removeEventListener("resize", findBlockElement);
                };
            }
        })["TutorBlockMarker[useEffect()]"];
        t2 = [
            blockId
        ];
        $[1] = blockId;
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t1, t2);
    if (!position) {
        return null;
    }
    let t3;
    if ($[4] !== position.left || $[5] !== position.top) {
        t3 = {
            position: "absolute",
            top: position.top,
            left: position.left,
            zIndex: 5,
            display: "flex",
            flexDirection: "column",
            gap: 0.25,
            transition: "top 0.2s ease",
            pointerEvents: "auto"
        };
        $[4] = position.left;
        $[5] = position.top;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== tutors) {
        t4 = tutors.map(_TutorBlockMarkerTutorsMap);
        $[7] = tutors;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    if ($[9] !== t3 || $[10] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            ref: markerRef,
            sx: t3,
            children: t4
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/TutorCursorOverlay.tsx",
            lineNumber: 164,
            columnNumber: 10
        }, this);
        $[9] = t3;
        $[10] = t4;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    return t5;
}
_s1(TutorBlockMarker, "XU0SOOu1lWe4KOr1AbCsyUR37M4=");
_c1 = TutorBlockMarker;
function _TutorBlockMarkerTutorsMap(tutor) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
        title: tutor.displayName || "Tutor",
        placement: "left",
        arrow: true,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__["Avatar"], {
            sx: {
                width: 24,
                height: 24,
                fontSize: "0.7rem",
                bgcolor: tutor.color || "#f59e0b",
                border: "2px solid",
                borderColor: "background.paper",
                cursor: "default"
            },
            children: (tutor.displayName?.[0] || "T").toUpperCase()
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/TutorCursorOverlay.tsx",
            lineNumber: 174,
            columnNumber: 107
        }, this)
    }, tutor.clientId, false, {
        fileName: "[project]/src/components/Workbook/TutorCursorOverlay.tsx",
        lineNumber: 174,
        columnNumber: 10
    }, this);
}
const __TURBOPACK__default__export__ = TutorCursorOverlay;
var _c, _c1;
__turbopack_context__.k.register(_c, "TutorCursorOverlay");
__turbopack_context__.k.register(_c1, "TutorBlockMarker");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Workbook/WorkbookInviteShare.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WorkbookInviteShare",
    ()=>WorkbookInviteShare
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * WorkbookInviteShare — Share/invite UI for collaborative workbook sessions.
 * Shows a share button that opens a popover with the workbook URL, a copy
 * button, and the current participant list.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Popover$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Popover/Popover.js [app-client] (ecmascript) <export default as Popover>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript) <export default as Avatar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$InputAdornment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputAdornment$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputAdornment/InputAdornment.js [app-client] (ecmascript) <export default as InputAdornment>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Share$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Share.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ContentCopy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ContentCopy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Check.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
// ============================================================================
// Helpers
// ============================================================================
function getShareUrl(workbookId) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return `${window.location.origin}/workbook/${workbookId}`;
}
function WorkbookInviteShare(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(80);
    if ($[0] !== "e242181a93461fdde32e20d229366c39c7e0711e447e363e79464190a7edac56") {
        for(let $i = 0; $i < 80; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e242181a93461fdde32e20d229366c39c7e0711e447e363e79464190a7edac56";
    }
    const { users, workbookId, isConnected: t1 } = t0;
    t1 === undefined ? true : t1;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const [anchorEl, setAnchorEl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [copied, setCopied] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t2;
    if ($[1] !== workbookId) {
        t2 = getShareUrl(workbookId);
        $[1] = workbookId;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const shareUrl = t2;
    const open = Boolean(anchorEl);
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "WorkbookInviteShare[handleOpen]": (event)=>{
                setAnchorEl(event.currentTarget);
            }
        })["WorkbookInviteShare[handleOpen]"];
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const handleOpen = t3;
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "WorkbookInviteShare[handleClose]": ()=>{
                setAnchorEl(null);
                setCopied(false);
            }
        })["WorkbookInviteShare[handleClose]"];
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    const handleClose = t4;
    let t5;
    if ($[5] !== shareUrl) {
        t5 = ({
            "WorkbookInviteShare[handleCopy]": async ()=>{
                try {
                    await navigator.clipboard.writeText(shareUrl);
                    setCopied(true);
                    setTimeout({
                        "WorkbookInviteShare[handleCopy > setTimeout()]": ()=>setCopied(false)
                    }["WorkbookInviteShare[handleCopy > setTimeout()]"], 2000);
                } catch  {
                    const input = document.createElement("input");
                    input.value = shareUrl;
                    document.body.appendChild(input);
                    input.select();
                    document.execCommand("copy");
                    document.body.removeChild(input);
                    setCopied(true);
                    setTimeout({
                        "WorkbookInviteShare[handleCopy > setTimeout()]": ()=>setCopied(false)
                    }["WorkbookInviteShare[handleCopy > setTimeout()]"], 2000);
                }
            }
        })["WorkbookInviteShare[handleCopy]"];
        $[5] = shareUrl;
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    const handleCopy = t5;
    let t6;
    if ($[7] !== t) {
        t6 = t("workbook.invite.shareTooltip");
        $[7] = t;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    const t7 = open ? "primary" : "default";
    let t8;
    if ($[9] !== t) {
        t8 = t("workbook.invite.shareTooltip");
        $[9] = t;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Share$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 144,
            columnNumber: 10
        }, this);
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    let t10;
    if ($[12] !== t7 || $[13] !== t8) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            size: "small",
            onClick: handleOpen,
            color: t7,
            "aria-label": t8,
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 151,
            columnNumber: 11
        }, this);
        $[12] = t7;
        $[13] = t8;
        $[14] = t10;
    } else {
        t10 = $[14];
    }
    let t11;
    if ($[15] !== t10 || $[16] !== t6) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: t6,
            children: t10
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 160,
            columnNumber: 11
        }, this);
        $[15] = t10;
        $[16] = t6;
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    let t13;
    let t14;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            vertical: "bottom",
            horizontal: "right"
        };
        t13 = {
            vertical: "top",
            horizontal: "right"
        };
        t14 = {
            paper: {
                sx: {
                    p: 2,
                    width: 340,
                    maxWidth: "90vw"
                }
            }
        };
        $[18] = t12;
        $[19] = t13;
        $[20] = t14;
    } else {
        t12 = $[18];
        t13 = $[19];
        t14 = $[20];
    }
    let t15;
    if ($[21] !== t) {
        t15 = t("workbook.invite.title");
        $[21] = t;
        $[22] = t15;
    } else {
        t15 = $[22];
    }
    let t16;
    if ($[23] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "subtitle2",
            gutterBottom: true,
            children: t15
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 206,
            columnNumber: 11
        }, this);
        $[23] = t15;
        $[24] = t16;
    } else {
        t16 = $[24];
    }
    let t17;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = {
            display: "block",
            mb: 1.5
        };
        $[25] = t17;
    } else {
        t17 = $[25];
    }
    let t18;
    if ($[26] !== t) {
        t18 = t("workbook.invite.description");
        $[26] = t;
        $[27] = t18;
    } else {
        t18 = $[27];
    }
    let t19;
    if ($[28] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            sx: t17,
            children: t18
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 232,
            columnNumber: 11
        }, this);
        $[28] = t18;
        $[29] = t19;
    } else {
        t19 = $[29];
    }
    let t20;
    if ($[30] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$InputAdornment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputAdornment$3e$__["InputAdornment"], {
            position: "start",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fontSize: "small",
                color: "action"
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
                lineNumber: 240,
                columnNumber: 44
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 240,
            columnNumber: 11
        }, this);
        $[30] = t20;
    } else {
        t20 = $[30];
    }
    const t21 = copied ? "success" : "default";
    let t22;
    if ($[31] !== t) {
        t22 = t("workbook.invite.copy");
        $[31] = t;
        $[32] = t22;
    } else {
        t22 = $[32];
    }
    let t23;
    if ($[33] !== copied) {
        t23 = copied ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 256,
            columnNumber: 20
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ContentCopy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 256,
            columnNumber: 53
        }, this);
        $[33] = copied;
        $[34] = t23;
    } else {
        t23 = $[34];
    }
    let t24;
    if ($[35] !== handleCopy || $[36] !== t21 || $[37] !== t22 || $[38] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$InputAdornment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputAdornment$3e$__["InputAdornment"], {
            position: "end",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                size: "small",
                onClick: handleCopy,
                color: t21,
                "aria-label": t22,
                children: t23
            }, void 0, false, {
                fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
                lineNumber: 264,
                columnNumber: 42
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 264,
            columnNumber: 11
        }, this);
        $[35] = handleCopy;
        $[36] = t21;
        $[37] = t22;
        $[38] = t23;
        $[39] = t24;
    } else {
        t24 = $[39];
    }
    let t25;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = {
            fontFamily: "monospace",
            fontSize: "0.75rem"
        };
        $[40] = t25;
    } else {
        t25 = $[40];
    }
    let t26;
    if ($[41] !== t24) {
        t26 = {
            input: {
                readOnly: true,
                startAdornment: t20,
                endAdornment: t24,
                sx: t25
            }
        };
        $[41] = t24;
        $[42] = t26;
    } else {
        t26 = $[42];
    }
    let t27;
    if ($[43] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = {
            mb: 1
        };
        $[43] = t27;
    } else {
        t27 = $[43];
    }
    let t28;
    if ($[44] !== shareUrl || $[45] !== t26) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
            fullWidth: true,
            size: "small",
            value: shareUrl,
            slotProps: t26,
            sx: t27
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 309,
            columnNumber: 11
        }, this);
        $[44] = shareUrl;
        $[45] = t26;
        $[46] = t28;
    } else {
        t28 = $[46];
    }
    let t29;
    if ($[47] !== copied) {
        t29 = copied ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 318,
            columnNumber: 20
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ContentCopy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 318,
            columnNumber: 36
        }, this);
        $[47] = copied;
        $[48] = t29;
    } else {
        t29 = $[48];
    }
    const t30 = copied ? "success" : "primary";
    let t31;
    if ($[49] === Symbol.for("react.memo_cache_sentinel")) {
        t31 = {
            mb: 2
        };
        $[49] = t31;
    } else {
        t31 = $[49];
    }
    let t32;
    if ($[50] !== copied || $[51] !== t) {
        t32 = copied ? t("workbook.invite.copied") : t("workbook.invite.copyLink");
        $[50] = copied;
        $[51] = t;
        $[52] = t32;
    } else {
        t32 = $[52];
    }
    let t33;
    if ($[53] !== handleCopy || $[54] !== t29 || $[55] !== t30 || $[56] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            fullWidth: true,
            variant: "outlined",
            size: "small",
            startIcon: t29,
            onClick: handleCopy,
            color: t30,
            sx: t31,
            children: t32
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 345,
            columnNumber: 11
        }, this);
        $[53] = handleCopy;
        $[54] = t29;
        $[55] = t30;
        $[56] = t32;
        $[57] = t33;
    } else {
        t33 = $[57];
    }
    let t34;
    if ($[58] === Symbol.for("react.memo_cache_sentinel")) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
            sx: {
                mb: 1.5
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 356,
            columnNumber: 11
        }, this);
        $[58] = t34;
    } else {
        t34 = $[58];
    }
    let t35;
    if ($[59] === Symbol.for("react.memo_cache_sentinel")) {
        t35 = {
            display: "block",
            mb: 1
        };
        $[59] = t35;
    } else {
        t35 = $[59];
    }
    let t36;
    if ($[60] !== t) {
        t36 = t("workbook.invite.currentlyOnline");
        $[60] = t;
        $[61] = t36;
    } else {
        t36 = $[61];
    }
    let t37;
    if ($[62] !== t36 || $[63] !== users.length) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            sx: t35,
            children: [
                t36,
                " (",
                users.length,
                ")"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 383,
            columnNumber: 11
        }, this);
        $[62] = t36;
        $[63] = users.length;
        $[64] = t37;
    } else {
        t37 = $[64];
    }
    let t38;
    if ($[65] !== t || $[66] !== users) {
        t38 = users.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "body2",
            color: "text.secondary",
            sx: {
                textAlign: "center",
                py: 1
            },
            children: t("workbook.invite.noOthers")
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 392,
            columnNumber: 32
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                flexDirection: "column",
                gap: 0.5
            },
            children: users.map({
                "WorkbookInviteShare[users.map()]": (user)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            display: "flex",
                            alignItems: "center",
                            gap: 1,
                            py: 0.5,
                            opacity: user.isIdle ? 0.5 : 1
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__["Avatar"], {
                                sx: {
                                    width: 24,
                                    height: 24,
                                    fontSize: "0.7rem",
                                    bgcolor: user.color || "#6366f1"
                                },
                                children: (user.displayName?.[0] || user.username?.[0] || "?").toUpperCase()
                            }, void 0, false, {
                                fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
                                lineNumber: 406,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                sx: {
                                    flex: 1
                                },
                                children: user.displayName || user.username
                            }, void 0, false, {
                                fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
                                lineNumber: 411,
                                columnNumber: 91
                            }, this),
                            user.role && user.role !== "student" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                size: "small",
                                label: user.role,
                                variant: "outlined",
                                sx: {
                                    height: 20,
                                    fontSize: "0.65rem"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
                                lineNumber: 413,
                                columnNumber: 103
                            }, this),
                            user.isIdle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "caption",
                                color: "text.secondary",
                                children: t("workbook.invite.idle")
                            }, void 0, false, {
                                fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
                                lineNumber: 416,
                                columnNumber: 33
                            }, this)
                        ]
                    }, user.clientId, true, {
                        fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
                        lineNumber: 400,
                        columnNumber: 53
                    }, this)
            }["WorkbookInviteShare[users.map()]"])
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 395,
            columnNumber: 55
        }, this);
        $[65] = t;
        $[66] = users;
        $[67] = t38;
    } else {
        t38 = $[67];
    }
    let t39;
    if ($[68] !== anchorEl || $[69] !== open || $[70] !== t16 || $[71] !== t19 || $[72] !== t28 || $[73] !== t33 || $[74] !== t37 || $[75] !== t38) {
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Popover$3e$__["Popover"], {
            open: open,
            anchorEl: anchorEl,
            onClose: handleClose,
            anchorOrigin: t12,
            transformOrigin: t13,
            slotProps: t14,
            children: [
                t16,
                t19,
                t28,
                t33,
                t34,
                t37,
                t38
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/WorkbookInviteShare.tsx",
            lineNumber: 426,
            columnNumber: 11
        }, this);
        $[68] = anchorEl;
        $[69] = open;
        $[70] = t16;
        $[71] = t19;
        $[72] = t28;
        $[73] = t33;
        $[74] = t37;
        $[75] = t38;
        $[76] = t39;
    } else {
        t39 = $[76];
    }
    let t40;
    if ($[77] !== t11 || $[78] !== t39) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t11,
                t39
            ]
        }, void 0, true);
        $[77] = t11;
        $[78] = t39;
        $[79] = t40;
    } else {
        t40 = $[79];
    }
    return t40;
}
_s(WorkbookInviteShare, "TDqDgkwTKvsn0T7C1dGLdP4jPMQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = WorkbookInviteShare;
var _c;
__turbopack_context__.k.register(_c, "WorkbookInviteShare");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Workbook/WorkbookPresenceBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WorkbookPresenceBar",
    ()=>WorkbookPresenceBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * WorkbookPresenceBar — shows all connected users as an avatar row
 * in the workbook header, with idle fade for inactive users and a
 * share/invite button for collaborative sessions.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript) <export default as Avatar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AvatarGroup$2f$AvatarGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AvatarGroup$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AvatarGroup/AvatarGroup.js [app-client] (ecmascript) <export default as AvatarGroup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/workbookHooks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$WorkbookInviteShare$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Workbook/WorkbookInviteShare.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
function WorkbookPresenceBar(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    if ($[0] !== "2b6cbed9ca137edac88d5f6023703f537605b680f8075a36ceef1b7054919319") {
        for(let $i = 0; $i < 15; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2b6cbed9ca137edac88d5f6023703f537605b680f8075a36ceef1b7054919319";
    }
    const { max: t1 } = t0;
    const max = t1 === undefined ? 5 : t1;
    const { workbook, workbookEnabled, unit } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const users = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePresenceUsers"])(workbook?.provider ?? null);
    if (!workbookEnabled || !workbook?.provider) {
        return null;
    }
    const workbookId = unit?.id || "";
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            py: 0.5,
            px: 1
        };
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    let t3;
    if ($[2] !== max || $[3] !== users) {
        t3 = users.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AvatarGroup$2f$AvatarGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AvatarGroup$3e$__["AvatarGroup"], {
            max: max,
            sx: {
                "& .MuiAvatar-root": {
                    width: 28,
                    height: 28,
                    fontSize: "0.75rem"
                }
            },
            children: users.map(_WorkbookPresenceBarUsersMap)
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookPresenceBar.tsx",
            lineNumber: 52,
            columnNumber: 30
        }, this);
        $[2] = max;
        $[3] = users;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== users.length) {
        t4 = users.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            children: [
                users.length,
                " ",
                users.length === 1 ? "user" : "users",
                " connected"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/WorkbookPresenceBar.tsx",
            lineNumber: 67,
            columnNumber: 30
        }, this);
        $[5] = users.length;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== users || $[8] !== workbook?.provider || $[9] !== workbookId) {
        t5 = workbookId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$WorkbookInviteShare$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WorkbookInviteShare"], {
            users: users,
            workbookId: workbookId,
            isConnected: !!workbook?.provider
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookPresenceBar.tsx",
            lineNumber: 75,
            columnNumber: 24
        }, this);
        $[7] = users;
        $[8] = workbook?.provider;
        $[9] = workbookId;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    let t6;
    if ($[11] !== t3 || $[12] !== t4 || $[13] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            display: "flex",
            alignItems: "center",
            gap: 1,
            sx: t2,
            children: [
                t3,
                t4,
                t5
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Workbook/WorkbookPresenceBar.tsx",
            lineNumber: 85,
            columnNumber: 10
        }, this);
        $[11] = t3;
        $[12] = t4;
        $[13] = t5;
        $[14] = t6;
    } else {
        t6 = $[14];
    }
    return t6;
}
_s(WorkbookPresenceBar, "SebNb8jIS200u4+7t6HPZxsn/e0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$workbookHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePresenceUsers"]
    ];
});
_c = WorkbookPresenceBar;
function _WorkbookPresenceBarUsersMap(user) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
        title: `${user.displayName || user.username}${user.isIdle ? " (idle)" : ""}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__["Avatar"], {
            sx: {
                bgcolor: user.color || "#6366f1",
                opacity: user.isIdle ? 0.4 : 1,
                transition: "opacity 0.3s ease"
            },
            children: (user.displayName?.[0] || user.username?.[0] || "?").toUpperCase()
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/WorkbookPresenceBar.tsx",
            lineNumber: 96,
            columnNumber: 117
        }, this)
    }, user.clientId, false, {
        fileName: "[project]/src/components/Workbook/WorkbookPresenceBar.tsx",
        lineNumber: 96,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "WorkbookPresenceBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Workbook/AIFeedbackSnackbar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AIFeedbackSnackbar",
    ()=>AIFeedbackSnackbar,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * AIFeedbackSnackbar — Shows a Snackbar when AI feedback is received
 * by another user in the same collaborative session.
 *
 * Listens to the workbook provider's feedback Y.Map for changes
 * and shows a brief notification with the block that was updated.
 *
 * @module AIFeedbackSnackbar
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoAwesome$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AutoAwesome.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function AIFeedbackSnackbar(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    if ($[0] !== "e47943fc662c05abed099b3e35a3f53f8d325217fb1c2c31a0694604c8c7fe71") {
        for(let $i = 0; $i < 15; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e47943fc662c05abed099b3e35a3f53f8d325217fb1c2c31a0694604c8c7fe71";
    }
    const { provider, currentUsername } = t0;
    const [notification, setNotification] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    if ($[1] !== provider) {
        t1 = ({
            "AIFeedbackSnackbar[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const feedbackMap = provider.getMap("feedback");
                const handleFeedbackChange = {
                    "AIFeedbackSnackbar[useEffect() > handleFeedbackChange]": (event)=>{
                        if (event.transaction.local) {
                            return;
                        }
                        for (const [blockId] of event.changes.keys){
                            setNotification({
                                blockId,
                                message: `AI feedback received for block ${blockId.slice(0, 8)}...`
                            });
                            setOpen(true);
                        }
                    }
                }["AIFeedbackSnackbar[useEffect() > handleFeedbackChange]"];
                feedbackMap.observe(handleFeedbackChange);
                return ()=>{
                    feedbackMap.unobserve(handleFeedbackChange);
                };
            }
        })["AIFeedbackSnackbar[useEffect()]"];
        $[1] = provider;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== currentUsername || $[4] !== provider) {
        t2 = [
            provider,
            currentUsername
        ];
        $[3] = currentUsername;
        $[4] = provider;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "AIFeedbackSnackbar[handleClose]": (_event, reason)=>{
                if (reason === "clickaway") {
                    return;
                }
                setOpen(false);
            }
        })["AIFeedbackSnackbar[handleClose]"];
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const handleClose = t3;
    let t4;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            vertical: "bottom",
            horizontal: "left"
        };
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    let t6;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoAwesome$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Workbook/AIFeedbackSnackbar.tsx",
            lineNumber: 110,
            columnNumber: 10
        }, this);
        t6 = {
            width: "100%"
        };
        $[8] = t5;
        $[9] = t6;
    } else {
        t5 = $[8];
        t6 = $[9];
    }
    const t7 = notification?.message || "AI feedback received";
    let t8;
    if ($[10] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClose: handleClose,
            severity: "info",
            variant: "filled",
            icon: t5,
            sx: t6,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/AIFeedbackSnackbar.tsx",
            lineNumber: 123,
            columnNumber: 10
        }, this);
        $[10] = t7;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== open || $[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            autoHideDuration: 5000,
            onClose: handleClose,
            anchorOrigin: t4,
            children: t8
        }, void 0, false, {
            fileName: "[project]/src/components/Workbook/AIFeedbackSnackbar.tsx",
            lineNumber: 131,
            columnNumber: 10
        }, this);
        $[12] = open;
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    return t9;
}
_s(AIFeedbackSnackbar, "1a2TswkTxQcJOELi63cBX3uPFs0=");
_c = AIFeedbackSnackbar;
const __TURBOPACK__default__export__ = AIFeedbackSnackbar;
var _c;
__turbopack_context__.k.register(_c, "AIFeedbackSnackbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_Workbook_0vat2bt._.js.map