(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/instrumentation-client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
/**
 * Client Instrumentation Hook (Next.js 16)
 *
 * Runs before any React code executes in the browser.
 * Sets up earliest-possible performance marks, error tracking, and Web Vitals collection.
 *
 * @see https://nextjs.org/docs/app/api-reference/file-conventions/instrumentation-client
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/web-vitals/dist/web-vitals.js [app-client] (ecmascript)");
;
// Mark application initialization for performance measurement
performance.mark("app-init");
// Global error handler — catches errors before React hydration
window.addEventListener("error", (event)=>{
    console.error("[Client Instrumentation] Uncaught error:", event.error);
});
// Unhandled promise rejection handler
window.addEventListener("unhandledrejection", (event)=>{
    console.error("[Client Instrumentation] Unhandled rejection:", event.reason);
});
// ============================================================================
// Web Vitals — collect LCP, INP, CLS, TTFB, FCP and send to /api/vitals
// ============================================================================
function sendMetric(metric) {
    const payload = JSON.stringify({
        type: "web-vital",
        name: metric.name,
        value: metric.value,
        rating: metric.rating,
        delta: metric.delta,
        id: metric.id,
        path: window.location.pathname,
        timestamp: new Date().toISOString()
    });
    if (navigator.sendBeacon) {
        navigator.sendBeacon("/api/vitals", payload);
    } else {
        fetch("/api/vitals", {
            method: "POST",
            body: payload,
            headers: {
                "Content-Type": "application/json"
            },
            keepalive: true
        }).catch(()=>{});
    }
}
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onLCP"])(sendMetric);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onINP"])(sendMetric);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onCLS"])(sendMetric);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onTTFB"])(sendMetric);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onFCP"])(sendMetric);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=instrumentation-client_ts_03sw2li._.js.map