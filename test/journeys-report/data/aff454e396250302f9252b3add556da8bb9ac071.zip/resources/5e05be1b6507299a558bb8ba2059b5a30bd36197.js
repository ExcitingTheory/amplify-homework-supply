(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$DataGrid$2f$DataGrid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/DataGrid/DataGrid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContentText$2f$DialogContentText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContentText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContentText/DialogContentText.js [app-client] (ecmascript) <export default as DialogContentText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextareaAutosize/TextareaAutosize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Autocomplete/Autocomplete.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useAutocomplete$2f$useAutocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/useAutocomplete/useAutocomplete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/useLexicalNodeSelection.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/CustomAnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PromptMethodSelector$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/PromptMethodSelector.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/apis/fetchAuthSession.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$274953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:274953 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Remove$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Remove.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const filter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useAutocomplete$2f$useAutocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createFilterOptions"])();
const useColumns = (t)=>[
        {
            field: "prompt",
            headerName: t("customAnswerEditor.columnHeaders.prompt"),
            flex: 1,
            minWidth: 100
        },
        {
            field: "answer",
            headerName: t("customAnswerEditor.columnHeaders.answer"),
            flex: 1,
            minWidth: 200
        },
        // {
        //     field: 'actions',
        //     headerName: 'Actions',
        //     sortable: false,
        //     flex: 1,
        //     minWidth: 100,
        //     renderCell: (params) => {
        //         return (
        //             <ActionsMenu
        //                 ids={[params.row.id]}
        //                 removeQuestionIDs={removeQuestionIDs}
        //             />
        //         );
        //     },
        // },
        {
            field: "id",
            headerName: t("customAnswerEditor.columnHeaders.id"),
            flex: 1,
            minWidth: 100,
            sortable: false,
            hide: true
        },
        {
            field: "promptAudio",
            headerName: t("customAnswerEditor.columnHeaders.promptAudio"),
            flex: 1,
            minWidth: 100,
            sortable: false,
            hide: true
        },
        {
            field: "answerAudio",
            headerName: t("customAnswerEditor.columnHeaders.answerAudio"),
            flex: 1,
            minWidth: 100,
            sortable: false,
            hide: true
        },
        {
            field: "hint",
            headerName: t("customAnswerEditor.columnHeaders.hint"),
            flex: 1,
            minWidth: 100,
            sortable: false,
            hide: true
        }
    ];
const __TURBOPACK__default__export__ = /*#__PURE__*/ _c1 = _s(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](_c = _s(function CustomAnswerEditor({ className, format, nodeKey, ids: questionIDs, promptMethod, allowedInput }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.blocks");
    const [value, setValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const [open, toggleOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [gridSelection, setGridSelection] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [dialogValue, setDialogValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        prompt: "",
        answer: "",
        hint: "",
        promptAudio: [],
        answerAudio: []
    });
    const [working, setWorking] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [previewMessage, setPreviewMessage] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const canvasRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const audioRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [audioSrc, setAudioSrc] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const [presignedUrl, setPresignedUrl] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    const doNothing = (e)=>{
        e.preventDefault();
        e.stopPropagation();
    };
    const _r = Math.floor(Math.random() * 255);
    const _g = Math.floor(Math.random() * 255);
    const _b = Math.floor(Math.random() * 255);
    const audioContextRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const sourceRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const analyserRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const customAnswerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const { questionBank } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { unit } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const columns = useColumns(t);
    const rows = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "CustomAnswerEditor.useMemo[rows]": ()=>{
            const result = [];
            if (questionIDs) {
                questionIDs.forEach({
                    "CustomAnswerEditor.useMemo[rows]": (id)=>{
                        const _q = questionBank[id];
                        if (_q) {
                            result.push({
                                id: _q.id,
                                prompt: _q.prompt,
                                answer: _q.answer,
                                hint: _q.hint,
                                promptAudio: _q.audio,
                                answerAudio: _q.answerAudio
                            });
                        }
                    }
                }["CustomAnswerEditor.useMemo[rows]"]);
            }
            return result;
        }
    }["CustomAnswerEditor.useMemo[rows]"], [
        questionIDs,
        questionBank
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "CustomAnswerEditor.useEffect": ()=>{
            const audio = audioRef.current;
            if (!audio) {
                return;
            } else if (audio.srcObject) {
                const tracks = audio.srcObject.getTracks();
                tracks.forEach({
                    "CustomAnswerEditor.useEffect": (track)=>track.stop()
                }["CustomAnswerEditor.useEffect"]);
                audio.srcObject = null;
            }
            const audioContext = audioContextRef.current || new AudioContext();
            const source = sourceRef.current || audioContext.createMediaElementSource(audio);
            const analyser = analyserRef.current || audioContext.createAnalyser();
            sourceRef.current = source;
            audioContextRef.current = audioContext;
            analyserRef.current = analyser;
            source.connect(analyser);
            analyser.connect(audioContext.destination);
            analyser.fftSize = 2048;
            analyser.smoothingTimeConstant = 0.8;
            const canvas = canvasRef.current;
            // const timeline = timelineRef.current;
            const canvasCtx = canvas.getContext("2d");
            // const timelineCtx = timeline.getContext('2d');
            const bufferLength = analyser.frequencyBinCount;
            const dataArray = new Uint8Array(bufferLength);
            // const timelineDataArray = new Uint8Array(bufferLength);
            // setDataArray(dataArray);
            const draw = {
                "CustomAnswerEditor.useEffect.draw": ()=>{
                    requestAnimationFrame(draw);
                    analyser.getByteFrequencyData(dataArray);
                    // TODO make this white or black depending on if its light or dark mode
                    canvasCtx.fillStyle = "rgb(255, 255, 255)";
                    canvasCtx.fillRect(0, 0, canvas.width, canvas.height);
                    const barWidth = canvas.width / bufferLength * 2.5;
                    let barHeight;
                    let x = 0;
                    // Find the maximum value in the dataArray
                    const max = Math.max(...dataArray);
                    // Reflect the canvas horizontally
                    canvasCtx.scale(-1, 1);
                    canvasCtx.translate(-canvas.width, 0);
                    for(let i = 0; i < bufferLength; i++){
                        barHeight = dataArray[i] / max * canvas.height / 2;
                        canvasCtx.fillStyle = `rgb(${barHeight + 100},${_g},${_b})`;
                        canvasCtx.fillRect(canvas.width - (x + barWidth / 2), canvas.height / 2 - barHeight / 2, barWidth, barHeight);
                        x += barWidth + 1;
                    }
                    // Reset the canvas transformation
                    canvasCtx.setTransform(1, 0, 0, 1, 0, 0);
                }
            }["CustomAnswerEditor.useEffect.draw"];
            draw();
            audio.addEventListener("canplaythrough", {
                "CustomAnswerEditor.useEffect": ()=>{
                    console.log("canplaythrough");
                    audio.play();
                    setWorking(false);
                    // setValue('');
                    setPreviewMessage(t("customAnswerEditor.successGeneratedAudio"));
                }
            }["CustomAnswerEditor.useEffect"]);
        }
    }["CustomAnswerEditor.useEffect"], [
        audioSrc
    ]);
    const title = t("customAnswerEditor.title");
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "CustomAnswerEditor.useEffect": ()=>{
            const fetchAudio = {
                "CustomAnswerEditor.useEffect.fetchAudio": async ()=>{
                    if (!presignedUrl) {
                        return;
                    }
                    try {
                        console.log("presignedUrl!!!", presignedUrl);
                        const response = await fetch(presignedUrl);
                        console.log("response!!!", response);
                        const blob = await response.blob();
                        const url = URL.createObjectURL(blob);
                        console.log("url!!!", url);
                        setAudioSrc(url);
                    } catch (error) {
                        console.error(error);
                    }
                }
            }["CustomAnswerEditor.useEffect.fetchAudio"];
            fetchAudio();
        }
    }["CustomAnswerEditor.useEffect"], [
        presignedUrl
    ]);
    const [editor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    const [isSelected, setSelected, clearSelection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"])(nodeKey);
    const onDelete = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "CustomAnswerEditor.useCallback[onDelete]": (payload)=>{
            if (isSelected && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])())) {
                const event = payload;
                event.preventDefault();
                const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isCustomAnswerNode"])(node)) {
                    node.remove();
                    return true;
                }
            }
            return false;
        }
    }["CustomAnswerEditor.useCallback[onDelete]"], [
        isSelected,
        nodeKey
    ]);
    const handleClose = ()=>{
        setDialogValue({
            prompt: "",
            answer: ""
        });
        // close modal
        setWorking(false);
        setPreviewMessage("");
        toggleOpen(false);
    };
    const addQuestion = (question)=>{
        editor.update(async ()=>{
            console.log("addQuestion", question);
            // upload the audio file if the question has one
            const node_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isCustomAnswerNode"])(node_0)) {
                node_0.appendQuestion(question);
            }
        });
    };
    const removeQuestionIDs = (ids)=>{
        editor.update(async ()=>{
            const node_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isCustomAnswerNode"])(node_1)) {
                node_1.removeIntersection(ids);
            }
        });
    };
    const addQuestionID = (id_0)=>{
        editor.update(async ()=>{
            const node_2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isCustomAnswerNode"])(node_2)) {
                node_2.appendId(id_0);
                // Add relationship to question
                const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                const { data: question_0 } = await client.models.Question.get({
                    id: id_0
                });
                if (question_0) {
                    await client.models.QuestionUnit.create({
                        unitID: unit.id,
                        questionID: question_0.id
                    });
                }
            }
        });
    };
    const handleSubmit = async (event_0)=>{
        event_0.preventDefault();
        const prompt = event_0.target[0].value;
        const answer = event_0.target[1].value;
        const hint = event_0.target[2].value;
        // upload the audio file for the prompt and answer
        // 1st just upload the prompt
        toggleOpen(true);
        setWorking(true);
        setPreviewMessage(t("customAnswerEditor.generatingAudio"));
        const { identityId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAuthSession"])();
        // Server Action for audio generation
        const result_0 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$274953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateSpeech"])({
            phrase: prompt,
            voice: "shimmer",
            model: "tts-1-hd"
        });
        const path = result_0.path;
        if (path) {
            console.log("s3Key", path, identityId);
            const _presignedUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(path);
            console.log("_presignedUrl", _presignedUrl);
            setPresignedUrl(_presignedUrl);
        } else {
            console.error("fileGenerator", fileGenerator);
            // send error message to preview modal
            setPreviewMessage(t("customAnswerEditor.errorGeneratingAudio"));
            setWorking(false);
        }
        console.log("handleSubmit", event_0);
        // default to creating an audio prompt and answer
        // upload the audio file for the prompt and answer
        // convert the expected prompt to a different style question with a hint
        // For example given the prompt "What is the capital of Japan?":
        // The expected answer would be "Tokyo"
        // The reversed question would be:
        // "The capital of Japan is famous for its sushi and is the largest city in the world."
        // The expected answer would be:
        // " What is Tokyo?"
        // Create and save the Question model
        try {
            const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const response_0 = await client_0.models.Question.create({
                prompt,
                answer,
                hint,
                audio: [
                    path
                ],
                answerAudio: [],
                // Can be populated later if answer audio is generated
                owner: unit?.owner || "system",
                identityId: unit?.identityId || "system"
            });
            if (response_0.errors) {
                throw new Error(response_0.errors[0].message);
            }
            // Add the question ID to the custom answer node
            addQuestionID(response_0.data.id);
            // Close the modal and reset form
            toggleOpen(false);
            setWorking(false);
        } catch (error_0) {
            console.error("Error creating question:", error_0);
            setPreviewMessage(t("customAnswerEditor.errorCreatingQuestion"));
            setWorking(false);
        }
    };
    const setAllowedInput = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "CustomAnswerEditor.useCallback[setAllowedInput]": (payload_0)=>{
            editor.update({
                "CustomAnswerEditor.useCallback[setAllowedInput]": async ()=>{
                    const node_3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isCustomAnswerNode"])(node_3)) {
                        console.log("setAllowedInput", payload_0);
                        node_3.setAllowedInput(payload_0);
                    }
                }
            }["CustomAnswerEditor.useCallback[setAllowedInput]"]);
        }
    }["CustomAnswerEditor.useCallback[setAllowedInput]"], [
        editor,
        nodeKey
    ]);
    const setPromptMethod = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "CustomAnswerEditor.useCallback[setPromptMethod]": (payload_1)=>{
            editor.update({
                "CustomAnswerEditor.useCallback[setPromptMethod]": async ()=>{
                    const node_4 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isCustomAnswerNode"])(node_4)) {
                        console.log("setPromptMethod", payload_1);
                        node_4.setPromptMethod(payload_1);
                    }
                }
            }["CustomAnswerEditor.useCallback[setPromptMethod]"]);
        }
    }["CustomAnswerEditor.useCallback[setPromptMethod]"], [
        editor,
        nodeKey
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "CustomAnswerEditor.useEffect": ()=>{
            let isMounted = true;
            const unregister = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CLICK_COMMAND"], {
                "CustomAnswerEditor.useEffect.unregister": (payload_2)=>{
                    const event_1 = payload_2;
                    if (customAnswerRef.current && customAnswerRef.current.contains(event_1.target)) {
                        event_1.preventDefault();
                        if (event_1.shiftKey) {
                            setSelected(!isSelected);
                        } else {
                            clearSelection();
                            setSelected(true);
                        }
                        return true;
                    }
                    return false;
                }
            }["CustomAnswerEditor.useEffect.unregister"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_DELETE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), editor.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_BACKSPACE_COMMAND"], onDelete, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]));
            return ({
                "CustomAnswerEditor.useEffect": ()=>{
                    isMounted = false;
                    unregister();
                }
            })["CustomAnswerEditor.useEffect"];
        }
    }["CustomAnswerEditor.useEffect"], [
        clearSelection,
        editor,
        isSelected,
        nodeKey,
        onDelete,
        setSelected
    ]);
    const _questionBank = Object.values(questionBank || []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: customAnswerRef,
        style: {
            maxHeight: "32rem",
            maxWidth: "72rem",
            border: isSelected ? "2px solid #1976d2" : "1px solid transparent",
            borderRadius: "4px",
            padding: "8px",
            cursor: "pointer"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "h5",
                children: title
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                lineNumber: 417,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "p",
                children: t("customAnswerEditor.description")
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                lineNumber: 419,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: "flex",
                    flexDirection: "row",
                    justifyContent: "right"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"], {
                    value: value,
                    onChange: (event_2, newValue)=>{
                        if (typeof newValue === "string") {
                            // timeout to avoid instant validation of the dialog's form.
                            setTimeout(()=>{
                                toggleOpen(true);
                                setDialogValue({
                                    phrase: newValue,
                                    pronunciation: "",
                                    definition: ""
                                });
                            });
                        } else if (newValue && newValue.inputValue) {
                            toggleOpen(true);
                            setDialogValue({
                                prompt: newValue.inputValue,
                                answer: "",
                                hint: ""
                            });
                        } else {
                            console.log("Autocomplete.newValue", newValue);
                            // Append wordID to wordIDs
                            const newQuestionId = newValue?.id;
                            if (newQuestionId) {
                                addQuestionID(newQuestionId);
                                setValue(null);
                                setDialogValue({
                                    prompt: "",
                                    answer: "",
                                    hint: ""
                                });
                            }
                        }
                    },
                    filterOptions: (options, params)=>{
                        const filtered = filter(options, params);
                        if (params.inputValue !== "") {
                            filtered.push({
                                inputValue: params.inputValue,
                                prompt: `Add "${params.inputValue}"`
                            });
                        }
                        return filtered;
                    },
                    sx: {
                        flexGrow: 1
                    },
                    id: "add-new-question",
                    options: _questionBank,
                    getOptionLabel: (option)=>{
                        // e.g value selected with enter, right from the input
                        if (typeof option === "string") {
                            return option;
                        }
                        if (option.inputValue) {
                            return option.inputValue;
                        }
                        return option.prompt;
                    },
                    selectOnFocus: true,
                    clearOnBlur: true,
                    handleHomeEndKeys: true,
                    renderOption: (props, option_0)=>{
                        const { key, ...otherProps } = props;
                        const phrase = `${option_0?.prompt} (${option_0?.answer}) ${option_0?.hint}`;
                        const uniqueKey = option_0?.id || key;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            ...otherProps,
                            children: phrase
                        }, uniqueKey, false, {
                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                            lineNumber: 489,
                            columnNumber: 16
                        }, this);
                    },
                    // sx={{ width: 300 }}
                    freeSolo: true,
                    renderInput: (params_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                            ...params_0,
                            label: t("customAnswerEditor.addWordLabel")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                            lineNumber: 494,
                            columnNumber: 41
                        }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                    lineNumber: 430,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                lineNumber: 425,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: "flex",
                    flexDirection: "row",
                    justifyContent: "right"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        color: "error",
                        style: {
                            margin: "0 0.5rem"
                        },
                        onClick: ()=>{
                            console.log("gridSelection", gridSelection);
                            console.log("removeQuestionIDs");
                            removeQuestionIDs(gridSelection);
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Remove$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                lineNumber: 583,
                                columnNumber: 11
                            }, this),
                            " ",
                            t("customAnswerEditor.remove")
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                        lineNumber: 576,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PromptMethodSelector$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PromptMethodSelector"], {
                        ids: gridSelection,
                        promptMethod: promptMethod,
                        setPromptMethod: setPromptMethod
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                        lineNumber: 586,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PromptMethodSelector$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AllowedInputSelector"], {
                        ids: gridSelection,
                        setAllowedInput: setAllowedInput,
                        allowedInput: allowedInput
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                        lineNumber: 587,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                lineNumber: 571,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                open: open,
                onClose: handleClose,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                    onSubmit: handleSubmit,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                            children: t("customAnswerEditor.dialogTitle")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                            lineNumber: 592,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                            sx: {
                                display: "flex",
                                flexDirection: "column",
                                width: "fit-content"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContentText$2f$DialogContentText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContentText$3e$__["DialogContentText"], {
                                    children: t("customAnswerEditor.dialogDescription")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                    lineNumber: 598,
                                    columnNumber: 13
                                }, this),
                                audioSrc && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            id: "modal-modal-title",
                                            variant: "h6",
                                            component: "h2",
                                            children: [
                                                t("customAnswerEditor.ttsPreview"),
                                                " ",
                                                working && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                                    variant: "rectangular",
                                                    width: 24,
                                                    height: 24,
                                                    sx: {
                                                        display: "inline-block",
                                                        borderRadius: 1,
                                                        verticalAlign: "middle"
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                                    lineNumber: 605,
                                                    columnNumber: 31
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                            lineNumber: 603,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            id: "modal-modal-description",
                                            sx: {
                                                mt: 2
                                            },
                                            children: previewMessage
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                            lineNumber: 612,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            style: {
                                                display: "flex",
                                                flexDirection: "column",
                                                width: "100%",
                                                justifyContent: "space-between",
                                                alignItems: "center"
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                                                    style: {
                                                        // width: '100%',
                                                        // height: '10vw',
                                                        margin: "auto"
                                                    },
                                                    ref: canvasRef
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                                    lineNumber: 624,
                                                    columnNumber: 19
                                                }, this),
                                                audioSrc && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    audioUrl: audioSrc,
                                                    width: 600,
                                                    height: 120,
                                                    title: t("customAnswerEditor.audioPreview"),
                                                    showDuration: true
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                                    lineNumber: 629,
                                                    columnNumber: 32
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                            lineNumber: 617,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                    autoFocus: true,
                                    margin: "dense",
                                    id: "prompt",
                                    value: dialogValue.phrase,
                                    onChange: (event_3)=>setDialogValue({
                                            ...dialogValue,
                                            prompt: event_3.target.value
                                        }),
                                    label: t("customAnswerEditor.promptLabel"),
                                    type: "text",
                                    variant: "standard"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                    lineNumber: 632,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    minRows: 3,
                                    style: {
                                        width: "100%",
                                        marginTop: "1rem"
                                    },
                                    id: "answer",
                                    value: dialogValue.definition,
                                    onChange: (event_4)=>setDialogValue({
                                            ...dialogValue,
                                            answer: event_4.target.value
                                        }),
                                    "aria-label": t("customAnswerEditor.answerLabel"),
                                    placeholder: t("customAnswerEditor.answerPlaceholder"),
                                    type: "text",
                                    variant: "standard"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                    lineNumber: 636,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    minRows: 3,
                                    style: {
                                        width: "100%",
                                        marginTop: "1rem"
                                    },
                                    id: "hint",
                                    value: dialogValue.hint,
                                    onChange: (event_5)=>setDialogValue({
                                            ...dialogValue,
                                            hint: event_5.target.value
                                        }),
                                    "aria-label": t("customAnswerEditor.hintLabel"),
                                    placeholder: t("customAnswerEditor.hintPlaceholder"),
                                    type: "text",
                                    variant: "standard"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                    lineNumber: 643,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                            lineNumber: 593,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onClick: handleClose,
                                    children: t("customAnswerEditor.cancel")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                    lineNumber: 652,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    type: "submit",
                                    variant: "contained",
                                    color: "primary",
                                    children: t("customAnswerEditor.add")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                                    lineNumber: 655,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                            lineNumber: 651,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                    lineNumber: 591,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                lineNumber: 590,
                columnNumber: 7
            }, this),
            rows?.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    marginTop: "0.5"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: t("customAnswerEditor.emptyState")
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                    lineNumber: 665,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                lineNumber: 662,
                columnNumber: 30
            }, this),
            rows?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$DataGrid$2f$DataGrid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DataGrid"], {
                sx: {
                    marginTop: "0.5rem"
                },
                rows: rows,
                columns: columns,
                initialState: {
                    pagination: {
                        paginationModel: {
                            page: 0,
                            pageSize: 10
                        }
                    }
                },
                pageSizeOptions: [
                    5,
                    10,
                    100
                ],
                checkboxSelection: true,
                rowSelectionModel: gridSelection,
                onRowSelectionModelChange: (e_0)=>{
                    console.log("onRowSelectionModelChange", e_0);
                    setGridSelection(e_0);
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
                lineNumber: 667,
                columnNumber: 28
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerEditor.jsx",
        lineNumber: 409,
        columnNumber: 10
    }, this);
}, "KKzJ84jsLGoxDAQIuthOF9EknNk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        useColumns,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"]
    ];
})), "KKzJ84jsLGoxDAQIuthOF9EknNk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        useColumns,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$useLexicalNodeSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalNodeSelection"]
    ];
});
var _c, _c1;
__turbopack_context__.k.register(_c, "%default%$React.memo");
__turbopack_context__.k.register(_c1, "%default%");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CustomAnswerComponent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ToggleButton/ToggleButton.js [app-client] (ecmascript) <export default as ToggleButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButtonGroup$2f$ToggleButtonGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButtonGroup$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ToggleButtonGroup/ToggleButtonGroup.js [app-client] (ecmascript) <export default as ToggleButtonGroup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$history$2f$LexicalHistory$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/history/LexicalHistory.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PlainTextAnswerInput$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/PlainTextAnswerInput.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioAutoSubmitWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AudioAutoSubmitWrapper.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$WorkbookBlockEnhancements$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/WorkbookBlockEnhancements.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useVerifyContext$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useVerifyContext.ts [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
const SketchPad = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(async ()=>(await __turbopack_context__.A("[project]/src/components/Editor3/components/SketchPad.jsx [app-client] (ecmascript, next/dynamic entry, async loader)")).default, {
    loadableGenerated: {
        modules: [
            "[project]/src/components/Editor3/components/SketchPad.jsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = SketchPad;
;
;
;
;
;
function LinearProgressWithLabel(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "7fdf6f802eb1d0754223ed0f1760f4fd39b41024051d2e0cb1c1c25047459a9f") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7fdf6f802eb1d0754223ed0f1760f4fd39b41024051d2e0cb1c1c25047459a9f";
    }
    const { value } = t0;
    let t1;
    if ($[1] !== value) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            width: "95%",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                variant: "determinate",
                value: value
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                lineNumber: 32,
                columnNumber: 27
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
            lineNumber: 32,
            columnNumber: 10
        }, this);
        $[1] = value;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== value) {
        t2 = Math.round(value);
        $[3] = value;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const t3 = `${t2}%`;
    let t4;
    if ($[5] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            width: "fit-content",
            marginLeft: 1,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                color: "textSecondary",
                children: t3
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                lineNumber: 49,
                columnNumber: 50
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
            lineNumber: 49,
            columnNumber: 10
        }, this);
        $[5] = t3;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== t1 || $[8] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                display: "flex",
                alignItems: "center",
                margin: 1,
                children: [
                    t1,
                    t4
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                lineNumber: 57,
                columnNumber: 12
            }, this)
        }, void 0, false);
        $[7] = t1;
        $[8] = t4;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    return t5;
}
_c1 = LinearProgressWithLabel;
function CustomAnswerComponent({ className, nodeKey, // questions,
ids: questionIDs, requestDefinition = false, customPrompt, allowedInput = [], promptMethod = [] }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("workbook");
    const tEditor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor");
    const tEditorAi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.ai");
    const [answers, setAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [progress, setProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [feedback, setFeedback] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const sharedHistoryState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$history$2f$LexicalHistory$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEmptyHistoryState"])());
    const [currentInputMethod, setCurrentInputMethod] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(allowedInput[0] || "text");
    const [allowedInputMethods, setAllowedInputMethods] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(allowedInput || [
        "text",
        "audio",
        "writing"
    ]);
    const [currentPromptMethod, setCurrentPromptMethod] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(promptMethod[0] || "text");
    const { grade, saveGrade, workbook } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { studentMemory, contentContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useVerifyContext$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVerifyContext"])();
    const { questionBank } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const gradeId = grade?.id;
    const inProgress = grade?.data?.[nodeKey];
    const completionSavedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    // Reset local state when grade changes (e.g., new grade after unit completion)
    const gradeIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(gradeId);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "CustomAnswerComponent.useEffect": ()=>{
            if (gradeId && gradeId !== gradeIdRef.current) {
                gradeIdRef.current = gradeId;
                // Only reset if the new grade has no data for this exercise
                if (!grade?.data?.[nodeKey]) {
                    setAnswers({});
                    setFeedback({});
                    setProgress(0);
                    completionSavedRef.current = false;
                }
            }
        }
    }["CustomAnswerComponent.useEffect"], [
        gradeId,
        grade?.data,
        nodeKey
    ]);
    // Load saved answers from progress data
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "CustomAnswerComponent.useEffect": ()=>{
            if (inProgress?.userResponse) {
                // For single question exercises
                const firstQuestionId = questionIDs?.[0];
                if (firstQuestionId) {
                    setAnswers({
                        "CustomAnswerComponent.useEffect": (prev)=>({
                                ...prev,
                                [firstQuestionId]: inProgress.userResponse
                            })
                    }["CustomAnswerComponent.useEffect"]);
                }
            }
            if (inProgress?.complete) {
                // Mark as complete if already finished with detailed feedback
                const completeFeedback = {};
                questionIDs?.forEach({
                    "CustomAnswerComponent.useEffect": (qid)=>{
                        completeFeedback[qid] = {
                            answer: true,
                            reason: inProgress.feedback || "Answer verified and accepted",
                            userResponse: inProgress.userResponse || answers[qid]
                        };
                    }
                }["CustomAnswerComponent.useEffect"]);
                setFeedback(completeFeedback);
            }
        }
    }["CustomAnswerComponent.useEffect"], [
        inProgress,
        questionIDs
    ]);
    const handleInputChange = (event, newInputMethod)=>{
        // console.log('newInputMethods', newInputMethods)
        setCurrentInputMethod(newInputMethod);
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "CustomAnswerComponent.useEffect": ()=>{
            if (allowedInput?.length > 0) {
                console.log("allowedInput", allowedInput);
                console.log("promptMethod", promptMethod);
                console.log("AnswerComponent.currentPromptMethod", currentPromptMethod);
                setAllowedInputMethods(allowedInput);
                setCurrentInputMethod(allowedInput[0]);
            }
        }
    }["CustomAnswerComponent.useEffect"], [
        JSON.stringify(allowedInput)
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "CustomAnswerComponent.useEffect": ()=>{
            console.log("AnswerComponent.promptMethod", promptMethod);
            if (promptMethod?.length > 0) {
                setCurrentPromptMethod(promptMethod[0]);
            }
        }
    }["CustomAnswerComponent.useEffect"], [
        JSON.stringify(promptMethod)
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "CustomAnswerComponent.useEffect": ()=>{
            console.log("allowedInput", allowedInput);
            console.log("promptMethod", promptMethod);
            setAllowedInputMethods(allowedInput);
            setCurrentInputMethod(allowedInput[0]);
            setCurrentPromptMethod(promptMethod[0]);
            console.log("AnswerComponent.currentPromptMethod", promptMethod[0]);
        }
    }["CustomAnswerComponent.useEffect"], []);
    // Reset completion guard when exercise changes
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "CustomAnswerComponent.useEffect": ()=>{
            completionSavedRef.current = false;
        }
    }["CustomAnswerComponent.useEffect"], [
        nodeKey
    ]);
    // Track completion of this exercise
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "CustomAnswerComponent.useEffect": ()=>{
            if (completionSavedRef.current) return;
            if (questionIDs && questionIDs.length > 0 && feedback) {
                // Check if all questions have been answered
                const allQuestionsAnswered = questionIDs.every({
                    "CustomAnswerComponent.useEffect.allQuestionsAnswered": (qid_0)=>feedback[qid_0] !== undefined
                }["CustomAnswerComponent.useEffect.allQuestionsAnswered"]);
                if (allQuestionsAnswered && !inProgress?.complete) {
                    completionSavedRef.current = true;
                    console.log("CustomAnswerComponent: All questions answered, marking complete");
                    // Get the first answer as user response (for single question exercises)
                    const firstQuestionId_0 = questionIDs?.[0];
                    const userResponse = answers[firstQuestionId_0] || inProgress?.userResponse;
                    const feedbackText = feedback[firstQuestionId_0]?.reason || "All questions completed";
                    // Update this exercise's data while preserving all other exercise data
                    const updatedData = {
                        ...grade?.data || {},
                        [nodeKey]: {
                            ...inProgress,
                            complete: true,
                            userResponse: userResponse,
                            feedback: feedbackText,
                            accuracy: 1.0
                        }
                    };
                    saveGrade(updatedData);
                }
            }
        }
    }["CustomAnswerComponent.useEffect"], [
        feedback,
        questionIDs,
        saveGrade,
        nodeKey,
        grade,
        inProgress
    ]);
    const blockGradeData = grade?.data?.[nodeKey];
    const nailedIt = blockGradeData?.nailedIt === true;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$WorkbookBlockEnhancements$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WorkbookBlockEnhancements"], {
        blockId: nodeKey,
        nailedIt: nailedIt,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: className,
            style: {
                display: "flex",
                flexDirection: "column",
                // alignItems: 'center',
                marginBottom: "6rem"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        flexGrow: 1
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "h6",
                        component: "div",
                        sx: {
                            flexGrow: 1
                        },
                        children: t("customAnswerComponent.answerQuestions")
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                        lineNumber: 216,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                    lineNumber: 213,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButtonGroup$2f$ToggleButtonGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButtonGroup$3e$__["ToggleButtonGroup"], {
                    exclusive: true,
                    value: currentInputMethod,
                    onChange: handleInputChange,
                    "aria-label": tEditorAi("promptMethodSelector.inputButton"),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButton$3e$__["ToggleButton"], {
                            disabled: !allowedInputMethods.includes("text"),
                            value: "text",
                            "aria-label": tEditor("customAnswerComponent.text"),
                            children: t("customAnswerComponent.text")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                            lineNumber: 224,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButton$3e$__["ToggleButton"], {
                            disabled: !allowedInputMethods.includes("audio"),
                            value: "audio",
                            "aria-label": tEditor("customAnswerComponent.audio"),
                            children: t("customAnswerComponent.audio")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                            lineNumber: 227,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ToggleButton$3e$__["ToggleButton"], {
                            disabled: !allowedInputMethods.includes("writing"),
                            value: "writing",
                            "aria-label": tEditor("customAnswerComponent.writing"),
                            children: t("customAnswerComponent.writing")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                            lineNumber: 230,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                    lineNumber: 223,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinearProgressWithLabel, {
                        value: 0
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                        lineNumber: 236,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                    lineNumber: 235,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    children: questionIDs && questionIDs.map((questionID)=>{
                        const question = questionBank[questionID] || {};
                        console.log("CustomAnswerComponent.questionID", questionID);
                        console.log("CustomAnswerComponent.questionBank", questionBank);
                        console.log("CustomAnswerComponent.question", question);
                        let borderStyle = "1px solid #ccc";
                        if (feedback[questionID]?.answer === true) {
                            console.log("feedback[questionID]", feedback[questionID]);
                            borderStyle = "1px solid green";
                        } else if (feedback[questionID]?.answer === false) {
                            console.log("feedback[questionID]", feedback[questionID]);
                            borderStyle = "1px solid red";
                        }
                        const { prompt, answer, phrase, definition, pronunciation } = question;
                        console.log("CustomAnswerComponent.question", question);
                        console.log("CustomAnswerComponent.prompt", prompt);
                        console.log("CustomAnswerComponent.feedback[questionID]", feedback[questionID]);
                        // Determine if this question is completed
                        const isCompleted = feedback[questionID] && feedback[questionID].answer !== undefined;
                        console.log("CustomAnswerComponent.isCompleted", isCompleted);
                        console.log("CustomAnswerComponent.currentPromptMethod", currentPromptMethod);
                        // Determine what to display as the prompt
                        let displayPrompt = prompt;
                        if (!displayPrompt && currentPromptMethod === "phrase") {
                            displayPrompt = phrase;
                        } else if (!displayPrompt && currentPromptMethod === "definition") {
                            displayPrompt = definition;
                        } else if (!displayPrompt && currentPromptMethod === "pronunciation") {
                            displayPrompt = pronunciation;
                        }
                        // If still no prompt but we have feedback, try to extract from there
                        if (!displayPrompt && isCompleted && feedback[questionID]) {
                            displayPrompt = feedback[questionID]?.prompt || null;
                        }
                        console.log("CustomAnswerComponent.displayPrompt", displayPrompt);
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            display: "flex",
                            children: [
                                (currentPromptMethod !== "audio" || isCompleted) && displayPrompt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body1",
                                    display: "flex",
                                    style: {
                                        textWrap: "wrap",
                                        wordBreak: "normal",
                                        marginBottom: "0.5rem"
                                    },
                                    color: "textPrimary",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            children: t("customAnswerComponent.question")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                            lineNumber: 293,
                                            columnNumber: 25
                                        }, this),
                                        " ",
                                        displayPrompt
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                    lineNumber: 288,
                                    columnNumber: 89
                                }, this),
                                isCompleted && !displayPrompt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body1",
                                    display: "flex",
                                    style: {
                                        textWrap: "wrap",
                                        wordBreak: "normal",
                                        marginBottom: "0.5rem"
                                    },
                                    color: "text.secondary",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            children: t("customAnswerComponent.completedQuestion")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                            lineNumber: 305,
                                            columnNumber: 23
                                        }, this),
                                        " ",
                                        t("customAnswerComponent.promptNotAvailable")
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                    lineNumber: 300,
                                    columnNumber: 53
                                }, this),
                                feedback[questionID] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        mb: 1.5,
                                        p: 1.5,
                                        border: 1,
                                        borderColor: feedback[questionID]?.answer === true ? "success.main" : "error.main",
                                        borderRadius: 1,
                                        bgcolor: "action.hover"
                                    },
                                    children: [
                                        feedback[questionID]?.userResponse && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "body2",
                                            color: "text.secondary",
                                            sx: {
                                                mb: 0.5,
                                                fontStyle: "italic"
                                            },
                                            children: t("customAnswerComponent.yourAnswer", {
                                                answer: feedback[questionID].userResponse
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                            lineNumber: 322,
                                            columnNumber: 62
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "body2",
                                            color: "text.primary",
                                            component: "div",
                                            sx: {
                                                flexGrow: 1
                                            },
                                            children: feedback[questionID]?.reason || ""
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                            lineNumber: 330,
                                            columnNumber: 23
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                    lineNumber: 314,
                                    columnNumber: 44
                                }, this),
                                currentPromptMethod === "audio" && question?.audio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    audioUrl: question.audio[0],
                                    width: 400,
                                    height: 60,
                                    title: question.prompt || t("customAnswerComponent.audioQuestion")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                    lineNumber: 337,
                                    columnNumber: 74
                                }, this),
                                currentInputMethod === "text" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    display: "flex",
                                    style: {
                                        marginBottom: "1rem"
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PlainTextAnswerInput$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        value: answers[questionID] || "",
                                        onChange: (text)=>{
                                            setAnswers({
                                                ...answers,
                                                [questionID]: text
                                            });
                                        },
                                        onAutoSubmit: async (text_0)=>{
                                            try {
                                                const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                                                const response = await client.queries.verifyShortAnswer({
                                                    answer: text_0,
                                                    prompt: prompt,
                                                    expected: answer,
                                                    model: 'gpt-3.5-turbo',
                                                    studentMemory,
                                                    contentContext
                                                });
                                                console.log('response', response);
                                                const data = JSON.parse(response?.data) || {};
                                                setFeedback({
                                                    ...feedback,
                                                    [questionID]: data
                                                });
                                                // Broadcast to collaborators via Yjs
                                                workbook?.setFeedback?.(nodeKey, {
                                                    text: data?.reason || "",
                                                    timestamp: Date.now()
                                                });
                                            } catch (error) {
                                                console.error(error);
                                                setFeedback({
                                                    ...feedback,
                                                    [questionID]: t("customAnswerComponent.errorOccurred")
                                                });
                                            }
                                        },
                                        historyState: sharedHistoryState.current,
                                        placeholder: t("customAnswerComponent.answerPlaceholder"),
                                        ariaLabel: tEditor("customAnswerComponent.yourAnswer"),
                                        borderStyle: borderStyle,
                                        textColor: feedback[questionID]?.answer === true ? "green" : feedback[questionID]?.answer === false ? "red" : "inherit",
                                        testId: "custom-answer-input",
                                        questionId: questionID,
                                        disabled: isCompleted
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                        lineNumber: 342,
                                        columnNumber: 23
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                    lineNumber: 339,
                                    columnNumber: 53
                                }, this),
                                currentInputMethod === "audio" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    display: "flex",
                                    style: {
                                        marginBottom: "1rem"
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioAutoSubmitWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        children: ({ wrapOnRecordingComplete })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                enableRecording: true,
                                                gradeId: grade?.id,
                                                nodeKey: `custom-answer-${questionID}`,
                                                title: prompt || question?.prompt,
                                                onRecordingComplete: wrapOnRecordingComplete(async (audioFile, uploadResult)=>{
                                                    const currentGradeData = grade?.data || {};
                                                    const audioNodeKey = `custom-answer-${questionID}`;
                                                    const updatedGradeData = {
                                                        ...currentGradeData,
                                                        [audioNodeKey]: {
                                                            ...currentGradeData[audioNodeKey],
                                                            audioFilePath: audioFile?.path || null,
                                                            audioFileId: audioFile?.id || null,
                                                            inputMethod: "audio"
                                                        }
                                                    };
                                                    saveGrade(updatedGradeData);
                                                    // Verify the recorded audio
                                                    try {
                                                        const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                                                        const audioUrl = audioFile?.path || uploadResult?.path;
                                                        if (audioUrl) {
                                                            const { data: data_0, errors } = await client_0.queries.verifyShortAnswer({
                                                                answer: audioUrl,
                                                                prompt: prompt,
                                                                expected: answer,
                                                                model: 'gpt-3.5-turbo',
                                                                studentMemory,
                                                                contentContext
                                                            });
                                                            if (!errors && data_0) {
                                                                const feedbackData = JSON.parse(data_0);
                                                                setFeedback((prev_0)=>({
                                                                        ...prev_0,
                                                                        [questionID]: feedbackData
                                                                    }));
                                                                // Broadcast to collaborators via Yjs
                                                                workbook?.setFeedback?.(nodeKey, {
                                                                    text: feedbackData?.reason || "",
                                                                    timestamp: Date.now()
                                                                });
                                                            }
                                                        }
                                                    } catch (err) {
                                                        console.error("[CustomAnswerComponent] Audio verification error:", err);
                                                    }
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                                lineNumber: 384,
                                                columnNumber: 23
                                            }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                        lineNumber: 381,
                                        columnNumber: 23
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                    lineNumber: 378,
                                    columnNumber: 54
                                }, this),
                                currentInputMethod === "writing" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    display: "flex",
                                    style: {
                                        marginBottom: "1rem"
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
                                        fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: t("customAnswerComponent.loading")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                            lineNumber: 436,
                                            columnNumber: 43
                                        }, this),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SketchPad, {
                                            excalidrawData: inProgress?.excalidrawData ?? {},
                                            className: className,
                                            expect: answer,
                                            questionID: questionID,
                                            setFeedback: (data_1)=>{
                                                setFeedback({
                                                    ...feedback,
                                                    [questionID]: data_1
                                                });
                                                // Broadcast to collaborators via Yjs
                                                workbook?.setFeedback?.(nodeKey, {
                                                    text: data_1?.reason || "",
                                                    timestamp: Date.now()
                                                });
                                            },
                                            feedback: feedback,
                                            question: prompt
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                            lineNumber: 437,
                                            columnNumber: 25
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                        lineNumber: 436,
                                        columnNumber: 23
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                                    lineNumber: 433,
                                    columnNumber: 56
                                }, this)
                            ]
                        }, questionID, true, {
                            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                            lineNumber: 284,
                            columnNumber: 18
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
                    lineNumber: 239,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
            lineNumber: 207,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Editor3/nodes/CustomAnswerNode/CustomAnswerComponent.jsx",
        lineNumber: 206,
        columnNumber: 10
    }, this);
}
_s(CustomAnswerComponent, "uIct0OzsN7a61m2dq5QCg6oz/Bs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useVerifyContext$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVerifyContext"]
    ];
});
_c2 = CustomAnswerComponent;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "SketchPad");
__turbopack_context__.k.register(_c1, "LinearProgressWithLabel");
__turbopack_context__.k.register(_c2, "CustomAnswerComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FileMetadataComponent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tabs/Tabs.js [app-client] (ecmascript) <export default as Tabs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tab/Tab.js [app-client] (ecmascript) <export default as Tab>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Accordion/Accordion.js [app-client] (ecmascript) <export default as Accordion>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AccordionSummary/AccordionSummary.js [app-client] (ecmascript) <export default as AccordionSummary>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AccordionDetails/AccordionDetails.js [app-client] (ecmascript) <export default as AccordionDetails>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$InputAdornment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputAdornment$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputAdornment/InputAdornment.js [app-client] (ecmascript) <export default as InputAdornment>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Portal/Portal.js [app-client] (ecmascript) <export default as Portal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript) <export default as Snackbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandMore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandLess.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Save.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Cancel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Cancel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Search.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Clear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Clear.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$VolumeUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/VolumeUp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PictureAsPdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PictureAsPdf.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Description.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Folder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Folder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Delete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Info.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Highlight search terms in text
const highlightMatches = (text, searchTerm)=>{
    if (!searchTerm || !text) return text;
    const regex = new RegExp(`(${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);
    return parts.map((part, index)=>regex.test(part) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("mark", {
            style: {
                backgroundColor: 'var(--mui-palette-custom-searchHighlight, #ffeb3b)',
                padding: '0 2px'
            },
            children: part
        }, index, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 12,
            columnNumber: 56
        }, ("TURBOPACK compile-time value", void 0)) : part);
};
// Get file type icon
const getFileTypeIcon = (mimeType)=>{
    if (mimeType?.includes('image')) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
        lineNumber: 22,
        columnNumber: 43
    }, ("TURBOPACK compile-time value", void 0));
    if (mimeType?.includes('audio')) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$VolumeUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
        lineNumber: 23,
        columnNumber: 43
    }, ("TURBOPACK compile-time value", void 0));
    if (mimeType === 'application/pdf') return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PictureAsPdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
        lineNumber: 24,
        columnNumber: 46
    }, ("TURBOPACK compile-time value", void 0));
    if (mimeType?.includes('text') || mimeType?.includes('document')) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
        lineNumber: 25,
        columnNumber: 76
    }, ("TURBOPACK compile-time value", void 0));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Folder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
        lineNumber: 26,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
function TabPanel(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "e7d5e8dc418f7e52de68c67288b0fa00266a5d099283e347792757ad8da972bc") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e7d5e8dc418f7e52de68c67288b0fa00266a5d099283e347792757ad8da972bc";
    }
    let children;
    let index;
    let other;
    let value;
    if ($[1] !== t0) {
        ({ children, value, index, ...other } = t0);
        $[1] = t0;
        $[2] = children;
        $[3] = index;
        $[4] = other;
        $[5] = value;
    } else {
        children = $[2];
        index = $[3];
        other = $[4];
        value = $[5];
    }
    const t1 = value !== index;
    const t2 = `metadata-tabpanel-${index}`;
    const t3 = `metadata-tab-${index}`;
    let t4;
    if ($[6] !== children || $[7] !== index || $[8] !== value) {
        t4 = value === index && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                p: 2
            },
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 63,
            columnNumber: 29
        }, this);
        $[6] = children;
        $[7] = index;
        $[8] = value;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    let t5;
    if ($[10] !== other || $[11] !== t1 || $[12] !== t2 || $[13] !== t3 || $[14] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            role: "tabpanel",
            hidden: t1,
            id: t2,
            "aria-labelledby": t3,
            ...other,
            children: t4
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 75,
            columnNumber: 10
        }, this);
        $[10] = other;
        $[11] = t1;
        $[12] = t2;
        $[13] = t3;
        $[14] = t4;
        $[15] = t5;
    } else {
        t5 = $[15];
    }
    return t5;
}
_c = TabPanel;
function FileMetadataComponent(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(158);
    if ($[0] !== "e7d5e8dc418f7e52de68c67288b0fa00266a5d099283e347792757ad8da972bc") {
        for(let $i = 0; $i < 158; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e7d5e8dc418f7e52de68c67288b0fa00266a5d099283e347792757ad8da972bc";
    }
    const { nodeKey, file, parsedContent, onFileNameUpdate, onRemove, search: t1, index: t2 } = t0;
    const search = t1 === undefined ? "" : t1;
    const index = t2 === undefined ? 0 : t2;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("editor.files");
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isSelected, setIsSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [editingFileName, setEditingFileName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [fileName, setFileName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(file?.name || "");
    const [localSearch, setLocalSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(search || "");
    const [selectedTab, setSelectedTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    let t3;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = new Set([
            "basic"
        ]);
        $[1] = t3;
    } else {
        t3 = $[1];
    }
    const [expandedSections, setExpandedSections] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3);
    let t4;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            open: false,
            message: "",
            onConfirm: null,
            severity: "warning"
        };
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    const [confirmDialog, setConfirmDialog] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t4);
    const isEvenRow = index % 2 === 0;
    let t5;
    let t6;
    if ($[3] !== search) {
        t5 = ({
            "FileMetadataComponent[useEffect()]": ()=>{
                setLocalSearch(search || "");
            }
        })["FileMetadataComponent[useEffect()]"];
        t6 = [
            search
        ];
        $[3] = search;
        $[4] = t5;
        $[5] = t6;
    } else {
        t5 = $[4];
        t6 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7;
    if ($[6] !== file) {
        t7 = ({
            "FileMetadataComponent[useEffect()]": ()=>{
                if (file?.name) {
                    setFileName(file.name);
                }
            }
        })["FileMetadataComponent[useEffect()]"];
        $[6] = file;
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    const t8 = file?.name;
    let t9;
    if ($[8] !== t8) {
        t9 = [
            t8
        ];
        $[8] = t8;
        $[9] = t9;
    } else {
        t9 = $[9];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t7, t9);
    let t10;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = ({
            "FileMetadataComponent[handleTabChange]": (event, newValue)=>{
                setSelectedTab(newValue);
            }
        })["FileMetadataComponent[handleTabChange]"];
        $[10] = t10;
    } else {
        t10 = $[10];
    }
    const handleTabChange = t10;
    let t11;
    if ($[11] !== file?.name || $[12] !== fileName || $[13] !== onFileNameUpdate) {
        t11 = ({
            "FileMetadataComponent[handleSaveFileName]": ()=>{
                if (onFileNameUpdate && fileName !== file?.name) {
                    onFileNameUpdate(fileName);
                }
                setEditingFileName(false);
            }
        })["FileMetadataComponent[handleSaveFileName]"];
        $[11] = file?.name;
        $[12] = fileName;
        $[13] = onFileNameUpdate;
        $[14] = t11;
    } else {
        t11 = $[14];
    }
    const handleSaveFileName = t11;
    let t12;
    if ($[15] !== file?.name) {
        t12 = ({
            "FileMetadataComponent[handleCancelFileName]": ()=>{
                setFileName(file?.name || "");
                setEditingFileName(false);
            }
        })["FileMetadataComponent[handleCancelFileName]"];
        $[15] = file?.name;
        $[16] = t12;
    } else {
        t12 = $[16];
    }
    const handleCancelFileName = t12;
    let t13;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = ({
            "FileMetadataComponent[toggleSection]": (section)=>{
                setExpandedSections({
                    "FileMetadataComponent[toggleSection > setExpandedSections()]": (prev)=>{
                        const newSet = new Set(prev);
                        if (newSet.has(section)) {
                            newSet.delete(section);
                        } else {
                            newSet.add(section);
                        }
                        return newSet;
                    }
                }["FileMetadataComponent[toggleSection > setExpandedSections()]"]);
            }
        })["FileMetadataComponent[toggleSection]"];
        $[17] = t13;
    } else {
        t13 = $[17];
    }
    const toggleSection = t13;
    let t14;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = ({
            "FileMetadataComponent[clearLocalSearch]": ()=>{
                setLocalSearch("");
            }
        })["FileMetadataComponent[clearLocalSearch]"];
        $[18] = t14;
    } else {
        t14 = $[18];
    }
    const clearLocalSearch = t14;
    let t15;
    if ($[19] !== localSearch) {
        t15 = ({
            "FileMetadataComponent[filterAndHighlight]": (items, textKey, t16)=>{
                const searchTerm = t16 === undefined ? localSearch : t16;
                if (!searchTerm || !items || !Array.isArray(items)) {
                    return items || [];
                }
                return items.filter({
                    "FileMetadataComponent[filterAndHighlight > items.filter()]": (item)=>{
                        if (!item) {
                            return false;
                        }
                        const text = typeof item === "string" ? item : item[textKey];
                        return text && text.toLowerCase().includes(searchTerm.toLowerCase());
                    }
                }["FileMetadataComponent[filterAndHighlight > items.filter()]"]);
            }
        })["FileMetadataComponent[filterAndHighlight]"];
        $[19] = localSearch;
        $[20] = t15;
    } else {
        t15 = $[20];
    }
    const filterAndHighlight = t15;
    let t16;
    if ($[21] !== file || $[22] !== localSearch || $[23] !== t) {
        t16 = ({
            "FileMetadataComponent[renderBasicInfo]": ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                alignItems: "center",
                                gap: 2
                            },
                            children: [
                                getFileTypeIcon(file?.mimeType),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    color: "text.secondary",
                                    children: [
                                        file?.mimeType,
                                        " • ",
                                        file?.size ? `${(file.size / 1000).toFixed(2)} KB` : t("fileMetadataComponent.unknownSize")
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 286,
                                    columnNumber: 45
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 282,
                            columnNumber: 74
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: "flex",
                                alignItems: "center",
                                gap: 1
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "body2",
                                    children: t("fileMetadataComponent.protectionLevel")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 290,
                                    columnNumber: 12
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                    size: "small",
                                    label: file?.level || t("fileMetadataComponent.unset"),
                                    color: file?.level === "PRIVATE" ? "error" : file?.level === "PROTECTED" ? "warning" : "default"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 290,
                                    columnNumber: 97
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 286,
                            columnNumber: 227
                        }, this),
                        file?.path && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "text.secondary",
                            sx: {
                                wordBreak: "break-all"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: t("fileMetadataComponent.path")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 292,
                                    columnNumber: 12
                                }, this),
                                " ",
                                highlightMatches(file.path, localSearch)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 290,
                            columnNumber: 293
                        }, this),
                        file?.createdAt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            color: "text.secondary",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: t("fileMetadataComponent.created")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 292,
                                    columnNumber: 190
                                }, this),
                                " ",
                                new Date(file.createdAt).toLocaleString()
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 292,
                            columnNumber: 139
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                    lineNumber: 282,
                    columnNumber: 55
                }, this)
        })["FileMetadataComponent[renderBasicInfo]"];
        $[21] = file;
        $[22] = localSearch;
        $[23] = t;
        $[24] = t16;
    } else {
        t16 = $[24];
    }
    const renderBasicInfo = t16;
    let t17;
    if ($[25] !== file || $[26] !== localSearch || $[27] !== t) {
        t17 = ({
            "FileMetadataComponent[renderMetadataTab]": ()=>{
                if (!file?.metadata) {
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "text.secondary",
                        children: t("fileMetadataComponent.noMetadataAvailable")
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                        lineNumber: 307,
                        columnNumber: 18
                    }, this);
                }
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                        style: {
                            whiteSpace: "pre-wrap",
                            fontFamily: "monospace",
                            fontSize: "0.8rem",
                            backgroundColor: "var(--mui-palette-grey-100, #f5f5f5)",
                            padding: "1rem",
                            borderRadius: "4px",
                            overflow: "auto"
                        },
                        children: highlightMatches(JSON.stringify(file.metadata, null, 2), localSearch)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                        lineNumber: 309,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                    lineNumber: 309,
                    columnNumber: 16
                }, this);
            }
        })["FileMetadataComponent[renderMetadataTab]"];
        $[25] = file;
        $[26] = localSearch;
        $[27] = t;
        $[28] = t17;
    } else {
        t17 = $[28];
    }
    const renderMetadataTab = t17;
    let t18;
    if ($[29] !== expandedSections || $[30] !== filterAndHighlight || $[31] !== localSearch || $[32] !== parsedContent || $[33] !== t) {
        t18 = ({
            "FileMetadataComponent[renderParsedContentTab]": ()=>{
                if (!parsedContent) {
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "text.secondary",
                        children: t("fileMetadataComponent.noParsedContentAvailable")
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                        lineNumber: 333,
                        columnNumber: 18
                    }, this);
                }
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                    spacing: 2,
                    children: [
                        parsedContent.vocabulary && parsedContent.vocabulary.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
                            expanded: expandedSections.has("vocabulary"),
                            onChange: {
                                "FileMetadataComponent[renderParsedContentTab > <Accordion>.onChange]": ()=>toggleSection("vocabulary")
                            }["FileMetadataComponent[renderParsedContentTab > <Accordion>.onChange]"],
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
                                    expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 337,
                                        columnNumber: 116
                                    }, this),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h6",
                                        children: t("fileMetadataComponent.vocabularyCount", {
                                            count: filterAndHighlight(parsedContent.vocabulary, "term").length
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 337,
                                        columnNumber: 136
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 337,
                                    columnNumber: 86
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                        dense: true,
                                        children: filterAndHighlight(parsedContent.vocabulary, "term").map({
                                            "FileMetadataComponent[renderParsedContentTab > (anonymous)()]": (vocab, index_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                                    divider: true,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                                        primary: highlightMatches(vocab.term, localSearch),
                                                        secondary: highlightMatches(vocab.definition, localSearch)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                                        lineNumber: 340,
                                                        columnNumber: 143
                                                    }, this)
                                                }, index_0, false, {
                                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                                    lineNumber: 340,
                                                    columnNumber: 104
                                                }, this)
                                        }["FileMetadataComponent[renderParsedContentTab > (anonymous)()]"])
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 339,
                                        columnNumber: 70
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 339,
                                    columnNumber: 52
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 335,
                            columnNumber: 103
                        }, this),
                        parsedContent.summaries && parsedContent.summaries.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
                            expanded: expandedSections.has("summaries"),
                            onChange: {
                                "FileMetadataComponent[renderParsedContentTab > <Accordion>.onChange]": ()=>toggleSection("summaries")
                            }["FileMetadataComponent[renderParsedContentTab > <Accordion>.onChange]"],
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
                                    expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 343,
                                        columnNumber: 116
                                    }, this),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h6",
                                        children: t("fileMetadataComponent.summariesCount", {
                                            count: filterAndHighlight(parsedContent.summaries, "content").length
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 343,
                                        columnNumber: 136
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 343,
                                    columnNumber: 86
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                        spacing: 2,
                                        children: filterAndHighlight(parsedContent.summaries, "content").map({
                                            "FileMetadataComponent[renderParsedContentTab > (anonymous)()]": (summary, index_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "body1",
                                                            component: "div",
                                                            children: highlightMatches(summary.content, localSearch)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                                            lineNumber: 346,
                                                            columnNumber: 125
                                                        }, this),
                                                        summary.type && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                                            size: "small",
                                                            label: summary.type,
                                                            sx: {
                                                                mt: 1
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                                            lineNumber: 346,
                                                            columnNumber: 247
                                                        }, this)
                                                    ]
                                                }, index_1, true, {
                                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                                    lineNumber: 346,
                                                    columnNumber: 106
                                                }, this)
                                        }["FileMetadataComponent[renderParsedContentTab > (anonymous)()]"])
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 345,
                                        columnNumber: 70
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 345,
                                    columnNumber: 52
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 341,
                            columnNumber: 190
                        }, this),
                        parsedContent.objectives && parsedContent.objectives.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
                            expanded: expandedSections.has("objectives"),
                            onChange: {
                                "FileMetadataComponent[renderParsedContentTab > <Accordion>.onChange]": ()=>toggleSection("objectives")
                            }["FileMetadataComponent[renderParsedContentTab > <Accordion>.onChange]"],
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
                                    expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 351,
                                        columnNumber: 116
                                    }, this),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h6",
                                        children: t("fileMetadataComponent.objectivesCount", {
                                            count: filterAndHighlight(parsedContent.objectives, "description").length
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 351,
                                        columnNumber: 136
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 351,
                                    columnNumber: 86
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                        dense: true,
                                        children: filterAndHighlight(parsedContent.objectives, "description").map({
                                            "FileMetadataComponent[renderParsedContentTab > (anonymous)()]": (objective, index_2)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                                    divider: true,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                                        primary: highlightMatches(objective.description, localSearch),
                                                        secondary: objective.type && `Type: ${objective.type}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                                        lineNumber: 354,
                                                        columnNumber: 147
                                                    }, this)
                                                }, index_2, false, {
                                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                                    lineNumber: 354,
                                                    columnNumber: 108
                                                }, this)
                                        }["FileMetadataComponent[renderParsedContentTab > (anonymous)()]"])
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 353,
                                        columnNumber: 70
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 353,
                                    columnNumber: 52
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 349,
                            columnNumber: 193
                        }, this),
                        parsedContent.concepts && parsedContent.concepts.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
                            expanded: expandedSections.has("concepts"),
                            onChange: {
                                "FileMetadataComponent[renderParsedContentTab > <Accordion>.onChange]": ()=>toggleSection("concepts")
                            }["FileMetadataComponent[renderParsedContentTab > <Accordion>.onChange]"],
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
                                    expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 357,
                                        columnNumber: 116
                                    }, this),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h6",
                                        children: t("fileMetadataComponent.conceptsCount", {
                                            count: filterAndHighlight(parsedContent.concepts, "name").length
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 357,
                                        columnNumber: 136
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 357,
                                    columnNumber: 86
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                        dense: true,
                                        children: filterAndHighlight(parsedContent.concepts, "name").map({
                                            "FileMetadataComponent[renderParsedContentTab > (anonymous)()]": (concept, index_3)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                                    divider: true,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                                        primary: highlightMatches(concept.name, localSearch),
                                                        secondary: highlightMatches(concept.description, localSearch)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                                        lineNumber: 360,
                                                        columnNumber: 145
                                                    }, this)
                                                }, index_3, false, {
                                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                                    lineNumber: 360,
                                                    columnNumber: 106
                                                }, this)
                                        }["FileMetadataComponent[renderParsedContentTab > (anonymous)()]"])
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 359,
                                        columnNumber: 70
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 359,
                                    columnNumber: 52
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 355,
                            columnNumber: 188
                        }, this),
                        parsedContent.questions && parsedContent.questions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
                            expanded: expandedSections.has("questions"),
                            onChange: {
                                "FileMetadataComponent[renderParsedContentTab > <Accordion>.onChange]": ()=>toggleSection("questions")
                            }["FileMetadataComponent[renderParsedContentTab > <Accordion>.onChange]"],
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$AccordionSummary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionSummary$3e$__["AccordionSummary"], {
                                    expandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 363,
                                        columnNumber: 116
                                    }, this),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "h6",
                                        children: t("fileMetadataComponent.questionsCount", {
                                            count: filterAndHighlight(parsedContent.questions, "question").length
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 363,
                                        columnNumber: 136
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 363,
                                    columnNumber: 86
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionDetails$2f$AccordionDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AccordionDetails$3e$__["AccordionDetails"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                        dense: true,
                                        children: filterAndHighlight(parsedContent.questions, "question").map({
                                            "FileMetadataComponent[renderParsedContentTab > (anonymous)()]": (q, index_4)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                                    divider: true,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                                        primary: highlightMatches(q.question, localSearch),
                                                        secondary: q.answer && highlightMatches(`Answer: ${q.answer}`, localSearch)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                                        lineNumber: 366,
                                                        columnNumber: 139
                                                    }, this)
                                                }, index_4, false, {
                                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                                    lineNumber: 366,
                                                    columnNumber: 100
                                                }, this)
                                        }["FileMetadataComponent[renderParsedContentTab > (anonymous)()]"])
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 365,
                                        columnNumber: 70
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 365,
                                    columnNumber: 52
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 361,
                            columnNumber: 190
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                    lineNumber: 335,
                    columnNumber: 16
                }, this);
            }
        })["FileMetadataComponent[renderParsedContentTab]"];
        $[29] = expandedSections;
        $[30] = filterAndHighlight;
        $[31] = localSearch;
        $[32] = parsedContent;
        $[33] = t;
        $[34] = t18;
    } else {
        t18 = $[34];
    }
    const renderParsedContentTab = t18;
    let t19;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = {
            margin: 0
        };
        $[35] = t19;
    } else {
        t19 = $[35];
    }
    const t20 = isEvenRow ? "background.paper" : "action.hover";
    let t21;
    if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = {
            backgroundColor: "action.hover"
        };
        $[36] = t21;
    } else {
        t21 = $[36];
    }
    let t22;
    if ($[37] !== t20) {
        t22 = {
            backgroundColor: t20,
            flexDirection: "column",
            alignItems: "stretch",
            padding: 0,
            margin: 0,
            borderBottom: "1px solid",
            borderColor: "divider",
            "&:hover": t21
        };
        $[37] = t20;
        $[38] = t22;
    } else {
        t22 = $[38];
    }
    const t23 = isEvenRow ? "grey.100" : "grey.200";
    let t24;
    if ($[39] !== t23) {
        t24 = {
            backgroundColor: t23,
            borderBottom: "1px solid",
            borderColor: "divider"
        };
        $[39] = t23;
        $[40] = t24;
    } else {
        t24 = $[40];
    }
    let t25;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = {
            display: "flex",
            alignItems: "center",
            gap: 0,
            justifyContent: "space-between",
            padding: 1,
            borderBottom: "1px solid",
            borderColor: "divider",
            minHeight: 24
        };
        $[41] = t25;
    } else {
        t25 = $[41];
    }
    let t26;
    if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
        t26 = {
            display: "flex",
            gap: 0,
            alignItems: "center"
        };
        $[42] = t26;
    } else {
        t26 = $[42];
    }
    let t27;
    if ($[43] !== isSelected) {
        t27 = ({
            "FileMetadataComponent[<Checkbox>.onChange]": (e)=>{
                e.stopPropagation();
                setIsSelected(!isSelected);
            }
        })["FileMetadataComponent[<Checkbox>.onChange]"];
        $[43] = isSelected;
        $[44] = t27;
    } else {
        t27 = $[44];
    }
    let t28;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = {
            p: 0.25
        };
        $[45] = t28;
    } else {
        t28 = $[45];
    }
    let t29;
    if ($[46] !== isSelected || $[47] !== t27) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
            size: "small",
            checked: isSelected,
            onChange: t27,
            sx: t28
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 480,
            columnNumber: 11
        }, this);
        $[46] = isSelected;
        $[47] = t27;
        $[48] = t29;
    } else {
        t29 = $[48];
    }
    let t30;
    if ($[49] !== isExpanded || $[50] !== t) {
        t30 = isExpanded ? t("fileMetadataComponent.collapse") : t("fileMetadataComponent.expand");
        $[49] = isExpanded;
        $[50] = t;
        $[51] = t30;
    } else {
        t30 = $[51];
    }
    let t31;
    if ($[52] !== isExpanded) {
        t31 = ({
            "FileMetadataComponent[<IconButton>.onClick]": (e_0)=>{
                e_0.stopPropagation();
                setIsExpanded(!isExpanded);
            }
        })["FileMetadataComponent[<IconButton>.onClick]"];
        $[52] = isExpanded;
        $[53] = t31;
    } else {
        t31 = $[53];
    }
    let t32;
    if ($[54] === Symbol.for("react.memo_cache_sentinel")) {
        t32 = {
            paddingLeft: 1
        };
        $[54] = t32;
    } else {
        t32 = $[54];
    }
    let t33;
    if ($[55] !== isExpanded) {
        t33 = !isExpanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 520,
            columnNumber: 25
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 520,
            columnNumber: 63
        }, this);
        $[55] = isExpanded;
        $[56] = t33;
    } else {
        t33 = $[56];
    }
    let t34;
    if ($[57] !== t30 || $[58] !== t31 || $[59] !== t33) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            size: "small",
            title: t30,
            onClick: t31,
            sx: t32,
            children: t33
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 528,
            columnNumber: 11
        }, this);
        $[57] = t30;
        $[58] = t31;
        $[59] = t33;
        $[60] = t34;
    } else {
        t34 = $[60];
    }
    let t35;
    if ($[61] !== t29 || $[62] !== t34) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t26,
            children: [
                t29,
                t34
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 538,
            columnNumber: 11
        }, this);
        $[61] = t29;
        $[62] = t34;
        $[63] = t35;
    } else {
        t35 = $[63];
    }
    let t36;
    if ($[64] === Symbol.for("react.memo_cache_sentinel")) {
        t36 = {
            display: "flex",
            gap: 1,
            alignItems: "center"
        };
        $[64] = t36;
    } else {
        t36 = $[64];
    }
    let t37;
    if ($[65] !== file) {
        t37 = file?.size ? `${(file.size / 1000).toFixed(2)} KB` : "";
        $[65] = file;
        $[66] = t37;
    } else {
        t37 = $[66];
    }
    let t38;
    if ($[67] !== t37) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            children: t37
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 566,
            columnNumber: 11
        }, this);
        $[67] = t37;
        $[68] = t38;
    } else {
        t38 = $[68];
    }
    let t39;
    if ($[69] !== file?.level || $[70] !== t) {
        t39 = file?.level || t("fileMetadataComponent.unset");
        $[69] = file?.level;
        $[70] = t;
        $[71] = t39;
    } else {
        t39 = $[71];
    }
    const t40 = file?.level === "PRIVATE" ? "error" : file?.level === "PROTECTED" ? "warning" : "default";
    let t41;
    if ($[72] !== t39 || $[73] !== t40) {
        t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            size: "small",
            label: t39,
            color: t40
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 584,
            columnNumber: 11
        }, this);
        $[72] = t39;
        $[73] = t40;
        $[74] = t41;
    } else {
        t41 = $[74];
    }
    let t42;
    if ($[75] !== t) {
        t42 = t("fileMetadataComponent.fileInfo");
        $[75] = t;
        $[76] = t42;
    } else {
        t42 = $[76];
    }
    let t43;
    if ($[77] === Symbol.for("react.memo_cache_sentinel")) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            size: "small",
            color: "default",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fontSize: "small"
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                lineNumber: 601,
                columnNumber: 52
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 601,
            columnNumber: 11
        }, this);
        $[77] = t43;
    } else {
        t43 = $[77];
    }
    let t44;
    if ($[78] !== t42) {
        t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: t42,
            children: t43
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 608,
            columnNumber: 11
        }, this);
        $[78] = t42;
        $[79] = t44;
    } else {
        t44 = $[79];
    }
    let t45;
    if ($[80] !== t) {
        t45 = t("fileMetadataComponent.deleteFile");
        $[80] = t;
        $[81] = t45;
    } else {
        t45 = $[81];
    }
    let t46;
    if ($[82] !== file?.name || $[83] !== nodeKey || $[84] !== onRemove || $[85] !== t) {
        t46 = ({
            "FileMetadataComponent[<IconButton>.onClick]": (e_1)=>{
                e_1.stopPropagation();
                setConfirmDialog({
                    open: true,
                    message: t("fileMetadataComponent.deleteConfirmation", {
                        fileName: file?.name
                    }),
                    severity: "warning",
                    onConfirm: ()=>{
                        onRemove && onRemove(nodeKey);
                        setConfirmDialog({
                            open: false,
                            message: "",
                            onConfirm: null,
                            severity: "warning"
                        });
                    }
                });
            }
        })["FileMetadataComponent[<IconButton>.onClick]"];
        $[82] = file?.name;
        $[83] = nodeKey;
        $[84] = onRemove;
        $[85] = t;
        $[86] = t46;
    } else {
        t46 = $[86];
    }
    let t47;
    if ($[87] === Symbol.for("react.memo_cache_sentinel")) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 655,
            columnNumber: 11
        }, this);
        $[87] = t47;
    } else {
        t47 = $[87];
    }
    let t48;
    if ($[88] !== t46) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            size: "small",
            onClick: t46,
            color: "error",
            children: t47
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 662,
            columnNumber: 11
        }, this);
        $[88] = t46;
        $[89] = t48;
    } else {
        t48 = $[89];
    }
    let t49;
    if ($[90] !== t45 || $[91] !== t48) {
        t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: t45,
            children: t48
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 670,
            columnNumber: 11
        }, this);
        $[90] = t45;
        $[91] = t48;
        $[92] = t49;
    } else {
        t49 = $[92];
    }
    let t50;
    if ($[93] !== t38 || $[94] !== t41 || $[95] !== t44 || $[96] !== t49) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t36,
            children: [
                t38,
                t41,
                t44,
                t49
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 679,
            columnNumber: 11
        }, this);
        $[93] = t38;
        $[94] = t41;
        $[95] = t44;
        $[96] = t49;
        $[97] = t50;
    } else {
        t50 = $[97];
    }
    let t51;
    if ($[98] !== t35 || $[99] !== t50) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t25,
            children: [
                t35,
                t50
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 690,
            columnNumber: 11
        }, this);
        $[98] = t35;
        $[99] = t50;
        $[100] = t51;
    } else {
        t51 = $[100];
    }
    let t52;
    if ($[101] !== editingFileName || $[102] !== file?.mimeType || $[103] !== fileName || $[104] !== handleCancelFileName || $[105] !== handleSaveFileName || $[106] !== isExpanded || $[107] !== localSearch) {
        t52 = !isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                padding: 1,
                display: "flex",
                alignItems: "center",
                gap: 1
            },
            children: [
                getFileTypeIcon(file?.mimeType),
                editingFileName ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: "flex",
                        alignItems: "center",
                        gap: 1,
                        flex: 1
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                            value: fileName,
                            onChange: {
                                "FileMetadataComponent[<TextField>.onChange]": (e_2)=>setFileName(e_2.target.value)
                            }["FileMetadataComponent[<TextField>.onChange]"],
                            variant: "standard",
                            size: "small",
                            fullWidth: true,
                            autoFocus: true
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 709,
                            columnNumber: 10
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                            size: "small",
                            onClick: handleSaveFileName,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                fontSize: "small"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 711,
                                columnNumber: 181
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 711,
                            columnNumber: 127
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                            size: "small",
                            onClick: handleCancelFileName,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Cancel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                fontSize: "small"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 711,
                                columnNumber: 279
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 711,
                            columnNumber: 223
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                    lineNumber: 704,
                    columnNumber: 60
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "body1",
                    component: "div",
                    sx: {
                        flex: 1,
                        cursor: "pointer",
                        "&:hover": {
                            textDecoration: "underline"
                        }
                    },
                    onClick: {
                        "FileMetadataComponent[<Typography>.onClick]": ()=>setEditingFileName(true)
                    }["FileMetadataComponent[<Typography>.onClick]"],
                    children: highlightMatches(fileName, localSearch)
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                    lineNumber: 711,
                    columnNumber: 332
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 699,
            columnNumber: 26
        }, this);
        $[101] = editingFileName;
        $[102] = file?.mimeType;
        $[103] = fileName;
        $[104] = handleCancelFileName;
        $[105] = handleSaveFileName;
        $[106] = isExpanded;
        $[107] = localSearch;
        $[108] = t52;
    } else {
        t52 = $[108];
    }
    let t53;
    if ($[109] !== t24 || $[110] !== t51 || $[111] !== t52) {
        t53 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t24,
            children: [
                t51,
                t52
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 733,
            columnNumber: 11
        }, this);
        $[109] = t24;
        $[110] = t51;
        $[111] = t52;
        $[112] = t53;
    } else {
        t53 = $[112];
    }
    let t54;
    if ($[113] !== editingFileName || $[114] !== file || $[115] !== fileName || $[116] !== handleCancelFileName || $[117] !== handleSaveFileName || $[118] !== isExpanded || $[119] !== localSearch || $[120] !== renderBasicInfo || $[121] !== renderMetadataTab || $[122] !== renderParsedContentTab || $[123] !== selectedTab || $[124] !== t) {
        t54 = isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                width: "100%",
                position: "relative"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    p: 2
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            mb: 2,
                            display: "flex",
                            alignItems: "center",
                            gap: 1
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                sx: {
                                    minWidth: 100
                                },
                                children: t("fileMetadataComponent.filename")
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 753,
                                columnNumber: 12
                            }, this),
                            getFileTypeIcon(file?.mimeType),
                            editingFileName ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                sx: {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 1,
                                    flex: 1
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                        value: fileName,
                                        onChange: {
                                            "FileMetadataComponent[<TextField>.onChange]": (e_3)=>setFileName(e_3.target.value)
                                        }["FileMetadataComponent[<TextField>.onChange]"],
                                        variant: "standard",
                                        size: "small",
                                        fullWidth: true,
                                        autoFocus: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 760,
                                        columnNumber: 14
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                        size: "small",
                                        onClick: handleSaveFileName,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            fontSize: "small"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                            lineNumber: 762,
                                            columnNumber: 185
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 762,
                                        columnNumber: 131
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                        size: "small",
                                        onClick: handleCancelFileName,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Cancel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            fontSize: "small"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                            lineNumber: 762,
                                            columnNumber: 283
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 762,
                                        columnNumber: 227
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 755,
                                columnNumber: 116
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body1",
                                component: "div",
                                sx: {
                                    flex: 1,
                                    cursor: "pointer",
                                    "&:hover": {
                                        textDecoration: "underline"
                                    }
                                },
                                onClick: {
                                    "FileMetadataComponent[<Typography>.onClick]": ()=>setEditingFileName(true)
                                }["FileMetadataComponent[<Typography>.onClick]"],
                                children: highlightMatches(fileName, localSearch)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 762,
                                columnNumber: 336
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                        lineNumber: 748,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            mb: 2,
                            display: "flex",
                            alignItems: "center",
                            gap: 1
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                sx: {
                                    minWidth: 100
                                },
                                children: t("fileMetadataComponent.type")
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 775,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body1",
                                color: "text.secondary",
                                children: file?.mimeType || t("fileMetadataComponent.unknown")
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 777,
                                columnNumber: 60
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                        lineNumber: 770,
                        columnNumber: 122
                    }, this),
                    file?.path && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            mb: 2,
                            display: "flex",
                            alignItems: "flex-start",
                            gap: 1
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                sx: {
                                    minWidth: 100
                                },
                                children: t("fileMetadataComponent.path")
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 782,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body1",
                                color: "text.secondary",
                                sx: {
                                    wordBreak: "break-all",
                                    flex: 1
                                },
                                children: highlightMatches(file.path, localSearch)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 784,
                                columnNumber: 60
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                        lineNumber: 777,
                        columnNumber: 199
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            mb: 2
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                            value: localSearch,
                            onChange: {
                                "FileMetadataComponent[<TextField>.onChange]": (e_4)=>setLocalSearch(e_4.target.value)
                            }["FileMetadataComponent[<TextField>.onChange]"],
                            placeholder: t("fileMetadataComponent.searchPlaceholder"),
                            size: "small",
                            fullWidth: true,
                            InputProps: {
                                startAdornment: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$InputAdornment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputAdornment$3e$__["InputAdornment"], {
                                    position: "start",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 792,
                                        columnNumber: 62
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 792,
                                    columnNumber: 29
                                }, this),
                                endAdornment: localSearch && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$InputAdornment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputAdornment$3e$__["InputAdornment"], {
                                    position: "end",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                        size: "small",
                                        onClick: clearLocalSearch,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Clear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                            lineNumber: 793,
                                            columnNumber: 125
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 793,
                                        columnNumber: 73
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                    lineNumber: 793,
                                    columnNumber: 42
                                }, this)
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                            lineNumber: 789,
                            columnNumber: 12
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                        lineNumber: 787,
                        columnNumber: 76
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
                        sx: {
                            my: 2
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                        lineNumber: 794,
                        columnNumber: 22
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            borderTop: 1,
                            borderColor: "divider"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__["Tabs"], {
                                value: selectedTab,
                                onChange: handleTabChange,
                                variant: "fullWidth",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                        label: t("fileMetadataComponent.basicInfo")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 799,
                                        columnNumber: 85
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                        label: t("fileMetadataComponent.rawMetadata")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 799,
                                        columnNumber: 137
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                        label: t("fileMetadataComponent.parsedContent")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                        lineNumber: 799,
                                        columnNumber: 191
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 799,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
                                value: selectedTab,
                                index: 0,
                                children: renderBasicInfo()
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 799,
                                columnNumber: 254
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
                                value: selectedTab,
                                index: 1,
                                children: renderMetadataTab()
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 799,
                                columnNumber: 324
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabPanel, {
                                value: selectedTab,
                                index: 2,
                                children: renderParsedContentTab()
                            }, void 0, false, {
                                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                                lineNumber: 799,
                                columnNumber: 396
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                        lineNumber: 796,
                        columnNumber: 14
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                lineNumber: 746,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 743,
            columnNumber: 25
        }, this);
        $[113] = editingFileName;
        $[114] = file;
        $[115] = fileName;
        $[116] = handleCancelFileName;
        $[117] = handleSaveFileName;
        $[118] = isExpanded;
        $[119] = localSearch;
        $[120] = renderBasicInfo;
        $[121] = renderMetadataTab;
        $[122] = renderParsedContentTab;
        $[123] = selectedTab;
        $[124] = t;
        $[125] = t54;
    } else {
        t54 = $[125];
    }
    let t55;
    if ($[126] !== t22 || $[127] !== t53 || $[128] !== t54) {
        t55 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
            sx: t22,
            children: [
                t53,
                t54
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 818,
            columnNumber: 11
        }, this);
        $[126] = t22;
        $[127] = t53;
        $[128] = t54;
        $[129] = t55;
    } else {
        t55 = $[129];
    }
    const t56 = confirmDialog.open;
    let t57;
    if ($[130] === Symbol.for("react.memo_cache_sentinel")) {
        t57 = {
            vertical: "top",
            horizontal: "center"
        };
        $[130] = t57;
    } else {
        t57 = $[130];
    }
    const t58 = confirmDialog.severity;
    let t59;
    if ($[131] === Symbol.for("react.memo_cache_sentinel")) {
        t59 = {
            width: "100%",
            minWidth: "300px",
            boxShadow: 3
        };
        $[131] = t59;
    } else {
        t59 = $[131];
    }
    let t60;
    if ($[132] === Symbol.for("react.memo_cache_sentinel")) {
        t60 = {
            display: "flex",
            gap: 1,
            ml: 2
        };
        $[132] = t60;
    } else {
        t60 = $[132];
    }
    let t61;
    if ($[133] !== confirmDialog) {
        t61 = ({
            "FileMetadataComponent[<Button>.onClick]": (e_5)=>{
                e_5.stopPropagation();
                if (confirmDialog.onConfirm) {
                    confirmDialog.onConfirm();
                }
            }
        })["FileMetadataComponent[<Button>.onClick]"];
        $[133] = confirmDialog;
        $[134] = t61;
    } else {
        t61 = $[134];
    }
    let t62;
    if ($[135] !== t) {
        t62 = t("fileMetadataComponent.confirm");
        $[135] = t;
        $[136] = t62;
    } else {
        t62 = $[136];
    }
    let t63;
    if ($[137] !== t61 || $[138] !== t62) {
        t63 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            color: "inherit",
            size: "small",
            onClick: t61,
            variant: "outlined",
            children: t62
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 885,
            columnNumber: 11
        }, this);
        $[137] = t61;
        $[138] = t62;
        $[139] = t63;
    } else {
        t63 = $[139];
    }
    let t64;
    if ($[140] === Symbol.for("react.memo_cache_sentinel")) {
        t64 = ({
            "FileMetadataComponent[<Button>.onClick]": (e_6)=>{
                e_6.stopPropagation();
                setConfirmDialog({
                    open: false,
                    message: "",
                    onConfirm: null,
                    severity: "warning"
                });
            }
        })["FileMetadataComponent[<Button>.onClick]"];
        $[140] = t64;
    } else {
        t64 = $[140];
    }
    let t65;
    if ($[141] !== t) {
        t65 = t("fileMetadataComponent.cancel");
        $[141] = t;
        $[142] = t65;
    } else {
        t65 = $[142];
    }
    let t66;
    if ($[143] !== t65) {
        t66 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            color: "inherit",
            size: "small",
            onClick: t64,
            variant: "contained",
            children: t65
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 919,
            columnNumber: 11
        }, this);
        $[143] = t65;
        $[144] = t66;
    } else {
        t66 = $[144];
    }
    let t67;
    if ($[145] !== t63 || $[146] !== t66) {
        t67 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t60,
            children: [
                t63,
                t66
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 927,
            columnNumber: 11
        }, this);
        $[145] = t63;
        $[146] = t66;
        $[147] = t67;
    } else {
        t67 = $[147];
    }
    let t68;
    if ($[148] !== confirmDialog.message || $[149] !== confirmDialog.severity || $[150] !== t67) {
        t68 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
            severity: t58,
            sx: t59,
            action: t67,
            children: confirmDialog.message
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 936,
            columnNumber: 11
        }, this);
        $[148] = confirmDialog.message;
        $[149] = confirmDialog.severity;
        $[150] = t67;
        $[151] = t68;
    } else {
        t68 = $[151];
    }
    let t69;
    if ($[152] !== confirmDialog.open || $[153] !== t68) {
        t69 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__["Portal"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
                open: t56,
                anchorOrigin: t57,
                onClose: _FileMetadataComponentSnackbarOnClose,
                children: t68
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
                lineNumber: 946,
                columnNumber: 19
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 946,
            columnNumber: 11
        }, this);
        $[152] = confirmDialog.open;
        $[153] = t68;
        $[154] = t69;
    } else {
        t69 = $[154];
    }
    let t70;
    if ($[155] !== t55 || $[156] !== t69) {
        t70 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t19,
            children: [
                t55,
                t69
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx",
            lineNumber: 955,
            columnNumber: 11
        }, this);
        $[155] = t55;
        $[156] = t69;
        $[157] = t70;
    } else {
        t70 = $[157];
    }
    return t70;
}
_s(FileMetadataComponent, "LNvTBA7LUTZ1ehaaeP3DHG6OAm8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c1 = FileMetadataComponent;
function _FileMetadataComponentSnackbarOnClose(event_0, reason) {
    if (reason === "clickaway") {
        return;
    }
}
var _c, _c1;
__turbopack_context__.k.register(_c, "TabPanel");
__turbopack_context__.k.register(_c1, "FileMetadataComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/nodes/FileMetadataNode/index.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createFileMetadataNode",
    ()=>$createFileMetadataNode,
    "$isFileMetadataNode",
    ()=>$isFileMetadataNode,
    "FileMetadataNode",
    ()=>FileMetadataNode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
// Import the component
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$nodes$2f$FileMetadataNode$2f$FileMetadataComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/nodes/FileMetadataNode/FileMetadataComponent.jsx [app-client] (ecmascript)");
;
;
;
class FileMetadataNode extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __file;
    __parsedContent;
    static getType() {
        return "file-metadata";
    }
    static clone(node) {
        return new FileMetadataNode(node.__file, node.__parsedContent, node.__key);
    }
    static importJSON(serializedNode) {
        const { file, parsedContent } = serializedNode;
        const node = $createFileMetadataNode(file, parsedContent);
        return node;
    }
    exportJSON() {
        return {
            file: this.__file,
            parsedContent: this.__parsedContent,
            type: "file-metadata",
            version: 1
        };
    }
    constructor(file, parsedContent, key){
        super(key);
        this.__file = file;
        this.__parsedContent = parsedContent;
    }
    createDOM(config) {
        const div = document.createElement("div");
        div.style.display = "contents";
        return div;
    }
    updateDOM() {
        return false;
    }
    exportDOM() {
        const element = document.createElement("div");
        element.setAttribute("data-lexical-file-metadata", "true");
        element.setAttribute("data-file", JSON.stringify(this.__file));
        return {
            element
        };
    }
    static importDOM() {
        return {
            div: (domNode)=>{
                if (!domNode.hasAttribute("data-lexical-file-metadata")) {
                    return null;
                }
                return {
                    conversion: (element)=>{
                        const fileStr = element.getAttribute("data-file");
                        const file = fileStr ? JSON.parse(fileStr) : null;
                        if (!file) return null;
                        return {
                            node: $createFileMetadataNode(file, null)
                        };
                    },
                    priority: 1
                };
            }
        };
    }
    setFile(file) {
        const writable = this.getWritable();
        writable.__file = file;
    }
    setParsedContent(parsedContent) {
        const writable = this.getWritable();
        writable.__parsedContent = parsedContent;
    }
    getFile() {
        return this.__file;
    }
    getParsedContent() {
        return this.__parsedContent;
    }
    decorate(editor, config) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: null,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$nodes$2f$FileMetadataNode$2f$FileMetadataComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                file: this.__file,
                parsedContent: this.__parsedContent,
                nodeKey: this.getKey(),
                onFileNameUpdate: (newName)=>{
                    editor.update(()=>{
                        const writableNode = this.getWritable();
                        writableNode.__file = {
                            ...writableNode.__file,
                            name: newName
                        };
                    });
                },
                onRemove: (nodeKey)=>{
                    editor.update(()=>{
                        const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(nodeKey);
                        if (node) {
                            node.remove();
                        }
                    });
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/index.jsx",
                lineNumber: 94,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/nodes/FileMetadataNode/index.jsx",
            lineNumber: 93,
            columnNumber: 7
        }, this);
    }
    isInline() {
        return false;
    }
    isKeyboardSelectable() {
        return true;
    }
}
function $createFileMetadataNode(file, parsedContent) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new FileMetadataNode(file, parsedContent));
}
function $isFileMetadataNode(node) {
    return node instanceof FileMetadataNode;
}
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_Editor3_nodes_0on4508._.js.map