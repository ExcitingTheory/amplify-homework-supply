(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/themes/editorThemes.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "THEME_PALETTES",
    ()=>THEME_PALETTES,
    "getCustomThemeOptions",
    ()=>getCustomThemeOptions,
    "getThemeOptions",
    ()=>getThemeOptions
]);
/**
 * Editor theme palette definitions for the CosmeticSelector themes.
 * Each theme defines both light and dark MUI palette overrides.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$colors$2f$red$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__red$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/colors/red.js [app-client] (ecmascript) <export default as red>");
;
const THEME_PALETTES = {
    default: {
        light: {
            primary: {
                main: "#556cd6"
            },
            secondary: {
                main: "#19857b"
            },
            error: {
                main: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$colors$2f$red$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__red$3e$__["red"].A400
            },
            background: {
                default: "#fafafa",
                paper: "#ffffff"
            },
            custom: {
                chatBubbleUser: "#e3f2fd",
                chatBubbleAssistant: "#f3f4f6",
                glassNavbar: "rgba(255,255,255,0.72)",
                editorBackground: "#ffffff",
                codeBlock: "#f6f8fa",
                searchHighlight: "#ffeb3b",
                subtleBorder: "#e0e0e0"
            }
        },
        dark: {
            primary: {
                main: "#7986cb"
            },
            secondary: {
                main: "#4db6ac"
            },
            error: {
                main: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$colors$2f$red$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__red$3e$__["red"].A200
            },
            background: {
                default: "#121212",
                paper: "#1e1e1e"
            },
            text: {
                primary: "#e0e0e0",
                secondary: "#a0a0a0"
            },
            custom: {
                chatBubbleUser: "#1a2634",
                chatBubbleAssistant: "#2d2d2d",
                glassNavbar: "rgba(30,30,30,0.85)",
                editorBackground: "#1e1e1e",
                codeBlock: "#161b22",
                searchHighlight: "#b8860b",
                subtleBorder: "#333333"
            }
        }
    },
    midnight: {
        light: {
            primary: {
                main: "#00bcd4"
            },
            secondary: {
                main: "#26c6da"
            },
            background: {
                default: "#f0f4f8",
                paper: "#ffffff"
            },
            custom: {
                chatBubbleUser: "#e0f7fa",
                chatBubbleAssistant: "#e8eaf6",
                glassNavbar: "rgba(240,244,248,0.85)",
                editorBackground: "#ffffff",
                codeBlock: "#eceff1",
                searchHighlight: "#80deea",
                subtleBorder: "#b0bec5"
            }
        },
        dark: {
            primary: {
                main: "#00bcd4"
            },
            secondary: {
                main: "#26c6da"
            },
            background: {
                default: "#1a1a2e",
                paper: "#16213e"
            },
            text: {
                primary: "#e0e0e0",
                secondary: "#90a4ae"
            },
            custom: {
                chatBubbleUser: "#1a2634",
                chatBubbleAssistant: "#1a1a2e",
                glassNavbar: "rgba(26,26,46,0.85)",
                editorBackground: "#16213e",
                codeBlock: "#0f3460",
                searchHighlight: "#006064",
                subtleBorder: "#2a3a5e"
            }
        }
    },
    forest: {
        light: {
            primary: {
                main: "#66bb6a"
            },
            secondary: {
                main: "#81c784"
            },
            background: {
                default: "#f1f8e9",
                paper: "#ffffff"
            },
            custom: {
                chatBubbleUser: "#e8f5e9",
                chatBubbleAssistant: "#f1f8e9",
                glassNavbar: "rgba(241,248,233,0.85)",
                editorBackground: "#ffffff",
                codeBlock: "#e8f5e9",
                searchHighlight: "#aed581",
                subtleBorder: "#c8e6c9"
            }
        },
        dark: {
            primary: {
                main: "#66bb6a"
            },
            secondary: {
                main: "#81c784"
            },
            background: {
                default: "#1b2d1b",
                paper: "#2e3d2e"
            },
            text: {
                primary: "#c8e6c9",
                secondary: "#81c784"
            },
            custom: {
                chatBubbleUser: "#1b3d1b",
                chatBubbleAssistant: "#2e3d2e",
                glassNavbar: "rgba(27,45,27,0.85)",
                editorBackground: "#2e3d2e",
                codeBlock: "#1b3d1b",
                searchHighlight: "#33691e",
                subtleBorder: "#4a6a4a"
            }
        }
    },
    sunset: {
        light: {
            primary: {
                main: "#ff7043"
            },
            secondary: {
                main: "#ffab91"
            },
            background: {
                default: "#fff3e0",
                paper: "#ffffff"
            },
            custom: {
                chatBubbleUser: "#fbe9e7",
                chatBubbleAssistant: "#fff3e0",
                glassNavbar: "rgba(255,243,224,0.85)",
                editorBackground: "#ffffff",
                codeBlock: "#fbe9e7",
                searchHighlight: "#ffcc80",
                subtleBorder: "#ffccbc"
            }
        },
        dark: {
            primary: {
                main: "#ff7043"
            },
            secondary: {
                main: "#ffab91"
            },
            background: {
                default: "#2d1b1b",
                paper: "#3e2723"
            },
            text: {
                primary: "#ffccbc",
                secondary: "#ffab91"
            },
            custom: {
                chatBubbleUser: "#3e2723",
                chatBubbleAssistant: "#2d1b1b",
                glassNavbar: "rgba(45,27,27,0.85)",
                editorBackground: "#3e2723",
                codeBlock: "#4e342e",
                searchHighlight: "#bf360c",
                subtleBorder: "#5d4037"
            }
        }
    },
    aurora: {
        light: {
            primary: {
                main: "#ab47bc"
            },
            secondary: {
                main: "#ce93d8"
            },
            background: {
                default: "#f3e5f5",
                paper: "#ffffff"
            },
            custom: {
                chatBubbleUser: "#f3e5f5",
                chatBubbleAssistant: "#ede7f6",
                glassNavbar: "rgba(243,229,245,0.85)",
                editorBackground: "#ffffff",
                codeBlock: "#ede7f6",
                searchHighlight: "#e1bee7",
                subtleBorder: "#ce93d8"
            }
        },
        dark: {
            primary: {
                main: "#ab47bc"
            },
            secondary: {
                main: "#ce93d8"
            },
            background: {
                default: "#0d1b2a",
                paper: "#1b2838"
            },
            text: {
                primary: "#e0f7fa",
                secondary: "#b39ddb"
            },
            custom: {
                chatBubbleUser: "#1b2838",
                chatBubbleAssistant: "#0d1b2a",
                glassNavbar: "rgba(13,27,42,0.85)",
                editorBackground: "#1b2838",
                codeBlock: "#1a237e",
                searchHighlight: "#4a148c",
                subtleBorder: "#311b92"
            }
        }
    }
};
function getThemeOptions(themeId) {
    const palette = THEME_PALETTES[themeId || "default"] ?? THEME_PALETTES.default;
    return {
        cssVariables: {
            colorSchemeSelector: "data-mui-color-scheme"
        },
        colorSchemes: {
            light: {
                palette: palette.light
            },
            dark: {
                palette: palette.dark
            }
        }
    };
}
function getCustomThemeOptions(palette) {
    return {
        cssVariables: {
            colorSchemeSelector: "data-mui-color-scheme"
        },
        colorSchemes: {
            light: {
                palette: palette.light
            },
            dark: {
                palette: palette.dark
            }
        }
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/theme.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createTheme$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/createTheme.js [app-client] (ecmascript) <export default as createTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$themes$2f$editorThemes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/themes/editorThemes.ts [app-client] (ecmascript)");
;
;
// Create the default theme instance using the shared palette definitions.
// ThemeRegistry uses this as the base; DynamicThemeProvider overrides it
// with the user's selected cosmetic theme at runtime.
const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createTheme$3e$__["createTheme"])({
    ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$themes$2f$editorThemes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getThemeOptions"])('default'),
    components: {
        MuiAccordionSummary: {
            defaultProps: {
                slotProps: {
                    content: {
                        component: 'div'
                    }
                }
            }
        }
    }
});
const __TURBOPACK__default__export__ = theme;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useColorMode.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useColorMode",
    ()=>useColorMode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/ThemeProviderWithVars.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/settingsContext.jsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
/**
 * Resolve the effective color scheme ('light' or 'dark') from MUI mode.
 * Used to persist the resolved value in a cookie for SSR.
 */ function resolveScheme(muiMode) {
    if (muiMode === 'dark') return 'dark';
    if (muiMode === 'light') return 'light';
    // 'system' — check media query (client only)
    if ("TURBOPACK compile-time truthy", 1) {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    //TURBOPACK unreachable
    ;
}
function setColorSchemeCookie(muiMode) {
    if (typeof document === 'undefined') return;
    const resolved = resolveScheme(muiMode);
    document.cookie = `mui-color-scheme=${resolved};path=/;max-age=31536000;SameSite=Lax`;
}
function useColorMode() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "045e84dbf9b7e9eb579fb81aabcbeb155dfcd717307348b640a1b40aa9b9f6d1") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "045e84dbf9b7e9eb579fb81aabcbeb155dfcd717307348b640a1b40aa9b9f6d1";
    }
    const { settings, updateSettings } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {};
    const { mode, setMode } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"])();
    let t0;
    if ($[1] !== setMode || $[2] !== settings) {
        t0 = ({
            "useColorMode[useEffect()]": ()=>{
                if (!settings?.editorTheme) {
                    return;
                }
                const muiMode = settings.editorTheme === "auto" ? "system" : settings.editorTheme;
                setMode(muiMode);
                setColorSchemeCookie(muiMode);
            }
        })["useColorMode[useEffect()]"];
        $[1] = setMode;
        $[2] = settings;
        $[3] = t0;
    } else {
        t0 = $[3];
    }
    const t1 = settings?.editorTheme;
    let t2;
    if ($[4] !== setMode || $[5] !== t1) {
        t2 = [
            t1,
            setMode
        ];
        $[4] = setMode;
        $[5] = t1;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t0, t2);
    let t3;
    let t4;
    if ($[7] !== mode) {
        t3 = ({
            "useColorMode[useEffect()]": ()=>{
                if (mode) {
                    setColorSchemeCookie(mode);
                }
            }
        })["useColorMode[useEffect()]"];
        t4 = [
            mode
        ];
        $[7] = mode;
        $[8] = t3;
        $[9] = t4;
    } else {
        t3 = $[8];
        t4 = $[9];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t3, t4);
    let t5;
    if ($[10] !== setMode || $[11] !== updateSettings) {
        t5 = ({
            "useColorMode[setColorMode]": (value)=>{
                const muiMode_0 = value === "auto" ? "system" : value;
                setMode(muiMode_0);
                setColorSchemeCookie(muiMode_0);
                if (updateSettings) {
                    updateSettings({
                        editorTheme: value
                    });
                }
            }
        })["useColorMode[setColorMode]"];
        $[10] = setMode;
        $[11] = updateSettings;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    const setColorMode = t5;
    const t6 = settings?.editorTheme || "auto";
    let t7;
    if ($[13] !== setColorMode || $[14] !== t6) {
        t7 = {
            mode: t6,
            setColorMode
        };
        $[13] = setColorMode;
        $[14] = t6;
        $[15] = t7;
    } else {
        t7 = $[15];
    }
    return t7;
}
_s(useColorMode, "blttdPbTC2OMv+WK7dU4MbWcOLU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useAvatarConfig.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useAvatarConfig",
    ()=>useAvatarConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * useAvatarConfig — Returns the current user's saved avatar configuration
 * from SettingsContext. All DiceBearAvatar instances for the current user
 * should consume this hook so they render identically.
 *
 * IMPORTANT: This hook must NOT depend on GamificationContext/useXP for
 * style resolution. The toolbar renders outside any GamificationProvider,
 * so level-based fallbacks would produce different styles than the profile
 * page (which has a provider). The saved style in settings.metadata is the
 * single source of truth. If none is saved, 'simple' is the default.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/settingsContext.jsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useAvatarConfig() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    if ($[0] !== "ea296ef64ef2f5d9068cb31d24f6751652fa856192220f8151623f26013e3bb8") {
        for(let $i = 0; $i < 11; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "ea296ef64ef2f5d9068cb31d24f6751652fa856192220f8151623f26013e3bb8";
    }
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const settings = ctx?.settings;
    const isLoaded = ctx ? !ctx.isLoading : false;
    const rawMetadata = settings?.metadata;
    const seed = settings?.owner || "";
    let t0;
    if ($[1] !== rawMetadata) {
        t0 = typeof rawMetadata === "string" ? (()=>{
            try {
                return JSON.parse(rawMetadata);
            } catch  {
                return {};
            }
        })() : rawMetadata || {};
        $[1] = rawMetadata;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const metadata = t0;
    const savedStyle = metadata.avatarStyle || undefined;
    const style = savedStyle || "simple";
    let t1;
    if ($[3] !== metadata.avatarOverrides) {
        t1 = metadata.avatarOverrides || {};
        $[3] = metadata.avatarOverrides;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    const overrides = t1;
    const glowRing = metadata.glowRing || null;
    let t2;
    if ($[5] !== glowRing || $[6] !== isLoaded || $[7] !== overrides || $[8] !== seed || $[9] !== style) {
        t2 = {
            style,
            overrides,
            isLoaded,
            seed,
            glowRing
        };
        $[5] = glowRing;
        $[6] = isLoaded;
        $[7] = overrides;
        $[8] = seed;
        $[9] = style;
        $[10] = t2;
    } else {
        t2 = $[10];
    }
    return t2;
}
_s(useAvatarConfig, "/dMy7t63NXD4eYACoT93CePwGrg=");
const __TURBOPACK__default__export__ = useAvatarConfig;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useNetworkStatus.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useNetworkStatus",
    ()=>useNetworkStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function useNetworkStatus() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "af23b45f71148e1d99782001b176cdc44c281f91feaa67acf2bcb2c8726aac2e") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "af23b45f71148e1d99782001b176cdc44c281f91feaa67acf2bcb2c8726aac2e";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            isOnline: true,
            lastChanged: 0
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "useNetworkStatus[handleOnline]": ()=>{
                setStatus({
                    isOnline: true,
                    lastChanged: Date.now()
                });
            }
        })["useNetworkStatus[handleOnline]"];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const handleOnline = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "useNetworkStatus[handleOffline]": ()=>{
                setStatus({
                    isOnline: false,
                    lastChanged: Date.now()
                });
            }
        })["useNetworkStatus[handleOffline]"];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const handleOffline = t2;
    let t3;
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "useNetworkStatus[useEffect()]": ()=>{
                setStatus({
                    isOnline: navigator.onLine,
                    lastChanged: Date.now()
                });
                window.addEventListener("online", handleOnline);
                window.addEventListener("offline", handleOffline);
                return ()=>{
                    window.removeEventListener("online", handleOnline);
                    window.removeEventListener("offline", handleOffline);
                };
            }
        })["useNetworkStatus[useEffect()]"];
        t4 = [
            handleOnline,
            handleOffline
        ];
        $[4] = t3;
        $[5] = t4;
    } else {
        t3 = $[4];
        t4 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    return status;
}
_s(useNetworkStatus, "B8TRFOq4idqqChSHYEZWZgF2hew=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useYjsFile.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useYjsFile",
    ()=>useYjsFile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/compiled/buffer/index.js [app-client] (ecmascript)");
/**
 * useYjsFile - Real-time collaborative file metadata management hook
 *
 * Integrates Yjs CRDT for conflict-free file operations with Amplify GraphQL
 * for cross-device persistence. Eliminates version conflicts during file deletion.
 *
 * @example
 * ```typescript
 * const { metadata, deleteFile, isSynced } = useYjsFile({ fileId: 'file-123' });
 *
 * // Update metadata - syncs automatically across clients
 * metadata?.set('name', 'new-name.pdf');
 *
 * // Delete file - no version conflicts!
 * await deleteFile();
 * ```
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$hooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/hooks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$unitContentStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/unitContentStorage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/remove.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/yjs/dist/yjs.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
function useYjsFile(config) {
    _s();
    const { fileId, enableWebSocket = true, enablePersistence = true, saveDebounceMs = 3000, bumpVersion } = config;
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
    const [file, setFile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const saveTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const isDeletingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    // Initialize Yjs provider only if we have a fileId
    const { provider, isSynced, isConnected } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$hooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useYjsProvider"])({
        docName: fileId ? `file-${fileId}` : "file-null",
        connect: enableWebSocket && !!fileId,
        persistence: enablePersistence && !!fileId
    });
    // Load initial state from Amplify
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsFile.useEffect": ()=>{
            if (!fileId) {
                setIsLoading(false);
                return;
            }
            async function loadFile() {
                try {
                    setIsLoading(true);
                    const { data } = await client.models.File.get({
                        id: fileId
                    });
                    if (!data) {
                        throw new Error(`File ${fileId} not found`);
                    }
                    setFile(data);
                    // Apply Yjs snapshot from S3 (fall back to DynamoDB for migration)
                    if (provider) {
                        const identityId = data.identityId || data.owner;
                        let applied = false;
                        if (identityId) {
                            const s3Snapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$unitContentStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadModelYjsSnapshot"])(identityId, "files", fileId);
                            if (s3Snapshot) {
                                applied = provider.applyUpdate(s3Snapshot);
                                if (applied) {
                                    console.log(`[useYjsFile] Applied Yjs snapshot from S3 for file ${fileId}`);
                                }
                            }
                        }
                        // Fall back to DynamoDB field (legacy data)
                        if (!applied && data.yjsSnapshot) {
                            const updateBytes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(data.yjsSnapshot, "base64");
                            if (provider.applyUpdate(updateBytes)) {
                                console.log(`[useYjsFile] Applied legacy DynamoDB snapshot for file ${fileId}`);
                            } else {
                                console.warn("[useYjsFile] Snapshot was corrupt — skipped");
                            }
                        } else if (!applied) {
                            // Initialize Yjs metadata from existing file data
                            const ymap = provider.getMap("metadata");
                            // Only initialize if empty (first time)
                            if (ymap.size === 0) {
                                Object.entries(data).forEach({
                                    "useYjsFile.useEffect.loadFile": ([key, value])=>{
                                        // Skip internal fields, relationships, and timestamps
                                        if (!key.startsWith("_") && !key.includes("ID") && key !== "createdAt" && key !== "updatedAt") {
                                            const type = typeof value;
                                            if (value === null || type === "string" || type === "number" || type === "boolean") {
                                                ymap.set(key, value);
                                            }
                                        }
                                    }
                                }["useYjsFile.useEffect.loadFile"]);
                                console.log(`[useYjsFile] Initialized Yjs metadata for file ${fileId}`);
                            }
                        }
                    }
                    setIsLoading(false);
                } catch (err) {
                    console.error("[useYjsFile] Failed to load file:", err);
                    setError(err);
                    setIsLoading(false);
                }
            }
            if (provider) {
                loadFile();
            }
        }
    }["useYjsFile.useEffect"], [
        fileId,
        provider,
        client
    ]);
    // Debounced save to GraphQL
    const saveToGraphQL = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useYjsFile.useCallback[saveToGraphQL]": async ()=>{
            if (!fileId || !provider || isDeletingRef.current) {
                return;
            }
            try {
                const ymap_0 = provider.getMap("metadata");
                // Check if file is marked deleted
                if (ymap_0.get("_deleted")) {
                    console.log(`[useYjsFile] File ${fileId} marked deleted, skipping save`);
                    return;
                }
                // Save Yjs snapshot to S3 (not DynamoDB)
                const yjsState = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeStateAsUpdate"](provider.getDoc());
                const identityId_0 = file?.identityId || file?.owner;
                if (identityId_0) {
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$unitContentStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveModelYjsSnapshot"])(identityId_0, "files", fileId, yjsState);
                }
                // Extract metadata for GraphQL update (no yjsSnapshot field)
                const fileData = {
                    id: fileId
                };
                ymap_0.forEach({
                    "useYjsFile.useCallback[saveToGraphQL]": (value_0, key_0)=>{
                        // Skip internal Yjs fields
                        if (!key_0.startsWith("_")) {
                            fileData[key_0] = value_0;
                        }
                    }
                }["useYjsFile.useCallback[saveToGraphQL]"]);
                // Optimistic version bump to block subscription echo
                const currentVersion = file?._version;
                const versionCtrl = bumpVersion && currentVersion != null ? bumpVersion(fileId, currentVersion) : null;
                if (currentVersion != null) {
                    fileData._version = currentVersion;
                }
                console.log(`[useYjsFile] Saving file ${fileId} to GraphQL`);
                const { data: saved, errors } = await client.models.File.update(fileData);
                if (errors?.length) {
                    console.error(`[useYjsFile] Errors saving file ${fileId}:`, errors);
                    versionCtrl?.rollback();
                } else {
                    if (saved) setFile(saved);
                    if (saved?._version != null) versionCtrl?.confirm(saved._version);
                    console.log(`[useYjsFile] Successfully saved file ${fileId}`);
                }
            } catch (err_0) {
                console.error("[useYjsFile] Failed to save to GraphQL:", err_0);
                setError(err_0);
            }
        }
    }["useYjsFile.useCallback[saveToGraphQL]"], [
        provider,
        fileId,
        client,
        file,
        bumpVersion
    ]);
    // Schedule debounced save on Y.Doc changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsFile.useEffect": ()=>{
            if (!provider) return;
            const updateHandler = {
                "useYjsFile.useEffect.updateHandler": ()=>{
                    // Clear existing timer
                    if (saveTimerRef.current) {
                        clearTimeout(saveTimerRef.current);
                    }
                    // Schedule new save
                    saveTimerRef.current = setTimeout({
                        "useYjsFile.useEffect.updateHandler": ()=>{
                            saveToGraphQL().catch({
                                "useYjsFile.useEffect.updateHandler": (err_1)=>{
                                    console.error("[useYjsFile] Debounced save failed:", err_1);
                                }
                            }["useYjsFile.useEffect.updateHandler"]);
                        }
                    }["useYjsFile.useEffect.updateHandler"], saveDebounceMs);
                }
            }["useYjsFile.useEffect.updateHandler"];
            const unsubscribe = provider.onUpdate(updateHandler);
            return ({
                "useYjsFile.useEffect": ()=>{
                    unsubscribe();
                    if (saveTimerRef.current) {
                        clearTimeout(saveTimerRef.current);
                    }
                }
            })["useYjsFile.useEffect"];
        }
    }["useYjsFile.useEffect"], [
        provider,
        saveToGraphQL,
        saveDebounceMs
    ]);
    // Update metadata helper
    const updateMetadata = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useYjsFile.useCallback[updateMetadata]": (updates)=>{
            if (!fileId || !provider) {
                console.warn("[useYjsFile] Cannot update metadata: no fileId or provider");
                return;
            }
            const ymap_1 = provider.getMap("metadata");
            Object.entries(updates).forEach({
                "useYjsFile.useCallback[updateMetadata]": ([key_1, value_1])=>{
                    ymap_1.set(key_1, value_1);
                }
            }["useYjsFile.useCallback[updateMetadata]"]);
            console.log("[useYjsFile] Updated metadata:", updates);
        }
    }["useYjsFile.useCallback[updateMetadata]"], [
        provider,
        fileId
    ]);
    // Delete file helper - no version conflicts!
    const deleteFile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useYjsFile.useCallback[deleteFile]": async ()=>{
            if (!fileId || !provider) {
                throw new Error("Cannot delete: no fileId or provider");
            }
            isDeletingRef.current = true;
            try {
                const ymap_2 = provider.getMap("metadata");
                // Get S3 path (access level is encoded in the path for Gen 2)
                const path = ymap_2.get("path") || file?.path;
                console.log(`[useYjsFile] Deleting file ${fileId} from S3: ${path}`);
                // Delete from S3 (if path exists)
                if (path) {
                    try {
                        // Gen 2 API: use path directly (access level is encoded in the path)
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["remove"])({
                            path: path
                        });
                        console.log(`[useYjsFile] Deleted from S3: ${path}`);
                    } catch (s3Error) {
                        console.warn("[useYjsFile] S3 deletion failed:", s3Error);
                    // Continue with database deletion even if S3 fails
                    }
                }
                // Mark deleted in Yjs
                ymap_2.set("_deleted", true);
                ymap_2.set("deletedAt", new Date().toISOString());
                // Force immediate save
                if (saveTimerRef.current) {
                    clearTimeout(saveTimerRef.current);
                }
                await saveToGraphQL();
                // Delete from GraphQL - no _version needed!
                await client.models.File.delete({
                    id: fileId
                });
                console.log(`[useYjsFile] Successfully deleted file ${fileId}`);
            } catch (err_2) {
                console.error(`[useYjsFile] Error deleting file ${fileId}:`, err_2);
                isDeletingRef.current = false;
                throw err_2;
            }
        }
    }["useYjsFile.useCallback[deleteFile]"], [
        fileId,
        provider,
        file,
        client,
        saveToGraphQL
    ]);
    // Force save helper
    const forceSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useYjsFile.useCallback[forceSave]": async ()=>{
            if (saveTimerRef.current) {
                clearTimeout(saveTimerRef.current);
            }
            await saveToGraphQL();
        }
    }["useYjsFile.useCallback[forceSave]"], [
        saveToGraphQL
    ]);
    return {
        provider: provider || null,
        file,
        metadata: provider ? provider.getMap("metadata") : null,
        isLoading,
        error,
        isSynced,
        isConnected,
        updateMetadata,
        deleteFile,
        forceSave
    };
}
_s(useYjsFile, "dU7HjTmWbl5VEd9nNTN7g0ncaDk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$hooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useYjsProvider"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useRecycleBin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRecycleBin",
    ()=>useRecycleBin,
    "useRecycleBinAdmin",
    ()=>useRecycleBinAdmin
]);
/**
 * useRecycleBin — React hook for soft delete, restore, and permanent delete operations.
 *
 * Wraps the custom GraphQL mutations/queries defined in the recycleBin Lambda.
 * Use in components that need delete/restore functionality.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
const SUPPORTED_MODELS = [
    "Unit",
    "Section",
    "Question",
    "Word",
    "File",
    "Document",
    "AssistantChat"
];
function useRecycleBin() {
    _s();
    const [loading, setLoading] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [error, setError] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const client = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "useRecycleBin.useMemo[client]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])()
    }["useRecycleBin.useMemo[client]"], []);
    /**
   * Soft delete a record (sets deletedAt, cascades to join tables)
   */ const softDelete = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useRecycleBin.useCallback[softDelete]": async (modelName, id)=>{
            if (!SUPPORTED_MODELS.includes(modelName)) {
                throw new Error(`Unsupported model: ${modelName}`);
            }
            setLoading(true);
            setError(null);
            try {
                const { data } = await client.graphql({
                    query: `mutation SoftDelete($modelName: String!, $id: ID!) {
            softDelete(modelName: $modelName, id: $id)
          }`,
                    variables: {
                        modelName,
                        id
                    }
                });
                const result = typeof data.softDelete === "string" ? JSON.parse(data.softDelete) : data.softDelete;
                if (!result.success) {
                    throw new Error(result.message || "Soft delete failed");
                }
                return result;
            } catch (err) {
                const message = err?.message || "Soft delete failed";
                setError(message);
                throw err;
            } finally{
                setLoading(false);
            }
        }
    }["useRecycleBin.useCallback[softDelete]"], [
        client
    ]);
    /**
   * Restore a soft-deleted record (clears deletedAt, cascades to join tables)
   */ const restoreRecord = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useRecycleBin.useCallback[restoreRecord]": async (modelName, id)=>{
            if (!SUPPORTED_MODELS.includes(modelName)) {
                throw new Error(`Unsupported model: ${modelName}`);
            }
            setLoading(true);
            setError(null);
            try {
                const { data } = await client.graphql({
                    query: `mutation RestoreRecord($modelName: String!, $id: ID!) {
            restoreRecord(modelName: $modelName, id: $id)
          }`,
                    variables: {
                        modelName,
                        id
                    }
                });
                const result = typeof data.restoreRecord === "string" ? JSON.parse(data.restoreRecord) : data.restoreRecord;
                if (!result.success) {
                    throw new Error(result.message || "Restore failed");
                }
                return result;
            } catch (err) {
                const message = err?.message || "Restore failed";
                setError(message);
                throw err;
            } finally{
                setLoading(false);
            }
        }
    }["useRecycleBin.useCallback[restoreRecord]"], [
        client
    ]);
    /**
   * Permanently delete a record (archives to S3, removes from DynamoDB)
   */ const permanentDelete = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useRecycleBin.useCallback[permanentDelete]": async (modelName, id)=>{
            if (!SUPPORTED_MODELS.includes(modelName)) {
                throw new Error(`Unsupported model: ${modelName}`);
            }
            setLoading(true);
            setError(null);
            try {
                const { data } = await client.graphql({
                    query: `mutation PermanentDelete($modelName: String!, $id: ID!) {
            permanentDelete(modelName: $modelName, id: $id)
          }`,
                    variables: {
                        modelName,
                        id
                    }
                });
                const result = typeof data.permanentDelete === "string" ? JSON.parse(data.permanentDelete) : data.permanentDelete;
                if (!result.success) {
                    throw new Error(result.message || "Permanent delete failed");
                }
                return result;
            } catch (err) {
                const message = err?.message || "Permanent delete failed";
                setError(message);
                throw err;
            } finally{
                setLoading(false);
            }
        }
    }["useRecycleBin.useCallback[permanentDelete]"], [
        client
    ]);
    return {
        softDelete,
        restoreRecord,
        permanentDelete,
        loading,
        error,
        SUPPORTED_MODELS
    };
}
_s(useRecycleBin, "mA08+CbQvIZ/OJ0cRCsftBlYg30=");
function useRecycleBinAdmin() {
    _s1();
    const [loading, setLoading] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [error, setError] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const client = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "useRecycleBinAdmin.useMemo[client]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])()
    }["useRecycleBinAdmin.useMemo[client]"], []);
    /**
   * List archived records (admin only)
   */ const listArchives = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useRecycleBinAdmin.useCallback[listArchives]": async ({ modelName, limit, continuationToken } = {})=>{
            setLoading(true);
            setError(null);
            try {
                const { data } = await client.graphql({
                    query: `query ListArchives($modelName: String, $limit: Int, $continuationToken: String) {
            listArchives(modelName: $modelName, limit: $limit, continuationToken: $continuationToken)
          }`,
                    variables: {
                        modelName,
                        limit,
                        continuationToken
                    }
                });
                const result = typeof data.listArchives === "string" ? JSON.parse(data.listArchives) : data.listArchives;
                if (!result.success) {
                    throw new Error(result.message || "List archives failed");
                }
                return result;
            } catch (err) {
                const message = err?.message || "List archives failed";
                setError(message);
                throw err;
            } finally{
                setLoading(false);
            }
        }
    }["useRecycleBinAdmin.useCallback[listArchives]"], [
        client
    ]);
    /**
   * Get archive details (admin only)
   */ const getArchive = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useRecycleBinAdmin.useCallback[getArchive]": async (archiveKey)=>{
            setLoading(true);
            setError(null);
            try {
                const { data } = await client.graphql({
                    query: `query GetArchive($archiveKey: String!) {
            getArchive(archiveKey: $archiveKey)
          }`,
                    variables: {
                        archiveKey
                    }
                });
                const result = typeof data.getArchive === "string" ? JSON.parse(data.getArchive) : data.getArchive;
                if (!result.success) {
                    throw new Error(result.message || "Get archive failed");
                }
                return result;
            } catch (err) {
                const message = err?.message || "Get archive failed";
                setError(message);
                throw err;
            } finally{
                setLoading(false);
            }
        }
    }["useRecycleBinAdmin.useCallback[getArchive]"], [
        client
    ]);
    /**
   * Unarchive a record (admin only — recreates from S3 back to DynamoDB)
   */ const unarchiveRecord = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useRecycleBinAdmin.useCallback[unarchiveRecord]": async (archiveKey)=>{
            setLoading(true);
            setError(null);
            try {
                const { data } = await client.graphql({
                    query: `mutation UnarchiveRecord($archiveKey: String!) {
            unarchiveRecord(archiveKey: $archiveKey)
          }`,
                    variables: {
                        archiveKey
                    }
                });
                const result = typeof data.unarchiveRecord === "string" ? JSON.parse(data.unarchiveRecord) : data.unarchiveRecord;
                if (!result.success) {
                    throw new Error(result.message || "Unarchive failed");
                }
                return result;
            } catch (err) {
                const message = err?.message || "Unarchive failed";
                setError(message);
                throw err;
            } finally{
                setLoading(false);
            }
        }
    }["useRecycleBinAdmin.useCallback[unarchiveRecord]"], [
        client
    ]);
    return {
        listArchives,
        getArchive,
        unarchiveRecord,
        loading,
        error
    };
}
_s1(useRecycleBinAdmin, "ZiVM+knV3595CraG/MmsMas7BdE=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useNailedItDetection.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useNailedItDetection",
    ()=>useNailedItDetection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * useNailedItDetection — Hook that watches AI feedback messages for Nailed It
 * JSON envelopes, triggers celebrations, and awards XP.
 *
 * Wraps nailedItParser to integrate with the React component tree.
 *
 * @module useNailedItDetection
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$nailedItParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/nailedItParser.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useNailedItDetection(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "50845435d0670b9a7f7aa763e31fc968767bca8934afe4fe1b59da50455bb5f0") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "50845435d0670b9a7f7aa763e31fc968767bca8934afe4fe1b59da50455bb5f0";
    }
    let t1;
    if ($[1] !== t0) {
        t1 = t0 === undefined ? {} : t0;
        $[1] = t0;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const options = t1;
    const { onNailedIt, onAwardXP } = options;
    const [lastResult, setLastResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [showCelebration, setShowCelebration] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = new Set();
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const processedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(t2);
    let t3;
    if ($[4] !== onAwardXP || $[5] !== onNailedIt) {
        t3 = ({
            "useNailedItDetection[processResponse]": (response)=>{
                const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$nailedItParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseNailedItResponse"])(response);
                const hash = response.slice(0, 100);
                if (processedRef.current.has(hash)) {
                    return result;
                }
                processedRef.current.add(hash);
                setLastResult(result);
                if (result.nailedIt) {
                    setShowCelebration(true);
                    onNailedIt?.(result);
                    if (result.xpToAward > 0) {
                        onAwardXP?.(result.xpToAward, result.nailedItReason || "Nailed It!");
                    }
                }
                return result;
            }
        })["useNailedItDetection[processResponse]"];
        $[4] = onAwardXP;
        $[5] = onNailedIt;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const processResponse = t3;
    let t4;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "useNailedItDetection[dismissCelebration]": ()=>{
                setShowCelebration(false);
            }
        })["useNailedItDetection[dismissCelebration]"];
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    const dismissCelebration = t4;
    let t5;
    if ($[8] !== lastResult || $[9] !== processResponse || $[10] !== showCelebration) {
        t5 = {
            processResponse,
            lastResult,
            showCelebration,
            dismissCelebration
        };
        $[8] = lastResult;
        $[9] = processResponse;
        $[10] = showCelebration;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    return t5;
}
_s(useNailedItDetection, "J7hOhtWikpd+49CJQiDd/MwAcUc=");
const __TURBOPACK__default__export__ = useNailedItDetection;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useStudentMemory.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useStudentMemory",
    ()=>useStudentMemory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * useStudentMemory — Fetches and caches the current student's AI memory document.
 * Used to pass personalized context to OpenAI verify operations.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useStudentMemory(studentId) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "a24a10025f461c1a60abb292d4513d0802a720020c4c1519e33b3a34f77243cb") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a24a10025f461c1a60abb292d4513d0802a720020c4c1519e33b3a34f77243cb";
    }
    const [memory, setMemory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(undefined);
    const fetchedForRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t0;
    let t1;
    if ($[1] !== studentId) {
        t0 = ({
            "useStudentMemory[useEffect()]": ()=>{
                if (!studentId || fetchedForRef.current === studentId) {
                    return;
                }
                fetchedForRef.current = studentId;
                const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                if (!client?.models?.StudentMemory) {
                    return;
                }
                client.models.StudentMemory.list({
                    filter: {
                        studentId: {
                            eq: studentId
                        }
                    }
                }).then({
                    "useStudentMemory[useEffect() > (anonymous)()]": (t2)=>{
                        const { data } = t2;
                        const items = data || [];
                        if (items.length > 0 && items[0]?.memoryMarkdown) {
                            setMemory(items[0].memoryMarkdown);
                        }
                    }
                }["useStudentMemory[useEffect() > (anonymous)()]"]).catch(_useStudentMemoryUseEffectAnonymous);
            }
        })["useStudentMemory[useEffect()]"];
        t1 = [
            studentId
        ];
        $[1] = studentId;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return memory;
}
_s(useStudentMemory, "f/ubRgF0kDcOmO5YpK9U+08iNcU=");
function _useStudentMemoryUseEffectAnonymous(err) {
    console.warn("[useStudentMemory] Failed to fetch memory:", err);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useVerifyContext.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useVerifyContext",
    ()=>useVerifyContext
]);
/**
 * useVerifyContext — Provides studentMemory, contentContext, and exerciseHistory
 * for AI verify calls. Used by AnswerComponent and CustomAnswerComponent to
 * personalize feedback.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/fileContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useStudentMemory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useStudentMemory.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$buildContentContext$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/buildContentContext.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
/**
 * Build a compact summary of completed blocks from the current session.
 * Included in verify calls so AI has context of prior responses.
 */ function buildExerciseHistory(gradeData) {
    if (!gradeData || typeof gradeData !== 'object') return '';
    const completedBlocks = Object.entries(gradeData).filter(([, block])=>block?.complete).map(([blockId, block])=>{
        const parts = [
            `Block ${blockId}:`
        ];
        if (block.accuracy != null) parts.push(`accuracy=${block.accuracy}%`);
        if (block.userAnswer) parts.push(`answer="${String(block.userAnswer).slice(0, 200)}"`);
        if (block.nailedIt) parts.push('(Nailed It!)');
        return parts.join(' ');
    }).slice(0, 10); // Limit to 10 blocks to keep token count reasonable
    if (completedBlocks.length === 0) return '';
    return `## Completed Blocks This Session\n${completedBlocks.join('\n')}`;
}
function useVerifyContext() {
    _s();
    const { unit, files, session, grade } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { documents } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$fileContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const studentMemory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useStudentMemory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStudentMemory"])(session?.username);
    const contentContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useVerifyContext.useMemo[contentContext]": ()=>{
            const docArray = documents ? Object.values(documents).filter(Boolean) : [];
            const base = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$buildContentContext$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildContentContext"])({
                unit,
                files,
                documents: docArray
            });
            const history = buildExerciseHistory(grade?.data);
            return history ? `${base}\n\n${history}` : base;
        }
    }["useVerifyContext.useMemo[contentContext]"], [
        unit?.id,
        files,
        documents,
        grade?.data
    ]);
    return {
        studentMemory,
        contentContext
    };
}
_s(useVerifyContext, "cuHb6YA/975ym4NwuVjAk4qaQqE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useStudentMemory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStudentMemory"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useToolbarScroll.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useToolbarScroll",
    ()=>useToolbarScroll
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview useToolbarScroll - Shared hook for toolbar horizontal scroll with arrow indicators.
 * @module useToolbarScroll
 *
 * Provides scroll state and handlers for horizontally scrollable toolbars.
 * Arrow visibility matches MUI TabScrollButton behavior for consistency.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useToolbarScroll(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "b6b4fc09cf02b9fb44df720ec153c1f4f8f581bc696b2f62c13e0f9caa6adffc") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b6b4fc09cf02b9fb44df720ec153c1f4f8f581bc696b2f62c13e0f9caa6adffc";
    }
    let t1;
    if ($[1] !== t0) {
        t1 = t0 === undefined ? {} : t0;
        $[1] = t0;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const { scrollAmount: t2 } = t1;
    const scrollAmount = t2 === undefined ? 200 : t2;
    const toolbarRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [showLeftArrow, setShowLeftArrow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showRightArrow, setShowRightArrow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "useToolbarScroll[checkToolbarOverflow]": ()=>{
                if (toolbarRef.current) {
                    const { scrollLeft, scrollWidth, clientWidth } = toolbarRef.current;
                    const hasOverflow = scrollWidth > clientWidth;
                    setShowLeftArrow(hasOverflow && scrollLeft > 5);
                    setShowRightArrow(hasOverflow && scrollLeft + clientWidth < scrollWidth - 5);
                }
            }
        })["useToolbarScroll[checkToolbarOverflow]"];
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const checkToolbarOverflow = t3;
    let t4;
    if ($[4] !== scrollAmount) {
        t4 = ({
            "useToolbarScroll[scrollToolbar]": (direction)=>{
                if (toolbarRef.current) {
                    const targetScroll = direction === "left" ? toolbarRef.current.scrollLeft - scrollAmount : toolbarRef.current.scrollLeft + scrollAmount;
                    toolbarRef.current.scrollTo({
                        left: targetScroll,
                        behavior: "smooth"
                    });
                    setTimeout(checkToolbarOverflow, 350);
                }
            }
        })["useToolbarScroll[scrollToolbar]"];
        $[4] = scrollAmount;
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const scrollToolbar = t4;
    let t5;
    let t6;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "useToolbarScroll[useEffect()]": ()=>{
                const el = toolbarRef.current;
                if (!el) {
                    return;
                }
                const timer = setTimeout(checkToolbarOverflow, 100);
                window.addEventListener("resize", checkToolbarOverflow);
                const observer = new MutationObserver(checkToolbarOverflow);
                observer.observe(el, {
                    childList: true,
                    subtree: true
                });
                return ()=>{
                    clearTimeout(timer);
                    window.removeEventListener("resize", checkToolbarOverflow);
                    observer.disconnect();
                };
            }
        })["useToolbarScroll[useEffect()]"];
        t6 = [
            checkToolbarOverflow
        ];
        $[6] = t5;
        $[7] = t6;
    } else {
        t5 = $[6];
        t6 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7;
    if ($[8] !== scrollToolbar || $[9] !== showLeftArrow || $[10] !== showRightArrow) {
        t7 = {
            toolbarRef,
            showLeftArrow,
            showRightArrow,
            scrollToolbar,
            checkToolbarOverflow
        };
        $[8] = scrollToolbar;
        $[9] = showLeftArrow;
        $[10] = showRightArrow;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    return t7;
}
_s(useToolbarScroll, "PjbvRYSAgjeSs1N1CMXDtgR2UHQ=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useGlobalChatShortcut.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useGlobalChatShortcut",
    ()=>useGlobalChatShortcut
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * useGlobalChatShortcut - Keyboard shortcut to toggle global chat
 * 
 * Listens for Cmd/Ctrl + Shift + C to toggle the global chat drawer.
 * 
 * @example
 * // In _app.jsx
 * function MyApp({ Component, pageProps }) {
 *   useGlobalChatShortcut();
 *   return <Component {...pageProps} />;
 * }
 * 
 * @see docs/GLOBAL_CHAT_INTEGRATION_PLAN.md
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/chatContext.jsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useGlobalChatShortcut(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "d9db01c6d644e0a42b824cd4f67f2b62d573740342c81909458290e529c854a2") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d9db01c6d644e0a42b824cd4f67f2b62d573740342c81909458290e529c854a2";
    }
    const enabled = t0 === undefined ? true : t0;
    const { isChatOpen, setIsChatOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t1;
    if ($[1] !== enabled || $[2] !== setIsChatOpen) {
        t1 = ({
            "useGlobalChatShortcut[useEffect()]": ()=>{
                if (!enabled) {
                    return;
                }
                const handleKeyDown = {
                    "useGlobalChatShortcut[useEffect() > handleKeyDown]": (event)=>{
                        const isMac = navigator.platform.toUpperCase().indexOf("MAC") >= 0;
                        const modifierKey = isMac ? event.metaKey : event.ctrlKey;
                        if (modifierKey && event.shiftKey && event.key === "C") {
                            event.preventDefault();
                            event.stopPropagation();
                            console.log("[useGlobalChatShortcut] Toggling chat via keyboard shortcut");
                            setIsChatOpen(_useGlobalChatShortcutUseEffectHandleKeyDownSetIsChatOpen);
                        }
                    }
                }["useGlobalChatShortcut[useEffect() > handleKeyDown]"];
                window.addEventListener("keydown", handleKeyDown);
                return ()=>{
                    window.removeEventListener("keydown", handleKeyDown);
                };
            }
        })["useGlobalChatShortcut[useEffect()]"];
        $[1] = enabled;
        $[2] = setIsChatOpen;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    let t2;
    if ($[4] !== enabled || $[5] !== isChatOpen || $[6] !== setIsChatOpen) {
        t2 = [
            enabled,
            isChatOpen,
            setIsChatOpen
        ];
        $[4] = enabled;
        $[5] = isChatOpen;
        $[6] = setIsChatOpen;
        $[7] = t2;
    } else {
        t2 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
}
_s(useGlobalChatShortcut, "wweKlhu51I6+G1xaVWkzTXQ5sGo=");
function _useGlobalChatShortcutUseEffectHandleKeyDownSetIsChatOpen(prev) {
    return !prev;
}
const __TURBOPACK__default__export__ = useGlobalChatShortcut;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/usePageViewTracking.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePageViewTracking",
    ()=>usePageViewTracking
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/analytics.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function usePageViewTracking() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "8cd29b39e6f957cb1217214ba8df7101e44f450768d745f8baf8221f15fb8556") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8cd29b39e6f957cb1217214ba8df7101e44f450768d745f8baf8221f15fb8556";
    }
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const previousPathRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t0;
    let t1;
    if ($[1] !== pathname) {
        t0 = ({
            "usePageViewTracking[useEffect()]": ()=>{
                if (!pathname) {
                    return;
                }
                if (pathname === previousPathRef.current) {
                    return;
                }
                previousPathRef.current = pathname;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackPageView"])(pathname);
            }
        })["usePageViewTracking[useEffect()]"];
        t1 = [
            pathname
        ];
        $[1] = pathname;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
}
_s(usePageViewTracking, "ui5asYJA/wt+kZhU/hiv9M4SHoY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/workers/embeddingWorker.js (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/embeddingWorker.0gmxyzlnap1wy.js");}),
"[project]/src/workers/embeddingWorker.js [app-client] (ecmascript, worker loader)", ((__turbopack_context__) => {

__turbopack_context__.v(function(Ctor, opts) {
    return __turbopack_context__.b(Ctor, "static/chunks/turbopack-worker-[client-fs]__next_static_chunks_12ee_mp._.js", ["static/chunks/src_workers_embeddingWorker_044tjm0.js","static/chunks/src_workers_embeddingWorker_0u_uju3.js","static/chunks/turbopack-src_workers_embeddingWorker_0b.aluy.js"], opts);
});
}),
"[project]/src/yjs/YjsProvider.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "YjsDocProvider",
    ()=>YjsDocProvider,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * YjsProvider - Unified Yjs provider with WebSocket + IndexedDB persistence
 *
 * Provides real-time sync across clients with automatic offline persistence
 * and reconnection handling.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/yjs/dist/yjs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$y$2d$websocket$2f$src$2f$y$2d$websocket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/y-websocket/src/y-websocket.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$y$2d$indexeddb$2f$src$2f$y$2d$indexeddb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/y-indexeddb/src/y-indexeddb.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$y$2d$protocols$2f$awareness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/y-protocols/awareness.js [app-client] (ecmascript)");
;
;
;
;
class YjsDocProvider {
    ydoc;
    docName;
    wsProvider = null;
    indexeddb = null;
    awareness;
    config;
    hasLoggedConnectionError = false;
    resetCount = 0;
    static MAX_RESETS = 2;
    listeners = new Map();
    lastStatusLog = "";
    defaultConfig = {
        wsUrl: ("TURBOPACK compile-time truthy", 1) ? ("TURBOPACK compile-time value", "wss://4uzs3gpvla.execute-api.us-east-1.amazonaws.com/live") || `${window.location.protocol === "https:" ? "wss:" : "ws:"}//${window.location.host}` : "TURBOPACK unreachable",
        resyncInterval: 5000,
        maxBackoffTime: 30000,
        connect: ("TURBOPACK compile-time truthy", 1) ? !!("TURBOPACK compile-time value", "wss://4uzs3gpvla.execute-api.us-east-1.amazonaws.com/live") : "TURBOPACK unreachable",
        persistence: true
    };
    constructor(config){
        this.docName = config.docName;
        this.ydoc = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Doc"]();
        // Filter out undefined values so they don't override defaults
        const definedConfig = Object.fromEntries(Object.entries(config).filter(([, v])=>v !== undefined));
        this.config = {
            ...this.defaultConfig,
            ...definedConfig
        };
        // Create standalone awareness (always available, even without WebSocket)
        this.awareness = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$y$2d$protocols$2f$awareness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Awareness"](this.ydoc);
        // Set up IndexedDB persistence (only in browser environments)
        if (this.config.persistence && typeof indexedDB !== "undefined") {
            this.indexeddb = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$y$2d$indexeddb$2f$src$2f$y$2d$indexeddb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndexeddbPersistence"](this.docName, this.ydoc);
        }
        // Set up WebSocket sync (if connect=true)
        if (this.config.connect) {
            this.setupWebSocket();
        }
    }
    setupWebSocket() {
        try {
            this.wsProvider = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$y$2d$websocket$2f$src$2f$y$2d$websocket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WebsocketProvider"](this.config.wsUrl, this.docName, this.ydoc, {
                resyncInterval: this.config.resyncInterval,
                maxBackoffTime: this.config.maxBackoffTime,
                awareness: this.awareness
            });
            // Handle sync status
            this.wsProvider.on("sync", (isSynced)=>{
                if (isSynced) {
                    console.log(`[YjsProvider] ${this.docName} synced with server`);
                }
            });
            // Handle connection status - only log changes to reduce noise
            this.wsProvider.on("status", ({ status })=>{
                if (status !== this.lastStatusLog) {
                    this.lastStatusLog = status;
                    console.log(`[YjsProvider] ${this.docName} connection status: ${status}`);
                }
            });
            // Handle errors - log first occurrence, then debug to reduce spam
            this.wsProvider.on("connection-error", (error)=>{
                if (!this.hasLoggedConnectionError) {
                    this.hasLoggedConnectionError = true;
                    console.warn(`[YjsProvider] ${this.docName} connection error (further retries logged as debug):`, error);
                } else {
                    console.debug(`[YjsProvider] ${this.docName} connection retry failed`);
                }
            });
            // Handle server-initiated close with code 4000 (corrupt state reset)
            // Clear local IndexedDB to prevent replaying corrupt data on reconnect.
            // Limit resets to prevent infinite loops.
            this.wsProvider.on("connection-close", (event)=>{
                if (event?.code === 4000) {
                    this.resetCount++;
                    if (this.resetCount > YjsDocProvider.MAX_RESETS) {
                        console.warn(`[YjsProvider] ${this.docName} exceeded max resets (${YjsDocProvider.MAX_RESETS}) — staying disconnected`);
                        if (this.wsProvider) {
                            this.wsProvider.destroy();
                            this.wsProvider = null;
                        }
                        return;
                    }
                    console.warn(`[YjsProvider] ${this.docName} server rejected corrupt data — clearing local cache (reset ${this.resetCount}/${YjsDocProvider.MAX_RESETS})`);
                    // 1. Stop auto-reconnect and destroy current provider
                    if (this.wsProvider) {
                        this.wsProvider.destroy();
                        this.wsProvider = null;
                    }
                    // 2. Clear corrupt IndexedDB data
                    this.clearLocalPersistence();
                    // 3. Reset the local Y.Doc and awareness to empty state
                    this.awareness.destroy();
                    this.ydoc.destroy();
                    this.ydoc = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Doc"]();
                    this.awareness = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$y$2d$protocols$2f$awareness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Awareness"](this.ydoc);
                    // 4. Notify consumers that doc was replaced
                    this.emit("doc-reset", this.ydoc);
                    // 5. Reconnect with fresh state after a short delay
                    this.hasLoggedConnectionError = false;
                    setTimeout(()=>this.setupWebSocket(), 1000);
                }
            });
        } catch (error) {
            console.error(`[YjsProvider] Failed to setup WebSocket for ${this.docName}:`, error);
        }
    }
    /**
   * Get the underlying Y.Doc
   */ getDoc() {
        return this.ydoc;
    }
    /**
   * Get a Y.Map from the document
   */ getMap(name) {
        return this.ydoc.getMap(name);
    }
    /**
   * Get a Y.Array from the document
   */ getArray(name) {
        return this.ydoc.getArray(name);
    }
    /**
   * Get a Y.Text from the document
   */ getText(name) {
        return this.ydoc.getText(name);
    }
    /**
   * Get awareness for presence tracking
   */ getAwareness() {
        return this.awareness;
    }
    /**
   * Set local awareness state (user presence, cursor position, etc.)
   */ setAwareness(state) {
        this.awareness.setLocalState(state);
    }
    /**
   * Get awareness state for a specific client
   */ getClientState(clientId) {
        return this.awareness.getStates().get(clientId) || null;
    }
    /**
   * Get all connected clients
   */ getConnectedClients() {
        return Array.from(this.awareness.getStates().keys());
    }
    /**
   * Check if synced with server
   */ isSynced() {
        if (!this.wsProvider) {
            return false;
        }
        return this.wsProvider.synced;
    }
    /**
   * Manually trigger reconnection
   */ reconnect() {
        if (this.wsProvider) {
            this.wsProvider.connect();
        }
    }
    /**
   * Disconnect from WebSocket
   */ disconnect() {
        if (this.wsProvider) {
            this.wsProvider.disconnect();
        }
    }
    /**
   * Get the encoded state (snapshot) for persistence
   */ getState() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeStateAsUpdate"](this.ydoc);
    }
    /**
   * Get state vector for diff updates
   */ getStateVector() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeStateVector"](this.ydoc);
    }
    /**
   * Apply an update from another client.
   * Guarded against corrupt data — returns false if the update failed to apply.
   */ applyUpdate(update) {
        try {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyUpdate"](this.ydoc, update);
            return true;
        } catch (err) {
            console.warn(`[YjsProvider] ${this.docName} failed to apply update (corrupt data):`, err.message);
            return false;
        }
    }
    /**
   * Subscribe to awareness changes
   */ onAwarenessChange(callback) {
        this.awareness.on("change", callback);
        return ()=>{
            this.awareness.off("change", callback);
        };
    }
    /**
   * Subscribe to update events
   */ onUpdate(callback) {
        const updateHandler = (update, origin)=>{
            callback(update, origin);
        };
        this.ydoc.on("update", updateHandler);
        return ()=>{
            this.ydoc.off("update", updateHandler);
        };
    }
    /**
   * Clear all data locally
   */ clear() {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transact"](this.ydoc, ()=>{
            // Remove all maps and arrays
            this.ydoc.share.forEach((value)=>{
                if (value instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Map"]) {
                    Array.from(value.keys()).forEach((k)=>value.delete(k));
                } else if (value instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$yjs$2f$dist$2f$yjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Array"]) {
                    value.delete(0, value.length);
                }
            });
        });
    }
    /**
   * Clear local IndexedDB persistence for this document.
   * Used to recover from corrupt state without replaying bad data on reconnect.
   */ clearLocalPersistence() {
        if (this.indexeddb) {
            this.indexeddb.clearData();
            console.log(`[YjsProvider] Cleared IndexedDB persistence for "${this.docName}"`);
        }
    }
    /**
   * Subscribe to provider events (e.g., 'doc-reset' when Y.Doc is replaced)
   */ on(event, callback) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, new Set());
        }
        this.listeners.get(event).add(callback);
    }
    /**
   * Unsubscribe from provider events
   */ off(event, callback) {
        this.listeners.get(event)?.delete(callback);
    }
    emit(event, ...args) {
        this.listeners.get(event)?.forEach((cb)=>{
            try {
                cb(...args);
            } catch (e) {
                console.warn(`[YjsProvider] Error in ${event} listener:`, e);
            }
        });
    }
    /**
   * Destroy provider and clean up resources
   */ destroy() {
        if (this.wsProvider) {
            this.wsProvider.destroy();
        }
        if (this.indexeddb) {
            this.indexeddb.destroy();
        }
        this.awareness.destroy();
        this.ydoc.destroy();
        this.listeners.clear();
    }
}
const __TURBOPACK__default__export__ = YjsDocProvider;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/yjs/WorkbookCollaborationProvider.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * WorkbookCollaborationProvider - Specialized YJS provider for collaborative student workbooks
 *
 * Enables real-time collaboration between students and tutors on workbook assignments.
 * Uses per-student Grade ID as the room identifier, ensuring each student has their
 * own collaborative space that tutors can join.
 *
 * @module WorkbookCollaborationProvider
 */ __turbopack_context__.s([
    "WorkbookCollaborationProvider",
    ()=>WorkbookCollaborationProvider,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/YjsProvider.ts [app-client] (ecmascript)");
;
class WorkbookCollaborationProvider extends __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YjsDocProvider"] {
    gradeId;
    user;
    workbookConfig;
    syncTimer = null;
    cursorDebounceTimer = null;
    activeTutors = new Map();
    // Y.js structures for workbook data
    workbookMap;
    metadataMap;
    feedbackMap;
    commentsMap;
    constructor(config){
        // Create the document name from the grade ID
        const docName = `workbook-${config.gradeId}`;
        super({
            ...config,
            docName
        });
        this.gradeId = config.gradeId;
        this.user = config.user;
        this.workbookConfig = {
            autoSyncToGrade: true,
            syncInterval: 3000,
            ...config
        };
        // Initialize Y.js data structures
        this.workbookMap = this.getMap("workbookData");
        this.metadataMap = this.getMap("metadata");
        this.feedbackMap = this.getMap("feedback");
        this.commentsMap = this.getMap("comments");
        // Set up awareness with user info
        this.initializeAwareness();
        // Listen for awareness changes (tutors joining/leaving)
        this.setupAwarenessHandlers();
        // Set up auto-sync to Grade.data if enabled
        if (this.workbookConfig.autoSyncToGrade) {
            this.setupAutoSync();
        }
    }
    /**
   * Initialize awareness with current user information
   */ initializeAwareness() {
        const awareness = this.getAwareness();
        awareness.setLocalState({
            user: this.user,
            timestamp: Date.now(),
            lastInteraction: Date.now(),
            gradeId: this.gradeId
        });
    }
    /**
   * Set up handlers for awareness changes (users joining/leaving)
   */ setupAwarenessHandlers() {
        const awareness = this.getAwareness();
        awareness.on("change", ({ added, removed })=>{
            // Handle users joining
            added.forEach((clientId)=>{
                if (clientId === awareness.clientID) return; // Skip self
                const state = this.getClientState(clientId);
                if (state?.user) {
                    const user = state.user;
                    // Track if it's a tutor/instructor
                    if (user.role === "tutor" || user.role === "instructor" || user.role === "admin") {
                        this.activeTutors.set(clientId, user);
                        this.workbookConfig.onTutorJoin?.(user);
                    }
                }
            });
            // Handle users leaving
            removed.forEach((clientId)=>{
                const tutor = this.activeTutors.get(clientId);
                if (tutor) {
                    this.activeTutors.delete(clientId);
                    this.workbookConfig.onTutorLeave?.(tutor);
                }
                // Check if student disconnected
                const state = this.getClientState(clientId);
                if (state?.user?.role === "student") {
                    this.workbookConfig.onStudentDisconnect?.();
                }
            });
        });
    }
    /**
   * Set up automatic syncing to Grade.data field
   */ setupAutoSync() {
        const ydoc = this.getDoc();
        ydoc.on("update", ()=>{
            // Debounce the sync
            if (this.syncTimer) {
                clearTimeout(this.syncTimer);
            }
            this.syncTimer = setTimeout(()=>{
                this.triggerGradeSync();
            }, this.workbookConfig.syncInterval);
        });
    }
    /**
   * Trigger sync to Grade.data field
   * This would be implemented by the consuming code using DataStore
   */ triggerGradeSync() {
        // Emit event that can be caught by consuming code
        if ("TURBOPACK compile-time truthy", 1) {
            const event = new CustomEvent("workbook-sync", {
                detail: {
                    gradeId: this.gradeId,
                    data: this.getWorkbookData(),
                    feedback: this.getFeedback(),
                    metadata: this.getMetadata()
                }
            });
            window.dispatchEvent(event);
        }
    }
    /**
   * Get all workbook block data
   */ getWorkbookData() {
        const data = {};
        this.workbookMap.forEach((value, key)=>{
            data[key] = value;
        });
        return data;
    }
    /**
   * Update a single block's data
   */ updateBlock(blockId, data) {
        const currentData = this.workbookMap.get(blockId) || {};
        const updatedData = {
            ...currentData,
            ...data,
            timestamp: new Date().toISOString()
        };
        this.workbookMap.set(blockId, updatedData);
        // Record history for each changed field
        for (const key of Object.keys(data)){
            if (key === "timestamp") continue;
            const oldVal = currentData[key];
            const newVal = data[key];
            if (oldVal !== newVal) {
                this.recordHistory(blockId, key, oldVal, newVal);
            }
        }
        this.touchLastInteraction();
    }
    /**
   * Get data for a specific block
   */ getBlock(blockId) {
        return this.workbookMap.get(blockId);
    }
    /**
   * Delete a block's data
   */ deleteBlock(blockId) {
        this.workbookMap.delete(blockId);
    }
    /**
   * Get all feedback data
   */ getFeedback() {
        const feedback = {};
        this.feedbackMap.forEach((value, key)=>{
            feedback[key] = value;
        });
        return feedback;
    }
    /**
   * Add or update feedback for a block
   */ setFeedback(blockId, feedback) {
        this.feedbackMap.set(blockId, {
            ...feedback,
            timestamp: new Date().toISOString(),
            author: this.user.username,
            authorRole: this.user.role
        });
    }
    /**
   * Get workbook metadata
   */ getMetadata() {
        const metadata = {};
        this.metadataMap.forEach((value, key)=>{
            metadata[key] = value;
        });
        return metadata;
    }
    /**
   * Update workbook metadata
   */ updateMetadata(key, value) {
        this.metadataMap.set(key, value);
    }
    /**
   * Get list of currently active tutors
   */ getActiveTutors() {
        return Array.from(this.activeTutors.values());
    }
    /**
   * Get all connected users (students + tutors)
   */ getConnectedUsers() {
        const users = [];
        const awareness = this.getAwareness();
        awareness.getStates().forEach((state)=>{
            if (state.user) {
                users.push(state.user);
            }
        });
        return users;
    }
    /**
   * Check if a tutor is currently helping
   */ hasTutorPresent() {
        return this.activeTutors.size > 0;
    }
    /**
   * Update current user's cursor position
   */ updateCursor(blockId, position) {
        // Debounce cursor updates by 300ms
        if (this.cursorDebounceTimer) {
            clearTimeout(this.cursorDebounceTimer);
        }
        this.cursorDebounceTimer = setTimeout(()=>{
            const awareness = this.getAwareness();
            const currentState = awareness.getLocalState();
            awareness.setLocalState({
                ...currentState,
                user: {
                    ...this.user,
                    cursor: {
                        blockId,
                        position
                    }
                },
                lastInteraction: Date.now()
            });
        }, 300);
    }
    /**
   * Update the lastInteraction timestamp in awareness state.
   * Called on user actions like block updates.
   */ touchLastInteraction() {
        const awareness = this.getAwareness();
        const currentState = awareness.getLocalState();
        if (currentState) {
            awareness.setLocalState({
                ...currentState,
                lastInteraction: Date.now()
            });
        }
    }
    /**
   * Load initial data from Grade.data JSON
   */ loadFromGradeData(gradeDataJson) {
        if (!gradeDataJson) return;
        try {
            const gradeData = typeof gradeDataJson === "string" ? JSON.parse(gradeDataJson) : gradeDataJson;
            // Populate workbook map with grade data
            Object.entries(gradeData).forEach(([blockId, blockData])=>{
                this.workbookMap.set(blockId, blockData);
            });
            console.log(`[WorkbookCollaboration] Loaded ${Object.keys(gradeData).length} blocks from Grade.data`);
        } catch (error) {
            console.error("[WorkbookCollaboration] Error loading Grade.data:", error);
        }
    }
    /**
   * Export workbook data as JSON for saving to Grade.data
   */ exportToGradeData() {
        const data = this.getWorkbookData();
        return JSON.stringify(data);
    }
    /**
   * Calculate completion percentage
   */ getCompletionPercentage() {
        const blocks = this.getWorkbookData();
        const blockIds = Object.keys(blocks);
        if (blockIds.length === 0) return 0;
        const completedBlocks = blockIds.filter((id)=>blocks[id].complete === true).length;
        return Math.round(completedBlocks / blockIds.length * 100);
    }
    /**
   * Calculate overall accuracy
   */ getOverallAccuracy() {
        const blocks = this.getWorkbookData();
        const blockIds = Object.keys(blocks);
        if (blockIds.length === 0) return 0;
        const accuracies = blockIds.map((id)=>blocks[id].accuracy).filter((acc)=>typeof acc === "number");
        if (accuracies.length === 0) return 0;
        const sum = accuracies.reduce((acc, val)=>acc + val, 0);
        return Math.round(sum / accuracies.length);
    }
    /**
   * Check if user has permission to edit
   */ canEdit() {
        // Students can always edit their own workbook
        if (this.user.role === "student") return true;
        // Tutors, instructors, and admins can edit as well
        if ([
            "tutor",
            "instructor",
            "admin"
        ].includes(this.user.role)) return true;
        return false;
    }
    /**
   * Check if user can provide feedback
   */ canProvideFeedback() {
        return [
            "tutor",
            "instructor",
            "admin"
        ].includes(this.user.role);
    }
    /**
   * Clean up and destroy provider
   */ destroy() {
        if (this.syncTimer) {
            clearTimeout(this.syncTimer);
        }
        if (this.cursorDebounceTimer) {
            clearTimeout(this.cursorDebounceTimer);
        }
        this.activeTutors.clear();
        super.destroy();
    }
    // ========================================================================
    // Comments
    // ========================================================================
    /**
   * Add a new comment thread to a block.
   */ addComment(blockId, text) {
        const thread = {
            id: crypto.randomUUID(),
            blockId,
            author: this.user.username,
            authorRole: this.user.role,
            displayName: this.user.displayName,
            text,
            replies: [],
            resolved: false,
            createdAt: new Date().toISOString()
        };
        this.commentsMap.set(`${blockId}-${thread.id}`, thread);
        this.touchLastInteraction();
        return thread;
    }
    /**
   * Reply to an existing comment thread.
   */ replyToComment(threadKey, text) {
        const thread = this.commentsMap.get(threadKey);
        if (!thread) return;
        const reply = {
            id: crypto.randomUUID(),
            author: this.user.username,
            authorRole: this.user.role,
            displayName: this.user.displayName,
            text,
            createdAt: new Date().toISOString()
        };
        this.commentsMap.set(threadKey, {
            ...thread,
            replies: [
                ...thread.replies,
                reply
            ]
        });
        this.touchLastInteraction();
    }
    /**
   * Resolve or unresolve a comment thread.
   */ resolveThread(threadKey, resolved = true) {
        const thread = this.commentsMap.get(threadKey);
        if (!thread) return;
        this.commentsMap.set(threadKey, {
            ...thread,
            resolved
        });
    }
    /**
   * Get all comment threads, optionally filtered by blockId.
   */ getComments(blockId) {
        const threads = [];
        this.commentsMap.forEach((thread)=>{
            if (!blockId || thread.blockId === blockId) {
                threads.push(thread);
            }
        });
        return threads;
    }
    /**
   * Get the comments Y.Map for observation in hooks.
   */ getCommentsMap() {
        return this.commentsMap;
    }
    // ========================================================================
    // Block-Level Change History
    // ========================================================================
    static MAX_HISTORY_ENTRIES = 50;
    /**
   * Record a history entry for a block change.
   * Call this when a block is updated with field-level changes.
   */ recordHistory(blockId, fieldChanged, oldValue, newValue) {
        const historyArrayName = `history-${blockId}`;
        const historyArray = this.getDoc().getArray(historyArrayName);
        const entry = {
            userId: this.user.username,
            displayName: this.user.displayName || this.user.username,
            timestamp: new Date().toISOString(),
            fieldChanged,
            oldValue,
            newValue
        };
        historyArray.push([
            entry
        ]);
        // Trim to last N entries
        if (historyArray.length > WorkbookCollaborationProvider.MAX_HISTORY_ENTRIES) {
            const excess = historyArray.length - WorkbookCollaborationProvider.MAX_HISTORY_ENTRIES;
            historyArray.delete(0, excess);
        }
    }
    /**
   * Get history entries for a block.
   */ getBlockHistory(blockId) {
        const historyArray = this.getDoc().getArray(`history-${blockId}`);
        return Array.from(historyArray);
    }
}
const __TURBOPACK__default__export__ = WorkbookCollaborationProvider;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/yjs/workbookHooks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useBlockEditors",
    ()=>useBlockEditors,
    "useBlockHistory",
    ()=>useBlockHistory,
    "usePresenceUsers",
    ()=>usePresenceUsers,
    "useTutorPresence",
    ()=>useTutorPresence,
    "useWorkbookBlock",
    ()=>useWorkbookBlock,
    "useWorkbookCollaboration",
    ()=>useWorkbookCollaboration,
    "useWorkbookComments",
    ()=>useWorkbookComments,
    "useWorkbookFeedback",
    ()=>useWorkbookFeedback,
    "useWorkbookStats",
    ()=>useWorkbookStats
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * React hooks for collaborative workbook editing
 * 
 * Provides hooks for managing workbook collaboration between students and tutors
 * using YJS for real-time synchronization.
 * 
 * @module workbookHooks
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$WorkbookCollaborationProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/WorkbookCollaborationProvider.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature();
;
;
;
function useWorkbookCollaboration(options) {
    _s();
    const { gradeId, user, initialData, onTutorJoin, onTutorLeave, onSyncToGrade, autoSyncToGrade = true, syncInterval = 3000, wsUrl } = options || {};
    const providerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [workbookData, setWorkbookData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [activeTutors, setActiveTutors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [connectedUsers, setConnectedUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isSynced, setIsSynced] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isConnected, setIsConnected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Initialize provider
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWorkbookCollaboration.useEffect": ()=>{
            if (!options || !gradeId || !user) return;
            console.log(`[useWorkbookCollaboration] Initializing for grade ${gradeId}`);
            const provider = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$WorkbookCollaborationProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WorkbookCollaborationProvider"]({
                gradeId,
                user,
                wsUrl,
                autoSyncToGrade,
                syncInterval,
                onTutorJoin: {
                    "useWorkbookCollaboration.useEffect": (tutor)=>{
                        setActiveTutors(provider.getActiveTutors());
                        onTutorJoin?.(tutor);
                    }
                }["useWorkbookCollaboration.useEffect"],
                onTutorLeave: {
                    "useWorkbookCollaboration.useEffect": (tutor_0)=>{
                        setActiveTutors(provider.getActiveTutors());
                        onTutorLeave?.(tutor_0);
                    }
                }["useWorkbookCollaboration.useEffect"]
            });
            providerRef.current = provider;
            // Load initial data from Grade.data if provided
            if (initialData) {
                provider.loadFromGradeData(initialData);
            }
            // Set initial workbook data
            setWorkbookData(provider.getWorkbookData());
            // Subscribe to workbook data changes
            const unsubscribe = provider.onUpdate({
                "useWorkbookCollaboration.useEffect.unsubscribe": ()=>{
                    setWorkbookData(provider.getWorkbookData());
                    setConnectedUsers(provider.getConnectedUsers());
                }
            }["useWorkbookCollaboration.useEffect.unsubscribe"]);
            // Subscribe to awareness changes
            const unsubscribeAwareness = provider.onAwarenessChange({
                "useWorkbookCollaboration.useEffect.unsubscribeAwareness": ()=>{
                    setActiveTutors(provider.getActiveTutors());
                    setConnectedUsers(provider.getConnectedUsers());
                }
            }["useWorkbookCollaboration.useEffect.unsubscribeAwareness"]);
            // Listen for sync events
            const handleWorkbookSync = {
                "useWorkbookCollaboration.useEffect.handleWorkbookSync": (event)=>{
                    if (event.detail.gradeId === gradeId) {
                        onSyncToGrade?.(event.detail.data, event.detail.feedback);
                    }
                }
            }["useWorkbookCollaboration.useEffect.handleWorkbookSync"];
            if ("TURBOPACK compile-time truthy", 1) {
                window.addEventListener('workbook-sync', handleWorkbookSync);
            }
            // Monitor connection status
            const wsProvider = provider.wsProvider;
            if (wsProvider) {
                wsProvider.on('sync', {
                    "useWorkbookCollaboration.useEffect": (synced)=>{
                        setIsSynced(synced);
                    }
                }["useWorkbookCollaboration.useEffect"]);
                wsProvider.on('status', {
                    "useWorkbookCollaboration.useEffect": ({ status })=>{
                        setIsConnected(status === 'connected');
                    }
                }["useWorkbookCollaboration.useEffect"]);
            }
            return ({
                "useWorkbookCollaboration.useEffect": ()=>{
                    unsubscribe();
                    unsubscribeAwareness();
                    if ("TURBOPACK compile-time truthy", 1) {
                        window.removeEventListener('workbook-sync', handleWorkbookSync);
                    }
                // Don't destroy provider on unmount - keeps connection alive
                }
            })["useWorkbookCollaboration.useEffect"];
        }
    }["useWorkbookCollaboration.useEffect"], [
        gradeId,
        user?.username
    ]); // Only reinitialize if gradeId or user changes
    const updateBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useWorkbookCollaboration.useCallback[updateBlock]": (blockId, data)=>{
            if (!providerRef.current) return;
            providerRef.current.updateBlock(blockId, data);
        }
    }["useWorkbookCollaboration.useCallback[updateBlock]"], []);
    const getBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useWorkbookCollaboration.useCallback[getBlock]": (blockId_0)=>{
            if (!providerRef.current) return undefined;
            return providerRef.current.getBlock(blockId_0);
        }
    }["useWorkbookCollaboration.useCallback[getBlock]"], []);
    const deleteBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useWorkbookCollaboration.useCallback[deleteBlock]": (blockId_1)=>{
            if (!providerRef.current) return;
            providerRef.current.deleteBlock(blockId_1);
        }
    }["useWorkbookCollaboration.useCallback[deleteBlock]"], []);
    const setFeedback = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useWorkbookCollaboration.useCallback[setFeedback]": (blockId_2, feedback)=>{
            if (!providerRef.current) return;
            providerRef.current.setFeedback(blockId_2, feedback);
        }
    }["useWorkbookCollaboration.useCallback[setFeedback]"], []);
    const updateCursor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useWorkbookCollaboration.useCallback[updateCursor]": (blockId_3, position)=>{
            if (!providerRef.current) return;
            providerRef.current.updateCursor(blockId_3, position);
        }
    }["useWorkbookCollaboration.useCallback[updateCursor]"], []);
    const exportToGradeData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useWorkbookCollaboration.useCallback[exportToGradeData]": ()=>{
            if (!providerRef.current) return '{}';
            return providerRef.current.exportToGradeData();
        }
    }["useWorkbookCollaboration.useCallback[exportToGradeData]"], []);
    const getCompletionPercentage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useWorkbookCollaboration.useCallback[getCompletionPercentage]": ()=>{
            if (!providerRef.current) return 0;
            return providerRef.current.getCompletionPercentage();
        }
    }["useWorkbookCollaboration.useCallback[getCompletionPercentage]"], []);
    const getOverallAccuracy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useWorkbookCollaboration.useCallback[getOverallAccuracy]": ()=>{
            if (!providerRef.current) return 0;
            return providerRef.current.getOverallAccuracy();
        }
    }["useWorkbookCollaboration.useCallback[getOverallAccuracy]"], []);
    return {
        provider: providerRef.current,
        workbookData,
        activeTutors,
        connectedUsers,
        isSynced,
        isConnected,
        hasTutorPresent: activeTutors.length > 0,
        updateBlock,
        getBlock,
        deleteBlock,
        setFeedback,
        updateCursor,
        exportToGradeData,
        getCompletionPercentage,
        getOverallAccuracy
    };
}
_s(useWorkbookCollaboration, "d88GOvt/anbyBMSCPyli0Zjfqw4=");
function useWorkbookBlock(provider, blockId) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf";
    }
    const [blockData, setBlockData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    let t0;
    let t1;
    if ($[1] !== blockId || $[2] !== provider) {
        t0 = ({
            "useWorkbookBlock[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                setBlockData(provider.getBlock(blockId));
                const unsubscribe = provider.onUpdate({
                    "useWorkbookBlock[useEffect() > provider.onUpdate()]": ()=>{
                        setBlockData(provider.getBlock(blockId));
                    }
                }["useWorkbookBlock[useEffect() > provider.onUpdate()]"]);
                return ()=>{
                    unsubscribe();
                };
            }
        })["useWorkbookBlock[useEffect()]"];
        t1 = [
            provider,
            blockId
        ];
        $[1] = blockId;
        $[2] = provider;
        $[3] = t0;
        $[4] = t1;
    } else {
        t0 = $[3];
        t1 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    let t2;
    if ($[5] !== blockId || $[6] !== provider) {
        t2 = ({
            "useWorkbookBlock[updateData]": (data)=>{
                if (!provider) {
                    return;
                }
                provider.updateBlock(blockId, data);
            }
        })["useWorkbookBlock[updateData]"];
        $[5] = blockId;
        $[6] = provider;
        $[7] = t2;
    } else {
        t2 = $[7];
    }
    const updateData = t2;
    let t3;
    if ($[8] !== blockId || $[9] !== provider) {
        t3 = ({
            "useWorkbookBlock[deleteData]": ()=>{
                if (!provider) {
                    return;
                }
                provider.deleteBlock(blockId);
            }
        })["useWorkbookBlock[deleteData]"];
        $[8] = blockId;
        $[9] = provider;
        $[10] = t3;
    } else {
        t3 = $[10];
    }
    const deleteData = t3;
    const t4 = blockData?.complete === true;
    const t5 = blockData?.accuracy;
    let t6;
    if ($[11] !== blockData || $[12] !== deleteData || $[13] !== t4 || $[14] !== t5 || $[15] !== updateData) {
        t6 = {
            blockData,
            updateData,
            deleteData,
            isComplete: t4,
            accuracy: t5
        };
        $[11] = blockData;
        $[12] = deleteData;
        $[13] = t4;
        $[14] = t5;
        $[15] = updateData;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    return t6;
}
_s1(useWorkbookBlock, "lLdlnkgADUohMekaskfiKWzj6u0=");
function useTutorPresence(provider, blockId) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [tutorsOnBlock, setTutorsOnBlock] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== blockId || $[3] !== provider) {
        t1 = ({
            "useTutorPresence[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const updateTutorPresence = {
                    "useTutorPresence[useEffect() > updateTutorPresence]": ()=>{
                        const awareness = provider.getAwareness();
                        const tutors = [];
                        awareness.getStates().forEach({
                            "useTutorPresence[useEffect() > updateTutorPresence > (anonymous)()]": (state, clientId)=>{
                                if (clientId === awareness.clientID) {
                                    return;
                                }
                                const user = state.user;
                                if (!user) {
                                    return;
                                }
                                if (![
                                    "tutor",
                                    "instructor",
                                    "admin"
                                ].includes(user.role)) {
                                    return;
                                }
                                if (blockId && user.cursor?.blockId !== blockId) {
                                    return;
                                }
                                tutors.push({
                                    ...user,
                                    clientId
                                });
                            }
                        }["useTutorPresence[useEffect() > updateTutorPresence > (anonymous)()]"]);
                        setTutorsOnBlock(tutors);
                    }
                }["useTutorPresence[useEffect() > updateTutorPresence]"];
                const unsubscribe = provider.onAwarenessChange(updateTutorPresence);
                updateTutorPresence();
                return ()=>{
                    unsubscribe();
                };
            }
        })["useTutorPresence[useEffect()]"];
        t2 = [
            provider,
            blockId
        ];
        $[2] = blockId;
        $[3] = provider;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return tutorsOnBlock;
}
_s2(useTutorPresence, "2myDo+e8ABQPt3EPeXqGhF55SLo=");
function useWorkbookFeedback(provider, onNewFeedback) {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {};
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [allFeedback, setAllFeedback] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== onNewFeedback || $[3] !== provider) {
        t1 = ({
            "useWorkbookFeedback[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const feedbackMap = provider.feedbackMap;
                if (!feedbackMap) {
                    return;
                }
                setAllFeedback(provider.getFeedback());
                let previousFeedback = new Set(Object.keys(provider.getFeedback()));
                const handleUpdate = {
                    "useWorkbookFeedback[useEffect() > handleUpdate]": ()=>{
                        const currentFeedback = provider.getFeedback();
                        setAllFeedback(currentFeedback);
                        const currentKeys = new Set(Object.keys(currentFeedback));
                        currentKeys.forEach({
                            "useWorkbookFeedback[useEffect() > handleUpdate > currentKeys.forEach()]": (blockId)=>{
                                if (!previousFeedback.has(blockId)) {
                                    onNewFeedback?.(blockId, currentFeedback[blockId]);
                                }
                            }
                        }["useWorkbookFeedback[useEffect() > handleUpdate > currentKeys.forEach()]"]);
                        previousFeedback = currentKeys;
                    }
                }["useWorkbookFeedback[useEffect() > handleUpdate]"];
                feedbackMap.observe(handleUpdate);
                return ()=>{
                    feedbackMap.unobserve(handleUpdate);
                };
            }
        })["useWorkbookFeedback[useEffect()]"];
        t2 = [
            provider,
            onNewFeedback
        ];
        $[2] = onNewFeedback;
        $[3] = provider;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return allFeedback;
}
_s3(useWorkbookFeedback, "sytDv8tWvXIUw4vm2FWA/aYUhK4=");
function useWorkbookStats(provider) {
    _s4();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            completion: 0,
            accuracy: 0,
            totalBlocks: 0,
            completedBlocks: 0,
            averageAttempts: 0
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [stats, setStats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== provider) {
        t1 = ({
            "useWorkbookStats[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const updateStats = {
                    "useWorkbookStats[useEffect() > updateStats]": ()=>{
                        const data = provider.getWorkbookData();
                        const blockIds = Object.keys(data);
                        const completedBlocks = blockIds.filter({
                            "useWorkbookStats[useEffect() > updateStats > blockIds.filter()]": (id)=>data[id].complete === true
                        }["useWorkbookStats[useEffect() > updateStats > blockIds.filter()]"]);
                        const attempts = blockIds.map({
                            "useWorkbookStats[useEffect() > updateStats > blockIds.map()]": (id_0)=>data[id_0].attempts || 0
                        }["useWorkbookStats[useEffect() > updateStats > blockIds.map()]"]).filter(_useWorkbookStatsUseEffectUpdateStatsAnonymous);
                        const avgAttempts = attempts.length > 0 ? Math.round(attempts.reduce(_useWorkbookStatsUseEffectUpdateStatsAttemptsReduce, 0) / attempts.length) : 0;
                        setStats({
                            completion: provider.getCompletionPercentage(),
                            accuracy: provider.getOverallAccuracy(),
                            totalBlocks: blockIds.length,
                            completedBlocks: completedBlocks.length,
                            averageAttempts: avgAttempts
                        });
                    }
                }["useWorkbookStats[useEffect() > updateStats]"];
                const unsubscribe = provider.onUpdate(updateStats);
                updateStats();
                return ()=>{
                    unsubscribe();
                };
            }
        })["useWorkbookStats[useEffect()]"];
        t2 = [
            provider
        ];
        $[2] = provider;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return stats;
}
_s4(useWorkbookStats, "4tpvAwWDAEZQM/ffiHlnO5uFZE4=");
// ============================================================================
// Presence Hooks
// ============================================================================
function _useWorkbookStatsUseEffectUpdateStatsAttemptsReduce(sum, a_0) {
    return sum + a_0;
}
function _useWorkbookStatsUseEffectUpdateStatsAnonymous(a) {
    return a > 0;
}
const IDLE_TIMEOUT_MS = 60000; // 60 seconds
function useBlockEditors(provider, blockId) {
    _s5();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [editors, setEditors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== blockId || $[3] !== provider) {
        t1 = ({
            "useBlockEditors[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const updateEditors = {
                    "useBlockEditors[useEffect() > updateEditors]": ()=>{
                        const awareness = provider.getAwareness();
                        const now = Date.now();
                        const result = [];
                        awareness.getStates().forEach({
                            "useBlockEditors[useEffect() > updateEditors > (anonymous)()]": (state, clientId)=>{
                                if (clientId === awareness.clientID) {
                                    return;
                                }
                                const user = state.user;
                                if (!user) {
                                    return;
                                }
                                if (user.cursor?.blockId !== blockId) {
                                    return;
                                }
                                const lastInteraction = state.lastInteraction;
                                const isIdle = lastInteraction != null ? now - lastInteraction > IDLE_TIMEOUT_MS : false;
                                result.push({
                                    ...user,
                                    clientId,
                                    lastInteraction,
                                    isIdle
                                });
                            }
                        }["useBlockEditors[useEffect() > updateEditors > (anonymous)()]"]);
                        setEditors(result);
                    }
                }["useBlockEditors[useEffect() > updateEditors]"];
                const unsubscribe = provider.onAwarenessChange(updateEditors);
                updateEditors();
                return ()=>{
                    unsubscribe();
                };
            }
        })["useBlockEditors[useEffect()]"];
        t2 = [
            provider,
            blockId
        ];
        $[2] = blockId;
        $[3] = provider;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return editors;
}
_s5(useBlockEditors, "znUGZPrpboXo6rYG/GfslmU0OM8=");
function usePresenceUsers(provider) {
    _s6();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [users, setUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== provider) {
        t1 = ({
            "usePresenceUsers[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const updateUsers = {
                    "usePresenceUsers[useEffect() > updateUsers]": ()=>{
                        const awareness = provider.getAwareness();
                        const now = Date.now();
                        const result = [];
                        awareness.getStates().forEach({
                            "usePresenceUsers[useEffect() > updateUsers > (anonymous)()]": (state, clientId)=>{
                                const user = state.user;
                                if (!user) {
                                    return;
                                }
                                const lastInteraction = state.lastInteraction;
                                const isIdle = lastInteraction != null ? now - lastInteraction > IDLE_TIMEOUT_MS : false;
                                result.push({
                                    ...user,
                                    clientId,
                                    lastInteraction,
                                    isIdle
                                });
                            }
                        }["usePresenceUsers[useEffect() > updateUsers > (anonymous)()]"]);
                        setUsers(result);
                    }
                }["usePresenceUsers[useEffect() > updateUsers]"];
                const unsubscribe = provider.onAwarenessChange(updateUsers);
                updateUsers();
                return ()=>{
                    unsubscribe();
                };
            }
        })["usePresenceUsers[useEffect()]"];
        t2 = [
            provider
        ];
        $[2] = provider;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return users;
}
_s6(usePresenceUsers, "bMc9h4N9OKuZQrV/7fQQ5OHy7B4=");
function useWorkbookComments(provider, blockId) {
    _s7();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18);
    if ($[0] !== "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf") {
        for(let $i = 0; $i < 18; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [threads, setThreads] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== blockId || $[3] !== provider) {
        t1 = ({
            "useWorkbookComments[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const commentsMap = provider.getCommentsMap();
                const updateThreads = {
                    "useWorkbookComments[useEffect() > updateThreads]": ()=>{
                        setThreads(provider.getComments(blockId));
                    }
                }["useWorkbookComments[useEffect() > updateThreads]"];
                updateThreads();
                commentsMap.observe(updateThreads);
                return ()=>{
                    commentsMap.unobserve(updateThreads);
                };
            }
        })["useWorkbookComments[useEffect()]"];
        t2 = [
            provider,
            blockId
        ];
        $[2] = blockId;
        $[3] = provider;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[6] !== blockId || $[7] !== provider) {
        t3 = ({
            "useWorkbookComments[addComment]": (text)=>{
                if (!provider || !blockId) {
                    return null;
                }
                return provider.addComment(blockId, text);
            }
        })["useWorkbookComments[addComment]"];
        $[6] = blockId;
        $[7] = provider;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    const addComment = t3;
    let t4;
    if ($[9] !== provider) {
        t4 = ({
            "useWorkbookComments[replyToComment]": (threadKey, text_0)=>{
                if (!provider) {
                    return;
                }
                provider.replyToComment(threadKey, text_0);
            }
        })["useWorkbookComments[replyToComment]"];
        $[9] = provider;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    const replyToComment = t4;
    let t5;
    if ($[11] !== provider) {
        t5 = ({
            "useWorkbookComments[resolveThread]": (threadKey_0, t6)=>{
                const resolved = t6 === undefined ? true : t6;
                if (!provider) {
                    return;
                }
                provider.resolveThread(threadKey_0, resolved);
            }
        })["useWorkbookComments[resolveThread]"];
        $[11] = provider;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    const resolveThread = t5;
    let t6;
    if ($[13] !== addComment || $[14] !== replyToComment || $[15] !== resolveThread || $[16] !== threads) {
        t6 = {
            threads,
            addComment,
            replyToComment,
            resolveThread
        };
        $[13] = addComment;
        $[14] = replyToComment;
        $[15] = resolveThread;
        $[16] = threads;
        $[17] = t6;
    } else {
        t6 = $[17];
    }
    return t6;
}
_s7(useWorkbookComments, "3RybUnneZvSF1ungGGLu403BWNE=");
function useBlockHistory(provider, blockId) {
    _s8();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "71f8ebf4890e9fdbc111bb32dfc41996d7961742b8555b36041fbac24886ffaf";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [entries, setEntries] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== blockId || $[3] !== provider) {
        t1 = ({
            "useBlockHistory[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const historyArray = provider.getDoc().getArray(`history-${blockId}`);
                const updateEntries = {
                    "useBlockHistory[useEffect() > updateEntries]": ()=>{
                        setEntries(Array.from(historyArray));
                    }
                }["useBlockHistory[useEffect() > updateEntries]"];
                updateEntries();
                historyArray.observe(updateEntries);
                return ()=>{
                    historyArray.unobserve(updateEntries);
                };
            }
        })["useBlockHistory[useEffect()]"];
        t2 = [
            provider,
            blockId
        ];
        $[2] = blockId;
        $[3] = provider;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[6] !== entries) {
        t3 = {
            entries
        };
        $[6] = entries;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    return t3;
}
_s8(useBlockHistory, "+fex2AwaOxKnPPb/tGdrde6jd9Y=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/yjs/hooks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAwareness",
    ()=>useAwareness,
    "useYArray",
    ()=>useYArray,
    "useYMap",
    ()=>useYMap,
    "useYText",
    ()=>useYText,
    "useYjsProvider",
    ()=>useYjsProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * useYjs - React hook for Yjs document provider
 * 
 * Manages document lifecycle and provides typed access to Y.Maps and Y.Arrays
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/YjsProvider.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature();
;
;
;
function useYjsProvider(config) {
    _s();
    const providerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isSynced, setIsSynced] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isConnected, setIsConnected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [, forceUpdate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsProvider.useEffect": ()=>{
            // Create provider if not already created
            if (!providerRef.current) {
                providerRef.current = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YjsDocProvider"](config);
            }
            const provider = providerRef.current;
            const wsProvider = provider.wsProvider;
            // Listen for sync status
            const handleSync = {
                "useYjsProvider.useEffect.handleSync": (synced)=>{
                    setIsSynced(synced);
                }
            }["useYjsProvider.useEffect.handleSync"];
            // Listen for connection status
            const handleStatus = {
                "useYjsProvider.useEffect.handleStatus": ({ status })=>{
                    setIsConnected(status === 'connected');
                }
            }["useYjsProvider.useEffect.handleStatus"];
            // Listen for doc-reset so consumers re-acquire Y.Doc references
            const handleDocReset = {
                "useYjsProvider.useEffect.handleDocReset": ()=>{
                    forceUpdate({
                        "useYjsProvider.useEffect.handleDocReset": (n)=>n + 1
                    }["useYjsProvider.useEffect.handleDocReset"]);
                }
            }["useYjsProvider.useEffect.handleDocReset"];
            provider.on('doc-reset', handleDocReset);
            if (wsProvider) {
                wsProvider.on('sync', handleSync);
                wsProvider.on('status', handleStatus);
            }
            return ({
                "useYjsProvider.useEffect": ()=>{
                    provider.off('doc-reset', handleDocReset);
                    if (wsProvider) {
                        wsProvider.off('sync', handleSync);
                        wsProvider.off('status', handleStatus);
                    }
                }
            })["useYjsProvider.useEffect"];
        }
    }["useYjsProvider.useEffect"], [
        config.docName
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useYjsProvider.useEffect": ()=>{
            // Cleanup on unmount
            return ({
                "useYjsProvider.useEffect": ()=>{
                // Don't destroy on unmount - keep document in memory for re-mounting
                // providerRef.current?.destroy()
                }
            })["useYjsProvider.useEffect"];
        }
    }["useYjsProvider.useEffect"], []);
    return {
        provider: providerRef.current,
        isSynced,
        isConnected
    };
}
_s(useYjsProvider, "gRCryHJI1LHWbNmTwMfHVGQMBaU=");
/**
 * Helper to check if Y type is ready to read from
 */ function isYTypeReady(ytype) {
    try {
        // Try to access the doc - will throw if not attached
        return ytype.doc !== null;
    } catch  {
        return false;
    }
}
function useYMap(ymap, initialState) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "07bae820d96868aee6a834525cf98fd5345ae824fad0c0c58918075349156db5") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "07bae820d96868aee6a834525cf98fd5345ae824fad0c0c58918075349156db5";
    }
    let t0;
    if ($[1] !== initialState) {
        t0 = initialState || {};
        $[1] = initialState;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[3] !== ymap) {
        t1 = ({
            "useYMap[useEffect()]": ()=>{
                if (!isYTypeReady(ymap)) {
                    console.warn("[useYMap] Y.Map not ready - skipping initial read");
                    return;
                }
                ;
                try {
                    const initialData = {};
                    ymap.forEach({
                        "useYMap[useEffect() > ymap.forEach()]": (value, key)=>{
                            initialData[key] = value;
                        }
                    }["useYMap[useEffect() > ymap.forEach()]"]);
                    setState(initialData);
                } catch (t3) {
                    const err = t3;
                    console.warn("[useYMap] Failed to initialize from Y.Map:", err);
                }
                const updateHandler = {
                    "useYMap[useEffect() > updateHandler]": ()=>{
                        ;
                        try {
                            const newData = {};
                            ymap.forEach({
                                "useYMap[useEffect() > updateHandler > ymap.forEach()]": (value_0, key_0)=>{
                                    newData[key_0] = value_0;
                                }
                            }["useYMap[useEffect() > updateHandler > ymap.forEach()]"]);
                            setState(newData);
                        } catch (t4) {
                            const err_0 = t4;
                            console.warn("[useYMap] Failed to update from Y.Map:", err_0);
                        }
                    }
                }["useYMap[useEffect() > updateHandler]"];
                ymap.observe(updateHandler);
                return ()=>{
                    ymap.unobserve(updateHandler);
                };
            }
        })["useYMap[useEffect()]"];
        t2 = [
            ymap
        ];
        $[3] = ymap;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[6] !== ymap) {
        t3 = ({
            "useYMap[updateValue]": (key_1, value_1)=>{
                ymap.set(String(key_1), value_1);
            }
        })["useYMap[updateValue]"];
        $[6] = ymap;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    const updateValue = t3;
    let t4;
    if ($[8] !== state || $[9] !== updateValue || $[10] !== ymap) {
        t4 = {
            state,
            updateValue,
            ymap
        };
        $[8] = state;
        $[9] = updateValue;
        $[10] = ymap;
        $[11] = t4;
    } else {
        t4 = $[11];
    }
    return t4;
}
_s1(useYMap, "JxtqLeQAOpJHyhwylfbSe2NhJoE=");
function useYArray(yarray) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "07bae820d96868aee6a834525cf98fd5345ae824fad0c0c58918075349156db5") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "07bae820d96868aee6a834525cf98fd5345ae824fad0c0c58918075349156db5";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [items, setItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== yarray) {
        t1 = ({
            "useYArray[useEffect()]": ()=>{
                if (!isYTypeReady(yarray)) {
                    console.warn("[useYArray] Y.Array not ready - skipping initial read");
                    return;
                }
                ;
                try {
                    setItems(Array.from(yarray));
                } catch (t3) {
                    const err = t3;
                    console.warn("[useYArray] Failed to initialize from Y.Array:", err);
                }
                const updateHandler = {
                    "useYArray[useEffect() > updateHandler]": ()=>{
                        ;
                        try {
                            setItems(Array.from(yarray));
                        } catch (t4) {
                            const err_0 = t4;
                            console.warn("[useYArray] Failed to update from Y.Array:", err_0);
                        }
                    }
                }["useYArray[useEffect() > updateHandler]"];
                yarray.observe(updateHandler);
                return ()=>{
                    yarray.unobserve(updateHandler);
                };
            }
        })["useYArray[useEffect()]"];
        t2 = [
            yarray
        ];
        $[2] = yarray;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[5] !== yarray) {
        t3 = ({
            "useYArray[push]": (item)=>{
                yarray.push([
                    item
                ]);
            }
        })["useYArray[push]"];
        $[5] = yarray;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const push = t3;
    let t4;
    if ($[7] !== yarray) {
        t4 = ({
            "useYArray[insert]": (index, item_0)=>{
                yarray.insert(index, [
                    item_0
                ]);
            }
        })["useYArray[insert]"];
        $[7] = yarray;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const insert = t4;
    let t5;
    if ($[9] !== yarray) {
        t5 = ({
            "useYArray[delete_]": (index_0, t6)=>{
                const length = t6 === undefined ? 1 : t6;
                yarray.delete(index_0, length);
            }
        })["useYArray[delete_]"];
        $[9] = yarray;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    const delete_ = t5;
    let t6;
    if ($[11] !== yarray) {
        t6 = ({
            "useYArray[clear]": ()=>{
                yarray.delete(0, yarray.length);
            }
        })["useYArray[clear]"];
        $[11] = yarray;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    const clear = t6;
    let t7;
    if ($[13] !== clear || $[14] !== delete_ || $[15] !== insert || $[16] !== items || $[17] !== push || $[18] !== yarray) {
        t7 = {
            items,
            push,
            insert,
            delete: delete_,
            clear,
            yarray
        };
        $[13] = clear;
        $[14] = delete_;
        $[15] = insert;
        $[16] = items;
        $[17] = push;
        $[18] = yarray;
        $[19] = t7;
    } else {
        t7 = $[19];
    }
    return t7;
}
_s2(useYArray, "BLhofg9JkZqiBpok1qEICemGFh0=");
function useYText(ytext) {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "07bae820d96868aee6a834525cf98fd5345ae824fad0c0c58918075349156db5") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "07bae820d96868aee6a834525cf98fd5345ae824fad0c0c58918075349156db5";
    }
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let t0;
    let t1;
    if ($[1] !== ytext) {
        t0 = ({
            "useYText[useEffect()]": ()=>{
                if (!isYTypeReady(ytext)) {
                    console.warn("[useYText] Y.Text not ready - skipping initial read");
                    return;
                }
                ;
                try {
                    setContent(ytext.toString());
                } catch (t2) {
                    const err = t2;
                    console.warn("[useYText] Failed to initialize from Y.Text:", err);
                }
                const updateHandler = {
                    "useYText[useEffect() > updateHandler]": ()=>{
                        ;
                        try {
                            setContent(ytext.toString());
                        } catch (t3) {
                            const err_0 = t3;
                            console.warn("[useYText] Failed to update from Y.Text:", err_0);
                        }
                    }
                }["useYText[useEffect() > updateHandler]"];
                ytext.observe(updateHandler);
                return ()=>{
                    ytext.unobserve(updateHandler);
                };
            }
        })["useYText[useEffect()]"];
        t1 = [
            ytext
        ];
        $[1] = ytext;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    let t2;
    if ($[4] !== ytext) {
        t2 = ({
            "useYText[insert]": (index, text)=>{
                ytext.insert(index, text);
            }
        })["useYText[insert]"];
        $[4] = ytext;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    const insert = t2;
    let t3;
    if ($[6] !== ytext) {
        t3 = ({
            "useYText[delete_]": (index_0, length)=>{
                ytext.delete(index_0, length);
            }
        })["useYText[delete_]"];
        $[6] = ytext;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    const delete_ = t3;
    let t4;
    if ($[8] !== ytext) {
        t4 = ({
            "useYText[format_0]": (index_1, length_0, format)=>{
                ytext.format(index_1, length_0, format);
            }
        })["useYText[format_0]"];
        $[8] = ytext;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    const format_0 = t4;
    let t5;
    if ($[10] !== content || $[11] !== delete_ || $[12] !== format_0 || $[13] !== insert || $[14] !== ytext) {
        t5 = {
            content,
            insert,
            delete: delete_,
            format: format_0,
            ytext,
            length: ytext.length
        };
        $[10] = content;
        $[11] = delete_;
        $[12] = format_0;
        $[13] = insert;
        $[14] = ytext;
        $[15] = t5;
    } else {
        t5 = $[15];
    }
    return t5;
}
_s3(useYText, "sr04CA2tf335xnQdpVaJvTVIPd4=");
function useAwareness(awareness) {
    _s4();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "07bae820d96868aee6a834525cf98fd5345ae824fad0c0c58918075349156db5") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "07bae820d96868aee6a834525cf98fd5345ae824fad0c0c58918075349156db5";
    }
    let t0;
    if ($[1] !== awareness) {
        t0 = awareness.getLocalState();
        $[1] = awareness;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const [awareness_, setAwareness] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = new Map();
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const [remoteStates, setRemoteStates] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    let t3;
    if ($[4] !== awareness) {
        t2 = ({
            "useAwareness[useEffect()]": ()=>{
                const updateHandler = {
                    "useAwareness[useEffect() > updateHandler]": ()=>{
                        const localState = awareness.getLocalState();
                        if (localState) {
                            setAwareness(localState);
                        }
                        const states = new Map(awareness.getStates());
                        setRemoteStates(states);
                    }
                }["useAwareness[useEffect() > updateHandler]"];
                awareness.on("change", updateHandler);
                return ()=>{
                    awareness.off("change", updateHandler);
                };
            }
        })["useAwareness[useEffect()]"];
        t3 = [
            awareness
        ];
        $[4] = awareness;
        $[5] = t2;
        $[6] = t3;
    } else {
        t2 = $[5];
        t3 = $[6];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    let t4;
    if ($[7] !== awareness) {
        t4 = ({
            "useAwareness[setLocalState]": (state)=>{
                awareness.setLocalState(state);
            }
        })["useAwareness[setLocalState]"];
        $[7] = awareness;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const setLocalState = t4;
    let t5;
    if ($[9] !== awareness.clientID || $[10] !== awareness_ || $[11] !== remoteStates || $[12] !== setLocalState) {
        t5 = {
            localState: awareness_,
            remoteStates,
            setLocalState,
            clientId: awareness.clientID
        };
        $[9] = awareness.clientID;
        $[10] = awareness_;
        $[11] = remoteStates;
        $[12] = setLocalState;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    return t5;
}
_s4(useAwareness, "gCc6E//o7oX/eHnogJEFwKOHy/M=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/yjs/PracticeCollaborationProvider.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * PracticeCollaborationProvider — Yjs provider for collaborative practice drill sessions.
 *
 * Each collaborative practice session is a Yjs document (`practice-{sessionId}`) with:
 * - `answersMap` Y.Map — merged block answers from all participants (keyed by blockId)
 * - `progressMap` Y.Map — per-participant progress (keyed by participantId)
 * - `groupStatsMap` Y.Map — aggregated group accuracy (no individual attribution)
 * - `messagesArray` Y.Array — in-session chat for study discussion
 *
 * Awareness carries: { user, activeBlockId, typing }
 *
 * Privacy: individual scores are tracked in progressMap but only the owner
 * and participant themselves can read their entry. The groupStatsMap exposes
 * only anonymized aggregates (average accuracy, blocks completed count).
 *
 * @module PracticeCollaborationProvider
 */ __turbopack_context__.s([
    "PracticeCollaborationProvider",
    ()=>PracticeCollaborationProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/YjsProvider.ts [app-client] (ecmascript)");
;
class PracticeCollaborationProvider extends __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$YjsProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YjsDocProvider"] {
    sessionId;
    user;
    practiceConfig;
    // Y.js structures
    answersMap;
    progressMap;
    groupStatsMap;
    messagesArray;
    activeParticipants = new Map();
    constructor(config){
        const docName = `practice-${config.sessionId}`;
        super({
            docName,
            wsUrl: config.wsUrl,
            connect: config.connect ?? true,
            persistence: config.persistence ?? true
        });
        this.sessionId = config.sessionId;
        this.user = config.user;
        this.practiceConfig = config;
        this.answersMap = this.getDoc().getMap("answers");
        this.progressMap = this.getDoc().getMap("progress");
        this.groupStatsMap = this.getDoc().getMap("groupStats");
        this.messagesArray = this.getDoc().getArray("messages");
        this.initializeAwareness();
        this.setupAwarenessHandlers();
    }
    // ========================================================================
    // Awareness
    // ========================================================================
    initializeAwareness() {
        const awareness = this.getAwareness();
        awareness.setLocalState({
            user: this.user,
            activeBlockId: null,
            typing: false
        });
    }
    setupAwarenessHandlers() {
        const awareness = this.getAwareness();
        awareness.on("change", ({ added, removed })=>{
            added.forEach((clientId)=>{
                if (clientId === awareness.clientID) return;
                const state = awareness.getStates().get(clientId);
                const peerUser = state?.user;
                if (peerUser) {
                    this.activeParticipants.set(clientId, peerUser);
                    this.practiceConfig.onParticipantJoin?.(peerUser);
                }
            });
            removed.forEach((clientId)=>{
                const leaving = this.activeParticipants.get(clientId);
                if (leaving) {
                    this.activeParticipants.delete(clientId);
                    this.practiceConfig.onParticipantLeave?.(leaving);
                }
            });
        });
    }
    /**
   * Set which block the local user is currently working on.
   */ setActiveBlock(blockId) {
        const awareness = this.getAwareness();
        const currentState = awareness.getLocalState();
        awareness.setLocalState({
            ...currentState,
            activeBlockId: blockId
        });
    }
    /**
   * Set the local user's typing state (for chat).
   */ setTyping(typing) {
        const awareness = this.getAwareness();
        const currentState = awareness.getLocalState();
        awareness.setLocalState({
            ...currentState,
            typing
        });
    }
    // ========================================================================
    // Block Answers — append-only per block, all participants' answers visible
    // ========================================================================
    /**
   * Submit an answer for a block. Appends to the block's answer array.
   * Each participant's answer is tracked separately.
   */ submitBlockAnswer(blockId, answer) {
        const entry = {
            ...answer,
            answeredBy: this.user.username,
            timestamp: new Date().toISOString()
        };
        const existing = this.answersMap.get(blockId) || [];
        // Replace previous answer from same user, or append
        const filtered = existing.filter((a)=>a.answeredBy !== this.user.username);
        this.answersMap.set(blockId, [
            ...filtered,
            entry
        ]);
        // Update own progress
        this.updateOwnProgress();
        // Recalculate group stats
        this.recalculateGroupStats();
    }
    /**
   * Get all answers for a specific block.
   */ getBlockAnswers(blockId) {
        return this.answersMap.get(blockId) || [];
    }
    /**
   * Get the current user's answer for a block, if any.
   */ getOwnAnswer(blockId) {
        const answers = this.answersMap.get(blockId) || [];
        return answers.find((a)=>a.answeredBy === this.user.username);
    }
    // ========================================================================
    // Progress — per-participant, only own + aggregate visible to students
    // ========================================================================
    updateOwnProgress() {
        let blocksCompleted = 0;
        let blocksAttempted = 0;
        this.answersMap.forEach((answers)=>{
            const own = answers.find((a)=>a.answeredBy === this.user.username);
            if (own) {
                blocksAttempted++;
                if (own.complete) blocksCompleted++;
            }
        });
        this.progressMap.set(this.user.username, {
            username: this.user.username,
            blocksCompleted,
            blocksAttempted,
            lastActiveAt: new Date().toISOString()
        });
    }
    /**
   * Get own progress.
   */ getOwnProgress() {
        return this.progressMap.get(this.user.username) || {
            username: this.user.username,
            blocksCompleted: 0,
            blocksAttempted: 0,
            lastActiveAt: new Date().toISOString()
        };
    }
    // ========================================================================
    // Group Stats — anonymized aggregates only
    // ========================================================================
    recalculateGroupStats() {
        const participantAccuracies = new Map();
        const blockAccuracies = {};
        let totalCompleted = 0;
        this.answersMap.forEach((answers, blockId)=>{
            const accuracies = [];
            for (const answer of answers){
                if (answer.complete) {
                    totalCompleted++;
                    accuracies.push(answer.accuracy);
                    // Collect per-participant
                    if (!participantAccuracies.has(answer.answeredBy)) {
                        participantAccuracies.set(answer.answeredBy, []);
                    }
                    participantAccuracies.get(answer.answeredBy).push(answer.accuracy);
                }
            }
            if (accuracies.length > 0) {
                blockAccuracies[blockId] = accuracies.reduce((s, a)=>s + a, 0) / accuracies.length;
            }
        });
        // Average accuracy across all participants
        let overallSum = 0;
        let overallCount = 0;
        participantAccuracies.forEach((accs)=>{
            const avg = accs.reduce((s, a)=>s + a, 0) / accs.length;
            overallSum += avg;
            overallCount++;
        });
        const stats = {
            totalParticipants: participantAccuracies.size,
            averageAccuracy: overallCount > 0 ? Math.round(overallSum / overallCount * 100) / 100 : 0,
            blocksCompletedTotal: totalCompleted,
            blockAccuracies: blockAccuracies,
            lastUpdated: new Date().toISOString()
        };
        this.groupStatsMap.set("stats", stats);
    }
    /**
   * Get anonymized group statistics.
   * Shows average accuracy and completion counts without individual attribution.
   */ getGroupStats() {
        return this.groupStatsMap.get("stats") || {
            totalParticipants: 0,
            averageAccuracy: 0,
            blocksCompletedTotal: 0,
            blockAccuracies: {},
            lastUpdated: new Date().toISOString()
        };
    }
    // ========================================================================
    // Chat Messages
    // ========================================================================
    /**
   * Send a message in the study session chat.
   */ sendMessage(content, referencedBlockId) {
        const message = {
            id: crypto.randomUUID(),
            author: this.user.username,
            displayName: this.user.displayName,
            content,
            referencedBlockId,
            createdAt: new Date().toISOString()
        };
        this.messagesArray.push([
            message
        ]);
        return message;
    }
    /**
   * Get all messages.
   */ getMessages() {
        return Array.from(this.messagesArray);
    }
    // ========================================================================
    // Accessors for hook observation
    // ========================================================================
    getAnswersMap() {
        return this.answersMap;
    }
    getProgressMap() {
        return this.progressMap;
    }
    getGroupStatsMap() {
        return this.groupStatsMap;
    }
    getMessagesArray() {
        return this.messagesArray;
    }
    getSessionId() {
        return this.sessionId;
    }
    getUser() {
        return this.user;
    }
    /**
   * Get active participants from awareness (excluding self).
   */ getActiveParticipants() {
        return Array.from(this.activeParticipants.values());
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/yjs/practiceCollaborationHooks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePracticeBlockAnswers",
    ()=>usePracticeBlockAnswers,
    "usePracticeCollaboration",
    ()=>usePracticeCollaboration,
    "usePracticeGroupStats",
    ()=>usePracticeGroupStats,
    "usePracticeParticipants",
    ()=>usePracticeParticipants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * React hooks for collaborative practice drill sessions.
 *
 * @module practiceCollaborationHooks
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$PracticeCollaborationProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/yjs/PracticeCollaborationProvider.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
;
;
;
function usePracticeCollaboration(options) {
    _s();
    const { sessionId, user, wsUrl, connect = true, persistence = true, onParticipantJoin, onParticipantLeave } = options || {};
    const providerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [participants, setParticipants] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [groupStats, setGroupStats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        totalParticipants: 0,
        averageAccuracy: 0,
        blocksCompletedTotal: 0,
        blockAccuracies: {},
        lastUpdated: new Date().toISOString()
    });
    const [ownProgress, setOwnProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        username: user?.username || '',
        blocksCompleted: 0,
        blocksAttempted: 0,
        lastActiveAt: new Date().toISOString()
    });
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isConnected, setIsConnected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePracticeCollaboration.useEffect": ()=>{
            if (!options || !sessionId || !user?.username) return;
            const provider = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$yjs$2f$PracticeCollaborationProvider$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PracticeCollaborationProvider"]({
                sessionId,
                user,
                wsUrl,
                connect,
                persistence,
                onParticipantJoin,
                onParticipantLeave
            });
            providerRef.current = provider;
            // Observe answers map → triggers groupStats + ownProgress refresh
            const answersMap = provider.getAnswersMap();
            const handleAnswersChange = {
                "usePracticeCollaboration.useEffect.handleAnswersChange": ()=>{
                    setGroupStats(provider.getGroupStats());
                    setOwnProgress(provider.getOwnProgress());
                }
            }["usePracticeCollaboration.useEffect.handleAnswersChange"];
            answersMap.observe(handleAnswersChange);
            // Observe group stats map
            const groupStatsMap = provider.getGroupStatsMap();
            const handleGroupStatsChange = {
                "usePracticeCollaboration.useEffect.handleGroupStatsChange": ()=>{
                    setGroupStats(provider.getGroupStats());
                }
            }["usePracticeCollaboration.useEffect.handleGroupStatsChange"];
            groupStatsMap.observe(handleGroupStatsChange);
            // Observe messages
            const messagesArray = provider.getMessagesArray();
            const handleMessagesChange = {
                "usePracticeCollaboration.useEffect.handleMessagesChange": ()=>{
                    setMessages(provider.getMessages());
                }
            }["usePracticeCollaboration.useEffect.handleMessagesChange"];
            messagesArray.observe(handleMessagesChange);
            handleMessagesChange();
            // Observe awareness for participants
            const unsubscribeAwareness = provider.onAwarenessChange({
                "usePracticeCollaboration.useEffect.unsubscribeAwareness": ()=>{
                    setParticipants(provider.getActiveParticipants());
                }
            }["usePracticeCollaboration.useEffect.unsubscribeAwareness"]);
            // Connection status
            const wsProvider = provider.wsProvider;
            if (wsProvider) {
                wsProvider.on('status', {
                    "usePracticeCollaboration.useEffect": ({ status })=>{
                        setIsConnected(status === 'connected');
                    }
                }["usePracticeCollaboration.useEffect"]);
            }
            // Initial state
            setGroupStats(provider.getGroupStats());
            setOwnProgress(provider.getOwnProgress());
            setParticipants(provider.getActiveParticipants());
            return ({
                "usePracticeCollaboration.useEffect": ()=>{
                    answersMap.unobserve(handleAnswersChange);
                    groupStatsMap.unobserve(handleGroupStatsChange);
                    messagesArray.unobserve(handleMessagesChange);
                    unsubscribeAwareness();
                    provider.destroy();
                    providerRef.current = null;
                }
            })["usePracticeCollaboration.useEffect"];
        }
    }["usePracticeCollaboration.useEffect"], [
        sessionId,
        user?.username
    ]);
    const submitBlockAnswer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeCollaboration.useCallback[submitBlockAnswer]": (blockId, answer)=>{
            providerRef.current?.submitBlockAnswer(blockId, answer);
        }
    }["usePracticeCollaboration.useCallback[submitBlockAnswer]"], []);
    const getBlockAnswers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeCollaboration.useCallback[getBlockAnswers]": (blockId_0)=>{
            return providerRef.current?.getBlockAnswers(blockId_0) || [];
        }
    }["usePracticeCollaboration.useCallback[getBlockAnswers]"], []);
    const getOwnAnswer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeCollaboration.useCallback[getOwnAnswer]": (blockId_1)=>{
            return providerRef.current?.getOwnAnswer(blockId_1);
        }
    }["usePracticeCollaboration.useCallback[getOwnAnswer]"], []);
    const sendMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeCollaboration.useCallback[sendMessage]": (content, referencedBlockId)=>{
            providerRef.current?.sendMessage(content, referencedBlockId);
        }
    }["usePracticeCollaboration.useCallback[sendMessage]"], []);
    const setActiveBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeCollaboration.useCallback[setActiveBlock]": (blockId_2)=>{
            providerRef.current?.setActiveBlock(blockId_2);
        }
    }["usePracticeCollaboration.useCallback[setActiveBlock]"], []);
    const setTyping = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePracticeCollaboration.useCallback[setTyping]": (typing)=>{
            providerRef.current?.setTyping(typing);
        }
    }["usePracticeCollaboration.useCallback[setTyping]"], []);
    return {
        provider: providerRef.current,
        participants,
        groupStats,
        ownProgress,
        messages,
        isConnected,
        submitBlockAnswer,
        getBlockAnswers,
        getOwnAnswer,
        sendMessage,
        setActiveBlock,
        setTyping
    };
}
_s(usePracticeCollaboration, "MWuGD8qbPT5PRNtDh4m4G2pfIfo=");
function usePracticeGroupStats(provider) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "38218a924cc184d5142640c44427ce192dff021517953f65dafaeaf6e2351ee1") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "38218a924cc184d5142640c44427ce192dff021517953f65dafaeaf6e2351ee1";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            totalParticipants: 0,
            averageAccuracy: 0,
            blocksCompletedTotal: 0,
            blockAccuracies: {},
            lastUpdated: new Date().toISOString()
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [stats, setStats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== provider) {
        t1 = ({
            "usePracticeGroupStats[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const groupStatsMap = provider.getGroupStatsMap();
                const handleChange = {
                    "usePracticeGroupStats[useEffect() > handleChange]": ()=>{
                        setStats(provider.getGroupStats());
                    }
                }["usePracticeGroupStats[useEffect() > handleChange]"];
                handleChange();
                groupStatsMap.observe(handleChange);
                return ()=>{
                    groupStatsMap.unobserve(handleChange);
                };
            }
        })["usePracticeGroupStats[useEffect()]"];
        t2 = [
            provider
        ];
        $[2] = provider;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return stats;
}
_s1(usePracticeGroupStats, "4tpvAwWDAEZQM/ffiHlnO5uFZE4=");
function usePracticeParticipants(provider) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "38218a924cc184d5142640c44427ce192dff021517953f65dafaeaf6e2351ee1") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "38218a924cc184d5142640c44427ce192dff021517953f65dafaeaf6e2351ee1";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [participants, setParticipants] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== provider) {
        t1 = ({
            "usePracticeParticipants[useEffect()]": ()=>{
                if (!provider) {
                    return;
                }
                const updateParticipants = {
                    "usePracticeParticipants[useEffect() > updateParticipants]": ()=>{
                        setParticipants(provider.getActiveParticipants());
                    }
                }["usePracticeParticipants[useEffect() > updateParticipants]"];
                const unsubscribe = provider.onAwarenessChange(updateParticipants);
                updateParticipants();
                return ()=>{
                    unsubscribe();
                };
            }
        })["usePracticeParticipants[useEffect()]"];
        t2 = [
            provider
        ];
        $[2] = provider;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return participants;
}
_s2(usePracticeParticipants, "dv39Eykavimirt48kuQd6DZD++o=");
function usePracticeBlockAnswers(provider, blockId) {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "38218a924cc184d5142640c44427ce192dff021517953f65dafaeaf6e2351ee1") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "38218a924cc184d5142640c44427ce192dff021517953f65dafaeaf6e2351ee1";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [answers, setAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== blockId || $[3] !== provider) {
        t1 = ({
            "usePracticeBlockAnswers[useEffect()]": ()=>{
                if (!provider || !blockId) {
                    return;
                }
                const answersMap = provider.getAnswersMap();
                const handleChange = {
                    "usePracticeBlockAnswers[useEffect() > handleChange]": ()=>{
                        setAnswers(provider.getBlockAnswers(blockId));
                    }
                }["usePracticeBlockAnswers[useEffect() > handleChange]"];
                handleChange();
                answersMap.observe(handleChange);
                return ()=>{
                    answersMap.unobserve(handleChange);
                };
            }
        })["usePracticeBlockAnswers[useEffect()]"];
        t2 = [
            provider,
            blockId
        ];
        $[2] = blockId;
        $[3] = provider;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return answers;
}
_s3(usePracticeBlockAnswers, "mcebAtm675asqLgRuZrIBMGXSFY=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0pw-gbk._.js.map