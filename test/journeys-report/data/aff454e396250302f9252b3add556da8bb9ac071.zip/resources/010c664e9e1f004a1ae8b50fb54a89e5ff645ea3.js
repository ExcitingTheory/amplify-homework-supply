(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/AppShellContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AppShellContext",
    ()=>AppShellContext,
    "DRAWER_WIDTH",
    ()=>DRAWER_WIDTH,
    "useAppShell",
    ()=>useAppShell,
    "useSecondaryToolbar",
    ()=>useSecondaryToolbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
const DRAWER_WIDTH = 280;
const AppShellContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({
    drawerOpen: false,
    setDrawerOpen: undefined,
    isDesktop: undefined,
    drawerWidth: DRAWER_WIDTH,
    toolbarContent: null,
    setToolbarContent: undefined,
    appBarHeight: 48,
    toolbarPortalRef: {
        current: null
    },
    toolbarChildrenPortalRef: {
        current: null
    }
});
function useAppShell() {
    _s();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](AppShellContext);
}
_s(useAppShell, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
function useSecondaryToolbar(content) {
    _s1();
    const { setToolbarContent } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](AppShellContext);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "useSecondaryToolbar.useEffect": ()=>{
            if (setToolbarContent) {
                setToolbarContent(content);
            }
            return ({
                "useSecondaryToolbar.useEffect": ()=>{
                    if (setToolbarContent) {
                        setToolbarContent(null);
                    }
                }
            })["useSecondaryToolbar.useEffect"];
        }
    }["useSecondaryToolbar.useEffect"], [
        content,
        setToolbarContent
    ]);
}
_s1(useSecondaryToolbar, "EdTpMOZCneMy6sjB0IDjydpqJdw=");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/SyncStatusIndicator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SyncStatusIndicator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Badge/Badge.js [app-client] (ecmascript) <export default as Badge>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemIcon/ListItemIcon.js [app-client] (ecmascript) <export default as ListItemIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudSync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CloudSync.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudOff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CloudOff.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ErrorOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ErrorOutline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Refresh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Refresh.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useNetworkStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useNetworkStatus.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function SyncStatusIndicator() {
    _s();
    const { isOnline } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useNetworkStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNetworkStatus"])();
    const [pendingCount, setPendingCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [pendingOps, setPendingOps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [dialogOpen, setDialogOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [syncing, setSyncing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Load pending count
    const refreshCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SyncStatusIndicator.useCallback[refreshCount]": async ()=>{
            try {
                const { getPendingCount, getAllPending } = await __turbopack_context__.A("[project]/src/offline/SyncQueue.ts [app-client] (ecmascript, async loader)");
                const count = await getPendingCount();
                setPendingCount(count);
                if (dialogOpen) {
                    const ops = await getAllPending();
                    setPendingOps(ops);
                }
            } catch  {
            // Module not loaded yet
            }
        }
    }["SyncStatusIndicator.useCallback[refreshCount]"], [
        dialogOpen
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SyncStatusIndicator.useEffect": ()=>{
            refreshCount();
            const interval = setInterval(refreshCount, 5000);
            return ({
                "SyncStatusIndicator.useEffect": ()=>clearInterval(interval)
            })["SyncStatusIndicator.useEffect"];
        }
    }["SyncStatusIndicator.useEffect"], [
        refreshCount
    ]);
    // Listen for service worker sync messages
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SyncStatusIndicator.useEffect": ()=>{
            const handler = {
                "SyncStatusIndicator.useEffect.handler": (event)=>{
                    if (event.data?.type === 'SYNC_COMPLETE') {
                        refreshCount();
                    }
                }
            }["SyncStatusIndicator.useEffect.handler"];
            if (typeof navigator !== 'undefined' && navigator.serviceWorker) {
                navigator.serviceWorker.addEventListener('message', handler);
                return ({
                    "SyncStatusIndicator.useEffect": ()=>navigator.serviceWorker.removeEventListener('message', handler)
                })["SyncStatusIndicator.useEffect"];
            }
        }
    }["SyncStatusIndicator.useEffect"], [
        refreshCount
    ]);
    const handleManualSync = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SyncStatusIndicator.useCallback[handleManualSync]": async ()=>{
            setSyncing(true);
            try {
                if (navigator.serviceWorker?.controller) {
                    navigator.serviceWorker.controller.postMessage({
                        type: 'PROCESS_SYNC_QUEUE'
                    });
                }
                // Wait a moment then refresh
                await new Promise({
                    "SyncStatusIndicator.useCallback[handleManualSync]": (r)=>setTimeout(r, 2000)
                }["SyncStatusIndicator.useCallback[handleManualSync]"]);
                await refreshCount();
            } finally{
                setSyncing(false);
            }
        }
    }["SyncStatusIndicator.useCallback[handleManualSync]"], [
        refreshCount
    ]);
    if (pendingCount === 0) {
        if (!isOnline) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                title: "Offline — no pending changes",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudOff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                        lineNumber: 80,
                        columnNumber: 23
                    }, this),
                    label: "Offline",
                    size: "small",
                    variant: "outlined"
                }, void 0, false, {
                    fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                    lineNumber: 80,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                lineNumber: 79,
                columnNumber: 14
            }, this);
        }
        return null; // All synced, nothing to show
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                title: `${pendingCount} changes pending sync`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__["Badge"], {
                    badgeContent: pendingCount,
                    color: "warning",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                        icon: isOnline ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudSync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                            lineNumber: 88,
                            columnNumber: 34
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudOff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                            lineNumber: 88,
                            columnNumber: 50
                        }, this),
                        label: `${pendingCount} pending`,
                        size: "small",
                        variant: "outlined",
                        color: isOnline ? 'primary' : 'default',
                        onClick: ()=>setDialogOpen(true),
                        sx: {
                            cursor: 'pointer'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                        lineNumber: 88,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                    lineNumber: 87,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                lineNumber: 86,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                open: dialogOpen,
                onClose: ()=>setDialogOpen(false),
                maxWidth: "sm",
                fullWidth: true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                        children: [
                            "Pending Sync Operations",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                onClick: handleManualSync,
                                disabled: !isOnline || syncing,
                                sx: {
                                    float: 'right'
                                },
                                children: syncing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                    variant: "circular",
                                    width: 20,
                                    height: 20
                                }, void 0, false, {
                                    fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                    lineNumber: 100,
                                    columnNumber: 24
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Refresh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                    lineNumber: 100,
                                    columnNumber: 81
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                lineNumber: 97,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                        children: pendingOps.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            color: "text.secondary",
                            children: "No pending operations"
                        }, void 0, false, {
                            fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                            lineNumber: 104,
                            columnNumber: 38
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                            dense: true,
                            children: pendingOps.map((op)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                            children: op.lastError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ErrorOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                color: "error"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                                lineNumber: 107,
                                                columnNumber: 37
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudSync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                color: "primary"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                                lineNumber: 107,
                                                columnNumber: 70
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                            lineNumber: 106,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                            primary: `${op.operation} ${op.model}`,
                                            secondary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    new Date(op.createdAt).toLocaleString(),
                                                    op.retryCount > 0 && ` · ${op.retryCount} retries`,
                                                    op.lastError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        component: "span",
                                                        variant: "caption",
                                                        color: "error",
                                                        display: "block",
                                                        children: op.lastError
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                                        lineNumber: 112,
                                                        columnNumber: 42
                                                    }, this)
                                                ]
                                            }, void 0, true)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                            lineNumber: 109,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, op.id ?? op.createdAt, true, {
                                    fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                    lineNumber: 105,
                                    columnNumber: 37
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                            lineNumber: 104,
                            columnNumber: 110
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                        lineNumber: 103,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                onClick: ()=>setDialogOpen(false),
                                children: "Close"
                            }, void 0, false, {
                                fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                lineNumber: 120,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                onClick: handleManualSync,
                                disabled: !isOnline || syncing,
                                variant: "contained",
                                startIcon: syncing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                                    variant: "circular",
                                    width: 16,
                                    height: 16
                                }, void 0, false, {
                                    fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                    lineNumber: 121,
                                    columnNumber: 119
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudSync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                    lineNumber: 121,
                                    columnNumber: 176
                                }, this),
                                children: "Sync now"
                            }, void 0, false, {
                                fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                                lineNumber: 121,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                        lineNumber: 119,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/SyncStatusIndicator.tsx",
                lineNumber: 94,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(SyncStatusIndicator, "ln6QSWiyMGyzZbTow6GKa0xPyBs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useNetworkStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNetworkStatus"]
    ];
});
_c = SyncStatusIndicator;
var _c;
__turbopack_context__.k.register(_c, "SyncStatusIndicator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Notifications/NotificationInvitations.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NotificationInvitations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemSecondaryAction$2f$ListItemSecondaryAction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemSecondaryAction/ListItemSecondaryAction.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$NotificationsNone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/NotificationsNone.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$notificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/notificationContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
function NotificationInvitations(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23);
    if ($[0] !== "6e1997d9236cd4c1d21ef7b0997f27f93959778f2569d75b64fc4dbd8f852219") {
        for(let $i = 0; $i < 23; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6e1997d9236cd4c1d21ef7b0997f27f93959778f2569d75b64fc4dbd8f852219";
    }
    const { types, onJoin, joinLabel: t1, emptyMessage: t2 } = t0;
    const joinLabel = t1 === undefined ? "Join" : t1;
    const emptyMessage = t2 === undefined ? "No pending invitations" : t2;
    const { notifications, loading, markInteracted } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$notificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotifications"])();
    let t3;
    if ($[1] !== notifications || $[2] !== types) {
        let t4;
        if ($[4] !== types) {
            t4 = ({
                "NotificationInvitations[notifications.filter()]": (n)=>typeof n.type === "string" && types.includes(n.type) && !n.interacted
            })["NotificationInvitations[notifications.filter()]"];
            $[4] = types;
            $[5] = t4;
        } else {
            t4 = $[5];
        }
        t3 = notifications.filter(t4);
        $[1] = notifications;
        $[2] = types;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const invitations = t3;
    if (loading) {
        let t4;
        if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = {
                p: 2
            };
            $[6] = t4;
        } else {
            t4 = $[6];
        }
        let t5;
        if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t4,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "rectangular",
                        height: 48,
                        sx: {
                            mb: 1
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                        lineNumber: 82,
                        columnNumber: 25
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "rectangular",
                        height: 48
                    }, void 0, false, {
                        fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                        lineNumber: 84,
                        columnNumber: 14
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                lineNumber: 82,
                columnNumber: 12
            }, this);
            $[7] = t5;
        } else {
            t5 = $[7];
        }
        return t5;
    }
    if (invitations.length === 0) {
        let t4;
        if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = {
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                py: 3,
                px: 2
            };
            $[8] = t4;
        } else {
            t4 = $[8];
        }
        let t5;
        if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$NotificationsNone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    fontSize: 40,
                    color: "text.disabled",
                    mb: 1
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                lineNumber: 107,
                columnNumber: 12
            }, this);
            $[9] = t5;
        } else {
            t5 = $[9];
        }
        let t6;
        if ($[10] !== emptyMessage) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t4,
                children: [
                    t5,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "body2",
                        color: "text.secondary",
                        children: emptyMessage
                    }, void 0, false, {
                        fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                        lineNumber: 118,
                        columnNumber: 29
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                lineNumber: 118,
                columnNumber: 12
            }, this);
            $[10] = emptyMessage;
            $[11] = t6;
        } else {
            t6 = $[11];
        }
        return t6;
    }
    let t4;
    if ($[12] !== invitations || $[13] !== joinLabel || $[14] !== markInteracted || $[15] !== onJoin) {
        let t5;
        if ($[17] !== joinLabel || $[18] !== markInteracted || $[19] !== onJoin) {
            t5 = ({
                "NotificationInvitations[invitations.map()]": (notification)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        divider: true,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                primary: notification.title,
                                secondary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    component: "span",
                                    sx: {
                                        display: "flex",
                                        alignItems: "center",
                                        gap: 0.5
                                    },
                                    children: [
                                        notification.senderName && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                "From: ",
                                                notification.senderName
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                                            lineNumber: 135,
                                            columnNumber: 42
                                        }, this),
                                        notification.body && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            variant: "caption",
                                            color: "text.disabled",
                                            component: "span",
                                            sx: {
                                                ml: 1
                                            },
                                            children: notification.body
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                                            lineNumber: 135,
                                            columnNumber: 109
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                                    lineNumber: 131,
                                    columnNumber: 172
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                                lineNumber: 131,
                                columnNumber: 118
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemSecondaryAction$2f$ListItemSecondaryAction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    sx: {
                                        display: "flex",
                                        alignItems: "center",
                                        gap: 1
                                    },
                                    children: [
                                        !notification.seen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            label: "New",
                                            size: "small",
                                            color: "primary"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                                            lineNumber: 141,
                                            columnNumber: 39
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            variant: "contained",
                                            size: "small",
                                            onClick: {
                                                "NotificationInvitations[invitations.map() > <Button>.onClick]": ()=>{
                                                    markInteracted(notification.id);
                                                    onJoin(notification);
                                                }
                                            }["NotificationInvitations[invitations.map() > <Button>.onClick]"],
                                            children: joinLabel
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                                            lineNumber: 141,
                                            columnNumber: 89
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                                    lineNumber: 137,
                                    columnNumber: 84
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                                lineNumber: 137,
                                columnNumber: 59
                            }, this)
                        ]
                    }, notification.id, true, {
                        fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
                        lineNumber: 131,
                        columnNumber: 71
                    }, this)
            })["NotificationInvitations[invitations.map()]"];
            $[17] = joinLabel;
            $[18] = markInteracted;
            $[19] = onJoin;
            $[20] = t5;
        } else {
            t5 = $[20];
        }
        t4 = invitations.map(t5);
        $[12] = invitations;
        $[13] = joinLabel;
        $[14] = markInteracted;
        $[15] = onJoin;
        $[16] = t4;
    } else {
        t4 = $[16];
    }
    let t5;
    if ($[21] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            dense: true,
            children: t4
        }, void 0, false, {
            fileName: "[project]/src/components/Notifications/NotificationInvitations.tsx",
            lineNumber: 166,
            columnNumber: 10
        }, this);
        $[21] = t4;
        $[22] = t5;
    } else {
        t5 = $[22];
    }
    return t5;
}
_s(NotificationInvitations, "cZegOzYTeBZiKWywN9LTPA22qa8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$notificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotifications"]
    ];
});
_c = NotificationInvitations;
var _c;
__turbopack_context__.k.register(_c, "NotificationInvitations");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>JoinPeerReviewDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview JoinPeerReviewDialog — Dialog for joining a peer review room
 * by entering a review room code. Calls the joinPeerReview mutation and
 * navigates to the review page on success.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tabs/Tabs.js [app-client] (ecmascript) <export default as Tabs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tab/Tab.js [app-client] (ecmascript) <export default as Tab>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RateReview$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RateReview.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$be4353__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:be4353 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Notifications$2f$NotificationInvitations$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Notifications/NotificationInvitations.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function JoinPeerReviewDialog({ open, onClose, onJoin }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('components');
    const tCommon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('common');
    const [code, setCode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [tab, setTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const handleCodeChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "JoinPeerReviewDialog.useCallback[handleCodeChange]": (e)=>{
            setCode(e.target.value.trim());
            setError(null);
        }
    }["JoinPeerReviewDialog.useCallback[handleCodeChange]"], []);
    const handleJoin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "JoinPeerReviewDialog.useCallback[handleJoin]": async ()=>{
            if (!code) {
                setError(t('peerReview.joinDialog.emptyCode'));
                return;
            }
            setLoading(true);
            setError(null);
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$be4353__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["joinPeerReview"])(code);
                if (!result.success) {
                    throw new Error(result.error || 'Failed to join peer review');
                }
                onJoin({
                    roomId: result.roomId
                });
                setCode('');
                setError(null);
            } catch (err) {
                console.error('[JoinPeerReviewDialog] Error:', err);
                const message = err.message || t('peerReview.joinDialog.error');
                setError(message);
            } finally{
                setLoading(false);
            }
        }
    }["JoinPeerReviewDialog.useCallback[handleJoin]"], [
        code,
        onJoin,
        t
    ]);
    const handleKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "JoinPeerReviewDialog.useCallback[handleKeyDown]": (e_0)=>{
            if (e_0.key === 'Enter' && code && !loading) {
                handleJoin();
            }
        }
    }["JoinPeerReviewDialog.useCallback[handleKeyDown]"], [
        handleJoin,
        code,
        loading
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
        open: open,
        onClose: onClose,
        maxWidth: "xs",
        fullWidth: true,
        "aria-labelledby": "join-peer-review-dialog-title",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                id: "join-peer-review-dialog-title",
                sx: {
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RateReview$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        color: "primary"
                    }, void 0, false, {
                        fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                        lineNumber: 83,
                        columnNumber: 9
                    }, this),
                    t('peerReview.joinDialog.title')
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__["Tabs"], {
                        value: tab,
                        onChange: (_, v)=>setTab(v),
                        sx: {
                            mb: 2,
                            borderBottom: 1,
                            borderColor: 'divider'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                label: t('peerReview.joinDialog.tabCode')
                            }, void 0, false, {
                                fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                                lineNumber: 93,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tab$3e$__["Tab"], {
                                label: t('peerReview.joinDialog.tabInvitations')
                            }, void 0, false, {
                                fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                                lineNumber: 94,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                        lineNumber: 88,
                        columnNumber: 9
                    }, this),
                    tab === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                variant: "body2",
                                color: "text.secondary",
                                sx: {
                                    mb: 2
                                },
                                children: t('peerReview.joinDialog.description')
                            }, void 0, false, {
                                fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                                lineNumber: 98,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                autoFocus: true,
                                fullWidth: true,
                                label: t('peerReview.joinDialog.codeLabel'),
                                value: code,
                                onChange: handleCodeChange,
                                onKeyDown: handleKeyDown,
                                placeholder: "room-abc123",
                                disabled: loading,
                                sx: {
                                    mb: 1
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                                lineNumber: 104,
                                columnNumber: 13
                            }, this),
                            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                severity: "error",
                                sx: {
                                    mt: 1
                                },
                                children: error
                            }, void 0, false, {
                                fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                                lineNumber: 108,
                                columnNumber: 23
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                        lineNumber: 97,
                        columnNumber: 23
                    }, this),
                    tab === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Notifications$2f$NotificationInvitations$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        types: [
                            'PEER_REVIEW_INVITE'
                        ],
                        onJoin: (notification)=>{
                            if (notification.linkPath) {
                                const match = notification.linkPath.match(/\/review\/([a-zA-Z0-9-]+)/);
                                if (match) {
                                    onJoin({
                                        roomId: match[1]
                                    });
                                    onClose();
                                }
                            }
                        },
                        joinLabel: t('peerReview.joinDialog.joinButton'),
                        emptyMessage: t('peerReview.joinDialog.noInvitations')
                    }, void 0, false, {
                        fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                        lineNumber: 115,
                        columnNumber: 23
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                sx: {
                    px: 3,
                    pb: 2
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        onClick: onClose,
                        disabled: loading,
                        children: tCommon('actions.cancel')
                    }, void 0, false, {
                        fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                        lineNumber: 132,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        variant: "contained",
                        onClick: handleJoin,
                        disabled: !code || loading,
                        startIcon: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Skeleton$3e$__["Skeleton"], {
                            variant: "circular",
                            width: 16,
                            height: 16
                        }, void 0, false, {
                            fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                            lineNumber: 135,
                            columnNumber: 107
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RateReview$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                            lineNumber: 135,
                            columnNumber: 164
                        }, this),
                        children: loading ? t('peerReview.joinDialog.joining') : t('peerReview.joinDialog.joinButton')
                    }, void 0, false, {
                        fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                        lineNumber: 135,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
                lineNumber: 128,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx",
        lineNumber: 77,
        columnNumber: 10
    }, this);
}
_s(JoinPeerReviewDialog, "7B6/7Sh8iwZDJOj4a2EWRVq9ruk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = JoinPeerReviewDialog;
var _c;
__turbopack_context__.k.register(_c, "JoinPeerReviewDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx [app-client] (ecmascript) <export default as JoinPeerReviewDialog>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "JoinPeerReviewDialog",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PeerReview$2f$JoinPeerReviewDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PeerReview$2f$JoinPeerReviewDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PeerReview/JoinPeerReviewDialog.tsx [app-client] (ecmascript)");
}),
"[project]/src/components/PeerReview/RoomInvite.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RoomInvite",
    ()=>RoomInvite,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * RoomInvite — UI for inviting peers to a review room.
 *
 * @module RoomInvite
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PersonAdd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PersonAdd.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
function RoomInvite(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(29);
    if ($[0] !== "b26ca7a9a342a1a4f45c95e88722db73ec8856c9f7683bde47bc36930089cbdf") {
        for(let $i = 0; $i < 29; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b26ca7a9a342a1a4f45c95e88722db73ec8856c9f7683bde47bc36930089cbdf";
    }
    const { roomState, invitedUsers, onInvite, onRemove } = t0;
    const [username, setUsername] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let t1;
    if ($[1] !== invitedUsers || $[2] !== roomState?.invitedUserIds) {
        t1 = roomState?.invitedUserIds ?? invitedUsers ?? [];
        $[1] = invitedUsers;
        $[2] = roomState?.invitedUserIds;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const invited = t1;
    let t2;
    if ($[4] !== onInvite || $[5] !== username) {
        t2 = ({
            "RoomInvite[handleInvite]": ()=>{
                const trimmed = username.trim();
                if (!trimmed) {
                    return;
                }
                onInvite(trimmed);
                setUsername("");
            }
        })["RoomInvite[handleInvite]"];
        $[4] = onInvite;
        $[5] = username;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    const handleInvite = t2;
    let t3;
    if ($[7] !== handleInvite) {
        t3 = ({
            "RoomInvite[handleKeyDown]": (e)=>{
                if (e.key === "Enter") {
                    e.preventDefault();
                    handleInvite();
                }
            }
        })["RoomInvite[handleKeyDown]"];
        $[7] = handleInvite;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    const handleKeyDown = t3;
    let t4;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle2",
            gutterBottom: true,
            children: "Invite Peers"
        }, void 0, false, {
            fileName: "[project]/src/components/PeerReview/RoomInvite.tsx",
            lineNumber: 88,
            columnNumber: 10
        }, this);
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    let t5;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "RoomInvite[<TextField>.onChange]": (e_0)=>setUsername(e_0.target.value)
        })["RoomInvite[<TextField>.onChange]"];
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    let t6;
    if ($[11] !== handleKeyDown || $[12] !== username) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            placeholder: "Enter username or email",
            value: username,
            onChange: t5,
            onKeyDown: handleKeyDown,
            fullWidth: true
        }, void 0, false, {
            fileName: "[project]/src/components/PeerReview/RoomInvite.tsx",
            lineNumber: 104,
            columnNumber: 10
        }, this);
        $[11] = handleKeyDown;
        $[12] = username;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    let t7;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PersonAdd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/PeerReview/RoomInvite.tsx",
            lineNumber: 113,
            columnNumber: 10
        }, this);
        $[14] = t7;
    } else {
        t7 = $[14];
    }
    let t8;
    if ($[15] !== username) {
        t8 = username.trim();
        $[15] = username;
        $[16] = t8;
    } else {
        t8 = $[16];
    }
    const t9 = !t8;
    let t10;
    if ($[17] !== handleInvite || $[18] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "outlined",
            startIcon: t7,
            onClick: handleInvite,
            disabled: t9,
            children: "Invite"
        }, void 0, false, {
            fileName: "[project]/src/components/PeerReview/RoomInvite.tsx",
            lineNumber: 129,
            columnNumber: 11
        }, this);
        $[17] = handleInvite;
        $[18] = t9;
        $[19] = t10;
    } else {
        t10 = $[19];
    }
    let t11;
    if ($[20] !== t10 || $[21] !== t6) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            spacing: 1,
            mb: 2,
            children: [
                t6,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PeerReview/RoomInvite.tsx",
            lineNumber: 138,
            columnNumber: 11
        }, this);
        $[20] = t10;
        $[21] = t6;
        $[22] = t11;
    } else {
        t11 = $[22];
    }
    let t12;
    if ($[23] !== invited || $[24] !== onRemove) {
        t12 = invited.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "caption",
                    color: "text.secondary",
                    gutterBottom: true,
                    children: "Invited:"
                }, void 0, false, {
                    fileName: "[project]/src/components/PeerReview/RoomInvite.tsx",
                    lineNumber: 147,
                    columnNumber: 38
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    direction: "row",
                    spacing: 0.5,
                    flexWrap: "wrap",
                    useFlexGap: true,
                    children: invited.map({
                        "RoomInvite[invited.map()]": (userId)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                label: userId,
                                size: "small",
                                variant: "outlined",
                                onDelete: onRemove ? ()=>onRemove(userId) : undefined
                            }, userId, false, {
                                fileName: "[project]/src/components/PeerReview/RoomInvite.tsx",
                                lineNumber: 148,
                                columnNumber: 50
                            }, this)
                    }["RoomInvite[invited.map()]"])
                }, void 0, false, {
                    fileName: "[project]/src/components/PeerReview/RoomInvite.tsx",
                    lineNumber: 147,
                    columnNumber: 132
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PeerReview/RoomInvite.tsx",
            lineNumber: 147,
            columnNumber: 33
        }, this);
        $[23] = invited;
        $[24] = onRemove;
        $[25] = t12;
    } else {
        t12 = $[25];
    }
    let t13;
    if ($[26] !== t11 || $[27] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t4,
                t11,
                t12
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/PeerReview/RoomInvite.tsx",
            lineNumber: 158,
            columnNumber: 11
        }, this);
        $[26] = t11;
        $[27] = t12;
        $[28] = t13;
    } else {
        t13 = $[28];
    }
    return t13;
}
_s(RoomInvite, "oX7frOsoM286qXdKn03TWCpXkD4=");
_c = RoomInvite;
const __TURBOPACK__default__export__ = RoomInvite;
var _c;
__turbopack_context__.k.register(_c, "RoomInvite");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PeerReview/OpenPeerReviewButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OpenPeerReviewButton",
    ()=>OpenPeerReviewButton,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * OpenPeerReviewButton — Button shown after homework completion
 * that creates a HomeworkRoom and opens peer review.
 *
 * @module OpenPeerReviewButton
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RateReview$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RateReview.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PeerReview$2f$RoomInvite$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PeerReview/RoomInvite.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
function OpenPeerReviewButton({ gradeId, disabled = false, onCreateRoom, onRoomCreated }) {
    _s();
    const [dialogOpen, setDialogOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [invitedUsers, setInvitedUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [creating, setCreating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleOpen = ()=>{
        setDialogOpen(true);
        setError(null);
    };
    const handleClose = ()=>{
        if (!creating) {
            setDialogOpen(false);
            setInvitedUsers([]);
            setError(null);
        }
    };
    const handleInvite = (username)=>{
        if (!invitedUsers.includes(username)) {
            setInvitedUsers((prev)=>[
                    ...prev,
                    username
                ]);
        }
    };
    const handleRemoveInvite = (username_0)=>{
        setInvitedUsers((prev_0)=>prev_0.filter((u)=>u !== username_0));
    };
    const handleCreate = async ()=>{
        setCreating(true);
        setError(null);
        try {
            const roomId = await onCreateRoom(gradeId, invitedUsers);
            setDialogOpen(false);
            setInvitedUsers([]);
            onRoomCreated?.(roomId);
        } catch (err) {
            setError(err?.message || 'Failed to create review room');
        } finally{
            setCreating(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "outlined",
                color: "primary",
                startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RateReview$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                    lineNumber: 68,
                    columnNumber: 61
                }, this),
                onClick: handleOpen,
                disabled: disabled,
                children: "Open for Peer Review"
            }, void 0, false, {
                fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                lineNumber: 68,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                open: dialogOpen,
                onClose: handleClose,
                maxWidth: "sm",
                fullWidth: true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        children: "Open Peer Review"
                    }, void 0, false, {
                        fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "body2",
                                color: "text.secondary",
                                sx: {
                                    mb: 2
                                },
                                children: "Invite classmates to review your homework. They will be able to view your answers and provide feedback through a chat room."
                            }, void 0, false, {
                                fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                                lineNumber: 75,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PeerReview$2f$RoomInvite$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RoomInvite"], {
                                invitedUsers: invitedUsers,
                                onInvite: handleInvite,
                                onRemove: handleRemoveInvite
                            }, void 0, false, {
                                fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                                lineNumber: 82,
                                columnNumber: 11
                            }, this),
                            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                color: "error",
                                variant: "body2",
                                sx: {
                                    mt: 1
                                },
                                children: error
                            }, void 0, false, {
                                fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                                lineNumber: 84,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                onClick: handleClose,
                                disabled: creating,
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                                lineNumber: 91,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "contained",
                                onClick: handleCreate,
                                disabled: creating,
                                startIcon: creating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    variant: "circular",
                                    width: 16,
                                    height: 16
                                }, void 0, false, {
                                    fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                                    lineNumber: 94,
                                    columnNumber: 104
                                }, this) : undefined,
                                children: creating ? 'Creating...' : 'Create Room'
                            }, void 0, false, {
                                fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                                lineNumber: 94,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/PeerReview/OpenPeerReviewButton.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(OpenPeerReviewButton, "xli7fAX2F0fUFM1KcXhfUy1ZhZo=");
_c = OpenPeerReviewButton;
const __TURBOPACK__default__export__ = OpenPeerReviewButton;
var _c;
__turbopack_context__.k.register(_c, "OpenPeerReviewButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/NotificationBadge.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NotificationBadge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Badge/Badge.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$notificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/notificationContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
function NotificationBadge(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    if ($[0] !== "079f23945675d65d9c415c2e35801042c0e5064b9352b52f340c296b1f4baa6a") {
        for(let $i = 0; $i < 11; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "079f23945675d65d9c415c2e35801042c0e5064b9352b52f340c296b1f4baa6a";
    }
    let badgeProps;
    let category;
    let children;
    if ($[1] !== t0) {
        ({ category, children, ...badgeProps } = t0);
        $[1] = t0;
        $[2] = badgeProps;
        $[3] = category;
        $[4] = children;
    } else {
        badgeProps = $[2];
        category = $[3];
        children = $[4];
    }
    const count = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$notificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUnseenCount"])(category);
    if (count === 0) {
        let t1;
        if ($[5] !== children) {
            t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: children
            }, void 0, false);
            $[5] = children;
            $[6] = t1;
        } else {
            t1 = $[6];
        }
        return t1;
    }
    let t1;
    if ($[7] !== badgeProps || $[8] !== children || $[9] !== count) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            badgeContent: count,
            color: "error",
            max: 99,
            overlap: "rectangular",
            ...badgeProps,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/NotificationBadge.tsx",
            lineNumber: 60,
            columnNumber: 10
        }, this);
        $[7] = badgeProps;
        $[8] = children;
        $[9] = count;
        $[10] = t1;
    } else {
        t1 = $[10];
    }
    return t1;
}
_s(NotificationBadge, "HLbRewFDNBB8gVpxrHwJV9dzpkU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$notificationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUnseenCount"]
    ];
});
_c = NotificationBadge;
var _c;
__turbopack_context__.k.register(_c, "NotificationBadge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/AppShell.jsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AppShell
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * @module AppShell
 * @category Components
 * @description Responsive app shell with persistent inline drawer on desktop
 * and temporary (modal) drawer on mobile. Provides a unified layout for pages
 * that want sidebar navigation alongside content.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AppBar/AppBar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/useTheme.js [app-client] (ecmascript) <export default as useTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MainToolbar$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MainToolbar.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/AppShellContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
/** Direct matchMedia hook - avoids MUI useMediaQuery hydration issues */ function useMatchMedia(query) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "302210af9eaded2df98947259f42a756e33b84999e7ce086b213583b31cfceb4") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "302210af9eaded2df98947259f42a756e33b84999e7ce086b213583b31cfceb4";
    }
    let t0;
    if ($[1] !== query) {
        t0 = ({
            "useMatchMedia[useState()]": ()=>{
                if ("TURBOPACK compile-time truthy", 1) {
                    return window.matchMedia(query).matches;
                }
                //TURBOPACK unreachable
                ;
            }
        })["useMatchMedia[useState()]"];
        $[1] = query;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const [matches, setMatches] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](t0);
    let t1;
    let t2;
    if ($[3] !== query) {
        t1 = ({
            "useMatchMedia[useEffect()]": ()=>{
                const mql = window.matchMedia(query);
                setMatches(mql.matches);
                const handler = {
                    "useMatchMedia[useEffect() > handler]": (e)=>setMatches(e.matches)
                }["useMatchMedia[useEffect() > handler]"];
                mql.addEventListener("change", handler);
                return ()=>mql.removeEventListener("change", handler);
            }
        })["useMatchMedia[useEffect()]"];
        t2 = [
            query
        ];
        $[3] = query;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t1, t2);
    return matches;
}
_s(useMatchMedia, "kOFv5dbte8wS8N7DCLnxd3NmPSs=");
function AppShell(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(41);
    if ($[0] !== "302210af9eaded2df98947259f42a756e33b84999e7ce086b213583b31cfceb4") {
        for(let $i = 0; $i < 41; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "302210af9eaded2df98947259f42a756e33b84999e7ce086b213583b31cfceb4";
    }
    const { children, toolbarChildren } = t0;
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"])();
    const isDesktop = useMatchMedia(`(min-width:${theme.breakpoints.values.md}px)`);
    let t1;
    if ($[1] !== theme.breakpoints.values.md) {
        t1 = ({
            "AppShell[useState()]": ()=>{
                if ("TURBOPACK compile-time truthy", 1) {
                    return window.matchMedia(`(min-width:${theme.breakpoints.values.md}px)`).matches;
                }
                //TURBOPACK unreachable
                ;
            }
        })["AppShell[useState()]"];
        $[1] = theme.breakpoints.values.md;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [drawerOpen, setDrawerOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](t1);
    const [toolbarContent, setToolbarContent] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const appBarRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const toolbarPortalRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const toolbarChildrenPortalRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [appBarHeight, setAppBarHeight] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](48);
    let t2;
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "AppShell[useEffect()]": ()=>{
                if (!appBarRef.current) {
                    return;
                }
                const observer = new ResizeObserver((entries)=>{
                    for (const entry of entries){
                        const height = entry.borderBoxSize?.[0]?.blockSize ?? entry.contentRect.height;
                        if (height > 0) {
                            setAppBarHeight(height);
                        }
                    }
                });
                observer.observe(appBarRef.current);
                return ()=>observer.disconnect();
            }
        })["AppShell[useEffect()]"];
        t3 = [];
        $[3] = t2;
        $[4] = t3;
    } else {
        t2 = $[3];
        t3 = $[4];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t2, t3);
    let t4;
    let t5;
    if ($[5] !== isDesktop) {
        t4 = ({
            "AppShell[useEffect()]": ()=>{
                if (isDesktop) {
                    setDrawerOpen(true);
                } else {
                    setDrawerOpen(false);
                }
            }
        })["AppShell[useEffect()]"];
        t5 = [
            isDesktop
        ];
        $[5] = isDesktop;
        $[6] = t4;
        $[7] = t5;
    } else {
        t4 = $[6];
        t5 = $[7];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t4, t5);
    let t6;
    if ($[8] !== appBarHeight || $[9] !== drawerOpen || $[10] !== isDesktop || $[11] !== toolbarContent) {
        t6 = {
            drawerOpen,
            setDrawerOpen,
            isDesktop,
            drawerWidth: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAWER_WIDTH"],
            toolbarContent,
            setToolbarContent,
            appBarHeight,
            toolbarPortalRef,
            toolbarChildrenPortalRef
        };
        $[8] = appBarHeight;
        $[9] = drawerOpen;
        $[10] = isDesktop;
        $[11] = toolbarContent;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    const contextValue = t6;
    let t7;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            backgroundColor: "custom.glassNavbar",
            backdropFilter: "blur(8px)",
            zIndex: _temp
        };
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[14] !== toolbarChildren) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MainToolbar$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: toolbarChildren
        }, void 0, false, {
            fileName: "[project]/src/components/AppShell.jsx",
            lineNumber: 195,
            columnNumber: 10
        }, this);
        $[14] = toolbarChildren;
        $[15] = t8;
    } else {
        t8 = $[15];
    }
    let t9;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: toolbarPortalRef
        }, void 0, false, {
            fileName: "[project]/src/components/AppShell.jsx",
            lineNumber: 203,
            columnNumber: 10
        }, this);
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    let t10;
    if ($[17] !== t8 || $[18] !== toolbarContent) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ref: appBarRef,
            position: "fixed",
            color: "default",
            sx: t7,
            children: [
                t8,
                toolbarContent,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AppShell.jsx",
            lineNumber: 210,
            columnNumber: 11
        }, this);
        $[17] = t8;
        $[18] = toolbarContent;
        $[19] = t10;
    } else {
        t10 = $[19];
    }
    const t11 = `${appBarHeight}px`;
    let t12;
    if ($[20] !== t11) {
        t12 = {
            display: "flex",
            marginTop: t11
        };
        $[20] = t11;
        $[21] = t12;
    } else {
        t12 = $[21];
    }
    let t13;
    if ($[22] !== theme.transitions) {
        t13 = theme.transitions.create([
            "margin",
            "width"
        ], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        });
        $[22] = theme.transitions;
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    let t14;
    if ($[24] !== drawerOpen || $[25] !== isDesktop || $[26] !== theme.transitions) {
        t14 = isDesktop && drawerOpen && {
            marginLeft: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAWER_WIDTH"]}px`,
            width: `calc(100% - ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAWER_WIDTH"]}px)`,
            transition: theme.transitions.create([
                "margin",
                "width"
            ], {
                easing: theme.transitions.easing.easeOut,
                duration: theme.transitions.duration.enteringScreen
            })
        };
        $[24] = drawerOpen;
        $[25] = isDesktop;
        $[26] = theme.transitions;
        $[27] = t14;
    } else {
        t14 = $[27];
    }
    let t15;
    if ($[28] !== t13 || $[29] !== t14) {
        t15 = {
            flexGrow: 1,
            transition: t13,
            ...t14
        };
        $[28] = t13;
        $[29] = t14;
        $[30] = t15;
    } else {
        t15 = $[30];
    }
    let t16;
    if ($[31] !== children || $[32] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            component: "main",
            sx: t15,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/AppShell.jsx",
            lineNumber: 272,
            columnNumber: 11
        }, this);
        $[31] = children;
        $[32] = t15;
        $[33] = t16;
    } else {
        t16 = $[33];
    }
    let t17;
    if ($[34] !== t12 || $[35] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t12,
            children: t16
        }, void 0, false, {
            fileName: "[project]/src/components/AppShell.jsx",
            lineNumber: 281,
            columnNumber: 11
        }, this);
        $[34] = t12;
        $[35] = t16;
        $[36] = t17;
    } else {
        t17 = $[36];
    }
    let t18;
    if ($[37] !== contextValue || $[38] !== t10 || $[39] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AppShellContext"].Provider, {
            value: contextValue,
            children: [
                t10,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AppShell.jsx",
            lineNumber: 290,
            columnNumber: 11
        }, this);
        $[37] = contextValue;
        $[38] = t10;
        $[39] = t17;
        $[40] = t18;
    } else {
        t18 = $[40];
    }
    return t18;
}
_s1(AppShell, "HMJ7kjy0blc96Q31Ie5uhnWGgi8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"],
        useMatchMedia
    ];
});
_c = AppShell;
function _temp(theme_0) {
    return theme_0.zIndex.modal + 2;
}
var _c;
__turbopack_context__.k.register(_c, "AppShell");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/DynamicThemeProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DynamicThemeProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ThemeProvider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/ThemeProvider.js [app-client] (ecmascript) <export default as ThemeProvider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createTheme$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/createTheme.js [app-client] (ecmascript) <export default as createTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/settingsContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$themes$2f$editorThemes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/themes/editorThemes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ThemeMixer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/ThemeMixer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function DynamicThemeProvider({ children }) {
    _s();
    const { settings } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$settingsContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const profileThemeId = settings?.profileThemeId || 'default';
    const theme = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "DynamicThemeProvider.useMemo[theme]": ()=>{
            let options;
            if (profileThemeId === 'custom' && settings?.customThemePalette) {
                const customInput = typeof settings.customThemePalette === 'string' ? JSON.parse(settings.customThemePalette) : settings.customThemePalette;
                const palette = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$ThemeMixer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildFullPaletteFromCustom"])(customInput);
                options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$themes$2f$editorThemes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCustomThemeOptions"])(palette);
            } else {
                options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$themes$2f$editorThemes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getThemeOptions"])(profileThemeId);
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createTheme$3e$__["createTheme"])({
                ...options,
                components: {
                    MuiAccordionSummary: {
                        defaultProps: {
                            slotProps: {
                                content: {
                                    component: 'div'
                                }
                            }
                        }
                    }
                }
            });
        }
    }["DynamicThemeProvider.useMemo[theme]"], [
        profileThemeId,
        settings?.customThemePalette
    ]);
    // Also sync the theme choice to a cookie so SSR can pick it up
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "DynamicThemeProvider.useEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            document.cookie = `profile-theme=${profileThemeId};path=/;max-age=31536000;SameSite=Lax`;
        }
    }["DynamicThemeProvider.useEffect"], [
        profileThemeId
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ThemeProvider$3e$__["ThemeProvider"], {
        theme: theme,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/DynamicThemeProvider.tsx",
        lineNumber: 59,
        columnNumber: 10
    }, this);
}
_s(DynamicThemeProvider, "w1ENZpr1KSMrfW9ZV06pe20bLeE=");
_c = DynamicThemeProvider;
var _c;
__turbopack_context__.k.register(_c, "DynamicThemeProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/GlobalChatButton.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GlobalChatButton",
    ()=>GlobalChatButton,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * GlobalChatButton - Floating Action Button to open global chat
 * 
 * A fixed-position FAB that appears on all pages (except editor which has its own chat).
 * Clicking it opens the GlobalChatDrawer.
 * 
 * @see docs/GLOBAL_CHAT_INTEGRATION_PLAN.md
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Fab$2f$Fab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Fab$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Fab/Fab.js [app-client] (ecmascript) <export default as Fab>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Badge/Badge.js [app-client] (ecmascript) <export default as Badge>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Zoom$2f$Zoom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zoom$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Zoom/Zoom.js [app-client] (ecmascript) <export default as Zoom>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Chat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Chat.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/chatContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
function GlobalChatButton(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23);
    if ($[0] !== "9eabe19a25b2e5e895173ad7969ce2c6963e7432baa429750c9716f3edb65c6f") {
        for(let $i = 0; $i < 23; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9eabe19a25b2e5e895173ad7969ce2c6963e7432baa429750c9716f3edb65c6f";
    }
    const { show: t1, unreadCount: t2 } = t0;
    const show = t1 === undefined ? true : t1;
    const unreadCount = t2 === undefined ? 0 : t2;
    let t3;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            bindI18nStore: ""
        };
        $[1] = t3;
    } else {
        t3 = $[1];
    }
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("common", t3);
    const { isChatOpen, setIsChatOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t4;
    if ($[2] !== setIsChatOpen) {
        t4 = ({
            "GlobalChatButton[handleClick]": ()=>{
                console.log("[GlobalChatButton] Opening chat");
                setIsChatOpen(true);
            }
        })["GlobalChatButton[handleClick]"];
        $[2] = setIsChatOpen;
        $[3] = t4;
    } else {
        t4 = $[3];
    }
    const handleClick = t4;
    if (!show || isChatOpen) {
        return null;
    }
    let t5;
    if ($[4] !== t) {
        t5 = t("chat.openAssistant");
        $[4] = t;
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    let t6;
    if ($[6] !== t) {
        t6 = t("chat.openAssistant");
        $[6] = t;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            position: "fixed",
            bottom: 24,
            right: 24,
            zIndex: _temp,
            boxShadow: _temp2,
            "&:hover": {
                boxShadow: _temp3
            }
        };
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    const t8 = unreadCount === 0;
    let t9;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Chat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/GlobalChatButton.jsx",
            lineNumber: 105,
            columnNumber: 10
        }, this);
        $[9] = t9;
    } else {
        t9 = $[9];
    }
    let t10;
    if ($[10] !== t8 || $[11] !== unreadCount) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__["Badge"], {
            badgeContent: unreadCount,
            color: "error",
            max: 99,
            invisible: t8,
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/components/GlobalChatButton.jsx",
            lineNumber: 112,
            columnNumber: 11
        }, this);
        $[10] = t8;
        $[11] = unreadCount;
        $[12] = t10;
    } else {
        t10 = $[12];
    }
    let t11;
    if ($[13] !== handleClick || $[14] !== t10 || $[15] !== t6) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Fab$2f$Fab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Fab$3e$__["Fab"], {
            color: "primary",
            "aria-label": t6,
            onClick: handleClick,
            sx: t7,
            "data-testid": "global-chat-button",
            "data-tour": "chat-button",
            children: t10
        }, void 0, false, {
            fileName: "[project]/src/components/GlobalChatButton.jsx",
            lineNumber: 121,
            columnNumber: 11
        }, this);
        $[13] = handleClick;
        $[14] = t10;
        $[15] = t6;
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    let t12;
    if ($[17] !== t11 || $[18] !== t5) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: t5,
            placement: "left",
            arrow: true,
            children: t11
        }, void 0, false, {
            fileName: "[project]/src/components/GlobalChatButton.jsx",
            lineNumber: 131,
            columnNumber: 11
        }, this);
        $[17] = t11;
        $[18] = t5;
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    let t13;
    if ($[20] !== show || $[21] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Zoom$2f$Zoom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zoom$3e$__["Zoom"], {
            in: show,
            children: t12
        }, void 0, false, {
            fileName: "[project]/src/components/GlobalChatButton.jsx",
            lineNumber: 140,
            columnNumber: 11
        }, this);
        $[20] = show;
        $[21] = t12;
        $[22] = t13;
    } else {
        t13 = $[22];
    }
    return t13;
}
_s(GlobalChatButton, "yUkUl9Py/K1bfb5XzQATxVnqnos=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = GlobalChatButton;
function _temp3(theme_1) {
    return theme_1.shadows[12];
}
function _temp2(theme_0) {
    return theme_0.shadows[8];
}
function _temp(theme) {
    return theme.zIndex.speedDial;
}
const __TURBOPACK__default__export__ = GlobalChatButton;
var _c;
__turbopack_context__.k.register(_c, "GlobalChatButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ShowDeletedToggle.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ShowDeletedToggle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Switch/Switch.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function ShowDeletedToggle(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "995b5ab496210a0be8ba1e4d000d47c588ec111cf2a44a9eb8658ee7e62ddd62") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "995b5ab496210a0be8ba1e4d000d47c588ec111cf2a44a9eb8658ee7e62ddd62";
    }
    const { showDeleted, setShowDeleted } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    let t1;
    if ($[1] !== setShowDeleted) {
        t1 = ({
            "ShowDeletedToggle[<Switch>.onChange]": (e)=>setShowDeleted(e.target.checked)
        })["ShowDeletedToggle[<Switch>.onChange]"];
        $[1] = setShowDeleted;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== showDeleted || $[4] !== t1) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            checked: showDeleted,
            onChange: t1
        }, void 0, false, {
            fileName: "[project]/src/components/ShowDeletedToggle.jsx",
            lineNumber: 36,
            columnNumber: 10
        }, this);
        $[3] = showDeleted;
        $[4] = t1;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    let t3;
    if ($[6] !== t) {
        t3 = t("showDeletedItems", "Show deleted items");
        $[6] = t;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    let t4;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            ml: 1
        };
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    if ($[9] !== t2 || $[10] !== t3) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            control: t2,
            label: t3,
            sx: t4
        }, void 0, false, {
            fileName: "[project]/src/components/ShowDeletedToggle.jsx",
            lineNumber: 62,
            columnNumber: 10
        }, this);
        $[9] = t2;
        $[10] = t3;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    return t5;
}
_s(ShowDeletedToggle, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = ShowDeletedToggle;
var _c;
__turbopack_context__.k.register(_c, "ShowDeletedToggle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/importReviewReducer.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * importReviewReducer — Shared reducer for VocabularyReview2 and QuestionsReview2.
 *
 * Manages the import state machine (idle → importing → complete/error)
 * and data loading state (loading → loaded).
 */ // ============================================================================
// Types
// ============================================================================
__turbopack_context__.s([
    "createInitialImportReviewState",
    ()=>createInitialImportReviewState,
    "importReviewReducer",
    ()=>importReviewReducer
]);
function createInitialImportReviewState() {
    return {
        parsedContent: null,
        document: null,
        items: [],
        summaries: [],
        objectives: [],
        loading: true,
        importStatus: "idle",
        importProgress: null,
        importResult: null,
        selectedItems: new Set(),
        expandedItems: new Set(),
        showSummaries: false
    };
}
function importReviewReducer(state, action) {
    switch(action.type){
        case "LOAD_START":
            return {
                ...state,
                loading: true
            };
        case "LOAD_SUCCESS":
            {
                const selectedItems = action.autoSelectAll ? new Set(action.items.map((_, i)=>i)) : state.selectedItems;
                return {
                    ...state,
                    loading: false,
                    parsedContent: action.parsedContent,
                    document: action.document,
                    items: action.items,
                    summaries: action.summaries,
                    objectives: action.objectives,
                    selectedItems
                };
            }
        case "LOAD_ERROR":
            return {
                ...state,
                loading: false
            };
        case "IMPORT_START":
            return {
                ...state,
                importStatus: "importing",
                importProgress: null,
                importResult: null
            };
        case "IMPORT_PROGRESS":
            return {
                ...state,
                importProgress: action.progress
            };
        case "IMPORT_SUCCESS":
            return {
                ...state,
                importStatus: "complete",
                importProgress: null,
                importResult: action.result
            };
        case "IMPORT_ERROR":
            return {
                ...state,
                importStatus: "error",
                importProgress: null,
                importResult: action.result
            };
        case "CLEAR_IMPORT_RESULT":
            return {
                ...state,
                importResult: null,
                importStatus: "idle"
            };
        case "TOGGLE_SELECT":
            {
                const next = new Set(state.selectedItems);
                if (next.has(action.index)) {
                    next.delete(action.index);
                } else {
                    next.add(action.index);
                }
                return {
                    ...state,
                    selectedItems: next
                };
            }
        case "SELECT_ALL":
            return {
                ...state,
                selectedItems: new Set(Array.from({
                    length: action.count
                }, (_, i)=>i))
            };
        case "DESELECT_ALL":
            return {
                ...state,
                selectedItems: new Set()
            };
        case "TOGGLE_EXPAND":
            {
                const next = new Set(state.expandedItems);
                if (next.has(action.index)) {
                    next.delete(action.index);
                } else {
                    next.add(action.index);
                }
                return {
                    ...state,
                    expandedItems: next
                };
            }
        case "TOGGLE_SUMMARIES":
            return {
                ...state,
                showSummaries: !state.showSummaries
            };
        case "UPDATE_ITEM":
            return {
                ...state,
                items: state.items.map((item, i)=>i === action.index ? action.item : item)
            };
        default:
            return state;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/VocabularyReview2.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VocabularyCard",
    ()=>VocabularyCard,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * VocabularyReview2 Component
 * 
 * Enhanced vocabulary review panel with:
 * - Lexical-powered inline editing with unified undo/redo
 * - Virtual scrolling for large lists (TanStack Virtual)
 * - Search term highlighting
 * - Auto-save with debouncing
 * - Polished card design with badges and shadows
 * - Better expand/collapse affordances
 * - Import state indicators
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript) <export default as Paper>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Collapse/Collapse.js [app-client] (ecmascript) <export default as Collapse>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Download.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandMore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandLess.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LibraryBooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/LibraryBooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Info.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Mic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Mic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vocabularyImportUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/vocabularyImportUtils.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
// Lexical imports
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposer.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalPlainTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalPlainTextPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalContentEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHistoryPlugin.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalOnChangePlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalErrorBoundary.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$mark$2f$LexicalMark$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/mark/LexicalMark.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$SearchHighlightPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/SearchHighlightPlugin.jsx [app-client] (ecmascript)");
// Virtual scrolling
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-virtual/dist/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$importReviewReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/importReviewReducer.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function NestedVocabField(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(46);
    if ($[0] !== "191151d27b9f6501b1531e0c50db38348d751387d98235d637bc7dd906dfb1e8") {
        for(let $i = 0; $i < 46; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "191151d27b9f6501b1531e0c50db38348d751387d98235d637bc7dd906dfb1e8";
    }
    const { value, field, itemIndex, onSave, searchTerm: t1, label: t2, placeholder: t3, multiline: t4 } = t0;
    const searchTerm = t1 === undefined ? "" : t1;
    const label = t2 === undefined ? "" : t2;
    const placeholder = t3 === undefined ? "" : t3;
    const multiline = t4 === undefined ? false : t4;
    const saveTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const t5 = `VocabField-${field}-${itemIndex}`;
    let t6;
    let t7;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$mark$2f$LexicalMark$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MarkNode"]
        ];
        t7 = {
            mark: "search-highlight"
        };
        $[1] = t6;
        $[2] = t7;
    } else {
        t6 = $[1];
        t7 = $[2];
    }
    let t8;
    if ($[3] !== value) {
        t8 = ()=>{
            const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
            root.clear();
            const paragraph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])();
            const text = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(value || "");
            paragraph.append(text);
            root.append(paragraph);
        };
        $[3] = value;
        $[4] = t8;
    } else {
        t8 = $[4];
    }
    let t9;
    if ($[5] !== t5 || $[6] !== t8) {
        t9 = {
            namespace: t5,
            nodes: t6,
            theme: t7,
            onError: _temp,
            editorState: t8
        };
        $[5] = t5;
        $[6] = t8;
        $[7] = t9;
    } else {
        t9 = $[7];
    }
    const initialConfig = t9;
    let t10;
    if ($[8] !== field || $[9] !== itemIndex || $[10] !== onSave || $[11] !== value) {
        t10 = ({
            "NestedVocabField[handleChange]": (editorState)=>{
                editorState.read({
                    "NestedVocabField[handleChange > editorState.read()]": ()=>{
                        const text_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().getTextContent();
                        if (saveTimeoutRef.current) {
                            clearTimeout(saveTimeoutRef.current);
                        }
                        saveTimeoutRef.current = setTimeout({
                            "NestedVocabField[handleChange > editorState.read() > setTimeout()]": async ()=>{
                                if (text_0 !== value) {
                                    await onSave(itemIndex, field, text_0);
                                }
                            }
                        }["NestedVocabField[handleChange > editorState.read() > setTimeout()]"], 1000);
                    }
                }["NestedVocabField[handleChange > editorState.read()]"]);
            }
        })["NestedVocabField[handleChange]"];
        $[8] = field;
        $[9] = itemIndex;
        $[10] = onSave;
        $[11] = value;
        $[12] = t10;
    } else {
        t10 = $[12];
    }
    const handleChange = t10;
    const t11 = multiline ? 1.5 : 0.5;
    let t12;
    if ($[13] !== t11) {
        t12 = {
            mb: t11,
            width: "100%"
        };
        $[13] = t11;
        $[14] = t12;
    } else {
        t12 = $[14];
    }
    let t13;
    if ($[15] !== label) {
        t13 = label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            sx: {
                display: "block",
                mb: 0.25,
                fontWeight: 500
            },
            children: label
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 187,
            columnNumber: 20
        }, this);
        $[15] = label;
        $[16] = t13;
    } else {
        t13 = $[16];
    }
    let t14;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = {
            position: "relative"
        };
        $[17] = t14;
    } else {
        t14 = $[17];
    }
    const t15 = multiline ? "60px" : "24px";
    const t16 = multiline ? "8px" : "4px 8px";
    const t17 = field === "word" ? "1.1rem" : "0.875rem";
    const t18 = field === "word" ? 600 : 400;
    const t19 = multiline ? "vertical" : "none";
    let t20;
    if ($[18] !== t15 || $[19] !== t16 || $[20] !== t17 || $[21] !== t18 || $[22] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentEditable"], {
            contentEditable: true,
            style: {
                minHeight: t15,
                padding: t16,
                border: "1px solid rgba(0, 0, 0, 0.12)",
                borderRadius: "4px",
                fontSize: t17,
                fontFamily: "inherit",
                fontWeight: t18,
                outline: "none",
                resize: t19,
                backgroundColor: "background.paper",
                cursor: "text",
                overflow: "hidden",
                overflowWrap: "break-word",
                wordBreak: "break-word"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 213,
            columnNumber: 11
        }, this);
        $[18] = t15;
        $[19] = t16;
        $[20] = t17;
        $[21] = t18;
        $[22] = t19;
        $[23] = t20;
    } else {
        t20 = $[23];
    }
    let t21;
    if ($[24] !== multiline || $[25] !== placeholder) {
        t21 = placeholder ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                position: "absolute",
                top: multiline ? "8px" : "4px",
                left: "8px",
                color: "rgba(0, 0, 0, 0.38)",
                pointerEvents: "none",
                fontSize: "0.875rem"
            },
            children: placeholder
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 240,
            columnNumber: 25
        }, this) : null;
        $[24] = multiline;
        $[25] = placeholder;
        $[26] = t21;
    } else {
        t21 = $[26];
    }
    let t22;
    if ($[27] !== t20 || $[28] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalPlainTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlainTextPlugin"], {
            ErrorBoundary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalErrorBoundary"],
            contentEditable: t20,
            placeholder: t21
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 256,
            columnNumber: 11
        }, this);
        $[27] = t20;
        $[28] = t21;
        $[29] = t22;
    } else {
        t22 = $[29];
    }
    let t23;
    if ($[30] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HistoryPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 265,
            columnNumber: 11
        }, this);
        $[30] = t23;
    } else {
        t23 = $[30];
    }
    let t24;
    if ($[31] !== handleChange) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OnChangePlugin"], {
            onChange: handleChange
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 272,
            columnNumber: 11
        }, this);
        $[31] = handleChange;
        $[32] = t24;
    } else {
        t24 = $[32];
    }
    let t25;
    if ($[33] !== searchTerm) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$SearchHighlightPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            searchTerm: searchTerm
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 280,
            columnNumber: 11
        }, this);
        $[33] = searchTerm;
        $[34] = t25;
    } else {
        t25 = $[34];
    }
    let t26;
    if ($[35] !== t22 || $[36] !== t24 || $[37] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t14,
            children: [
                t22,
                t23,
                t24,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 288,
            columnNumber: 11
        }, this);
        $[35] = t22;
        $[36] = t24;
        $[37] = t25;
        $[38] = t26;
    } else {
        t26 = $[38];
    }
    let t27;
    if ($[39] !== initialConfig || $[40] !== t26) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalComposer"], {
            initialConfig: initialConfig,
            children: t26
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 298,
            columnNumber: 11
        }, this);
        $[39] = initialConfig;
        $[40] = t26;
        $[41] = t27;
    } else {
        t27 = $[41];
    }
    let t28;
    if ($[42] !== t12 || $[43] !== t13 || $[44] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t12,
            children: [
                t13,
                t27
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 307,
            columnNumber: 11
        }, this);
        $[42] = t12;
        $[43] = t13;
        $[44] = t27;
        $[45] = t28;
    } else {
        t28 = $[45];
    }
    return t28;
}
_s(NestedVocabField, "nqB4vf/Orw8Sp7yzfGj49tAYSPk=");
_c = NestedVocabField;
// =============================================================================
// VocabularyCard - Individual vocabulary item with Lexical editing
// =============================================================================
function _temp(error) {
    return console.error("Lexical error:", error);
}
function VocabularyCard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(76);
    if ($[0] !== "191151d27b9f6501b1531e0c50db38348d751387d98235d637bc7dd906dfb1e8") {
        for(let $i = 0; $i < 76; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "191151d27b9f6501b1531e0c50db38348d751387d98235d637bc7dd906dfb1e8";
    }
    const { item, index, isSelected, isExpanded, alreadyImported, searchTerm: t1, onToggleSelect, onToggleExpand, onUpdate, onOpenRubyEditor, onOpenAudioStudio } = t0;
    const searchTerm = t1 === undefined ? "" : t1;
    const isEvenRow = index % 2 === 0;
    const t2 = isEvenRow ? "background.paper" : "action.hover";
    const t3 = isEvenRow ? "action.selected" : "action.focus";
    let t4;
    if ($[1] !== t3) {
        t4 = {
            backgroundColor: t3,
            boxShadow: 1
        };
        $[1] = t3;
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    let t5;
    if ($[3] !== t2 || $[4] !== t4) {
        t5 = {
            backgroundColor: t2,
            flexDirection: "column",
            alignItems: "stretch",
            padding: 0,
            margin: 0,
            borderBottom: "1px solid",
            borderColor: "divider",
            overflow: "hidden",
            transition: "box-shadow 0.2s ease",
            "&:hover": t4
        };
        $[3] = t2;
        $[4] = t4;
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    let t6;
    if ($[6] !== index || $[7] !== isExpanded || $[8] !== onToggleExpand) {
        t6 = ({
            "VocabularyCard[<Box>.onClick]": (e)=>{
                if (e.target.closest(".MuiCheckbox-root")) {
                    return;
                }
                if (!isExpanded) {
                    onToggleExpand(index);
                }
            }
        })["VocabularyCard[<Box>.onClick]"];
        $[6] = index;
        $[7] = isExpanded;
        $[8] = onToggleExpand;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    const t7 = isExpanded ? "1px solid" : "none";
    const t8 = isExpanded ? "default" : "pointer";
    let t9;
    if ($[10] !== t7 || $[11] !== t8) {
        t9 = {
            display: "flex",
            alignItems: "center",
            gap: 1,
            justifyContent: "space-between",
            padding: 1,
            borderBottom: t7,
            borderColor: "divider",
            cursor: t8
        };
        $[10] = t7;
        $[11] = t8;
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    let t10;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            display: "flex",
            gap: 0.5,
            alignItems: "center",
            flex: 1,
            minWidth: 0,
            overflow: "hidden"
        };
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] !== alreadyImported || $[15] !== index || $[16] !== isSelected || $[17] !== onToggleSelect) {
        t11 = !alreadyImported && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
            size: "small",
            checked: isSelected,
            onChange: {
                "VocabularyCard[<Checkbox>.onChange]": ()=>onToggleSelect(index)
            }["VocabularyCard[<Checkbox>.onChange]"],
            sx: {
                p: 0.5
            },
            className: "MuiCheckbox-root"
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 449,
            columnNumber: 31
        }, this);
        $[14] = alreadyImported;
        $[15] = index;
        $[16] = isSelected;
        $[17] = onToggleSelect;
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] !== index || $[20] !== onToggleExpand) {
        t12 = ({
            "VocabularyCard[<IconButton>.onClick]": (e_0)=>{
                e_0.stopPropagation();
                onToggleExpand(index);
            }
        })["VocabularyCard[<IconButton>.onClick]"];
        $[19] = index;
        $[20] = onToggleExpand;
        $[21] = t12;
    } else {
        t12 = $[21];
    }
    let t13;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            p: 0.5
        };
        $[22] = t13;
    } else {
        t13 = $[22];
    }
    let t14;
    if ($[23] !== isExpanded) {
        t14 = isExpanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 487,
            columnNumber: 24
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 487,
            columnNumber: 62
        }, this);
        $[23] = isExpanded;
        $[24] = t14;
    } else {
        t14 = $[24];
    }
    let t15;
    if ($[25] !== t12 || $[26] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            size: "small",
            onClick: t12,
            sx: t13,
            children: t14
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 495,
            columnNumber: 11
        }, this);
        $[25] = t12;
        $[26] = t14;
        $[27] = t15;
    } else {
        t15 = $[27];
    }
    let t16;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            flex: 1,
            minWidth: 0
        };
        $[28] = t16;
    } else {
        t16 = $[28];
    }
    let t17;
    if ($[29] !== index || $[30] !== isExpanded || $[31] !== item.definition || $[32] !== item.word || $[33] !== onUpdate || $[34] !== searchTerm) {
        t17 = !isExpanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                display: "flex",
                alignItems: "center",
                gap: 1,
                flexWrap: "wrap",
                minWidth: 0
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    onClick: _VocabularyCardBoxOnClick,
                    sx: {
                        fontWeight: 600,
                        fontSize: "0.875rem",
                        minWidth: 0,
                        maxWidth: "200px",
                        flex: "0 1 auto"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedVocabField, {
                        value: item.word || "",
                        field: "word",
                        itemIndex: index,
                        onSave: onUpdate,
                        searchTerm: searchTerm
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 526,
                        columnNumber: 10
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 520,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    onClick: _VocabularyCardBoxOnClick2,
                    sx: {
                        fontSize: "0.875rem",
                        flex: 1,
                        minWidth: 0,
                        overflow: "hidden",
                        display: {
                            xs: "none",
                            sm: "block"
                        }
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedVocabField, {
                        value: item.definition || "",
                        field: "definition",
                        itemIndex: index,
                        onSave: onUpdate,
                        searchTerm: searchTerm
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 535,
                        columnNumber: 10
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 526,
                    columnNumber: 133
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 514,
            columnNumber: 25
        }, this) : null;
        $[29] = index;
        $[30] = isExpanded;
        $[31] = item.definition;
        $[32] = item.word;
        $[33] = onUpdate;
        $[34] = searchTerm;
        $[35] = t17;
    } else {
        t17 = $[35];
    }
    let t18;
    if ($[36] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t16,
            children: t17
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 548,
            columnNumber: 11
        }, this);
        $[36] = t17;
        $[37] = t18;
    } else {
        t18 = $[37];
    }
    let t19;
    if ($[38] !== t11 || $[39] !== t15 || $[40] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t10,
            children: [
                t11,
                t15,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 556,
            columnNumber: 11
        }, this);
        $[38] = t11;
        $[39] = t15;
        $[40] = t18;
        $[41] = t19;
    } else {
        t19 = $[41];
    }
    let t20;
    if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = {
            display: "flex",
            gap: 0.5,
            alignItems: "center",
            flexShrink: 0
        };
        $[42] = t20;
    } else {
        t20 = $[42];
    }
    let t21;
    if ($[43] !== item.filename) {
        t21 = item.filename && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: `Source: ${item.filename}`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                label: item.filename.length > 20 ? `${item.filename.slice(0, 17)}...` : item.filename,
                size: "small",
                variant: "outlined",
                color: "primary",
                sx: {
                    fontSize: "0.65rem",
                    height: "20px",
                    maxWidth: "150px"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/VocabularyReview2.tsx",
                lineNumber: 578,
                columnNumber: 72
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 578,
            columnNumber: 28
        }, this);
        $[43] = item.filename;
        $[44] = t21;
    } else {
        t21 = $[44];
    }
    let t22;
    if ($[45] !== item.page) {
        t22 = item.page && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            label: `p.${item.page}`,
            size: "small",
            variant: "outlined",
            sx: {
                fontSize: "0.7rem",
                height: "20px"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 590,
            columnNumber: 24
        }, this);
        $[45] = item.page;
        $[46] = t22;
    } else {
        t22 = $[46];
    }
    let t23;
    if ($[47] !== item.phonetic || $[48] !== onOpenRubyEditor) {
        t23 = item.phonetic && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: onOpenRubyEditor ? "Open ruby tag editor" : "Has phonetic notation",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                component: "span",
                display: "inline-block",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LibraryBooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        fontSize: "small"
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 601,
                        columnNumber: 170
                    }, this),
                    label: item.phonetic,
                    size: "small",
                    variant: "outlined",
                    onClick: onOpenRubyEditor ? (e_3)=>{
                        e_3.stopPropagation();
                        onOpenRubyEditor();
                    } : undefined,
                    sx: {
                        fontSize: "0.65rem",
                        height: "20px",
                        maxWidth: "200px",
                        cursor: onOpenRubyEditor ? "pointer" : "default",
                        "&:hover": onOpenRubyEditor ? {
                            backgroundColor: "action.hover"
                        } : undefined
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 601,
                    columnNumber: 158
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/VocabularyReview2.tsx",
                lineNumber: 601,
                columnNumber: 113
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 601,
            columnNumber: 28
        }, this);
        $[47] = item.phonetic;
        $[48] = onOpenRubyEditor;
        $[49] = t23;
    } else {
        t23 = $[49];
    }
    let t24;
    if ($[50] !== item.audio || $[51] !== onOpenAudioStudio) {
        t24 = item.audio && item.audio.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: onOpenAudioStudio ? "Open audio studio" : `${item.audio.length} audio file(s)`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                component: "span",
                display: "inline-block",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Mic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        fontSize: "small"
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 621,
                        columnNumber: 203
                    }, this),
                    label: item.audio.length,
                    size: "small",
                    variant: "outlined",
                    color: "secondary",
                    "data-tour": "play-audio",
                    onClick: onOpenAudioStudio ? (e_4)=>{
                        e_4.stopPropagation();
                        onOpenAudioStudio();
                    } : undefined,
                    sx: {
                        fontSize: "0.65rem",
                        height: "20px",
                        cursor: onOpenAudioStudio ? "pointer" : "default",
                        "&:hover": onOpenAudioStudio ? {
                            backgroundColor: "action.hover"
                        } : undefined
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 621,
                    columnNumber: 191
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/VocabularyReview2.tsx",
                lineNumber: 621,
                columnNumber: 146
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 621,
            columnNumber: 50
        }, this);
        $[50] = item.audio;
        $[51] = onOpenAudioStudio;
        $[52] = t24;
    } else {
        t24 = $[52];
    }
    let t25;
    if ($[53] !== t21 || $[54] !== t22 || $[55] !== t23 || $[56] !== t24) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t20,
            children: [
                t21,
                t22,
                t23,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 640,
            columnNumber: 11
        }, this);
        $[53] = t21;
        $[54] = t22;
        $[55] = t23;
        $[56] = t24;
        $[57] = t25;
    } else {
        t25 = $[57];
    }
    let t26;
    if ($[58] !== t19 || $[59] !== t25 || $[60] !== t6 || $[61] !== t9) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            onClick: t6,
            sx: t9,
            children: [
                t19,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 651,
            columnNumber: 11
        }, this);
        $[58] = t19;
        $[59] = t25;
        $[60] = t6;
        $[61] = t9;
        $[62] = t26;
    } else {
        t26 = $[62];
    }
    let t27;
    if ($[63] !== index || $[64] !== isExpanded || $[65] !== item.context || $[66] !== item.definition || $[67] !== item.phonetic || $[68] !== item.word || $[69] !== onUpdate || $[70] !== searchTerm) {
        t27 = isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                p: 2,
                pt: 1.5
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedVocabField, {
                    value: item.word || "",
                    field: "word",
                    itemIndex: index,
                    onSave: onUpdate,
                    searchTerm: searchTerm,
                    label: "Word",
                    placeholder: "Enter word..."
                }, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 665,
                    columnNumber: 8
                }, this),
                item.phonetic !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedVocabField, {
                    value: item.phonetic || "",
                    field: "phonetic",
                    itemIndex: index,
                    onSave: onUpdate,
                    searchTerm: searchTerm,
                    label: "Phonetic",
                    placeholder: "Enter phonetic pronunciation..."
                }, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 665,
                    columnNumber: 198
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedVocabField, {
                    value: item.definition || "",
                    field: "definition",
                    itemIndex: index,
                    onSave: onUpdate,
                    searchTerm: searchTerm,
                    label: "Definition",
                    placeholder: "Enter definition...",
                    multiline: true
                }, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 665,
                    columnNumber: 387
                }, this),
                item.context !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedVocabField, {
                    value: item.context || "",
                    field: "context",
                    itemIndex: index,
                    onSave: onUpdate,
                    searchTerm: searchTerm,
                    label: "Context",
                    placeholder: "Enter context or example sentence...",
                    multiline: true
                }, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 665,
                    columnNumber: 617
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 662,
            columnNumber: 25
        }, this);
        $[63] = index;
        $[64] = isExpanded;
        $[65] = item.context;
        $[66] = item.definition;
        $[67] = item.phonetic;
        $[68] = item.word;
        $[69] = onUpdate;
        $[70] = searchTerm;
        $[71] = t27;
    } else {
        t27 = $[71];
    }
    let t28;
    if ($[72] !== t26 || $[73] !== t27 || $[74] !== t5) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
            "data-tour": "word-card",
            sx: t5,
            children: [
                t26,
                t27
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 680,
            columnNumber: 11
        }, this);
        $[72] = t26;
        $[73] = t27;
        $[74] = t5;
        $[75] = t28;
    } else {
        t28 = $[75];
    }
    return t28;
}
_c1 = VocabularyCard;
// Export VocabularyCard for reuse in other components - already exported above as named export
// =============================================================================
// VocabularyReview2 - Main component with virtual scrolling
// =============================================================================
function _VocabularyCardBoxOnClick2(e_2) {
    return e_2.stopPropagation();
}
function _VocabularyCardBoxOnClick(e_1) {
    return e_1.stopPropagation();
}
const VocabularyReview2 = ({ documentId, unitId, owner, identityId, onImportComplete, searchTerm = '' })=>{
    _s1();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('components');
    const { user, isLoading: authLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {
        user: undefined,
        isLoading: true
    };
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$importReviewReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["importReviewReducer"], undefined, {
        "VocabularyReview2.useReducer": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$importReviewReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createInitialImportReviewState"])()
    }["VocabularyReview2.useReducer"]);
    const { parsedContent, document, items: vocabularyItems, selectedItems, expandedItems, loading, importStatus, importProgress, importResult, showSummaries, summaries, objectives } = state;
    const importing = importStatus === 'importing';
    // Use DictionaryContext to access existing dictionary words
    const { dictionary } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {
        dictionary: {}
    };
    // Refs for virtual scrolling
    const parentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Filter vocabulary items by search term
    const filteredVocabulary = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "VocabularyReview2.useMemo[filteredVocabulary]": ()=>{
            if (!searchTerm) return vocabularyItems;
            const lowerSearch = searchTerm.toLowerCase();
            return vocabularyItems.filter({
                "VocabularyReview2.useMemo[filteredVocabulary]": (item)=>{
                    return item.word?.toLowerCase().includes(lowerSearch) || item.definition?.toLowerCase().includes(lowerSearch) || item.context?.toLowerCase().includes(lowerSearch) || item.phonetic?.toLowerCase().includes(lowerSearch);
                }
            }["VocabularyReview2.useMemo[filteredVocabulary]"]);
        }
    }["VocabularyReview2.useMemo[filteredVocabulary]"], [
        vocabularyItems,
        searchTerm
    ]);
    // Virtual scrolling setup
    // estimateSize returns a stable collapsed-row height;
    // measureElement's ResizeObserver handles actual sizing on expand/collapse
    const virtualizer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"])({
        count: filteredVocabulary.length,
        getScrollElement: {
            "VocabularyReview2.useVirtualizer[virtualizer]": ()=>parentRef.current
        }["VocabularyReview2.useVirtualizer[virtualizer]"],
        estimateSize: {
            "VocabularyReview2.useVirtualizer[virtualizer]": ()=>60
        }["VocabularyReview2.useVirtualizer[virtualizer]"],
        overscan: 5
    });
    // Fetch ParsedContent and Document
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VocabularyReview2.useEffect": ()=>{
            // Wait for authentication
            if (authLoading || !user) {
                console.log('[VocabularyReview2] Waiting for authentication', {
                    authLoading,
                    hasUser: !!user
                });
                return;
            }
            loadParsedContent();
            console.log('[VocabularyReview2] Setting up ParsedContent subscription for user:', user.username);
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const subscription = client.models.ParsedContent.observeQuery().subscribe({
                next: {
                    "VocabularyReview2.useEffect.subscription": ({ items })=>{
                        // Filter out null items that can appear during subscription updates
                        const validItems = items.filter({
                            "VocabularyReview2.useEffect.subscription.validItems": (item_0)=>item_0 != null && item_0.id != null
                        }["VocabularyReview2.useEffect.subscription.validItems"]);
                        loadParsedContent();
                    }
                }["VocabularyReview2.useEffect.subscription"],
                error: {
                    "VocabularyReview2.useEffect.subscription": (error)=>console.error('[VocabularyReview2] ParsedContent subscription error:', error)
                }["VocabularyReview2.useEffect.subscription"]
            });
            return ({
                "VocabularyReview2.useEffect": ()=>subscription.unsubscribe()
            })["VocabularyReview2.useEffect"];
        }
    }["VocabularyReview2.useEffect"], [
        documentId,
        authLoading,
        user?.username
    ]);
    const loadParsedContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "VocabularyReview2.useCallback[loadParsedContent]": async ()=>{
            try {
                dispatch({
                    type: 'LOAD_START'
                });
                const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                // Get document
                const { data: doc } = await client_0.models.Document.get({
                    id: documentId
                });
                // Get parsed content for this document
                const { data: parsedContents } = await client_0.models.ParsedContent.list({
                    filter: {
                        documentID: {
                            eq: documentId
                        }
                    }
                });
                if (parsedContents.length > 0) {
                    const content = parsedContents[0];
                    // Parse vocabulary - a.json() fields may be returned as objects or strings
                    const vocab = content.vocabularyJSON ? typeof content.vocabularyJSON === 'string' ? JSON.parse(content.vocabularyJSON) : content.vocabularyJSON : [];
                    // Enrich vocabulary with source metadata
                    const enrichedVocab = vocab.map({
                        "VocabularyReview2.useCallback[loadParsedContent].enrichedVocab": (v)=>({
                                ...v,
                                documentID: content.documentID,
                                fileID: content.fileID || undefined,
                                filename: doc?.filename || undefined
                            })
                    }["VocabularyReview2.useCallback[loadParsedContent].enrichedVocab"]);
                    // Parse summaries - a.json() fields may be returned as objects or strings
                    const sums = content.summariesJSON ? typeof content.summariesJSON === 'string' ? JSON.parse(content.summariesJSON) : content.summariesJSON : [];
                    // Parse objectives - a.json() fields may be returned as objects or strings
                    const objs = content.objectivesJSON ? typeof content.objectivesJSON === 'string' ? JSON.parse(content.objectivesJSON) : content.objectivesJSON : [];
                    dispatch({
                        type: 'LOAD_SUCCESS',
                        parsedContent: content,
                        document: doc,
                        items: enrichedVocab,
                        summaries: sums,
                        objectives: objs,
                        autoSelectAll: !content.importedAt
                    });
                } else {
                    dispatch({
                        type: 'LOAD_ERROR'
                    });
                }
            } catch (error_0) {
                console.error('Error loading parsed content:', error_0);
                dispatch({
                    type: 'LOAD_ERROR'
                });
            }
        }
    }["VocabularyReview2.useCallback[loadParsedContent]"], [
        documentId
    ]);
    const toggleItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "VocabularyReview2.useCallback[toggleItem]": (index)=>{
            dispatch({
                type: 'TOGGLE_SELECT',
                index
            });
        }
    }["VocabularyReview2.useCallback[toggleItem]"], []);
    const toggleExpand = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "VocabularyReview2.useCallback[toggleExpand]": (index_0)=>{
            dispatch({
                type: 'TOGGLE_EXPAND',
                index: index_0
            });
        }
    }["VocabularyReview2.useCallback[toggleExpand]"], []);
    const toggleAll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "VocabularyReview2.useCallback[toggleAll]": ()=>{
            if (selectedItems.size === vocabularyItems.length) {
                dispatch({
                    type: 'DESELECT_ALL'
                });
            } else {
                dispatch({
                    type: 'SELECT_ALL',
                    count: vocabularyItems.length
                });
            }
        }
    }["VocabularyReview2.useCallback[toggleAll]"], [
        selectedItems.size,
        vocabularyItems.length
    ]);
    const handleUpdate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "VocabularyReview2.useCallback[handleUpdate]": async (index_1, field, newValue)=>{
            if (!parsedContent) return;
            const updates = {
                [field]: newValue
            };
            const success = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vocabularyImportUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateVocabularyItem"])(parsedContent.id, index_1, updates);
            if (success) {
                const updated = {
                    ...vocabularyItems[index_1],
                    ...updates
                };
                dispatch({
                    type: 'UPDATE_ITEM',
                    index: index_1,
                    item: updated
                });
            }
        }
    }["VocabularyReview2.useCallback[handleUpdate]"], [
        parsedContent,
        vocabularyItems
    ]);
    const handleImport = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "VocabularyReview2.useCallback[handleImport]": async ()=>{
            if (!parsedContent || !unitId) {
                console.error('Missing parsedContent or unitId');
                return;
            }
            dispatch({
                type: 'IMPORT_START'
            });
            const selectedIndices = Array.from(selectedItems).map(String);
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$vocabularyImportUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["importVocabularyToUnit"])(parsedContent.id, unitId, selectedIndices, owner, identityId, {
                "VocabularyReview2.useCallback[handleImport]": (current, total, message)=>{
                    dispatch({
                        type: 'IMPORT_PROGRESS',
                        progress: {
                            current,
                            total,
                            message
                        }
                    });
                }
            }["VocabularyReview2.useCallback[handleImport]"]);
            if (result?.success) {
                dispatch({
                    type: 'IMPORT_SUCCESS',
                    result
                });
                onImportComplete?.(result);
            } else {
                dispatch({
                    type: 'IMPORT_ERROR',
                    result
                });
            }
            // Reload to show updated status
            loadParsedContent();
        }
    }["VocabularyReview2.useCallback[handleImport]"], [
        parsedContent,
        unitId,
        selectedItems,
        owner,
        identityId,
        onImportComplete,
        loadParsedContent
    ]);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                p: 2
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {}, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 939,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "body2",
                    sx: {
                        mt: 1,
                        textAlign: 'center'
                    },
                    children: t('vocabularyReview.loading')
                }, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 940,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 936,
            columnNumber: 12
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (!parsedContent || vocabularyItems.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                p: 2
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                severity: "info",
                children: t('vocabularyReview.noVocabulary')
            }, void 0, false, {
                fileName: "[project]/src/components/VocabularyReview2.tsx",
                lineNumber: 952,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/VocabularyReview2.tsx",
            lineNumber: 949,
            columnNumber: 12
        }, ("TURBOPACK compile-time value", void 0));
    }
    const alreadyImported = !!parsedContent.importedAt;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
            overflow: 'hidden'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    p: 2,
                    flexShrink: 0
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "h6",
                        gutterBottom: true,
                        sx: {
                            fontWeight: 600
                        },
                        children: t('vocabularyReview.sectionHeading')
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 969,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    document && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "text.secondary",
                        gutterBottom: true,
                        children: [
                            t('vocabularyReview.from'),
                            ": ",
                            document.filename,
                            document.pageCount && ` (${document.pageCount} ${t('vocabularyReview.pages')})`
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 974,
                        columnNumber: 30
                    }, ("TURBOPACK compile-time value", void 0)),
                    alreadyImported && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                        severity: "success",
                        sx: {
                            mt: 1
                        },
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/VocabularyReview2.tsx",
                            lineNumber: 981,
                            columnNumber: 16
                        }, ("TURBOPACK compile-time value", void 0)),
                        children: t('vocabularyReview.importedOn', {
                            date: new Date(parsedContent.importedAt).toLocaleString()
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 979,
                        columnNumber: 37
                    }, ("TURBOPACK compile-time value", void 0)),
                    searchTerm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                        severity: "info",
                        sx: {
                            mt: 1
                        },
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/VocabularyReview2.tsx",
                            lineNumber: 989,
                            columnNumber: 16
                        }, ("TURBOPACK compile-time value", void 0)),
                        children: t('vocabularyReview.filteringBySearch', {
                            searchTerm,
                            count: filteredVocabulary.length,
                            total: vocabularyItems.length
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 987,
                        columnNumber: 32
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/VocabularyReview2.tsx",
                lineNumber: 965,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            (summaries.length > 0 || objectives.length > 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    px: 2,
                    pb: 1,
                    flexShrink: 0
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        size: "small",
                        onClick: ()=>dispatch({
                                type: 'TOGGLE_SUMMARIES'
                            }),
                        endIcon: showSummaries ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/VocabularyReview2.tsx",
                            lineNumber: 1006,
                            columnNumber: 36
                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/VocabularyReview2.tsx",
                            lineNumber: 1006,
                            columnNumber: 57
                        }, ("TURBOPACK compile-time value", void 0)),
                        variant: "outlined",
                        children: [
                            showSummaries ? t('vocabularyReview.hide') : t('vocabularyReview.show'),
                            " ",
                            t('vocabularyReview.summariesAndObjectives')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 1004,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__["Collapse"], {
                        in: showSummaries,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
                            elevation: 0,
                            sx: {
                                p: 2,
                                mt: 1,
                                bgcolor: 'action.hover'
                            },
                            children: [
                                summaries.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        mb: 2
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "subtitle2",
                                            gutterBottom: true,
                                            fontWeight: 600,
                                            children: t('vocabularyReview.summaries')
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VocabularyReview2.tsx",
                                            lineNumber: 1018,
                                            columnNumber: 37
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        summaries.map((summary, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                sx: {
                                                    mb: 1
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "body2",
                                                        fontWeight: "bold",
                                                        children: summary.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                                                        lineNumber: 1024,
                                                        columnNumber: 45
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "body2",
                                                        color: "text.secondary",
                                                        children: summary.content
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                                                        lineNumber: 1027,
                                                        columnNumber: 45
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, i, true, {
                                                fileName: "[project]/src/components/VocabularyReview2.tsx",
                                                lineNumber: 1021,
                                                columnNumber: 68
                                            }, ("TURBOPACK compile-time value", void 0)))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                                    lineNumber: 1015,
                                    columnNumber: 54
                                }, ("TURBOPACK compile-time value", void 0)),
                                objectives.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "subtitle2",
                                            gutterBottom: true,
                                            fontWeight: 600,
                                            children: t('vocabularyReview.learningObjectives')
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VocabularyReview2.tsx",
                                            lineNumber: 1033,
                                            columnNumber: 37
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                            dense: true,
                                            children: objectives.map((obj, i_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                                    sx: {
                                                        py: 0.5
                                                    },
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "body2",
                                                        children: [
                                                            "• ",
                                                            obj.objective
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                                                        lineNumber: 1040,
                                                        columnNumber: 49
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, i_0, false, {
                                                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                                                    lineNumber: 1037,
                                                    columnNumber: 71
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VocabularyReview2.tsx",
                                            lineNumber: 1036,
                                            columnNumber: 37
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                                    lineNumber: 1032,
                                    columnNumber: 55
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/VocabularyReview2.tsx",
                            lineNumber: 1010,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 1009,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/VocabularyReview2.tsx",
                lineNumber: 999,
                columnNumber: 65
            }, ("TURBOPACK compile-time value", void 0)),
            !alreadyImported && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    px: 2,
                    pb: 1,
                    display: 'flex',
                    gap: 1,
                    alignItems: 'center',
                    flexShrink: 0
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        variant: "outlined",
                        size: "small",
                        onClick: toggleAll,
                        children: selectedItems.size === vocabularyItems.length ? t('vocabularyReview.deselectAll') : t('vocabularyReview.selectAll')
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 1059,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "text.secondary",
                        children: t('vocabularyReview.selectedCount', {
                            count: selectedItems.size,
                            total: vocabularyItems.length
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 1062,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            flex: 1
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 1068,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        variant: "contained",
                        startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/VocabularyReview2.tsx",
                            lineNumber: 1071,
                            columnNumber: 60
                        }, ("TURBOPACK compile-time value", void 0)),
                        onClick: handleImport,
                        disabled: importing || selectedItems.size === 0,
                        children: t('vocabularyReview.importToDictionary')
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 1071,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/VocabularyReview2.tsx",
                lineNumber: 1051,
                columnNumber: 34
            }, ("TURBOPACK compile-time value", void 0)),
            importing && importProgress && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    px: 2,
                    pb: 1,
                    flexShrink: 0
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                        variant: "determinate",
                        value: importProgress.current / importProgress.total * 100
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 1082,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        sx: {
                            mt: 0.5,
                            textAlign: 'center'
                        },
                        children: importProgress.message
                    }, void 0, false, {
                        fileName: "[project]/src/components/VocabularyReview2.tsx",
                        lineNumber: 1083,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/VocabularyReview2.tsx",
                lineNumber: 1077,
                columnNumber: 45
            }, ("TURBOPACK compile-time value", void 0)),
            importResult && !importing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    px: 2,
                    pb: 1,
                    flexShrink: 0
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                    severity: importResult.success ? 'success' : 'error',
                    onClose: ()=>dispatch({
                            type: 'CLEAR_IMPORT_RESULT'
                        }),
                    children: importResult.message || `Imported ${importResult.imported} new words, ${importResult.skipped} already existed, ${importResult.errors} errors`
                }, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 1097,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/VocabularyReview2.tsx",
                lineNumber: 1092,
                columnNumber: 44
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
                ref: parentRef,
                elevation: 2,
                sx: {
                    flex: 1,
                    overflow: 'auto',
                    mx: 2,
                    mb: 2
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                    sx: {
                        height: virtualizer.getTotalSize(),
                        position: 'relative',
                        padding: 0
                    },
                    children: virtualizer.getVirtualItems().map((virtualItem)=>{
                        const item_1 = filteredVocabulary[virtualItem.index];
                        const existsInDictionary = dictionary && Object.values(dictionary).some((word)=>word.phrase?.toLowerCase().trim() === item_1.word?.toLowerCase().trim());
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            "data-index": virtualItem.index,
                            ref: virtualizer.measureElement,
                            sx: {
                                position: 'absolute',
                                top: 0,
                                left: 0,
                                width: '100%',
                                transform: `translateY(${virtualItem.start}px)`
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(VocabularyCard, {
                                item: item_1,
                                index: virtualItem.index,
                                isSelected: selectedItems.has(virtualItem.index),
                                isExpanded: expandedItems.has(virtualItem.index),
                                existsInDictionary: existsInDictionary,
                                alreadyImported: alreadyImported,
                                searchTerm: searchTerm,
                                onToggleSelect: toggleItem,
                                onToggleExpand: toggleExpand,
                                onUpdate: handleUpdate
                            }, void 0, false, {
                                fileName: "[project]/src/components/VocabularyReview2.tsx",
                                lineNumber: 1126,
                                columnNumber: 33
                            }, ("TURBOPACK compile-time value", void 0))
                        }, virtualItem.key, false, {
                            fileName: "[project]/src/components/VocabularyReview2.tsx",
                            lineNumber: 1119,
                            columnNumber: 18
                        }, ("TURBOPACK compile-time value", void 0));
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/VocabularyReview2.tsx",
                    lineNumber: 1111,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/VocabularyReview2.tsx",
                lineNumber: 1105,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/VocabularyReview2.tsx",
        lineNumber: 958,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s1(VocabularyReview2, "h88+y2egD9I9Wi1fGJ3tK8g/zpw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"]
    ];
});
_c2 = VocabularyReview2;
const __TURBOPACK__default__export__ = VocabularyReview2;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "NestedVocabField");
__turbopack_context__.k.register(_c1, "VocabularyCard");
__turbopack_context__.k.register(_c2, "VocabularyReview2");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/QuestionsReview2.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "QuestionCard",
    ()=>QuestionCard,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * QuestionsReview2 Component
 * 
 * Enhanced questions review panel with:
 * - Lexical-powered inline editing with unified undo/redo
 * - Virtual scrolling for large lists (TanStack Virtual)
 * - Search term highlighting
 * - Auto-save with debouncing
 * - Polished card design with badges and shadows
 * - Better expand/collapse affordances
 * - Import state indicators
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript) <export default as Paper>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Collapse/Collapse.js [app-client] (ecmascript) <export default as Collapse>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Download.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CheckCircle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandMore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ExpandLess.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Mic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Mic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Info.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$QuestionAnswer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/QuestionAnswer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/dictionaryContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$questionImportUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/questionImportUtils.jsx [app-client] (ecmascript)");
// Lexical imports
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposer.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalPlainTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalPlainTextPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalContentEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHistoryPlugin.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalOnChangePlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalErrorBoundary.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$mark$2f$LexicalMark$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/mark/LexicalMark.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$SearchHighlightPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/SearchHighlightPlugin.jsx [app-client] (ecmascript)");
// Virtual scrolling
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-virtual/dist/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$importReviewReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/importReviewReducer.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function NestedQuestionField(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(49);
    if ($[0] !== "8da2f9bd7fa6eb9e6707d38d1a7c0aa80cd23346a4136ff8c7e2de224f58e9e8") {
        for(let $i = 0; $i < 49; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8da2f9bd7fa6eb9e6707d38d1a7c0aa80cd23346a4136ff8c7e2de224f58e9e8";
    }
    const { value, field, itemIndex, onSave, searchTerm: t1, label: t2, placeholder: t3, multiline: t4 } = t0;
    const searchTerm = t1 === undefined ? "" : t1;
    const label = t2 === undefined ? "" : t2;
    const placeholder = t3 === undefined ? "" : t3;
    const multiline = t4 === undefined ? false : t4;
    const saveTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const t5 = `QuestionField-${field}-${itemIndex}`;
    let t6;
    let t7;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$mark$2f$LexicalMark$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MarkNode"]
        ];
        t7 = {
            mark: "search-highlight"
        };
        $[1] = t6;
        $[2] = t7;
    } else {
        t6 = $[1];
        t7 = $[2];
    }
    let t8;
    if ($[3] !== value) {
        t8 = ()=>{
            const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
            root.clear();
            const paragraph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])();
            const text = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(value || "");
            paragraph.append(text);
            root.append(paragraph);
        };
        $[3] = value;
        $[4] = t8;
    } else {
        t8 = $[4];
    }
    let t9;
    if ($[5] !== t5 || $[6] !== t8) {
        t9 = {
            namespace: t5,
            nodes: t6,
            theme: t7,
            onError: _temp,
            editorState: t8
        };
        $[5] = t5;
        $[6] = t8;
        $[7] = t9;
    } else {
        t9 = $[7];
    }
    const initialConfig = t9;
    let t10;
    if ($[8] !== field || $[9] !== itemIndex || $[10] !== onSave || $[11] !== value) {
        t10 = ({
            "NestedQuestionField[handleChange]": (editorState)=>{
                editorState.read({
                    "NestedQuestionField[handleChange > editorState.read()]": ()=>{
                        const text_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().getTextContent();
                        if (saveTimeoutRef.current) {
                            clearTimeout(saveTimeoutRef.current);
                        }
                        saveTimeoutRef.current = setTimeout({
                            "NestedQuestionField[handleChange > editorState.read() > setTimeout()]": async ()=>{
                                if (text_0 !== value) {
                                    await onSave(itemIndex, field, text_0);
                                }
                            }
                        }["NestedQuestionField[handleChange > editorState.read() > setTimeout()]"], 1000);
                    }
                }["NestedQuestionField[handleChange > editorState.read()]"]);
            }
        })["NestedQuestionField[handleChange]"];
        $[8] = field;
        $[9] = itemIndex;
        $[10] = onSave;
        $[11] = value;
        $[12] = t10;
    } else {
        t10 = $[12];
    }
    const handleChange = t10;
    const t11 = multiline ? 1.5 : 0.5;
    let t12;
    if ($[13] !== t11) {
        t12 = {
            mb: t11,
            width: "100%"
        };
        $[13] = t11;
        $[14] = t12;
    } else {
        t12 = $[14];
    }
    let t13;
    if ($[15] !== label) {
        t13 = label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            variant: "caption",
            color: "text.secondary",
            sx: {
                display: "block",
                mb: 0.25,
                fontWeight: 500
            },
            children: label
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 188,
            columnNumber: 20
        }, this);
        $[15] = label;
        $[16] = t13;
    } else {
        t13 = $[16];
    }
    let t14;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = {
            position: "relative"
        };
        $[17] = t14;
    } else {
        t14 = $[17];
    }
    const t15 = label || placeholder || field;
    const t16 = multiline ? "80px" : "24px";
    const t17 = multiline ? "8px" : "4px 8px";
    const t18 = field === "prompt" ? "1rem" : "0.875rem";
    const t19 = field === "prompt" ? 500 : 400;
    const t20 = multiline ? "vertical" : "none";
    let t21;
    if ($[18] !== t16 || $[19] !== t17 || $[20] !== t18 || $[21] !== t19 || $[22] !== t20) {
        t21 = {
            minHeight: t16,
            padding: t17,
            border: "1px solid var(--mui-palette-divider, rgba(0, 0, 0, 0.12))",
            borderRadius: "4px",
            fontSize: t18,
            fontFamily: "inherit",
            fontWeight: t19,
            outline: "none",
            resize: t20,
            backgroundColor: "background.paper",
            cursor: "text"
        };
        $[18] = t16;
        $[19] = t17;
        $[20] = t18;
        $[21] = t19;
        $[22] = t20;
        $[23] = t21;
    } else {
        t21 = $[23];
    }
    let t22;
    if ($[24] !== t15 || $[25] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentEditable"], {
            contentEditable: true,
            "aria-label": t15,
            style: t21
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 239,
            columnNumber: 11
        }, this);
        $[24] = t15;
        $[25] = t21;
        $[26] = t22;
    } else {
        t22 = $[26];
    }
    let t23;
    if ($[27] !== multiline || $[28] !== placeholder) {
        t23 = placeholder ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                position: "absolute",
                top: multiline ? "8px" : "4px",
                left: "8px",
                color: "var(--mui-palette-text-disabled, rgba(0, 0, 0, 0.38))",
                pointerEvents: "none",
                fontSize: "0.875rem"
            },
            children: placeholder
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 248,
            columnNumber: 25
        }, this) : null;
        $[27] = multiline;
        $[28] = placeholder;
        $[29] = t23;
    } else {
        t23 = $[29];
    }
    let t24;
    if ($[30] !== t22 || $[31] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalPlainTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlainTextPlugin"], {
            ErrorBoundary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalErrorBoundary"],
            contentEditable: t22,
            placeholder: t23
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 264,
            columnNumber: 11
        }, this);
        $[30] = t22;
        $[31] = t23;
        $[32] = t24;
    } else {
        t24 = $[32];
    }
    let t25;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHistoryPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HistoryPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 273,
            columnNumber: 11
        }, this);
        $[33] = t25;
    } else {
        t25 = $[33];
    }
    let t26;
    if ($[34] !== handleChange) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalOnChangePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OnChangePlugin"], {
            onChange: handleChange
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 280,
            columnNumber: 11
        }, this);
        $[34] = handleChange;
        $[35] = t26;
    } else {
        t26 = $[35];
    }
    let t27;
    if ($[36] !== searchTerm) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$SearchHighlightPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            searchTerm: searchTerm
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 288,
            columnNumber: 11
        }, this);
        $[36] = searchTerm;
        $[37] = t27;
    } else {
        t27 = $[37];
    }
    let t28;
    if ($[38] !== t24 || $[39] !== t26 || $[40] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t14,
            children: [
                t24,
                t25,
                t26,
                t27
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 296,
            columnNumber: 11
        }, this);
        $[38] = t24;
        $[39] = t26;
        $[40] = t27;
        $[41] = t28;
    } else {
        t28 = $[41];
    }
    let t29;
    if ($[42] !== initialConfig || $[43] !== t28) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalComposer"], {
            initialConfig: initialConfig,
            children: t28
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 306,
            columnNumber: 11
        }, this);
        $[42] = initialConfig;
        $[43] = t28;
        $[44] = t29;
    } else {
        t29 = $[44];
    }
    let t30;
    if ($[45] !== t12 || $[46] !== t13 || $[47] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t12,
            children: [
                t13,
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 315,
            columnNumber: 11
        }, this);
        $[45] = t12;
        $[46] = t13;
        $[47] = t29;
        $[48] = t30;
    } else {
        t30 = $[48];
    }
    return t30;
}
_s(NestedQuestionField, "nqB4vf/Orw8Sp7yzfGj49tAYSPk=");
_c = NestedQuestionField;
// =============================================================================
// QuestionCard - Individual question item with Lexical editing
// =============================================================================
function _temp(error) {
    return console.error("Lexical error:", error);
}
function QuestionCard(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(80);
    if ($[0] !== "8da2f9bd7fa6eb9e6707d38d1a7c0aa80cd23346a4136ff8c7e2de224f58e9e8") {
        for(let $i = 0; $i < 80; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8da2f9bd7fa6eb9e6707d38d1a7c0aa80cd23346a4136ff8c7e2de224f58e9e8";
    }
    const { item, index, isSelected, isExpanded, alreadyImported, searchTerm: t1, onToggleSelect, onToggleExpand, onUpdate } = t0;
    const searchTerm = t1 === undefined ? "" : t1;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const isEvenRow = index % 2 === 0;
    const t2 = isEvenRow ? "background.paper" : "action.hover";
    const t3 = isEvenRow ? "action.selected" : "action.focus";
    let t4;
    if ($[1] !== t3) {
        t4 = {
            backgroundColor: t3,
            boxShadow: 1
        };
        $[1] = t3;
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    let t5;
    if ($[3] !== t2 || $[4] !== t4) {
        t5 = {
            backgroundColor: t2,
            flexDirection: "column",
            alignItems: "stretch",
            padding: 0,
            margin: 0,
            borderBottom: "1px solid",
            borderColor: "divider",
            transition: "box-shadow 0.2s ease",
            "&:hover": t4
        };
        $[3] = t2;
        $[4] = t4;
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    let t6;
    if ($[6] !== index || $[7] !== isExpanded || $[8] !== onToggleExpand) {
        t6 = ({
            "QuestionCard[<Box>.onClick]": (e)=>{
                if (e.target.closest(".MuiCheckbox-root")) {
                    return;
                }
                if (!isExpanded) {
                    onToggleExpand(index);
                }
            }
        })["QuestionCard[<Box>.onClick]"];
        $[6] = index;
        $[7] = isExpanded;
        $[8] = onToggleExpand;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    const t7 = isExpanded ? "1px solid" : "none";
    const t8 = isExpanded ? "default" : "pointer";
    let t9;
    if ($[10] !== t7 || $[11] !== t8) {
        t9 = {
            display: "flex",
            alignItems: "center",
            gap: 1,
            justifyContent: "space-between",
            padding: 1,
            borderBottom: t7,
            borderColor: "divider",
            cursor: t8
        };
        $[10] = t7;
        $[11] = t8;
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    let t10;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            display: "flex",
            gap: 0.5,
            alignItems: "center",
            flex: 1,
            minWidth: 0
        };
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] !== alreadyImported || $[15] !== index || $[16] !== isSelected || $[17] !== onToggleSelect || $[18] !== t) {
        t11 = !alreadyImported && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
            size: "small",
            checked: isSelected,
            onChange: {
                "QuestionCard[<Checkbox>.onChange]": ()=>onToggleSelect(index)
            }["QuestionCard[<Checkbox>.onChange]"],
            sx: {
                p: 0.5
            },
            className: "MuiCheckbox-root",
            inputProps: {
                "aria-label": t("questionsReview.selectQuestion", {
                    index: index + 1
                })
            }
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 452,
            columnNumber: 31
        }, this);
        $[14] = alreadyImported;
        $[15] = index;
        $[16] = isSelected;
        $[17] = onToggleSelect;
        $[18] = t;
        $[19] = t11;
    } else {
        t11 = $[19];
    }
    let t12;
    if ($[20] !== index || $[21] !== onToggleExpand) {
        t12 = ({
            "QuestionCard[<IconButton>.onClick]": (e_0)=>{
                e_0.stopPropagation();
                onToggleExpand(index);
            }
        })["QuestionCard[<IconButton>.onClick]"];
        $[20] = index;
        $[21] = onToggleExpand;
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    let t13;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            p: 0.5
        };
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    let t14;
    if ($[24] !== isExpanded || $[25] !== t) {
        t14 = isExpanded ? t("questionsReview.collapse") : t("questionsReview.expand");
        $[24] = isExpanded;
        $[25] = t;
        $[26] = t14;
    } else {
        t14 = $[26];
    }
    let t15;
    if ($[27] !== isExpanded) {
        t15 = isExpanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 504,
            columnNumber: 24
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 504,
            columnNumber: 62
        }, this);
        $[27] = isExpanded;
        $[28] = t15;
    } else {
        t15 = $[28];
    }
    let t16;
    if ($[29] !== t12 || $[30] !== t14 || $[31] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            size: "small",
            onClick: t12,
            sx: t13,
            "aria-label": t14,
            children: t15
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 512,
            columnNumber: 11
        }, this);
        $[29] = t12;
        $[30] = t14;
        $[31] = t15;
        $[32] = t16;
    } else {
        t16 = $[32];
    }
    let t17;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = {
            flex: 1,
            minWidth: 0
        };
        $[33] = t17;
    } else {
        t17 = $[33];
    }
    let t18;
    if ($[34] !== index || $[35] !== isExpanded || $[36] !== item.prompt || $[37] !== onUpdate || $[38] !== searchTerm) {
        t18 = !isExpanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            onClick: _QuestionCardBoxOnClick,
            sx: {
                fontSize: "0.875rem",
                flex: 1
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedQuestionField, {
                value: item.prompt || "",
                field: "prompt",
                itemIndex: index,
                onSave: onUpdate,
                searchTerm: searchTerm
            }, void 0, false, {
                fileName: "[project]/src/components/QuestionsReview2.tsx",
                lineNumber: 535,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 532,
            columnNumber: 25
        }, this) : null;
        $[34] = index;
        $[35] = isExpanded;
        $[36] = item.prompt;
        $[37] = onUpdate;
        $[38] = searchTerm;
        $[39] = t18;
    } else {
        t18 = $[39];
    }
    let t19;
    if ($[40] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t17,
            children: t18
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 547,
            columnNumber: 11
        }, this);
        $[40] = t18;
        $[41] = t19;
    } else {
        t19 = $[41];
    }
    let t20;
    if ($[42] !== t11 || $[43] !== t16 || $[44] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t10,
            children: [
                t11,
                t16,
                t19
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 555,
            columnNumber: 11
        }, this);
        $[42] = t11;
        $[43] = t16;
        $[44] = t19;
        $[45] = t20;
    } else {
        t20 = $[45];
    }
    let t21;
    if ($[46] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = {
            display: "flex",
            gap: 0.5,
            alignItems: "center",
            flexShrink: 0
        };
        $[46] = t21;
    } else {
        t21 = $[46];
    }
    let t22;
    if ($[47] !== item.filename) {
        t22 = item.filename && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: `Source: ${item.filename}`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                label: item.filename.length > 20 ? `${item.filename.slice(0, 17)}...` : item.filename,
                size: "small",
                variant: "outlined",
                color: "primary",
                sx: {
                    fontSize: "0.65rem",
                    height: "20px",
                    maxWidth: "150px"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/QuestionsReview2.tsx",
                lineNumber: 577,
                columnNumber: 72
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 577,
            columnNumber: 28
        }, this);
        $[47] = item.filename;
        $[48] = t22;
    } else {
        t22 = $[48];
    }
    let t23;
    if ($[49] !== item.page) {
        t23 = item.page && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            label: `p.${item.page}`,
            size: "small",
            variant: "outlined",
            sx: {
                fontSize: "0.65rem",
                height: "20px"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 589,
            columnNumber: 24
        }, this);
        $[49] = item.page;
        $[50] = t23;
    } else {
        t23 = $[50];
    }
    let t24;
    if ($[51] !== item.hasAudio || $[52] !== t) {
        t24 = item.hasAudio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: t("questionsReview.hasAudio"),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Mic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fontSize: "small",
                color: "primary",
                "aria-label": t("questionsReview.hasAudio")
            }, void 0, false, {
                fileName: "[project]/src/components/QuestionsReview2.tsx",
                lineNumber: 600,
                columnNumber: 75
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 600,
            columnNumber: 28
        }, this);
        $[51] = item.hasAudio;
        $[52] = t;
        $[53] = t24;
    } else {
        t24 = $[53];
    }
    let t25;
    if ($[54] !== item.hasImage || $[55] !== t) {
        t25 = item.hasImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
            title: t("questionsReview.hasImage"),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fontSize: "small",
                color: "secondary",
                "aria-label": t("questionsReview.hasImage")
            }, void 0, false, {
                fileName: "[project]/src/components/QuestionsReview2.tsx",
                lineNumber: 609,
                columnNumber: 75
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 609,
            columnNumber: 28
        }, this);
        $[54] = item.hasImage;
        $[55] = t;
        $[56] = t25;
    } else {
        t25 = $[56];
    }
    let t26;
    if ($[57] !== t22 || $[58] !== t23 || $[59] !== t24 || $[60] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t21,
            children: [
                t22,
                t23,
                t24,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 618,
            columnNumber: 11
        }, this);
        $[57] = t22;
        $[58] = t23;
        $[59] = t24;
        $[60] = t25;
        $[61] = t26;
    } else {
        t26 = $[61];
    }
    let t27;
    if ($[62] !== t20 || $[63] !== t26 || $[64] !== t6 || $[65] !== t9) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            onClick: t6,
            sx: t9,
            children: [
                t20,
                t26
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 629,
            columnNumber: 11
        }, this);
        $[62] = t20;
        $[63] = t26;
        $[64] = t6;
        $[65] = t9;
        $[66] = t27;
    } else {
        t27 = $[66];
    }
    let t28;
    if ($[67] !== index || $[68] !== isExpanded || $[69] !== item.answer || $[70] !== item.hint || $[71] !== item.prompt || $[72] !== onUpdate || $[73] !== searchTerm || $[74] !== t) {
        t28 = isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                p: 2,
                pt: 1.5
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedQuestionField, {
                    value: item.prompt || "",
                    field: "prompt",
                    itemIndex: index,
                    onSave: onUpdate,
                    searchTerm: searchTerm,
                    label: t("questionsReview.questionPrompt"),
                    placeholder: t("questionsReview.enterQuestion"),
                    multiline: true
                }, void 0, false, {
                    fileName: "[project]/src/components/QuestionsReview2.tsx",
                    lineNumber: 643,
                    columnNumber: 8
                }, this),
                item.hint !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedQuestionField, {
                    value: item.hint || "",
                    field: "hint",
                    itemIndex: index,
                    onSave: onUpdate,
                    searchTerm: searchTerm,
                    label: t("questionsReview.hintOptional"),
                    placeholder: t("questionsReview.enterHint"),
                    multiline: true
                }, void 0, false, {
                    fileName: "[project]/src/components/QuestionsReview2.tsx",
                    lineNumber: 643,
                    columnNumber: 270
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedQuestionField, {
                    value: item.answer || "",
                    field: "answer",
                    itemIndex: index,
                    onSave: onUpdate,
                    searchTerm: searchTerm,
                    label: t("questionsReview.answer"),
                    placeholder: t("questionsReview.enterAnswer"),
                    multiline: true
                }, void 0, false, {
                    fileName: "[project]/src/components/QuestionsReview2.tsx",
                    lineNumber: 643,
                    columnNumber: 495
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 640,
            columnNumber: 25
        }, this);
        $[67] = index;
        $[68] = isExpanded;
        $[69] = item.answer;
        $[70] = item.hint;
        $[71] = item.prompt;
        $[72] = onUpdate;
        $[73] = searchTerm;
        $[74] = t;
        $[75] = t28;
    } else {
        t28 = $[75];
    }
    let t29;
    if ($[76] !== t27 || $[77] !== t28 || $[78] !== t5) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
            sx: t5,
            children: [
                t27,
                t28
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 658,
            columnNumber: 11
        }, this);
        $[76] = t27;
        $[77] = t28;
        $[78] = t5;
        $[79] = t29;
    } else {
        t29 = $[79];
    }
    return t29;
}
_s1(QuestionCard, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c1 = QuestionCard;
// =============================================================================
// QuestionsReview2 - Main component with virtual scrolling
// =============================================================================
function _QuestionCardBoxOnClick(e_1) {
    return e_1.stopPropagation();
}
const QuestionsReview2 = ({ documentId, unitId, owner, identityId, onImportComplete, searchTerm = '' })=>{
    _s2();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('components');
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$importReviewReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["importReviewReducer"], undefined, {
        "QuestionsReview2.useReducer": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$importReviewReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createInitialImportReviewState"])()
    }["QuestionsReview2.useReducer"]);
    const { parsedContent, document, items: questionItems, selectedItems, expandedItems, loading, importStatus, importProgress, importResult, showSummaries, summaries, objectives } = state;
    const importing = importStatus === 'importing';
    // Use DictionaryContext to access existing questions
    const { questionBank } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$dictionaryContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {
        questionBank: {}
    };
    // Refs for virtual scrolling
    const parentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Filter question items by search term
    const filteredQuestions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "QuestionsReview2.useMemo[filteredQuestions]": ()=>{
            if (!searchTerm) return questionItems;
            const lowerSearch = searchTerm.toLowerCase();
            return questionItems.filter({
                "QuestionsReview2.useMemo[filteredQuestions]": (item)=>{
                    return item.prompt?.toLowerCase().includes(lowerSearch) || item.answer?.toLowerCase().includes(lowerSearch) || item.hint?.toLowerCase().includes(lowerSearch);
                }
            }["QuestionsReview2.useMemo[filteredQuestions]"]);
        }
    }["QuestionsReview2.useMemo[filteredQuestions]"], [
        questionItems,
        searchTerm
    ]);
    // Virtual scrolling setup
    // estimateSize returns a stable collapsed-row height;
    // measureElement's ResizeObserver handles actual sizing on expand/collapse
    const virtualizer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"])({
        count: filteredQuestions.length,
        getScrollElement: {
            "QuestionsReview2.useVirtualizer[virtualizer]": ()=>parentRef.current
        }["QuestionsReview2.useVirtualizer[virtualizer]"],
        estimateSize: {
            "QuestionsReview2.useVirtualizer[virtualizer]": ()=>60
        }["QuestionsReview2.useVirtualizer[virtualizer]"],
        overscan: 5
    });
    // Fetch ParsedContent and Document
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "QuestionsReview2.useEffect": ()=>{
            loadParsedContent();
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const subscription = client.models.ParsedContent.observeQuery().subscribe({
                next: {
                    "QuestionsReview2.useEffect.subscription": ({ items })=>{
                        // Filter out null items that can appear during subscription updates
                        const validItems = items.filter({
                            "QuestionsReview2.useEffect.subscription.validItems": (item_0)=>item_0 != null && item_0.id != null
                        }["QuestionsReview2.useEffect.subscription.validItems"]);
                        loadParsedContent();
                    }
                }["QuestionsReview2.useEffect.subscription"],
                error: {
                    "QuestionsReview2.useEffect.subscription": (error)=>console.error('[QuestionsReview2] ParsedContent subscription error:', error)
                }["QuestionsReview2.useEffect.subscription"]
            });
            return ({
                "QuestionsReview2.useEffect": ()=>subscription.unsubscribe()
            })["QuestionsReview2.useEffect"];
        }
    }["QuestionsReview2.useEffect"], [
        documentId
    ]);
    const loadParsedContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuestionsReview2.useCallback[loadParsedContent]": async ()=>{
            try {
                dispatch({
                    type: 'LOAD_START'
                });
                const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                // Get document
                const { data: doc } = await client_0.models.Document.get({
                    id: documentId
                });
                // Get parsed content for this document
                const { data: parsedContents } = await client_0.models.ParsedContent.list({
                    filter: {
                        documentID: {
                            eq: documentId
                        }
                    }
                });
                if (parsedContents.length > 0) {
                    const content = parsedContents[0];
                    // Parse questions - handle both string and object formats
                    const questions = ({
                        "QuestionsReview2.useCallback[loadParsedContent].questions": ()=>{
                            if (!content.questionsJSON) return [];
                            if (typeof content.questionsJSON === 'string') {
                                try {
                                    return JSON.parse(content.questionsJSON);
                                } catch (e) {
                                    console.error('Error parsing questionsJSON:', e);
                                    return [];
                                }
                            }
                            // Already an object/array
                            return Array.isArray(content.questionsJSON) ? content.questionsJSON : [];
                        }
                    })["QuestionsReview2.useCallback[loadParsedContent].questions"]();
                    // Enrich questions with source metadata
                    const enrichedQuestions = questions.map({
                        "QuestionsReview2.useCallback[loadParsedContent].enrichedQuestions": (q)=>({
                                ...q,
                                documentID: content.documentID,
                                fileID: content.fileID || undefined,
                                filename: doc?.filename || undefined
                            })
                    }["QuestionsReview2.useCallback[loadParsedContent].enrichedQuestions"]);
                    // Parse summaries - handle both string and object formats
                    const sums = ({
                        "QuestionsReview2.useCallback[loadParsedContent].sums": ()=>{
                            if (!content.summariesJSON) return [];
                            if (typeof content.summariesJSON === 'string') {
                                try {
                                    return JSON.parse(content.summariesJSON);
                                } catch (e_0) {
                                    console.error('Error parsing summariesJSON:', e_0);
                                    return [];
                                }
                            }
                            return Array.isArray(content.summariesJSON) ? content.summariesJSON : [];
                        }
                    })["QuestionsReview2.useCallback[loadParsedContent].sums"]();
                    // Parse objectives - handle both string and object formats
                    const objs = ({
                        "QuestionsReview2.useCallback[loadParsedContent].objs": ()=>{
                            if (!content.objectivesJSON) return [];
                            if (typeof content.objectivesJSON === 'string') {
                                try {
                                    return JSON.parse(content.objectivesJSON);
                                } catch (e_1) {
                                    console.error('Error parsing objectivesJSON:', e_1);
                                    return [];
                                }
                            }
                            return Array.isArray(content.objectivesJSON) ? content.objectivesJSON : [];
                        }
                    })["QuestionsReview2.useCallback[loadParsedContent].objs"]();
                    dispatch({
                        type: 'LOAD_SUCCESS',
                        parsedContent: content,
                        document: doc,
                        items: enrichedQuestions,
                        summaries: sums,
                        objectives: objs,
                        autoSelectAll: !content.importedAt
                    });
                } else {
                    dispatch({
                        type: 'LOAD_ERROR'
                    });
                }
            } catch (error_0) {
                console.error('Error loading parsed content:', error_0);
                dispatch({
                    type: 'LOAD_ERROR'
                });
            }
        }
    }["QuestionsReview2.useCallback[loadParsedContent]"], [
        documentId
    ]);
    const toggleItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuestionsReview2.useCallback[toggleItem]": (index)=>{
            dispatch({
                type: 'TOGGLE_SELECT',
                index
            });
        }
    }["QuestionsReview2.useCallback[toggleItem]"], []);
    const toggleExpand = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuestionsReview2.useCallback[toggleExpand]": (index_0)=>{
            dispatch({
                type: 'TOGGLE_EXPAND',
                index: index_0
            });
        }
    }["QuestionsReview2.useCallback[toggleExpand]"], []);
    const toggleAll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuestionsReview2.useCallback[toggleAll]": ()=>{
            if (selectedItems.size === questionItems.length) {
                dispatch({
                    type: 'DESELECT_ALL'
                });
            } else {
                dispatch({
                    type: 'SELECT_ALL',
                    count: questionItems.length
                });
            }
        }
    }["QuestionsReview2.useCallback[toggleAll]"], [
        selectedItems.size,
        questionItems.length
    ]);
    const handleUpdate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuestionsReview2.useCallback[handleUpdate]": async (index_1, field, newValue)=>{
            if (!parsedContent) return;
            const updates = {
                [field]: newValue
            };
            const success = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$questionImportUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateQuestionItem"])(parsedContent.id, index_1, updates);
            if (success) {
                const updated = {
                    ...questionItems[index_1],
                    ...updates
                };
                dispatch({
                    type: 'UPDATE_ITEM',
                    index: index_1,
                    item: updated
                });
            }
        }
    }["QuestionsReview2.useCallback[handleUpdate]"], [
        parsedContent,
        questionItems
    ]);
    const handleImport = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuestionsReview2.useCallback[handleImport]": async ()=>{
            if (!parsedContent || !unitId) {
                console.error('Missing parsedContent or unitId');
                return;
            }
            dispatch({
                type: 'IMPORT_START'
            });
            const selectedIndices = Array.from(selectedItems);
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$questionImportUtils$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["importQuestionsToUnit"])(parsedContent.id, unitId, selectedIndices, owner, identityId, {
                "QuestionsReview2.useCallback[handleImport]": (current, total, message)=>{
                    dispatch({
                        type: 'IMPORT_PROGRESS',
                        progress: {
                            current,
                            total,
                            message
                        }
                    });
                }
            }["QuestionsReview2.useCallback[handleImport]"]);
            if (result.success) {
                dispatch({
                    type: 'IMPORT_SUCCESS',
                    result
                });
                onImportComplete?.(result);
            } else {
                dispatch({
                    type: 'IMPORT_ERROR',
                    result
                });
            }
            // Reload to show updated status
            loadParsedContent();
        }
    }["QuestionsReview2.useCallback[handleImport]"], [
        parsedContent,
        unitId,
        selectedItems,
        owner,
        identityId,
        onImportComplete,
        loadParsedContent
    ]);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                p: 2
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {}, void 0, false, {
                    fileName: "[project]/src/components/QuestionsReview2.tsx",
                    lineNumber: 924,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "body2",
                    sx: {
                        mt: 1,
                        textAlign: 'center'
                    },
                    children: t('questionsReview.loading')
                }, void 0, false, {
                    fileName: "[project]/src/components/QuestionsReview2.tsx",
                    lineNumber: 925,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 921,
            columnNumber: 12
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (!parsedContent || questionItems.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                p: 2
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                severity: "info",
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$QuestionAnswer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/QuestionsReview2.tsx",
                    lineNumber: 937,
                    columnNumber: 46
                }, ("TURBOPACK compile-time value", void 0)),
                children: t('questionsReview.noQuestions')
            }, void 0, false, {
                fileName: "[project]/src/components/QuestionsReview2.tsx",
                lineNumber: 937,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/QuestionsReview2.tsx",
            lineNumber: 934,
            columnNumber: 12
        }, ("TURBOPACK compile-time value", void 0));
    }
    const alreadyImported = !!parsedContent.importedAt;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
            overflow: 'hidden'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    p: 2,
                    flexShrink: 0
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "h6",
                        gutterBottom: true,
                        sx: {
                            fontWeight: 600
                        },
                        children: t('questionsReview.sectionHeading')
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 954,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    document && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "text.secondary",
                        gutterBottom: true,
                        children: [
                            t('questionsReview.from'),
                            ": ",
                            document.filename,
                            document.pageCount && ` (${document.pageCount} ${t('questionsReview.pages')})`
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 959,
                        columnNumber: 30
                    }, ("TURBOPACK compile-time value", void 0)),
                    alreadyImported && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                        severity: "success",
                        sx: {
                            mt: 1
                        },
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CheckCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/QuestionsReview2.tsx",
                            lineNumber: 966,
                            columnNumber: 16
                        }, ("TURBOPACK compile-time value", void 0)),
                        children: t('questionsReview.importedOn', {
                            date: new Date(parsedContent.importedAt).toLocaleString()
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 964,
                        columnNumber: 37
                    }, ("TURBOPACK compile-time value", void 0)),
                    searchTerm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                        severity: "info",
                        sx: {
                            mt: 1
                        },
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/QuestionsReview2.tsx",
                            lineNumber: 974,
                            columnNumber: 16
                        }, ("TURBOPACK compile-time value", void 0)),
                        children: t('questionsReview.filteringBySearch', {
                            searchTerm,
                            count: filteredQuestions.length,
                            total: questionItems.length
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 972,
                        columnNumber: 32
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/QuestionsReview2.tsx",
                lineNumber: 950,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            (summaries.length > 0 || objectives.length > 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    px: 2,
                    pb: 1,
                    flexShrink: 0
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        size: "small",
                        onClick: ()=>dispatch({
                                type: 'TOGGLE_SUMMARIES'
                            }),
                        endIcon: showSummaries ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandLess$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/QuestionsReview2.tsx",
                            lineNumber: 991,
                            columnNumber: 36
                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ExpandMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/QuestionsReview2.tsx",
                            lineNumber: 991,
                            columnNumber: 57
                        }, ("TURBOPACK compile-time value", void 0)),
                        variant: "outlined",
                        children: [
                            showSummaries ? t('questionsReview.hide') : t('questionsReview.show'),
                            " ",
                            t('questionsReview.summariesAndObjectives')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 989,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Collapse$3e$__["Collapse"], {
                        in: showSummaries,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
                            elevation: 0,
                            sx: {
                                p: 2,
                                mt: 1,
                                bgcolor: 'action.hover'
                            },
                            children: [
                                summaries.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        mb: 2
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "subtitle2",
                                            gutterBottom: true,
                                            fontWeight: 600,
                                            children: t('questionsReview.summaries')
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/QuestionsReview2.tsx",
                                            lineNumber: 1003,
                                            columnNumber: 37
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        summaries.map((summary, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                sx: {
                                                    mb: 1
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "body2",
                                                        fontWeight: "bold",
                                                        children: summary.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                                                        lineNumber: 1009,
                                                        columnNumber: 45
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "body2",
                                                        color: "text.secondary",
                                                        children: summary.content
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                                                        lineNumber: 1012,
                                                        columnNumber: 45
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, i, true, {
                                                fileName: "[project]/src/components/QuestionsReview2.tsx",
                                                lineNumber: 1006,
                                                columnNumber: 68
                                            }, ("TURBOPACK compile-time value", void 0)))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/QuestionsReview2.tsx",
                                    lineNumber: 1000,
                                    columnNumber: 54
                                }, ("TURBOPACK compile-time value", void 0)),
                                objectives.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "subtitle2",
                                            gutterBottom: true,
                                            fontWeight: 600,
                                            children: t('questionsReview.learningObjectives')
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/QuestionsReview2.tsx",
                                            lineNumber: 1018,
                                            columnNumber: 37
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                            dense: true,
                                            children: objectives.map((obj, i_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                                    sx: {
                                                        py: 0.5
                                                    },
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                        variant: "body2",
                                                        children: [
                                                            "• ",
                                                            obj.objective
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                                                        lineNumber: 1025,
                                                        columnNumber: 49
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, i_0, false, {
                                                    fileName: "[project]/src/components/QuestionsReview2.tsx",
                                                    lineNumber: 1022,
                                                    columnNumber: 71
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/QuestionsReview2.tsx",
                                            lineNumber: 1021,
                                            columnNumber: 37
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/QuestionsReview2.tsx",
                                    lineNumber: 1017,
                                    columnNumber: 55
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/QuestionsReview2.tsx",
                            lineNumber: 995,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 994,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/QuestionsReview2.tsx",
                lineNumber: 984,
                columnNumber: 65
            }, ("TURBOPACK compile-time value", void 0)),
            !alreadyImported && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    px: 2,
                    pb: 1,
                    display: 'flex',
                    gap: 1,
                    alignItems: 'center',
                    flexShrink: 0
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        variant: "outlined",
                        size: "small",
                        onClick: toggleAll,
                        children: selectedItems.size === questionItems.length ? t('questionsReview.deselectAll') : t('questionsReview.selectAll')
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 1044,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        color: "text.secondary",
                        children: t('questionsReview.selectedCount', {
                            count: selectedItems.size,
                            total: questionItems.length
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 1047,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            flex: 1
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 1053,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        variant: "contained",
                        startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/QuestionsReview2.tsx",
                            lineNumber: 1056,
                            columnNumber: 60
                        }, ("TURBOPACK compile-time value", void 0)),
                        onClick: handleImport,
                        disabled: importing || selectedItems.size === 0,
                        children: t('questionsReview.importToQuestionBank')
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 1056,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/QuestionsReview2.tsx",
                lineNumber: 1036,
                columnNumber: 34
            }, ("TURBOPACK compile-time value", void 0)),
            importing && importProgress && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    px: 2,
                    pb: 1,
                    flexShrink: 0
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {
                        variant: "determinate",
                        value: importProgress.current / importProgress.total * 100
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 1067,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "body2",
                        sx: {
                            mt: 0.5,
                            textAlign: 'center'
                        },
                        children: importProgress.message
                    }, void 0, false, {
                        fileName: "[project]/src/components/QuestionsReview2.tsx",
                        lineNumber: 1068,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/QuestionsReview2.tsx",
                lineNumber: 1062,
                columnNumber: 45
            }, ("TURBOPACK compile-time value", void 0)),
            importResult && !importing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    px: 2,
                    pb: 1,
                    flexShrink: 0
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                    severity: importResult.success ? 'success' : 'error',
                    onClose: ()=>dispatch({
                            type: 'CLEAR_IMPORT_RESULT'
                        }),
                    children: importResult.message || `Imported ${importResult.imported} new questions, ${importResult.skipped} already existed, ${importResult.errors} errors`
                }, void 0, false, {
                    fileName: "[project]/src/components/QuestionsReview2.tsx",
                    lineNumber: 1082,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/QuestionsReview2.tsx",
                lineNumber: 1077,
                columnNumber: 44
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
                ref: parentRef,
                elevation: 2,
                sx: {
                    flex: 1,
                    overflow: 'auto',
                    mx: 2,
                    mb: 2
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                    sx: {
                        height: virtualizer.getTotalSize(),
                        position: 'relative',
                        padding: 0
                    },
                    children: virtualizer.getVirtualItems().map((virtualItem)=>{
                        const item_1 = filteredQuestions[virtualItem.index];
                        const existsInQuestionBank = questionBank && Object.values(questionBank).some((q_0)=>q_0.prompt?.toLowerCase().trim() === item_1.prompt?.toLowerCase().trim());
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            "data-index": virtualItem.index,
                            ref: virtualizer.measureElement,
                            sx: {
                                position: 'absolute',
                                top: 0,
                                left: 0,
                                width: '100%',
                                transform: `translateY(${virtualItem.start}px)`
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(QuestionCard, {
                                item: item_1,
                                index: virtualItem.index,
                                isSelected: selectedItems.has(virtualItem.index),
                                isExpanded: expandedItems.has(virtualItem.index),
                                existsInQuestionBank: existsInQuestionBank,
                                alreadyImported: alreadyImported,
                                searchTerm: searchTerm,
                                onToggleSelect: toggleItem,
                                onToggleExpand: toggleExpand,
                                onUpdate: handleUpdate
                            }, void 0, false, {
                                fileName: "[project]/src/components/QuestionsReview2.tsx",
                                lineNumber: 1111,
                                columnNumber: 33
                            }, ("TURBOPACK compile-time value", void 0))
                        }, virtualItem.key, false, {
                            fileName: "[project]/src/components/QuestionsReview2.tsx",
                            lineNumber: 1104,
                            columnNumber: 18
                        }, ("TURBOPACK compile-time value", void 0));
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/QuestionsReview2.tsx",
                    lineNumber: 1096,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/QuestionsReview2.tsx",
                lineNumber: 1090,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/QuestionsReview2.tsx",
        lineNumber: 943,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s2(QuestionsReview2, "3KfF4o/rnqS8pvaX7kt/9hSCdDo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"]
    ];
});
_c2 = QuestionsReview2;
const __TURBOPACK__default__export__ = QuestionsReview2;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "NestedQuestionField");
__turbopack_context__.k.register(_c1, "QuestionCard");
__turbopack_context__.k.register(_c2, "QuestionsReview2");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RecordingStudio3.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * RecordingStudio3 - Advanced Dialogue Recording and TTS Generation
 *
 * Features:
 * - Script-based dialogue format with speakers, timing, emotions, and directions
 * - Multiple takes per dialogue line (human recordings or TTS generated)
 * - Locked tracks mode for model-bound recordings (Word, Question)
 * - Timeline view with waveform visualization
 * - Batch TTS generation
 * - Non-destructive editing (all takes preserved)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/sectionContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript) <export default as Paper>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Select/Select.js [app-client] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControl/FormControl.js [app-client] (ecmascript) <export default as FormControl>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputLabel/InputLabel.js [app-client] (ecmascript) <export default as InputLabel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Badge/Badge.js [app-client] (ecmascript) <export default as Badge>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Star.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$StarBorder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/StarBorder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Add.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Delete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Upload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Upload.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Download.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$GraphicEq$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/GraphicEq.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$userSubmissionStorage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/userSubmissionStorage.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calculateWaveformData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/calculateWaveformData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getCachedUrl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$274953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:274953 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$f8e400__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:f8e400 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$takeVersioning$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/takeVersioning.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$processAndUploadTake$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/processAndUploadTake.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$ScreenplayEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudio3/ScreenplayEditor.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$HorizontalTimeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudio3/HorizontalTimeline.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$AudioFilterPanel$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudio3/AudioFilterPanel.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$TakeVersionHistory$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudio3/TakeVersionHistory.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$parseFountainToScriptData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudio3/parseFountainToScriptData.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Available TTS voices
const TTS_VOICES = [
    {
        value: "alloy",
        label: "Alloy (Neutral)"
    },
    {
        value: "echo",
        label: "Echo (Male)"
    },
    {
        value: "fable",
        label: "Fable (British Male)"
    },
    {
        value: "onyx",
        label: "Onyx (Deep Male)"
    },
    {
        value: "nova",
        label: "Nova (Female)"
    },
    {
        value: "shimmer",
        label: "Shimmer (Soft Female)"
    }
];
const __TURBOPACK__default__export__ = /*#__PURE__*/ _c1 = _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s(function RecordingStudio3({ scriptData: initialScriptData, onScriptChange, onUpdateData, lockedTracks = [], gradeId, nodeKey, identityId, readOnly = false }, ref) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    // Course context for AI generation
    const { currentUnit, dictionary } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const { sections, assignments } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$sectionContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const courseOutline = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "RecordingStudio3.useMemo[courseOutline]": ()=>{
            if (!currentUnit?.id || !assignments?.length || !sections?.length) return null;
            const sectionIds = assignments.filter({
                "RecordingStudio3.useMemo[courseOutline].sectionIds": (a)=>a.unitID === currentUnit.id
            }["RecordingStudio3.useMemo[courseOutline].sectionIds"]).map({
                "RecordingStudio3.useMemo[courseOutline].sectionIds": (a_0)=>a_0.sectionID
            }["RecordingStudio3.useMemo[courseOutline].sectionIds"]);
            for (const sId of sectionIds){
                const section = sections.find({
                    "RecordingStudio3.useMemo[courseOutline].section": (s)=>s.id === sId
                }["RecordingStudio3.useMemo[courseOutline].section"]);
                if (section?.courseOutline) {
                    try {
                        return typeof section.courseOutline === "string" ? JSON.parse(section.courseOutline) : section.courseOutline;
                    } catch  {
                    /* skip */ }
                }
            }
            return null;
        }
    }["RecordingStudio3.useMemo[courseOutline]"], [
        currentUnit?.id,
        assignments,
        sections
    ]);
    // Script data state
    const [scriptData, setScriptData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialScriptData || {
        metadata: {
            title: "New Recording",
            scene: "",
            date: new Date().toISOString().split("T")[0],
            version: "1.0"
        },
        speakers: {},
        dialogue: []
    });
    // UI state
    const [selectedDialogueId, setSelectedDialogueId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [playing, setPlaying] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentTime, setCurrentTime] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [recordingMode, setRecordingMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("overdub"); // 'overdub', 'punch-in', 'replace'
    const [ttsQueue, setTtsQueue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isGenerating, setIsGenerating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeFilters, setActiveFilters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    // Fountain screenplay text — bidirectional sync with scriptData
    const [fountainText, setFountainText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "RecordingStudio3.useState": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$parseFountainToScriptData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scriptDataToFountain"])(initialScriptData || {
                metadata: {
                    title: "",
                    scene: "",
                    date: "",
                    version: "1.0"
                },
                speakers: {},
                dialogue: []
            })
    }["RecordingStudio3.useState"]);
    // Refs
    const playbackTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Get selected dialogue line
    const selectedDialogue = scriptData.dialogue.find((d)=>d.id === selectedDialogueId);
    const selectedSpeaker = selectedDialogue ? scriptData.speakers[selectedDialogue.speaker] : null;
    // Persist filter changes to the active take's File record and re-process audio
    const handleFiltersChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RecordingStudio3.useCallback[handleFiltersChange]": async (newFilters)=>{
            setActiveFilters(newFilters);
            // Find the active take for the selected dialogue
            if (!selectedDialogue) return;
            const takes = selectedDialogue.takes || [];
            const activeTake = takes[selectedDialogue.activeTakeIndex ?? takes.length - 1];
            if (!activeTake?.fileId && !activeTake?.audioPath) return;
            const filterArray = [
                ...newFilters
            ];
            // Save filter settings to File.settings if we have a fileId
            if (activeTake.fileId) {
                try {
                    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                    const { data: fileRecord } = await client.models.File.get({
                        id: activeTake.fileId
                    });
                    if (fileRecord) {
                        const existingSettings = typeof fileRecord.settings === "string" ? JSON.parse(fileRecord.settings) : fileRecord.settings || {};
                        await client.models.File.update({
                            id: activeTake.fileId,
                            settings: JSON.stringify({
                                ...existingSettings,
                                audioFilters: filterArray
                            }),
                            _version: fileRecord._version
                        });
                    }
                } catch (err) {
                    console.warn("[RecordingStudio3] Failed to save filter settings:", err);
                }
            }
            // Re-process audio from raw and upload processed copy
            const rawPath = activeTake.audioPath;
            if (rawPath && filterArray.length > 0) {
                try {
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$processAndUploadTake$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["processAndUploadTake"])(rawPath, newFilters);
                    console.log("[RecordingStudio3] Re-processed take with filters:", filterArray);
                } catch (err_0) {
                    console.warn("[RecordingStudio3] Failed to process take:", err_0);
                }
            }
        }
    }["RecordingStudio3.useCallback[handleFiltersChange]"], [
        selectedDialogue
    ]);
    // Load saved filters from the active take's File record when selection changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RecordingStudio3.useEffect": ()=>{
            if (!selectedDialogue) return;
            const takes_0 = selectedDialogue.takes || [];
            const activeTake_0 = takes_0[selectedDialogue.activeTakeIndex ?? takes_0.length - 1];
            if (!activeTake_0?.fileId) return;
            let cancelled = false;
            ({
                "RecordingStudio3.useEffect": async ()=>{
                    try {
                        const client_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
                        const { data: fileRecord_0 } = await client_0.models.File.get({
                            id: activeTake_0.fileId
                        });
                        if (cancelled) return;
                        const settings = typeof fileRecord_0?.settings === "string" ? JSON.parse(fileRecord_0.settings) : fileRecord_0?.settings;
                        if (settings?.audioFilters) {
                            setActiveFilters(new Set(settings.audioFilters));
                        } else {
                            setActiveFilters(new Set());
                        }
                    } catch  {
                    // Silently skip — filters default to empty
                    }
                }
            })["RecordingStudio3.useEffect"]();
            return ({
                "RecordingStudio3.useEffect": ()=>{
                    cancelled = true;
                }
            })["RecordingStudio3.useEffect"];
        }
    }["RecordingStudio3.useEffect"], [
        selectedDialogue?.id,
        selectedDialogue?.activeTakeIndex
    ]);
    // Check if track is locked
    const isTrackLocked = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RecordingStudio3.useCallback[isTrackLocked]": (speakerId)=>{
            return lockedTracks.includes(speakerId);
        }
    }["RecordingStudio3.useCallback[isTrackLocked]"], [
        lockedTracks
    ]);
    // Update script data and notify parent
    const updateScriptData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RecordingStudio3.useCallback[updateScriptData]": (updates, updateType = null, updatePayload = null)=>{
            setScriptData({
                "RecordingStudio3.useCallback[updateScriptData]": (prev)=>{
                    const newData = {
                        ...prev,
                        ...updates
                    };
                    // Call onScriptChange with full data
                    if (onScriptChange) {
                        onScriptChange(newData);
                    }
                    // Call onUpdateData with granular update info
                    if (onUpdateData && updateType) {
                        onUpdateData({
                            type: updateType,
                            payload: updatePayload,
                            scriptData: newData
                        });
                    }
                    return newData;
                }
            }["RecordingStudio3.useCallback[updateScriptData]"]);
        }
    }["RecordingStudio3.useCallback[updateScriptData]"], [
        onScriptChange,
        onUpdateData
    ]);
    // Add new speaker
    const handleAddSpeaker = ()=>{
        const speakerId_0 = `speaker_${Date.now()}`;
        const newSpeaker = {
            name: "New Speaker",
            voice: "alloy",
            description: ""
        };
        updateScriptData({
            ...scriptData,
            speakers: {
                ...scriptData.speakers,
                [speakerId_0]: newSpeaker
            }
        }, "SPEAKER_ADDED", {
            speakerId: speakerId_0,
            speaker: newSpeaker
        });
    };
    // Update speaker
    const handleUpdateSpeaker = (speakerId_1, updates_0)=>{
        if (isTrackLocked(speakerId_1) && updates_0.name !== undefined) {
            console.warn("Cannot update locked speaker name");
            return;
        }
        updateScriptData({
            ...scriptData,
            speakers: {
                ...scriptData.speakers,
                [speakerId_1]: {
                    ...scriptData.speakers[speakerId_1],
                    ...updates_0
                }
            }
        }, "SPEAKER_UPDATED", {
            speakerId: speakerId_1,
            updates: updates_0
        });
    };
    // Delete speaker
    const handleDeleteSpeaker = (speakerId_2)=>{
        if (isTrackLocked(speakerId_2)) {
            console.warn("Cannot delete locked speaker");
            return;
        }
        const { [speakerId_2]: removed, ...remainingSpeakers } = scriptData.speakers;
        const updatedDialogue = scriptData.dialogue.filter((d_0)=>d_0.speaker !== speakerId_2);
        updateScriptData({
            ...scriptData,
            speakers: remainingSpeakers,
            dialogue: updatedDialogue
        }, "SPEAKER_DELETED", {
            speakerId: speakerId_2,
            removedSpeaker: removed
        });
    };
    // Add dialogue line
    const handleAddDialogueLine = ()=>{
        const speakerIds = Object.keys(scriptData.speakers);
        if (speakerIds.length === 0) {
            alert(t("recordingStudio3.addSpeakerFirst"));
            return;
        }
        const newLine = {
            id: Date.now(),
            speaker: speakerIds[0],
            text: "",
            timing: {
                start: 0,
                end: 0
            },
            direction: "",
            emotion: "",
            takes: [],
            activeTakeIndex: null
        };
        updateScriptData({
            ...scriptData,
            dialogue: [
                ...scriptData.dialogue,
                newLine
            ]
        }, "DIALOGUE_ADDED", {
            dialogueId: newLine.id,
            dialogue: newLine
        });
        setSelectedDialogueId(newLine.id);
    };
    // Update dialogue line
    const handleUpdateDialogueLine = (dialogueId, updates_1)=>{
        updateScriptData({
            ...scriptData,
            dialogue: scriptData.dialogue.map((d_1)=>d_1.id === dialogueId ? Object.assign({}, d_1, updates_1) : d_1)
        }, "DIALOGUE_UPDATED", {
            dialogueId,
            updates: updates_1
        });
    };
    // Delete dialogue line
    const handleDeleteDialogueLine = (dialogueId_0)=>{
        const deletedDialogue = scriptData.dialogue.find((d_2)=>d_2.id === dialogueId_0);
        updateScriptData({
            ...scriptData,
            dialogue: scriptData.dialogue.filter((d_3)=>d_3.id !== dialogueId_0)
        }, "DIALOGUE_DELETED", {
            dialogueId: dialogueId_0,
            dialogue: deletedDialogue
        });
        if (selectedDialogueId === dialogueId_0) {
            setSelectedDialogueId(null);
        }
    };
    // Handle recording from AudioWaveformPlayer
    const handleAudioWaveformRecordingComplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RecordingStudio3.useCallback[handleAudioWaveformRecordingComplete]": async (file)=>{
            if (!selectedDialogue) return;
            // file is { path: blobURL } or a saved File record
            // Fetch the blob from the URL for handleRecordingComplete
            try {
                const response = await fetch(file.path);
                const audioBlob = await response.blob();
                await handleRecordingComplete(audioBlob, "human");
            } catch (error) {
                console.error("Error processing AudioWaveformPlayer recording:", error);
            }
        }
    }["RecordingStudio3.useCallback[handleAudioWaveformRecordingComplete]"], [
        selectedDialogue
    ]);
    // Handle completed recording
    const handleRecordingComplete = async (audioBlob_0, type = "human", cinematicMetadata = null, existingTake = null // Pass an existing take for re-record (version increment)
    )=>{
        if (!selectedDialogue) return;
        try {
            // Calculate waveform
            const waveformData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calculateWaveformData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateWaveformData"])(audioBlob_0, 600);
            // For re-records, reuse the existing slotId and increment version
            const slotId = existingTake?.id && typeof existingTake.id === "string" ? existingTake.id : crypto.randomUUID();
            const version = existingTake?.version ? existingTake.version + 1 : 1;
            const ext = type === "tts" ? "mp3" : "webm";
            // Upload to S3 if gradeId and nodeKey provided
            let audioPath = null;
            let fileId = null;
            if (gradeId && nodeKey && identityId) {
                const versionedKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$takeVersioning$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildVersionedKey"])(identityId, selectedDialogue.id, slotId, version, ext);
                const uploadResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$userSubmissionStorage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadStudentSubmission"])({
                    file: audioBlob_0,
                    gradeId,
                    nodeKey: versionedKey,
                    fileType: ext,
                    metadata: {
                        dialogueId: selectedDialogue.id,
                        speaker: selectedDialogue.speaker,
                        text: selectedDialogue.text,
                        scene: scriptData.metadata.scene,
                        direction: selectedDialogue.direction,
                        emotion: selectedDialogue.emotion,
                        ...cinematicMetadata
                    }
                });
                audioPath = uploadResult.path;
                fileId = uploadResult.fileId || null;
            }
            // Determine which processing was applied (for metadata/debugging)
            const processingApplied = type === "human" ? [
                ...activeFilters.size > 0 ? activeFilters : new Set([
                    "derumble",
                    "compress",
                    "normalize"
                ])
            ] : [];
            // Create new take with file metadata and cinematic context
            const newTake = {
                id: slotId,
                type,
                // 'human' or 'tts'
                version,
                processingApplied,
                // Filter names applied before upload
                audioBlob: audioPath ? null : audioBlob_0,
                // Store blob if not uploaded
                audioPath,
                // S3 path if uploaded
                fileId,
                // DynamoDB File record ID
                waveformData,
                // Waveform data for visualization
                duration: audioBlob_0.size ? 0 : 0,
                // Will be calculated from actual audio
                file: audioPath ? {
                    key: audioPath,
                    level: "protected",
                    identityId: identityId,
                    type: audioBlob_0.type || "audio/mpeg",
                    size: audioBlob_0.size
                } : null,
                cinematicMetadata,
                // Store scene, direction, emotion context
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            // Add take to dialogue line
            const existingTakes = selectedDialogue.takes || [];
            const updatedTakes = [
                ...existingTakes,
                newTake
            ];
            // Update with specific TAKE_ADDED event
            updateScriptData({
                ...scriptData,
                dialogue: scriptData.dialogue.map((d_4)=>d_4.id === selectedDialogue.id ? {
                        ...d_4,
                        takes: updatedTakes,
                        activeTakeIndex: updatedTakes.length - 1
                    } : d_4)
            }, "TAKE_ADDED", {
                dialogueId: selectedDialogue.id,
                take: newTake,
                takeIndex: updatedTakes.length - 1
            });
        } catch (error_0) {
            console.error("Error processing recording:", error_0);
            alert(t("recordingStudio3.saveRecordingFailed"));
        }
    };
    // Generate TTS for dialogue line
    const handleGenerateTTS = async (dialogueId_1)=>{
        const dialogue = scriptData.dialogue.find((d_5)=>d_5.id === dialogueId_1);
        if (!dialogue || !dialogue.text) {
            alert(t("recordingStudio3.noTextToGenerate"));
            return;
        }
        const speaker = scriptData.speakers[dialogue.speaker];
        if (!speaker) {
            alert(t("recordingStudio3.speakerNotFound"));
            return;
        }
        setIsGenerating(true);
        try {
            // Build cinematic context for TTS generation
            const contextParts = [];
            // Add scene context
            if (scriptData.metadata.scene) {
                contextParts.push(`Scene: ${scriptData.metadata.scene}`);
            }
            // Add character description
            if (speaker.description) {
                contextParts.push(`Character: ${speaker.name} (${speaker.description})`);
            }
            // Add direction notes
            if (dialogue.direction) {
                contextParts.push(`Direction: ${dialogue.direction}`);
            }
            // Add emotional context
            if (dialogue.emotion) {
                contextParts.push(`Emotion: ${dialogue.emotion}`);
            }
            const cinematicContext = contextParts.length > 0 ? contextParts.join(" | ") : null;
            // Server Action for TTS generation
            const ttsResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$274953__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateSpeech"])({
                phrase: dialogue.text,
                voice: speaker.voice || "alloy",
                model: "tts-1-hd"
            });
            // Get audio URL
            const audioUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getCachedUrl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ttsResult.path);
            // Fetch audio as blob
            const audioResponse = await fetch(audioUrl);
            const audioBlob_1 = await audioResponse.blob();
            // Process as TTS recording with cinematic metadata
            await handleRecordingComplete(audioBlob_1, "tts", {
                cinematicContext,
                scene: scriptData.metadata.scene,
                direction: dialogue.direction,
                emotion: dialogue.emotion,
                characterDescription: speaker.description
            });
        } catch (error_1) {
            console.error("Error generating TTS:", error_1);
            alert(t("recordingStudio3.ttsGenerationFailed"));
        } finally{
            setIsGenerating(false);
        }
    };
    // Batch generate TTS for all missing
    const handleBatchGenerateTTS = async ()=>{
        const missingLines = scriptData.dialogue.filter((d_6)=>d_6.text && (!d_6.takes || d_6.takes.length === 0));
        if (missingLines.length === 0) {
            alert(t("recordingStudio3.noMissingAudio"));
            return;
        }
        setTtsQueue(missingLines.map((line)=>line.id));
        for (const line_0 of missingLines){
            await handleGenerateTTS(line_0.id);
            setTtsQueue((prev_0)=>prev_0.filter((id)=>id !== line_0.id));
        }
    };
    // Expose imperative API for parent (e.g., RecordingStudio3Modal)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(ref, {
        "RecordingStudio3.useImperativeHandle": ()=>({
                triggerBatchTTS: handleBatchGenerateTTS
            })
    }["RecordingStudio3.useImperativeHandle"], [
        handleBatchGenerateTTS
    ]);
    // Set active take
    const handleSetActiveTake = (dialogueId_2, takeIndex)=>{
        updateScriptData({
            ...scriptData,
            dialogue: scriptData.dialogue.map((d_7)=>d_7.id === dialogueId_2 ? {
                    ...d_7,
                    activeTakeIndex: takeIndex
                } : d_7)
        }, "ACTIVE_TAKE_CHANGED", {
            dialogueId: dialogueId_2,
            takeIndex
        });
    };
    // Delete take
    const handleDeleteTake = (dialogueId_3, takeIndex_0)=>{
        const dialogue_0 = scriptData.dialogue.find((d_8)=>d_8.id === dialogueId_3);
        if (!dialogue_0) return;
        const deletedTake = dialogue_0.takes[takeIndex_0];
        const updatedTakes_0 = dialogue_0.takes.filter((_, idx)=>idx !== takeIndex_0);
        const newActiveTakeIndex = dialogue_0.activeTakeIndex === takeIndex_0 ? updatedTakes_0.length > 0 ? 0 : null : dialogue_0.activeTakeIndex > takeIndex_0 ? dialogue_0.activeTakeIndex - 1 : dialogue_0.activeTakeIndex;
        updateScriptData({
            ...scriptData,
            dialogue: scriptData.dialogue.map((d_9)=>d_9.id === dialogueId_3 ? {
                    ...d_9,
                    takes: updatedTakes_0,
                    activeTakeIndex: newActiveTakeIndex
                } : d_9)
        }, "TAKE_DELETED", {
            dialogueId: dialogueId_3,
            takeIndex: takeIndex_0,
            take: deletedTake
        });
    };
    // Rollback take to a previous version (restores audioPath without new S3 write)
    const handleRollbackTake = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RecordingStudio3.useCallback[handleRollbackTake]": async (dialogueId_4, slotId_0, versionKey)=>{
            updateScriptData({
                ...scriptData,
                dialogue: scriptData.dialogue.map({
                    "RecordingStudio3.useCallback[handleRollbackTake]": (d_10)=>{
                        if (d_10.id !== dialogueId_4) return d_10;
                        const updatedTakes_1 = d_10.takes.map({
                            "RecordingStudio3.useCallback[handleRollbackTake].updatedTakes_1": (take)=>{
                                if (take.id !== slotId_0) return take;
                                return {
                                    ...take,
                                    audioPath: versionKey,
                                    file: take.file ? {
                                        ...take.file,
                                        key: versionKey
                                    } : null,
                                    updatedAt: new Date().toISOString()
                                };
                            }
                        }["RecordingStudio3.useCallback[handleRollbackTake].updatedTakes_1"]);
                        return {
                            ...d_10,
                            takes: updatedTakes_1
                        };
                    }
                }["RecordingStudio3.useCallback[handleRollbackTake]"])
            }, "TAKE_ROLLBACK", {
                dialogueId: dialogueId_4,
                slotId: slotId_0,
                versionKey
            });
        }
    }["RecordingStudio3.useCallback[handleRollbackTake]"], [
        scriptData,
        updateScriptData
    ]);
    // Export script as JSON
    const handleExportJSON = ()=>{
        const dataStr = JSON.stringify(scriptData, null, 2);
        const dataBlob = new Blob([
            dataStr
        ], {
            type: "application/json"
        });
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `${scriptData.metadata.title || "script"}.json`;
        link.click();
        URL.revokeObjectURL(url);
    };
    // Import script from JSON
    const handleImportJSON = (event)=>{
        const file_0 = event.target.files?.[0];
        if (!file_0) return;
        const reader = new FileReader();
        reader.onload = (e)=>{
            try {
                const imported = JSON.parse(e.target.result);
                setScriptData(imported);
                setFountainText((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$parseFountainToScriptData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scriptDataToFountain"])(imported));
                if (onScriptChange) {
                    onScriptChange(imported);
                }
            } catch (error_2) {
                console.error("Error importing JSON:", error_2);
                alert(t("recordingStudio3.importFailed"));
            }
        };
        reader.readAsText(file_0);
    };
    // Handle AI prompt submission — generate/modify Fountain screenplay
    const handlePromptSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RecordingStudio3.useCallback[handlePromptSubmit]": async (prompt)=>{
            setIsGenerating(true);
            try {
                const systemParts = [
                    "You are a screenplay writer. Output ONLY valid Fountain format text, no explanation.",
                    "Fountain format rules:",
                    '- Title page: "Title: ..." and "Date: ..." at the top, followed by a blank line',
                    "- Scene headings: lines starting with INT. or EXT.",
                    "- Character names: UPPERCASE on their own line before dialogue",
                    "- Dialogue: normal text on the line after the character name",
                    "- Parentheticals: (emotion) between character name and dialogue",
                    "- Notes: [[direction notes]] inside dialogue text",
                    "- Blank line between each dialogue block"
                ];
                // Add course context for progression-aware dialogue
                if (currentUnit) {
                    systemParts.push(`\nCurrent Unit: ${currentUnit.name}${currentUnit.description ? ` — ${currentUnit.description}` : ""}`);
                }
                if (courseOutline && courseOutline.length > 0) {
                    systemParts.push("\nCourse progression:");
                    for (const entry of courseOutline){
                        const marker = entry.unitId === currentUnit?.id ? " ← CURRENT" : "";
                        systemParts.push(`  ${entry.number != null ? `${entry.number}. ` : "• "}${entry.name}${marker}`);
                    }
                }
                if (dictionary && Object.keys(dictionary).length > 0) {
                    const vocabList = Object.values(dictionary).filter({
                        "RecordingStudio3.useCallback[handlePromptSubmit].vocabList": (w)=>w?.phrase
                    }["RecordingStudio3.useCallback[handlePromptSubmit].vocabList"]).slice(0, 15).map({
                        "RecordingStudio3.useCallback[handlePromptSubmit].vocabList": (w_0)=>`${w_0.phrase}${w_0.definition ? ` (${w_0.definition})` : ""}`
                    }["RecordingStudio3.useCallback[handlePromptSubmit].vocabList"]).join(", ");
                    if (vocabList) {
                        systemParts.push(`\nUnit vocabulary to incorporate: ${vocabList}`);
                    }
                }
                const systemMessage = systemParts.join("\n");
                // Include current script as context if it exists
                const currentContext = scriptData.dialogue.length > 0 ? `\n\nCurrent screenplay:\n${fountainText}\n\nModify or extend the above based on the user request.` : "";
                const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$f8e400__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["chatCompletion"])({
                    messages: [
                        {
                            role: "system",
                            content: systemMessage + currentContext
                        },
                        {
                            role: "user",
                            content: prompt
                        }
                    ]
                });
                if (data) {
                    const newFountain = data.trim();
                    setFountainText(newFountain);
                    // Parse into scriptData
                    const existingVoices = {};
                    for (const [key, speaker_0] of Object.entries(scriptData.speakers)){
                        existingVoices[key] = speaker_0.voice;
                    }
                    const parsed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$parseFountainToScriptData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseFountainToScriptData"])(newFountain, existingVoices);
                    updateScriptData(parsed, "AI_GENERATE", {
                        prompt
                    });
                }
            } catch (err_1) {
                console.error("AI script generation failed:", err_1);
                alert(t("recordingStudio3.aiGenerationFailed", "Failed to generate script. Please try again."));
            } finally{
                setIsGenerating(false);
            }
        }
    }["RecordingStudio3.useCallback[handlePromptSubmit]"], [
        scriptData.speakers,
        scriptData.dialogue.length,
        fountainText,
        updateScriptData,
        currentUnit,
        courseOutline,
        dictionary,
        t
    ]);
    // Handle Fountain editor changes — re-parse into scriptData, preserving takes
    const handleFountainChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RecordingStudio3.useCallback[handleFountainChange]": (newText)=>{
            setFountainText(newText);
            try {
                // Build existing voice map so parser preserves voice assignments
                const existingVoices_0 = {};
                for (const [key_0, speaker_1] of Object.entries(scriptData.speakers)){
                    existingVoices_0[key_0] = speaker_1.voice;
                }
                const parsed_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$parseFountainToScriptData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseFountainToScriptData"])(newText, existingVoices_0);
                // Preserve takes from current dialogue lines by matching on speaker+text
                const takesMap = new Map();
                for (const line_1 of scriptData.dialogue){
                    const key_1 = `${line_1.speaker}::${line_1.text}`;
                    if (line_1.takes?.length > 0) {
                        takesMap.set(key_1, {
                            takes: line_1.takes,
                            activeTakeIndex: line_1.activeTakeIndex
                        });
                    }
                }
                for (const line_2 of parsed_0.dialogue){
                    const key_2 = `${line_2.speaker}::${line_2.text}`;
                    const existing = takesMap.get(key_2);
                    if (existing) {
                        line_2.takes = existing.takes;
                        line_2.activeTakeIndex = existing.activeTakeIndex;
                    }
                }
                updateScriptData(parsed_0, "FOUNTAIN_CHANGE", {
                    fountainText: newText
                });
            } catch (err_2) {
                console.warn("Fountain parse error (waiting for valid text):", err_2);
            }
        }
    }["RecordingStudio3.useCallback[handleFountainChange]"], [
        scriptData.speakers,
        scriptData.dialogue,
        updateScriptData
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            height: "100vh",
            display: "flex",
            flexDirection: "column"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
                sx: {
                    p: 1.5,
                    borderRadius: 0
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                    direction: "row",
                    spacing: 2,
                    alignItems: "center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "h6",
                            sx: {
                                flex: 1
                            },
                            children: scriptData.metadata.title
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                            lineNumber: 773,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$GraphicEq$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                lineNumber: 779,
                                columnNumber: 30
                            }, this),
                            onClick: handleBatchGenerateTTS,
                            disabled: readOnly || isGenerating,
                            variant: "contained",
                            size: "small",
                            children: t("recordingStudio3.generateAllMissing")
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                            lineNumber: 779,
                            columnNumber: 11
                        }, this),
                        ttsQueue.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                width: 120
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {}, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                lineNumber: 785,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                            lineNumber: 782,
                            columnNumber: 35
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "file",
                            accept: "application/json",
                            style: {
                                display: "none"
                            },
                            id: "import-json-input",
                            onChange: handleImportJSON
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                            lineNumber: 788,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            htmlFor: "import-json-input",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                component: "span",
                                startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Upload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                    lineNumber: 792,
                                    columnNumber: 49
                                }, this),
                                variant: "outlined",
                                size: "small",
                                children: t("recordingStudio3.importJson")
                            }, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                lineNumber: 792,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                            lineNumber: 791,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                lineNumber: 797,
                                columnNumber: 30
                            }, this),
                            onClick: handleExportJSON,
                            variant: "outlined",
                            size: "small",
                            children: t("recordingStudio3.exportJson")
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                            lineNumber: 797,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                    lineNumber: 772,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/RecordingStudio3.jsx",
                lineNumber: 768,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    flex: 1,
                    overflow: "hidden",
                    minHeight: 0
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        sx: {
                            flex: 1,
                            display: "flex",
                            flexDirection: "column",
                            overflow: "hidden"
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$ScreenplayEditor$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            fountainText: fountainText,
                            onFountainChange: handleFountainChange,
                            onPromptSubmit: handlePromptSubmit,
                            isGenerating: isGenerating,
                            readOnly: readOnly
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                            lineNumber: 817,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/RecordingStudio3.jsx",
                        lineNumber: 811,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
                        sx: {
                            width: 300,
                            borderRadius: 0,
                            overflow: "auto",
                            flexShrink: 0
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                p: 2
                            },
                            children: [
                                selectedDialogue && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        mb: 2
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "subtitle2",
                                            gutterBottom: true,
                                            children: t("recordingStudio3.lineNumber", {
                                                number: scriptData.dialogue.findIndex((d_11)=>d_11.id === selectedDialogue.id) + 1,
                                                speaker: selectedSpeaker?.name
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                            lineNumber: 834,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                            spacing: 1.5,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                                    fullWidth: true,
                                                    multiline: true,
                                                    rows: 2,
                                                    size: "small",
                                                    label: "Text",
                                                    value: selectedDialogue.text || "",
                                                    onChange: (e_0)=>handleUpdateDialogueLine(selectedDialogue.id, {
                                                            text: e_0.target.value
                                                        }),
                                                    disabled: readOnly
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                    lineNumber: 842,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                                    fullWidth: true,
                                                    size: "small",
                                                    label: "Direction",
                                                    value: selectedDialogue.direction || "",
                                                    onChange: (e_1)=>handleUpdateDialogueLine(selectedDialogue.id, {
                                                            direction: e_1.target.value
                                                        }),
                                                    disabled: readOnly,
                                                    placeholder: "e.g., entering, out of breath"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                    lineNumber: 846,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                                    fullWidth: true,
                                                    size: "small",
                                                    label: "Emotion",
                                                    value: selectedDialogue.emotion || "",
                                                    onChange: (e_2)=>handleUpdateDialogueLine(selectedDialogue.id, {
                                                            emotion: e_2.target.value
                                                        }),
                                                    disabled: readOnly,
                                                    placeholder: "e.g., cheerful, tired"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                    lineNumber: 850,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                                    spacing: 1,
                                                    children: [
                                                        !readOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            enableRecording: true,
                                                            onRecordingComplete: handleAudioWaveformRecordingComplete,
                                                            height: 60,
                                                            width: 400
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                            lineNumber: 856,
                                                            columnNumber: 35
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                            variant: "outlined",
                                                            size: "small",
                                                            startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$GraphicEq$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                lineNumber: 858,
                                                                columnNumber: 72
                                                            }, this),
                                                            onClick: ()=>handleGenerateTTS(selectedDialogue.id),
                                                            disabled: readOnly || isGenerating || !selectedDialogue.text,
                                                            children: t("recordingStudio3.generateTts")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                            lineNumber: 858,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                    lineNumber: 855,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$AudioFilterPanel$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    activeFilters: activeFilters,
                                                    onFiltersChange: handleFiltersChange
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                    lineNumber: 864,
                                                    columnNumber: 19
                                                }, this),
                                                selectedDialogue.takes && selectedDialogue.takes.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            variant: "caption",
                                                            color: "text.secondary",
                                                            children: t("recordingStudio3.takes")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                            lineNumber: 868,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                                            dense: true,
                                                            children: selectedDialogue.takes.map((take_0, index)=>{
                                                                const isActive = selectedDialogue.activeTakeIndex === index;
                                                                const takeAudioUrl = take_0.audioPath ? null // Will be resolved by AudioWaveformPlayer via file prop
                                                                 : take_0.audioBlob ? URL.createObjectURL(take_0.audioBlob) : null;
                                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                                                    sx: {
                                                                        flexDirection: "column",
                                                                        alignItems: "stretch",
                                                                        py: 1
                                                                    },
                                                                    secondaryAction: !readOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                                        edge: "end",
                                                                        size: "small",
                                                                        onClick: ()=>handleDeleteTake(selectedDialogue.id, index),
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                            fontSize: "small"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                            lineNumber: 881,
                                                                            columnNumber: 39
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                        lineNumber: 880,
                                                                        columnNumber: 54
                                                                    }, this),
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                                                            direction: "row",
                                                                            alignItems: "center",
                                                                            spacing: 1,
                                                                            sx: {
                                                                                width: "100%"
                                                                            },
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                                                    size: "small",
                                                                                    onClick: ()=>handleSetActiveTake(selectedDialogue.id, index),
                                                                                    disabled: readOnly,
                                                                                    children: isActive ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                        color: "primary"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                                        lineNumber: 887,
                                                                                        columnNumber: 49
                                                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$StarBorder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                                                        fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                                        lineNumber: 887,
                                                                                        columnNumber: 80
                                                                                    }, this)
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                                    lineNumber: 886,
                                                                                    columnNumber: 35
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                                    variant: "caption",
                                                                                    sx: {
                                                                                        minWidth: 90
                                                                                    },
                                                                                    children: `Take ${index + 1} (${take_0.type})`
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                                    lineNumber: 889,
                                                                                    columnNumber: 35
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                                    variant: "caption",
                                                                                    color: "text.secondary",
                                                                                    children: new Date(take_0.createdAt).toLocaleTimeString()
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                                    lineNumber: 894,
                                                                                    columnNumber: 35
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$TakeVersionHistory$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                    identityId: identityId,
                                                                                    dialogueId: selectedDialogue.id,
                                                                                    slotId: typeof take_0.id === "string" ? take_0.id : null,
                                                                                    currentVersion: take_0.version,
                                                                                    currentAudioPath: take_0.audioPath,
                                                                                    takeType: take_0.type,
                                                                                    onRestore: handleRollbackTake,
                                                                                    disabled: readOnly || typeof take_0.id !== "string"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                                    lineNumber: 897,
                                                                                    columnNumber: 35
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                            lineNumber: 883,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        (takeAudioUrl || take_0.file) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                                            sx: {
                                                                                mt: 0.5,
                                                                                pl: 5
                                                                            },
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                audioUrl: takeAudioUrl,
                                                                                file: take_0.file,
                                                                                waveformData: take_0.waveformData,
                                                                                audioFilters: activeFilters,
                                                                                width: 350,
                                                                                height: 50,
                                                                                showDuration: true
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                                lineNumber: 903,
                                                                                columnNumber: 37
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                            lineNumber: 899,
                                                                            columnNumber: 67
                                                                        }, this)
                                                                    ]
                                                                }, take_0.id, true, {
                                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                    lineNumber: 876,
                                                                    columnNumber: 28
                                                                }, this);
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                            lineNumber: 871,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                    lineNumber: 867,
                                                    columnNumber: 83
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                            lineNumber: 841,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
                                            sx: {
                                                my: 2
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                            lineNumber: 911,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                    lineNumber: 831,
                                    columnNumber: 34
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                    direction: "row",
                                    spacing: 1,
                                    sx: {
                                        mb: 2
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "subtitle1",
                                            sx: {
                                                flex: 1
                                            },
                                            children: t("recordingStudio3.speakers")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                            lineNumber: 920,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                            size: "small",
                                            startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                lineNumber: 925,
                                                columnNumber: 47
                                            }, this),
                                            onClick: handleAddSpeaker,
                                            disabled: readOnly,
                                            children: t("recordingStudio3.add")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                            lineNumber: 925,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                    lineNumber: 917,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                    spacing: 2,
                                    children: Object.entries(scriptData.speakers).map(([speakerId_3, speaker_2])=>{
                                        const isLocked = isTrackLocked(speakerId_3);
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paper$3e$__["Paper"], {
                                            variant: "outlined",
                                            sx: {
                                                p: 1.5
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                                spacing: 1,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                                        direction: "row",
                                                        spacing: 1,
                                                        alignItems: "center",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                                                fullWidth: true,
                                                                size: "small",
                                                                value: speaker_2.name,
                                                                onChange: (e_3)=>handleUpdateSpeaker(speakerId_3, {
                                                                        name: e_3.target.value
                                                                    }),
                                                                disabled: readOnly || isLocked,
                                                                label: "Name"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                lineNumber: 938,
                                                                columnNumber: 27
                                                            }, this),
                                                            !isLocked && !readOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                                                size: "small",
                                                                onClick: ()=>handleDeleteSpeaker(speakerId_3),
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                    fontSize: "small"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                    lineNumber: 942,
                                                                    columnNumber: 31
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                lineNumber: 941,
                                                                columnNumber: 54
                                                            }, this),
                                                            isLocked && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                                                title: "Locked track",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__["Badge"], {
                                                                    badgeContent: "🔒"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                    lineNumber: 945,
                                                                    columnNumber: 31
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                lineNumber: 944,
                                                                columnNumber: 40
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                        lineNumber: 937,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__["FormControl"], {
                                                        fullWidth: true,
                                                        size: "small",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__["InputLabel"], {
                                                                children: t("recordingStudio3.voice")
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                lineNumber: 950,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                                                                value: speaker_2.voice || "alloy",
                                                                onChange: (e_4)=>handleUpdateSpeaker(speakerId_3, {
                                                                        voice: e_4.target.value
                                                                    }),
                                                                disabled: readOnly,
                                                                label: t("recordingStudio3.voice"),
                                                                children: TTS_VOICES.map((voice)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                                                        value: voice.value,
                                                                        children: voice.label
                                                                    }, voice.value, false, {
                                                                        fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                        lineNumber: 954,
                                                                        columnNumber: 54
                                                                    }, this))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                                lineNumber: 951,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                        lineNumber: 949,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                                        fullWidth: true,
                                                        size: "small",
                                                        multiline: true,
                                                        rows: 2,
                                                        value: speaker_2.description || "",
                                                        onChange: (e_5)=>handleUpdateSpeaker(speakerId_3, {
                                                                description: e_5.target.value
                                                            }),
                                                        disabled: readOnly,
                                                        label: "Description",
                                                        placeholder: "e.g., 30s, energetic, professional"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                        lineNumber: 960,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/RecordingStudio3.jsx",
                                                lineNumber: 936,
                                                columnNumber: 23
                                            }, this)
                                        }, speakerId_3, false, {
                                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                                            lineNumber: 933,
                                            columnNumber: 22
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3.jsx",
                                    lineNumber: 930,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/RecordingStudio3.jsx",
                            lineNumber: 827,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/RecordingStudio3.jsx",
                        lineNumber: 821,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/RecordingStudio3.jsx",
                lineNumber: 804,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2f$HorizontalTimeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                scriptData: scriptData,
                selectedDialogueId: selectedDialogueId,
                onSelectDialogue: setSelectedDialogueId,
                playing: playing,
                onPlay: ()=>setPlaying(true),
                onStop: ()=>setPlaying(false),
                onRecordingComplete: handleAudioWaveformRecordingComplete,
                readOnly: readOnly
            }, void 0, false, {
                fileName: "[project]/src/components/RecordingStudio3.jsx",
                lineNumber: 972,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/RecordingStudio3.jsx",
        lineNumber: 762,
        columnNumber: 10
    }, this);
}, "ItkjFsmSWVqeZ3Lmi07oH9udsWY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
})), "ItkjFsmSWVqeZ3Lmi07oH9udsWY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
var _c, _c1;
__turbopack_context__.k.register(_c, "%default%$forwardRef");
__turbopack_context__.k.register(_c1, "%default%");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RecordingStudio3Modal.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RecordingStudio3Modal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview RecordingStudio3Modal - Fullscreen modal wrapper for RecordingStudio3
 *
 * Provides the shared modal chrome (open/close, title bar, confirmation preview,
 * save/cancel actions) around RecordingStudio3 for both Dictionary and Editor workflows.
 *
 * RecordingStudio3 itself has NO internal save/close UI — it is purely reactive,
 * calling onScriptChange on every mutation. This modal adds:
 *   - Fullscreen MUI Dialog with AppBar-style title bar
 *   - "Done" button that opens a confirmation preview before saving
 *   - "Cancel" button with unsaved-changes guard
 *   - MicLevelIndicator integration during active recording
 *   - Preset-aware save logic (word preset saves to Word model, conversation saves File records)
 *
 * Props:
 * @param {boolean} open                    - Controls dialog visibility
 * @param {Function} onClose                - Called when modal is dismissed (cancel or after save)
 * @param {Function} onSave                 - Called with save payload after user confirms preview
 *                                            Dictionary: (wordUpdates, scriptData) => Promise<void>
 *                                            Editor:     (fileRecords, scriptData) => Promise<void>
 * @param {string} title                    - Dialog title text
 * @param {'word'|'conversation'|'question'} preset - Determines save behavior and confirmation UI
 * @param {Object} scriptData               - Initial script data from preset factory
 * @param {string[]} lockedTracks           - Passed through to RecordingStudio3
 * @param {string} [gradeId]               - For student S3 uploads (passed through)
 * @param {string} [nodeKey]               - File organization key (passed through)
 * @param {Object} [identityId]            - User identity for S3 (passed through)
 * @param {boolean} [readOnly=false]        - Disable all editing (passed through)
 * @param {Function} [onGenerateMissingTTS]  - Called when user clicks "Generate Missing" in preview.
 *                                             Receives (missingLines) array. Parent or RS3 handles TTS.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AppBar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AppBar/AppBar.js [app-client] (ecmascript) <export default as AppBar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Toolbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Toolbar/Toolbar.js [app-client] (ecmascript) <export default as Toolbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItem/ListItem.js [app-client] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript) <export default as ListItemText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemIcon/ListItemIcon.js [app-client] (ecmascript) <export default as ListItemIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slide$2f$Slide$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Slide$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Slide/Slide.js [app-client] (ecmascript) <export default as Slide>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Save.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$GraphicEq$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/GraphicEq.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Check.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Warning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RecordVoiceOver$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RecordVoiceOver.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript) <export default as LinearProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudio3.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
// Slide-up transition for fullscreen dialog
const Transition = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = function Transition(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "5f6556ebb9bcd41be6870ccd3e23cc0f0d9b25be3151d70c511f4031a5734193") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5f6556ebb9bcd41be6870ccd3e23cc0f0d9b25be3151d70c511f4031a5734193";
    }
    let t0;
    if ($[1] !== props || $[2] !== ref) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slide$2f$Slide$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Slide$3e$__["Slide"], {
            direction: "up",
            ref: ref,
            ...props
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
            lineNumber: 52,
            columnNumber: 10
        }, this);
        $[1] = props;
        $[2] = ref;
        $[3] = t0;
    } else {
        t0 = $[3];
    }
    return t0;
});
_c1 = Transition;
/**
 * Extracts a save summary from scriptData for the confirmation preview.
 *
 * @param {Object} scriptData - Current script state from RS3
 * @param {string} preset     - 'word' | 'conversation' | 'question'
 * @returns {{ totalTakes: number, linesSummary: Array, speakers: string[], hasUnsaved: boolean }}
 */ function extractSaveSummary(scriptData, preset) {
    const speakers = Object.values(scriptData.speakers || {}).map((s)=>s.name);
    const linesSummary = (scriptData.dialogue || []).map((line)=>{
        const speaker = scriptData.speakers[line.speaker];
        const activeTake = line.activeTakeIndex !== null && line.takes?.[line.activeTakeIndex];
        return {
            id: line.id,
            speaker: speaker?.name || 'Unknown',
            text: line.text,
            hasTake: !!activeTake,
            takeType: activeTake?.type || null,
            // 'human' | 'tts' | null
            hasAudioPath: !!activeTake?.audioPath,
            totalTakes: line.takes?.length || 0
        };
    });
    const totalTakes = linesSummary.reduce((sum, l)=>sum + l.totalTakes, 0);
    const linesWithActiveTake = linesSummary.filter((l)=>l.hasTake).length;
    const linesWithoutTake = linesSummary.filter((l)=>!l.hasTake).length;
    const linesWithTextButNoTake = linesSummary.filter((l)=>!l.hasTake && l.text);
    return {
        totalTakes,
        linesSummary,
        speakers,
        linesWithActiveTake,
        linesWithoutTake,
        linesWithTextButNoTake
    };
}
/**
 * Builds the save payload depending on preset type.
 *
 * For 'word' preset:
 *   - phrase_track active takes → audio paths for Word.audio[]
 *   - definition_track active takes → audio paths for Word.definitionAudio[]
 *   - waveformData extracted per track
 *   - Full scriptData for Word.scriptData field
 *
 * For 'conversation' / 'question' preset:
 *   - All active takes with audioPath → File record candidates
 *   - Full scriptData for File record (application/json)
 */ function buildSavePayload(scriptData, preset) {
    if (preset === 'word') {
        const phraseLines = scriptData.dialogue.filter((d)=>d.speaker === 'phrase_track');
        const defLines = scriptData.dialogue.filter((d)=>d.speaker === 'definition_track');
        const extractActivePaths = (lines)=>lines.filter((l)=>l.activeTakeIndex !== null && l.takes?.[l.activeTakeIndex]?.audioPath).map((l)=>({
                    audioPath: l.takes[l.activeTakeIndex].audioPath,
                    waveformData: l.takes[l.activeTakeIndex].waveformData
                }));
        return {
            type: 'word',
            phraseAudio: extractActivePaths(phraseLines),
            definitionAudio: extractActivePaths(defLines),
            scriptData
        };
    }
    // conversation or question
    const audioFiles = scriptData.dialogue.filter((l)=>l.activeTakeIndex !== null && l.takes?.[l.activeTakeIndex]?.audioPath).map((l)=>{
        const take = l.takes[l.activeTakeIndex];
        const speaker = scriptData.speakers[l.speaker];
        return {
            audioPath: take.audioPath,
            waveformData: take.waveformData,
            speakerName: speaker?.name,
            text: l.text,
            type: take.type
        };
    });
    return {
        type: preset,
        audioFiles,
        scriptData
    };
}
function RecordingStudio3Modal(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(68);
    if ($[0] !== "5f6556ebb9bcd41be6870ccd3e23cc0f0d9b25be3151d70c511f4031a5734193") {
        for(let $i = 0; $i < 68; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5f6556ebb9bcd41be6870ccd3e23cc0f0d9b25be3151d70c511f4031a5734193";
    }
    const { open, onClose, onSave, title, preset, scriptData: initialScriptData, lockedTracks: t1, gradeId, nodeKey, identityId, readOnly: t2 } = t0;
    let t3;
    if ($[1] !== t1) {
        t3 = t1 === undefined ? [] : t1;
        $[1] = t1;
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    const lockedTracks = t3;
    const readOnly = t2 === undefined ? false : t2;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const scriptDataRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(initialScriptData);
    const [hasChanges, setHasChanges] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showPreview, setShowPreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [saveSummary, setSaveSummary] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [generatingTTS, setGeneratingTTS] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t4;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            done: 0,
            total: 0
        };
        $[3] = t4;
    } else {
        t4 = $[3];
    }
    const [, setTtsProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t4);
    const rs3Ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isRecording, setIsRecording] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t5;
    let t6;
    if ($[4] !== initialScriptData || $[5] !== open) {
        t5 = ({
            "RecordingStudio3Modal[useEffect()]": ()=>{
                if (open) {
                    scriptDataRef.current = initialScriptData;
                    setHasChanges(false);
                    setShowPreview(false);
                    setSaving(false);
                    setSaveSummary(null);
                    setGeneratingTTS(false);
                    setTtsProgress({
                        done: 0,
                        total: 0
                    });
                }
            }
        })["RecordingStudio3Modal[useEffect()]"];
        t6 = [
            open,
            initialScriptData
        ];
        $[4] = initialScriptData;
        $[5] = open;
        $[6] = t5;
        $[7] = t6;
    } else {
        t5 = $[6];
        t6 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = ({
            "RecordingStudio3Modal[handleScriptChange]": (newScriptData)=>{
                scriptDataRef.current = newScriptData;
                setHasChanges(true);
            }
        })["RecordingStudio3Modal[handleScriptChange]"];
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    const handleScriptChange = t7;
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = ({
            "RecordingStudio3Modal[handleUpdateData]": (t9)=>{
                const { type, scriptData: newData } = t9;
                scriptDataRef.current = newData;
                setHasChanges(true);
                if (type === "TAKE_ADDED") {
                    setIsRecording(false);
                }
            }
        })["RecordingStudio3Modal[handleUpdateData]"];
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    const handleUpdateData = t8;
    let t9;
    if ($[10] !== preset) {
        t9 = ({
            "RecordingStudio3Modal[handleDoneClick]": ()=>{
                const summary = extractSaveSummary(scriptDataRef.current, preset);
                setSaveSummary(summary);
                setShowPreview(true);
            }
        })["RecordingStudio3Modal[handleDoneClick]"];
        $[10] = preset;
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    const handleDoneClick = t9;
    let t10;
    if ($[12] !== onClose || $[13] !== onSave || $[14] !== preset) {
        t10 = ({
            "RecordingStudio3Modal[handleConfirmSave]": async ()=>{
                setSaving(true);
                ;
                try {
                    const payload_0 = buildSavePayload(scriptDataRef.current, preset);
                    await onSave(payload_0);
                    onClose();
                } catch (t11) {
                    const error = t11;
                    console.error("RecordingStudio3Modal save error:", error);
                    setSaving(false);
                }
            }
        })["RecordingStudio3Modal[handleConfirmSave]"];
        $[12] = onClose;
        $[13] = onSave;
        $[14] = preset;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    const handleConfirmSave = t10;
    let t11;
    if ($[16] !== preset || $[17] !== saveSummary?.linesWithTextButNoTake) {
        t11 = ({
            "RecordingStudio3Modal[handleGenerateMissingTTS]": ()=>{
                setGeneratingTTS(true);
                const missing = saveSummary?.linesWithTextButNoTake || [];
                setTtsProgress({
                    done: 0,
                    total: missing.length
                });
                setShowPreview(false);
                if (rs3Ref.current?.triggerBatchTTS) {
                    rs3Ref.current.triggerBatchTTS().then({
                        "RecordingStudio3Modal[handleGenerateMissingTTS > (anonymous)()]": ()=>{
                            setGeneratingTTS(false);
                            const summary_0 = extractSaveSummary(scriptDataRef.current, preset);
                            setSaveSummary(summary_0);
                            setShowPreview(true);
                        }
                    }["RecordingStudio3Modal[handleGenerateMissingTTS > (anonymous)()]"]).catch({
                        "RecordingStudio3Modal[handleGenerateMissingTTS > (anonymous)()]": ()=>{
                            setGeneratingTTS(false);
                        }
                    }["RecordingStudio3Modal[handleGenerateMissingTTS > (anonymous)()]"]);
                } else {
                    setGeneratingTTS(false);
                }
            }
        })["RecordingStudio3Modal[handleGenerateMissingTTS]"];
        $[16] = preset;
        $[17] = saveSummary?.linesWithTextButNoTake;
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    const handleGenerateMissingTTS = t11;
    let t12;
    if ($[19] !== hasChanges || $[20] !== onClose || $[21] !== t) {
        t12 = ({
            "RecordingStudio3Modal[handleCancel]": ()=>{
                if (hasChanges) {
                    const confirmed = window.confirm(t("recordingStudio3Modal.unsavedChanges"));
                    if (!confirmed) {
                        return;
                    }
                }
                onClose();
            }
        })["RecordingStudio3Modal[handleCancel]"];
        $[19] = hasChanges;
        $[20] = onClose;
        $[21] = t;
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    const handleCancel = t12;
    let t13;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            position: "relative"
        };
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    let t14;
    if ($[24] !== t) {
        t14 = t("common.close");
        $[24] = t;
        $[25] = t14;
    } else {
        t14 = $[25];
    }
    let t15;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
            lineNumber: 375,
            columnNumber: 11
        }, this);
        $[26] = t15;
    } else {
        t15 = $[26];
    }
    let t16;
    if ($[27] !== handleCancel || $[28] !== t14) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            edge: "start",
            color: "inherit",
            onClick: handleCancel,
            "aria-label": t14,
            children: t15
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
            lineNumber: 382,
            columnNumber: 11
        }, this);
        $[27] = handleCancel;
        $[28] = t14;
        $[29] = t16;
    } else {
        t16 = $[29];
    }
    let t17;
    if ($[30] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = {
            ml: 2,
            flex: 1
        };
        $[30] = t17;
    } else {
        t17 = $[30];
    }
    let t18;
    if ($[31] !== title) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
            sx: t17,
            variant: "h6",
            component: "div",
            children: title
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
            lineNumber: 401,
            columnNumber: 11
        }, this);
        $[31] = title;
        $[32] = t18;
    } else {
        t18 = $[32];
    }
    let t19;
    if ($[33] !== isRecording || $[34] !== t) {
        t19 = isRecording && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$GraphicEq$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                lineNumber: 409,
                columnNumber: 38
            }, this),
            label: t("recordingStudio3Modal.recording"),
            color: "error",
            size: "small",
            sx: {
                mr: 2
            }
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
            lineNumber: 409,
            columnNumber: 26
        }, this);
        $[33] = isRecording;
        $[34] = t;
        $[35] = t19;
    } else {
        t19 = $[35];
    }
    let t20;
    if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
            lineNumber: 420,
            columnNumber: 11
        }, this);
        $[36] = t20;
    } else {
        t20 = $[36];
    }
    const t21 = readOnly || saving;
    let t22;
    if ($[37] !== t) {
        t22 = t("recordingStudio3Modal.done");
        $[37] = t;
        $[38] = t22;
    } else {
        t22 = $[38];
    }
    let t23;
    if ($[39] !== handleDoneClick || $[40] !== t21 || $[41] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            autoFocus: true,
            color: "inherit",
            startIcon: t20,
            onClick: handleDoneClick,
            disabled: t21,
            children: t22
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
            lineNumber: 436,
            columnNumber: 11
        }, this);
        $[39] = handleDoneClick;
        $[40] = t21;
        $[41] = t22;
        $[42] = t23;
    } else {
        t23 = $[42];
    }
    let t24;
    if ($[43] !== t16 || $[44] !== t18 || $[45] !== t19 || $[46] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AppBar$3e$__["AppBar"], {
            sx: t13,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Toolbar$3e$__["Toolbar"], {
                children: [
                    t16,
                    t18,
                    t19,
                    t23
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                lineNumber: 446,
                columnNumber: 28
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
            lineNumber: 446,
            columnNumber: 11
        }, this);
        $[43] = t16;
        $[44] = t18;
        $[45] = t19;
        $[46] = t23;
        $[47] = t24;
    } else {
        t24 = $[47];
    }
    let t25;
    if ($[48] !== generatingTTS || $[49] !== gradeId || $[50] !== handleConfirmSave || $[51] !== handleGenerateMissingTTS || $[52] !== identityId || $[53] !== initialScriptData || $[54] !== lockedTracks || $[55] !== nodeKey || $[56] !== preset || $[57] !== readOnly || $[58] !== saveSummary || $[59] !== saving || $[60] !== showPreview || $[61] !== t) {
        t25 = !showPreview ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                flex: 1,
                overflow: "hidden"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudio3$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                ref: rs3Ref,
                scriptData: initialScriptData,
                onScriptChange: handleScriptChange,
                onUpdateData: handleUpdateData,
                lockedTracks: lockedTracks,
                gradeId: gradeId,
                nodeKey: nodeKey,
                identityId: identityId,
                readOnly: readOnly
            }, void 0, false, {
                fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                lineNumber: 460,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
            lineNumber: 457,
            columnNumber: 26
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                flex: 1,
                overflow: "auto",
                p: 3,
                maxWidth: 800,
                mx: "auto"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "h5",
                    gutterBottom: true,
                    children: t("recordingStudio3Modal.confirmTitle")
                }, void 0, false, {
                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                    lineNumber: 466,
                    columnNumber: 8
                }, this),
                saveSummary && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                            direction: "row",
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                    label: `${saveSummary.speakers.length} speakers`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                    lineNumber: 466,
                                    columnNumber: 177
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                    label: `${saveSummary.totalTakes} total takes`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                    lineNumber: 466,
                                    columnNumber: 235
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                    label: `${saveSummary.linesWithActiveTake} lines with audio`,
                                    color: "success",
                                    variant: "outlined"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                    lineNumber: 466,
                                    columnNumber: 291
                                }, this),
                                saveSummary.linesWithoutTake > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                    label: `${saveSummary.linesWithoutTake} lines without audio`,
                                    color: "warning",
                                    variant: "outlined"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                    lineNumber: 466,
                                    columnNumber: 433
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                            lineNumber: 466,
                            columnNumber: 142
                        }, this),
                        saveSummary.linesWithoutTake > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                            severity: "warning",
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                lineNumber: 466,
                                columnNumber: 616
                            }, this),
                            action: saveSummary.linesWithTextButNoTake.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                color: "warning",
                                size: "small",
                                startIcon: generatingTTS ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RecordVoiceOver$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                    lineNumber: 466,
                                    columnNumber: 761
                                }, this),
                                onClick: handleGenerateMissingTTS,
                                disabled: generatingTTS || saving,
                                children: generatingTTS ? t("recordingStudio3Modal.generatingTts") : t("recordingStudio3Modal.generateMissingTts", {
                                    count: saveSummary.linesWithTextButNoTake.length
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                lineNumber: 466,
                                columnNumber: 690
                            }, this),
                            children: t("recordingStudio3Modal.missingTakesWarning", {
                                count: saveSummary.linesWithoutTake
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                            lineNumber: 466,
                            columnNumber: 584
                        }, this),
                        generatingTTS && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                width: "100%"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LinearProgress$3e$__["LinearProgress"], {}, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                    lineNumber: 472,
                                    columnNumber: 12
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    variant: "caption",
                                    color: "text.secondary",
                                    sx: {
                                        mt: 0.5
                                    },
                                    children: t("recordingStudio3Modal.generatingTtsProgress")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                    lineNumber: 472,
                                    columnNumber: 30
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                            lineNumber: 470,
                            columnNumber: 41
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                            children: saveSummary.linesSummary.map({
                                "RecordingStudio3Modal[saveSummary.linesSummary.map()]": (line, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemIcon$3e$__["ListItemIcon"], {
                                                        children: line.hasTake ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            color: "success"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                                            lineNumber: 475,
                                                            columnNumber: 157
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            color: "warning"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                                            lineNumber: 475,
                                                            columnNumber: 189
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                                        lineNumber: 475,
                                                        columnNumber: 127
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItemText$3e$__["ListItemText"], {
                                                        primary: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                                            direction: "row",
                                                            spacing: 1,
                                                            alignItems: "center",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                    variant: "body2",
                                                                    color: "text.secondary",
                                                                    children: [
                                                                        index + 1,
                                                                        "."
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                                                    lineNumber: 475,
                                                                    columnNumber: 314
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                                                    label: line.speaker,
                                                                    size: "small"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                                                    lineNumber: 475,
                                                                    columnNumber: 390
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                    variant: "body2",
                                                                    noWrap: true,
                                                                    sx: {
                                                                        flex: 1
                                                                    },
                                                                    children: line.text || "(empty)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                                                    lineNumber: 475,
                                                                    columnNumber: 432
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                                            lineNumber: 475,
                                                            columnNumber: 259
                                                        }, this),
                                                        secondary: line.hasTake ? `${line.takeType} recording • ${line.totalTakes} take(s)` : t("recordingStudio3Modal.noActiveTake")
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                                        lineNumber: 475,
                                                        columnNumber: 236
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                                lineNumber: 475,
                                                columnNumber: 117
                                            }, this),
                                            index < saveSummary.linesSummary.length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {}, void 0, false, {
                                                fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                                lineNumber: 477,
                                                columnNumber: 257
                                            }, this)
                                        ]
                                    }, line.id, true, {
                                        fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                        lineNumber: 475,
                                        columnNumber: 87
                                    }, this)
                            }["RecordingStudio3Modal[saveSummary.linesSummary.map()]"])
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                            lineNumber: 474,
                            columnNumber: 84
                        }, this),
                        preset === "word" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                            severity: "info",
                            children: t("recordingStudio3Modal.wordSaveInfo")
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                            lineNumber: 478,
                            columnNumber: 100
                        }, this),
                        preset === "conversation" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                            severity: "info",
                            children: t("recordingStudio3Modal.conversationSaveInfo")
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                            lineNumber: 478,
                            columnNumber: 203
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {}, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                            lineNumber: 478,
                            columnNumber: 284
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                            direction: "row",
                            spacing: 2,
                            justifyContent: "flex-end",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "outlined",
                                    onClick: {
                                        "RecordingStudio3Modal[<Button>.onClick]": ()=>setShowPreview(false)
                                    }["RecordingStudio3Modal[<Button>.onClick]"],
                                    disabled: saving,
                                    children: t("recordingStudio3Modal.backToStudio")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                    lineNumber: 478,
                                    columnNumber: 356
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "contained",
                                    startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                        lineNumber: 480,
                                        columnNumber: 164
                                    }, this),
                                    onClick: handleConfirmSave,
                                    disabled: saving,
                                    children: saving ? t("recordingStudio3Modal.saving") : t("recordingStudio3Modal.confirmSave")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                                    lineNumber: 480,
                                    columnNumber: 125
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                            lineNumber: 478,
                            columnNumber: 295
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
                    lineNumber: 466,
                    columnNumber: 123
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
            lineNumber: 460,
            columnNumber: 257
        }, this);
        $[48] = generatingTTS;
        $[49] = gradeId;
        $[50] = handleConfirmSave;
        $[51] = handleGenerateMissingTTS;
        $[52] = identityId;
        $[53] = initialScriptData;
        $[54] = lockedTracks;
        $[55] = nodeKey;
        $[56] = preset;
        $[57] = readOnly;
        $[58] = saveSummary;
        $[59] = saving;
        $[60] = showPreview;
        $[61] = t;
        $[62] = t25;
    } else {
        t25 = $[62];
    }
    let t26;
    if ($[63] !== handleCancel || $[64] !== open || $[65] !== t24 || $[66] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
            open: open,
            onClose: handleCancel,
            fullScreen: true,
            TransitionComponent: Transition,
            children: [
                t24,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudio3Modal.jsx",
            lineNumber: 501,
            columnNumber: 11
        }, this);
        $[63] = handleCancel;
        $[64] = open;
        $[65] = t24;
        $[66] = t25;
        $[67] = t26;
    } else {
        t26 = $[67];
    }
    return t26;
}
_s(RecordingStudio3Modal, "F21wDdLdSv1wVmkNIn1mxNpYkTQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c2 = RecordingStudio3Modal;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Transition$React.forwardRef");
__turbopack_context__.k.register(_c1, "Transition");
__turbopack_context__.k.register(_c2, "RecordingStudio3Modal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/recordingStudioReducer.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * recordingStudioReducer — State machine for RecordingStudioEnhanced.
 *
 * Manages recording/playback state machine, tracks, filters, and selection.
 * Prevents impossible states (e.g., recording + playing simultaneously).
 */ // ============================================================================
// Types
// ============================================================================
__turbopack_context__.s([
    "initialRecordingStudioState",
    ()=>initialRecordingStudioState,
    "recordingStudioReducer",
    ()=>recordingStudioReducer
]);
const initialRecordingStudioState = {
    tracks: [
        {
            id: 1,
            name: "Track 1",
            voice: "alloy",
            prompt: "",
            clips: []
        }
    ],
    selectedTrackId: 1,
    filters: {
        noiseReduction: "none",
        popClickRemoval: false,
        speechEnhancement: "none",
        highPassFilter: false,
        lowPassFilter: false,
        normalize: false
    },
    recordingStatus: "idle",
    mediaRecorder: null,
    mediaStream: null,
    recordingAnalyser: null,
    playbackStatus: "idle",
    currentTime: 0,
    duration: 0,
    selectionStart: null,
    selectionEnd: null
};
function recordingStudioReducer(state, action) {
    switch(action.type){
        case "START_RECORDING":
            // Can't record while playing
            if (state.playbackStatus !== "idle") return state;
            return {
                ...state,
                recordingStatus: "recording",
                mediaStream: action.mediaStream,
                mediaRecorder: action.mediaRecorder,
                recordingAnalyser: action.recordingAnalyser
            };
        case "STOP_RECORDING":
            return {
                ...state,
                recordingStatus: "stopping"
            };
        case "RECORDING_STOPPED":
            {
                const track = state.tracks.find((t)=>t.id === state.selectedTrackId);
                if (!track) return {
                    ...state,
                    recordingStatus: "idle",
                    mediaRecorder: null,
                    mediaStream: null,
                    recordingAnalyser: null
                };
                return {
                    ...state,
                    recordingStatus: "idle",
                    mediaRecorder: null,
                    mediaStream: null,
                    recordingAnalyser: null,
                    tracks: state.tracks.map((t)=>t.id === state.selectedTrackId ? {
                            ...t,
                            clips: [
                                ...t.clips,
                                action.clip
                            ]
                        } : t)
                };
            }
        case "CLEANUP_RECORDING_RESOURCES":
            return {
                ...state,
                recordingStatus: "idle",
                mediaRecorder: null,
                mediaStream: null,
                recordingAnalyser: null
            };
        case "START_PLAYBACK":
            // Can't play while recording
            if (state.recordingStatus !== "idle") return state;
            return {
                ...state,
                playbackStatus: "playing"
            };
        case "PAUSE_PLAYBACK":
            return {
                ...state,
                playbackStatus: "paused"
            };
        case "STOP_PLAYBACK":
            return {
                ...state,
                playbackStatus: "idle",
                currentTime: 0
            };
        case "SET_CURRENT_TIME":
            return {
                ...state,
                currentTime: action.time
            };
        case "SET_DURATION":
            return {
                ...state,
                duration: action.duration
            };
        case "SET_SELECTION":
            return {
                ...state,
                selectionStart: action.start,
                selectionEnd: action.end
            };
        case "CLEAR_SELECTION":
            return {
                ...state,
                selectionStart: null,
                selectionEnd: null
            };
        case "CUT_SELECTION":
            // Reset selection after cut (actual audio manipulation happens externally)
            return {
                ...state,
                selectionStart: null,
                selectionEnd: null
            };
        case "ADD_TRACK":
            return {
                ...state,
                tracks: [
                    ...state.tracks,
                    action.track
                ]
            };
        case "DELETE_TRACK":
            {
                if (state.tracks.length <= 1) return state;
                const remaining = state.tracks.filter((t)=>t.id !== action.trackId);
                return {
                    ...state,
                    tracks: remaining,
                    selectedTrackId: state.selectedTrackId === action.trackId ? remaining[0].id : state.selectedTrackId
                };
            }
        case "UPDATE_TRACK":
            return {
                ...state,
                tracks: state.tracks.map((t)=>t.id === action.trackId ? {
                        ...t,
                        ...action.updates
                    } : t)
            };
        case "SELECT_TRACK":
            return {
                ...state,
                selectedTrackId: action.trackId
            };
        case "SET_FILTER":
            return {
                ...state,
                filters: {
                    ...state.filters,
                    ...action.filter
                }
            };
        default:
            return state;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RecordingStudioEnhanced.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RecordingStudioEnhanced
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Toolbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Toolbar/Toolbar.js [app-client] (ecmascript) <export default as Toolbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Select/Select.js [app-client] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript) <export default as MenuItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControl/FormControl.js [app-client] (ecmascript) <export default as FormControl>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputLabel/InputLabel.js [app-client] (ecmascript) <export default as InputLabel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript) <export default as CardContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$recordingStudioReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/recordingStudioReducer.ts [app-client] (ecmascript)");
// Icons
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$KeyboardVoice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/KeyboardVoice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Stop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Stop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ContentCut$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ContentCut.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Add.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Delete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AudioWaveformPlayer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$MicLevelIndicator$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/MicLevelIndicator.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calculateWaveformData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/calculateWaveformData.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function RecordingStudioEnhanced({ gradeId, nodeKey, onRecordingComplete, metadata = {}, /** Optional ref — parent can read current state on demand (e.g. modal Save button) */ stateRef }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$recordingStudioReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["recordingStudioReducer"], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$recordingStudioReducer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialRecordingStudioState"]);
    const { tracks, selectedTrackId, filters, recordingStatus, recordingAnalyser, selectionStart, selectionEnd } = state;
    const recording = recordingStatus === "recording";
    // Keep stateRef current so parent modal can read state on Save
    if (stateRef) {
        stateRef.current = state;
    }
    // Refs
    const trackContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const audioContextRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Available Whisper voices
    const whisperVoices = [
        {
            value: "alloy",
            label: "Alloy"
        },
        {
            value: "echo",
            label: "Echo"
        },
        {
            value: "fable",
            label: "Fable"
        },
        {
            value: "onyx",
            label: "Onyx"
        },
        {
            value: "nova",
            label: "Nova"
        },
        {
            value: "shimmer",
            label: "Shimmer"
        }
    ];
    const selectedTrack = tracks.find((t_0)=>t_0.id === selectedTrackId);
    // Add new track
    const handleAddTrack = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RecordingStudioEnhanced.useCallback[handleAddTrack]": ()=>{
            const newTrack = {
                id: Date.now(),
                name: t("recordingStudioEnhanced.trackName", {
                    number: tracks.length + 1
                }),
                voice: "alloy",
                prompt: "",
                clips: []
            };
            dispatch({
                type: "ADD_TRACK",
                track: newTrack
            });
        }
    }["RecordingStudioEnhanced.useCallback[handleAddTrack]"], [
        tracks.length,
        t
    ]);
    // Delete track
    const handleDeleteTrack = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RecordingStudioEnhanced.useCallback[handleDeleteTrack]": (trackId)=>{
            if (tracks.length === 1) {
                alert(t("recordingStudioEnhanced.deleteLastTrackAlert"));
                return;
            }
            dispatch({
                type: "DELETE_TRACK",
                trackId
            });
        }
    }["RecordingStudioEnhanced.useCallback[handleDeleteTrack]"], [
        tracks.length,
        t
    ]);
    // Update track property
    const updateTrack = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RecordingStudioEnhanced.useCallback[updateTrack]": (trackId_0, updates)=>{
            dispatch({
                type: "UPDATE_TRACK",
                trackId: trackId_0,
                updates
            });
        }
    }["RecordingStudioEnhanced.useCallback[updateTrack]"], []);
    // Start recording
    const startRecording = async ()=>{
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: true
            });
            // Create AudioContext + AnalyserNode for MicLevelIndicator
            const audioContext = new AudioContext();
            audioContextRef.current = audioContext;
            const source = audioContext.createMediaStreamSource(stream);
            const analyser = audioContext.createAnalyser();
            source.connect(analyser);
            analyser.fftSize = 2048;
            analyser.smoothingTimeConstant = 0.8;
            const recorder = new MediaRecorder(stream);
            const audioChunks = [];
            recorder.ondataavailable = (event)=>{
                audioChunks.push(event.data);
            };
            recorder.onstop = async ()=>{
                const audioBlob = new Blob(audioChunks, {
                    type: "audio/mp3"
                });
                // Apply filters to the recorded audio
                const processedBlob = await applyFilters(audioBlob, filters);
                // Calculate waveform
                const waveform = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calculateWaveformData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateWaveformData"])(processedBlob, 600);
                // Add clip to selected track via reducer
                const newClip = {
                    id: Date.now(),
                    audioBlob: processedBlob,
                    waveformData: waveform,
                    startTime: 0,
                    duration: 0
                };
                dispatch({
                    type: "RECORDING_STOPPED",
                    clip: newClip
                });
                // Clean up
                stream.getTracks().forEach((track)=>track.stop());
                if (audioContextRef.current) {
                    audioContextRef.current.close();
                    audioContextRef.current = null;
                }
            };
            recorder.start();
            dispatch({
                type: "START_RECORDING",
                mediaStream: stream,
                mediaRecorder: recorder,
                recordingAnalyser: analyser
            });
        } catch (error) {
            console.error("Error starting recording:", error);
            alert(t("recordingStudioEnhanced.micAccessError"));
        }
    };
    // Stop recording
    const stopRecording = ()=>{
        if (state.mediaRecorder && recording) {
            state.mediaRecorder.stop();
            dispatch({
                type: "STOP_RECORDING"
            });
            if (audioContextRef.current) {
                audioContextRef.current.close();
                audioContextRef.current = null;
            }
        }
    };
    // Apply audio filters (simplified version - would need Web Audio API for real implementation)
    const applyFilters = async (audioBlob_0, filters_0)=>{
        // This is a placeholder. Real implementation would use Web Audio API
        // to apply actual filters like:
        // - BiquadFilterNode for high/low pass filters
        // - DynamicsCompressorNode for normalization
        // - Custom noise gate for noise reduction
        // - etc.
        console.log("Applying filters:", filters_0);
        // For now, just return the original blob
        // TODO: Implement actual audio filtering
        return audioBlob_0;
    };
    // Cut selected portion of audio
    const handleCut = ()=>{
        if (selectionStart === null || selectionEnd === null) {
            alert(t("recordingStudioEnhanced.selectToCut"));
            return;
        }
        // TODO: Implement actual cutting logic using Web Audio API
        console.log("Cutting from", selectionStart, "to", selectionEnd);
        dispatch({
            type: "CUT_SELECTION"
        });
    };
    // Generate audio from prompt using TTS
    const handleGenerateFromPrompt = async (trackId_1)=>{
        const track_0 = tracks.find((t_1)=>t_1.id === trackId_1);
        if (!track_0 || !track_0.prompt.trim()) {
            alert(t("recordingStudioEnhanced.enterPrompt"));
            return;
        }
        try {
            // TODO: Call OpenAI TTS API with track.voice and track.prompt
            console.log("Generating audio:", {
                voice: track_0.voice,
                prompt: track_0.prompt
            });
            // Placeholder - would need to implement actual API call
            alert(t("recordingStudioEnhanced.ttsNotImplemented"));
        } catch (error_0) {
            console.error("Error generating audio:", error_0);
            alert(t("recordingStudioEnhanced.ttsGenerationFailed"));
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            width: "100%",
            height: "100%"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Toolbar$3e$__["Toolbar"], {
                sx: {
                    bgcolor: "background.paper",
                    borderBottom: 1,
                    borderColor: "divider",
                    gap: 2,
                    flexWrap: "wrap"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "subtitle2",
                        sx: {
                            mr: 2
                        },
                        children: t("recordingStudioEnhanced.audioFilters")
                    }, void 0, false, {
                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                        lineNumber: 263,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__["FormControl"], {
                        size: "small",
                        sx: {
                            minWidth: 150
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__["InputLabel"], {
                                children: t("recordingStudioEnhanced.noiseReduction")
                            }, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                lineNumber: 272,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                                value: filters.noiseReduction,
                                label: t("recordingStudioEnhanced.noiseReduction"),
                                onChange: (e)=>dispatch({
                                        type: "SET_FILTER",
                                        filter: {
                                            noiseReduction: e.target.value
                                        }
                                    }),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                        value: "none",
                                        children: t("recordingStudioEnhanced.none")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                        lineNumber: 279,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                        value: "light",
                                        children: t("recordingStudioEnhanced.light")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                        lineNumber: 282,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                        value: "medium",
                                        children: t("recordingStudioEnhanced.medium")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                        lineNumber: 285,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                        value: "heavy",
                                        children: t("recordingStudioEnhanced.heavy")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                        lineNumber: 288,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                lineNumber: 273,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                        lineNumber: 269,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__["FormControl"], {
                        size: "small",
                        sx: {
                            minWidth: 150
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__["InputLabel"], {
                                children: t("recordingStudioEnhanced.speechEnhancement")
                            }, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                lineNumber: 297,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                                value: filters.speechEnhancement,
                                label: t("recordingStudioEnhanced.speechEnhancement"),
                                onChange: (e_0)=>dispatch({
                                        type: "SET_FILTER",
                                        filter: {
                                            speechEnhancement: e_0.target.value
                                        }
                                    }),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                        value: "none",
                                        children: t("recordingStudioEnhanced.none")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                        lineNumber: 306,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                        value: "clarity",
                                        children: t("recordingStudioEnhanced.clarity")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                        lineNumber: 309,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                        value: "presence",
                                        children: t("recordingStudioEnhanced.presence")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                        lineNumber: 312,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                        value: "broadcast",
                                        children: t("recordingStudioEnhanced.broadcast")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                        lineNumber: 315,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                lineNumber: 300,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                        lineNumber: 294,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: t("recordingStudioEnhanced.popClickTooltip"),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "small",
                            variant: filters.popClickRemoval ? "contained" : "outlined",
                            onClick: ()=>dispatch({
                                    type: "SET_FILTER",
                                    filter: {
                                        popClickRemoval: !filters.popClickRemoval
                                    }
                                }),
                            children: t("recordingStudioEnhanced.popClick")
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 322,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                        lineNumber: 321,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: t("recordingStudioEnhanced.highPassTooltip"),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "small",
                            variant: filters.highPassFilter ? "contained" : "outlined",
                            onClick: ()=>dispatch({
                                    type: "SET_FILTER",
                                    filter: {
                                        highPassFilter: !filters.highPassFilter
                                    }
                                }),
                            children: "HPF"
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 333,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                        lineNumber: 332,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: t("recordingStudioEnhanced.lowPassTooltip"),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "small",
                            variant: filters.lowPassFilter ? "contained" : "outlined",
                            onClick: ()=>dispatch({
                                    type: "SET_FILTER",
                                    filter: {
                                        lowPassFilter: !filters.lowPassFilter
                                    }
                                }),
                            children: "LPF"
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 344,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                        lineNumber: 343,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: t("recordingStudioEnhanced.normalizeTooltip"),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "small",
                            variant: filters.normalize ? "contained" : "outlined",
                            onClick: ()=>dispatch({
                                    type: "SET_FILTER",
                                    filter: {
                                        normalize: !filters.normalize
                                    }
                                }),
                            children: t("recordingStudioEnhanced.normalize")
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 355,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                        lineNumber: 354,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
                        orientation: "vertical",
                        flexItem: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                        lineNumber: 365,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: t("recordingStudioEnhanced.cutTooltip"),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                onClick: handleCut,
                                disabled: selectionStart === null || selectionEnd === null,
                                color: "primary",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ContentCut$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                    lineNumber: 370,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                lineNumber: 369,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 368,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                        lineNumber: 367,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                lineNumber: 256,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    p: 2,
                    bgcolor: "background.default"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        display: "flex",
                        gap: 2,
                        alignItems: "center",
                        mb: 2
                    },
                    children: [
                        !recording ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                            onClick: startRecording,
                            color: "error",
                            size: "large",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$KeyboardVoice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                lineNumber: 388,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 387,
                            columnNumber: 25
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                            onClick: stopRecording,
                            color: "primary",
                            size: "large",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Stop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                lineNumber: 390,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 389,
                            columnNumber: 29
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            children: recording ? t("recordingStudioEnhanced.recording") : t("recordingStudioEnhanced.clickToRecord")
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 393,
                            columnNumber: 11
                        }, this),
                        recording && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                minWidth: 120,
                                flexGrow: 1,
                                maxWidth: 200
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$MicLevelIndicator$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                analyser: recordingAnalyser
                            }, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                lineNumber: 401,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 396,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                flexGrow: 1
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 404,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Add$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                lineNumber: 408,
                                columnNumber: 30
                            }, this),
                            onClick: handleAddTrack,
                            variant: "outlined",
                            size: "small",
                            children: t("recordingStudioEnhanced.addTrack")
                        }, void 0, false, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 408,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                    lineNumber: 381,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                lineNumber: 377,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                ref: trackContainerRef,
                sx: {
                    overflowX: "auto",
                    overflowY: "auto",
                    maxHeight: "60vh",
                    bgcolor: "background.paper",
                    p: 2
                },
                children: tracks.map((track_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                        sx: {
                            mb: 2,
                            border: 2,
                            borderColor: selectedTrackId === track_1.id ? "primary.main" : "transparent"
                        },
                        onClick: ()=>dispatch({
                                type: "SELECT_TRACK",
                                trackId: track_1.id
                            }),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        display: "flex",
                                        gap: 2,
                                        mb: 2,
                                        alignItems: "center"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                            label: t("recordingStudioEnhanced.trackName"),
                                            value: track_1.name,
                                            onChange: (e_1)=>updateTrack(track_1.id, {
                                                    name: e_1.target.value
                                                }),
                                            size: "small",
                                            sx: {
                                                width: 150
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                            lineNumber: 437,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__["FormControl"], {
                                            size: "small",
                                            sx: {
                                                minWidth: 120
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InputLabel$3e$__["InputLabel"], {
                                                    children: t("recordingStudioEnhanced.voice")
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                                    lineNumber: 446,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                                                    value: track_1.voice,
                                                    label: t("recordingStudioEnhanced.voice"),
                                                    onChange: (e_2)=>updateTrack(track_1.id, {
                                                            voice: e_2.target.value
                                                        }),
                                                    children: whisperVoices.map((voice)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuItem$3e$__["MenuItem"], {
                                                            value: voice.value,
                                                            children: voice.label
                                                        }, voice.value, false, {
                                                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                                            lineNumber: 450,
                                                            columnNumber: 49
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                                    lineNumber: 447,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                            lineNumber: 443,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                            label: t("recordingStudioEnhanced.promptPlaceholder"),
                                            value: track_1.prompt,
                                            onChange: (e_3)=>updateTrack(track_1.id, {
                                                    prompt: e_3.target.value
                                                }),
                                            multiline: true,
                                            size: "small",
                                            sx: {
                                                flexGrow: 1
                                            },
                                            placeholder: t("recordingStudioEnhanced.promptPlaceholder")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                            lineNumber: 456,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                            onClick: ()=>handleGenerateFromPrompt(track_1.id),
                                            variant: "contained",
                                            size: "small",
                                            disabled: !track_1.prompt.trim(),
                                            children: t("recordingStudioEnhanced.generate")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                            lineNumber: 462,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                            onClick: ()=>handleDeleteTrack(track_1.id),
                                            size: "small",
                                            color: "error",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Delete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                                lineNumber: 467,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                            lineNumber: 466,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                    lineNumber: 431,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    sx: {
                                        overflowX: "auto",
                                        overflowY: "hidden",
                                        whiteSpace: "nowrap",
                                        border: 1,
                                        borderColor: "divider",
                                        borderRadius: 1,
                                        p: 1,
                                        minHeight: 100,
                                        bgcolor: "background.default"
                                    },
                                    children: track_1.clips.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                        variant: "caption",
                                        color: "text.secondary",
                                        sx: {
                                            display: "inline-block",
                                            lineHeight: "80px"
                                        },
                                        children: t("recordingStudioEnhanced.noClips")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                        lineNumber: 483,
                                        columnNumber: 47
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                        sx: {
                                            display: "inline-flex",
                                            gap: 1
                                        },
                                        children: track_1.clips.map((clip)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                sx: {
                                                    display: "inline-block",
                                                    verticalAlign: "top"
                                                },
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AudioWaveformPlayer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    waveformData: clip.waveformData,
                                                    width: 300,
                                                    height: 80,
                                                    showDuration: true
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                                    lineNumber: 496,
                                                    columnNumber: 25
                                                }, this)
                                            }, clip.id, false, {
                                                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                                lineNumber: 492,
                                                columnNumber: 48
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                        lineNumber: 488,
                                        columnNumber: 35
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                                    lineNumber: 472,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                            lineNumber: 430,
                            columnNumber: 13
                        }, this)
                    }, track_1.id, false, {
                        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                        lineNumber: 422,
                        columnNumber: 32
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                lineNumber: 415,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    p: 2,
                    bgcolor: "background.paper",
                    borderTop: 1,
                    borderColor: "divider"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                    variant: "caption",
                    color: "text.secondary",
                    children: t("recordingStudioEnhanced.tips")
                }, void 0, false, {
                    fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                    lineNumber: 511,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
                lineNumber: 505,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/RecordingStudioEnhanced.jsx",
        lineNumber: 251,
        columnNumber: 10
    }, this);
}
_s(RecordingStudioEnhanced, "3mm0x2lDW+WB6zHFT6Qb0+EOrFY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = RecordingStudioEnhanced;
var _c;
__turbopack_context__.k.register(_c, "RecordingStudioEnhanced");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RecordingStudioEnhancedModal.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RecordingStudioEnhancedModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AppBar/AppBar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Toolbar/Toolbar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slide$2f$Slide$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Slide/Slide.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Save.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudioEnhanced$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RecordingStudioEnhanced.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
/**
 * @fileoverview RecordingStudioEnhancedModal — Fullscreen dialog wrapper for RecordingStudioEnhanced.
 *
 * Renders RecordingStudioEnhanced inside a fullscreen MUI Dialog with Save / Cancel actions.
 * The current studio state is captured via a ref that RecordingStudioEnhanced writes to on each
 * render, so the modal can read it on Save without requiring internal plumbing changes.
 */ 'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const Transition = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = function Transition(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "3840dcf3ca6471d07e587158c97017a973641e4a33ff637038dde12c91f25982") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "3840dcf3ca6471d07e587158c97017a973641e4a33ff637038dde12c91f25982";
    }
    let t0;
    if ($[1] !== props || $[2] !== ref) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slide$2f$Slide$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "up",
            ref: ref,
            ...props
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudioEnhancedModal.jsx",
            lineNumber: 35,
            columnNumber: 10
        }, this);
        $[1] = props;
        $[2] = ref;
        $[3] = t0;
    } else {
        t0 = $[3];
    }
    return t0;
});
_c1 = Transition;
function RecordingStudioEnhancedModal(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(41);
    if ($[0] !== "3840dcf3ca6471d07e587158c97017a973641e4a33ff637038dde12c91f25982") {
        for(let $i = 0; $i < 41; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "3840dcf3ca6471d07e587158c97017a973641e4a33ff637038dde12c91f25982";
    }
    const { open, onClose, onSave, title, metadata: t1, gradeId, nodeKey } = t0;
    let t2;
    if ($[1] !== t1) {
        t2 = t1 === undefined ? {} : t1;
        $[1] = t1;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const metadata = t2;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const stateRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    let t3;
    if ($[3] !== onClose || $[4] !== onSave) {
        t3 = ({
            "RecordingStudioEnhancedModal[handleSave]": ()=>{
                if (typeof onSave === "function" && stateRef.current) {
                    onSave(stateRef.current);
                }
                onClose?.();
            }
        })["RecordingStudioEnhancedModal[handleSave]"];
        $[3] = onClose;
        $[4] = onSave;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const handleSave = t3;
    let t4;
    if ($[6] !== t || $[7] !== title) {
        t4 = title || t("recordingStudioEnhancedModal.defaultTitle", "Generate Conversation");
        $[6] = t;
        $[7] = title;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const displayTitle = t4;
    let t5;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            position: "relative"
        };
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] !== t) {
        t6 = t("recordingStudioEnhancedModal.cancel", "Cancel");
        $[10] = t;
        $[11] = t6;
    } else {
        t6 = $[11];
    }
    let t7;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/RecordingStudioEnhancedModal.jsx",
            lineNumber: 129,
            columnNumber: 10
        }, this);
        $[12] = t7;
    } else {
        t7 = $[12];
    }
    let t8;
    if ($[13] !== onClose || $[14] !== t6) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            edge: "start",
            color: "inherit",
            onClick: onClose,
            "aria-label": t6,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudioEnhancedModal.jsx",
            lineNumber: 136,
            columnNumber: 10
        }, this);
        $[13] = onClose;
        $[14] = t6;
        $[15] = t8;
    } else {
        t8 = $[15];
    }
    let t9;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            ml: 2,
            flex: 1
        };
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    let t10;
    if ($[17] !== displayTitle) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t9,
            variant: "h6",
            component: "div",
            noWrap: true,
            children: displayTitle
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudioEnhancedModal.jsx",
            lineNumber: 155,
            columnNumber: 11
        }, this);
        $[17] = displayTitle;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    let t11;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/RecordingStudioEnhancedModal.jsx",
            lineNumber: 163,
            columnNumber: 11
        }, this);
        $[19] = t11;
    } else {
        t11 = $[19];
    }
    let t12;
    if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            ml: 2
        };
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] !== t) {
        t13 = t("recordingStudioEnhancedModal.saveConversation", "Save Conversation");
        $[21] = t;
        $[22] = t13;
    } else {
        t13 = $[22];
    }
    let t14;
    if ($[23] !== handleSave || $[24] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            color: "primary",
            variant: "contained",
            startIcon: t11,
            onClick: handleSave,
            sx: t12,
            children: t13
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudioEnhancedModal.jsx",
            lineNumber: 187,
            columnNumber: 11
        }, this);
        $[23] = handleSave;
        $[24] = t13;
        $[25] = t14;
    } else {
        t14 = $[25];
    }
    let t15;
    if ($[26] !== t10 || $[27] !== t14 || $[28] !== t8) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t5,
            color: "default",
            elevation: 1,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    t8,
                    t10,
                    t14
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/RecordingStudioEnhancedModal.jsx",
                lineNumber: 196,
                columnNumber: 57
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudioEnhancedModal.jsx",
            lineNumber: 196,
            columnNumber: 11
        }, this);
        $[26] = t10;
        $[27] = t14;
        $[28] = t8;
        $[29] = t15;
    } else {
        t15 = $[29];
    }
    let t16;
    if ($[30] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            height: "100%",
            overflow: "auto",
            bgcolor: "background.default"
        };
        $[30] = t16;
    } else {
        t16 = $[30];
    }
    let t17;
    if ($[31] !== gradeId || $[32] !== metadata || $[33] !== nodeKey || $[34] !== onSave) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t16,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RecordingStudioEnhanced$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                gradeId: gradeId,
                nodeKey: nodeKey,
                metadata: metadata,
                stateRef: stateRef,
                onRecordingComplete: onSave
            }, void 0, false, {
                fileName: "[project]/src/components/RecordingStudioEnhancedModal.jsx",
                lineNumber: 217,
                columnNumber: 25
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/RecordingStudioEnhancedModal.jsx",
            lineNumber: 217,
            columnNumber: 11
        }, this);
        $[31] = gradeId;
        $[32] = metadata;
        $[33] = nodeKey;
        $[34] = onSave;
        $[35] = t17;
    } else {
        t17 = $[35];
    }
    let t18;
    if ($[36] !== onClose || $[37] !== open || $[38] !== t15 || $[39] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fullScreen: true,
            open: open,
            onClose: onClose,
            TransitionComponent: Transition,
            keepMounted: false,
            children: [
                t15,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/RecordingStudioEnhancedModal.jsx",
            lineNumber: 228,
            columnNumber: 11
        }, this);
        $[36] = onClose;
        $[37] = open;
        $[38] = t15;
        $[39] = t17;
        $[40] = t18;
    } else {
        t18 = $[40];
    }
    return t18;
}
_s(RecordingStudioEnhancedModal, "0RywTV/5C+mt4X3OlBw0iP0DFcc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c2 = RecordingStudioEnhancedModal;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Transition$React.forwardRef");
__turbopack_context__.k.register(_c1, "Transition");
__turbopack_context__.k.register(_c2, "RecordingStudioEnhancedModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/AIFeedbackWidget.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AIFeedbackWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview AIFeedbackWidget - Reusable component for collecting user feedback on AI-generated content
 * 
 * Displays thumbs up/down buttons and allows users to provide optional reasons
 * for negative feedback. Integrates with DataStore to persist feedback.
 * 
 * @example
 * <AIFeedbackWidget
 *   contentType="CHAT_MESSAGE"
 *   messageId={message.id}
 *   generatedContent={message.content}
 *   model="gpt-4"
 *   prompt={userPrompt}
 *   metadata={{ unitId: currentUnit.id }}
 * />
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Popover$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Popover/Popover.js [app-client] (ecmascript) <export default as Popover>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControl/FormControl.js [app-client] (ecmascript) <export default as FormControl>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$FormLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormLabel$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormLabel/FormLabel.js [app-client] (ecmascript) <export default as FormLabel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormGroup$2f$FormGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormGroup$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormGroup/FormGroup.js [app-client] (ecmascript) <export default as FormGroup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-client] (ecmascript) <export default as FormControlLabel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript) <export default as Snackbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ThumbUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ThumbUp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ThumbDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ThumbDown.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ThumbUpOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ThumbUpOutlined.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ThumbDownOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ThumbDownOutlined.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
// Gen 2 enum values - must match schema definitions
const AiContentType = {
    CHAT_MESSAGE: 'CHAT_MESSAGE',
    CONTENT_COMPLETION: 'CONTENT_COMPLETION',
    AUDIO_GENERATION: 'AUDIO_GENERATION',
    IMAGE_GENERATION: 'IMAGE_GENERATION',
    DOCUMENT_ANALYSIS: 'DOCUMENT_ANALYSIS',
    VOCABULARY_EXTRACTION: 'VOCABULARY_EXTRACTION',
    TRANSCRIPTION: 'TRANSCRIPTION',
    IMAGE_DESCRIPTION: 'IMAGE_DESCRIPTION',
    GRADING_FEEDBACK: 'GRADING_FEEDBACK',
    BLOCK_SUGGESTION: 'BLOCK_SUGGESTION'
};
const AiFeedbackType = {
    POSITIVE: 'POSITIVE',
    NEGATIVE: 'NEGATIVE'
};
const AiFeedbackReason = {
    INCORRECT: 'INCORRECT',
    INCOMPLETE: 'INCOMPLETE',
    INAPPROPRIATE: 'INAPPROPRIATE',
    NOT_HELPFUL: 'NOT_HELPFUL',
    IRRELEVANT: 'IRRELEVANT',
    POOR_QUALITY: 'POOR_QUALITY',
    OTHER: 'OTHER'
};
const REASON_LABELS = {
    INCORRECT: 'Incorrect information',
    INCOMPLETE: 'Incomplete or missing details',
    INAPPROPRIATE: 'Inappropriate content',
    NOT_HELPFUL: "Doesn't answer the question",
    IRRELEVANT: 'Off-topic or irrelevant',
    POOR_QUALITY: 'Poor quality (grammar, formatting, etc.)',
    OTHER: 'Other (specify below)'
};
function AIFeedbackWidget({ contentType, generatedContent, model, prompt, messageId, unitId, gradeId, documentId, sessionId, metadata, onFeedbackSubmitted, size = 'small', showLabels = false }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('components');
    const [feedbackType, setFeedbackType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [anchorEl, setAnchorEl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedReasons, setSelectedReasons] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [comment, setComment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isSubmitting, setIsSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [snackbar, setSnackbar] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        open: false,
        message: '',
        severity: 'success'
    });
    const handleThumbsUp = ()=>{
        if (feedbackType === 'POSITIVE') {
            // Remove feedback
            setFeedbackType(null);
        } else {
            setFeedbackType('POSITIVE');
            submitFeedback('POSITIVE');
        }
    };
    const handleThumbsDown = (event)=>{
        if (feedbackType === 'NEGATIVE') {
            // Remove feedback
            setFeedbackType(null);
            setAnchorEl(null);
        } else {
            setFeedbackType('NEGATIVE');
            setAnchorEl(event.currentTarget);
        }
    };
    const handleReasonToggle = (reason)=>{
        const newReasons = new Set(selectedReasons);
        if (newReasons.has(reason)) {
            newReasons.delete(reason);
        } else {
            newReasons.add(reason);
        }
        setSelectedReasons(newReasons);
    };
    const handleClosePopover = ()=>{
        setAnchorEl(null);
    };
    const submitFeedback = async (type, reasons, userComment)=>{
        setIsSubmitting(true);
        try {
            const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
            const { data: feedback } = await client.models.AIFeedback.create({
                contentType: AiContentType[contentType],
                feedbackType: type === 'POSITIVE' ? AiFeedbackType.POSITIVE : AiFeedbackType.NEGATIVE,
                reasons: reasons?.map((r)=>AiFeedbackReason[r]),
                comment: userComment,
                model,
                prompt,
                generatedContent,
                unitID: unitId,
                gradeID: gradeId,
                documentID: documentId,
                messageId,
                sessionId,
                metadata: metadata ? JSON.stringify(metadata) : undefined
            });
            setSnackbar({
                open: true,
                message: 'Thank you for your feedback!',
                severity: 'success'
            });
            if (feedback) {
                onFeedbackSubmitted?.(feedback);
            }
            // Clear the form
            setSelectedReasons(new Set());
            setComment('');
            handleClosePopover();
        } catch (error) {
            console.error('Error submitting feedback:', error);
            setSnackbar({
                open: true,
                message: 'Failed to submit feedback. Please try again.',
                severity: 'error'
            });
        } finally{
            setIsSubmitting(false);
        }
    };
    const handleSubmitNegativeFeedback = ()=>{
        const reasonArray = Array.from(selectedReasons);
        submitFeedback('NEGATIVE', reasonArray, comment);
    };
    const open = Boolean(anchorEl);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: 'flex',
                    gap: 0.5,
                    alignItems: 'center'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: "This was helpful",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                size: size,
                                onClick: handleThumbsUp,
                                color: feedbackType === 'POSITIVE' ? 'success' : 'default',
                                disabled: isSubmitting,
                                sx: {
                                    opacity: feedbackType === 'NEGATIVE' ? 0.3 : 1,
                                    '&:hover': {
                                        backgroundColor: feedbackType === 'POSITIVE' ? 'success.light' : undefined
                                    }
                                },
                                children: feedbackType === 'POSITIVE' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ThumbUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    fontSize: size
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                    lineNumber: 216,
                                    columnNumber: 46
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ThumbUpOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    fontSize: size
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                    lineNumber: 216,
                                    columnNumber: 80
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                lineNumber: 210,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                            lineNumber: 209,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                        lineNumber: 208,
                        columnNumber: 9
                    }, this),
                    showLabels && feedbackType === 'POSITIVE' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        color: "success.main",
                        children: t('aiFeedbackWidget.helpful')
                    }, void 0, false, {
                        fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                        lineNumber: 221,
                        columnNumber: 55
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                        title: "This needs improvement",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
                                size: size,
                                onClick: handleThumbsDown,
                                color: feedbackType === 'NEGATIVE' ? 'error' : 'default',
                                disabled: isSubmitting,
                                sx: {
                                    opacity: feedbackType === 'POSITIVE' ? 0.3 : 1,
                                    '&:hover': {
                                        backgroundColor: feedbackType === 'NEGATIVE' ? 'error.light' : undefined
                                    }
                                },
                                children: feedbackType === 'NEGATIVE' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ThumbDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    fontSize: size
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                    lineNumber: 233,
                                    columnNumber: 46
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ThumbDownOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    fontSize: size
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                    lineNumber: 233,
                                    columnNumber: 82
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                lineNumber: 227,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                            lineNumber: 226,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                        lineNumber: 225,
                        columnNumber: 9
                    }, this),
                    showLabels && feedbackType === 'NEGATIVE' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "caption",
                        color: "error.main",
                        children: t('aiFeedbackWidget.needsImprovement')
                    }, void 0, false, {
                        fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                        lineNumber: 238,
                        columnNumber: 55
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                lineNumber: 203,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Popover$3e$__["Popover"], {
                open: open,
                anchorEl: anchorEl,
                onClose: handleClosePopover,
                anchorOrigin: {
                    vertical: 'bottom',
                    horizontal: 'left'
                },
                transformOrigin: {
                    vertical: 'top',
                    horizontal: 'left'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: {
                        p: 2,
                        minWidth: 300,
                        maxWidth: 400
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "subtitle2",
                            gutterBottom: true,
                            children: t('aiFeedbackWidget.whatToImprove')
                        }, void 0, false, {
                            fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                            lineNumber: 256,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControl$3e$__["FormControl"], {
                            component: "fieldset",
                            variant: "standard",
                            fullWidth: true,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$FormLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormLabel$3e$__["FormLabel"], {
                                    component: "legend",
                                    sx: {
                                        fontSize: '0.875rem',
                                        mb: 1
                                    },
                                    children: t('aiFeedbackWidget.selectAllThatApply')
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                    lineNumber: 261,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormGroup$2f$FormGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormGroup$3e$__["FormGroup"], {
                                    children: Object.entries(REASON_LABELS).map(([key, label])=>{
                                        const reasonKey = key;
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__["FormControlLabel"], {
                                            control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                                                checked: selectedReasons.has(reasonKey),
                                                onChange: ()=>handleReasonToggle(reasonKey),
                                                size: "small"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                                lineNumber: 270,
                                                columnNumber: 59
                                            }, this),
                                            label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                variant: "body2",
                                                children: label
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                                lineNumber: 270,
                                                columnNumber: 181
                                            }, this)
                                        }, key, false, {
                                            fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                            lineNumber: 270,
                                            columnNumber: 22
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                    lineNumber: 267,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                            lineNumber: 260,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                            fullWidth: true,
                            multiline: true,
                            rows: 3,
                            placeholder: "Additional comments (optional)",
                            value: comment,
                            onChange: (e)=>setComment(e.target.value),
                            sx: {
                                mt: 2
                            },
                            size: "small"
                        }, void 0, false, {
                            fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                            lineNumber: 275,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                            sx: {
                                display: 'flex',
                                gap: 1,
                                mt: 2,
                                justifyContent: 'flex-end'
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "outlined",
                                    size: "small",
                                    onClick: handleClosePopover,
                                    disabled: isSubmitting,
                                    children: t('aiFeedbackWidget.cancel')
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                    lineNumber: 285,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    variant: "contained",
                                    size: "small",
                                    onClick: handleSubmitNegativeFeedback,
                                    disabled: isSubmitting || selectedReasons.size === 0,
                                    children: t('aiFeedbackWidget.submit')
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                                    lineNumber: 288,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                            lineNumber: 279,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                    lineNumber: 251,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                lineNumber: 244,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
                open: snackbar.open,
                autoHideDuration: 3000,
                onClose: ()=>setSnackbar({
                        ...snackbar,
                        open: false
                    }),
                anchorOrigin: {
                    vertical: 'bottom',
                    horizontal: 'center'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                    onClose: ()=>setSnackbar({
                            ...snackbar,
                            open: false
                        }),
                    severity: snackbar.severity,
                    variant: "filled",
                    sx: {
                        width: '100%'
                    },
                    children: snackbar.message
                }, void 0, false, {
                    fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                    lineNumber: 303,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/AIFeedbackWidget.tsx",
                lineNumber: 296,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(AIFeedbackWidget, "4HK+rgThDdxGSBTo30EBLcGf8u4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = AIFeedbackWidget;
var _c;
__turbopack_context__.k.register(_c, "AIFeedbackWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/SortableAnswers.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SortableAnswers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrag$2f$useDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-dnd/dist/hooks/useDrag/useDrag.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-dnd/dist/hooks/useDrop/useDrop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/react-dnd-multi-backend/dist/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rdndmb$2d$html5$2d$to$2d$touch$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rdndmb-html5-to-touch/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-client] (ecmascript) <export default as FormControlLabel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Switch/Switch.js [app-client] (ecmascript) <export default as Switch>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$DragIndicator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/DragIndicator.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Clear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Clear.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
const reorder = (list, startIndex, endIndex)=>{
    const result = Array.from(list);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);
    return result;
};
function SortableAnswers(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    if ($[0] !== "7dfcaa0e86bd9c56deb4ecb9440c61409962d37dc39e70685468874e236476cf") {
        for(let $i = 0; $i < 11; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7dfcaa0e86bd9c56deb4ecb9440c61409962d37dc39e70685468874e236476cf";
    }
    const { answers, onQuestionChange, onCorrectChange, onQuestionDelete, onQuestionReorder } = t0;
    let t1;
    if ($[1] !== answers || $[2] !== onCorrectChange || $[3] !== onQuestionChange || $[4] !== onQuestionDelete || $[5] !== onQuestionReorder) {
        t1 = function list() {
            console.log("answers", answers);
            const _answers = answers || [];
            return _answers.map({
                "SortableAnswers[list > _answers.map()]": (answer, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Answer, {
                        data: answer,
                        answers: answers,
                        index: index,
                        onQuestionChange: onQuestionChange,
                        onCorrectChange: onCorrectChange,
                        onQuestionDelete: onQuestionDelete,
                        onQuestionReorder: onQuestionReorder
                    }, index, false, {
                        fileName: "[project]/src/components/SortableAnswers.jsx",
                        lineNumber: 38,
                        columnNumber: 70
                    }, this)
            }["SortableAnswers[list > _answers.map()]"]);
        };
        $[1] = answers;
        $[2] = onCorrectChange;
        $[3] = onQuestionChange;
        $[4] = onQuestionDelete;
        $[5] = onQuestionReorder;
        $[6] = t1;
    } else {
        t1 = $[6];
    }
    const list = t1;
    let t2;
    if ($[7] !== list) {
        t2 = list();
        $[7] = list;
        $[8] = t2;
    } else {
        t2 = $[8];
    }
    let t3;
    if ($[9] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DndProvider"], {
            options: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rdndmb$2d$html5$2d$to$2d$touch$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HTML5toTouch"],
            children: t2
        }, void 0, false, {
            fileName: "[project]/src/components/SortableAnswers.jsx",
            lineNumber: 61,
            columnNumber: 10
        }, this);
        $[9] = t2;
        $[10] = t3;
    } else {
        t3 = $[10];
    }
    return t3;
}
_c = SortableAnswers;
function Answer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(56);
    if ($[0] !== "7dfcaa0e86bd9c56deb4ecb9440c61409962d37dc39e70685468874e236476cf") {
        for(let $i = 0; $i < 56; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7dfcaa0e86bd9c56deb4ecb9440c61409962d37dc39e70685468874e236476cf";
    }
    const { data, index, answers, onQuestionReorder, onQuestionChange, onCorrectChange, onQuestionDelete } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    const tCommon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("common");
    console.log("Answer", data);
    let t1;
    if ($[1] !== index) {
        t1 = {
            type: "answer",
            item: {
                type: "answer",
                id: index,
                index
            },
            collect: _temp
        };
        $[1] = index;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [t2, drag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrag$2f$useDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrag"])(t1);
    const { isDragging } = t2;
    let t3;
    if ($[3] !== answers || $[4] !== index || $[5] !== onQuestionReorder) {
        t3 = {
            accept: "answer",
            drop: (draggedItem, monitor_0)=>{
                const draggedIndex = draggedItem.index;
                const droppedIndex = index;
                if (draggedIndex === droppedIndex) {
                    return;
                }
                const newAnswers = reorder(answers, draggedIndex, droppedIndex);
                onQuestionReorder(newAnswers);
            },
            collect: _temp2
        };
        $[3] = answers;
        $[4] = index;
        $[5] = onQuestionReorder;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const [t4, drop] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrop"])(t3);
    const { isOver } = t4;
    const t5 = isOver ? "var(--mui-palette-action-hover, lightblue)" : "var(--mui-palette-background-paper, white)";
    let t6;
    if ($[7] !== t5) {
        t6 = {
            backgroundColor: t5
        };
        $[7] = t5;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    const t7 = isDragging ? 0.5 : 1;
    let t8;
    if ($[9] !== t7) {
        t8 = {
            opacity: t7
        };
        $[9] = t7;
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$DragIndicator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/SortableAnswers.jsx",
            lineNumber: 159,
            columnNumber: 10
        }, this);
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    const t10 = index + 1;
    let t11;
    if ($[12] !== t || $[13] !== t10) {
        t11 = t("sortableAnswers.answerLabel", {
            number: t10
        });
        $[12] = t;
        $[13] = t10;
        $[14] = t11;
    } else {
        t11 = $[14];
    }
    const t12 = data.answer || "";
    let t13;
    if ($[15] !== index || $[16] !== onQuestionChange) {
        t13 = ({
            "Answer[<TextField>.onChange]": (event)=>{
                onQuestionChange(event, index);
            }
        })["Answer[<TextField>.onChange]"];
        $[15] = index;
        $[16] = onQuestionChange;
        $[17] = t13;
    } else {
        t13 = $[17];
    }
    let t14;
    if ($[18] !== t11 || $[19] !== t12 || $[20] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: t11,
            value: t12,
            onChange: t13,
            fullWidth: true,
            inputRef: _AnswerTextFieldInputRef
        }, void 0, false, {
            fileName: "[project]/src/components/SortableAnswers.jsx",
            lineNumber: 192,
            columnNumber: 11
        }, this);
        $[18] = t11;
        $[19] = t12;
        $[20] = t13;
        $[21] = t14;
    } else {
        t14 = $[21];
    }
    let t15;
    if ($[22] !== data.correct) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
            color: "primary",
            checked: data.correct
        }, void 0, false, {
            fileName: "[project]/src/components/SortableAnswers.jsx",
            lineNumber: 202,
            columnNumber: 11
        }, this);
        $[22] = data.correct;
        $[23] = t15;
    } else {
        t15 = $[23];
    }
    let t16;
    if ($[24] !== data.correct || $[25] !== t) {
        t16 = data.correct ? t("sortableAnswers.correct") : t("sortableAnswers.incorrect");
        $[24] = data.correct;
        $[25] = t;
        $[26] = t16;
    } else {
        t16 = $[26];
    }
    let t17;
    if ($[27] !== index || $[28] !== onCorrectChange) {
        t17 = ({
            "Answer[<FormControlLabel>.onChange]": (event_0)=>{
                onCorrectChange(event_0, index);
            }
        })["Answer[<FormControlLabel>.onChange]"];
        $[27] = index;
        $[28] = onCorrectChange;
        $[29] = t17;
    } else {
        t17 = $[29];
    }
    let t18;
    if ($[30] !== data.correct || $[31] !== t15 || $[32] !== t16 || $[33] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__["FormControlLabel"], {
            value: data.correct,
            "data-tour": "correct-checkbox",
            control: t15,
            label: t16,
            onChange: t17,
            labelPlacement: "bottom"
        }, void 0, false, {
            fileName: "[project]/src/components/SortableAnswers.jsx",
            lineNumber: 232,
            columnNumber: 11
        }, this);
        $[30] = data.correct;
        $[31] = t15;
        $[32] = t16;
        $[33] = t17;
        $[34] = t18;
    } else {
        t18 = $[34];
    }
    let t19;
    if ($[35] !== tCommon) {
        t19 = tCommon("actions.delete");
        $[35] = tCommon;
        $[36] = t19;
    } else {
        t19 = $[36];
    }
    let t20;
    if ($[37] !== index || $[38] !== onQuestionDelete) {
        t20 = ({
            "Answer[<IconButton>.onClick]": ()=>{
                onQuestionDelete(index);
            }
        })["Answer[<IconButton>.onClick]"];
        $[37] = index;
        $[38] = onQuestionDelete;
        $[39] = t20;
    } else {
        t20 = $[39];
    }
    let t21;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Clear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/SortableAnswers.jsx",
            lineNumber: 264,
            columnNumber: 11
        }, this);
        $[40] = t21;
    } else {
        t21 = $[40];
    }
    let t22;
    if ($[41] !== t19 || $[42] !== t20) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"], {
            "aria-label": t19,
            onClick: t20,
            children: t21
        }, void 0, false, {
            fileName: "[project]/src/components/SortableAnswers.jsx",
            lineNumber: 271,
            columnNumber: 11
        }, this);
        $[41] = t19;
        $[42] = t20;
        $[43] = t22;
    } else {
        t22 = $[43];
    }
    let t23;
    if ($[44] !== t14 || $[45] !== t18 || $[46] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
            border: "thin solid",
            padding: "0.5rem",
            margin: "0.5rem",
            direction: "row",
            spacing: 2,
            maxWidth: "40rem",
            alignItems: "center",
            children: [
                t9,
                t14,
                t18,
                t22
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/SortableAnswers.jsx",
            lineNumber: 280,
            columnNumber: 11
        }, this);
        $[44] = t14;
        $[45] = t18;
        $[46] = t22;
        $[47] = t23;
    } else {
        t23 = $[47];
    }
    let t24;
    if ($[48] !== drag || $[49] !== t23 || $[50] !== t8) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: drag,
            style: t8,
            children: t23
        }, void 0, false, {
            fileName: "[project]/src/components/SortableAnswers.jsx",
            lineNumber: 290,
            columnNumber: 11
        }, this);
        $[48] = drag;
        $[49] = t23;
        $[50] = t8;
        $[51] = t24;
    } else {
        t24 = $[51];
    }
    let t25;
    if ($[52] !== drop || $[53] !== t24 || $[54] !== t6) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: drop,
            style: t6,
            children: t24
        }, void 0, false, {
            fileName: "[project]/src/components/SortableAnswers.jsx",
            lineNumber: 300,
            columnNumber: 11
        }, this);
        $[52] = drop;
        $[53] = t24;
        $[54] = t6;
        $[55] = t25;
    } else {
        t25 = $[55];
    }
    return t25;
}
_s(Answer, "wyeo+Tg0LgCjaAUKqx7D2aw+/tM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrag$2f$useDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrag"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrop"]
    ];
});
_c1 = Answer;
function _AnswerTextFieldInputRef(input) {
    if (input != null && !input?.value) {
        input.focus();
    }
}
function _temp2(monitor_1) {
    return {
        isOver: !!monitor_1.isOver()
    };
}
function _temp(monitor) {
    return {
        isDragging: !!monitor.isDragging()
    };
}
var _c, _c1;
__turbopack_context__.k.register(_c, "SortableAnswers");
__turbopack_context__.k.register(_c1, "Answer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ToolbarScrollButton.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ToolbarScrollButton",
    ()=>ToolbarScrollButton,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview ToolbarScrollButton - Scroll arrow button matching MUI TabScrollButton style.
 * @module ToolbarScrollButton
 *
 * Provides consistent scroll arrow buttons for horizontally scrollable toolbars.
 * Styled to exactly match MUI Tabs scroll buttons for visual consistency.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ButtonBase$2f$ButtonBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ButtonBase/ButtonBase.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$KeyboardArrowLeft$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/KeyboardArrowLeft.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$KeyboardArrowRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/KeyboardArrowRight.js [app-client] (ecmascript)");
;
;
;
;
;
;
const ToolbarScrollButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](_c = function ToolbarScrollButton(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "0d244b805f171aee06e0c1888942d417f8f3e72b559415fc22bf6fb1fa786905") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0d244b805f171aee06e0c1888942d417f8f3e72b559415fc22bf6fb1fa786905";
    }
    const { direction, onClick, disabled: t1, ariaLabel, height: t2 } = t0;
    const disabled = t1 === undefined ? false : t1;
    const height = t2 === undefined ? "2rem" : t2;
    const Icon = direction === "left" ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$KeyboardArrowLeft$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$KeyboardArrowRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
    const t3 = disabled ? 0.3 : 1;
    let t4;
    let t5;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            backgroundColor: "action.hover"
        };
        t5 = {
            opacity: 0.3
        };
        $[1] = t4;
        $[2] = t5;
    } else {
        t4 = $[1];
        t5 = $[2];
    }
    let t6;
    if ($[3] !== height || $[4] !== t3) {
        t6 = {
            width: "2rem",
            minWidth: "2rem",
            height,
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
            borderRadius: "4px",
            opacity: t3,
            color: "text.secondary",
            transition: "opacity 0.2s ease",
            "&:hover": t4,
            "&.Mui-disabled": t5
        };
        $[3] = height;
        $[4] = t3;
        $[5] = t6;
    } else {
        t6 = $[5];
    }
    let t7;
    if ($[6] !== Icon) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {}, void 0, false, {
            fileName: "[project]/src/components/ToolbarScrollButton.jsx",
            lineNumber: 84,
            columnNumber: 10
        }, this);
        $[6] = Icon;
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    let t8;
    if ($[8] !== ariaLabel || $[9] !== disabled || $[10] !== onClick || $[11] !== t6 || $[12] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ButtonBase$2f$ButtonBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: onClick,
            disabled: disabled,
            "aria-label": ariaLabel,
            sx: t6,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/ToolbarScrollButton.jsx",
            lineNumber: 92,
            columnNumber: 10
        }, this);
        $[8] = ariaLabel;
        $[9] = disabled;
        $[10] = onClick;
        $[11] = t6;
        $[12] = t7;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    return t8;
});
_c1 = ToolbarScrollButton;
const __TURBOPACK__default__export__ = ToolbarScrollButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "ToolbarScrollButton$React.memo");
__turbopack_context__.k.register(_c1, "ToolbarScrollButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/BotAvatar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BotAvatar",
    ()=>BotAvatar,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/DiceBearAvatar.tsx [app-client] (ecmascript)");
;
;
;
/** Default bot appearance — purple-ish tones, friendly look */ const BOT_DEFAULTS = {
    backgroundColor: [
        'b6e3f4'
    ]
};
function BotAvatar(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "eca1d0f2a7ecc331cdb394cc36e2627ff225f201128978170a9be6d52005580c") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "eca1d0f2a7ecc331cdb394cc36e2627ff225f201128978170a9be6d52005580c";
    }
    const { size: t1, style: t2, overrides } = t0;
    const size = t1 === undefined ? 28 : t1;
    const style = t2 === undefined ? "simple" : t2;
    const t3 = overrides || BOT_DEFAULTS;
    let t4;
    if ($[1] !== size || $[2] !== style || $[3] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DiceBearAvatar"], {
            seed: "homework-supply-bot",
            style: style,
            size: size,
            label: "AI Assistant",
            overrides: t3
        }, void 0, false, {
            fileName: "[project]/src/components/BotAvatar.tsx",
            lineNumber: 43,
            columnNumber: 10
        }, this);
        $[1] = size;
        $[2] = style;
        $[3] = t3;
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    return t4;
}
_c = BotAvatar;
const __TURBOPACK__default__export__ = BotAvatar;
var _c;
__turbopack_context__.k.register(_c, "BotAvatar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/GlobalChatDrawer.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GlobalChatDrawer",
    ()=>GlobalChatDrawer,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * GlobalChatDrawer - Global drawer containing ChatSidebar
 * 
 * A persistent drawer that slides in from the right containing the AI assistant chat.
 * Accessible from all pages via GlobalChatButton or keyboard shortcut.
 * 
 * @see docs/GLOBAL_CHAT_INTEGRATION_PLAN.md
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Drawer$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Drawer/Drawer.js [app-client] (ecmascript) <export default as Drawer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/useMediaQuery/index.js [app-client] (ecmascript) <export default as useMediaQuery>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/chatContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ChatSidebar.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
function GlobalChatDrawer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "d6ad0a27a62e33729a5c23ed6f6e7e348e68c8c69328c156936f3e98c5d563fa") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d6ad0a27a62e33729a5c23ed6f6e7e348e68c8c69328c156936f3e98c5d563fa";
    }
    const { width: t1 } = t0;
    const width = t1 === undefined ? 450 : t1;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            noSsr: true
        };
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    const isMobile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__["useMediaQuery"])("(max-width:599.95px)", t2);
    const { isChatOpen, setIsChatOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$chatContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let t3;
    if ($[2] !== setIsChatOpen) {
        t3 = ({
            "GlobalChatDrawer[handleClose]": ()=>{
                console.log("[GlobalChatDrawer] Closing chat");
                setIsChatOpen(false);
            }
        })["GlobalChatDrawer[handleClose]"];
        $[2] = setIsChatOpen;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const handleClose = t3;
    const drawerWidth = isMobile ? "100%" : width;
    const t4 = isMobile ? "temporary" : "persistent";
    let t5;
    if ($[4] !== isMobile) {
        t5 = !isMobile && {
            top: 64,
            height: "calc(100% - 64px)"
        };
        $[4] = isMobile;
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    let t6;
    if ($[6] !== drawerWidth || $[7] !== t5) {
        t6 = {
            width: drawerWidth,
            boxSizing: "border-box",
            ...t5
        };
        $[6] = drawerWidth;
        $[7] = t5;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] !== drawerWidth || $[10] !== t6) {
        t7 = {
            width: drawerWidth,
            flexShrink: 0,
            "& .MuiDrawer-paper": t6
        };
        $[9] = drawerWidth;
        $[10] = t6;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            keepMounted: true
        };
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            flex: 1,
            overflow: "hidden",
            display: "flex",
            flexDirection: "column"
        };
        $[13] = t9;
    } else {
        t9 = $[13];
    }
    let t10;
    if ($[14] !== handleClose) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: t9,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatSidebar$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                onClose: handleClose
            }, void 0, false, {
                fileName: "[project]/src/components/GlobalChatDrawer.jsx",
                lineNumber: 129,
                columnNumber: 24
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/GlobalChatDrawer.jsx",
            lineNumber: 129,
            columnNumber: 11
        }, this);
        $[14] = handleClose;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    let t11;
    if ($[16] !== handleClose || $[17] !== isChatOpen || $[18] !== t10 || $[19] !== t4 || $[20] !== t7) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Drawer$3e$__["Drawer"], {
            anchor: "right",
            open: isChatOpen,
            onClose: handleClose,
            variant: t4,
            sx: t7,
            ModalProps: t8,
            "data-testid": "global-chat-drawer",
            "data-tour": "chat-sidebar",
            children: t10
        }, void 0, false, {
            fileName: "[project]/src/components/GlobalChatDrawer.jsx",
            lineNumber: 137,
            columnNumber: 11
        }, this);
        $[16] = handleClose;
        $[17] = isChatOpen;
        $[18] = t10;
        $[19] = t4;
        $[20] = t7;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    return t11;
}
_s(GlobalChatDrawer, "HYb6Gz3jDS+doIbqP6Vk7NIdJSo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__["useMediaQuery"]
    ];
});
_c = GlobalChatDrawer;
const __TURBOPACK__default__export__ = GlobalChatDrawer;
var _c;
__turbopack_context__.k.register(_c, "GlobalChatDrawer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/OfflineBanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OfflineBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript) <export default as Snackbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slide$2f$Slide$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Slide$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Slide/Slide.js [app-client] (ecmascript) <export default as Slide>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$WifiOff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/WifiOff.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudSync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CloudSync.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useNetworkStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useNetworkStatus.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function OfflineBanner() {
    _s();
    const { isOnline } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useNetworkStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNetworkStatus"])();
    const [pendingCount, setPendingCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [justReconnected, setJustReconnected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const wasOfflineRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    // Listen for SW messages: sync queue count updates AND Background Sync triggers
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfflineBanner.useEffect": ()=>{
            const handler = {
                "OfflineBanner.useEffect.handler": async (event)=>{
                    if (event.data?.type === 'SYNC_QUEUE_COUNT') {
                        setPendingCount(event.data.count ?? 0);
                    }
                    if (event.data?.type === 'PROCESS_SYNC_QUEUE') {
                        try {
                            const { processQueue } = await __turbopack_context__.A("[project]/src/offline/SyncQueue.ts [app-client] (ecmascript, async loader)");
                            const result = await processQueue({
                                "OfflineBanner.useEffect.handler": async (model, operation, payload)=>{
                                    const { generateClient } = await __turbopack_context__.A("[project]/node_modules/aws-amplify/dist/esm/api/index.mjs [app-client] (ecmascript, async loader)");
                                    const client = generateClient();
                                    if (operation === 'update') {
                                        await client.models[model].update(payload);
                                    } else if (operation === 'create') {
                                        await client.models[model].create(payload);
                                    } else if (operation === 'delete') {
                                        await client.models[model].delete(payload);
                                    }
                                }
                            }["OfflineBanner.useEffect.handler"]);
                            setPendingCount(result.remaining);
                            // Notify SW that sync is complete
                            navigator.serviceWorker?.controller?.postMessage({
                                type: 'SYNC_COMPLETE',
                                result
                            });
                        } catch  {
                        // Queue processing failed — will retry on next trigger
                        }
                    }
                }
            }["OfflineBanner.useEffect.handler"];
            if (typeof navigator !== 'undefined' && navigator.serviceWorker) {
                navigator.serviceWorker.addEventListener('message', handler);
                return ({
                    "OfflineBanner.useEffect": ()=>navigator.serviceWorker.removeEventListener('message', handler)
                })["OfflineBanner.useEffect"];
            }
        }
    }["OfflineBanner.useEffect"], []);
    // Track offline → online transitions (skip initial mount)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfflineBanner.useEffect": ()=>{
            if (!isOnline) {
                wasOfflineRef.current = true;
            } else if (wasOfflineRef.current) {
                // Genuinely transitioned from offline → online
                setJustReconnected(true);
                wasOfflineRef.current = false;
                const timer = setTimeout({
                    "OfflineBanner.useEffect.timer": ()=>setJustReconnected(false)
                }["OfflineBanner.useEffect.timer"], 4000);
                return ({
                    "OfflineBanner.useEffect": ()=>clearTimeout(timer)
                })["OfflineBanner.useEffect"];
            }
        }
    }["OfflineBanner.useEffect"], [
        isOnline
    ]);
    const handleManualSync = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OfflineBanner.useCallback[handleManualSync]": async ()=>{
            try {
                const { processQueue: processQueue_0 } = await __turbopack_context__.A("[project]/src/offline/SyncQueue.ts [app-client] (ecmascript, async loader)");
                const result_0 = await processQueue_0({
                    "OfflineBanner.useCallback[handleManualSync]": async (model_0, operation_0, payload_0)=>{
                        const { generateClient: generateClient_0 } = await __turbopack_context__.A("[project]/node_modules/aws-amplify/dist/esm/api/index.mjs [app-client] (ecmascript, async loader)");
                        const client_0 = generateClient_0();
                        if (operation_0 === 'update') {
                            await client_0.models[model_0].update(payload_0);
                        } else if (operation_0 === 'create') {
                            await client_0.models[model_0].create(payload_0);
                        } else if (operation_0 === 'delete') {
                            await client_0.models[model_0].delete(payload_0);
                        }
                    }
                }["OfflineBanner.useCallback[handleManualSync]"]);
                setPendingCount(result_0.remaining);
            } catch  {
            // Sync failed — will retry
            }
        }
    }["OfflineBanner.useCallback[handleManualSync]"], []);
    // Offline banner
    if (!isOnline) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
            open: true,
            anchorOrigin: {
                vertical: 'top',
                horizontal: 'center'
            },
            TransitionComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slide$2f$Slide$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Slide$3e$__["Slide"],
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                severity: "warning",
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$WifiOff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/OfflineBanner.tsx",
                    lineNumber: 104,
                    columnNumber: 41
                }, this),
                action: pendingCount > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    color: "inherit",
                    size: "small",
                    startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudSync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/OfflineBanner.tsx",
                        lineNumber: 104,
                        columnNumber: 129
                    }, this),
                    children: [
                        pendingCount,
                        " pending"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/OfflineBanner.tsx",
                    lineNumber: 104,
                    columnNumber: 81
                }, this) : undefined,
                sx: {
                    width: '100%'
                },
                children: "You're offline — your work is saved locally"
            }, void 0, false, {
                fileName: "[project]/src/components/OfflineBanner.tsx",
                lineNumber: 104,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/OfflineBanner.tsx",
            lineNumber: 100,
            columnNumber: 12
        }, this);
    }
    // Brief reconnection banner
    if (justReconnected && pendingCount > 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Snackbar$3e$__["Snackbar"], {
            open: true,
            autoHideDuration: 4000,
            onClose: ()=>setJustReconnected(false),
            anchorOrigin: {
                vertical: 'top',
                horizontal: 'center'
            },
            TransitionComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slide$2f$Slide$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Slide$3e$__["Slide"],
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                severity: "success",
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloudSync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/OfflineBanner.tsx",
                    lineNumber: 120,
                    columnNumber: 41
                }, this),
                action: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    color: "inherit",
                    size: "small",
                    onClick: handleManualSync,
                    children: "Sync now"
                }, void 0, false, {
                    fileName: "[project]/src/components/OfflineBanner.tsx",
                    lineNumber: 120,
                    columnNumber: 64
                }, this),
                sx: {
                    width: '100%'
                },
                children: [
                    "Back online — syncing ",
                    pendingCount,
                    " pending changes"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/OfflineBanner.tsx",
                lineNumber: 120,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/OfflineBanner.tsx",
            lineNumber: 116,
            columnNumber: 12
        }, this);
    }
    return null;
}
_s(OfflineBanner, "OdaCW+VtjoKTNRb/xkeoXBRhWbI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useNetworkStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNetworkStatus"]
    ];
});
_c = OfflineBanner;
var _c;
__turbopack_context__.k.register(_c, "OfflineBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/AuthFormSkeleton.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AuthFormSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
function AuthFormSkeleton() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "af9087fbfc1f2d2c9c702b6003d01e22d17368b0080761207a53f168fa167595") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "af9087fbfc1f2d2c9c702b6003d01e22d17368b0080761207a53f168fa167595";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            display: "flex",
            justifyContent: "center",
            pt: 6
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            width: 360,
            borderRadius: 2,
            overflow: "hidden",
            boxShadow: "0 4px 24px rgba(0,0,0,0.1)",
            p: 3,
            backgroundColor: "background.paper"
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                display: "flex",
                gap: 1,
                mb: 3
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "rounded",
                    width: "50%",
                    height: 36
                }, void 0, false, {
                    fileName: "[project]/src/components/AuthFormSkeleton.jsx",
                    lineNumber: 52,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "rounded",
                    width: "50%",
                    height: 36
                }, void 0, false, {
                    fileName: "[project]/src/components/AuthFormSkeleton.jsx",
                    lineNumber: 52,
                    columnNumber: 62
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AuthFormSkeleton.jsx",
            lineNumber: 48,
            columnNumber: 10
        }, this);
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "text",
            width: 80,
            height: 18,
            sx: {
                mb: 0.5
            }
        }, void 0, false, {
            fileName: "[project]/src/components/AuthFormSkeleton.jsx",
            lineNumber: 59,
            columnNumber: 10
        }, this);
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "rounded",
            width: "100%",
            height: 40,
            sx: {
                mb: 2,
                borderRadius: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/AuthFormSkeleton.jsx",
            lineNumber: 68,
            columnNumber: 10
        }, this);
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "text",
            width: 100,
            height: 18,
            sx: {
                mb: 0.5
            }
        }, void 0, false, {
            fileName: "[project]/src/components/AuthFormSkeleton.jsx",
            lineNumber: 78,
            columnNumber: 10
        }, this);
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "rounded",
            width: "100%",
            height: 40,
            sx: {
                mb: 1,
                borderRadius: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/AuthFormSkeleton.jsx",
            lineNumber: 87,
            columnNumber: 10
        }, this);
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                display: "flex",
                justifyContent: "flex-end",
                mb: 3
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "text",
                width: 130,
                height: 18
            }, void 0, false, {
                fileName: "[project]/src/components/AuthFormSkeleton.jsx",
                lineNumber: 101,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AuthFormSkeleton.jsx",
            lineNumber: 97,
            columnNumber: 10
        }, this);
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t0,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t1,
                children: [
                    t2,
                    t3,
                    t4,
                    t5,
                    t6,
                    t7,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "rounded",
                        width: "100%",
                        height: 42,
                        sx: {
                            borderRadius: 1
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/AuthFormSkeleton.jsx",
                        lineNumber: 108,
                        columnNumber: 60
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/AuthFormSkeleton.jsx",
                lineNumber: 108,
                columnNumber: 23
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/AuthFormSkeleton.jsx",
            lineNumber: 108,
            columnNumber: 10
        }, this);
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    return t8;
}
_c = AuthFormSkeleton;
var _c;
__turbopack_context__.k.register(_c, "AuthFormSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/AppSkeleton.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AppSkeleton,
    "hasLikelySession",
    ()=>hasLikelySession
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AuthFormSkeleton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/AuthFormSkeleton.jsx [app-client] (ecmascript)");
;
;
;
;
;
;
const DRAWER_WIDTH = 280;
const APPBAR_HEIGHT = 48;
function hasLikelySession() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    function isLiveJwt(token) {
        if (!token) return false;
        try {
            const parts = token.split(".");
            if (parts.length !== 3) return false;
            const payload = JSON.parse(atob(parts[1].replace(/-/g, "+").replace(/_/g, "/")));
            return payload.exp && payload.exp * 1000 > Date.now();
        } catch  {
            return false;
        }
    }
    try {
        // 1. Check localStorage (Amplify default storage)
        for(let i = 0; i < localStorage.length; i++){
            const key = localStorage.key(i);
            if (key && key.endsWith(".idToken")) {
                if (isLiveJwt(localStorage.getItem(key))) return true;
            }
        }
    } catch  {
    // localStorage may be blocked in some contexts
    }
    try {
        // 2. Check cookies (ChunkedCookieStorage path — ssr:true)
        for (const raw of document.cookie.split(";")){
            const eqIdx = raw.indexOf("=");
            if (eqIdx === -1) continue;
            const name = raw.slice(0, eqIdx).trim();
            if (name.endsWith(".idToken")) {
                const value = decodeURIComponent(raw.slice(eqIdx + 1).trim());
                if (isLiveJwt(value)) return true;
            }
        }
    } catch  {
    // cookies may be blocked
    }
    return false;
}
function AppSkeleton(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(30);
    if ($[0] !== "33a842924cc7248004da234baba1dbedc0a7a671573c1352bf9069b0089b0eb4") {
        for(let $i = 0; $i < 30; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "33a842924cc7248004da234baba1dbedc0a7a671573c1352bf9069b0089b0eb4";
    }
    const { variant: t1 } = t0;
    const variant = t1 === undefined ? "page" : t1;
    const isLikelyLoggedIn = hasLikelySession();
    if (!isLikelyLoggedIn) {
        let t2;
        if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AuthFormSkeleton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 80,
                columnNumber: 12
            }, this);
            $[1] = t2;
        } else {
            t2 = $[1];
        }
        return t2;
    }
    if (variant === "page") {
        return null;
    }
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            xs: 2,
            sm: 3
        };
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const t3 = variant === "detail" ? "none" : "80rem";
    const t4 = variant === "detail" ? 0 : "auto";
    let t5;
    if ($[3] !== t3 || $[4] !== t4) {
        t5 = {
            flexGrow: 1,
            p: t2,
            maxWidth: t3,
            mx: t4,
            width: "100%"
        };
        $[3] = t3;
        $[4] = t4;
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    let t6;
    if ($[6] !== variant) {
        t6 = variant === "cards" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CardsSkeleton, {}, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 119,
            columnNumber: 33
        }, this);
        $[6] = variant;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] !== variant) {
        t7 = variant === "sections" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionsSkeleton, {}, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 127,
            columnNumber: 36
        }, this);
        $[8] = variant;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] !== variant) {
        t8 = variant === "detail" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DetailSkeleton, {}, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 135,
            columnNumber: 34
        }, this);
        $[10] = variant;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== variant) {
        t9 = variant === "page" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PageSkeleton, {}, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 143,
            columnNumber: 32
        }, this);
        $[12] = variant;
        $[13] = t9;
    } else {
        t9 = $[13];
    }
    let t10;
    if ($[14] !== t5 || $[15] !== t6 || $[16] !== t7 || $[17] !== t8 || $[18] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            component: "main",
            sx: t5,
            children: [
                t6,
                t7,
                t8,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 151,
            columnNumber: 11
        }, this);
        $[14] = t5;
        $[15] = t6;
        $[16] = t7;
        $[17] = t8;
        $[18] = t9;
        $[19] = t10;
    } else {
        t10 = $[19];
    }
    const contentSkeleton = t10;
    if (variant !== "page") {
        return contentSkeleton;
    }
    let t11;
    if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            minHeight: "100vh"
        };
        $[20] = t11;
    } else {
        t11 = $[20];
    }
    let t12;
    let t13;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            height: APPBAR_HEIGHT,
            zIndex: 1300,
            backgroundColor: "background.paper",
            borderBottom: "1px solid",
            borderColor: "divider",
            display: "flex",
            alignItems: "center",
            px: 1.5,
            gap: 1
        };
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "circular",
            width: 36,
            height: 36
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 192,
            columnNumber: 11
        }, this);
        $[21] = t12;
        $[22] = t13;
    } else {
        t12 = $[21];
        t13 = $[22];
    }
    let t14;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t12,
            children: [
                t13,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        flexGrow: 1
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 201,
                    columnNumber: 30
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "circular",
                    width: 32,
                    height: 32
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 203,
                    columnNumber: 12
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "circular",
                    width: 32,
                    height: 32
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 203,
                    columnNumber: 66
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "circular",
                    width: 32,
                    height: 32
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 203,
                    columnNumber: 120
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 201,
            columnNumber: 11
        }, this);
        $[23] = t14;
    } else {
        t14 = $[23];
    }
    let t15;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            display: "flex",
            mt: `${APPBAR_HEIGHT}px`
        };
        $[24] = t15;
    } else {
        t15 = $[24];
    }
    let t16;
    let t17;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            width: DRAWER_WIDTH,
            minWidth: DRAWER_WIDTH,
            borderRight: "1px solid",
            borderColor: "divider",
            height: `calc(100vh - ${APPBAR_HEIGHT}px)`,
            p: 2,
            display: {
                xs: "none",
                md: "block"
            }
        };
        t17 = [
            0,
            1,
            2,
            3,
            4
        ].map(_AppSkeletonAnonymous);
        $[25] = t16;
        $[26] = t17;
    } else {
        t16 = $[25];
        t17 = $[26];
    }
    let t18;
    if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t16,
            children: [
                t17,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "rectangular",
                    height: 1,
                    sx: {
                        my: 2,
                        opacity: 0.3
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 242,
                    columnNumber: 30
                }, this),
                [
                    0,
                    1
                ].map(_AppSkeletonAnonymous2)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 242,
            columnNumber: 11
        }, this);
        $[27] = t18;
    } else {
        t18 = $[27];
    }
    let t19;
    if ($[28] !== contentSkeleton) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t11,
            children: [
                t14,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: t15,
                    children: [
                        t18,
                        contentSkeleton
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 252,
                    columnNumber: 30
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 252,
            columnNumber: 11
        }, this);
        $[28] = contentSkeleton;
        $[29] = t19;
    } else {
        t19 = $[29];
    }
    return t19;
}
_c = AppSkeleton;
/** Default page skeleton: streak row + progress rings + divider + assignment cards (home page) */ function _AppSkeletonAnonymous2(i_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            display: "flex",
            alignItems: "center",
            gap: 1.5,
            mb: 1.5
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "circular",
                width: 24,
                height: 24
            }, void 0, false, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 268,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "text",
                width: `${50 + i_0 * 15}%`,
                height: 24
            }, void 0, false, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 268,
                columnNumber: 60
            }, this)
        ]
    }, `s${i_0}`, true, {
        fileName: "[project]/src/components/AppSkeleton.jsx",
        lineNumber: 263,
        columnNumber: 10
    }, this);
}
function _AppSkeletonAnonymous(i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            display: "flex",
            alignItems: "center",
            gap: 1.5,
            mb: 1.5
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "circular",
                width: 24,
                height: 24
            }, void 0, false, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 276,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "text",
                width: `${40 + i * 10}%`,
                height: 24
            }, void 0, false, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 276,
                columnNumber: 60
            }, this)
        ]
    }, i, true, {
        fileName: "[project]/src/components/AppSkeleton.jsx",
        lineNumber: 271,
        columnNumber: 10
    }, this);
}
function PageSkeleton() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "33a842924cc7248004da234baba1dbedc0a7a671573c1352bf9069b0089b0eb4") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "33a842924cc7248004da234baba1dbedc0a7a671573c1352bf9069b0089b0eb4";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                display: "flex",
                alignItems: "center",
                gap: 2,
                mb: 2
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "circular",
                    width: 40,
                    height: 40
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 293,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "text",
                    width: 120,
                    height: 28
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 293,
                    columnNumber: 62
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 288,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                display: "flex",
                gap: 3,
                mb: 3,
                flexWrap: "wrap"
            },
            children: [
                0,
                1,
                2
            ].map(_PageSkeletonAnonymous)
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 300,
            columnNumber: 10
        }, this);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t0,
                t1,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "rectangular",
                    height: 1,
                    sx: {
                        mb: 3,
                        opacity: 0.3
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 312,
                    columnNumber: 20
                }, this),
                [
                    0,
                    1,
                    2
                ].map(_PageSkeletonAnonymous2)
            ]
        }, void 0, true);
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_c1 = PageSkeleton;
/** Sections skeleton: title + bordered cards with left accent matching sections page */ function _PageSkeletonAnonymous2(i_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            display: "flex",
            alignItems: "center",
            gap: 2,
            mb: 1.5,
            p: 2,
            border: 1,
            borderColor: "divider",
            borderRadius: 1
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                width: 80,
                height: 60,
                sx: {
                    borderRadius: 1
                }
            }, void 0, false, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 334,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    flexGrow: 1
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "text",
                        width: "60%",
                        height: 24
                    }, void 0, false, {
                        fileName: "[project]/src/components/AppSkeleton.jsx",
                        lineNumber: 338,
                        columnNumber: 8
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "text",
                        width: "35%",
                        height: 18
                    }, void 0, false, {
                        fileName: "[project]/src/components/AppSkeleton.jsx",
                        lineNumber: 338,
                        columnNumber: 59
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 336,
                columnNumber: 10
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                width: 60,
                height: 24,
                sx: {
                    borderRadius: 0.5
                }
            }, void 0, false, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 338,
                columnNumber: 116
            }, this)
        ]
    }, i_0, true, {
        fileName: "[project]/src/components/AppSkeleton.jsx",
        lineNumber: 325,
        columnNumber: 10
    }, this);
}
function _PageSkeletonAnonymous(i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        variant: "circular",
        width: 80,
        height: 80
    }, i, false, {
        fileName: "[project]/src/components/AppSkeleton.jsx",
        lineNumber: 343,
        columnNumber: 10
    }, this);
}
function SectionsSkeleton() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "33a842924cc7248004da234baba1dbedc0a7a671573c1352bf9069b0089b0eb4") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "33a842924cc7248004da234baba1dbedc0a7a671573c1352bf9069b0089b0eb4";
    }
    let t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 3
        };
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "text",
            width: "30%",
            height: 48
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 362,
            columnNumber: 10
        }, this);
        $[1] = t0;
        $[2] = t1;
    } else {
        t0 = $[1];
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: t0,
                    children: [
                        t1,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "rectangular",
                            width: 140,
                            height: 36,
                            sx: {
                                borderRadius: 1
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/AppSkeleton.jsx",
                            lineNumber: 371,
                            columnNumber: 29
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 371,
                    columnNumber: 12
                }, this),
                [
                    0,
                    1,
                    2,
                    3
                ].map(_SectionsSkeletonAnonymous)
            ]
        }, void 0, true);
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_c2 = SectionsSkeleton;
/** Card list skeleton: grid of card placeholders (for units page) */ function _SectionsSkeletonAnonymous(i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            border: 1,
            borderColor: "divider",
            borderRadius: 2,
            p: 2.5,
            mb: 2,
            borderLeft: 4
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "text",
                width: "50%",
                height: 28,
                sx: {
                    mb: 0.5
                }
            }, void 0, false, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 390,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "text",
                width: "35%",
                height: 20,
                sx: {
                    mb: 1
                }
            }, void 0, false, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 392,
                columnNumber: 10
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    display: "flex",
                    gap: 1,
                    alignItems: "center"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "text",
                        width: 80,
                        height: 20
                    }, void 0, false, {
                        fileName: "[project]/src/components/AppSkeleton.jsx",
                        lineNumber: 398,
                        columnNumber: 8
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "rectangular",
                        width: 80,
                        height: 24,
                        sx: {
                            borderRadius: 0.5
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/AppSkeleton.jsx",
                        lineNumber: 398,
                        columnNumber: 58
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 394,
                columnNumber: 10
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                width: 120,
                height: 32,
                sx: {
                    borderRadius: 1,
                    mt: 1.5
                }
            }, void 0, false, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 400,
                columnNumber: 18
            }, this)
        ]
    }, i, true, {
        fileName: "[project]/src/components/AppSkeleton.jsx",
        lineNumber: 383,
        columnNumber: 10
    }, this);
}
function CardsSkeleton() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3);
    if ($[0] !== "33a842924cc7248004da234baba1dbedc0a7a671573c1352bf9069b0089b0eb4") {
        for(let $i = 0; $i < 3; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "33a842924cc7248004da234baba1dbedc0a7a671573c1352bf9069b0089b0eb4";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "text",
            width: "30%",
            height: 40,
            sx: {
                mb: 3
            }
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 415,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t0,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        display: "grid",
                        gridTemplateColumns: {
                            xs: "1fr",
                            sm: "1fr 1fr",
                            md: "1fr 1fr 1fr"
                        },
                        gap: 2
                    },
                    children: [
                        0,
                        1,
                        2,
                        3,
                        4,
                        5
                    ].map(_CardsSkeletonAnonymous)
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 424,
                    columnNumber: 16
                }, this)
            ]
        }, void 0, true);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    return t1;
}
_c3 = CardsSkeleton;
/** Detail/editor skeleton: title + description, toolbar, side tabs + canvas */ function _CardsSkeletonAnonymous(i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            border: 1,
            borderColor: "divider",
            borderRadius: 1,
            overflow: "hidden"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "rectangular",
                height: 140
            }, void 0, false, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 447,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    p: 2
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "text",
                        width: "80%",
                        height: 24,
                        sx: {
                            mb: 1
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/AppSkeleton.jsx",
                        lineNumber: 449,
                        columnNumber: 8
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "text",
                        width: "50%",
                        height: 20
                    }, void 0, false, {
                        fileName: "[project]/src/components/AppSkeleton.jsx",
                        lineNumber: 451,
                        columnNumber: 12
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/AppSkeleton.jsx",
                lineNumber: 447,
                columnNumber: 53
            }, this)
        ]
    }, i, true, {
        fileName: "[project]/src/components/AppSkeleton.jsx",
        lineNumber: 442,
        columnNumber: 10
    }, this);
}
function DetailSkeleton() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "33a842924cc7248004da234baba1dbedc0a7a671573c1352bf9069b0089b0eb4") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "33a842924cc7248004da234baba1dbedc0a7a671573c1352bf9069b0089b0eb4";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            mx: -2
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            px: 2,
            pt: 1,
            mb: 1
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t1,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "text",
                    width: "45%",
                    height: 36,
                    sx: {
                        mb: 0.5
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 483,
                    columnNumber: 23
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "text",
                    width: "65%",
                    height: 22
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 485,
                    columnNumber: 12
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 483,
            columnNumber: 10
        }, this);
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            display: "flex",
            alignItems: "center",
            gap: 1,
            px: 2,
            py: 1,
            borderBottom: 1,
            borderColor: "divider"
        };
        t4 = [
            0,
            1
        ].map(_DetailSkeletonAnonymous);
        $[4] = t3;
        $[5] = t4;
    } else {
        t3 = $[4];
        t4 = $[5];
    }
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "rounded",
            width: 60,
            height: 28,
            sx: {
                borderRadius: 0.5
            }
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 511,
            columnNumber: 10
        }, this);
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    let t7;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "rounded",
            width: 24,
            height: 28,
            sx: {
                borderRadius: 0.5
            }
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 521,
            columnNumber: 10
        }, this);
        t7 = [
            0,
            1,
            2
        ].map(_DetailSkeletonAnonymous2);
        $[7] = t6;
        $[8] = t7;
    } else {
        t6 = $[7];
        t7 = $[8];
    }
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                flexGrow: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 533,
            columnNumber: 10
        }, this);
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    let t9;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "rounded",
            width: 100,
            height: 32,
            sx: {
                borderRadius: 1
            }
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 542,
            columnNumber: 10
        }, this);
        $[10] = t9;
    } else {
        t9 = $[10];
    }
    let t10;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t4,
                t5,
                t6,
                t7,
                t8,
                t9,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "rounded",
                    width: 28,
                    height: 28,
                    sx: {
                        borderRadius: 0.5
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 551,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 551,
            columnNumber: 11
        }, this);
        $[11] = t10;
    } else {
        t10 = $[11];
    }
    let t11;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            display: "flex",
            height: "calc(100vh - 200px)"
        };
        $[12] = t11;
    } else {
        t11 = $[12];
    }
    let t12;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                width: 40,
                borderRight: 1,
                borderColor: "divider",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 1.5,
                pt: 2
            },
            children: [
                0,
                1,
                2,
                3,
                4
            ].map(_DetailSkeletonAnonymous3)
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 570,
            columnNumber: 11
        }, this);
        $[13] = t12;
    } else {
        t12 = $[13];
    }
    let t13;
    let t14;
    let t15;
    let t16;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            flexGrow: 1,
            p: 3,
            display: "flex",
            flexDirection: "column",
            gap: 2
        };
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "text",
            width: "70%",
            height: 28
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 596,
            columnNumber: 11
        }, this);
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "text",
            width: "90%",
            height: 20
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 597,
            columnNumber: 11
        }, this);
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "text",
            width: "80%",
            height: 20
        }, void 0, false, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 598,
            columnNumber: 11
        }, this);
        $[14] = t13;
        $[15] = t14;
        $[16] = t15;
        $[17] = t16;
    } else {
        t13 = $[14];
        t14 = $[15];
        t15 = $[16];
        t16 = $[17];
    }
    let t17;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t13,
            children: [
                t14,
                t15,
                t16,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "rectangular",
                    height: 100,
                    sx: {
                        borderRadius: 1,
                        mt: 1
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 611,
                    columnNumber: 40
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "text",
                    width: "60%",
                    height: 20
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 614,
                    columnNumber: 12
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "text",
                    width: "85%",
                    height: 20
                }, void 0, false, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 614,
                    columnNumber: 63
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 611,
            columnNumber: 11
        }, this);
        $[18] = t17;
    } else {
        t17 = $[18];
    }
    let t18;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t0,
            children: [
                t2,
                t10,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: t11,
                    children: [
                        t12,
                        t17,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                width: 40,
                                borderLeft: 1,
                                borderColor: "divider",
                                display: "flex",
                                flexDirection: "column",
                                alignItems: "center",
                                gap: 1.5,
                                pt: 2
                            },
                            children: [
                                0,
                                1,
                                2,
                                3,
                                4,
                                5
                            ].map(_DetailSkeletonAnonymous4)
                        }, void 0, false, {
                            fileName: "[project]/src/components/AppSkeleton.jsx",
                            lineNumber: 621,
                            columnNumber: 57
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/AppSkeleton.jsx",
                    lineNumber: 621,
                    columnNumber: 33
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/AppSkeleton.jsx",
            lineNumber: 621,
            columnNumber: 11
        }, this);
        $[19] = t18;
    } else {
        t18 = $[19];
    }
    return t18;
}
_c4 = DetailSkeleton;
function _DetailSkeletonAnonymous4(i_2) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        variant: "rounded",
        width: 24,
        height: 24,
        sx: {
            borderRadius: 0.5
        }
    }, i_2, false, {
        fileName: "[project]/src/components/AppSkeleton.jsx",
        lineNumber: 638,
        columnNumber: 10
    }, this);
}
function _DetailSkeletonAnonymous3(i_1) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        variant: "rounded",
        width: 24,
        height: 24,
        sx: {
            borderRadius: 0.5
        }
    }, i_1, false, {
        fileName: "[project]/src/components/AppSkeleton.jsx",
        lineNumber: 643,
        columnNumber: 10
    }, this);
}
function _DetailSkeletonAnonymous2(i_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        variant: "rounded",
        width: 28,
        height: 28,
        sx: {
            borderRadius: 0.5
        }
    }, `f${i_0}`, false, {
        fileName: "[project]/src/components/AppSkeleton.jsx",
        lineNumber: 648,
        columnNumber: 10
    }, this);
}
function _DetailSkeletonAnonymous(i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        variant: "rounded",
        width: 28,
        height: 28,
        sx: {
            borderRadius: 0.5
        }
    }, `g${i}`, false, {
        fileName: "[project]/src/components/AppSkeleton.jsx",
        lineNumber: 653,
        columnNumber: 10
    }, this);
}
var _c, _c1, _c2, _c3, _c4;
__turbopack_context__.k.register(_c, "AppSkeleton");
__turbopack_context__.k.register(_c1, "PageSkeleton");
__turbopack_context__.k.register(_c2, "SectionsSkeleton");
__turbopack_context__.k.register(_c3, "CardsSkeleton");
__turbopack_context__.k.register(_c4, "DetailSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/AmplifyAuthenticator.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MyAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * @fileoverview Authenticator - AWS Amplify authentication component wrapper
 *
 * Provides sign in, sign up, and password reset flows using AWS Cognito.
 * Displays email/password form with custom field configuration. Used throughout
 * the app to gate access to authenticated content.
 *
 * Handles return URL redirection: when a user is logged out and tries to access
 * a protected URL, the URL is stored and the user is redirected back after login.
 *
 * @module Authenticator
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$ui$2d$react$2f$dist$2f$esm$2f$components$2f$Authenticator$2f$Authenticator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/ui-react/dist/esm/components/Authenticator/Authenticator.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$ui$2d$react$2f$dist$2f$esm$2f$components$2f$ThemeProvider$2f$ThemeProvider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/ui-react/dist/esm/components/ThemeProvider/ThemeProvider.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/ThemeProviderWithVars.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Hub$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Hub/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/authContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
const amplifyAuthTheme = {
    name: "homework-supply-auth",
    tokens: {
        colors: {
            brand: {
                primary: {
                    10: {
                        value: "#eef0fa"
                    },
                    20: {
                        value: "#d5d9f0"
                    },
                    40: {
                        value: "#9aa3e0"
                    },
                    60: {
                        value: "#6f7bd6"
                    },
                    80: {
                        value: "#556cd6"
                    },
                    90: {
                        value: "#4458b8"
                    },
                    100: {
                        value: "#344499"
                    }
                }
            },
            background: {
                primary: {
                    value: "#fafafa"
                },
                secondary: {
                    value: "#ffffff"
                }
            },
            font: {
                primary: {
                    value: "#1a1a1a"
                },
                secondary: {
                    value: "#666666"
                }
            },
            border: {
                primary: {
                    value: "#e0e0e0"
                }
            }
        },
        components: {
            authenticator: {
                router: {
                    borderWidth: {
                        value: "0"
                    },
                    boxShadow: {
                        value: "0 4px 24px rgba(0, 0, 0, 0.1)"
                    }
                }
            }
        }
    },
    overrides: [
        {
            colorMode: "dark",
            tokens: {
                colors: {
                    brand: {
                        primary: {
                            10: {
                                value: "#1a1e3a"
                            },
                            20: {
                                value: "#2a3060"
                            },
                            40: {
                                value: "#4a5690"
                            },
                            60: {
                                value: "#5560a0"
                            },
                            80: {
                                value: "#4a5690"
                            },
                            90: {
                                value: "#3f4a80"
                            },
                            100: {
                                value: "#354070"
                            }
                        }
                    },
                    background: {
                        primary: {
                            value: "#121212"
                        },
                        secondary: {
                            value: "#1e1e1e"
                        }
                    },
                    font: {
                        primary: {
                            value: "#e0e0e0"
                        },
                        secondary: {
                            value: "#a0a0a0"
                        }
                    },
                    border: {
                        primary: {
                            value: "#333333"
                        }
                    }
                },
                components: {
                    authenticator: {
                        router: {
                            boxShadow: {
                                value: "0 4px 24px rgba(0, 0, 0, 0.4)"
                            }
                        }
                    }
                }
            }
        }
    ]
};
function getFormFields(t) {
    return {
        signUp: {
            given_name: {
                label: t("authenticator.firstNameLabel"),
                placeholder: t("authenticator.firstNamePlaceholder"),
                isRequired: true,
                order: 1
            },
            family_name: {
                label: t("authenticator.lastNameLabel"),
                placeholder: t("authenticator.lastNamePlaceholder"),
                isRequired: true,
                order: 2
            },
            email: {
                label: t("authenticator.emailLabel"),
                placeholder: t("authenticator.emailPlaceholder"),
                isRequired: true,
                order: 3
            },
            phone_number: {
                label: t("authenticator.phoneLabel"),
                placeholder: t("authenticator.phonePlaceholder"),
                isRequired: false,
                order: 4
            },
            preferred_username: {
                label: t("authenticator.preferredNameLabel"),
                placeholder: t("authenticator.preferredNamePlaceholder"),
                isRequired: false,
                order: 5
            },
            password: {
                label: t("authenticator.passwordLabel"),
                placeholder: t("authenticator.passwordPlaceholder"),
                isRequired: false,
                order: 6
            },
            confirm_password: {
                label: t("authenticator.confirmPasswordLabel"),
                placeholder: t("authenticator.confirmPasswordPlaceholder"),
                order: 7
            }
        }
    };
}
function MyAuth(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "09a787206fd30f4152677ae90b70b21342f6058573981bf2d551c8b4a6d00995") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "09a787206fd30f4152677ae90b70b21342f6058573981bf2d551c8b4a6d00995";
    }
    const { children } = t0;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("components");
    let t1;
    if ($[1] !== t) {
        t1 = getFormFields(t);
        $[1] = t;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const formFields = t1;
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { mode } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"])();
    const { user: authUser } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$authContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const colorMode = mode || "system";
    let t2;
    let t3;
    if ($[3] !== router) {
        t2 = ({
            "MyAuth[useEffect()]": ()=>{
                const hubListener = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Hub$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hub"].listen("auth", {
                    "MyAuth[useEffect() > Hub.listen()]": (t4)=>{
                        const { payload } = t4;
                        if (payload.event === "signedIn") {
                            console.log("[MyAuth] User signed in, checking for return URL");
                            const returnUrl = sessionStorage.getItem("returnUrl");
                            if (returnUrl) {
                                console.log("[MyAuth] Redirecting to return URL:", returnUrl);
                                sessionStorage.removeItem("returnUrl");
                                router.replace(returnUrl);
                            }
                        }
                    }
                }["MyAuth[useEffect() > Hub.listen()]"]);
                return ()=>hubListener();
            }
        })["MyAuth[useEffect()]"];
        t3 = [
            router
        ];
        $[3] = router;
        $[4] = t2;
        $[5] = t3;
    } else {
        t2 = $[4];
        t3 = $[5];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(t2, t3);
    if (authUser) {
        let t4;
        if ($[6] !== children) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: children
            }, void 0, false);
            $[6] = children;
            $[7] = t4;
        } else {
            t4 = $[7];
        }
        return t4;
    }
    let t4;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = [
            "email",
            "phone_number"
        ];
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    if ($[9] !== children) {
        t5 = (t6)=>{
            const { signOut, user } = t6;
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Children.map(children, {
                "MyAuth[<anonymous> > React.Children.map()]": (child)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isValidElement(child) && typeof child.type === "function" ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].cloneElement(child, {
                        signOut,
                        user
                    }) : child
            }["MyAuth[<anonymous> > React.Children.map()]"]);
        };
        $[9] = children;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    let t6;
    if ($[11] !== formFields || $[12] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$ui$2d$react$2f$dist$2f$esm$2f$components$2f$Authenticator$2f$Authenticator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Authenticator"], {
            variant: "modal",
            formFields: formFields,
            loginMechanisms: t4,
            children: t5
        }, void 0, false, {
            fileName: "[project]/src/components/AmplifyAuthenticator.jsx",
            lineNumber: 299,
            columnNumber: 10
        }, this);
        $[11] = formFields;
        $[12] = t5;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    let t7;
    if ($[14] !== colorMode || $[15] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$ui$2d$react$2f$dist$2f$esm$2f$components$2f$ThemeProvider$2f$ThemeProvider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeProvider"], {
            theme: amplifyAuthTheme,
            colorMode: colorMode,
            children: t6
        }, void 0, false, {
            fileName: "[project]/src/components/AmplifyAuthenticator.jsx",
            lineNumber: 308,
            columnNumber: 10
        }, this);
        $[14] = colorMode;
        $[15] = t6;
        $[16] = t7;
    } else {
        t7 = $[16];
    }
    return t7;
}
_s(MyAuth, "UDFNpiU4YZz/A7gwFd1ErufuNjM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"]
    ];
});
_c = MyAuth;
var _c;
__turbopack_context__.k.register(_c, "MyAuth");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_0x9qp2x._.js.map