(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0rx4rba._.js","static/chunks/node_modules_next_dist_compiled_next-devtools_index_0553esy.js","static/chunks/node_modules_next_dist_compiled_react-dom_058-ah~._.js","static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_0p3wegg._.js","static/chunks/node_modules_next_dist_compiled_0.4_mz-._.js","static/chunks/node_modules_next_dist_client_0fhqo1d._.js","static/chunks/node_modules_next_dist_server_0bxku-~._.js","static/chunks/node_modules_next_dist_0ifwd0~._.js","static/chunks/node_modules_04ue1eq._.js","static/chunks/instrumentation-client_ts_03sw2li._.js"],
    source: "entry"
});
