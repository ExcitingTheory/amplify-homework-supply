(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Editor3/context/AudioPlayerContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AudioPlayerProvider",
    ()=>AudioPlayerProvider,
    "useAudioPlayer",
    ()=>useAudioPlayer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
/**
 * Shared audio player context
 * Provides a single audio element that all AudioWaveformPlayers can use
 * Only one audio can play at a time
 * 
 * DO NOT MODIFY the duration normalization or event listener structure without
 * testing both URL-based playback and recorded blob playback. Key invariants:
 * 
 * 1. SINGLE AUDIO ELEMENT: One Audio() instance shared across all players.
 *    The active source is tracked via `currentSource` state.
 * 
 * 2. DURATION HANDLING: The `loadedmetadata` handler normalizes Infinity/NaN
 *    durations to 0. For WebM recorded blobs, the real duration comes from
 *    `decodeAudioData()` in AudioWaveformPlayer — not from this context.
 * 
 * 3. SUBSCRIBER PATTERN: Players subscribe via `audioPlayer.subscribe(listener)`
 *    and receive onTimeUpdate, onDurationChange, onEnded, onCanPlay, onError
 *    callbacks. Always unsubscribe in cleanup.
 */ const AudioPlayerContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function AudioPlayerProvider({ children }) {
    _s();
    const audioRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [currentSource, setCurrentSource] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isPlaying, setIsPlaying] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentTime, setCurrentTime] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [duration, setDuration] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const listenersRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Set());
    // Initialize audio element if it doesn't exist
    if (!audioRef.current && ("TURBOPACK compile-time value", "object") !== 'undefined') {
        audioRef.current = new Audio();
        audioRef.current.preload = 'metadata';
        // Set up event listeners
        audioRef.current.addEventListener('timeupdate', ()=>{
            const time = audioRef.current.currentTime;
            setCurrentTime(time);
            // Notify all listeners
            listenersRef.current.forEach((listener)=>{
                if (listener.onTimeUpdate) {
                    listener.onTimeUpdate(time);
                }
            });
        });
        audioRef.current.addEventListener('loadedmetadata', ()=>{
            const dur = audioRef.current.duration;
            const validDuration = isNaN(dur) || !isFinite(dur) ? 0 : dur;
            setDuration(validDuration);
            listenersRef.current.forEach((listener_0)=>{
                if (listener_0.onDurationChange) {
                    listener_0.onDurationChange(validDuration);
                }
            });
        });
        audioRef.current.addEventListener('ended', ()=>{
            setIsPlaying(false);
            setCurrentTime(0);
            listenersRef.current.forEach((listener_1)=>{
                if (listener_1.onEnded) {
                    listener_1.onEnded();
                }
            });
        });
        audioRef.current.addEventListener('canplay', ()=>{
            listenersRef.current.forEach((listener_2)=>{
                if (listener_2.onCanPlay) {
                    listener_2.onCanPlay();
                }
            });
        });
        audioRef.current.addEventListener('error', (e)=>{
            console.error('Shared audio error:', e, audioRef.current.error);
            setIsPlaying(false);
            listenersRef.current.forEach((listener_3)=>{
                if (listener_3.onError) {
                    listener_3.onError(e);
                }
            });
        });
        audioRef.current.addEventListener('play', ()=>{
            setIsPlaying(true);
        });
        audioRef.current.addEventListener('pause', ()=>{
            setIsPlaying(false);
        });
    }
    const loadSource = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioPlayerProvider.useCallback[loadSource]": (sourceUrl)=>{
            if (!audioRef.current || !sourceUrl) {
                console.warn('[AudioPlayerContext] Cannot load source - missing audio element or source URL');
                return false;
            }
            // If already loaded with same source, just notify it's ready
            if (currentSource === sourceUrl && audioRef.current.src === sourceUrl) {
                console.log('[AudioPlayerContext] Source already loaded:', sourceUrl.substring(0, 50) + '...');
                // Trigger canplay event for already-loaded source
                listenersRef.current.forEach({
                    "AudioPlayerProvider.useCallback[loadSource]": (listener_4)=>{
                        if (listener_4.onCanPlay) {
                            listener_4.onCanPlay();
                        }
                    }
                }["AudioPlayerProvider.useCallback[loadSource]"]);
                return true;
            }
            try {
                console.log('[AudioPlayerContext] Loading new source:', sourceUrl.substring(0, 50) + '...');
                audioRef.current.src = sourceUrl;
                audioRef.current.load();
                setCurrentSource(sourceUrl);
                setCurrentTime(0);
                return true;
            } catch (error) {
                console.error('[AudioPlayerContext] Error loading audio source:', error);
                return false;
            }
        }
    }["AudioPlayerProvider.useCallback[loadSource]"], [
        currentSource
    ]);
    const play = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioPlayerProvider.useCallback[play]": async (sourceUrl_0)=>{
            if (!audioRef.current) return false;
            // Load source if different
            if (sourceUrl_0 && sourceUrl_0 !== currentSource) {
                const loaded = loadSource(sourceUrl_0);
                if (!loaded) return false;
            }
            try {
                await audioRef.current.play();
                return true;
            } catch (error_0) {
                console.error('Error playing audio:', error_0);
                setIsPlaying(false);
                return false;
            }
        }
    }["AudioPlayerProvider.useCallback[play]"], [
        currentSource,
        loadSource
    ]);
    const pause = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioPlayerProvider.useCallback[pause]": ()=>{
            if (!audioRef.current) return;
            audioRef.current.pause();
        }
    }["AudioPlayerProvider.useCallback[pause]"], []);
    const seek = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioPlayerProvider.useCallback[seek]": (time_0)=>{
            if (!audioRef.current) return;
            audioRef.current.currentTime = time_0;
        }
    }["AudioPlayerProvider.useCallback[seek]"], []);
    const subscribe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AudioPlayerProvider.useCallback[subscribe]": (listener_5)=>{
            listenersRef.current.add(listener_5);
            return ({
                "AudioPlayerProvider.useCallback[subscribe]": ()=>{
                    listenersRef.current.delete(listener_5);
                }
            })["AudioPlayerProvider.useCallback[subscribe]"];
        }
    }["AudioPlayerProvider.useCallback[subscribe]"], []);
    const value = {
        audioElement: audioRef.current,
        currentSource,
        isPlaying,
        currentTime,
        duration,
        loadSource,
        play,
        pause,
        seek,
        subscribe
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AudioPlayerContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/Editor3/context/AudioPlayerContext.jsx",
        lineNumber: 165,
        columnNumber: 10
    }, this);
}
_s(AudioPlayerProvider, "qJnl/TXhNxUVtS2VJ9eUkLa4w54=");
_c = AudioPlayerProvider;
function useAudioPlayer() {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "225caa179daf7846aaffd4126f356834110ff1ad416ff58a3411168f9651c3d4") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "225caa179daf7846aaffd4126f356834110ff1ad416ff58a3411168f9651c3d4";
    }
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AudioPlayerContext);
    if (!context) {
        throw new Error("useAudioPlayer must be used within AudioPlayerProvider");
    }
    return context;
}
_s1(useAudioPlayer, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "AudioPlayerProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/context/SharedAutocompleteContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AutocompleteProvider",
    ()=>AutocompleteProvider,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
const AutocompleteContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])();
const AutocompleteProvider = (t0)=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "db769622b80f2e53d30fe5a269ac0397a25401e7f5e8db3ae383c8a62c0ce01a") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "db769622b80f2e53d30fe5a269ac0397a25401e7f5e8db3ae383c8a62c0ce01a";
    }
    const { children } = t0;
    const [suggestion, setSuggestion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let t1;
    if ($[1] !== suggestion) {
        t1 = {
            suggestion,
            setSuggestion
        };
        $[1] = suggestion;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== children || $[4] !== t1) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AutocompleteContext.Provider, {
            value: t1,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/context/SharedAutocompleteContext.jsx",
            lineNumber: 30,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[3] = children;
        $[4] = t1;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    return t2;
};
_s(AutocompleteProvider, "Aljejhhzkh3roPMXQ4HEJ8cwLK0=");
_c = AutocompleteProvider;
;
const __TURBOPACK__default__export__ = AutocompleteContext;
var _c;
__turbopack_context__.k.register(_c, "AutocompleteProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/config/LanguageEditorTheme.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const theme = {
    blockCursor: 'LanguageEditorTheme__blockCursor',
    characterLimit: 'LanguageEditorTheme__characterLimit',
    code: 'LanguageEditorTheme__code',
    codeHighlight: {
        atrule: 'LanguageEditorTheme__tokenAttr',
        attr: 'LanguageEditorTheme__tokenAttr',
        boolean: 'LanguageEditorTheme__tokenProperty',
        builtin: 'LanguageEditorTheme__tokenSelector',
        cdata: 'LanguageEditorTheme__tokenComment',
        char: 'LanguageEditorTheme__tokenSelector',
        class: 'LanguageEditorTheme__tokenFunction',
        'class-name': 'LanguageEditorTheme__tokenFunction',
        comment: 'LanguageEditorTheme__tokenComment',
        constant: 'LanguageEditorTheme__tokenProperty',
        deleted: 'LanguageEditorTheme__tokenProperty',
        doctype: 'LanguageEditorTheme__tokenComment',
        entity: 'LanguageEditorTheme__tokenOperator',
        function: 'LanguageEditorTheme__tokenFunction',
        important: 'LanguageEditorTheme__tokenVariable',
        inserted: 'LanguageEditorTheme__tokenSelector',
        keyword: 'LanguageEditorTheme__tokenAttr',
        namespace: 'LanguageEditorTheme__tokenVariable',
        number: 'LanguageEditorTheme__tokenProperty',
        operator: 'LanguageEditorTheme__tokenOperator',
        prolog: 'LanguageEditorTheme__tokenComment',
        property: 'LanguageEditorTheme__tokenProperty',
        punctuation: 'LanguageEditorTheme__tokenPunctuation',
        regex: 'LanguageEditorTheme__tokenVariable',
        selector: 'LanguageEditorTheme__tokenSelector',
        string: 'LanguageEditorTheme__tokenSelector',
        symbol: 'LanguageEditorTheme__tokenProperty',
        tag: 'LanguageEditorTheme__tokenProperty',
        url: 'LanguageEditorTheme__tokenOperator',
        variable: 'LanguageEditorTheme__tokenVariable'
    },
    embedBlock: {
        base: 'LanguageEditorTheme__embedBlock',
        focus: 'LanguageEditorTheme__embedBlockFocus'
    },
    hashtag: 'LanguageEditorTheme__hashtag',
    heading: {
        h1: 'LanguageEditorTheme__h1',
        h2: 'LanguageEditorTheme__h2',
        h3: 'LanguageEditorTheme__h3',
        h4: 'LanguageEditorTheme__h4',
        h5: 'LanguageEditorTheme__h5',
        h6: 'LanguageEditorTheme__h6'
    },
    image: 'editor-image',
    indent: 'LanguageEditorTheme__indent',
    inlineImage: 'inline-editor-image',
    layoutContainer: 'LanguageEditorTheme__layoutContaner',
    layoutItem: 'LanguageEditorTheme__layoutItem',
    link: 'LanguageEditorTheme__link',
    list: {
        listitem: 'LanguageEditorTheme__listItem',
        listitemChecked: 'LanguageEditorTheme__listItemChecked',
        listitemUnchecked: 'LanguageEditorTheme__listItemUnchecked',
        nested: {
            listitem: 'LanguageEditorTheme__nestedListItem'
        },
        olDepth: [
            'LanguageEditorTheme__ol1',
            'LanguageEditorTheme__ol2',
            'LanguageEditorTheme__ol3',
            'LanguageEditorTheme__ol4',
            'LanguageEditorTheme__ol5'
        ],
        ul: 'LanguageEditorTheme__ul'
    },
    ltr: 'LanguageEditorTheme__ltr',
    mark: 'LanguageEditorTheme__mark',
    markOverlap: 'LanguageEditorTheme__markOverlap',
    paragraph: 'LanguageEditorTheme__paragraph',
    quote: 'LanguageEditorTheme__quote',
    rtl: 'LanguageEditorTheme__rtl',
    table: 'LanguageEditorTheme__table',
    tableAddColumns: 'LanguageEditorTheme__tableAddColumns',
    tableAddColumnsVisible: 'LanguageEditorTheme__tableAddColumnsVisible',
    tableAddRows: 'LanguageEditorTheme__tableAddRows',
    tableAddRowsVisible: 'LanguageEditorTheme__tableAddRowsVisible',
    tableWrapper: 'LanguageEditorTheme__tableWrapper',
    tableCell: 'LanguageEditorTheme__tableCell',
    tableCellActionButton: 'LanguageEditorTheme__tableCellActionButton',
    tableCellActionButtonContainer: 'LanguageEditorTheme__tableCellActionButtonContainer',
    tableCellEditing: 'LanguageEditorTheme__tableCellEditing',
    tableCellHeader: 'LanguageEditorTheme__tableCellHeader',
    tableCellPrimarySelected: 'LanguageEditorTheme__tableCellPrimarySelected',
    tableCellResizer: 'LanguageEditorTheme__tableCellResizer',
    tableCellSelected: 'LanguageEditorTheme__tableCellSelected',
    tableCellSortedIndicator: 'LanguageEditorTheme__tableCellSortedIndicator',
    tableResizeRuler: 'LanguageEditorTheme__tableCellResizeRuler',
    tableSelected: 'LanguageEditorTheme__tableSelected',
    tableSelection: 'LanguageEditorTheme__tableSelection',
    text: {
        bold: 'LanguageEditorTheme__textBold',
        code: 'LanguageEditorTheme__textCode',
        italic: 'LanguageEditorTheme__textItalic',
        strikethrough: 'LanguageEditorTheme__textStrikethrough',
        subscript: 'LanguageEditorTheme__textSubscript',
        superscript: 'LanguageEditorTheme__textSuperscript',
        underline: 'LanguageEditorTheme__textUnderline',
        underlineStrikethrough: 'LanguageEditorTheme__textUnderlineStrikethrough'
    }
};
const __TURBOPACK__default__export__ = theme;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/utils/customMarkdownTransformers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ANSWER_TRANSFORMER",
    ()=>ANSWER_TRANSFORMER,
    "CODE_BLOCK_QUIZ_TRANSFORMER",
    ()=>CODE_BLOCK_QUIZ_TRANSFORMER,
    "CUSTOM_ANSWER_TRANSFORMER",
    ()=>CUSTOM_ANSWER_TRANSFORMER,
    "CUSTOM_BLOCK_TRANSFORMERS",
    ()=>CUSTOM_BLOCK_TRANSFORMERS,
    "MEANING_ASSOCIATION_TRANSFORMER",
    ()=>MEANING_ASSOCIATION_TRANSFORMER,
    "QUIZ_TRANSFORMER",
    ()=>QUIZ_TRANSFORMER
]);
/**
 * Custom Markdown Transformers for Homework Supply Editor Blocks
 * 
 * Extends Lexical's markdown support to include custom block syntax:
 * 
 * Quiz Block:
 * :::quiz[q1,q2,q3]
 * 
 * Answer Block:
 * :::answer[word-1,word-2,word-3]
 * mode=translate
 * 
 * Meaning Association:
 * :::meaning[word-1,word-2,word-3,word-4]
 * modes=learn,easy,hard
 * 
 * Custom Answer:
 * :::custom-answer[q-1,q-2]
 * input=text,audio
 * prompt=audio
 * 
 * @see https://lexical.dev/docs/concepts/serialization#markdown
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/QuizPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/AnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/MeaningAssociationPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/CustomAnswerPlugin.jsx [app-client] (ecmascript)");
;
;
;
;
/**
 * Regular expressions for matching custom block syntax
 */ const QUIZ_REGEX = /^:::quiz\[([^\]]+)\]$/;
const ANSWER_REGEX = /^:::answer\[([^\]]+)\]$/;
const MEANING_REGEX = /^:::meaning\[([^\]]+)\]$/;
const CUSTOM_ANSWER_REGEX = /^:::custom-answer\[([^\]]+)\]$/;
/**
 * Parse metadata from following lines
 * Example:
 *   mode=translate
 *   input=text,audio
 */ function parseMetadata(lines) {
    const metadata = {};
    for (const line of lines){
        const match = line.match(/^(\w+)=(.+)$/);
        if (match) {
            const [, key, value] = match;
            // Split comma-separated values into arrays
            metadata[key] = value.includes(',') ? value.split(',').map((s)=>s.trim()) : value;
        } else if (line.trim() === '') {
            break;
        }
    }
    return metadata;
}
const QUIZ_TRANSFORMER = {
    dependencies: [],
    export: (node)=>{
        if (!$isQuizNode(node)) {
            return null;
        }
        const data = node.getData();
        // Filter out null items before mapping to IDs
        const ids = Array.isArray(data) ? data.filter((item)=>item != null && item.id != null).map((item)=>item.id).join(',') : '';
        return `:::quiz[${ids}]`;
    },
    regExp: QUIZ_REGEX,
    replace: (textNode, match)=>{
        const [, ids] = match;
        const idArray = ids.split(',').map((id)=>id.trim());
        const quizNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createQuizNode"])(idArray);
        textNode.replace(quizNode);
    },
    type: 'element'
};
const ANSWER_TRANSFORMER = {
    dependencies: [],
    export: (node)=>{
        if (!$isAnswerNode(node)) {
            return null;
        }
        const ids = node.getIds();
        const mode = node.getMode();
        let markdown = `:::answer[${ids.join(',')}]`;
        if (mode) {
            markdown += `\nmode=${mode}`;
        }
        return markdown;
    },
    regExp: ANSWER_REGEX,
    replace: (textNode, match)=>{
        const [, ids] = match;
        const idArray = ids.split(',').map((id)=>id.trim());
        // Look ahead for metadata on next lines
        // Note: This is simplified - full implementation would parse following lines
        const answerNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createAnswerNode"])(idArray);
        textNode.replace(answerNode);
    },
    type: 'element'
};
const MEANING_ASSOCIATION_TRANSFORMER = {
    dependencies: [],
    export: (node)=>{
        if (!$isMeaningAssociationNode(node)) {
            return null;
        }
        const ids = node.getIds();
        const enabledModes = node.getEnabledModes();
        let markdown = `:::meaning[${ids.join(',')}]`;
        if (enabledModes && enabledModes.length > 0) {
            markdown += `\nmodes=${enabledModes.join(',')}`;
        }
        return markdown;
    },
    regExp: MEANING_REGEX,
    replace: (textNode, match)=>{
        const [, ids] = match;
        const idArray = ids.split(',').map((id)=>id.trim());
        const meaningNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createMeaningAssociationNode"])(idArray);
        textNode.replace(meaningNode);
    },
    type: 'element'
};
const CUSTOM_ANSWER_TRANSFORMER = {
    dependencies: [],
    export: (node)=>{
        if (!$isCustomAnswerNode(node)) {
            return null;
        }
        const ids = node.getIds();
        const allowedInput = node.getAllowedInput();
        const promptMethod = node.getPromptMethod();
        let markdown = `:::custom-answer[${ids.join(',')}]`;
        if (allowedInput && allowedInput.length > 0) {
            markdown += `\ninput=${allowedInput.join(',')}`;
        }
        if (promptMethod && promptMethod.length > 0) {
            markdown += `\nprompt=${promptMethod.join(',')}`;
        }
        return markdown;
    },
    regExp: CUSTOM_ANSWER_REGEX,
    replace: (textNode, match)=>{
        const [, ids] = match;
        const idArray = ids.split(',').map((id)=>id.trim());
        const customAnswerNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createCustomAnswerNode"])(idArray);
        textNode.replace(customAnswerNode);
    },
    type: 'element'
};
const CODE_BLOCK_QUIZ_TRANSFORMER = {
    dependencies: [],
    export: (node)=>{
        if (!$isQuizNode(node)) {
            return null;
        }
        const data = node.getData();
        return '```quiz\n' + JSON.stringify({
            questions: data
        }, null, 2) + '\n```';
    },
    regExp: /^```quiz\s*\n([\s\S]+?)\n```$/,
    replace: (textNode, match)=>{
        const [, jsonContent] = match;
        try {
            const parsed = JSON.parse(jsonContent);
            const quizNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createQuizNode"])(parsed.questions || []);
            textNode.replace(quizNode);
        } catch (error) {
            console.error('[CODE_BLOCK_QUIZ_TRANSFORMER] Invalid JSON:', error);
        }
    },
    type: 'element'
};
const CUSTOM_BLOCK_TRANSFORMERS = [
    QUIZ_TRANSFORMER,
    ANSWER_TRANSFORMER,
    MEANING_ASSOCIATION_TRANSFORMER,
    CUSTOM_ANSWER_TRANSFORMER,
    CODE_BLOCK_QUIZ_TRANSFORMER
];
// Import type guards (these would need to be exported from the plugin files)
function $isQuizNode(node) {
    return node && node.getType && node.getType() === 'quiz';
}
function $isAnswerNode(node) {
    return node && node.getType && node.getType() === 'answer';
}
function $isMeaningAssociationNode(node) {
    return node && node.getType && node.getType() === 'meaning-association';
}
function $isCustomAnswerNode(node) {
    return node && node.getType && node.getType() === 'custom-answer';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/utils/swipe.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addSwipeDownListener",
    ()=>addSwipeDownListener,
    "addSwipeLeftListener",
    ()=>addSwipeLeftListener,
    "addSwipeRightListener",
    ()=>addSwipeRightListener,
    "addSwipeUpListener",
    ()=>addSwipeUpListener
]);
const elements = new WeakMap();
function readTouch(e) {
    const touch = e.changedTouches[0];
    if (touch === undefined) {
        return null;
    }
    return [
        touch.clientX,
        touch.clientY
    ];
}
function addListener(element, cb) {
    let elementValues = elements.get(element);
    if (elementValues === undefined) {
        const listeners = new Set();
        const handleTouchstart = (e)=>{
            if (elementValues !== undefined) {
                elementValues.start = readTouch(e);
            }
        };
        const handleTouchend = (e)=>{
            if (elementValues === undefined) {
                return;
            }
            const start = elementValues.start;
            if (start === null) {
                return;
            }
            const end = readTouch(e);
            for (const listener of listeners){
                if (end !== null) {
                    listener([
                        end[0] - start[0],
                        end[1] - start[1]
                    ], e);
                }
            }
        };
        element.addEventListener('touchstart', handleTouchstart);
        element.addEventListener('touchend', handleTouchend);
        elementValues = {
            handleTouchend,
            handleTouchstart,
            listeners,
            start: null
        };
        elements.set(element, elementValues);
    }
    elementValues.listeners.add(cb);
    return ()=>deleteListener(element, cb);
}
function deleteListener(element, cb) {
    const elementValues = elements.get(element);
    if (elementValues === undefined) {
        return;
    }
    const listeners = elementValues.listeners;
    listeners.delete(cb);
    if (listeners.size === 0) {
        elements.delete(element);
        element.removeEventListener('touchstart', elementValues.handleTouchstart);
        element.removeEventListener('touchend', elementValues.handleTouchend);
    }
}
function addSwipeLeftListener(element, cb) {
    return addListener(element, (force, e)=>{
        const [x, y] = force;
        if (x < 0 && -x > Math.abs(y)) {
            cb(x, e);
        }
    });
}
function addSwipeRightListener(element, cb) {
    return addListener(element, (force, e)=>{
        const [x, y] = force;
        if (x > 0 && x > Math.abs(y)) {
            cb(x, e);
        }
    });
}
function addSwipeUpListener(element, cb) {
    return addListener(element, (force, e)=>{
        const [x, y] = force;
        if (y < 0 && -y > Math.abs(x)) {
            cb(x, e);
        }
    });
}
function addSwipeDownListener(element, cb) {
    return addListener(element, (force, e)=>{
        const [x, y] = force;
        if (y > 0 && y > Math.abs(x)) {
            cb(x, e);
        }
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/editorConfig.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ALL_TRANSFORMERS",
    ()=>ALL_TRANSFORMERS,
    "DEBOUNCE_SAVE_DELAY_MS",
    ()=>DEBOUNCE_SAVE_DELAY_MS,
    "DRAWER_WIDTH",
    ()=>DRAWER_WIDTH,
    "EditorNodes",
    ()=>EditorNodes,
    "debounce",
    ()=>debounce,
    "onError",
    ()=>onError,
    "sanitizeEditorStateJSON",
    ()=>sanitizeEditorStateJSON
]);
/**
 * Shared editor configuration, nodes, and utilities for Editor3
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/rich-text/LexicalRichText.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/list/LexicalList.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$code$2f$LexicalCode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/code/LexicalCode.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$link$2f$LexicalLink$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/link/LexicalLink.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHorizontalRuleNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHorizontalRuleNode.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$hashtag$2f$LexicalHashtag$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/hashtag/LexicalHashtag.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/table/LexicalTable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$markdown$2f$LexicalMarkdown$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/markdown/LexicalMarkdown.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$utils$2f$customMarkdownTransformers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/utils/customMarkdownTransformers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$YouTubePlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/YouTubePlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$WordBlockPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/MeaningAssociationPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/QuizPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PdfViewerNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/PdfViewerNode.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AutocompleteNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AutocompleteNode.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AIContentSuggestionNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/AIContentSuggestionNode.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$ImageNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/ImageNode.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$LayoutContainerNode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/LayoutContainerNode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$LayoutItemNode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/LayoutItemNode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/AnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/CustomAnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAIPlugin$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/CustomAIPlugin.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ArmorEditorPlugin$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/ArmorEditorPlugin.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$nodes$2f$FileMetadataNode$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/nodes/FileMetadataNode/index.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ConversationPlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/ConversationPlaylistPlugin.jsx [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const EditorNodes = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeadingNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItemNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuoteNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$hashtag$2f$LexicalHashtag$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HashtagNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRowNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHorizontalRuleNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HorizontalRuleNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$code$2f$LexicalCode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CodeNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$code$2f$LexicalCode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CodeHighlightNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$link$2f$LexicalLink$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinkNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$link$2f$LexicalLink$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AutoLinkNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$YouTubePlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YouTubeNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$WordBlockPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WordBlockNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeaningAssociationNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AutocompleteNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AutocompleteNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AIContentSuggestionNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AIContentSuggestionNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$AIContentSuggestionNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AILoadingNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$ImageNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuizNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlaylistNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$PdfViewerNode$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PdfViewerNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$LayoutContainerNode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LayoutContainerNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$LayoutItemNode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LayoutItemNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnswerNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomAnswerNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAIPlugin$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomAINode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ArmorEditorPlugin$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArmorEditorNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$nodes$2f$FileMetadataNode$2f$index$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileMetadataNode"],
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ConversationPlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConversationPlaylistNode"]
];
const ALL_TRANSFORMERS = [
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$markdown$2f$LexicalMarkdown$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRANSFORMERS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$utils$2f$customMarkdownTransformers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CUSTOM_BLOCK_TRANSFORMERS"]
];
/**
 * Set of registered node type strings for fast lookup during sanitization
 */ const REGISTERED_NODE_TYPES = new Set(EditorNodes.map((NodeClass)=>NodeClass.getType?.()).filter(Boolean));
// Also include built-in Lexical types that don't need explicit registration
[
    "root",
    "text",
    "linebreak",
    "tab",
    "paragraph"
].forEach((t)=>REGISTERED_NODE_TYPES.add(t));
/**
 * Recursively sanitizes a parsed Lexical editor state JSON to remove nodes
 * with undefined, null, or unregistered types that would crash parseEditorState.
 */ function sanitizeNodeChildren(node) {
    if (!node || typeof node !== "object") return node;
    if (Array.isArray(node.children)) {
        node.children = node.children.filter((child)=>child != null && typeof child.type === "string" && child.type !== "undefined").filter((child)=>REGISTERED_NODE_TYPES.has(child.type)).map((child)=>sanitizeNodeChildren(child));
    }
    return node;
}
function sanitizeEditorStateJSON(jsonString) {
    if (!jsonString) return null;
    try {
        const parsed = JSON.parse(jsonString);
        if (!parsed?.root) return jsonString; // Not a Lexical state format, pass through
        // Ensure root node has required Lexical fields
        const root = parsed.root;
        if (!root.type) root.type = "root";
        if (root.version == null) root.version = 1;
        if (!("direction" in root)) root.direction = null;
        if (!("format" in root)) root.format = "";
        if (!("indent" in root)) root.indent = 0;
        sanitizeNodeChildren(root);
        return JSON.stringify(parsed);
    } catch  {
        console.warn("[Editor] Failed to sanitize editor state JSON, using null");
        return null;
    }
}
const DRAWER_WIDTH = 350;
const DEBOUNCE_SAVE_DELAY_MS = 2000;
function onError(error) {
    console.error(error);
    throw error;
}
function debounce(func, timeout = DEBOUNCE_SAVE_DELAY_MS) {
    let timer;
    return function(...args) {
        clearTimeout(timer);
        timer = setTimeout(()=>{
            func.apply(this, args);
        }, timeout);
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/styledComponents.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AppBar",
    ()=>AppBar,
    "Drawer",
    ()=>Drawer,
    "DrawerHeader",
    ()=>DrawerHeader,
    "closedMixin",
    ()=>closedMixin,
    "openedMixin",
    ()=>openedMixin
]);
/**
 * Shared styled components for Editor3
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Drawer/Drawer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AppBar/AppBar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/editorConfig.ts [app-client] (ecmascript)");
;
;
;
;
const openedMixin = (theme, width = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAWER_WIDTH"])=>({
        width: width,
        transition: theme.transitions.create("width", {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen
        }),
        overflowX: "hidden"
    });
const closedMixin = (theme)=>({
        transition: theme.transitions.create("width", {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        }),
        overflowX: "hidden",
        width: "2.5rem"
    });
const DrawerHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])("div")(({ theme })=>({
        display: "flex",
        alignItems: "center",
        justifyContent: "flex-end",
        padding: theme.spacing(0, 1),
        // necessary for content to be below app bar
        ...theme.mixins.toolbar
    }));
const AppBar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    shouldForwardProp: (prop)=>prop !== "open"
})(({ theme, open })=>({
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create([
            "width",
            "margin"
        ], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        }),
        ...open && {
            marginLeft: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAWER_WIDTH"],
            width: `calc(100% - ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAWER_WIDTH"]}px)`,
            transition: theme.transitions.create([
                "width",
                "margin"
            ], {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen
            })
        }
    }));
const Drawer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    shouldForwardProp: (prop)=>prop !== "open" && prop !== "drawerwidth"
})(({ theme, open, drawerwidth = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAWER_WIDTH"] })=>({
        width: open ? drawerwidth : "2.5rem",
        flexShrink: 0,
        boxSizing: "border-box",
        ...open && {
            ...openedMixin(theme, drawerwidth),
            "& .MuiDrawer-paper": {
                ...openedMixin(theme, drawerwidth),
                position: "relative",
                border: "none"
            }
        },
        ...!open && {
            whiteSpace: "nowrap",
            ...closedMixin(theme),
            "& .MuiDrawer-paper": {
                ...closedMixin(theme),
                position: "relative",
                border: "none"
            }
        }
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/Workbook.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Workbook",
    ()=>Workbook
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * Workbook Component - Read-only view of editor content for students
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalComposer.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalRichTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalRichTextPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalContentEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalErrorBoundary.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalAutoFocusPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalAutoFocusPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalCheckListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalCheckListPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalClickableLinkPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalClickableLinkPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHashtagPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHashtagPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHorizontalRulePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHorizontalRulePlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalListPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalTabIndentationPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalTabIndentationPlugin.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalTablePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalTablePlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalMarkdownShortcutPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalMarkdownShortcutPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$VerticalTabsRo$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/components/VerticalTabsRo.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$AudioPlayerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/context/AudioPlayerContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$SharedAutocompleteContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/context/SharedAutocompleteContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DndWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MeaningAssociationExercise/DndWrapper.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$config$2f$LanguageEditorTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/config/LanguageEditorTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$StoryProgressPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/StoryProgressPlugin.js [app-client] (ecmascript)");
// @ts-ignore - JSX file without proper module exports
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$WorkbookStatePlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/WorkbookStatePlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ToolBarRoPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/ToolBarRoPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$YouTubePlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/YouTubePlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$WordBlockPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/WordBlockPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/QuizPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/MeaningAssociationPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/PlaylistPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PdfViewerPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/PdfViewerPlugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ImagesPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/ImagesPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/AnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/CustomAnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$UnitCompletedPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/UnitCompletedPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/editorConfig.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$styledComponents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/styledComponents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/AppShellContext.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$TutorPresenceBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Workbook/TutorPresenceBanner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$WorkbookProgress$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Workbook/WorkbookProgress.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$TutorCursorOverlay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Workbook/TutorCursorOverlay.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$WorkbookPresenceBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Workbook/WorkbookPresenceBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$AIFeedbackSnackbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Workbook/AIFeedbackSnackbar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/unitContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function Workbook() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(62);
    if ($[0] !== "a8641678f93f31cc1304e4925f5c85a88b344ee64d96debc352a2f5d9875b86e") {
        for(let $i = 0; $i < 62; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a8641678f93f31cc1304e4925f5c85a88b344ee64d96debc352a2f5d9875b86e";
    }
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("common");
    const { appBarHeight: t0 } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppShell"])();
    const appBarHeight = t0 === undefined ? 48 : t0;
    const [openTab, setOpenTab] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [tabValue, setTabValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](0);
    const drawerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [actualDrawerWidth, setActualDrawerWidth] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAWER_WIDTH"]);
    const [currentDrawerWidth, setCurrentDrawerWidth] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRAWER_WIDTH"]);
    const [isScrolled, setIsScrolled] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const contentRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    let t1;
    let t2;
    if ($[1] !== openTab) {
        t1 = ({
            "Workbook[useEffect()]": ()=>{
                if (openTab && drawerRef.current) {
                    const resizeObserver = new ResizeObserver((entries)=>{
                        for (const entry of entries){
                            const width = entry.contentRect.width;
                            if (width > 0) {
                                setActualDrawerWidth(width);
                            }
                        }
                    });
                    resizeObserver.observe(drawerRef.current);
                    return ()=>{
                        resizeObserver.disconnect();
                    };
                }
            }
        })["Workbook[useEffect()]"];
        t2 = [
            openTab
        ];
        $[1] = openTab;
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t1, t2);
    let t3;
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "Workbook[useEffect()]": ()=>{
                const handleScroll = {
                    "Workbook[useEffect() > handleScroll]": (event)=>{
                        const target = event.target;
                        const scrollTop = target.scrollTop;
                        setIsScrolled(scrollTop > 50);
                    }
                }["Workbook[useEffect() > handleScroll]"];
                const contentElement = contentRef.current;
                if (contentElement) {
                    contentElement.addEventListener("scroll", handleScroll);
                    return ()=>{
                        contentElement.removeEventListener("scroll", handleScroll);
                    };
                }
            }
        })["Workbook[useEffect()]"];
        t4 = [];
        $[4] = t3;
        $[5] = t4;
    } else {
        t3 = $[4];
        t4 = $[5];
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](t3, t4);
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            namespace: "LanguageEditor",
            theme: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$config$2f$LanguageEditorTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
            onError: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onError"],
            editable: false,
            editorState: null,
            nodes: [
                ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EditorNodes"]
            ]
        };
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    const initialConfig = t5;
    let t10;
    let t11;
    let t12;
    let t13;
    let t14;
    let t15;
    let t16;
    let t17;
    let t18;
    let t19;
    let t20;
    let t21;
    let t22;
    let t23;
    let t24;
    let t25;
    let t26;
    let t27;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            id: "c0dcda9732e908ff",
            children: ".layout-container{display:grid}.layout-container>div{margin:.25rem;padding:.25rem}"
        }, void 0, false, void 0, this);
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalAutoFocusPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AutoFocusPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 169,
            columnNumber: 10
        }, this);
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalCheckListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CheckListPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 170,
            columnNumber: 10
        }, this);
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHashtagPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HashtagPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 171,
            columnNumber: 10
        }, this);
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHorizontalRulePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HorizontalRulePlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 172,
            columnNumber: 11
        }, this);
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 173,
            columnNumber: 11
        }, this);
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalTabIndentationPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TabIndentationPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 174,
            columnNumber: 11
        }, this);
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalMarkdownShortcutPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MarkdownShortcutPlugin"], {
            transformers: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$editorConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ALL_TRANSFORMERS"]
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 175,
            columnNumber: 11
        }, this);
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalTablePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TablePlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 176,
            columnNumber: 11
        }, this);
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalClickableLinkPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ClickableLinkPlugin"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 177,
            columnNumber: 11
        }, this);
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$YouTubePlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 178,
            columnNumber: 11
        }, this);
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$WordBlockPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 179,
            columnNumber: 11
        }, this);
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 180,
            columnNumber: 11
        }, this);
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$WorkbookStatePlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 181,
            columnNumber: 11
        }, this);
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$StoryProgressPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 182,
            columnNumber: 11
        }, this);
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 183,
            columnNumber: 11
        }, this);
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PlaylistPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 184,
            columnNumber: 11
        }, this);
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$PdfViewerPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 185,
            columnNumber: 11
        }, this);
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ImagesPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            captionsEnabled: false
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 187,
            columnNumber: 11
        }, this);
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 188,
            columnNumber: 11
        }, this);
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$UnitCompletedPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 189,
            columnNumber: 11
        }, this);
        $[7] = t10;
        $[8] = t11;
        $[9] = t12;
        $[10] = t13;
        $[11] = t14;
        $[12] = t15;
        $[13] = t16;
        $[14] = t17;
        $[15] = t18;
        $[16] = t19;
        $[17] = t20;
        $[18] = t21;
        $[19] = t22;
        $[20] = t23;
        $[21] = t24;
        $[22] = t25;
        $[23] = t26;
        $[24] = t27;
        $[25] = t6;
        $[26] = t7;
        $[27] = t8;
        $[28] = t9;
    } else {
        t10 = $[7];
        t11 = $[8];
        t12 = $[9];
        t13 = $[10];
        t14 = $[11];
        t15 = $[12];
        t16 = $[13];
        t17 = $[14];
        t18 = $[15];
        t19 = $[16];
        t20 = $[17];
        t21 = $[18];
        t22 = $[19];
        t23 = $[20];
        t24 = $[21];
        t25 = $[22];
        t26 = $[23];
        t27 = $[24];
        t6 = $[25];
        t7 = $[26];
        t8 = $[27];
        t9 = $[28];
    }
    const t28 = `calc(100vh - ${appBarHeight}px)`;
    let t29;
    if ($[29] !== t28) {
        t29 = {
            display: "flex",
            overflow: "hidden",
            height: t28
        };
        $[29] = t28;
        $[30] = t29;
    } else {
        t29 = $[30];
    }
    let t30;
    if ($[31] !== isScrolled || $[32] !== openTab) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$ToolBarRoPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            setOpen: setOpenTab,
            open: openTab,
            setTabValue: setTabValue,
            isScrolled: isScrolled
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 251,
            columnNumber: 11
        }, this);
        $[31] = isScrolled;
        $[32] = openTab;
        $[33] = t30;
    } else {
        t30 = $[33];
    }
    let t31;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
        t31 = {
            height: "100%",
            flexShrink: 0,
            position: "relative"
        };
        $[34] = t31;
    } else {
        t31 = $[34];
    }
    let t32;
    if ($[35] !== openTab || $[36] !== tabValue) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$components$2f$VerticalTabsRo$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            setOpen: setOpenTab,
            open: openTab,
            setDrawerWidth: setCurrentDrawerWidth,
            value: tabValue,
            setValue: setTabValue
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 271,
            columnNumber: 11
        }, this);
        $[35] = openTab;
        $[36] = tabValue;
        $[37] = t32;
    } else {
        t32 = $[37];
    }
    let t33;
    if ($[38] !== currentDrawerWidth || $[39] !== openTab || $[40] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$styledComponents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"], {
            ref: drawerRef,
            drawerwidth: currentDrawerWidth,
            sx: t31,
            variant: "permanent",
            open: openTab,
            children: t32
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 280,
            columnNumber: 11
        }, this);
        $[38] = currentDrawerWidth;
        $[39] = openTab;
        $[40] = t32;
        $[41] = t33;
    } else {
        t33 = $[41];
    }
    let t34;
    if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
        t34 = {
            flexGrow: 1,
            flexShrink: 1,
            minWidth: 0,
            margin: 0,
            padding: 0,
            boxSizing: "border-box",
            transition: _temp,
            marginLeft: 0
        };
        $[42] = t34;
    } else {
        t34 = $[42];
    }
    const t35 = `editor-${actualDrawerWidth}-${openTab}`;
    let t36;
    if ($[43] === Symbol.for("react.memo_cache_sentinel")) {
        t36 = {
            margin: "0",
            padding: "0",
            paddingLeft: "1.5rem",
            height: "100%",
            overflowY: "auto",
            width: "100%",
            boxSizing: "border-box"
        };
        $[43] = t36;
    } else {
        t36 = $[43];
    }
    let t37;
    let t38;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                px: 1,
                pt: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$WorkbookPresenceBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WorkbookPresenceBar"], {}, void 0, false, {
                    fileName: "[project]/src/components/Editor3/Workbook.tsx",
                    lineNumber: 326,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$TutorPresenceBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TutorPresenceBanner"], {}, void 0, false, {
                    fileName: "[project]/src/components/Editor3/Workbook.tsx",
                    lineNumber: 326,
                    columnNumber: 31
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$WorkbookProgress$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WorkbookProgress"], {
                    variant: "compact"
                }, void 0, false, {
                    fileName: "[project]/src/components/Editor3/Workbook.tsx",
                    lineNumber: 326,
                    columnNumber: 54
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 323,
            columnNumber: 11
        }, this);
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$TutorCursorOverlay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TutorCursorOverlay"], {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 327,
            columnNumber: 11
        }, this);
        $[44] = t37;
        $[45] = t38;
    } else {
        t37 = $[44];
        t38 = $[45];
    }
    let t39;
    if ($[46] !== t) {
        t39 = t("navigation.workbook");
        $[46] = t;
        $[47] = t39;
    } else {
        t39 = $[47];
    }
    let t40;
    if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
        t40 = {
            width: "100%",
            maxWidth: "100%",
            boxSizing: "border-box",
            minHeight: "100%",
            padding: "1rem 2rem 1rem 0.5rem"
        };
        $[48] = t40;
    } else {
        t40 = $[48];
    }
    let t41;
    if ($[49] !== t39) {
        t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalContentEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContentEditable"], {
            "data-lexical-editor": "true",
            "aria-label": t39,
            style: t40
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 357,
            columnNumber: 11
        }, this);
        $[49] = t39;
        $[50] = t41;
    } else {
        t41 = $[50];
    }
    let t42;
    if ($[51] !== t35 || $[52] !== t41) {
        t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            component: "main",
            sx: t34,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalRichTextPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RichTextPlugin"], {
                contentEditable: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "editor",
                    ref: contentRef,
                    "data-tour": "workbook",
                    style: t36,
                    children: [
                        t37,
                        t38,
                        t41
                    ]
                }, t35, true, {
                    fileName: "[project]/src/components/Editor3/Workbook.tsx",
                    lineNumber: 365,
                    columnNumber: 75
                }, this),
                placeholder: null,
                ErrorBoundary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalErrorBoundary$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalErrorBoundary"]
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/Workbook.tsx",
                lineNumber: 365,
                columnNumber: 42
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 365,
            columnNumber: 11
        }, this);
        $[51] = t35;
        $[52] = t41;
        $[53] = t42;
    } else {
        t42 = $[53];
    }
    let t43;
    if ($[54] !== t29 || $[55] !== t30 || $[56] !== t33 || $[57] !== t42) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposer$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LexicalComposer"], {
            initialConfig: initialConfig,
            children: [
                t6,
                t7,
                t8,
                t9,
                t10,
                t11,
                t12,
                t13,
                t14,
                t15,
                t16,
                t17,
                t18,
                t19,
                t20,
                t21,
                t22,
                t23,
                t24,
                t25,
                t26,
                t27,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    sx: t29,
                    children: [
                        t30,
                        t33,
                        t42
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/Workbook.tsx",
                    lineNumber: 374,
                    columnNumber: 164
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 374,
            columnNumber: 11
        }, this);
        $[54] = t29;
        $[55] = t30;
        $[56] = t33;
        $[57] = t42;
        $[58] = t43;
    } else {
        t43 = $[58];
    }
    let t44;
    if ($[59] === Symbol.for("react.memo_cache_sentinel")) {
        t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WorkbookAIFeedback, {}, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 385,
            columnNumber: 11
        }, this);
        $[59] = t44;
    } else {
        t44 = $[59];
    }
    let t45;
    if ($[60] !== t43) {
        t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MeaningAssociationExercise$2f$DndWrapper$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndWrapper"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$SharedAutocompleteContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AutocompleteProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$context$2f$AudioPlayerContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AudioPlayerProvider"], {
                    children: [
                        t43,
                        t44
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Editor3/Workbook.tsx",
                    lineNumber: 392,
                    columnNumber: 45
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Editor3/Workbook.tsx",
                lineNumber: 392,
                columnNumber: 23
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 392,
            columnNumber: 11
        }, this);
        $[60] = t43;
        $[61] = t45;
    } else {
        t45 = $[61];
    }
    return t45;
}
_s(Workbook, "a2LNcqG+1Qozrt82e15CxOE4DO4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AppShellContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppShell"]
    ];
});
_c = Workbook;
/** Renders AIFeedbackSnackbar using UnitContext workbook provider */ function _temp(theme) {
    return theme.transitions.create("margin", {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen
    });
}
function WorkbookAIFeedback() {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "a8641678f93f31cc1304e4925f5c85a88b344ee64d96debc352a2f5d9875b86e") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a8641678f93f31cc1304e4925f5c85a88b344ee64d96debc352a2f5d9875b86e";
    }
    const { workbook, workbookEnabled, session } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$unitContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    if (!workbookEnabled || !workbook?.provider) {
        return null;
    }
    const t0 = session?.username || "";
    let t1;
    if ($[1] !== t0 || $[2] !== workbook.provider) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Workbook$2f$AIFeedbackSnackbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AIFeedbackSnackbar"], {
            provider: workbook.provider,
            currentUsername: t0
        }, void 0, false, {
            fileName: "[project]/src/components/Editor3/Workbook.tsx",
            lineNumber: 427,
            columnNumber: 10
        }, this);
        $[1] = t0;
        $[2] = workbook.provider;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    return t1;
}
_s1(WorkbookAIFeedback, "wiC/DqLR9jKn+xjDFtdeEX482Nk=");
_c1 = WorkbookAIFeedback;
var _c, _c1;
__turbopack_context__.k.register(_c, "Workbook");
__turbopack_context__.k.register(_c1, "WorkbookAIFeedback");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Editor3/configs/chatMessageConfig.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "chatMessageEditorConfig",
    ()=>chatMessageEditorConfig,
    "createChatMessageConfig",
    ()=>createChatMessageConfig,
    "default",
    ()=>__TURBOPACK__default__export__
]);
/**
 * Lexical Editor Configuration for Chat Messages
 * 
 * Optimized read-only configuration for rendering chat messages with markdown support.
 * Includes all necessary nodes for rich text display but excludes editing features.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/rich-text/LexicalRichText.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$code$2f$LexicalCode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/code/LexicalCode.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$link$2f$LexicalLink$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/link/LexicalLink.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@lexical/list/LexicalList.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHorizontalRuleNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@lexical/react/LexicalHorizontalRuleNode.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/QuizPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/AnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/CustomAnswerPlugin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Editor3/plugins/MeaningAssociationPlugin.jsx [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
/**
 * Theme configuration for chat message rendering
 * Uses CSS classes that can be styled independently from main editor
 */ const chatMessageTheme = {
    paragraph: 'chat-message-paragraph',
    quote: 'chat-message-quote',
    heading: {
        h1: 'chat-message-h1',
        h2: 'chat-message-h2',
        h3: 'chat-message-h3',
        h4: 'chat-message-h4',
        h5: 'chat-message-h5',
        h6: 'chat-message-h6'
    },
    list: {
        ul: 'chat-message-ul',
        ol: 'chat-message-ol',
        listitem: 'chat-message-li',
        nested: {
            listitem: 'chat-message-li-nested'
        },
        checklist: 'chat-message-checklist'
    },
    code: 'chat-message-code',
    codeHighlight: {
        atrule: 'chat-code-atrule',
        attr: 'chat-code-attr',
        boolean: 'chat-code-boolean',
        builtin: 'chat-code-builtin',
        cdata: 'chat-code-cdata',
        char: 'chat-code-char',
        class: 'chat-code-class',
        'class-name': 'chat-code-class-name',
        comment: 'chat-code-comment',
        constant: 'chat-code-constant',
        deleted: 'chat-code-deleted',
        doctype: 'chat-code-doctype',
        entity: 'chat-code-entity',
        function: 'chat-code-function',
        important: 'chat-code-important',
        inserted: 'chat-code-inserted',
        keyword: 'chat-code-keyword',
        namespace: 'chat-code-namespace',
        number: 'chat-code-number',
        operator: 'chat-code-operator',
        prolog: 'chat-code-prolog',
        property: 'chat-code-property',
        punctuation: 'chat-code-punctuation',
        regex: 'chat-code-regex',
        selector: 'chat-code-selector',
        string: 'chat-code-string',
        symbol: 'chat-code-symbol',
        tag: 'chat-code-tag',
        url: 'chat-code-url',
        variable: 'chat-code-variable'
    },
    link: 'chat-message-link',
    text: {
        bold: 'chat-message-bold',
        italic: 'chat-message-italic',
        underline: 'chat-message-underline',
        strikethrough: 'chat-message-strikethrough',
        code: 'chat-message-inline-code'
    },
    hr: 'chat-message-hr'
};
const createChatMessageConfig = (options = {})=>{
    const { includeCustomBlocks = false, onInsertBlock } = options;
    const baseNodes = [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeadingNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuoteNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$code$2f$LexicalCode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CodeNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$code$2f$LexicalCode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CodeHighlightNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$link$2f$LexicalLink$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinkNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$link$2f$LexicalLink$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AutoLinkNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItemNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$lexical$2f$react$2f$LexicalHorizontalRuleNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HorizontalRuleNode"]
    ];
    // Add custom blocks if requested (for AI-generated content in chat)
    const nodes = includeCustomBlocks ? [
        ...baseNodes,
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$QuizPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuizNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$AnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnswerNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$CustomAnswerPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomAnswerNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Editor3$2f$plugins$2f$MeaningAssociationPlugin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeaningAssociationNode"]
    ] : baseNodes;
    return {
        namespace: 'ChatMessage',
        theme: chatMessageTheme,
        nodes,
        editable: false,
        onError: (error)=>{
            console.error('Lexical chat message error:', error);
        },
        // Pass insert callback to custom nodes via editor context
        ...onInsertBlock && {
            onInsertBlock
        }
    };
};
const chatMessageEditorConfig = createChatMessageConfig();
const __TURBOPACK__default__export__ = chatMessageEditorConfig;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_Editor3_01eg5sl._.js.map