(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Gamification/LevelBadge.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LevelBadge",
    ()=>LevelBadge,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoStories$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AutoStories.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TravelExplore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TravelExplore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$HistoryEdu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/HistoryEdu.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Diversity3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Diversity3.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/EmojiObjects.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$School$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/School.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const LEVEL_COLORS = {
    1: '#9e9e9e',
    // Beginner - grey
    2: '#4caf50',
    // Explorer - green
    3: '#2196f3',
    // Practitioner - blue
    4: '#9c27b0',
    // Contributor - purple
    5: '#ff9800',
    // Expert - orange
    6: '#f44336' // Master - red
};
const LEVEL_ICONS = {
    1: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoStories$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "small"
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/LevelBadge.tsx",
        lineNumber: 43,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0)),
    // Beginner — open book
    2: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TravelExplore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "small"
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/LevelBadge.tsx",
        lineNumber: 45,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0)),
    // Explorer — globe search
    3: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$HistoryEdu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "small"
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/LevelBadge.tsx",
        lineNumber: 47,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0)),
    // Practitioner — quill
    4: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Diversity3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "small"
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/LevelBadge.tsx",
        lineNumber: 49,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0)),
    // Contributor — group
    5: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "small"
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/LevelBadge.tsx",
        lineNumber: 51,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0)),
    // Expert — lightbulb
    6: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$School$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "small"
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/LevelBadge.tsx",
        lineNumber: 53,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0))
};
function LevelBadge(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23);
    if ($[0] !== "f359fbe48bf2e164fe651748ea385e25c211f5c63c7532feb8f47fc89e12eef6") {
        for(let $i = 0; $i < 23; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f359fbe48bf2e164fe651748ea385e25c211f5c63c7532feb8f47fc89e12eef6";
    }
    const { level, showProgress: t1, size: t2 } = t0;
    const showProgress = t1 === undefined ? true : t1;
    const size = t2 === undefined ? "medium" : t2;
    const color = LEVEL_COLORS[level.level] || LEVEL_COLORS[1];
    const icon = LEVEL_ICONS[level.level] || LEVEL_ICONS[1];
    const isSmall = size === "small";
    const tooltipText = level.xpForNextLevel !== null ? `Lvl. ${level.level} · ${level.label} — ${level.progress}% to Lvl. ${level.level + 1}` : `Lvl. ${level.level} · ${level.label}`;
    let t3;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            display: "inline-flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 0.5
        };
        $[1] = t3;
    } else {
        t3 = $[1];
    }
    const t4 = `Lvl. ${level.level}`;
    const t5 = isSmall ? "small" : "medium";
    const t6 = isSmall ? "0.75rem" : "0.875rem";
    let t7;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            color: "#fff"
        };
        $[2] = t7;
    } else {
        t7 = $[2];
    }
    let t8;
    if ($[3] !== color || $[4] !== t6) {
        t8 = {
            bgcolor: color,
            color: "#fff",
            fontWeight: 700,
            fontSize: t6,
            "& .MuiChip-icon": t7
        };
        $[3] = color;
        $[4] = t6;
        $[5] = t8;
    } else {
        t8 = $[5];
    }
    let t9;
    if ($[6] !== icon || $[7] !== t4 || $[8] !== t5 || $[9] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            icon: icon,
            label: t4,
            size: t5,
            sx: t8
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/LevelBadge.tsx",
            lineNumber: 115,
            columnNumber: 10
        }, this);
        $[6] = icon;
        $[7] = t4;
        $[8] = t5;
        $[9] = t8;
        $[10] = t9;
    } else {
        t9 = $[10];
    }
    let t10;
    if ($[11] !== color || $[12] !== isSmall || $[13] !== level.progress || $[14] !== level.xpForNextLevel || $[15] !== showProgress) {
        t10 = showProgress && level.xpForNextLevel !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                width: "100%",
                minWidth: isSmall ? 60 : 100
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "determinate",
                value: level.progress,
                sx: {
                    height: isSmall ? 4 : 6,
                    borderRadius: 3,
                    bgcolor: "action.hover",
                    "& .MuiLinearProgress-bar": {
                        bgcolor: color
                    }
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/LevelBadge.tsx",
                lineNumber: 129,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/LevelBadge.tsx",
            lineNumber: 126,
            columnNumber: 60
        }, this);
        $[11] = color;
        $[12] = isSmall;
        $[13] = level.progress;
        $[14] = level.xpForNextLevel;
        $[15] = showProgress;
        $[16] = t10;
    } else {
        t10 = $[16];
    }
    let t11;
    if ($[17] !== t10 || $[18] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/LevelBadge.tsx",
            lineNumber: 148,
            columnNumber: 11
        }, this);
        $[17] = t10;
        $[18] = t9;
        $[19] = t11;
    } else {
        t11 = $[19];
    }
    let t12;
    if ($[20] !== t11 || $[21] !== tooltipText) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: tooltipText,
            arrow: true,
            children: t11
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/LevelBadge.tsx",
            lineNumber: 157,
            columnNumber: 11
        }, this);
        $[20] = t11;
        $[21] = tooltipText;
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    return t12;
}
_c = LevelBadge;
const __TURBOPACK__default__export__ = LevelBadge;
var _c;
__turbopack_context__.k.register(_c, "LevelBadge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/AvatarGlowRing.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AvatarGlowRing",
    ()=>AvatarGlowRing,
    "DEFAULT_GLOW_COLORS",
    ()=>DEFAULT_GLOW_COLORS,
    "GLOW_COLOR_PRESETS",
    ()=>GLOW_COLOR_PRESETS,
    "GLOW_LEVEL_UP_DURATION_MS",
    ()=>GLOW_LEVEL_UP_DURATION_MS,
    "default",
    ()=>__TURBOPACK__default__export__,
    "isGlowActive",
    ()=>isGlowActive
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * AvatarGlowRing — Animated rotating gradient ring that encircles an avatar.
 *
 * Renders a conic-gradient border that continuously rotates, with a soft
 * outer glow that pulses. The gradient colors are user-configurable.
 *
 * Activated by the AVATAR_GLOW badge (earned on level-up) for a limited
 * duration, or permanently via easter egg.
 *
 * @module AvatarGlowRing
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
const DEFAULT_GLOW_COLORS = [
    '#ff6b6b',
    '#feca57',
    '#48dbfb',
    '#ff9ff3',
    '#54a0ff',
    '#5f27cd'
];
const GLOW_COLOR_PRESETS = {
    rainbow: [
        '#ff6b6b',
        '#feca57',
        '#48dbfb',
        '#ff9ff3',
        '#54a0ff',
        '#5f27cd'
    ],
    fire: [
        '#ff4500',
        '#ff6347',
        '#ffa500',
        '#ffd700',
        '#ff4500'
    ],
    ice: [
        '#00bfff',
        '#87ceeb',
        '#e0ffff',
        '#4169e1',
        '#00bfff'
    ],
    aurora: [
        '#00ff87',
        '#60efff',
        '#ff00e5',
        '#00ff87'
    ],
    sunset: [
        '#ff6b35',
        '#f7c59f',
        '#efefd0',
        '#ff6b35'
    ],
    ocean: [
        '#0077b6',
        '#00b4d8',
        '#90e0ef',
        '#caf0f8',
        '#0077b6'
    ],
    neon: [
        '#39ff14',
        '#ff073a',
        '#00fff7',
        '#f2ea02',
        '#39ff14'
    ]
};
const GLOW_LEVEL_UP_DURATION_MS = 24 * 60 * 60 * 1000;
function isGlowActive(config) {
    if (!config?.active) return false;
    if (!config.expiresAt) return true; // permanent
    return new Date(config.expiresAt).getTime() > Date.now();
}
/** Build a conic-gradient CSS string from color stops */ function buildConicGradient(colors) {
    if (colors.length < 2) return `conic-gradient(${colors[0] || '#fff'}, ${colors[0] || '#fff'})`;
    // Distribute colors evenly and repeat the first to close the loop
    const stops = [
        ...colors,
        colors[0]
    ];
    const step = 360 / (stops.length - 1);
    const cssStops = stops.map((c, i)=>`${c} ${Math.round(step * i)}deg`).join(', ');
    return `conic-gradient(${cssStops})`;
}
// Unique ID counter for SVG filter deduplication
let glowIdCounter = 0;
function AvatarGlowRing({ children, size, config }) {
    _s();
    const active = isGlowActive(config);
    const idRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(++glowIdCounter);
    if (!active) {
        // No ring — just render the avatar directly
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: children
        }, void 0, false);
    }
    const { colors = DEFAULT_GLOW_COLORS, speed = 4, thickness = 3 } = config;
    const ringSize = size + thickness * 2 + 4; // avatar + ring + small gap
    const gradient = buildConicGradient(colors);
    const glowColor = colors[0] || '#fff';
    const filterId = `glow-blur-${idRef.current}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            position: 'relative',
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: ringSize,
            height: ringSize
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                width: 0,
                height: 0,
                style: {
                    position: 'absolute'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("filter", {
                        id: filterId,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feGaussianBlur", {
                                stdDeviation: "3",
                                result: "blur"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
                                lineNumber: 121,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feMerge", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feMergeNode", {
                                        in: "blur"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
                                        lineNumber: 123,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feMergeNode", {
                                        in: "SourceGraphic"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
                                        lineNumber: 124,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
                                lineNumber: 122,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
                        lineNumber: 120,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
                    lineNumber: 119,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
                lineNumber: 116,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    position: 'absolute',
                    inset: 0,
                    borderRadius: '50%',
                    background: gradient,
                    filter: `url(#${filterId})`,
                    animation: `avatarGlowSpin ${speed}s linear infinite`,
                    '@keyframes avatarGlowSpin': {
                        '0%': {
                            transform: 'rotate(0deg)'
                        },
                        '100%': {
                            transform: 'rotate(360deg)'
                        }
                    }
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
                lineNumber: 131,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    position: 'absolute',
                    inset: -2,
                    borderRadius: '50%',
                    boxShadow: `0 0 ${size * 0.15}px ${glowColor}40, 0 0 ${size * 0.3}px ${glowColor}20`,
                    animation: `avatarGlowPulse ${speed * 0.75}s ease-in-out infinite alternate`,
                    '@keyframes avatarGlowPulse': {
                        '0%': {
                            opacity: 0.6
                        },
                        '100%': {
                            opacity: 1
                        }
                    }
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
                lineNumber: 149,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    position: 'absolute',
                    inset: `${thickness + 2}px`,
                    borderRadius: '50%',
                    bgcolor: 'background.paper'
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    position: 'relative',
                    zIndex: 1,
                    display: 'inline-flex',
                    borderRadius: '50%'
                },
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
                lineNumber: 174,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Gamification/AvatarGlowRing.tsx",
        lineNumber: 107,
        columnNumber: 10
    }, this);
}
_s(AvatarGlowRing, "6rVtrzf3zL31kiuSxy/GY4EaNyE=");
_c = AvatarGlowRing;
const __TURBOPACK__default__export__ = AvatarGlowRing;
var _c;
__turbopack_context__.k.register(_c, "AvatarGlowRing");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/DiceBearAvatar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ALL_AVATAR_STYLES",
    ()=>ALL_AVATAR_STYLES,
    "DiceBearAvatar",
    ()=>DiceBearAvatar,
    "LEVELING_STYLES",
    ()=>LEVELING_STYLES,
    "REWARD_ONLY_STYLES",
    ()=>REWARD_ONLY_STYLES,
    "STYLE_CONFIG",
    ()=>STYLE_CONFIG,
    "default",
    ()=>__TURBOPACK__default__export__,
    "getStyleNarrativeReason",
    ()=>getStyleNarrativeReason,
    "getStyleTierStatus",
    ()=>getStyleTierStatus,
    "getUnlockedStyleTier",
    ()=>getUnlockedStyleTier,
    "getUnlockedStyles",
    ()=>getUnlockedStyles
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * DiceBearAvatar — Generates and displays a DiceBear SVG avatar
 * from a seed string. Supports multiple style sets that unlock
 * at XP milestones.
 *
 * Uses `@dicebear/core` + style packages to generate inline SVG
 * entirely client-side — no external API calls.
 *
 * @module DiceBearAvatar
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$core$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/core/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$core$2f$lib$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/core/lib/core.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$avataaars$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/avataaars-neutral/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$avataaars$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/avataaars-neutral/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$avataaars$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/avataaars/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$avataaars$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/avataaars/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$toon$2d$head$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/toon-head/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$toon$2d$head$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/toon-head/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$lorelei$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/lorelei-neutral/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$lorelei$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/lorelei-neutral/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$notionists$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/notionists/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$notionists$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/notionists/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$open$2d$peeps$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/open-peeps/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$open$2d$peeps$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/open-peeps/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$personas$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/personas/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$personas$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/personas/lib/index.js [app-client] (ecmascript)");
// Extended styles (installed separately)
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$adventurer$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/adventurer/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$adventurer$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/adventurer/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$adventurer$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/adventurer-neutral/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$adventurer$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/adventurer-neutral/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$bottts$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/bottts/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$bottts$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/bottts/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$bottts$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/bottts-neutral/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$bottts$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/bottts-neutral/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$pixel$2d$art$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/pixel-art/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$pixel$2d$art$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/pixel-art/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$pixel$2d$art$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/pixel-art-neutral/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$pixel$2d$art$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/pixel-art-neutral/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$shapes$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/shapes/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$shapes$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/shapes/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$thumbs$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/thumbs/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$thumbs$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/thumbs/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$rings$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/rings/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$rings$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/rings/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$glass$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/glass/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$glass$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/glass/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$identicon$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/identicon/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$identicon$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/identicon/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$initials$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/initials/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$initials$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dicebear/initials/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$AvatarGlowRing$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/AvatarGlowRing.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// ============================================================================
// Style config — maps tier to DiceBear style collection + metadata
// ============================================================================
const STYLE_CONFIG = {
    simple: {
        displayName: 'Avataaars Neutral',
        description: 'Clean neutral character avatars'
    },
    detailed: {
        displayName: 'Avataaars',
        description: 'Full-featured character avatars'
    },
    toonhead: {
        displayName: 'Toon Head',
        description: 'Animated-series character portraits'
    },
    lorelei: {
        displayName: 'Lorelei',
        description: 'Soft pencil-sketch style portraits'
    },
    notionists: {
        displayName: 'Notionists',
        description: 'Minimalist line-art characters'
    },
    openpeeps: {
        displayName: 'Open Peeps',
        description: 'Hand-drawn illustration people'
    },
    personas: {
        displayName: 'Personas',
        description: 'Colorful geometric character avatars'
    },
    // Extended — surreal/abstract styles with narrative justification
    adventurer: {
        displayName: 'Adventurer',
        description: 'RPG-style character portraits',
        narrativeReason: 'Your debugging quest has granted you a hero\'s visage.'
    },
    'adventurer-neutral': {
        displayName: 'Adventurer Neutral',
        description: 'Gender-neutral RPG characters',
        narrativeReason: 'The code respects no gender — neither does your avatar.'
    },
    bottts: {
        displayName: 'Bottts',
        description: 'Robot companion avatars',
        narrativeReason: 'You stared into the CI/CD pipeline too long. It stared back. You are now partially automated.'
    },
    'bottts-neutral': {
        displayName: 'Bottts Neutral',
        description: 'Simplified robot avatars',
        narrativeReason: 'A minimalist mechanical form — the bugs can\'t target what has no flesh.'
    },
    'pixel-art': {
        displayName: 'Pixel Art',
        description: 'Retro 8-bit pixel avatars',
        narrativeReason: 'After resolving that legacy codebase, reality itself downgraded to 8-bit around you.'
    },
    'pixel-art-neutral': {
        displayName: 'Pixel Art Neutral',
        description: 'Neutral retro pixel style',
        narrativeReason: 'The compression artifacts are permanent. A small price for surviving the image optimization sprint.'
    },
    shapes: {
        displayName: 'Shapes',
        description: 'Abstract geometric forms',
        narrativeReason: 'You have transcended human form. You are now a pure abstraction — much like your code architecture.'
    },
    thumbs: {
        displayName: 'Thumbs',
        description: 'Expressive thumb characters',
        narrativeReason: 'When the PR was finally approved, you became the living embodiment of 👍. There is no going back.'
    },
    rings: {
        displayName: 'Rings',
        description: 'Concentric ring patterns',
        narrativeReason: 'Each ring represents a dependency cycle you broke. The pattern is infinite, like node_modules.'
    },
    glass: {
        displayName: 'Glass',
        description: 'Frosted glass refractions',
        narrativeReason: 'Your identity shattered across 47 microservices. What remains is... beautiful, actually.'
    },
    identicon: {
        displayName: 'Identicon',
        description: 'Hash-based geometric patterns',
        narrativeReason: 'You committed so many times that Git replaced your face with your commit hash. It\'s canonical now.'
    },
    initials: {
        displayName: 'Initials',
        description: 'Typographic initial letters',
        narrativeReason: 'After mass-renaming 200 variables, you forgot your own name. Only initials remain.'
    }
};
/** Maps style tier to its DiceBear collection module */ const STYLE_MAP = {
    simple: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$avataaars$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    detailed: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$avataaars$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    toonhead: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$toon$2d$head$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    lorelei: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$lorelei$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    notionists: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$notionists$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    openpeeps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$open$2d$peeps$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    personas: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$personas$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    adventurer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$adventurer$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    'adventurer-neutral': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$adventurer$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    bottts: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$bottts$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    'bottts-neutral': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$bottts$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    'pixel-art': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$pixel$2d$art$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    'pixel-art-neutral': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$pixel$2d$art$2d$neutral$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    shapes: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$shapes$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    thumbs: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$thumbs$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    rings: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$rings$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    glass: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$glass$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    identicon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$identicon$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__,
    initials: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$initials$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__
};
const ALL_AVATAR_STYLES = [
    'simple',
    'detailed',
    'toonhead',
    'lorelei',
    'notionists',
    'openpeeps',
    'personas',
    'adventurer',
    'adventurer-neutral',
    'bottts',
    'bottts-neutral',
    'pixel-art',
    'pixel-art-neutral',
    'shapes',
    'thumbs',
    'rings',
    'glass',
    'identicon',
    'initials'
];
const LEVELING_STYLES = [
    'simple',
    'detailed',
    'toonhead',
    'lorelei',
    'notionists',
    'openpeeps',
    'personas',
    'adventurer',
    'adventurer-neutral'
];
const REWARD_ONLY_STYLES = [
    'bottts',
    'bottts-neutral',
    'pixel-art',
    'pixel-art-neutral',
    'shapes',
    'thumbs',
    'rings',
    'glass',
    'identicon',
    'initials'
];
function getStyleNarrativeReason(tier) {
    return STYLE_CONFIG[tier]?.narrativeReason;
}
function DiceBearAvatar(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(34);
    if ($[0] !== "9005426d014140a346b988d88023ccef3de01b964b2853b56c332d073b868548") {
        for(let $i = 0; $i < 34; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9005426d014140a346b988d88023ccef3de01b964b2853b56c332d073b868548";
    }
    const { seed, style: t1, size: t2, label, onClick, locked: t3, overrides, glowRing } = t0;
    const style = t1 === undefined ? "simple" : t1;
    const size = t2 === undefined ? 48 : t2;
    const locked = t3 === undefined ? false : t3;
    let t4;
    bb0: {
        const styleModule = STYLE_MAP[style] || STYLE_MAP.simple;
        if (!styleModule?.meta) {
            t4 = "";
            break bb0;
        }
        let t5;
        if ($[1] !== overrides || $[2] !== seed || $[3] !== size || $[4] !== styleModule) {
            const options = {
                seed,
                size
            };
            if (overrides) {
                Object.entries(overrides).forEach({
                    "DiceBearAvatar[(anonymous)()]": (t6)=>{
                        const [key, value] = t6;
                        if (value !== undefined) {
                            options[key] = value;
                        }
                    }
                }["DiceBearAvatar[(anonymous)()]"]);
            }
            const avatar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dicebear$2f$core$2f$lib$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAvatar"])(styleModule, options);
            t5 = avatar.toDataUri();
            $[1] = overrides;
            $[2] = seed;
            $[3] = size;
            $[4] = styleModule;
            $[5] = t5;
        } else {
            t5 = $[5];
        }
        t4 = t5;
    }
    const dataUri = t4;
    const t5 = label || seed;
    const t6 = onClick ? "pointer" : "default";
    const t7 = locked ? "grayscale(100%) opacity(0.4)" : "none";
    let t8;
    if ($[6] !== locked || $[7] !== onClick) {
        t8 = onClick ? {
            filter: locked ? "grayscale(100%) opacity(0.5)" : "brightness(1.1)"
        } : undefined;
        $[6] = locked;
        $[7] = onClick;
        $[8] = t8;
    } else {
        t8 = $[8];
    }
    let t9;
    if ($[9] !== size || $[10] !== t6 || $[11] !== t7 || $[12] !== t8) {
        t9 = {
            width: size,
            height: size,
            cursor: t6,
            filter: t7,
            transition: "filter 0.3s ease",
            "&:hover": t8
        };
        $[9] = size;
        $[10] = t6;
        $[11] = t7;
        $[12] = t8;
        $[13] = t9;
    } else {
        t9 = $[13];
    }
    let t10;
    if ($[14] !== dataUri || $[15] !== onClick || $[16] !== t5 || $[17] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: dataUri,
            alt: t5,
            onClick: onClick,
            sx: t9
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/DiceBearAvatar.tsx",
            lineNumber: 353,
            columnNumber: 11
        }, this);
        $[14] = dataUri;
        $[15] = onClick;
        $[16] = t5;
        $[17] = t9;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    const avatar_0 = t10;
    let t11;
    if ($[19] !== glowRing) {
        t11 = glowRing && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$AvatarGlowRing$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isGlowActive"])(glowRing);
        $[19] = glowRing;
        $[20] = t11;
    } else {
        t11 = $[20];
    }
    const showGlow = t11;
    let t12;
    if ($[21] !== glowRing || $[22] !== showGlow || $[23] !== size) {
        t12 = ({
            "DiceBearAvatar[wrapGlow]": (node)=>showGlow ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$AvatarGlowRing$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AvatarGlowRing"], {
                    size: size,
                    config: glowRing,
                    children: node
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/DiceBearAvatar.tsx",
                    lineNumber: 375,
                    columnNumber: 54
                }, this) : node
        })["DiceBearAvatar[wrapGlow]"];
        $[21] = glowRing;
        $[22] = showGlow;
        $[23] = size;
        $[24] = t12;
    } else {
        t12 = $[24];
    }
    const wrapGlow = t12;
    if (label) {
        const t13 = locked ? `${label} (Locked)` : label;
        let t14;
        if ($[25] !== avatar_0 || $[26] !== wrapGlow) {
            t14 = wrapGlow(avatar_0);
            $[25] = avatar_0;
            $[26] = wrapGlow;
            $[27] = t14;
        } else {
            t14 = $[27];
        }
        let t15;
        if ($[28] !== t13 || $[29] !== t14) {
            t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: t13,
                children: t14
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/DiceBearAvatar.tsx",
                lineNumber: 398,
                columnNumber: 13
            }, this);
            $[28] = t13;
            $[29] = t14;
            $[30] = t15;
        } else {
            t15 = $[30];
        }
        return t15;
    }
    let t13;
    if ($[31] !== avatar_0 || $[32] !== wrapGlow) {
        t13 = wrapGlow(avatar_0);
        $[31] = avatar_0;
        $[32] = wrapGlow;
        $[33] = t13;
    } else {
        t13 = $[33];
    }
    return t13;
}
_c = DiceBearAvatar;
// ============================================================================
// Utility: get the style tier for a given level
// ============================================================================
/** Default level → style unlock schedule (used when no instructor config) */ const DEFAULT_LEVEL_TIERS = [
    {
        minLevel: 3,
        tier: 'toonhead'
    },
    {
        minLevel: 2,
        tier: 'detailed'
    },
    {
        minLevel: 1,
        tier: 'simple'
    }
];
/** @deprecated Use DEFAULT_LEVEL_TIERS instead */ const LEVEL_TIERS = DEFAULT_LEVEL_TIERS;
function getUnlockedStyleTier(level, config) {
    const tiers = config?.unlocks?.length ? config.unlocks : DEFAULT_LEVEL_TIERS;
    // Ensure sorted descending by minLevel for correct lookup
    const sorted = [
        ...tiers
    ].sort((a, b)=>b.minLevel - a.minLevel);
    for (const entry of sorted){
        if (level >= entry.minLevel) return entry.tier;
    }
    return sorted[sorted.length - 1]?.tier ?? 'simple';
}
function getUnlockedStyles(level, config) {
    const tiers = config?.unlocks?.length ? config.unlocks : DEFAULT_LEVEL_TIERS;
    return tiers.filter((entry)=>level >= entry.minLevel).map((e)=>e.tier);
}
function getStyleTierStatus(level, config) {
    const tiers = config?.unlocks?.length ? config.unlocks : DEFAULT_LEVEL_TIERS;
    return [
        ...tiers
    ].sort((a, b)=>a.minLevel - b.minLevel).map((entry)=>({
            tier: entry.tier,
            unlocked: level >= entry.minLevel,
            displayName: STYLE_CONFIG[entry.tier]?.displayName ?? entry.tier
        }));
}
;
const __TURBOPACK__default__export__ = DiceBearAvatar;
var _c;
__turbopack_context__.k.register(_c, "DiceBearAvatar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/AvatarDisplay.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AvatarDisplay",
    ()=>AvatarDisplay,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Avatar/Avatar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Whatshot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Whatshot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoStories$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AutoStories.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TravelExplore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/TravelExplore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$HistoryEdu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/HistoryEdu.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Diversity3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Diversity3.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/EmojiObjects.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$School$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/School.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/DiceBearAvatar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$AvatarGlowRing$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/AvatarGlowRing.tsx [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// ============================================================================
// Level icon/color config (matches LevelBadge)
// ============================================================================
const LEVEL_COLORS = {
    1: '#9e9e9e',
    // Beginner - grey
    2: '#4caf50',
    // Explorer - green
    3: '#2196f3',
    // Practitioner - blue
    4: '#9c27b0',
    // Contributor - purple
    5: '#ff9800',
    // Expert - orange
    6: '#f44336' // Master - red
};
const LEVEL_ICONS = {
    1: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AutoStories$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: '0.9rem'
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
        lineNumber: 47,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0)),
    2: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$TravelExplore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: '0.9rem'
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
        lineNumber: 50,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0)),
    3: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$HistoryEdu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: '0.9rem'
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
        lineNumber: 53,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0)),
    4: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Diversity3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: '0.9rem'
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
        lineNumber: 56,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0)),
    5: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: '0.9rem'
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
        lineNumber: 59,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0)),
    6: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$School$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        sx: {
            fontSize: '0.9rem'
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
        lineNumber: 62,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0))
};
function hashToColor(str) {
    let hash = 0;
    for(let i = 0; i < str.length; i++){
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
        hash |= 0;
    }
    const hue = Math.abs(hash) % 360;
    return `hsl(${hue}, 60%, 45%)`;
}
function getInitials(name) {
    return name.split(/\s+/).slice(0, 2).map((w)=>w.charAt(0).toUpperCase()).join('');
}
// ============================================================================
// Border effect styles
// ============================================================================
const BORDER_CONFIGS = {
    none: ()=>({}),
    solid: (color = '#1976d2')=>({
            border: `3px solid ${color}`
        }),
    gradient: ()=>({}),
    // Handled via AvatarGlowRing
    pulse: ()=>({
            border: '3px solid #9c27b0',
            animation: 'avatarDisplayPulse 2s ease-in-out infinite',
            '@keyframes avatarDisplayPulse': {
                '0%, 100%': {
                    boxShadow: '0 0 0 0 rgba(156, 39, 176, 0.4)'
                },
                '50%': {
                    boxShadow: '0 0 0 8px rgba(156, 39, 176, 0)'
                }
            }
        }),
    rainbow: ()=>({}),
    // Handled via AvatarGlowRing
    fire: ()=>({
            border: '3px solid #ff4500',
            boxShadow: '0 0 8px rgba(255, 69, 0, 0.5), 0 0 16px rgba(255, 69, 0, 0.3)',
            animation: 'avatarDisplayFire 1.5s ease-in-out infinite alternate',
            '@keyframes avatarDisplayFire': {
                '0%': {
                    boxShadow: '0 0 8px rgba(255, 69, 0, 0.5), 0 0 16px rgba(255, 69, 0, 0.3)'
                },
                '100%': {
                    boxShadow: '0 0 12px rgba(255, 165, 0, 0.7), 0 0 24px rgba(255, 69, 0, 0.5)'
                }
            }
        }),
    ice: ()=>({
            border: '3px solid #00bfff',
            boxShadow: '0 0 8px rgba(0, 191, 255, 0.4), 0 0 16px rgba(135, 206, 235, 0.2)'
        }),
    gold: ()=>({
            border: '3px solid #ffd700',
            boxShadow: '0 0 6px rgba(255, 215, 0, 0.5), inset 0 0 4px rgba(255, 215, 0, 0.2)'
        }),
    shadow: ()=>({
            border: '3px solid #424242',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.4), 0 2px 6px rgba(0, 0, 0, 0.3)'
        })
};
/** Map border effects that need a glow ring to their ring config */ function getEffectGlowConfig(effect, color, secondary) {
    if (effect === 'rainbow') {
        return {
            colors: [
                '#ff6b6b',
                '#feca57',
                '#48dbfb',
                '#ff9ff3',
                '#54a0ff',
                '#5f27cd'
            ],
            speed: 3,
            thickness: 3,
            active: true,
            expiresAt: null
        };
    }
    if (effect === 'gradient') {
        return {
            colors: [
                color || '#ff6b6b',
                secondary || '#54a0ff'
            ],
            speed: 6,
            thickness: 3,
            active: true,
            expiresAt: null
        };
    }
    return null;
}
function AvatarDisplay(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(55);
    if ($[0] !== "94a19b39c33f7c9dd8563c1ddde6eafbd88bde8561146ee5c2c3bee33c08438b") {
        for(let $i = 0; $i < 55; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "94a19b39c33f7c9dd8563c1ddde6eafbd88bde8561146ee5c2c3bee33c08438b";
    }
    const { seed, style: t1, size: t2, streak: t3, level, badge, borderEffect: t4, borderColor, borderColorSecondary, glowRing, overrides, onClick, label, locked: t5, guildCrestSvg, guildName, guildId } = t0;
    const style = t1 === undefined ? "simple" : t1;
    const size = t2 === undefined ? 64 : t2;
    const streak = t3 === undefined ? 0 : t3;
    const borderEffect = t4 === undefined ? "none" : t4;
    const locked = t5 === undefined ? false : t5;
    const showGlow = glowRing && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$AvatarGlowRing$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isGlowActive"])(glowRing);
    let t6;
    if ($[1] !== borderColor || $[2] !== borderColorSecondary || $[3] !== borderEffect) {
        t6 = getEffectGlowConfig(borderEffect, borderColor, borderColorSecondary);
        $[1] = borderColor;
        $[2] = borderColorSecondary;
        $[3] = borderEffect;
        $[4] = t6;
    } else {
        t6 = $[4];
    }
    const effectGlow = t6;
    const activeGlow = showGlow ? glowRing : effectGlow;
    let t7;
    if ($[5] !== activeGlow || $[6] !== borderColor || $[7] !== borderColorSecondary || $[8] !== borderEffect) {
        t7 = activeGlow ? {} : BORDER_CONFIGS[borderEffect](borderColor, borderColorSecondary);
        $[5] = activeGlow;
        $[6] = borderColor;
        $[7] = borderColorSecondary;
        $[8] = borderEffect;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    const borderStyles = t7;
    const hasGuildBadge = Boolean(guildCrestSvg || guildName);
    let t8;
    if ($[10] !== size) {
        t8 = Math.round(size * 0.3);
        $[10] = size;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    const guildBadgeSize = Math.max(18, t8);
    const t9 = guildId || guildName || seed;
    let t10;
    if ($[12] !== t9) {
        t10 = hashToColor(t9);
        $[12] = t9;
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    const guildBgColor = t10;
    const t11 = guildName || "Guild";
    let t12;
    if ($[14] !== t11) {
        t12 = getInitials(t11);
        $[14] = t11;
        $[15] = t12;
    } else {
        t12 = $[15];
    }
    const guildInitials = t12;
    const containerSize = size + 16;
    let t13;
    if ($[16] !== containerSize) {
        t13 = {
            display: "inline-flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 0.5,
            position: "relative",
            minWidth: containerSize
        };
        $[16] = containerSize;
        $[17] = t13;
    } else {
        t13 = $[17];
    }
    let t14;
    if ($[18] !== streak) {
        t14 = streak > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                position: "absolute",
                top: "60%",
                right: -20,
                zIndex: 3,
                display: "flex",
                alignItems: "center",
                gap: "2px",
                bgcolor: "background.paper",
                borderRadius: "10px",
                px: 0.5,
                py: "1px",
                boxShadow: 1,
                fontSize: "0.7rem"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Whatshot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        fontSize: "0.85rem",
                        color: streak >= 7 ? "#ff6d00" : "#ff9800"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
                    lineNumber: 328,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "caption",
                    sx: {
                        fontWeight: 700,
                        lineHeight: 1
                    },
                    children: streak
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
                    lineNumber: 331,
                    columnNumber: 12
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
            lineNumber: 314,
            columnNumber: 25
        }, this);
        $[18] = streak;
        $[19] = t14;
    } else {
        t14 = $[19];
    }
    let t15;
    if ($[20] !== guildBadgeSize || $[21] !== guildBgColor || $[22] !== guildCrestSvg || $[23] !== guildInitials || $[24] !== guildName || $[25] !== hasGuildBadge) {
        t15 = hasGuildBadge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: guildName ? `Guild: ${guildName}` : "Guild crest",
            arrow: true,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    position: "absolute",
                    top: "60%",
                    left: -20,
                    zIndex: 3,
                    bgcolor: "background.paper",
                    borderRadius: "50%",
                    boxShadow: 1,
                    p: "2px",
                    display: "inline-flex"
                },
                children: guildCrestSvg ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        width: guildBadgeSize,
                        height: guildBadgeSize,
                        bgcolor: "transparent",
                        "& svg": {
                            width: "100%",
                            height: "100%"
                        }
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        component: "span",
                        dangerouslySetInnerHTML: {
                            __html: guildCrestSvg
                        },
                        sx: {
                            display: "flex",
                            width: "100%",
                            height: "100%"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
                        lineNumber: 360,
                        columnNumber: 12
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
                    lineNumber: 352,
                    columnNumber: 27
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        width: guildBadgeSize,
                        height: guildBadgeSize,
                        bgcolor: guildBgColor,
                        fontSize: Math.max(10, Math.round(guildBadgeSize * 0.4)),
                        fontWeight: 700
                    },
                    children: guildInitials
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
                    lineNumber: 366,
                    columnNumber: 28
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
                lineNumber: 342,
                columnNumber: 108
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
            lineNumber: 342,
            columnNumber: 28
        }, this);
        $[20] = guildBadgeSize;
        $[21] = guildBgColor;
        $[22] = guildCrestSvg;
        $[23] = guildInitials;
        $[24] = guildName;
        $[25] = hasGuildBadge;
        $[26] = t15;
    } else {
        t15 = $[26];
    }
    let t16;
    if ($[27] !== level) {
        t16 = level && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: `Lv. ${level.level} · ${level.label}`,
            arrow: true,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    position: "absolute",
                    top: "28%",
                    right: -18,
                    zIndex: 3,
                    bgcolor: "background.paper",
                    borderRadius: "50%",
                    width: 22,
                    height: 22,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    boxShadow: 1,
                    color: LEVEL_COLORS[level.level] || LEVEL_COLORS[1]
                },
                children: LEVEL_ICONS[level.level] || LEVEL_ICONS[1]
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
                lineNumber: 385,
                columnNumber: 88
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
            lineNumber: 385,
            columnNumber: 20
        }, this);
        $[27] = level;
        $[28] = t16;
    } else {
        t16 = $[28];
    }
    let t17;
    if ($[29] !== activeGlow || $[30] !== borderStyles) {
        t17 = !activeGlow ? borderStyles : {};
        $[29] = activeGlow;
        $[30] = borderStyles;
        $[31] = t17;
    } else {
        t17 = $[31];
    }
    let t18;
    if ($[32] !== t17) {
        t18 = {
            position: "relative",
            borderRadius: "50%",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            ...t17
        };
        $[32] = t17;
        $[33] = t18;
    } else {
        t18 = $[33];
    }
    let t19;
    if ($[34] !== activeGlow || $[35] !== label || $[36] !== locked || $[37] !== onClick || $[38] !== overrides || $[39] !== seed || $[40] !== size || $[41] !== style) {
        t19 = activeGlow ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$AvatarGlowRing$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AvatarGlowRing"], {
            size: size,
            config: activeGlow,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DiceBearAvatar"], {
                seed: seed,
                style: style,
                size: size,
                label: label,
                onClick: onClick,
                locked: locked,
                overrides: overrides
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
                lineNumber: 431,
                columnNumber: 72
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
            lineNumber: 431,
            columnNumber: 24
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$DiceBearAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DiceBearAvatar"], {
            seed: seed,
            style: style,
            size: size,
            label: label,
            onClick: onClick,
            locked: locked,
            overrides: overrides
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
            lineNumber: 431,
            columnNumber: 218
        }, this);
        $[34] = activeGlow;
        $[35] = label;
        $[36] = locked;
        $[37] = onClick;
        $[38] = overrides;
        $[39] = seed;
        $[40] = size;
        $[41] = style;
        $[42] = t19;
    } else {
        t19 = $[42];
    }
    let t20;
    if ($[43] !== t18 || $[44] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t18,
            children: t19
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
            lineNumber: 446,
            columnNumber: 11
        }, this);
        $[43] = t18;
        $[44] = t19;
        $[45] = t20;
    } else {
        t20 = $[45];
    }
    let t21;
    if ($[46] !== badge) {
        t21 = badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    display: "flex",
                    alignItems: "center",
                    gap: "3px"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        role: "img",
                        "aria-label": "badge",
                        children: badge.emoji
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
                        lineNumber: 459,
                        columnNumber: 8
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: badge.label
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
                        lineNumber: 459,
                        columnNumber: 64
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
                lineNumber: 455,
                columnNumber: 33
            }, this),
            size: "small",
            sx: {
                mt: -1,
                height: 20,
                fontSize: "0.65rem",
                fontWeight: 600,
                "& .MuiChip-label": {
                    px: 0.75
                },
                bgcolor: "action.selected",
                position: "relative",
                zIndex: 2
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
            lineNumber: 455,
            columnNumber: 20
        }, this);
        $[46] = badge;
        $[47] = t21;
    } else {
        t21 = $[47];
    }
    let t22;
    if ($[48] !== t13 || $[49] !== t14 || $[50] !== t15 || $[51] !== t16 || $[52] !== t20 || $[53] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t13,
            children: [
                t14,
                t15,
                t16,
                t20,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/AvatarDisplay.tsx",
            lineNumber: 478,
            columnNumber: 11
        }, this);
        $[48] = t13;
        $[49] = t14;
        $[50] = t15;
        $[51] = t16;
        $[52] = t20;
        $[53] = t21;
        $[54] = t22;
    } else {
        t22 = $[54];
    }
    return t22;
}
_c = AvatarDisplay;
const __TURBOPACK__default__export__ = AvatarDisplay;
var _c;
__turbopack_context__.k.register(_c, "AvatarDisplay");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/XPToast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "XPToast",
    ()=>XPToast,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/EmojiObjects.js [app-client] (ecmascript)");
;
;
;
;
;
function XPToast(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "a1bb52c1c8a1f15783761640cd69ad537e51c460f24baed3e21c31f7b5bef4d1") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a1bb52c1c8a1f15783761640cd69ad537e51c460f24baed3e21c31f7b5bef4d1";
    }
    const { open, xpAmount, xpReason, onClose, autoHideDuration: t1 } = t0;
    const autoHideDuration = t1 === undefined ? 2500 : t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            vertical: "bottom",
            horizontal: "right"
        };
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    let t3;
    let t4;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$EmojiObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/XPToast.tsx",
            lineNumber: 48,
            columnNumber: 10
        }, this);
        t4 = {
            fontWeight: 600
        };
        $[2] = t3;
        $[3] = t4;
    } else {
        t3 = $[2];
        t4 = $[3];
    }
    let t5;
    if ($[4] !== xpAmount || $[5] !== xpReason) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            severity: "success",
            icon: t3,
            sx: t4,
            children: [
                "+",
                xpAmount,
                " XP — ",
                xpReason
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/XPToast.tsx",
            lineNumber: 60,
            columnNumber: 10
        }, this);
        $[4] = xpAmount;
        $[5] = xpReason;
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] !== autoHideDuration || $[8] !== onClose || $[9] !== open || $[10] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            autoHideDuration: autoHideDuration,
            anchorOrigin: t2,
            onClose: onClose,
            children: t5
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/XPToast.tsx",
            lineNumber: 69,
            columnNumber: 10
        }, this);
        $[7] = autoHideDuration;
        $[8] = onClose;
        $[9] = open;
        $[10] = t5;
        $[11] = t6;
    } else {
        t6 = $[11];
    }
    return t6;
}
_c = XPToast;
const __TURBOPACK__default__export__ = XPToast;
var _c;
__turbopack_context__.k.register(_c, "XPToast");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/ThemeMixer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeMixer",
    ()=>ThemeMixer,
    "buildFullPaletteFromCustom",
    ()=>buildFullPaletteFromCustom,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * ThemeMixer — Color picker UI for creating custom themes.
 *
 * Users can adjust primary, secondary, background, and accent colors.
 * Generates both light and dark palette variants from chosen colors.
 *
 * @module ThemeMixer
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ButtonGroup$2f$ButtonGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ButtonGroup/ButtonGroup.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Save.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Restore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Restore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
/** Default starting palette (the "default" theme colors) */ const DEFAULT_CUSTOM_PALETTE = {
    primaryMain: '#556cd6',
    secondaryMain: '#19857b',
    backgroundDefault: '#fafafa',
    backgroundPaper: '#ffffff',
    accentColor: '#ffeb3b'
};
// ============================================================================
// Helpers — auto-derive dark mode + custom tokens from user's picks
// ============================================================================
/** Darken a hex color by a factor (0–1) */ function darken(hex, factor) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    const dr = Math.round(r * (1 - factor));
    const dg = Math.round(g * (1 - factor));
    const db = Math.round(b * (1 - factor));
    return `#${dr.toString(16).padStart(2, '0')}${dg.toString(16).padStart(2, '0')}${db.toString(16).padStart(2, '0')}`;
}
/** Lighten a hex color by a factor (0–1) */ function lighten(hex, factor) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    const lr = Math.round(r + (255 - r) * factor);
    const lg = Math.round(g + (255 - g) * factor);
    const lb = Math.round(b + (255 - b) * factor);
    return `#${lr.toString(16).padStart(2, '0')}${lg.toString(16).padStart(2, '0')}${lb.toString(16).padStart(2, '0')}`;
}
/** Add alpha to a hex color */ function withAlpha(hex, alpha) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r},${g},${b},${alpha})`;
}
// ============================================================================
// HSL ↔ Hex conversions for color wheel
// ============================================================================
function hexToHsl(hex) {
    const r = parseInt(hex.slice(1, 3), 16) / 255;
    const g = parseInt(hex.slice(3, 5), 16) / 255;
    const b = parseInt(hex.slice(5, 7), 16) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const l = (max + min) / 2;
    if (max === min) return [
        0,
        0,
        l
    ];
    const d = max - min;
    const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    let h = 0;
    if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
    else if (max === g) h = ((b - r) / d + 2) / 6;
    else h = ((r - g) / d + 4) / 6;
    return [
        h * 360,
        s,
        l
    ];
}
function hslToHex(h, s, l) {
    h = (h % 360 + 360) % 360;
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs(h / 60 % 2 - 1));
    const m = l - c / 2;
    let r = 0, g = 0, b = 0;
    if (h < 60) {
        r = c;
        g = x;
    } else if (h < 120) {
        r = x;
        g = c;
    } else if (h < 180) {
        g = c;
        b = x;
    } else if (h < 240) {
        g = x;
        b = c;
    } else if (h < 300) {
        r = x;
        b = c;
    } else {
        r = c;
        b = x;
    }
    const toHex = (v)=>Math.round((v + m) * 255).toString(16).padStart(2, '0');
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}
const HARMONY_LABELS = {
    mono: 'Mono',
    analogous: 'Analogous',
    split: 'Split',
    complementary: 'Compl.',
    triadic: 'Triadic',
    square: 'Square'
};
/**
 * Given a base hue, generate 5 hues for the palette colors using the specified harmony.
 * Returns [primary, secondary, background, paper, accent] hues and adjusted S/L values.
 */ function generateHarmonyPalette(baseHue, harmony) {
    const hues = [];
    switch(harmony){
        case 'mono':
            hues.push(baseHue, baseHue, baseHue, baseHue, baseHue);
            break;
        case 'analogous':
            hues.push(baseHue, baseHue + 30, baseHue, baseHue, baseHue - 30);
            break;
        case 'split':
            hues.push(baseHue, baseHue + 150, baseHue, baseHue, baseHue - 150);
            break;
        case 'complementary':
            hues.push(baseHue, baseHue + 180, baseHue, baseHue, baseHue + 180);
            break;
        case 'triadic':
            hues.push(baseHue, baseHue + 120, baseHue, baseHue, baseHue + 240);
            break;
        case 'square':
            hues.push(baseHue, baseHue + 90, baseHue, baseHue, baseHue + 270);
            break;
    }
    return {
        primaryMain: hslToHex(hues[0], 0.65, 0.45),
        secondaryMain: hslToHex(hues[1], 0.55, 0.4),
        backgroundDefault: hslToHex(hues[2], 0.05, 0.97),
        backgroundPaper: '#ffffff',
        accentColor: hslToHex(hues[4], 0.7, 0.55)
    };
}
function buildFullPaletteFromCustom(input) {
    return {
        light: {
            primary: {
                main: input.primaryMain
            },
            secondary: {
                main: input.secondaryMain
            },
            background: {
                default: input.backgroundDefault,
                paper: input.backgroundPaper
            },
            custom: {
                chatBubbleUser: lighten(input.primaryMain, 0.85),
                chatBubbleAssistant: lighten(input.secondaryMain, 0.9),
                glassNavbar: withAlpha(input.backgroundDefault, 0.85),
                editorBackground: input.backgroundPaper,
                codeBlock: lighten(input.backgroundDefault, 0.3),
                searchHighlight: input.accentColor,
                subtleBorder: darken(input.backgroundDefault, 0.15)
            }
        },
        dark: {
            primary: {
                main: lighten(input.primaryMain, 0.2)
            },
            secondary: {
                main: lighten(input.secondaryMain, 0.2)
            },
            background: {
                default: darken(input.backgroundDefault, 0.85),
                paper: darken(input.backgroundPaper, 0.8)
            },
            text: {
                primary: '#e0e0e0',
                secondary: '#a0a0a0'
            },
            custom: {
                chatBubbleUser: darken(input.primaryMain, 0.7),
                chatBubbleAssistant: darken(input.secondaryMain, 0.75),
                glassNavbar: withAlpha(darken(input.backgroundDefault, 0.85), 0.85),
                editorBackground: darken(input.backgroundPaper, 0.8),
                codeBlock: darken(input.backgroundDefault, 0.9),
                searchHighlight: darken(input.accentColor, 0.5),
                subtleBorder: darken(input.backgroundDefault, 0.6)
            }
        }
    };
}
function ThemeMixer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(106);
    if ($[0] !== "6b1a4a2ecb25c919621f7ee7dd3d85377cf10f6309875f26560cba7cac545b1a") {
        for(let $i = 0; $i < 106; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6b1a4a2ecb25c919621f7ee7dd3d85377cf10f6309875f26560cba7cac545b1a";
    }
    const { value, onSave } = t0;
    let t1;
    if ($[1] !== value) {
        t1 = ({
            "ThemeMixer[useState()]": ()=>value || DEFAULT_CUSTOM_PALETTE
        })["ThemeMixer[useState()]"];
        $[1] = value;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [palette, setPalette] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "ThemeMixer[handleChange]": (field, newValue)=>{
                setPalette({
                    "ThemeMixer[handleChange > setPalette()]": (prev)=>({
                            ...prev,
                            [field]: newValue
                        })
                }["ThemeMixer[handleChange > setPalette()]"]);
            }
        })["ThemeMixer[handleChange]"];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const handleChange = t2;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "ThemeMixer[handleReset]": ()=>{
                setPalette(DEFAULT_CUSTOM_PALETTE);
            }
        })["ThemeMixer[handleReset]"];
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const handleReset = t3;
    let t4;
    if ($[5] !== onSave || $[6] !== palette) {
        t4 = ({
            "ThemeMixer[handleSave]": ()=>{
                onSave(palette);
            }
        })["ThemeMixer[handleSave]"];
        $[5] = onSave;
        $[6] = palette;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    const handleSave = t4;
    let t5;
    if ($[8] !== palette.primaryMain) {
        t5 = ({
            "ThemeMixer[handleHarmony]": (harmony)=>{
                const [baseHue] = hexToHsl(palette.primaryMain);
                setPalette(generateHarmonyPalette(baseHue, harmony));
            }
        })["ThemeMixer[handleHarmony]"];
        $[8] = palette.primaryMain;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    const handleHarmony = t5;
    let t6;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "ThemeMixer[handleWheelChange]": (field_0, hex)=>{
                setPalette({
                    "ThemeMixer[handleWheelChange > setPalette()]": (prev_0)=>({
                            ...prev_0,
                            [field_0]: hex
                        })
                }["ThemeMixer[handleWheelChange > setPalette()]"]);
            }
        })["ThemeMixer[handleWheelChange]"];
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    const handleWheelChange = t6;
    let t7;
    if ($[11] !== palette) {
        t7 = buildFullPaletteFromCustom(palette);
        $[11] = palette;
        $[12] = t7;
    } else {
        t7 = $[12];
    }
    const preview = t7;
    let t8;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle2",
            gutterBottom: true,
            children: "Mix Your Own Theme"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 351,
            columnNumber: 10
        }, this);
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: {
                mb: 2
            },
            children: "Pick your colors below. A dark mode variant is automatically generated."
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 358,
            columnNumber: 10
        }, this);
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== palette) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorWheel, {
            palette: palette,
            onChange: handleWheelChange
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 367,
            columnNumber: 11
        }, this);
        $[15] = palette;
        $[16] = t10;
    } else {
        t10 = $[16];
    }
    let t11;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            sx: {
                mb: 0.5,
                display: "block"
            },
            children: "Color Harmonies"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 375,
            columnNumber: 11
        }, this);
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = Object.keys(HARMONY_LABELS);
        $[18] = t12;
    } else {
        t12 = $[18];
    }
    let t13;
    if ($[19] !== handleHarmony) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t11,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ButtonGroup$2f$ButtonGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    size: "small",
                    variant: "outlined",
                    children: t12.map({
                        "ThemeMixer[(anonymous)()]": (h)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                onClick: {
                                    "ThemeMixer[(anonymous)() > <Button>.onClick]": ()=>handleHarmony(h)
                                }["ThemeMixer[(anonymous)() > <Button>.onClick]"],
                                children: HARMONY_LABELS[h]
                            }, h, false, {
                                fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
                                lineNumber: 393,
                                columnNumber: 45
                            }, this)
                    }["ThemeMixer[(anonymous)()]"])
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
                    lineNumber: 392,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 392,
            columnNumber: 11
        }, this);
        $[19] = handleHarmony;
        $[20] = t13;
    } else {
        t13 = $[20];
    }
    let t14;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 404,
            columnNumber: 11
        }, this);
        $[21] = t14;
    } else {
        t14 = $[21];
    }
    let t15;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = ({
            "ThemeMixer[<ColorInput>.onChange]": (v)=>handleChange("primaryMain", v)
        })["ThemeMixer[<ColorInput>.onChange]"];
        $[22] = t15;
    } else {
        t15 = $[22];
    }
    let t16;
    if ($[23] !== palette.primaryMain) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorInput, {
            label: "Primary",
            value: palette.primaryMain,
            onChange: t15
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 420,
            columnNumber: 11
        }, this);
        $[23] = palette.primaryMain;
        $[24] = t16;
    } else {
        t16 = $[24];
    }
    let t17;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = ({
            "ThemeMixer[<ColorInput>.onChange]": (v_0)=>handleChange("secondaryMain", v_0)
        })["ThemeMixer[<ColorInput>.onChange]"];
        $[25] = t17;
    } else {
        t17 = $[25];
    }
    let t18;
    if ($[26] !== palette.secondaryMain) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorInput, {
            label: "Secondary",
            value: palette.secondaryMain,
            onChange: t17
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 437,
            columnNumber: 11
        }, this);
        $[26] = palette.secondaryMain;
        $[27] = t18;
    } else {
        t18 = $[27];
    }
    let t19;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = ({
            "ThemeMixer[<ColorInput>.onChange]": (v_1)=>handleChange("backgroundDefault", v_1)
        })["ThemeMixer[<ColorInput>.onChange]"];
        $[28] = t19;
    } else {
        t19 = $[28];
    }
    let t20;
    if ($[29] !== palette.backgroundDefault) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorInput, {
            label: "Background",
            value: palette.backgroundDefault,
            onChange: t19
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 454,
            columnNumber: 11
        }, this);
        $[29] = palette.backgroundDefault;
        $[30] = t20;
    } else {
        t20 = $[30];
    }
    let t21;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = ({
            "ThemeMixer[<ColorInput>.onChange]": (v_2)=>handleChange("backgroundPaper", v_2)
        })["ThemeMixer[<ColorInput>.onChange]"];
        $[31] = t21;
    } else {
        t21 = $[31];
    }
    let t22;
    if ($[32] !== palette.backgroundPaper) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorInput, {
            label: "Paper",
            value: palette.backgroundPaper,
            onChange: t21
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 471,
            columnNumber: 11
        }, this);
        $[32] = palette.backgroundPaper;
        $[33] = t22;
    } else {
        t22 = $[33];
    }
    let t23;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = ({
            "ThemeMixer[<ColorInput>.onChange]": (v_3)=>handleChange("accentColor", v_3)
        })["ThemeMixer[<ColorInput>.onChange]"];
        $[34] = t23;
    } else {
        t23 = $[34];
    }
    let t24;
    if ($[35] !== palette.accentColor) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorInput, {
            label: "Accent",
            value: palette.accentColor,
            onChange: t23
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 488,
            columnNumber: 11
        }, this);
        $[35] = palette.accentColor;
        $[36] = t24;
    } else {
        t24 = $[36];
    }
    let t25;
    if ($[37] !== t16 || $[38] !== t18 || $[39] !== t20 || $[40] !== t22 || $[41] !== t24) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            flexWrap: "wrap",
            gap: 2,
            children: [
                t16,
                t18,
                t20,
                t22,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 496,
            columnNumber: 11
        }, this);
        $[37] = t16;
        $[38] = t18;
        $[39] = t20;
        $[40] = t22;
        $[41] = t24;
        $[42] = t25;
    } else {
        t25 = $[42];
    }
    let t26;
    let t27;
    if ($[43] === Symbol.for("react.memo_cache_sentinel")) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 509,
            columnNumber: 11
        }, this);
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            children: "Preview"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 510,
            columnNumber: 11
        }, this);
        $[43] = t26;
        $[44] = t27;
    } else {
        t26 = $[43];
        t27 = $[44];
    }
    let t28;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = {
            width: 140,
            overflow: "hidden"
        };
        $[45] = t28;
    } else {
        t28 = $[45];
    }
    let t29;
    if ($[46] !== preview.light.primary.main) {
        t29 = {
            height: 24,
            bgcolor: preview.light.primary.main,
            display: "flex",
            alignItems: "center",
            px: 1
        };
        $[46] = preview.light.primary.main;
        $[47] = t29;
    } else {
        t29 = $[47];
    }
    let t30;
    if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            sx: {
                color: "#fff",
                fontSize: "0.65rem"
            },
            children: "Light"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 543,
            columnNumber: 11
        }, this);
        $[48] = t30;
    } else {
        t30 = $[48];
    }
    let t31;
    if ($[49] !== t29) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t29,
            children: t30
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 553,
            columnNumber: 11
        }, this);
        $[49] = t29;
        $[50] = t31;
    } else {
        t31 = $[50];
    }
    let t32;
    if ($[51] !== preview.light.background.default) {
        t32 = {
            p: 1,
            bgcolor: preview.light.background.default
        };
        $[51] = preview.light.background.default;
        $[52] = t32;
    } else {
        t32 = $[52];
    }
    let t33;
    if ($[53] !== preview.light.secondary.main) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                height: 8,
                bgcolor: preview.light.secondary.main,
                borderRadius: 1,
                mb: 0.5
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 572,
            columnNumber: 11
        }, this);
        $[53] = preview.light.secondary.main;
        $[54] = t33;
    } else {
        t33 = $[54];
    }
    let t34;
    if ($[55] !== preview.light.custom.subtleBorder) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                height: 4,
                bgcolor: preview.light.custom.subtleBorder,
                borderRadius: 1,
                mb: 0.5
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 585,
            columnNumber: 11
        }, this);
        $[55] = preview.light.custom.subtleBorder;
        $[56] = t34;
    } else {
        t34 = $[56];
    }
    const t35 = `1px solid ${preview.light.custom.subtleBorder}`;
    let t36;
    if ($[57] !== preview.light.background.paper || $[58] !== t35) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                height: 12,
                bgcolor: preview.light.background.paper,
                borderRadius: 0.5,
                border: t35
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 599,
            columnNumber: 11
        }, this);
        $[57] = preview.light.background.paper;
        $[58] = t35;
        $[59] = t36;
    } else {
        t36 = $[59];
    }
    let t37;
    if ($[60] !== t32 || $[61] !== t33 || $[62] !== t34 || $[63] !== t36) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t32,
            children: [
                t33,
                t34,
                t36
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 613,
            columnNumber: 11
        }, this);
        $[60] = t32;
        $[61] = t33;
        $[62] = t34;
        $[63] = t36;
        $[64] = t37;
    } else {
        t37 = $[64];
    }
    let t38;
    if ($[65] !== t31 || $[66] !== t37) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "outlined",
            sx: t28,
            children: [
                t31,
                t37
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 624,
            columnNumber: 11
        }, this);
        $[65] = t31;
        $[66] = t37;
        $[67] = t38;
    } else {
        t38 = $[67];
    }
    let t39;
    if ($[68] === Symbol.for("react.memo_cache_sentinel")) {
        t39 = {
            width: 140,
            overflow: "hidden"
        };
        $[68] = t39;
    } else {
        t39 = $[68];
    }
    let t40;
    if ($[69] !== preview.dark.primary.main) {
        t40 = {
            height: 24,
            bgcolor: preview.dark.primary.main,
            display: "flex",
            alignItems: "center",
            px: 1
        };
        $[69] = preview.dark.primary.main;
        $[70] = t40;
    } else {
        t40 = $[70];
    }
    let t41;
    if ($[71] === Symbol.for("react.memo_cache_sentinel")) {
        t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            sx: {
                color: "#fff",
                fontSize: "0.65rem"
            },
            children: "Dark"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 657,
            columnNumber: 11
        }, this);
        $[71] = t41;
    } else {
        t41 = $[71];
    }
    let t42;
    if ($[72] !== t40) {
        t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t40,
            children: t41
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 667,
            columnNumber: 11
        }, this);
        $[72] = t40;
        $[73] = t42;
    } else {
        t42 = $[73];
    }
    let t43;
    if ($[74] !== preview.dark.background.default) {
        t43 = {
            p: 1,
            bgcolor: preview.dark.background.default
        };
        $[74] = preview.dark.background.default;
        $[75] = t43;
    } else {
        t43 = $[75];
    }
    let t44;
    if ($[76] !== preview.dark.secondary.main) {
        t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                height: 8,
                bgcolor: preview.dark.secondary.main,
                borderRadius: 1,
                mb: 0.5
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 686,
            columnNumber: 11
        }, this);
        $[76] = preview.dark.secondary.main;
        $[77] = t44;
    } else {
        t44 = $[77];
    }
    let t45;
    if ($[78] !== preview.dark.custom.subtleBorder) {
        t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                height: 4,
                bgcolor: preview.dark.custom.subtleBorder,
                borderRadius: 1,
                mb: 0.5
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 699,
            columnNumber: 11
        }, this);
        $[78] = preview.dark.custom.subtleBorder;
        $[79] = t45;
    } else {
        t45 = $[79];
    }
    const t46 = `1px solid ${preview.dark.custom.subtleBorder}`;
    let t47;
    if ($[80] !== preview.dark.background.paper || $[81] !== t46) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                height: 12,
                bgcolor: preview.dark.background.paper,
                borderRadius: 0.5,
                border: t46
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 713,
            columnNumber: 11
        }, this);
        $[80] = preview.dark.background.paper;
        $[81] = t46;
        $[82] = t47;
    } else {
        t47 = $[82];
    }
    let t48;
    if ($[83] !== t43 || $[84] !== t44 || $[85] !== t45 || $[86] !== t47) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t43,
            children: [
                t44,
                t45,
                t47
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 727,
            columnNumber: 11
        }, this);
        $[83] = t43;
        $[84] = t44;
        $[85] = t45;
        $[86] = t47;
        $[87] = t48;
    } else {
        t48 = $[87];
    }
    let t49;
    if ($[88] !== t42 || $[89] !== t48) {
        t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "outlined",
            sx: t39,
            children: [
                t42,
                t48
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 738,
            columnNumber: 11
        }, this);
        $[88] = t42;
        $[89] = t48;
        $[90] = t49;
    } else {
        t49 = $[90];
    }
    let t50;
    if ($[91] !== t38 || $[92] !== t49) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            gap: 1.5,
            children: [
                t38,
                t49
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 747,
            columnNumber: 11
        }, this);
        $[91] = t38;
        $[92] = t49;
        $[93] = t50;
    } else {
        t50 = $[93];
    }
    let t51;
    if ($[94] === Symbol.for("react.memo_cache_sentinel")) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 756,
            columnNumber: 11
        }, this);
        $[94] = t51;
    } else {
        t51 = $[94];
    }
    let t52;
    if ($[95] !== handleSave) {
        t52 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "contained",
            size: "small",
            startIcon: t51,
            onClick: handleSave,
            children: "Save Custom Theme"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 763,
            columnNumber: 11
        }, this);
        $[95] = handleSave;
        $[96] = t52;
    } else {
        t52 = $[96];
    }
    let t53;
    if ($[97] === Symbol.for("react.memo_cache_sentinel")) {
        t53 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "outlined",
            size: "small",
            startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Restore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
                lineNumber: 771,
                columnNumber: 62
            }, this),
            onClick: handleReset,
            children: "Reset"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 771,
            columnNumber: 11
        }, this);
        $[97] = t53;
    } else {
        t53 = $[97];
    }
    let t54;
    if ($[98] !== t52) {
        t54 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            gap: 1,
            children: [
                t52,
                t53
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 778,
            columnNumber: 11
        }, this);
        $[98] = t52;
        $[99] = t54;
    } else {
        t54 = $[99];
    }
    let t55;
    if ($[100] !== t10 || $[101] !== t13 || $[102] !== t25 || $[103] !== t50 || $[104] !== t54) {
        t55 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t8,
                t9,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    spacing: 2,
                    children: [
                        t10,
                        t13,
                        t14,
                        t25,
                        t26,
                        t27,
                        t50,
                        t54
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
                    lineNumber: 786,
                    columnNumber: 24
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 786,
            columnNumber: 11
        }, this);
        $[100] = t10;
        $[101] = t13;
        $[102] = t25;
        $[103] = t50;
        $[104] = t54;
        $[105] = t55;
    } else {
        t55 = $[105];
    }
    return t55;
}
_s(ThemeMixer, "Kp0zXmFHvjIQ3LCw0BwsBYwhvLk=");
_c = ThemeMixer;
// ============================================================================
// Color Wheel — interactive HSL wheel with draggable sample points
// ============================================================================
const WHEEL_SIZE = 220;
const WHEEL_RADIUS = WHEEL_SIZE / 2;
const POINT_RADIUS = 10;
const POINT_FIELDS = [
    {
        field: 'primaryMain',
        label: 'P'
    },
    {
        field: 'secondaryMain',
        label: 'S'
    },
    {
        field: 'backgroundDefault',
        label: 'B'
    },
    {
        field: 'backgroundPaper',
        label: 'W'
    },
    {
        field: 'accentColor',
        label: 'A'
    }
];
function ColorWheel(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "6b1a4a2ecb25c919621f7ee7dd3d85377cf10f6309875f26560cba7cac545b1a") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6b1a4a2ecb25c919621f7ee7dd3d85377cf10f6309875f26560cba7cac545b1a";
    }
    const { palette, onChange } = t0;
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const draggingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "ColorWheel[useEffect()]": ()=>{
                const canvas = canvasRef.current;
                if (!canvas) {
                    return;
                }
                const ctx = canvas.getContext("2d");
                if (!ctx) {
                    return;
                }
                ctx.clearRect(0, 0, WHEEL_SIZE, WHEEL_SIZE);
                for(let angle = 0; angle < 360; angle++){
                    const startAngle = (angle - 1) * (Math.PI / 180);
                    const endAngle = (angle + 1) * (Math.PI / 180);
                    const gradient = ctx.createRadialGradient(WHEEL_RADIUS, WHEEL_RADIUS, 0, WHEEL_RADIUS, WHEEL_RADIUS, WHEEL_RADIUS);
                    gradient.addColorStop(0, `hsl(${angle}, 0%, 100%)`);
                    gradient.addColorStop(0.5, `hsl(${angle}, 50%, 70%)`);
                    gradient.addColorStop(1, `hsl(${angle}, 100%, 50%)`);
                    ctx.beginPath();
                    ctx.moveTo(WHEEL_RADIUS, WHEEL_RADIUS);
                    ctx.arc(WHEEL_RADIUS, WHEEL_RADIUS, WHEEL_RADIUS - 2, startAngle, endAngle);
                    ctx.closePath();
                    ctx.fillStyle = gradient;
                    ctx.fill();
                }
                const vignette = ctx.createRadialGradient(WHEEL_RADIUS, WHEEL_RADIUS, WHEEL_RADIUS * 0.7, WHEEL_RADIUS, WHEEL_RADIUS, WHEEL_RADIUS);
                vignette.addColorStop(0, "rgba(0,0,0,0)");
                vignette.addColorStop(1, "rgba(0,0,0,0.15)");
                ctx.fillStyle = vignette;
                ctx.fillRect(0, 0, WHEEL_SIZE, WHEEL_SIZE);
            }
        })["ColorWheel[useEffect()]"];
        t2 = [];
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    const hexToPosition = _ColorWheelHexToPosition;
    const positionToHex = _ColorWheelPositionToHex;
    let t3;
    if ($[3] !== palette) {
        t3 = ({
            "ColorWheel[handlePointerDown]": (e)=>{
                const rect = containerRef.current?.getBoundingClientRect();
                if (!rect) {
                    return;
                }
                const x_0 = e.clientX - rect.left;
                const y_0 = e.clientY - rect.top;
                for (const { field } of POINT_FIELDS){
                    const pos = hexToPosition(palette[field]);
                    const dx_0 = x_0 - pos.x;
                    const dy_0 = y_0 - pos.y;
                    if (dx_0 * dx_0 + dy_0 * dy_0 <= (POINT_RADIUS + 4) * (POINT_RADIUS + 4)) {
                        draggingRef.current = field;
                        e.target.setPointerCapture(e.pointerId);
                        return;
                    }
                }
            }
        })["ColorWheel[handlePointerDown]"];
        $[3] = palette;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const handlePointerDown = t3;
    let t4;
    if ($[5] !== onChange || $[6] !== palette) {
        t4 = ({
            "ColorWheel[handlePointerMove]": (e_0)=>{
                if (!draggingRef.current) {
                    return;
                }
                const rect_0 = containerRef.current?.getBoundingClientRect();
                if (!rect_0) {
                    return;
                }
                const x_1 = Math.max(0, Math.min(WHEEL_SIZE, e_0.clientX - rect_0.left));
                const y_1 = Math.max(0, Math.min(WHEEL_SIZE, e_0.clientY - rect_0.top));
                const field_0 = draggingRef.current;
                const hex_0 = positionToHex(x_1, y_1, palette[field_0]);
                onChange(field_0, hex_0);
            }
        })["ColorWheel[handlePointerMove]"];
        $[5] = onChange;
        $[6] = palette;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    const handlePointerMove = t4;
    let t5;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "ColorWheel[handlePointerUp]": ()=>{
                draggingRef.current = null;
            }
        })["ColorWheel[handlePointerUp]"];
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    const handlePointerUp = t5;
    let t6;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            position: "relative",
            width: WHEEL_SIZE,
            height: WHEEL_SIZE,
            alignSelf: "center",
            cursor: "crosshair",
            touchAction: "none",
            userSelect: "none"
        };
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
            ref: canvasRef,
            width: WHEEL_SIZE,
            height: WHEEL_SIZE,
            style: {
                borderRadius: "50%",
                display: "block"
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 973,
            columnNumber: 10
        }, this);
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    let t8;
    if ($[11] !== palette) {
        t8 = POINT_FIELDS.map({
            "ColorWheel[POINT_FIELDS.map()]": (t9)=>{
                const { field: field_1, label } = t9;
                const pos_0 = hexToPosition(palette[field_1]);
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        position: "absolute",
                        left: pos_0.x - POINT_RADIUS,
                        top: pos_0.y - POINT_RADIUS,
                        width: POINT_RADIUS * 2,
                        height: POINT_RADIUS * 2,
                        borderRadius: "50%",
                        bgcolor: palette[field_1],
                        border: "2px solid #fff",
                        boxShadow: "0 1px 4px rgba(0,0,0,0.4)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        pointerEvents: "none"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: "0.55rem",
                            fontWeight: 700,
                            color: "#fff",
                            textShadow: "0 0 2px rgba(0,0,0,0.7)",
                            lineHeight: 1
                        },
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
                        lineNumber: 1004,
                        columnNumber: 12
                    }, this)
                }, field_1, false, {
                    fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
                    lineNumber: 990,
                    columnNumber: 16
                }, this);
            }
        }["ColorWheel[POINT_FIELDS.map()]"]);
        $[11] = palette;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] !== handlePointerDown || $[14] !== handlePointerMove || $[15] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ref: containerRef,
            sx: t6,
            onPointerDown: handlePointerDown,
            onPointerMove: handlePointerMove,
            onPointerUp: handlePointerUp,
            onPointerCancel: handlePointerUp,
            children: [
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 1020,
            columnNumber: 10
        }, this);
        $[13] = handlePointerDown;
        $[14] = handlePointerMove;
        $[15] = t8;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    return t9;
}
_s1(ColorWheel, "DvKZptGTSBeivQXhAzEkTDd9x1M=");
_c1 = ColorWheel;
// ============================================================================
// Color Input — native color picker + hex text field
// ============================================================================
function _ColorWheelPositionToHex(x, y, currentHex) {
    const dx = x - WHEEL_RADIUS;
    const dy = y - WHEEL_RADIUS;
    const dist_0 = Math.min(Math.sqrt(dx * dx + dy * dy), WHEEL_RADIUS - 4);
    const angle_0 = (Math.atan2(dy, dx) * 180 / Math.PI + 90 + 360) % 360;
    const saturation = dist_0 / (WHEEL_RADIUS - 4);
    const [, , l_0] = hexToHsl(currentHex);
    return hslToHex(angle_0, saturation, l_0);
}
function _ColorWheelHexToPosition(hex) {
    const [h, s] = hexToHsl(hex);
    const dist = s * (WHEEL_RADIUS - POINT_RADIUS - 4);
    const angleRad = (h - 90) * (Math.PI / 180);
    return {
        x: WHEEL_RADIUS + dist * Math.cos(angleRad),
        y: WHEEL_RADIUS + dist * Math.sin(angleRad)
    };
}
function ColorInput(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "6b1a4a2ecb25c919621f7ee7dd3d85377cf10f6309875f26560cba7cac545b1a") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6b1a4a2ecb25c919621f7ee7dd3d85377cf10f6309875f26560cba7cac545b1a";
    }
    const { label, value, onChange } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            display: "flex",
            alignItems: "center",
            gap: 1
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== onChange) {
        t2 = ({
            "ColorInput[<Box>.onChange]": (e)=>onChange(e.target.value)
        })["ColorInput[<Box>.onChange]"];
        $[2] = onChange;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            width: 32,
            height: 32,
            border: "1px solid",
            borderColor: "divider",
            borderRadius: 1,
            cursor: "pointer",
            p: 0,
            "&::-webkit-color-swatch-wrapper": {
                padding: 0
            },
            "&::-webkit-color-swatch": {
                border: "none",
                borderRadius: 4
            }
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== t2 || $[6] !== value) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            component: "input",
            type: "color",
            value: value,
            onChange: t2,
            sx: t3
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 1110,
            columnNumber: 10
        }, this);
        $[5] = t2;
        $[6] = value;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] !== label || $[9] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: label,
            children: t4
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 1119,
            columnNumber: 10
        }, this);
        $[8] = label;
        $[9] = t4;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    let t6;
    if ($[11] !== onChange) {
        t6 = ({
            "ColorInput[<TextField>.onChange]": (e_0)=>{
                const v = e_0.target.value;
                if (/^#[0-9a-fA-F]{0,6}$/.test(v)) {
                    onChange(v);
                }
            }
        })["ColorInput[<TextField>.onChange]"];
        $[11] = onChange;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    let t7;
    let t8;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            width: 110
        };
        t8 = {
            style: {
                fontFamily: "monospace",
                fontSize: "0.8rem"
            }
        };
        $[13] = t7;
        $[14] = t8;
    } else {
        t7 = $[13];
        t8 = $[14];
    }
    let t9;
    if ($[15] !== label || $[16] !== t6 || $[17] !== value) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            label: label,
            value: value,
            onChange: t6,
            sx: t7,
            inputProps: t8
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 1161,
            columnNumber: 10
        }, this);
        $[15] = label;
        $[16] = t6;
        $[17] = value;
        $[18] = t9;
    } else {
        t9 = $[18];
    }
    let t10;
    if ($[19] !== t5 || $[20] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t1,
            children: [
                t5,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ThemeMixer.tsx",
            lineNumber: 1171,
            columnNumber: 11
        }, this);
        $[19] = t5;
        $[20] = t9;
        $[21] = t10;
    } else {
        t10 = $[21];
    }
    return t10;
}
_c2 = ColorInput;
const __TURBOPACK__default__export__ = ThemeMixer;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ThemeMixer");
__turbopack_context__.k.register(_c1, "ColorWheel");
__turbopack_context__.k.register(_c2, "ColorInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/EasterEggTrigger.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HiddenEasterEgg",
    ()=>HiddenEasterEgg,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useEasterEggKeyword",
    ()=>useEasterEggKeyword,
    "useEasterEggRapidClick",
    ()=>useEasterEggRapidClick,
    "useEasterEggTime",
    ()=>useEasterEggTime,
    "useEasterEggTrigger",
    ()=>useEasterEggTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * EasterEggTrigger — Client-side detection hooks and components for Easter eggs.
 *
 * Trigger types supported:
 * - Hidden clickable element (tiny icon placed in course map)
 * - Keyword typed in a text field (Konami-style sequences)
 * - Time-based (active during specific time windows)
 * - UI interaction patterns (e.g. rapid-click, long-press)
 *
 * When triggered, fires a callback (typically a GraphQL mutation to award XP).
 *
 * @module EasterEggTrigger
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Search.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
;
;
;
;
;
function useEasterEggKeyword(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "540721967b99070f49709cc6729abcf45e122f838b5f5153fa2ef8894d562dd5") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "540721967b99070f49709cc6729abcf45e122f838b5f5153fa2ef8894d562dd5";
    }
    const { keyword, onTrigger, disabled } = t0;
    const bufferRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])("");
    let t1;
    let t2;
    if ($[1] !== disabled || $[2] !== keyword || $[3] !== onTrigger) {
        t1 = ({
            "useEasterEggKeyword[useEffect()]": ()=>{
                if (disabled || !keyword) {
                    return;
                }
                const handler = {
                    "useEasterEggKeyword[useEffect() > handler]": (e)=>{
                        if (e.key.length !== 1) {
                            return;
                        }
                        bufferRef.current = bufferRef.current + e.key.toLowerCase();
                        if (bufferRef.current.length > keyword.length * 2) {
                            bufferRef.current = bufferRef.current.slice(-keyword.length);
                        }
                        if (bufferRef.current.endsWith(keyword.toLowerCase())) {
                            bufferRef.current = "";
                            onTrigger();
                        }
                    }
                }["useEasterEggKeyword[useEffect() > handler]"];
                window.addEventListener("keypress", handler);
                return ()=>window.removeEventListener("keypress", handler);
            }
        })["useEasterEggKeyword[useEffect()]"];
        t2 = [
            keyword,
            onTrigger,
            disabled
        ];
        $[1] = disabled;
        $[2] = keyword;
        $[3] = onTrigger;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
}
_s(useEasterEggKeyword, "+gQpFV/pn6pIfviIv1QScdXxacs=");
function useEasterEggTime(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "540721967b99070f49709cc6729abcf45e122f838b5f5153fa2ef8894d562dd5") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "540721967b99070f49709cc6729abcf45e122f838b5f5153fa2ef8894d562dd5";
    }
    const { activeAfter, activeUntil, onTrigger, disabled } = t0;
    const triggeredRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    let t1;
    let t2;
    if ($[1] !== activeAfter || $[2] !== activeUntil || $[3] !== disabled || $[4] !== onTrigger) {
        t1 = ({
            "useEasterEggTime[useEffect()]": ()=>{
                if (disabled || triggeredRef.current) {
                    return;
                }
                const check = {
                    "useEasterEggTime[useEffect() > check]": ()=>{
                        const now = Date.now();
                        const after = activeAfter ? new Date(activeAfter).getTime() : 0;
                        const until = activeUntil ? new Date(activeUntil).getTime() : Infinity;
                        if (now >= after && now <= until && !triggeredRef.current) {
                            triggeredRef.current = true;
                            onTrigger();
                        }
                    }
                }["useEasterEggTime[useEffect() > check]"];
                check();
                const interval = setInterval(check, 30000);
                return ()=>clearInterval(interval);
            }
        })["useEasterEggTime[useEffect()]"];
        t2 = [
            activeAfter,
            activeUntil,
            onTrigger,
            disabled
        ];
        $[1] = activeAfter;
        $[2] = activeUntil;
        $[3] = disabled;
        $[4] = onTrigger;
        $[5] = t1;
        $[6] = t2;
    } else {
        t1 = $[5];
        t2 = $[6];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
}
_s1(useEasterEggTime, "f/Lkp18BtKWF9VmKzM09OfkL6cs=");
function useEasterEggRapidClick(t0) {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "540721967b99070f49709cc6729abcf45e122f838b5f5153fa2ef8894d562dd5") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "540721967b99070f49709cc6729abcf45e122f838b5f5153fa2ef8894d562dd5";
    }
    const { clickCount: t1, clickWindow: t2, onTrigger, disabled } = t0;
    const clickCount = t1 === undefined ? 5 : t1;
    const clickWindow = t2 === undefined ? 2000 : t2;
    let t3;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [];
        $[1] = t3;
    } else {
        t3 = $[1];
    }
    const clicksRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(t3);
    let t4;
    if ($[2] !== clickCount || $[3] !== clickWindow || $[4] !== disabled || $[5] !== onTrigger) {
        t4 = ({
            "useEasterEggRapidClick[handleClick]": ()=>{
                if (disabled) {
                    return;
                }
                const now = Date.now();
                clicksRef.current.push(now);
                clicksRef.current = clicksRef.current.filter({
                    "useEasterEggRapidClick[handleClick > clicksRef.current.filter()]": (t)=>now - t < clickWindow
                }["useEasterEggRapidClick[handleClick > clicksRef.current.filter()]"]);
                if (clicksRef.current.length >= clickCount) {
                    clicksRef.current = [];
                    onTrigger();
                }
            }
        })["useEasterEggRapidClick[handleClick]"];
        $[2] = clickCount;
        $[3] = clickWindow;
        $[4] = disabled;
        $[5] = onTrigger;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const handleClick = t4;
    let t5;
    if ($[7] !== handleClick) {
        t5 = {
            handleClick
        };
        $[7] = handleClick;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    return t5;
}
_s2(useEasterEggRapidClick, "d6bln6H6JULcpVIMwSN7bWRo0eQ=");
function HiddenEasterEgg(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "540721967b99070f49709cc6729abcf45e122f838b5f5153fa2ef8894d562dd5") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "540721967b99070f49709cc6729abcf45e122f838b5f5153fa2ef8894d562dd5";
    }
    const { sx, onFind, found: t1, ariaLabel: t2 } = t0;
    const found = t1 === undefined ? false : t1;
    const ariaLabel = t2 === undefined ? "Hidden element" : t2;
    if (found) {
        return null;
    }
    let t3;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            opacity: 0.15
        };
        $[1] = t3;
    } else {
        t3 = $[1];
    }
    let t4;
    if ($[2] !== sx) {
        t4 = {
            position: "absolute",
            opacity: 0.05,
            width: 16,
            height: 16,
            cursor: "default",
            "&:hover": t3,
            transition: "opacity 0.3s",
            ...sx
        };
        $[2] = sx;
        $[3] = t4;
    } else {
        t4 = $[3];
    }
    let t5;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            width: 16,
            height: 16,
            p: 0
        };
        $[4] = t5;
    } else {
        t5 = $[4];
    }
    let t6;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: 12
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/EasterEggTrigger.tsx",
            lineNumber: 323,
            columnNumber: 10
        }, this);
        $[5] = t6;
    } else {
        t6 = $[5];
    }
    let t7;
    if ($[6] !== ariaLabel || $[7] !== onFind) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            onClick: onFind,
            "aria-label": ariaLabel,
            sx: t5,
            children: t6
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/EasterEggTrigger.tsx",
            lineNumber: 332,
            columnNumber: 10
        }, this);
        $[6] = ariaLabel;
        $[7] = onFind;
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] !== t4 || $[10] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t4,
            children: t7
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/EasterEggTrigger.tsx",
            lineNumber: 341,
            columnNumber: 10
        }, this);
        $[9] = t4;
        $[10] = t7;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    return t8;
}
_c = HiddenEasterEgg;
function useEasterEggTrigger(t0) {
    _s3();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(28);
    if ($[0] !== "540721967b99070f49709cc6729abcf45e122f838b5f5153fa2ef8894d562dd5") {
        for(let $i = 0; $i < 28; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "540721967b99070f49709cc6729abcf45e122f838b5f5153fa2ef8894d562dd5";
    }
    const { config, foundEggs, onTrigger } = t0;
    let t1;
    if ($[1] !== config.id || $[2] !== foundEggs) {
        t1 = foundEggs?.has(config.id) ?? false;
        $[1] = config.id;
        $[2] = foundEggs;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const disabled = t1;
    let t2;
    if ($[4] !== config.id || $[5] !== config.message || $[6] !== config.xpReward || $[7] !== disabled || $[8] !== onTrigger) {
        t2 = ({
            "useEasterEggTrigger[handleTrigger]": ()=>{
                if (disabled) {
                    return;
                }
                onTrigger({
                    eggId: config.id,
                    message: config.message,
                    xpReward: config.xpReward
                });
            }
        })["useEasterEggTrigger[handleTrigger]"];
        $[4] = config.id;
        $[5] = config.message;
        $[6] = config.xpReward;
        $[7] = disabled;
        $[8] = onTrigger;
        $[9] = t2;
    } else {
        t2 = $[9];
    }
    const handleTrigger = t2;
    const t3 = config.keyword || "";
    const t4 = disabled || config.type !== "KEYWORD";
    let t5;
    if ($[10] !== handleTrigger || $[11] !== t3 || $[12] !== t4) {
        t5 = {
            keyword: t3,
            onTrigger: handleTrigger,
            disabled: t4
        };
        $[10] = handleTrigger;
        $[11] = t3;
        $[12] = t4;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    useEasterEggKeyword(t5);
    const t6 = disabled || config.type !== "TIME";
    let t7;
    if ($[14] !== config.activeAfter || $[15] !== config.activeUntil || $[16] !== handleTrigger || $[17] !== t6) {
        t7 = {
            activeAfter: config.activeAfter,
            activeUntil: config.activeUntil,
            onTrigger: handleTrigger,
            disabled: t6
        };
        $[14] = config.activeAfter;
        $[15] = config.activeUntil;
        $[16] = handleTrigger;
        $[17] = t6;
        $[18] = t7;
    } else {
        t7 = $[18];
    }
    useEasterEggTime(t7);
    const t8 = disabled || config.type !== "INTERACTION";
    let t9;
    if ($[19] !== config.clickCount || $[20] !== config.clickWindow || $[21] !== handleTrigger || $[22] !== t8) {
        t9 = {
            clickCount: config.clickCount,
            clickWindow: config.clickWindow,
            onTrigger: handleTrigger,
            disabled: t8
        };
        $[19] = config.clickCount;
        $[20] = config.clickWindow;
        $[21] = handleTrigger;
        $[22] = t8;
        $[23] = t9;
    } else {
        t9 = $[23];
    }
    const { handleClick } = useEasterEggRapidClick(t9);
    let t10;
    if ($[24] !== disabled || $[25] !== handleClick || $[26] !== handleTrigger) {
        t10 = {
            handleClick,
            handleFind: handleTrigger,
            isFound: disabled
        };
        $[24] = disabled;
        $[25] = handleClick;
        $[26] = handleTrigger;
        $[27] = t10;
    } else {
        t10 = $[27];
    }
    return t10;
}
_s3(useEasterEggTrigger, "cPPc2LjCGZrDmCqmQVZYwGJlmkU=", false, function() {
    return [
        useEasterEggKeyword,
        useEasterEggTime,
        useEasterEggRapidClick
    ];
});
const __TURBOPACK__default__export__ = HiddenEasterEgg;
var _c;
__turbopack_context__.k.register(_c, "HiddenEasterEgg");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/EasterEggToast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EasterEggToast",
    ()=>EasterEggToast,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Snackbar/Snackbar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Search.js [app-client] (ecmascript)");
;
;
;
;
;
function EasterEggToast(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "95f40b1867318862706ac568ed608072d12498d8cd52ac3a52472af430ad802f") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "95f40b1867318862706ac568ed608072d12498d8cd52ac3a52472af430ad802f";
    }
    const { open, message, xpReward, onClose, autoHideDuration: t1 } = t0;
    const autoHideDuration = t1 === undefined ? 4000 : t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            vertical: "top",
            horizontal: "center"
        };
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    let t3;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/EasterEggToast.tsx",
            lineNumber: 47,
            columnNumber: 10
        }, this);
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    let t4;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            fontWeight: 600,
            border: "1px solid",
            borderColor: "info.main"
        };
        $[3] = t4;
    } else {
        t4 = $[3];
    }
    let t5;
    if ($[4] !== message || $[5] !== onClose || $[6] !== xpReward) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            severity: "info",
            icon: t3,
            onClose: onClose,
            sx: t4,
            children: [
                "🔍 Secret Unlocked! ",
                message,
                " (+",
                xpReward,
                " XP)"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/EasterEggToast.tsx",
            lineNumber: 65,
            columnNumber: 10
        }, this);
        $[4] = message;
        $[5] = onClose;
        $[6] = xpReward;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] !== autoHideDuration || $[9] !== onClose || $[10] !== open || $[11] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Snackbar$2f$Snackbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            autoHideDuration: autoHideDuration,
            anchorOrigin: t2,
            onClose: onClose,
            children: t5
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/EasterEggToast.tsx",
            lineNumber: 75,
            columnNumber: 10
        }, this);
        $[8] = autoHideDuration;
        $[9] = onClose;
        $[10] = open;
        $[11] = t5;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    return t6;
}
_c = EasterEggToast;
const __TURBOPACK__default__export__ = EasterEggToast;
var _c;
__turbopack_context__.k.register(_c, "EasterEggToast");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/EasterEggLayer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EasterEggLayer",
    ()=>EasterEggLayer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/EasterEggTrigger.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/EasterEggToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/amplifyClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/apis/fetchAuthSession.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
function getClient() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$amplifyClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyClient"])();
}
function EasterEggLayer({ studentId: studentIdProp }) {
    _s();
    const [toast, setToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        open: false,
        message: '',
        xpReward: 0
    });
    const [keywordEggs, setKeywordEggs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [scheduleEggs, setScheduleEggs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [studentId, setStudentId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(studentIdProp || '');
    const discoveredRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Set());
    // Resolve studentId from auth if not passed as prop
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EasterEggLayer.useEffect": ()=>{
            if (studentIdProp) {
                setStudentId(studentIdProp);
                return;
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$apis$2f$fetchAuthSession$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAuthSession"])().then({
                "EasterEggLayer.useEffect": (session)=>{
                    const username = session?.tokens?.idToken?.payload?.['cognito:username'] || session?.tokens?.idToken?.payload?.sub || '';
                    if (username) setStudentId(username);
                }
            }["EasterEggLayer.useEffect"]).catch({
                "EasterEggLayer.useEffect": ()=>{}
            }["EasterEggLayer.useEffect"]);
        }
    }["EasterEggLayer.useEffect"], [
        studentIdProp
    ]);
    // Fetch active easter eggs (KEYWORD + SCHEDULE)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EasterEggLayer.useEffect": ()=>{
            if (!studentId) return;
            getClient().models?.EasterEgg?.list?.().then({
                "EasterEggLayer.useEffect": ({ data })=>{
                    const active = (data || []).filter({
                        "EasterEggLayer.useEffect.active": (e)=>e != null && e.triggerValue
                    }["EasterEggLayer.useEffect.active"]);
                    // KEYWORD eggs
                    const keywords = active.filter({
                        "EasterEggLayer.useEffect.keywords": (e_0)=>e_0.trigger === 'KEYWORD'
                    }["EasterEggLayer.useEffect.keywords"]);
                    setKeywordEggs(keywords.map({
                        "EasterEggLayer.useEffect": (e_1)=>({
                                id: e_1.id,
                                keyword: e_1.triggerValue,
                                message: e_1.revealMessage || 'Secret found!',
                                xpReward: e_1.xpReward || 0
                            })
                    }["EasterEggLayer.useEffect"]));
                    // SCHEDULE eggs — filter out eggs whose end time has passed (expired)
                    const now = new Date().toISOString();
                    const schedules = active.filter({
                        "EasterEggLayer.useEffect.schedules": (e_2)=>e_2.trigger === 'SCHEDULE'
                    }["EasterEggLayer.useEffect.schedules"]);
                    setScheduleEggs(schedules.map({
                        "EasterEggLayer.useEffect": (e_3)=>{
                            let start = '', end = '';
                            try {
                                const parsed = JSON.parse(e_3.triggerValue || '{}');
                                start = parsed.start || '';
                                end = parsed.end || '';
                            } catch  {}
                            return {
                                id: e_3.id,
                                start,
                                end,
                                message: e_3.revealMessage || 'Time-based secret found!',
                                xpReward: e_3.xpReward || 0
                            };
                        }
                    }["EasterEggLayer.useEffect"]).filter({
                        "EasterEggLayer.useEffect": (e_4)=>!e_4.end || e_4.end >= now
                    }["EasterEggLayer.useEffect"]) // exclude expired
                    );
                    // Mark already-discovered eggs
                    for (const egg of active){
                        const discoveries = egg.discoveries || [];
                        if (discoveries.some({
                            "EasterEggLayer.useEffect": (d)=>d.studentId === studentId
                        }["EasterEggLayer.useEffect"])) {
                            discoveredRef.current.add(egg.id);
                        }
                    }
                }
            }["EasterEggLayer.useEffect"]).catch({
                "EasterEggLayer.useEffect": (err)=>console.warn('[EasterEggLayer] fetch error:', err)
            }["EasterEggLayer.useEffect"]);
        }
    }["EasterEggLayer.useEffect"], [
        studentId
    ]);
    // Poll SCHEDULE eggs every 60 seconds
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EasterEggLayer.useEffect": ()=>{
            if (!studentId || scheduleEggs.length === 0) return;
            const checkSchedules = {
                "EasterEggLayer.useEffect.checkSchedules": ()=>{
                    const now_0 = new Date().toISOString();
                    for (const egg_0 of scheduleEggs){
                        if (discoveredRef.current.has(egg_0.id)) continue;
                        // Award if the drop time has passed — students who were offline still get it
                        const dropped = !egg_0.start || now_0 >= egg_0.start;
                        if (dropped) {
                            handleDiscover(egg_0.id, egg_0.message, egg_0.xpReward);
                        }
                    }
                }
            }["EasterEggLayer.useEffect.checkSchedules"];
            // Check immediately, then every 60s
            checkSchedules();
            const interval = setInterval(checkSchedules, 60000);
            return ({
                "EasterEggLayer.useEffect": ()=>clearInterval(interval)
            })["EasterEggLayer.useEffect"];
        }
    }["EasterEggLayer.useEffect"], [
        studentId,
        scheduleEggs
    ]);
    const handleDiscover = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "EasterEggLayer.useCallback[handleDiscover]": async (eggId, message, xpReward)=>{
            if (!studentId || discoveredRef.current.has(eggId)) return;
            discoveredRef.current.add(eggId);
            setToast({
                open: true,
                message,
                xpReward
            });
            try {
                await getClient().mutations?.discoverEasterEgg?.({
                    studentId,
                    eggId
                });
            } catch (err_0) {
                console.error('[EasterEggLayer] discoverEasterEgg error:', err_0);
            }
        }
    }["EasterEggLayer.useCallback[handleDiscover]"], [
        studentId
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            keywordEggs.map((egg_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(KeywordListener, {
                    keyword: egg_1.keyword,
                    disabled: discoveredRef.current.has(egg_1.id),
                    onTrigger: ()=>handleDiscover(egg_1.id, egg_1.message, egg_1.xpReward)
                }, egg_1.id, false, {
                    fileName: "[project]/src/components/Gamification/EasterEggLayer.tsx",
                    lineNumber: 147,
                    columnNumber: 33
                }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EasterEggToast"], {
                open: toast.open,
                message: toast.message,
                xpReward: toast.xpReward,
                onClose: ()=>setToast((t)=>({
                            ...t,
                            open: false
                        }))
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/EasterEggLayer.tsx",
                lineNumber: 148,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(EasterEggLayer, "K5KYQbdWOrM7ElzCgI5EmISjc6s=");
_c = EasterEggLayer;
/** Internal wrapper that uses the keyword hook for each egg */ function KeywordListener(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "d06208dae48a8e2602e59e4642a985303d49f4d8aff731d96d8d7e6e9003f683") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d06208dae48a8e2602e59e4642a985303d49f4d8aff731d96d8d7e6e9003f683";
    }
    const { keyword, disabled, onTrigger } = t0;
    let t1;
    if ($[1] !== disabled || $[2] !== keyword || $[3] !== onTrigger) {
        t1 = {
            keyword,
            onTrigger,
            disabled
        };
        $[1] = disabled;
        $[2] = keyword;
        $[3] = onTrigger;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEasterEggKeyword"])(t1);
    return null;
}
_s1(KeywordListener, "A8zkXlUgekNN8sAOcXdqjkXgM9Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$EasterEggTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEasterEggKeyword"]
    ];
});
_c1 = KeywordListener;
var _c, _c1;
__turbopack_context__.k.register(_c, "EasterEggLayer");
__turbopack_context__.k.register(_c1, "KeywordListener");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/NailedItCelebration.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NailedItCelebration",
    ()=>NailedItCelebration,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * NailedItCelebration — Full-screen celebration modal triggered on
 * the first "Nailed It" event per session.
 *
 * @module NailedItCelebration
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
function NailedItCelebration({ open, nailedItReason, onClose }) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NailedItCelebration.useEffect": ()=>{
            if (open) {
                // Dynamically import canvas-confetti to avoid SSR issues
                // @ts-expect-error — canvas-confetti has no type declarations
                __turbopack_context__.A("[project]/node_modules/canvas-confetti/dist/confetti.module.mjs [app-client] (ecmascript, async loader)").then({
                    "NailedItCelebration.useEffect": (mod)=>{
                        const confetti = mod.default || mod;
                        confetti({
                            particleCount: 80,
                            spread: 70,
                            origin: {
                                y: 0.6
                            }
                        });
                    }
                }["NailedItCelebration.useEffect"]).catch({
                    "NailedItCelebration.useEffect": ()=>{
                    // canvas-confetti not installed — skip silently
                    }
                }["NailedItCelebration.useEffect"]);
            }
        }
    }["NailedItCelebration.useEffect"], [
        open
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        open: open,
        maxWidth: "xs",
        fullWidth: true,
        onClose: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                textAlign: 'center',
                p: 4
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "h1",
                    sx: {
                        fontSize: '4rem'
                    },
                    children: "🎯"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/NailedItCelebration.tsx",
                    lineNumber: 47,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "h5",
                    fontWeight: 700,
                    mt: 2,
                    children: "Nailed It!"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/NailedItCelebration.tsx",
                    lineNumber: 52,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "body1",
                    color: "text.secondary",
                    mt: 1,
                    children: nailedItReason
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/NailedItCelebration.tsx",
                    lineNumber: 55,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    label: "+20 XP",
                    color: "success",
                    sx: {
                        mt: 2,
                        fontSize: '1rem',
                        p: 1
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/NailedItCelebration.tsx",
                    lineNumber: 58,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "contained",
                    fullWidth: true,
                    sx: {
                        mt: 3
                    },
                    onClick: onClose,
                    children: "Keep Going"
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/NailedItCelebration.tsx",
                    lineNumber: 63,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/NailedItCelebration.tsx",
            lineNumber: 43,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Gamification/NailedItCelebration.tsx",
        lineNumber: 42,
        columnNumber: 10
    }, this);
}
_s(NailedItCelebration, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = NailedItCelebration;
const __TURBOPACK__default__export__ = NailedItCelebration;
var _c;
__turbopack_context__.k.register(_c, "NailedItCelebration");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/NailedItBadge.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NailedItBadge",
    ()=>NailedItBadge,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Star.js [app-client] (ecmascript)");
;
;
;
;
function NailedItBadge(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "03f0caa1ceeebcfe0c4765c1c95e4b4bf30f29ce7cca4efd6660c2040002e9cf") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "03f0caa1ceeebcfe0c4765c1c95e4b4bf30f29ce7cca4efd6660c2040002e9cf";
    }
    const { size: t1 } = t0;
    const size = t1 === undefined ? "small" : t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/Gamification/NailedItBadge.tsx",
            lineNumber: 30,
            columnNumber: 10
        }, this);
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    let t3;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            fontWeight: 700,
            ml: 1
        };
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    let t4;
    if ($[3] !== size) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            icon: t2,
            label: "Nailed It",
            color: "success",
            variant: "filled",
            size: size,
            sx: t3
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/NailedItBadge.tsx",
            lineNumber: 47,
            columnNumber: 10
        }, this);
        $[3] = size;
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    return t4;
}
_c = NailedItBadge;
const __TURBOPACK__default__export__ = NailedItBadge;
var _c;
__turbopack_context__.k.register(_c, "NailedItBadge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/armoriaCharges.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * CC0-licensed heraldic charge SVGs from Azgaar/Armoria.
 *
 * Each charge's `svgContent` contains inner SVG elements in
 * Armoria coordinate space (viewBox "50 50 200 200", center ~100,100).
 * Render via nested `<svg viewBox="50 50 200 200">` for correct mapping.
 *
 * License: CC0 1.0 Universal (Public Domain)
 * Source: https://github.com/Azgaar/Armoria
 */ __turbopack_context__.s([
    "CHARGES",
    ()=>CHARGES,
    "CHARGE_VIEWBOX",
    ()=>CHARGE_VIEWBOX
]);
const CHARGE_VIEWBOX = '50 50 100 100';
const CHARGES = [
    {
        id: 'none',
        label: 'None',
        svgContent: ''
    },
    // ===== Geometric =====
    {
        id: 'mullet',
        label: 'Star',
        svgContent: '<polygon points="100 60 108.98 87.64 138.04 87.64 114.53 104.72 123.51 132.36 100 115.28 76.49 132.36 85.47 104.72 61.96 87.64 91.02 87.64"/>'
    },
    {
        id: 'mullet4',
        label: '4-Point Star',
        svgContent: '<polygon points="100 60 109.9 90.1 140 100 109.9 109.9 100 140 90.1 109.9 60 100 90.1 90.1"/>'
    },
    {
        id: 'mullet6',
        label: '6-Point Star',
        svgContent: '<polygon points="100 60 107.64 86.77 134.64 80 115.28 100 134.64 120 107.64 113.23 100 140 92.36 113.23 65.36 120 84.72 100 65.36 80 92.36 86.77"/>'
    },
    {
        id: 'annulet',
        label: 'Ring',
        svgContent: '<path d="M70 100c0 16.569 13.431 30 30 30 16.569 0 30-13.431 30-30 0-16.569-13.431-30-30-30-16.569 0-30 13.431-30 30m10 0c0-11.046 8.954-20 20-20s20 8.954 20 20-8.954 20-20 20-20-8.954-20-20"/>'
    },
    {
        id: 'roundel',
        label: 'Circle',
        svgContent: '<circle cx="100" cy="100" r="30"/>'
    },
    {
        id: 'lozenge',
        label: 'Diamond',
        svgContent: '<polygon points="100 60 135 100 100 140 65 100"/>'
    },
    {
        id: 'fusil',
        label: 'Tall Diamond',
        svgContent: '<polygon points="100 55 130 100 100 145 70 100"/>'
    },
    {
        id: 'carreau',
        label: 'Curved Diamond',
        svgContent: '<path stroke-width=".5" d="M100 59.8C94.4 75.1 86.2 88.6 75 100c11.2 11.4 19.4 24.9 25 40.2 5.6-15.3 13.8-28.8 25-40.2-11.2-11.4-19.4-24.9-25-40.2z"/>'
    },
    {
        id: 'billet',
        label: 'Rectangle',
        svgContent: '<polygon points="80 65 120 65 120 135 80 135"/>'
    },
    {
        id: 'delf',
        label: 'Square',
        svgContent: '<polygon points="75 75 125 75 125 125 75 125"/>'
    },
    {
        id: 'triangle',
        label: 'Triangle',
        svgContent: '<polygon points="100 60 135 130 65 130"/>'
    },
    {
        id: 'trianglePierced',
        label: 'Pierced Triangle',
        svgContent: '<path d="M100 60l35 70H65zm0 20l-20 40h40z"/>'
    },
    // ===== Nature =====
    {
        id: 'crescent',
        label: 'Crescent',
        svgContent: '<path d="M84 65c-32 15-24 68 16 68s48-53 16-68c18 20 2 41-16 41S67 85 84 65z"/><path fill="none" d="M84 65c-26 15-14 56 16 56s42-41 16-56"/>'
    },
    {
        id: 'sun',
        label: 'Sun',
        svgContent: '<path stroke-width=".5" d="M84.7 63c-1 3.9.1 7.1 2 10.1 1.5 2.3 2.4 4.8 2.4 7.5-.7.4-1.3.8-1.9 1.2L71.8 71.7l10.4 15.2c-.2.3-.4.5-.5.8-2.9-1.3-5.7-1.6-8.3-1.1-3.7.7-6.9-.1-10.2-2 2.1 3.5 5.1 5 8.6 5.7 2.7.6 5.1 1.7 7 3.6-.2.7-.4 1.5-.5 2.2l-18.1 3.7 18.1 3.5c0 .3.1.6.2.9-3 1.1-5.2 2.9-6.6 5.1-2.1 3.1-4.9 4.8-8.6 5.8 3.9 1 7.1-.1 10.1-2 2.3-1.5 4.8-2.4 7.5-2.4.4.7.8 1.3 1.2 1.9l-10.3 15.5 15.3-10.4c.3.2.5.4.8.5-1.3 2.9-1.6 5.7-1.1 8.3.7 3.7-.1 6.8-2 10.1 3.5-2.1 5-5.1 5.7-8.6.6-2.7 1.7-5.1 3.6-7 .7.2 1.5.4 2.2.5l3.7 18.1 3.5-18.1c.3 0 .6-.1.9-.2 1.1 3 2.9 5.2 5.1 6.6 3.1 2.1 4.8 4.9 5.8 8.6 1-3.9-.1-7.1-2-10.1-1.5-2.3-2.4-4.8-2.4-7.5.7-.4 1.3-.8 1.9-1.2l15.4 10.2-10.4-15.3c.2-.3.4-.5.5-.8 2.9 1.3 5.7 1.6 8.3 1.1 3.7-.7 6.8.1 10.1 2-2.1-3.5-5.1-4.9-8.6-5.7-2.7-.6-5.1-1.7-7-3.6.2-.7.4-1.5.5-2.2l18.1-3.7-18.1-3.5c0-.3-.1-.6-.2-.9 3-1.1 5.2-2.9 6.6-5.1 2.1-3.1 4.9-4.8 8.6-5.7-3.9-1-7.1.1-10.1 2-2.3 1.5-4.8 2.4-7.5 2.4-.4-.7-.8-1.3-1.2-1.9L128 71.6l-15.3 10.3c-.3-.2-.5-.4-.8-.5 1.3-2.9 1.6-5.7 1.1-8.3-.7-3.7.1-6.9 2-10.2-3.5 2.1-4.9 5.1-5.7 8.6-.6 2.7-1.7 5.2-3.7 7-.7-.2-1.5-.4-2.2-.5L100 60l-3.5 18.1c-.3 0-.6.1-.9.2-1.1-3-2.9-5.2-5.1-6.6-3.1-2.1-4.8-4.9-5.7-8.6z"/>'
    },
    {
        id: 'goutte',
        label: 'Water Drop',
        svgContent: '<path d="M100 134c17-1 16-19 10-25-1.9-1.8-4.6-5.3-3.9-8.1C108 94 102 90 102 87c-1-7 3-7 3-13-.1-6.2-3.3-8.7-6-12 1.2 3 2 6 1 9-1.5 5.9-6.2 6.9-8 11-2 5 3 11 3 15-.6 9.1-9 13-9 23 .3 11.3 9 14 14 14z"/>'
    },
    {
        id: 'trefle',
        label: 'Clover',
        svgContent: '<path stroke-width=".5" d="M100 70c-7.8 0-14.1 6.4-14.1 14.3 0 5.6 3.2 10.5 7.9 12.8 1.4.7-.1 2.5-1.2 1.3-2.6-3-6.4-4.8-10.6-4.8-7.8 0-14.1 6.4-14.1 14.3s6.3 14.3 14.1 14.3c7.7 0 14.1-6.3 14.1-14.1 0-1.4 2.1-1.5 2.1.3 0 2.9-2.8 18.5-4.3 21.5 3.96-.86 8.16-1.15 12 0-1.5-3-4.3-18.6-4.3-21.5 0-1.9 2.1-1.7 2.1-.3.1 7.8 6.4 14.1 14.1 14.1 7.8 0 14.1-6.4 14.1-14.3s-6.3-14.3-14.1-14.3c-4.2 0-8 1.9-10.6 4.8-1 1.2-2.6-.6-1.2-1.3 4.7-2.3 7.9-7.2 7.9-12.8.2-7.9-6.1-14.3-13.9-14.3z"/>'
    },
    // ===== Heraldic =====
    {
        id: 'fleurDeLis',
        label: 'Fleur-de-lis',
        svgContent: `<path d="M104.2 113.2c.1-5.4 1.5-10.5 4-15.3 6.6-13.8 26.6-13.5 22.2 3.4-1.6 6.2-7.2 9.9-13.7 10.5.5-1.6 3.1-7.4 1-8.6-3.4.1-7.6 6-8.6 8.7-.1.4-.1.9-.3 1.3"/><path d="M95.8 113.2c-.1-5.4-1.5-10.5-4-15.3-6.5-13.8-26.6-13.4-22.2 3.5 1.6 6.2 7.2 9.9 13.7 10.5-.5-1.6-3.1-7.4-1-8.6 3.4.1 7.6 6 8.6 8.7.1.4.1.9.3 1.3"/><path d="M99.6 60.5C92.7 68 88 76.6 90 86.7c1.1 5.6 3.8 10.7 5.7 16.1 1.2 3.4 1.5 6.9 1.3 10.4h5.9c-.3-3.6.4-7 1.3-10.4 1.8-5.4 4.5-10.5 5.7-16.1 2.1-10.4-2.9-18.3-9.5-26.2l-.4-.5z"/><path d="M92 117.4c-1.7 3.4-8.5 9.7-12.2 11.5-.9.5 4.5-.3 6.9-.7 3.2-.5 7.4-3 7.3-2.1 0 4 1.5 10.7 5.6 13.8l.4.3.4-.3c4-3.4 5.6-9.5 5.6-13.8-.1-.9 4.1 1.6 7.3 2.1 2.4.4 7.9 1.1 6.9.7-3.6-1.8-10.5-8.1-12.2-11.5z"/><rect width="28" height="5" x="86.4" y="112.6"/>`
    },
    {
        id: 'heart',
        label: 'Heart',
        svgContent: '<path stroke-width=".5" d="M100 84c-.7-1.1-1.4-2.2-2.4-3.2-6.3-6.8-16.6-6.8-23 0-6.3 6.8-5.4 17.8 1 24.6 6.3 6.8 17.7 12.4 24.2 27 7.3-14.4 18.2-20.2 24.5-27 6.3-6.8 7.3-17.8 1-24.6-6.3-6.8-16.6-6.8-23 0-.9 1-1.6 2.1-2.3 3.2z"/>'
    },
    {
        id: 'pique',
        label: 'Spade',
        svgContent: '<path stroke-width=".5" d="M100 70c-5.7 10.3-25.2 19.8-25.2 32.8 0 6.2 5.6 11.1 12.6 11.1 4.4 0 8.4-2 10.6-5.1-.9 8.9-3.5 18.8-12.6 20.7h29.2c-9.2-1.9-11.7-11.8-12.6-20.7 2.2 3.1 6.2 5.1 10.6 5.1 7 0 12.6-5 12.6-11.1 0-13-19.5-22.5-25.2-32.8z"/>'
    },
    // ===== Crosses =====
    {
        id: 'crossHummetty',
        label: 'Cross',
        svgContent: '<path d="M90 60h20v30h30v20h-30v30H90v-30H60V90h30z"/>'
    },
    {
        id: 'crossMaltese',
        label: 'Maltese Cross',
        svgContent: '<path d="M98 98L83 60l17 11 17-11-15 38 38-15-11 17 11 17-38-15 15 38-17-11-17 11 15-38-38 15 11-17-11-17z"/>'
    },
    {
        id: 'crossPattee',
        label: 'Cross Pattée',
        svgContent: '<path d="M 77,62 C 88,71 95,82 96,96 82,95 71,88 62,77 v 46 c 9,-11 20,-18 34,-19 -1,14 -8,25 -19,34 h 46 c -11,-9 -18,-20 -19,-34 14,1 25,8 34,19 V 77 c -9,11 -20,18 -34,19 1,-14 8,-25 19,-34 z"/>'
    },
    {
        id: 'crossLatin',
        label: 'Latin Cross',
        svgContent: '<path d="m 95,60 h 10 v 20 h 25 v 10 h -25 v 50 H 95 V 90 H 70 V 80 h 25 z"/>'
    },
    {
        id: 'crossCeltic',
        label: 'Celtic Cross',
        svgContent: '<path d="m 95,60 v 7 C 80,70 70,80 67,95 h -7 v 10 h 7 c 3,15 13,25 28,28 v 7 h 10 v -7 c 15,-3 25,-13 28,-28 h 7 V 95 h -7 C 130,80 120,70 105,67 v -7 z m 0,15 V 95 H 75 C 77,85 85,77 95,75 Z m 10,0 c 10,2 18,10 20,20 h -20 z m -30,30 h 20 v 20 C 85,123 77,115 75,105 Z m 30,0 h 20 c -2,10 -10,18 -20,20 z"/>'
    },
    {
        id: 'crossSaltire',
        label: 'Saltire',
        svgContent: '<path d="m 74,66 -8,8 26,26 -26,26 8,8 26,-26 26,26 8,-8 -26,-26 26,-26 -8,-8 -26,26 z"/>'
    },
    {
        id: 'crosslet',
        label: 'Crosslet',
        svgContent: '<path d="M95 60h10v10h12v10h-12v15h15V83h10v12h10v10h-10v12h-10v-12h-15v15h12v10h-12v10H95v-10H83v-10h12v-15H80v12H70v-12H60V95h10V83h10v12h15V80H83V70h12z"/>'
    },
    // ===== Symbols =====
    {
        id: 'compassRose',
        label: 'Compass Rose',
        svgContent: `<path d="M100 60l6 28 14-8-8 15 28 5-28 6 8 14-14-8-6 28-6-28-14 8 8-14-28-6 28-6-8-14 14 8z"/><path fill="#000" fill-opacity=".5" stroke-opacity=".2" d="M100 61v39l7-6 5 1c2.7-5 5.3-10 8-15-4.3 4.3-8.7 9.7-13 14-2.3-10.7-4.7-22.3-7-33zm0 39l7 7c10.7-2.3 21.3-4.7 32-7zm0 0l-7 7c2.3 10.7 4.7 21.3 7 32zm0 0l-7-7-32 7zm-7-7l1-5-14-8zm0 14c-1.7-.3-3.3-.7-5-1-2.7 4.7-5.3 9.3-8 14l13-13zm14 0c-.3 1.7-.7 3.3-1 5 4.7 2.7 9.3 5.3 14 8z"/>`
    },
    {
        id: 'spiral',
        label: 'Spiral',
        svgContent: '<path d="M123.05 69.88c-21.64-15.51-45.11-5.13-54.44 7.88-16 22.3-6.78 43.54 4.28 52.2 14.91 11.7 39.13 10.79 49.65-3.71 8.51-11.74 8.88-29.46-5.13-39.85-7.71-5.72-22.7-7.56-31.19 4.5-6.1 8.69-1.82 17.66 2.52 21.37 5.43 4.63 12.77 3.72 16.07-.81 5.15-7.06-1.2-13.23-5.71-11.8 1.31 1.29 1.58 4.25-.46 4.8-2.49.69-4.8-3.46-2.68-6.29 3.16-4.2 9.56-3.48 12.66-1.1 6 4.62 6.94 13 1.42 20.12-8.24 10.62-21.14 7.1-26.38 3.01-10.1-7.87-14.39-22.27-4.89-35.08 14.2-19.15 35.64-11.73 43.75-6.06 11.3 7.91 13.52 17.34 16.22 32.28 4.05-17.96-2.71-32.15-15.7-41.46z"/>'
    },
    {
        id: 'drawingCompass',
        label: 'Compass',
        svgContent: `<path d="m102.48 69.79 21.27 70.2c.98-19.23-12.9-49.16-19.75-77.25-1.08 2.92-.36 4.8-1.52 7.05z"/><path d="M97.2 62.92c-8.52 32.34-23.6 65.9-20.65 76.43 7.33-17.18 12.24-37.8 17.44-52.5l5.07-15.23 3.6-1.16 1.68-5.49c.36-4.7-4.47-7.07-7.15-2.05z"/><path d="M117.92 70.77c-.8-.01-1.63.37-2.37 1.3a16.7 16.7 0 0 1-21.89 8.05c-3.69-.88-5.58 4.17-2.39 6.45a22.32 22.32 0 0 0 8.8 1.96 22.88 22.88 0 0 0 20.43-12.08c1.48-2.69-.38-5.67-2.58-5.68zm.05 2.22c.7.02 1.3.78.8 1.97-3.63 6.54-11.03 11.88-19.2 11.07-2.02-.1-2.97-.36-3.67-.53-1.7-.3-1.02-2.9.44-2.37.92.25 1.72.46 3.63.58 7.71.25 13.1-3.6 16.74-9.6.25-.79.78-1.13 1.26-1.12z"/><circle cx="100.77" cy="63.88" r="3"/><circle cx="92.94" cy="83.29" r=".86"/><circle cx="108.25" cy="83.27" r="2.57"/>`
    },
    {
        id: 'laurelWreath',
        label: 'Laurel Wreath',
        svgContent: `<path d="m 83,74 c -4.6,2 -10.4,7.8 -13,13 -4.4,12.2 1.1,26 8.8,34 5,4 11.4,7 21.2,7 16,-1 26,-11 30,-22 4,-11.9 0,-26 -14,-32 v 1 c 13,6 16,19 13,30 -6,19 -29.1,29 -48.2,16 C 72,112 66.5,101 71,87 74,82.2 78.7,76.8 83,75 Z"/><path d="m102 127s0-7 4-10c0 0 5 5-4 10z"/><path d="m102 127s0 9 9 7c0 0 1-4-9-7z"/><path d="m110 126s-2-7 1-11c0 0 6 5-1 11z"/><path d="m110 126s1 7 11 4c0 0 2-5-11-4z"/><path d="m117 122s5 7 12 1c0 0-3-4-12-1z"/><path d="m117 122s-4-2-1-11c0 0 6 4 1 11z"/><path d="m123 116c-3-2-4-5-4-9 5 2 6 5 4 9z"/><path d="m123 116c3 4 11 4 12-2-4-1-8 0-12 2z"/><path d="m128 109s7-7 11-5c0 0-2 9-11 5z"/><path d="m128 109s-5-1-6-7c0 0 7 0 6 7z"/><path d="m130 102s2-7.9 8-8.8c0 0 2 8.8-8 8.8z"/><path d="m130 102s-7-1-9-6.1c0 0 7-1.5 9 6.1z"/><path d="m131 93.7s-3-6.3 5-10.2c0-.2 2 7.8-5 10.2z"/><path d="m131 93.7s-10 2.2-12-3.7c0 0 6-3.5 12 3.7z"/><path d="m128 86.2s-3-7.5 2-12.2c0 0 5 8.2-2 12.2z"/><path d="m128 86.2s-6-5.9-12-.5c0 0 6 3.5 12 .5z"/><path d="m123 79.4s-5-5.6-1-13c0 0 7 9 1 13z"/><path d="m117 75.1s1-7.2-9-7.8c0 0-1 7.7 9 7.8z"/><path d="m97.7 127s-.3-7-4.7-10c0 0-4.6 5 4.7 10z"/><path d="m97.7 127s-.6 9-9.8 7c0 0-.4-4 9.8-7z"/><path d="m89.2 126s1.8-7-1.4-11c.1 0-5.1 5 1.4 11z"/><path d="m89.2 126s-1 7-11 4c0 0-1.5-5 11-4z"/><path d="m82.1 122s-4.9 7-11.6 1c0 0 2.6-4 11.6-1z"/><path d="m82.1 122s3.9-2 1.5-11c0 0-6.7 4-1.5 11z"/><path d="m76.3 116c4.2-2 4.2-4 4.2-9-5.6 1-7.4 4-4.2 9z"/><path d="m76.3 116c-3.2 5-8.8 4-12-2 4.5-1 8.1 0 12 2z"/><path d="m71.9 109s-6.7-7-10.9-5c0 0 2 9 10.9 5z"/><path d="m71.9 109s5.1-1 6.4-7c.1 0-7.4 0-6.4 7z"/><path d="m69.5 102s-2.4-7.9-8.2-8.8c0 0-2.2 8.8 8.2 8.8z"/><path d="m69.5 102s7.2-1 8.7-6.1c0 0-6.6-1.5-8.7 6.1z"/><path d="m68.6 93.7s2.6-6.3-4.9-10.2c0-.2-2.8 7.8 4.9 10.2z"/><path d="m68.6 93.7s9.6 2.2 11.4-3.7c0 0-5.5-3.5-11.4 3.7z"/><path d="m70.8 86.2s2.7-7.5-2.3-12.2c0 0-5.7 8.2 2.3 12.2z"/><path d="m70.8 86.2s5.4-5.9 11.3-.5c0 0-5.5 3.5-11.3.5z"/><path d="m76.3 79.4s5.1-5.6.7-13c0 0-7 9-.7 13z"/><path d="m76.3 79.7s4.3-5.1 10.7 1.3c0 0-5.8 3.4-10.7-1.3z"/><path d="m81.9 75.1s-.1-7.2 9.9-7.8c0 0 .1 7.7-9.9 7.8z"/><path d="m123 79.7s-4-5.1-11 1.3c0 0 6 3.4 11-1.3z"/>`
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/useArmorUndoRedo.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useArmorUndoRedo",
    ()=>useArmorUndoRedo
]);
/**
 * useArmorUndoRedo — Shared undo/redo hook for the ArmorEditor.
 *
 * Manages a single undo/redo stack encompassing:
 *   - Armor config (shape, colors, division, charges)
 *   - Squad name
 *   - Squad description
 *
 * Supports Ctrl/Cmd+Z (undo) and Ctrl/Cmd+Shift+Z (redo) keyboard shortcuts.
 *
 * @module useArmorUndoRedo
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const MAX_HISTORY = 50;
function useArmorUndoRedo(initial) {
    _s();
    const [snapshot, setSnapshotRaw] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initial);
    const [past, setPast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [future, setFuture] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const snapshotRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(snapshot);
    snapshotRef.current = snapshot;
    const setSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useArmorUndoRedo.useCallback[setSnapshot]": (next)=>{
            setSnapshotRaw(next);
        }
    }["useArmorUndoRedo.useCallback[setSnapshot]"], []);
    const pushAndUpdate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useArmorUndoRedo.useCallback[pushAndUpdate]": (updater)=>{
            setPast({
                "useArmorUndoRedo.useCallback[pushAndUpdate]": (prev)=>[
                        ...prev.slice(-(MAX_HISTORY - 1)),
                        snapshotRef.current
                    ]
            }["useArmorUndoRedo.useCallback[pushAndUpdate]"]);
            setFuture([]);
            setSnapshotRaw({
                "useArmorUndoRedo.useCallback[pushAndUpdate]": (prev_0)=>updater(prev_0)
            }["useArmorUndoRedo.useCallback[pushAndUpdate]"]);
        }
    }["useArmorUndoRedo.useCallback[pushAndUpdate]"], []);
    const undo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useArmorUndoRedo.useCallback[undo]": ()=>{
            setPast({
                "useArmorUndoRedo.useCallback[undo]": (prev_1)=>{
                    if (prev_1.length === 0) return prev_1;
                    const last = prev_1[prev_1.length - 1];
                    setFuture({
                        "useArmorUndoRedo.useCallback[undo]": (f)=>[
                                snapshotRef.current,
                                ...f
                            ]
                    }["useArmorUndoRedo.useCallback[undo]"]);
                    setSnapshotRaw(last);
                    return prev_1.slice(0, -1);
                }
            }["useArmorUndoRedo.useCallback[undo]"]);
        }
    }["useArmorUndoRedo.useCallback[undo]"], []);
    const redo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useArmorUndoRedo.useCallback[redo]": ()=>{
            setFuture({
                "useArmorUndoRedo.useCallback[redo]": (prev_2)=>{
                    if (prev_2.length === 0) return prev_2;
                    const next_0 = prev_2[0];
                    setPast({
                        "useArmorUndoRedo.useCallback[redo]": (p)=>[
                                ...p,
                                snapshotRef.current
                            ]
                    }["useArmorUndoRedo.useCallback[redo]"]);
                    setSnapshotRaw(next_0);
                    return prev_2.slice(1);
                }
            }["useArmorUndoRedo.useCallback[redo]"]);
        }
    }["useArmorUndoRedo.useCallback[redo]"], []);
    const reset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useArmorUndoRedo.useCallback[reset]": (initial_0)=>{
            setSnapshotRaw(initial_0);
            setPast([]);
            setFuture([]);
        }
    }["useArmorUndoRedo.useCallback[reset]"], []);
    return {
        snapshot,
        setSnapshot,
        pushAndUpdate,
        undo,
        redo,
        canUndo: past.length > 0,
        canRedo: future.length > 0,
        reset
    };
}
_s(useArmorUndoRedo, "icncmWZVLRDdhDQR5FeQwQS2kGU=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/ArmorEditor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArmorEditor",
    ()=>ArmorEditor,
    "default",
    ()=>__TURBOPACK__default__export__,
    "renderShieldSvg",
    ()=>renderShieldSvg
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * ArmorEditor — Modal UI for designing a squad coat of arms.
 *
 * Features:
 *   - 4 shield shapes (Classic, Rounded, Pointed, Diamond)
 *   - 10 plain-English colors with swatches
 *   - 4 field divisions (None, Halved, Quartered, Diagonal)
 *   - 10 SVG-path charges (star, cross, lightning, etc.)
 *   - Randomize button for instant inspiration
 *   - Live SVG preview
 *   - Full undo/redo stack with Ctrl/Cmd+Z / Ctrl/Cmd+Shift+Z
 *   - Squad name & description as Lexical plain text editors
 *   - Autosave on change (debounced)
 *
 * @module ArmorEditor
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$armoriaCharges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/armoriaCharges.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$useArmorUndoRedo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/useArmorUndoRedo.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Slider/Slider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Casino$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Casino.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Undo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Undo.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Redo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Redo.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AddCircleOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AddCircleOutline.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const SHIELD_SHAPES = [
    {
        id: 'classic',
        label: 'Classic',
        path: 'M10,2 L90,2 L90,60 Q90,95 50,98 Q10,95 10,60 Z'
    },
    {
        id: 'rounded',
        label: 'Rounded',
        path: 'M10,2 Q10,2 10,2 L90,2 Q95,2 95,8 L95,55 Q95,95 50,98 Q5,95 5,55 L5,8 Q5,2 10,2 Z'
    },
    {
        id: 'pointed',
        label: 'Pointed',
        path: 'M10,2 L90,2 L90,50 L50,98 L10,50 Z'
    },
    {
        id: 'diamond',
        label: 'Diamond',
        path: 'M50,2 L90,40 L50,98 L10,40 Z'
    },
    {
        id: 'heater',
        label: 'Heater',
        path: 'M10,2 L90,2 L90,55 Q90,80 50,98 Q10,80 10,55 Z'
    },
    {
        id: 'oval',
        label: 'Oval',
        path: 'M50,2 Q90,2 90,50 Q90,98 50,98 Q10,98 10,50 Q10,2 50,2 Z'
    },
    {
        id: 'square',
        label: 'Square',
        path: 'M8,2 L92,2 L92,92 L8,92 Z'
    },
    {
        id: 'kite',
        label: 'Kite',
        path: 'M50,2 L85,30 L50,98 L15,30 Z'
    },
    {
        id: 'swiss',
        label: 'Swiss',
        path: 'M10,2 L90,2 L90,65 Q90,85 70,92 L50,98 L30,92 Q10,85 10,65 Z'
    },
    {
        id: 'french',
        label: 'French',
        path: 'M10,2 L90,2 L90,70 Q90,90 75,95 L50,98 L25,95 Q10,90 10,70 Z'
    },
    {
        id: 'horsehead',
        label: 'Horse Head',
        path: 'M15,2 L85,2 Q92,2 92,10 L92,60 Q92,75 80,85 L50,98 L20,85 Q8,75 8,60 L8,10 Q8,2 15,2 Z'
    },
    {
        id: 'banner',
        label: 'Banner',
        path: 'M5,5 L95,5 L95,80 L50,95 L5,80 Z'
    }
];
const COLORS = [
    {
        id: 'blue',
        label: 'Blue',
        hex: '#1565c0'
    },
    {
        id: 'red',
        label: 'Red',
        hex: '#c62828'
    },
    {
        id: 'green',
        label: 'Green',
        hex: '#2e7d32'
    },
    {
        id: 'purple',
        label: 'Purple',
        hex: '#6a1b9a'
    },
    {
        id: 'gold',
        label: 'Gold',
        hex: '#f9a825'
    },
    {
        id: 'orange',
        label: 'Orange',
        hex: '#e65100'
    },
    {
        id: 'teal',
        label: 'Teal',
        hex: '#00838f'
    },
    {
        id: 'black',
        label: 'Black',
        hex: '#212121'
    },
    {
        id: 'silver',
        label: 'Silver',
        hex: '#bdbdbd'
    },
    {
        id: 'white',
        label: 'White',
        hex: '#f5f5f5'
    }
];
const DIVISIONS = [
    // Field splits — how the background is divided
    {
        id: 'none',
        label: 'Solid',
        group: 'split'
    },
    {
        id: 'halved',
        label: 'Halved',
        group: 'split'
    },
    {
        id: 'horizontal',
        label: 'Horizontal Split',
        group: 'split'
    },
    {
        id: 'quartered',
        label: 'Quartered',
        group: 'split'
    },
    {
        id: 'diagonal-right',
        label: 'Diagonal Right',
        group: 'split'
    },
    {
        id: 'diagonal-left',
        label: 'Diagonal Left',
        group: 'split'
    },
    {
        id: 'x-split',
        label: 'X Split',
        group: 'split'
    },
    {
        id: 'chevron-split',
        label: 'Chevron Split',
        group: 'split'
    },
    // Ordinaries — bands and stripes overlaid on the field
    {
        id: 'fess',
        label: 'Horizontal Band',
        group: 'ordinary'
    },
    {
        id: 'pale',
        label: 'Vertical Band',
        group: 'ordinary'
    },
    {
        id: 'bend',
        label: 'Diagonal Band',
        group: 'ordinary'
    },
    {
        id: 'chevron',
        label: 'Chevron',
        group: 'ordinary'
    },
    {
        id: 'chief',
        label: 'Top Band',
        group: 'ordinary'
    },
    {
        id: 'saltire',
        label: 'X Band',
        group: 'ordinary'
    },
    {
        id: 'cross-band',
        label: 'Cross Band',
        group: 'ordinary'
    },
    {
        id: 'border',
        label: 'Border',
        group: 'ordinary'
    }
];
const POSITIONS = [
    {
        id: 'top-left',
        label: 'Top Left',
        x: 32,
        y: 28
    },
    {
        id: 'top',
        label: 'Top Center',
        x: 50,
        y: 28
    },
    {
        id: 'top-right',
        label: 'Top Right',
        x: 68,
        y: 28
    },
    {
        id: 'left',
        label: 'Center Left',
        x: 30,
        y: 50
    },
    {
        id: 'center',
        label: 'Center',
        x: 50,
        y: 50
    },
    {
        id: 'right',
        label: 'Center Right',
        x: 70,
        y: 50
    },
    {
        id: 'bottom-left',
        label: 'Bottom Left',
        x: 36,
        y: 70
    },
    {
        id: 'bottom',
        label: 'Bottom Center',
        x: 50,
        y: 70
    },
    {
        id: 'bottom-right',
        label: 'Bottom Right',
        x: 64,
        y: 70
    }
];
/** Extract charges array from config, handling legacy single-charge format */ function getCharges(config) {
    if (config.charges && config.charges.length > 0) return config.charges;
    if (config.chargeId && config.chargeId !== 'none') {
        return [
            {
                chargeId: config.chargeId,
                chargeColor: config.chargeColor,
                chargePosition: config.chargePosition || 'center',
                chargeScale: config.chargeScale
            }
        ];
    }
    return [];
}
function renderShieldSvg(config) {
    const shape = SHIELD_SHAPES.find((s)=>s.id === config.shape) || SHIELD_SHAPES[0];
    const clipId = 'shield-clip';
    // Build division / ordinary pattern
    const c2 = config.fieldColor2;
    const cp = `clip-path="url(#${clipId})"`;
    let divisionFill = '';
    switch(config.division){
        case 'halved':
            divisionFill = `<rect x="50" y="0" width="50" height="100" fill="${c2}" ${cp}/>`;
            break;
        case 'horizontal':
            divisionFill = `<rect x="0" y="50" width="100" height="50" fill="${c2}" ${cp}/>`;
            break;
        case 'quartered':
            divisionFill = `<rect x="50" y="0" width="50" height="50" fill="${c2}" ${cp}/><rect x="0" y="50" width="50" height="50" fill="${c2}" ${cp}/>`;
            break;
        case 'diagonal-right':
            divisionFill = `<polygon points="0,0 100,0 100,100" fill="${c2}" ${cp}/>`;
            break;
        case 'diagonal-left':
            divisionFill = `<polygon points="0,0 100,0 0,100" fill="${c2}" ${cp}/>`;
            break;
        case 'x-split':
            divisionFill = `<polygon points="50,50 100,0 100,100" fill="${c2}" ${cp}/><polygon points="50,50 0,0 0,100" fill="${c2}" ${cp}/>`;
            break;
        case 'chevron-split':
            divisionFill = `<polygon points="0,45 50,15 100,45 100,100 0,100" fill="${c2}" ${cp}/>`;
            break;
        case 'fess':
            divisionFill = `<rect x="0" y="35" width="100" height="30" fill="${c2}" ${cp}/>`;
            break;
        case 'pale':
            divisionFill = `<rect x="35" y="0" width="30" height="100" fill="${c2}" ${cp}/>`;
            break;
        case 'bend':
            divisionFill = `<polygon points="-10,-2 2,-10 110,88 98,110" fill="${c2}" ${cp}/>`;
            break;
        case 'chevron':
            divisionFill = `<polygon points="50,20 80,55 75,60 50,32 25,60 20,55" fill="${c2}" ${cp}/>`;
            break;
        case 'chief':
            divisionFill = `<rect x="0" y="0" width="100" height="30" fill="${c2}" ${cp}/>`;
            break;
        case 'saltire':
            divisionFill = `<polygon points="-5,-10 5,-10 50,40 95,-10 105,-10 60,50 105,110 95,110 50,60 5,110 -5,110 40,50" fill="${c2}" ${cp}/>`;
            break;
        case 'cross-band':
            divisionFill = `<rect x="0" y="35" width="100" height="30" fill="${c2}" ${cp}/><rect x="35" y="0" width="30" height="100" fill="${c2}" ${cp}/>`;
            break;
        case 'border':
            divisionFill = `<path d="${shape.path}" fill="none" stroke="${c2}" stroke-width="12" ${cp}/>`;
            break;
    }
    // Charge SVGs — render all charges from the charges array
    let chargeSvg = '';
    const chargesList = getCharges(config);
    if (chargesList.length > 0) {
        let inner = '';
        for (const ch of chargesList){
            const charge = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$armoriaCharges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHARGES"].find((c)=>c.id === ch.chargeId);
            const pos = POSITIONS.find((p)=>p.id === (ch.chargePosition || 'center')) || POSITIONS[4];
            if (charge?.svgContent) {
                const scale = ch.chargeScale ?? 1;
                const size = 30 * scale;
                const cx = pos.x + (ch.offsetX ?? 0);
                const cy = pos.y + (ch.offsetY ?? 0);
                const rot = ch.rotation ?? 0;
                const rotAttr = rot !== 0 ? ` transform="rotate(${rot}, ${cx}, ${cy})"` : '';
                inner += `<g${rotAttr}><svg x="${cx - size / 2}" y="${cy - size / 2}" width="${size}" height="${size}" viewBox="${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$armoriaCharges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHARGE_VIEWBOX"]}" fill="${ch.chargeColor}" stroke="#000" stroke-width="${1 / scale}">${charge.svgContent}</svg></g>`;
            }
        }
        if (inner) chargeSvg = `<g clip-path="url(#${clipId})">${inner}</g>`;
    }
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="200" height="200">
  <defs>
    <clipPath id="${clipId}">
      <path d="${shape.path}"/>
    </clipPath>
  </defs>
  <path d="${shape.path}" fill="${config.fieldColor}" stroke="#333" stroke-width="1.5"/>
  ${divisionFill}
  ${chargeSvg}
  <path d="${shape.path}" fill="none" stroke="#333" stroke-width="1.5"/>
</svg>`;
}
// ============================================================================
// Sub-components
// ============================================================================
function ColorSwatch(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "959e075de765a64e1deda1206408d63812883af6db15075b83dbc81e4ba2bc85") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "959e075de765a64e1deda1206408d63812883af6db15075b83dbc81e4ba2bc85";
    }
    const { color, selected, onClick } = t0;
    let t1;
    if ($[1] !== onClick) {
        t1 = ({
            "ColorSwatch[<Box>.onKeyDown]": (e)=>{
                if (e.key === "Enter" || e.key === " ") {
                    onClick();
                }
            }
        })["ColorSwatch[<Box>.onKeyDown]"];
        $[1] = onClick;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const t2 = selected ? "3px solid" : "2px solid transparent";
    const t3 = selected ? "primary.main" : "transparent";
    let t4;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            transform: "scale(1.15)"
        };
        $[3] = t4;
    } else {
        t4 = $[3];
    }
    let t5;
    if ($[4] !== color.hex || $[5] !== t2 || $[6] !== t3) {
        t5 = {
            width: 28,
            height: 28,
            borderRadius: "50%",
            bgcolor: color.hex,
            cursor: "pointer",
            border: t2,
            borderColor: t3,
            outline: "1px solid rgba(0,0,0,0.15)",
            transition: "transform 0.1s, border-color 0.15s",
            "&:hover": t4
        };
        $[4] = color.hex;
        $[5] = t2;
        $[6] = t3;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] !== color.label || $[9] !== onClick || $[10] !== selected || $[11] !== t1 || $[12] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: onClick,
            role: "radio",
            "aria-checked": selected,
            "aria-label": color.label,
            tabIndex: 0,
            onKeyDown: t1,
            sx: t5
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
            lineNumber: 506,
            columnNumber: 10
        }, this);
        $[8] = color.label;
        $[9] = onClick;
        $[10] = selected;
        $[11] = t1;
        $[12] = t5;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    let t7;
    if ($[14] !== color.label || $[15] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: color.label,
            children: t6
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
            lineNumber: 518,
            columnNumber: 10
        }, this);
        $[14] = color.label;
        $[15] = t6;
        $[16] = t7;
    } else {
        t7 = $[16];
    }
    return t7;
}
_c = ColorSwatch;
function ShapeSelector(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "959e075de765a64e1deda1206408d63812883af6db15075b83dbc81e4ba2bc85") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "959e075de765a64e1deda1206408d63812883af6db15075b83dbc81e4ba2bc85";
    }
    const { shapes, selected, onSelect } = t0;
    let t1;
    if ($[1] !== onSelect || $[2] !== selected || $[3] !== shapes) {
        let t2;
        if ($[5] !== onSelect || $[6] !== selected) {
            t2 = ({
                "ShapeSelector[shapes.map()]": (shape)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        title: shape.label,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            onClick: {
                                "ShapeSelector[shapes.map() > <Box>.onClick]": ()=>onSelect(shape.id)
                            }["ShapeSelector[shapes.map() > <Box>.onClick]"],
                            sx: {
                                width: 44,
                                height: 44,
                                cursor: "pointer",
                                border: selected === shape.id ? "2px solid" : "2px solid transparent",
                                borderColor: selected === shape.id ? "primary.main" : "transparent",
                                borderRadius: 1,
                                p: 0.25,
                                "& svg": {
                                    width: "100%",
                                    height: "100%"
                                }
                            },
                            dangerouslySetInnerHTML: {
                                __html: `<svg viewBox="0 0 100 100"><path d="${shape.path}" fill="#e0e0e0" stroke="#666" stroke-width="2"/></svg>`
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                            lineNumber: 545,
                            columnNumber: 93
                        }, this)
                    }, shape.id, false, {
                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                        lineNumber: 545,
                        columnNumber: 49
                    }, this)
            })["ShapeSelector[shapes.map()]"];
            $[5] = onSelect;
            $[6] = selected;
            $[7] = t2;
        } else {
            t2 = $[7];
        }
        t1 = shapes.map(t2);
        $[1] = onSelect;
        $[2] = selected;
        $[3] = shapes;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    let t2;
    if ($[8] !== t1) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            flexWrap: "wrap",
            gap: 1,
            children: t1
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
            lineNumber: 579,
            columnNumber: 10
        }, this);
        $[8] = t1;
        $[9] = t2;
    } else {
        t2 = $[9];
    }
    return t2;
}
_c1 = ShapeSelector;
function ChargeSelector(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "959e075de765a64e1deda1206408d63812883af6db15075b83dbc81e4ba2bc85") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "959e075de765a64e1deda1206408d63812883af6db15075b83dbc81e4ba2bc85";
    }
    const { charges, selected, onSelect } = t0;
    let t1;
    if ($[1] !== charges || $[2] !== onSelect || $[3] !== selected) {
        let t2;
        if ($[5] !== onSelect || $[6] !== selected) {
            t2 = ({
                "ChargeSelector[charges.map()]": (ch)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        title: ch.label,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            onClick: {
                                "ChargeSelector[charges.map() > <Box>.onClick]": ()=>onSelect(ch.id)
                            }["ChargeSelector[charges.map() > <Box>.onClick]"],
                            sx: {
                                width: 36,
                                height: 36,
                                cursor: "pointer",
                                border: selected === ch.id ? "2px solid" : "2px solid transparent",
                                borderColor: selected === ch.id ? "primary.main" : "transparent",
                                borderRadius: 1,
                                p: 0.25,
                                bgcolor: selected === ch.id ? "action.selected" : "transparent",
                                "& svg": {
                                    width: "100%",
                                    height: "100%"
                                }
                            },
                            dangerouslySetInnerHTML: {
                                __html: ch.svgContent ? `<svg viewBox="${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$armoriaCharges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHARGE_VIEWBOX"]}" fill="#555" stroke="#000">${ch.svgContent}</svg>` : "<svg viewBox=\"0 0 40 40\"><line x1=\"8\" y1=\"8\" x2=\"32\" y2=\"32\" stroke=\"#ccc\" stroke-width=\"2\"/><line x1=\"32\" y1=\"8\" x2=\"8\" y2=\"32\" stroke=\"#ccc\" stroke-width=\"2\"/></svg>"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                            lineNumber: 605,
                            columnNumber: 86
                        }, this)
                    }, ch.id, false, {
                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                        lineNumber: 605,
                        columnNumber: 48
                    }, this)
            })["ChargeSelector[charges.map()]"];
            $[5] = onSelect;
            $[6] = selected;
            $[7] = t2;
        } else {
            t2 = $[7];
        }
        t1 = charges.map(t2);
        $[1] = charges;
        $[2] = onSelect;
        $[3] = selected;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    let t2;
    if ($[8] !== t1) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            flexWrap: "wrap",
            gap: 0.5,
            children: t1
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
            lineNumber: 640,
            columnNumber: 10
        }, this);
        $[8] = t1;
        $[9] = t2;
    } else {
        t2 = $[9];
    }
    return t2;
}
_c2 = ChargeSelector;
function divisionPreviewSvg(id, c1, c2) {
    const bg = `<rect width="100" height="100" fill="${c1}"/>`;
    const border = `<rect width="100" height="100" fill="none" stroke="#999" stroke-width="4"/>`;
    let overlay = '';
    switch(id){
        case 'halved':
            overlay = `<rect x="50" width="50" height="100" fill="${c2}"/>`;
            break;
        case 'horizontal':
            overlay = `<rect y="50" width="100" height="50" fill="${c2}"/>`;
            break;
        case 'quartered':
            overlay = `<rect x="50" y="0" width="50" height="50" fill="${c2}"/><rect x="0" y="50" width="50" height="50" fill="${c2}"/>`;
            break;
        case 'diagonal-right':
            overlay = `<polygon points="0,0 100,0 100,100" fill="${c2}"/>`;
            break;
        case 'diagonal-left':
            overlay = `<polygon points="0,0 100,0 0,100" fill="${c2}"/>`;
            break;
        case 'x-split':
            overlay = `<polygon points="50,50 100,0 100,100" fill="${c2}"/><polygon points="50,50 0,0 0,100" fill="${c2}"/>`;
            break;
        case 'chevron-split':
            overlay = `<polygon points="0,45 50,15 100,45 100,100 0,100" fill="${c2}"/>`;
            break;
        case 'fess':
            overlay = `<rect y="35" width="100" height="30" fill="${c2}"/>`;
            break;
        case 'pale':
            overlay = `<rect x="35" width="30" height="100" fill="${c2}"/>`;
            break;
        case 'bend':
            overlay = `<polygon points="-10,-2 2,-10 110,88 98,110" fill="${c2}"/>`;
            break;
        case 'chevron':
            overlay = `<polygon points="50,20 80,55 75,60 50,32 25,60 20,55" fill="${c2}"/>`;
            break;
        case 'chief':
            overlay = `<rect width="100" height="30" fill="${c2}"/>`;
            break;
        case 'saltire':
            overlay = `<polygon points="-5,-10 5,-10 50,40 95,-10 105,-10 60,50 105,110 95,110 50,60 5,110 -5,110 40,50" fill="${c2}"/>`;
            break;
        case 'cross-band':
            overlay = `<rect y="35" width="100" height="30" fill="${c2}"/><rect x="35" width="30" height="100" fill="${c2}"/>`;
            break;
        case 'border':
            overlay = `<rect width="100" height="100" fill="none" stroke="${c2}" stroke-width="16"/>`;
            break;
    }
    return `<svg viewBox="0 0 100 100">${bg}${overlay}${border}</svg>`;
}
function DivisionSelector(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(29);
    if ($[0] !== "959e075de765a64e1deda1206408d63812883af6db15075b83dbc81e4ba2bc85") {
        for(let $i = 0; $i < 29; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "959e075de765a64e1deda1206408d63812883af6db15075b83dbc81e4ba2bc85";
    }
    const { selected, onSelect, color1, color2 } = t0;
    let T0;
    let T1;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    if ($[1] !== color1 || $[2] !== color2 || $[3] !== onSelect || $[4] !== selected) {
        const splits = DIVISIONS.filter(_DivisionSelectorDIVISIONSFilter);
        const ordinaries = DIVISIONS.filter(_DivisionSelectorDIVISIONSFilter2);
        const renderItem = {
            "DivisionSelector[renderItem]": (div)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    title: div.label,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onClick: {
                            "DivisionSelector[renderItem > <Box>.onClick]": ()=>onSelect(div.id)
                        }["DivisionSelector[renderItem > <Box>.onClick]"],
                        sx: {
                            width: 32,
                            height: 32,
                            cursor: "pointer",
                            border: selected === div.id ? "2px solid" : "2px solid transparent",
                            borderColor: selected === div.id ? "primary.main" : "transparent",
                            borderRadius: 1,
                            overflow: "hidden",
                            "& svg": {
                                width: "100%",
                                height: "100%"
                            }
                        },
                        dangerouslySetInnerHTML: {
                            __html: divisionPreviewSvg(div.id, color1, color2)
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                        lineNumber: 728,
                        columnNumber: 86
                    }, this)
                }, div.id, false, {
                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                    lineNumber: 728,
                    columnNumber: 46
                }, this)
        }["DivisionSelector[renderItem]"];
        T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        t5 = 0.5;
        const t8 = splits.map(renderItem);
        if ($[14] !== t8) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                direction: "row",
                flexWrap: "wrap",
                gap: 0.5,
                children: t8
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                lineNumber: 750,
                columnNumber: 12
            }, this);
            $[14] = t8;
            $[15] = t6;
        } else {
            t6 = $[15];
        }
        if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "caption",
                color: "text.secondary",
                sx: {
                    fontSize: "0.65rem",
                    mt: 0.25
                },
                children: "Bands & Stripes"
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                lineNumber: 757,
                columnNumber: 12
            }, this);
            $[16] = t7;
        } else {
            t7 = $[16];
        }
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        t1 = "row";
        t2 = "wrap";
        t3 = 0.5;
        t4 = ordinaries.map(renderItem);
        $[1] = color1;
        $[2] = color2;
        $[3] = onSelect;
        $[4] = selected;
        $[5] = T0;
        $[6] = T1;
        $[7] = t1;
        $[8] = t2;
        $[9] = t3;
        $[10] = t4;
        $[11] = t5;
        $[12] = t6;
        $[13] = t7;
    } else {
        T0 = $[5];
        T1 = $[6];
        t1 = $[7];
        t2 = $[8];
        t3 = $[9];
        t4 = $[10];
        t5 = $[11];
        t6 = $[12];
        t7 = $[13];
    }
    let t8;
    if ($[17] !== T0 || $[18] !== t1 || $[19] !== t2 || $[20] !== t3 || $[21] !== t4) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            direction: t1,
            flexWrap: t2,
            gap: t3,
            children: t4
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
            lineNumber: 796,
            columnNumber: 10
        }, this);
        $[17] = T0;
        $[18] = t1;
        $[19] = t2;
        $[20] = t3;
        $[21] = t4;
        $[22] = t8;
    } else {
        t8 = $[22];
    }
    let t9;
    if ($[23] !== T1 || $[24] !== t5 || $[25] !== t6 || $[26] !== t7 || $[27] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
            spacing: t5,
            children: [
                t6,
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
            lineNumber: 808,
            columnNumber: 10
        }, this);
        $[23] = T1;
        $[24] = t5;
        $[25] = t6;
        $[26] = t7;
        $[27] = t8;
        $[28] = t9;
    } else {
        t9 = $[28];
    }
    return t9;
}
_c3 = DivisionSelector;
/** 3×3 clickable grid for charge placement */ function _DivisionSelectorDIVISIONSFilter2(d_0) {
    return d_0.group === "ordinary";
}
function _DivisionSelectorDIVISIONSFilter(d) {
    return d.group === "split";
}
function PositionSelector(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "959e075de765a64e1deda1206408d63812883af6db15075b83dbc81e4ba2bc85") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "959e075de765a64e1deda1206408d63812883af6db15075b83dbc81e4ba2bc85";
    }
    const { selected, onSelect } = t0;
    let t1;
    if ($[1] !== onSelect || $[2] !== selected) {
        const rows = [
            [
                "top-left",
                "top",
                "top-right"
            ],
            [
                "left",
                "center",
                "right"
            ],
            [
                "bottom-left",
                "bottom",
                "bottom-right"
            ]
        ];
        let t2;
        if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = {
                display: "inline-grid",
                gridTemplateColumns: "repeat(3, 24px)",
                gap: "3px"
            };
            $[4] = t2;
        } else {
            t2 = $[4];
        }
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t2,
            children: rows.flat().map({
                "PositionSelector[(anonymous)()]": (posId)=>{
                    const pos = POSITIONS.find({
                        "PositionSelector[(anonymous)() > POSITIONS.find()]": (p)=>p.id === posId
                    }["PositionSelector[(anonymous)() > POSITIONS.find()]"]);
                    const isSel = selected === posId;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        title: pos.label,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            onClick: {
                                "PositionSelector[(anonymous)() > <Box>.onClick]": ()=>onSelect(posId)
                            }["PositionSelector[(anonymous)() > <Box>.onClick]"],
                            sx: {
                                width: 24,
                                height: 24,
                                borderRadius: "50%",
                                cursor: "pointer",
                                bgcolor: isSel ? "primary.main" : "action.hover",
                                border: "2px solid",
                                borderColor: isSel ? "primary.dark" : "divider",
                                transition: "background-color 0.15s",
                                "&:hover": {
                                    bgcolor: isSel ? "primary.main" : "action.selected"
                                }
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                            lineNumber: 860,
                            columnNumber: 57
                        }, this)
                    }, posId, false, {
                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                        lineNumber: 860,
                        columnNumber: 18
                    }, this);
                }
            }["PositionSelector[(anonymous)()]"])
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
            lineNumber: 854,
            columnNumber: 10
        }, this);
        $[1] = onSelect;
        $[2] = selected;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    return t1;
}
_c4 = PositionSelector;
// ============================================================================
// Random config generator
// ============================================================================
function randomConfig() {
    const pick = (arr)=>arr[Math.floor(Math.random() * arr.length)];
    const numCharges = pick([
        1,
        1,
        2,
        2,
        3
    ]);
    const charges = Array.from({
        length: numCharges
    }, ()=>({
            chargeId: pick(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$armoriaCharges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHARGES"].filter((c)=>c.id !== 'none')).id,
            chargeColor: pick(COLORS).hex,
            chargePosition: pick(POSITIONS).id,
            chargeScale: pick([
                0.75,
                1,
                1,
                1.25,
                1.5
            ]),
            offsetX: 0,
            offsetY: 0,
            rotation: pick([
                0,
                0,
                0,
                45,
                90,
                180,
                270
            ])
        }));
    const first = charges[0];
    return {
        shape: pick(SHIELD_SHAPES).id,
        fieldColor: pick(COLORS).hex,
        fieldColor2: pick(COLORS).hex,
        division: pick(DIVISIONS).id,
        chargeId: first.chargeId,
        chargeColor: first.chargeColor,
        chargePosition: first.chargePosition,
        chargeScale: first.chargeScale,
        charges
    };
}
// ============================================================================
// Main Component
// ============================================================================
const DEFAULT_CONFIG = {
    shape: 'classic',
    fieldColor: '#1565c0',
    fieldColor2: '#f9a825',
    division: 'none',
    chargeId: 'none',
    chargeColor: '#f9a825',
    chargePosition: 'center',
    chargeScale: 1,
    charges: []
};
function ArmorEditor({ open, squadName, squadDescription = '', initialConfig, onSave, onClose, autoSaveDelay = 1500 }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('components');
    const initialSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ArmorEditor.useMemo[initialSnapshot]": ()=>({
                config: initialConfig ? {
                    ...DEFAULT_CONFIG,
                    ...initialConfig
                } : DEFAULT_CONFIG,
                name: squadName,
                description: squadDescription
            })
    }["ArmorEditor.useMemo[initialSnapshot]"], [
        initialConfig,
        squadName,
        squadDescription
    ]);
    const { snapshot, pushAndUpdate, undo: handleUndo, redo: handleRedo, canUndo, canRedo, reset } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$useArmorUndoRedo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useArmorUndoRedo"])(initialSnapshot);
    const { config, name, description } = snapshot;
    const [activeChargeIndex, setActiveChargeIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const charges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ArmorEditor.useMemo[charges]": ()=>getCharges(config)
    }["ArmorEditor.useMemo[charges]"], [
        config
    ]);
    // Autosave timer ref
    const autoSaveTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const snapshotRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(snapshot);
    snapshotRef.current = snapshot;
    // Reset state when dialog opens
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ArmorEditor.useEffect": ()=>{
            if (open) {
                reset(initialSnapshot);
                setActiveChargeIndex(0);
            }
        }
    }["ArmorEditor.useEffect"], [
        open,
        initialSnapshot,
        reset
    ]);
    // Autosave effect — fires after config/name/description changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ArmorEditor.useEffect": ()=>{
            if (!open || autoSaveDelay <= 0) return;
            if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current);
            autoSaveTimerRef.current = setTimeout({
                "ArmorEditor.useEffect": ()=>{
                    const s = snapshotRef.current;
                    const svg = renderShieldSvg(s.config);
                    onSave(s.config, svg, s.name, s.description);
                }
            }["ArmorEditor.useEffect"], autoSaveDelay);
            return ({
                "ArmorEditor.useEffect": ()=>{
                    if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current);
                }
            })["ArmorEditor.useEffect"];
        }
    }["ArmorEditor.useEffect"], [
        snapshot,
        open,
        autoSaveDelay,
        onSave
    ]);
    // Keyboard shortcuts: Ctrl/Cmd+Z for undo, Ctrl/Cmd+Shift+Z for redo
    // Intercepts EVERYWHERE including in Lexical editors (shared stack)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ArmorEditor.useEffect": ()=>{
            if (!open) return;
            const handleKeyDown = {
                "ArmorEditor.useEffect.handleKeyDown": (e)=>{
                    const isMod = e.metaKey || e.ctrlKey;
                    if (!isMod || e.key.toLowerCase() !== 'z') return;
                    e.preventDefault();
                    if (e.shiftKey) {
                        handleRedo();
                    } else {
                        handleUndo();
                    }
                }
            }["ArmorEditor.useEffect.handleKeyDown"];
            document.addEventListener('keydown', handleKeyDown, true); // capture phase
            return ({
                "ArmorEditor.useEffect": ()=>document.removeEventListener('keydown', handleKeyDown, true)
            })["ArmorEditor.useEffect"];
        }
    }["ArmorEditor.useEffect"], [
        open,
        handleUndo,
        handleRedo
    ]);
    const handleRandomize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ArmorEditor.useCallback[handleRandomize]": ()=>{
            pushAndUpdate({
                "ArmorEditor.useCallback[handleRandomize]": (prev)=>({
                        ...prev,
                        config: randomConfig()
                    })
            }["ArmorEditor.useCallback[handleRandomize]"]);
        }
    }["ArmorEditor.useCallback[handleRandomize]"], [
        pushAndUpdate
    ]);
    const update = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ArmorEditor.useCallback[update]": (partial)=>{
            pushAndUpdate({
                "ArmorEditor.useCallback[update]": (prev_0)=>({
                        ...prev_0,
                        config: {
                            ...prev_0.config,
                            ...partial
                        }
                    })
            }["ArmorEditor.useCallback[update]"]);
        }
    }["ArmorEditor.useCallback[update]"], [
        pushAndUpdate
    ]);
    const addCharge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ArmorEditor.useCallback[addCharge]": ()=>{
            const newCharge = {
                chargeId: 'mullet',
                chargeColor: '#f9a825',
                chargePosition: 'center',
                chargeScale: 1,
                offsetX: 0,
                offsetY: 0,
                rotation: 0
            };
            pushAndUpdate({
                "ArmorEditor.useCallback[addCharge]": (prev_1)=>({
                        ...prev_1,
                        config: {
                            ...prev_1.config,
                            charges: [
                                ...getCharges(prev_1.config),
                                newCharge
                            ]
                        }
                    })
            }["ArmorEditor.useCallback[addCharge]"]);
            setActiveChargeIndex(charges.length);
        }
    }["ArmorEditor.useCallback[addCharge]"], [
        pushAndUpdate,
        charges.length
    ]);
    const removeCharge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ArmorEditor.useCallback[removeCharge]": (index)=>{
            pushAndUpdate({
                "ArmorEditor.useCallback[removeCharge]": (prev_2)=>{
                    const updated = getCharges(prev_2.config).filter({
                        "ArmorEditor.useCallback[removeCharge].updated": (_, i)=>i !== index
                    }["ArmorEditor.useCallback[removeCharge].updated"]);
                    return {
                        ...prev_2,
                        config: {
                            ...prev_2.config,
                            charges: updated
                        }
                    };
                }
            }["ArmorEditor.useCallback[removeCharge]"]);
            setActiveChargeIndex({
                "ArmorEditor.useCallback[removeCharge]": (i_0)=>{
                    const newLen = charges.length - 1;
                    if (newLen <= 0) return 0;
                    return i_0 >= newLen ? newLen - 1 : i_0;
                }
            }["ArmorEditor.useCallback[removeCharge]"]);
        }
    }["ArmorEditor.useCallback[removeCharge]"], [
        pushAndUpdate,
        charges.length
    ]);
    const updateActiveCharge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ArmorEditor.useCallback[updateActiveCharge]": (partial_0)=>{
            pushAndUpdate({
                "ArmorEditor.useCallback[updateActiveCharge]": (prev_3)=>{
                    const current = getCharges(prev_3.config);
                    const updated_0 = current.map({
                        "ArmorEditor.useCallback[updateActiveCharge].updated_0": (ch, i_1)=>i_1 === activeChargeIndex ? {
                                ...ch,
                                ...partial_0
                            } : ch
                    }["ArmorEditor.useCallback[updateActiveCharge].updated_0"]);
                    return {
                        ...prev_3,
                        config: {
                            ...prev_3.config,
                            charges: updated_0
                        }
                    };
                }
            }["ArmorEditor.useCallback[updateActiveCharge]"]);
        }
    }["ArmorEditor.useCallback[updateActiveCharge]"], [
        pushAndUpdate,
        activeChargeIndex
    ]);
    const handleChargeSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ArmorEditor.useCallback[handleChargeSelect]": (chargeId)=>{
            if (charges.length === 0) {
                const newCharge_0 = {
                    chargeId,
                    chargeColor: '#f9a825',
                    chargePosition: 'center',
                    chargeScale: 1,
                    offsetX: 0,
                    offsetY: 0,
                    rotation: 0
                };
                pushAndUpdate({
                    "ArmorEditor.useCallback[handleChargeSelect]": (prev_4)=>({
                            ...prev_4,
                            config: {
                                ...prev_4.config,
                                charges: [
                                    newCharge_0
                                ]
                            }
                        })
                }["ArmorEditor.useCallback[handleChargeSelect]"]);
                setActiveChargeIndex(0);
            } else {
                updateActiveCharge({
                    chargeId
                });
            }
        }
    }["ArmorEditor.useCallback[handleChargeSelect]"], [
        charges.length,
        pushAndUpdate,
        updateActiveCharge
    ]);
    const previewSvg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ArmorEditor.useMemo[previewSvg]": ()=>renderShieldSvg(config)
    }["ArmorEditor.useMemo[previewSvg]"], [
        config
    ]);
    const handleSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ArmorEditor.useCallback[handleSave]": ()=>{
            const chargesList = getCharges(config);
            const first = chargesList[0];
            const savedConfig = {
                ...config,
                charges: chargesList,
                chargeId: first?.chargeId || 'none',
                chargeColor: first?.chargeColor || config.chargeColor,
                chargePosition: first?.chargePosition || 'center',
                chargeScale: first?.chargeScale
            };
            onSave(savedConfig, previewSvg, name, description);
        }
    }["ArmorEditor.useCallback[handleSave]"], [
        config,
        previewSvg,
        onSave,
        name,
        description
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        open: open,
        onClose: onClose,
        maxWidth: "md",
        fullWidth: true,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "Design Coat of Arms — ",
                            name || squadName
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                        lineNumber: 1124,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        direction: "row",
                        spacing: 0.5,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Undo (Ctrl+Z)",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        onClick: handleUndo,
                                        disabled: !canUndo,
                                        size: "small",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Undo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1129,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                        lineNumber: 1128,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                    lineNumber: 1127,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                lineNumber: 1126,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Redo (Ctrl+Shift+Z)",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        onClick: handleRedo,
                                        disabled: !canRedo,
                                        size: "small",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Redo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1136,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                        lineNumber: 1135,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                    lineNumber: 1134,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                lineNumber: 1133,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Randomize",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onClick: handleRandomize,
                                    size: "small",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Casino$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                        lineNumber: 1142,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                    lineNumber: 1141,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                lineNumber: 1140,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                        lineNumber: 1125,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                lineNumber: 1119,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    overflowX: 'hidden',
                    overflowY: 'auto'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        display: 'flex',
                        gap: 3,
                        mt: 1
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                flex: '0 0 200px',
                                position: 'sticky',
                                top: 0,
                                alignSelf: 'flex-start',
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                gap: 2,
                                pt: 1,
                                '& svg': {
                                    width: 200,
                                    height: 200
                                }
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                dangerouslySetInnerHTML: {
                                    __html: previewSvg
                                },
                                role: "img",
                                "aria-label": t('armorEditor.shieldPreview')
                            }, void 0, false, {
                                fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                lineNumber: 1172,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                            lineNumber: 1157,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            spacing: 2,
                            sx: {
                                flex: 1,
                                minWidth: 0
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            variant: "caption",
                                            color: "text.secondary",
                                            children: "Shield Shape"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1184,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShapeSelector, {
                                            shapes: SHIELD_SHAPES,
                                            selected: config.shape,
                                            onSelect: (id)=>update({
                                                    shape: id
                                                })
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1185,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                    lineNumber: 1183,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            variant: "caption",
                                            color: "text.secondary",
                                            children: "Division"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1192,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DivisionSelector, {
                                            selected: config.division,
                                            onSelect: (id_0)=>update({
                                                    division: id_0
                                                }),
                                            color1: config.fieldColor,
                                            color2: config.fieldColor2
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1193,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                    lineNumber: 1191,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            variant: "caption",
                                            color: "text.secondary",
                                            children: "Primary Color"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1200,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            direction: "row",
                                            flexWrap: "wrap",
                                            gap: 0.5,
                                            sx: {
                                                mt: 0.5
                                            },
                                            children: COLORS.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorSwatch, {
                                                    color: c,
                                                    selected: config.fieldColor === c.hex,
                                                    onClick: ()=>update({
                                                            fieldColor: c.hex
                                                        })
                                                }, c.id, false, {
                                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                    lineNumber: 1204,
                                                    columnNumber: 34
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1201,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                    lineNumber: 1199,
                                    columnNumber: 13
                                }, this),
                                config.division !== 'none' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            variant: "caption",
                                            color: "text.secondary",
                                            children: "Secondary Color"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1212,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            direction: "row",
                                            flexWrap: "wrap",
                                            gap: 0.5,
                                            sx: {
                                                mt: 0.5
                                            },
                                            children: COLORS.map((c_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorSwatch, {
                                                    color: c_0,
                                                    selected: config.fieldColor2 === c_0.hex,
                                                    onClick: ()=>update({
                                                            fieldColor2: c_0.hex
                                                        })
                                                }, c_0.id, false, {
                                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                    lineNumber: 1216,
                                                    columnNumber: 38
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1213,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                    lineNumber: 1211,
                                    columnNumber: 44
                                }, this),
                                charges.length > 0 && activeChargeIndex < charges.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            variant: "caption",
                                            color: "text.secondary",
                                            children: "Charge Color"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1224,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            direction: "row",
                                            flexWrap: "wrap",
                                            gap: 0.5,
                                            sx: {
                                                mt: 0.5
                                            },
                                            children: COLORS.map((c_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorSwatch, {
                                                    color: c_1,
                                                    selected: charges[activeChargeIndex].chargeColor === c_1.hex,
                                                    onClick: ()=>updateActiveCharge({
                                                            chargeColor: c_1.hex
                                                        })
                                                }, c_1.id, false, {
                                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                    lineNumber: 1228,
                                                    columnNumber: 38
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1225,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                    lineNumber: 1223,
                                    columnNumber: 74
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            variant: "caption",
                                            color: "text.secondary",
                                            children: charges.length > 0 ? 'Change Charge Type' : 'Add a Charge'
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1236,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ChargeSelector, {
                                            charges: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$armoriaCharges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHARGES"].filter((c_2)=>c_2.id !== 'none'),
                                            selected: charges.length > 0 && activeChargeIndex < charges.length ? charges[activeChargeIndex].chargeId : '',
                                            onSelect: handleChargeSelect
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1239,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                    lineNumber: 1235,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            direction: "row",
                                            alignItems: "center",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    variant: "caption",
                                                    color: "text.secondary",
                                                    children: "Charges"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                    lineNumber: 1245,
                                                    columnNumber: 17
                                                }, this),
                                                charges.length > 0 && charges.length < 5 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    title: "Add another charge",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        size: "small",
                                                        onClick: addCharge,
                                                        "aria-label": t('armorEditor.addCharge'),
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AddCircleOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            fontSize: "small"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1248,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                        lineNumber: 1247,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                    lineNumber: 1246,
                                                    columnNumber: 62
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1244,
                                            columnNumber: 15
                                        }, this),
                                        charges.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            direction: "row",
                                            gap: 0.5,
                                            sx: {
                                                mt: 0.5,
                                                mb: 1
                                            },
                                            children: charges.map((ch_0, i_2)=>{
                                                const entry = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$armoriaCharges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHARGES"].find((c_3)=>c_3.id === ch_0.chargeId);
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    onClick: ()=>setActiveChargeIndex(i_2),
                                                    sx: {
                                                        position: 'relative',
                                                        width: 40,
                                                        height: 40,
                                                        cursor: 'pointer',
                                                        border: '2px solid',
                                                        borderColor: i_2 === activeChargeIndex ? 'primary.main' : 'divider',
                                                        borderRadius: 1,
                                                        bgcolor: i_2 === activeChargeIndex ? 'action.selected' : 'transparent',
                                                        '& svg': {
                                                            width: '100%',
                                                            height: '100%'
                                                        }
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            dangerouslySetInnerHTML: {
                                                                __html: entry?.svgContent ? `<svg viewBox="${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$armoriaCharges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHARGE_VIEWBOX"]}" fill="${ch_0.chargeColor}" stroke="#000">${entry.svgContent}</svg>` : ''
                                                            },
                                                            sx: {
                                                                width: '100%',
                                                                height: '100%'
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1274,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            onClick: (e_0)=>{
                                                                e_0.stopPropagation();
                                                                removeCharge(i_2);
                                                            },
                                                            sx: {
                                                                position: 'absolute',
                                                                top: -6,
                                                                right: -6,
                                                                width: 16,
                                                                height: 16,
                                                                borderRadius: '50%',
                                                                bgcolor: 'error.main',
                                                                color: 'white',
                                                                fontSize: 10,
                                                                lineHeight: '16px',
                                                                textAlign: 'center',
                                                                cursor: 'pointer',
                                                                '&:hover': {
                                                                    bgcolor: 'error.dark'
                                                                }
                                                            },
                                                            role: "button",
                                                            "aria-label": `Remove charge ${i_2 + 1}`,
                                                            children: "×"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1280,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, i_2, true, {
                                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                    lineNumber: 1260,
                                                    columnNumber: 24
                                                }, this);
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1254,
                                            columnNumber: 38
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                    lineNumber: 1243,
                                    columnNumber: 13
                                }, this),
                                charges.length > 0 && activeChargeIndex < charges.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            direction: "row",
                                            gap: 2,
                                            alignItems: "flex-start",
                                            sx: {
                                                '& > *': {
                                                    flex: '1 1 0',
                                                    minWidth: 0
                                                }
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            variant: "caption",
                                                            color: "text.secondary",
                                                            children: "Position"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1316,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            sx: {
                                                                mt: 0.5
                                                            },
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PositionSelector, {
                                                                selected: charges[activeChargeIndex].chargePosition || 'center',
                                                                onSelect: (id_1)=>updateActiveCharge({
                                                                        chargePosition: id_1
                                                                    })
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                                lineNumber: 1320,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1317,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                    lineNumber: 1315,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            variant: "caption",
                                                            color: "text.secondary",
                                                            children: "Size"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1326,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            value: charges[activeChargeIndex].chargeScale ?? 1,
                                                            onChange: (__0, v)=>updateActiveCharge({
                                                                    chargeScale: v
                                                                }),
                                                            min: 0.5,
                                                            max: 2,
                                                            step: 0.25,
                                                            marks: [
                                                                {
                                                                    value: 0.5,
                                                                    label: 'S'
                                                                },
                                                                {
                                                                    value: 1,
                                                                    label: 'M'
                                                                },
                                                                {
                                                                    value: 2,
                                                                    label: 'L'
                                                                }
                                                            ],
                                                            size: "small",
                                                            sx: {
                                                                mt: 1.5
                                                            },
                                                            "aria-label": t('armorEditor.chargeSize')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1327,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                    lineNumber: 1325,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            variant: "caption",
                                                            color: "text.secondary",
                                                            children: "Rotation"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1343,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            value: charges[activeChargeIndex].rotation ?? 0,
                                                            onChange: (__1, v_0)=>updateActiveCharge({
                                                                    rotation: v_0
                                                                }),
                                                            min: 0,
                                                            max: 315,
                                                            step: 45,
                                                            marks: [
                                                                {
                                                                    value: 0,
                                                                    label: '0°'
                                                                },
                                                                {
                                                                    value: 180,
                                                                    label: '180°'
                                                                }
                                                            ],
                                                            size: "small",
                                                            valueLabelDisplay: "auto",
                                                            valueLabelFormat: (v_1)=>`${v_1}°`,
                                                            sx: {
                                                                mt: 1.5
                                                            },
                                                            "aria-label": t('armorEditor.chargeRotation')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1344,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                    lineNumber: 1342,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1309,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            direction: "row",
                                            gap: 2,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    sx: {
                                                        flex: 1
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            variant: "caption",
                                                            color: "text.secondary",
                                                            children: "X Offset"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1361,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            value: charges[activeChargeIndex].offsetX ?? 0,
                                                            onChange: (__2, v_2)=>updateActiveCharge({
                                                                    offsetX: v_2
                                                                }),
                                                            min: -50,
                                                            max: 50,
                                                            step: 1,
                                                            size: "small",
                                                            valueLabelDisplay: "auto",
                                                            "aria-label": t('armorEditor.xOffset')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1362,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                    lineNumber: 1358,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    sx: {
                                                        flex: 1
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            variant: "caption",
                                                            color: "text.secondary",
                                                            children: "Y Offset"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1369,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$Slider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            value: charges[activeChargeIndex].offsetY ?? 0,
                                                            onChange: (__3, v_3)=>updateActiveCharge({
                                                                    offsetY: v_3
                                                                }),
                                                            min: -50,
                                                            max: 50,
                                                            step: 1,
                                                            size: "small",
                                                            valueLabelDisplay: "auto",
                                                            "aria-label": t('armorEditor.yOffset')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                            lineNumber: 1370,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                                    lineNumber: 1366,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                                            lineNumber: 1357,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                            lineNumber: 1178,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                    lineNumber: 1151,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                lineNumber: 1147,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "caption",
                        color: "text.secondary",
                        sx: {
                            mr: 'auto',
                            ml: 1
                        },
                        children: autoSaveDelay > 0 ? 'Auto-saving…' : ''
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                        lineNumber: 1380,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onClick: onClose,
                        children: "Cancel"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                        lineNumber: 1386,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onClick: handleSave,
                        variant: "contained",
                        children: "Save Coat of Arms"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                        lineNumber: 1387,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
                lineNumber: 1379,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Gamification/ArmorEditor.tsx",
        lineNumber: 1118,
        columnNumber: 10
    }, this);
}
_s(ArmorEditor, "jonUUm5q5O3mqpMs8AOovPOyKsY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$useArmorUndoRedo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useArmorUndoRedo"]
    ];
});
_c5 = ArmorEditor;
const __TURBOPACK__default__export__ = ArmorEditor;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "ColorSwatch");
__turbopack_context__.k.register(_c1, "ShapeSelector");
__turbopack_context__.k.register(_c2, "ChargeSelector");
__turbopack_context__.k.register(_c3, "DivisionSelector");
__turbopack_context__.k.register(_c4, "PositionSelector");
__turbopack_context__.k.register(_c5, "ArmorEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/StreakIndicator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StreakIndicator",
    ()=>StreakIndicator,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Whatshot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/Whatshot.js [app-client] (ecmascript)");
;
;
;
;
;
function StreakIndicator(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "700b8575d501765cf593de108b4ac6f0b759a6cf6fd818c693b9111349a06c38") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "700b8575d501765cf593de108b4ac6f0b759a6cf6fd818c693b9111349a06c38";
    }
    const { currentStreak, size: t1 } = t0;
    const size = t1 === undefined ? "medium" : t1;
    if (currentStreak <= 0) {
        return null;
    }
    const isMilestone = currentStreak >= 7;
    const isSmall = size === "small";
    let t2;
    if ($[1] !== isMilestone) {
        t2 = isMilestone && {
            filter: "drop-shadow(0 0 6px rgba(255,152,0,0.6))",
            animation: "pulse 2s ease-in-out infinite",
            "@keyframes pulse": {
                "0%, 100%": {
                    filter: "drop-shadow(0 0 6px rgba(255,152,0,0.6))"
                },
                "50%": {
                    filter: "drop-shadow(0 0 12px rgba(255,152,0,0.9))"
                }
            }
        };
        $[1] = isMilestone;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== t2) {
        t3 = {
            display: "inline-flex",
            alignItems: "center",
            gap: 0.5,
            ...t2
        };
        $[3] = t2;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const t4 = isMilestone ? "#ff6d00" : "#ff9800";
    const t5 = isSmall ? "1rem" : "1.25rem";
    let t6;
    if ($[5] !== t4 || $[6] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Whatshot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                color: t4,
                fontSize: t5
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/StreakIndicator.tsx",
            lineNumber: 73,
            columnNumber: 10
        }, this);
        $[5] = t4;
        $[6] = t5;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    const t7 = isSmall ? "caption" : "body2";
    let t8;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            fontWeight: 700,
            color: "text.primary"
        };
        $[8] = t8;
    } else {
        t8 = $[8];
    }
    let t9;
    if ($[9] !== currentStreak || $[10] !== t7) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: t7,
            sx: t8,
            children: currentStreak
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/StreakIndicator.tsx",
            lineNumber: 96,
            columnNumber: 10
        }, this);
        $[9] = currentStreak;
        $[10] = t7;
        $[11] = t9;
    } else {
        t9 = $[11];
    }
    let t10;
    if ($[12] !== t3 || $[13] !== t6 || $[14] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t6,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/StreakIndicator.tsx",
            lineNumber: 105,
            columnNumber: 11
        }, this);
        $[12] = t3;
        $[13] = t6;
        $[14] = t9;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    return t10;
}
_c = StreakIndicator;
const __TURBOPACK__default__export__ = StreakIndicator;
var _c;
__turbopack_context__.k.register(_c, "StreakIndicator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/HomeworkXPSummary.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HomeworkXPSummary",
    ()=>HomeworkXPSummary,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/xpCalculation.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
function XPLineItem(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "f66619871d7b65f15757553e6ace1a5fc20784fa3e70ec70272ce5081f859577") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f66619871d7b65f15757553e6ace1a5fc20784fa3e70ec70272ce5081f859577";
    }
    const { label, xp } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            display: "flex",
            justifyContent: "space-between"
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== label) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            children: label
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
            lineNumber: 51,
            columnNumber: 10
        }, this);
        $[2] = label;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] !== xp) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            fontWeight: 600,
            color: "success.main",
            children: [
                "+",
                xp,
                " XP"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
            lineNumber: 59,
            columnNumber: 10
        }, this);
        $[4] = xp;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== t2 || $[7] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t1,
            children: [
                t2,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
            lineNumber: 67,
            columnNumber: 10
        }, this);
        $[6] = t2;
        $[7] = t3;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    return t4;
}
_c = XPLineItem;
function HomeworkXPSummary(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(24);
    if ($[0] !== "f66619871d7b65f15757553e6ace1a5fc20784fa3e70ec70272ce5081f859577") {
        for(let $i = 0; $i < 24; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f66619871d7b65f15757553e6ace1a5fc20784fa3e70ec70272ce5081f859577";
    }
    const { lineItems, totalXP, cumulativeXP } = t0;
    let t1;
    if ($[1] !== cumulativeXP) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$xpCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLevelInfo"])(cumulativeXP);
        $[1] = cumulativeXP;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const levelInfo = t1;
    let t2;
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            border: "2px solid",
            borderColor: "success.main",
            p: 3
        };
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h6",
            fontWeight: 700,
            children: "🏁 Homework Complete!"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
            lineNumber: 106,
            columnNumber: 10
        }, this);
        $[3] = t2;
        $[4] = t3;
    } else {
        t2 = $[3];
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                my: 2
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
            lineNumber: 115,
            columnNumber: 10
        }, this);
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== lineItems) {
        t5 = lineItems.map(_HomeworkXPSummaryLineItemsMap);
        $[6] = lineItems;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            spacing: 1,
            children: t5
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
            lineNumber: 132,
            columnNumber: 10
        }, this);
        $[8] = t5;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                my: 2
            }
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
            lineNumber: 140,
            columnNumber: 10
        }, this);
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    let t8;
    if ($[11] !== totalXP) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h5",
            fontWeight: 700,
            color: "success.main",
            children: [
                "Total: +",
                totalXP,
                " XP"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
            lineNumber: 149,
            columnNumber: 10
        }, this);
        $[11] = totalXP;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    const t9 = levelInfo.progress * 100;
    let t10;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            mt: 2,
            height: 10,
            borderRadius: 5
        };
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "determinate",
            value: t9,
            sx: t10
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
            lineNumber: 169,
            columnNumber: 11
        }, this);
        $[14] = t9;
        $[15] = t11;
    } else {
        t11 = $[15];
    }
    const t12 = (levelInfo.xpForNextLevel ?? 0) - (cumulativeXP - levelInfo.xpRequired);
    const t13 = levelInfo.level + 1;
    let t14;
    if ($[16] !== t12 || $[17] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "text.secondary",
            children: [
                t12,
                " XP to Level ",
                t13
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
            lineNumber: 179,
            columnNumber: 11
        }, this);
        $[16] = t12;
        $[17] = t13;
        $[18] = t14;
    } else {
        t14 = $[18];
    }
    let t15;
    if ($[19] !== t11 || $[20] !== t14 || $[21] !== t6 || $[22] !== t8) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t2,
            children: [
                t3,
                t4,
                t6,
                t7,
                t8,
                t11,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
            lineNumber: 188,
            columnNumber: 11
        }, this);
        $[19] = t11;
        $[20] = t14;
        $[21] = t6;
        $[22] = t8;
        $[23] = t15;
    } else {
        t15 = $[23];
    }
    return t15;
}
_c1 = HomeworkXPSummary;
function _HomeworkXPSummaryLineItemsMap(item, index) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(XPLineItem, {
        label: item.label,
        xp: item.xp
    }, index, false, {
        fileName: "[project]/src/components/Gamification/HomeworkXPSummary.tsx",
        lineNumber: 200,
        columnNumber: 10
    }, this);
}
const __TURBOPACK__default__export__ = HomeworkXPSummary;
var _c, _c1;
__turbopack_context__.k.register(_c, "XPLineItem");
__turbopack_context__.k.register(_c1, "HomeworkXPSummary");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/badgeRegistry.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Badge Registry — Maps each BadgeType to a React Icon component,
 * background style (solid color or gradient), and animation preset.
 *
 * Uses react-icons for the icon library instead of emojis or DiceBear.
 *
 * @module badgeRegistry
 */ __turbopack_context__.s([
    "BADGE_REGISTRY",
    ()=>BADGE_REGISTRY,
    "RARITY_EFFECTS",
    ()=>RARITY_EFFECTS,
    "getAllBadgeTypes",
    ()=>getAllBadgeTypes,
    "getBadgeConfig",
    ()=>getBadgeConfig,
    "getBadgesByCategory",
    ()=>getBadgesByCategory,
    "getBadgesByRarity",
    ()=>getBadgesByRarity
]);
// Game Icons (gi) — rich line-art, great for achievements
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/gi/index.mjs [app-client] (ecmascript)");
;
const BADGE_REGISTRY = {
    // ── Core Achievement Badges ───────────────────────────────────────────
    FIRST_SUBMISSION: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiArcheryTarget"],
        name: "First Submission",
        description: "Submitted your first homework",
        bgColor: "#4caf50",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#66bb6a",
                    position: "0%"
                },
                {
                    color: "#2e7d32",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        category: "core",
        rarity: "common"
    },
    GOOD_EYE: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSpyglass"],
        name: "Good Eye",
        description: "Revised work after AI feedback",
        bgColor: "#7c4dff",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#b388ff",
                    position: "0%"
                },
                {
                    color: "#651fff",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        category: "core",
        rarity: "common"
    },
    QUICK_DRAW: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiLightningBow"],
        name: "Quick Draw",
        description: "Submitted before the due date",
        bgColor: "#ff9800",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#ffb74d",
                    position: "0%"
                },
                {
                    color: "#e65100",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "hexagon",
        animation: "bounce-in",
        hoverAnimation: "shake",
        category: "core",
        rarity: "common"
    },
    SHARPSHOOTER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiCrossedSwords"],
        name: "Sharpshooter",
        description: "Scored 90%+ on an assignment",
        bgColor: "#f44336",
        gradient: {
            type: "linear",
            angle: "160deg",
            stops: [
                {
                    color: "#ef5350",
                    position: "0%"
                },
                {
                    color: "#b71c1c",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "shield",
        animation: "draw",
        hoverAnimation: "glow",
        category: "core",
        rarity: "uncommon"
    },
    CONSISTENT: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiCalendar"],
        name: "Consistent",
        description: "Maintained a 7-day streak",
        bgColor: "#2196f3",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#64b5f6",
                    position: "0%"
                },
                {
                    color: "#1565c0",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        category: "core",
        rarity: "uncommon"
    },
    TEAM_PLAYER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiShakingHands"],
        name: "Team Player",
        description: "Completed a peer review",
        bgColor: "#00bcd4",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#4dd0e1",
                    position: "0%"
                },
                {
                    color: "#00838f",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        category: "core",
        rarity: "common"
    },
    DEEP_THINKER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBrain"],
        name: "Deep Thinker",
        description: "Completed all blocks in a unit",
        bgColor: "#9c27b0",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#ce93d8",
                    position: "0%"
                },
                {
                    color: "#6a1b9a",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "glow",
        category: "core",
        rarity: "rare"
    },
    TOP_OF_CLASS: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiLaurelCrown"],
        name: "Top of Class",
        description: "Reached #1 on the leaderboard",
        bgColor: "#ffc107",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#ffd54f",
                    position: "0%"
                },
                {
                    color: "#ff8f00",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "shield",
        animation: "spin-in",
        hoverAnimation: "glow",
        iconScale: 1.1,
        category: "core",
        rarity: "epic"
    },
    PERFECTIONIST: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiCutDiamond"],
        name: "Perfectionist",
        description: "Scored 100% on an assignment",
        bgColor: "#e91e63",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#f48fb1",
                    position: "0%"
                },
                {
                    color: "#880e4f",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "diamond",
        animation: "draw",
        hoverAnimation: "glow",
        category: "core",
        rarity: "epic"
    },
    // ── Avatar Unlock Badges ──────────────────────────────────────────────
    AVATAR_COLORS: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiPalette"],
        name: "Color Unlocked",
        description: "Reached Level 2 — unlock avatar color picker",
        bgColor: "#e91e63",
        gradient: {
            type: "linear",
            angle: "90deg",
            stops: [
                {
                    color: "#f44336",
                    position: "0%"
                },
                {
                    color: "#ff9800",
                    position: "25%"
                },
                {
                    color: "#ffeb3b",
                    position: "50%"
                },
                {
                    color: "#4caf50",
                    position: "75%"
                },
                {
                    color: "#2196f3",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "circle",
        animation: "spin-in",
        hoverAnimation: "pulse",
        category: "avatar",
        rarity: "uncommon"
    },
    AVATAR_DETAILED: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiPaintBrush"],
        name: "New Look",
        description: "Reached Level 3 — unlocked detailed avatar style",
        bgColor: "#3f51b5",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#7986cb",
                    position: "0%"
                },
                {
                    color: "#283593",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "pulse",
        category: "avatar",
        rarity: "uncommon"
    },
    AVATAR_ACCESSORIES: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTopHat"],
        name: "Accessorized",
        description: "Reached Level 4 — unlock avatar accessories",
        bgColor: "#795548",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#a1887f",
                    position: "0%"
                },
                {
                    color: "#4e342e",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "shield",
        animation: "bounce-in",
        hoverAnimation: "shake",
        category: "avatar",
        rarity: "rare"
    },
    AVATAR_PORTRAIT: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiMirrorMirror"],
        name: "Portrait Mode",
        description: "Reached Level 5 — unlocked portrait avatar style & full customizer",
        bgColor: "#9c27b0",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#e1bee7",
                    position: "0%"
                },
                {
                    color: "#4a148c",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "diamond",
        animation: "draw",
        hoverAnimation: "glow",
        category: "avatar",
        rarity: "epic"
    },
    // ── Avatar Powerup Badges ────────────────────────────────────────────
    AVATAR_GLOW: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiRingedPlanet"],
        name: "Glow Ring",
        description: "Level up! — rotating gradient ring around your avatar for 24 hours",
        bgColor: "#7c4dff",
        gradient: {
            type: "linear",
            angle: "90deg",
            stops: [
                {
                    color: "#ff6b6b",
                    position: "0%"
                },
                {
                    color: "#feca57",
                    position: "25%"
                },
                {
                    color: "#48dbfb",
                    position: "50%"
                },
                {
                    color: "#ff9ff3",
                    position: "75%"
                },
                {
                    color: "#ff6b6b",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "circle",
        animation: "spin-in",
        hoverAnimation: "glow",
        category: "avatar",
        rarity: "rare"
    },
    // ── Bot Whisperer Tiered Badges ───────────────────────────────────────
    BOT_WHISPERER_I: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiRobotGolem"],
        name: "Bot Whisperer I",
        description: "Had your first real conversation with the AI tutor",
        bgColor: "#607d8b",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#90a4ae",
                    position: "0%"
                },
                {
                    color: "#37474f",
                    position: "100%"
                }
            ]
        },
        iconColor: "#b0bec5",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "pulse",
        category: "bot-whisperer",
        rarity: "common"
    },
    BOT_WHISPERER_II: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiCyberEye"],
        name: "Bot Whisperer II",
        description: "Earned Deep Thinker — upgraded your bot's style",
        bgColor: "#00acc1",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#4dd0e1",
                    position: "0%"
                },
                {
                    color: "#006064",
                    position: "100%"
                }
            ]
        },
        iconColor: "#e0f7fa",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "glow",
        category: "bot-whisperer",
        rarity: "uncommon"
    },
    BOT_WHISPERER_III: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiArtificialIntelligence"],
        name: "Bot Whisperer III",
        description: "Used AI across 5 units — choose your bot's eyes & mouth",
        bgColor: "#1e88e5",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#42a5f5",
                    position: "0%"
                },
                {
                    color: "#0d47a1",
                    position: "100%"
                }
            ]
        },
        iconColor: "#bbdefb",
        shape: "shield",
        animation: "draw",
        hoverAnimation: "glow",
        category: "bot-whisperer",
        rarity: "rare"
    },
    BOT_WHISPERER_IV: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiCircuitry"],
        name: "Bot Whisperer IV",
        description: "AI mastery achieved — full bot customization unlocked",
        bgColor: "#7c4dff",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#b388ff",
                    position: "0%"
                },
                {
                    color: "#311b92",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ede7f6",
        shape: "diamond",
        animation: "spin-in",
        hoverAnimation: "glow",
        iconScale: 1.1,
        category: "bot-whisperer",
        rarity: "legendary"
    },
    // ── Additional Badges (from Lambda handler) ───────────────────────────
    DRILL_MASTER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiFireShield"],
        name: "Drill Master",
        description: "Completed 10 practice drills",
        bgColor: "#ff5722",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#ff8a65",
                    position: "0%"
                },
                {
                    color: "#bf360c",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "shield",
        animation: "bounce-in",
        hoverAnimation: "shake",
        category: "core",
        rarity: "uncommon"
    },
    COMEBACK_KID: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiReturnArrow"],
        name: "Comeback Kid",
        description: "Returned after a break and got back on track",
        bgColor: "#009688",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#4db6ac",
                    position: "0%"
                },
                {
                    color: "#004d40",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "circle",
        animation: "bounce-in",
        hoverAnimation: "pulse",
        category: "special",
        rarity: "uncommon"
    },
    STREAK_14: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiFire"],
        name: "14-Day Streak",
        description: "Maintained a 14-day activity streak",
        bgColor: "#ff5722",
        gradient: {
            type: "linear",
            angle: "180deg",
            stops: [
                {
                    color: "#ffab91",
                    position: "0%"
                },
                {
                    color: "#ff3d00",
                    position: "50%"
                },
                {
                    color: "#dd2c00",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "glow",
        category: "streak",
        rarity: "rare"
    },
    STREAK_30: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiMountainRoad"],
        name: "30-Day Streak",
        description: "Maintained a 30-day activity streak — legendary commitment",
        bgColor: "#f44336",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#ffd54f",
                    position: "0%"
                },
                {
                    color: "#ff6f00",
                    position: "40%"
                },
                {
                    color: "#e65100",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "shield",
        animation: "spin-in",
        hoverAnimation: "glow",
        iconScale: 1.1,
        category: "streak",
        rarity: "legendary"
    },
    EASTER_EGG_HUNTER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiEggClutch"],
        name: "Easter Egg Hunter",
        description: "Discovered 3 hidden Easter eggs",
        bgColor: "#8bc34a",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#aed581",
                    position: "0%"
                },
                {
                    color: "#33691e",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "circle",
        animation: "bounce-in",
        hoverAnimation: "shake",
        category: "special",
        rarity: "rare"
    },
    NAILED_IT: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiHammerNails"],
        name: "Nailed It",
        description: "Received a perfect AI evaluation on a block",
        bgColor: "#e65100",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#ffab40",
                    position: "0%"
                },
                {
                    color: "#bf360c",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "hexagon",
        animation: "bounce-in",
        hoverAnimation: "shake",
        category: "core",
        rarity: "rare"
    },
    // ── Additional Streak Badges ──────────────────────────────────────────
    STREAK_7: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiAllSeeingEye"],
        name: "7-Day Streak",
        description: "Maintained a 7-day activity streak",
        bgColor: "#2196f3",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#64b5f6",
                    position: "0%"
                },
                {
                    color: "#0d47a1",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        category: "streak",
        rarity: "common"
    },
    // ── Storybook Documentation Promo Badges ──────────────────────────────
    DOCS_EXPLORER: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiSpellBook"],
        name: "Docs Explorer",
        description: "Visited the Storybook documentation and started onboarding",
        bgColor: "#5c6bc0",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#7986cb",
                    position: "0%"
                },
                {
                    color: "#283593",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "circle",
        animation: "draw",
        hoverAnimation: "pulse",
        category: "special",
        rarity: "common"
    },
    INSTRUCTOR_ONBOARD: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTeacher"],
        name: "Instructor Certified",
        description: "Completed the instructor onboarding in Storybook",
        bgColor: "#43a047",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#66bb6a",
                    position: "0%"
                },
                {
                    color: "#1b5e20",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "shield",
        animation: "draw",
        hoverAnimation: "glow",
        category: "special",
        rarity: "uncommon"
    },
    LEARNER_ONBOARD: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiBookCover"],
        name: "Learner Certified",
        description: "Completed the learner onboarding in Storybook",
        bgColor: "#1e88e5",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#42a5f5",
                    position: "0%"
                },
                {
                    color: "#0d47a1",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "glow",
        category: "special",
        rarity: "uncommon"
    },
    TRANSLATOR_ONBOARD: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiEarthAmerica"],
        name: "Translator Certified",
        description: "Completed the translator onboarding in Storybook",
        bgColor: "#00897b",
        gradient: {
            type: "linear",
            angle: "135deg",
            stops: [
                {
                    color: "#4db6ac",
                    position: "0%"
                },
                {
                    color: "#004d40",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "hexagon",
        animation: "draw",
        hoverAnimation: "glow",
        category: "special",
        rarity: "uncommon"
    },
    A11Y_CHAMPION: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiMagnifyingGlass"],
        name: "Accessibility Champion",
        description: "Completed accessibility-related tasks in Storybook",
        bgColor: "#6a1b9a",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#ce93d8",
                    position: "0%"
                },
                {
                    color: "#4a148c",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "diamond",
        animation: "draw",
        hoverAnimation: "glow",
        category: "special",
        rarity: "rare"
    },
    DOCS_CHAMPION: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTrophy"],
        name: "Documentation Champion",
        description: "Completed all onboarding paths — instructor, learner, and translator",
        bgColor: "#f9a825",
        gradient: {
            type: "radial",
            stops: [
                {
                    color: "#fff176",
                    position: "0%"
                },
                {
                    color: "#ff8f00",
                    position: "50%"
                },
                {
                    color: "#e65100",
                    position: "100%"
                }
            ]
        },
        iconColor: "#ffffff",
        shape: "shield",
        animation: "spin-in",
        hoverAnimation: "glow",
        iconScale: 1.1,
        category: "special",
        rarity: "legendary"
    }
};
function getBadgeConfig(badgeType) {
    return BADGE_REGISTRY[badgeType] ?? BADGE_REGISTRY.FIRST_SUBMISSION;
}
function getAllBadgeTypes() {
    return Object.keys(BADGE_REGISTRY);
}
function getBadgesByCategory(category) {
    return Object.entries(BADGE_REGISTRY).filter(([, config])=>config.category === category);
}
function getBadgesByRarity(rarity) {
    return Object.entries(BADGE_REGISTRY).filter(([, config])=>config.rarity === rarity);
}
const RARITY_EFFECTS = {
    common: {
        borderWidth: 1,
        glowColor: "transparent",
        glowIntensity: 0
    },
    uncommon: {
        borderWidth: 1.5,
        glowColor: "rgba(76, 175, 80, 0.3)",
        glowIntensity: 4
    },
    rare: {
        borderWidth: 2,
        glowColor: "rgba(33, 150, 243, 0.4)",
        glowIntensity: 8
    },
    epic: {
        borderWidth: 2.5,
        glowColor: "rgba(156, 39, 176, 0.5)",
        glowIntensity: 12
    },
    legendary: {
        borderWidth: 3,
        glowColor: "rgba(255, 193, 7, 0.6)",
        glowIntensity: 16
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/BadgeIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BadgeIcon",
    ()=>BadgeIcon,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
/**
 * BadgeIcon — Renders a React Icon inside a shaped badge container
 * with animated SVG path drawing, gradient backgrounds, and motion effects.
 *
 * Replaces emoji-based badges with rich, animated, icon-based badges
 * using react-icons + framer-motion.
 *
 * @module BadgeIcon
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$badgeRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/badgeRegistry.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
// Typed wrapper to avoid MUI Box + motion.div type conflicts
const MotionBox = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].create(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
_c = MotionBox;
;
// ============================================================================
// Shape clip paths (SVG viewBox 0 0 100 100)
// ============================================================================
const SHAPE_PATHS = {
    circle: 'M 50,0 A 50,50 0 1,1 50,100 A 50,50 0 1,1 50,0 Z',
    hexagon: 'M 50 0 L 93.3 25 L 93.3 75 L 50 100 L 6.7 75 L 6.7 25 Z',
    shield: 'M 50 0 L 95 15 L 90 60 Q 75 90, 50 100 Q 25 90, 10 60 L 5 15 Z',
    diamond: 'M 50 0 L 100 50 L 50 100 L 0 50 Z'
};
// ============================================================================
// Animation variants
// ============================================================================
const containerVariants = {
    draw: {
        hidden: {
            opacity: 0,
            scale: 0.8
        },
        visible: {
            opacity: 1,
            scale: 1,
            transition: {
                duration: 0.5,
                ease: 'easeOut'
            }
        }
    },
    pulse: {
        hidden: {
            opacity: 0,
            scale: 0.9
        },
        visible: {
            opacity: 1,
            scale: [
                1,
                1.06,
                1
            ],
            transition: {
                duration: 1.2,
                repeat: Infinity,
                repeatDelay: 2
            }
        }
    },
    'spin-in': {
        hidden: {
            opacity: 0,
            rotate: -180,
            scale: 0.5
        },
        visible: {
            opacity: 1,
            rotate: 0,
            scale: 1,
            transition: {
                type: 'spring',
                stiffness: 150,
                damping: 15
            }
        }
    },
    'bounce-in': {
        hidden: {
            opacity: 0,
            y: 20,
            scale: 0.6
        },
        visible: {
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
                type: 'spring',
                stiffness: 300,
                damping: 12
            }
        }
    },
    glow: {
        hidden: {
            opacity: 0,
            scale: 0.9
        },
        visible: {
            opacity: 1,
            scale: 1,
            transition: {
                duration: 0.4
            }
        }
    },
    shake: {
        hidden: {
            opacity: 0
        },
        visible: {
            opacity: 1,
            x: [
                0,
                -4,
                4,
                -4,
                4,
                0
            ],
            transition: {
                duration: 0.5
            }
        }
    },
    none: {
        hidden: {
            opacity: 1
        },
        visible: {
            opacity: 1
        }
    }
};
const hoverVariants = {
    draw: {},
    pulse: {
        scale: 1.08,
        transition: {
            duration: 0.2
        }
    },
    'spin-in': {
        rotate: 15,
        transition: {
            duration: 0.2
        }
    },
    'bounce-in': {
        y: -4,
        transition: {
            type: 'spring',
            stiffness: 400
        }
    },
    glow: {
        scale: 1.05,
        transition: {
            duration: 0.2
        }
    },
    shake: {
        x: [
            0,
            -3,
            3,
            -3,
            3,
            0
        ],
        transition: {
            duration: 0.4
        }
    },
    none: {}
};
function DrawableIcon(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(31);
    if ($[0] !== "4d6862aaa2391c7c5512298c3deee36e70ec8759135e22b6755899a15922a5fb") {
        for(let $i = 0; $i < 31; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4d6862aaa2391c7c5512298c3deee36e70ec8759135e22b6755899a15922a5fb";
    }
    const { Icon, color, size, draw, scale, translate, animationDelay } = t0;
    let t1;
    if ($[1] !== scale || $[2] !== size) {
        t1 = Math.round(size * 0.55 * scale);
        $[1] = scale;
        $[2] = size;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const iconSize = t1;
    const [tx, ty] = translate;
    if (!draw) {
        const t2 = `translate(${tx}px, ${ty}px)`;
        let t3;
        if ($[4] !== color || $[5] !== t2) {
            t3 = {
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                transform: t2,
                color
            };
            $[4] = color;
            $[5] = t2;
            $[6] = t3;
        } else {
            t3 = $[6];
        }
        let t4;
        if ($[7] !== Icon || $[8] !== iconSize) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                size: iconSize
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
                lineNumber: 259,
                columnNumber: 12
            }, this);
            $[7] = Icon;
            $[8] = iconSize;
            $[9] = t4;
        } else {
            t4 = $[9];
        }
        let t5;
        if ($[10] !== t3 || $[11] !== t4) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t3,
                children: t4
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
                lineNumber: 268,
                columnNumber: 12
            }, this);
            $[10] = t3;
            $[11] = t4;
            $[12] = t5;
        } else {
            t5 = $[12];
        }
        return t5;
    }
    const t2 = `translate(${tx}px, ${ty}px)`;
    let t3;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            overflow: "visible"
        };
        $[13] = t3;
    } else {
        t3 = $[13];
    }
    const t4 = `badgeIconDraw 1.2s ease-out ${animationDelay}s forwards, badgeIconFill 0.4s ease-in ${animationDelay + 1}s forwards`;
    let t5;
    if ($[14] !== color || $[15] !== t4) {
        t5 = {
            strokeDasharray: 1000,
            strokeDashoffset: 1000,
            animation: t4,
            stroke: color,
            strokeWidth: 0.5,
            fill: "transparent"
        };
        $[14] = color;
        $[15] = t4;
        $[16] = t5;
    } else {
        t5 = $[16];
    }
    let t6;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            to: {
                strokeDashoffset: 0
            }
        };
        $[17] = t6;
    } else {
        t6 = $[17];
    }
    let t7;
    if ($[18] !== color) {
        t7 = {
            to: {
                fill: color,
                strokeWidth: 0
            }
        };
        $[18] = color;
        $[19] = t7;
    } else {
        t7 = $[19];
    }
    let t8;
    if ($[20] !== color || $[21] !== t2 || $[22] !== t5 || $[23] !== t7) {
        t8 = {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            transform: t2,
            color,
            "& svg": t3,
            "& svg path, & svg circle, & svg rect, & svg line, & svg polyline, & svg polygon, & svg ellipse": t5,
            "@keyframes badgeIconDraw": t6,
            "@keyframes badgeIconFill": t7
        };
        $[20] = color;
        $[21] = t2;
        $[22] = t5;
        $[23] = t7;
        $[24] = t8;
    } else {
        t8 = $[24];
    }
    let t9;
    if ($[25] !== Icon || $[26] !== iconSize) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
            size: iconSize
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
            lineNumber: 351,
            columnNumber: 10
        }, this);
        $[25] = Icon;
        $[26] = iconSize;
        $[27] = t9;
    } else {
        t9 = $[27];
    }
    let t10;
    if ($[28] !== t8 || $[29] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MotionBox, {
            sx: t8,
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
            lineNumber: 360,
            columnNumber: 11
        }, this);
        $[28] = t8;
        $[29] = t9;
        $[30] = t10;
    } else {
        t10 = $[30];
    }
    return t10;
}
_c1 = DrawableIcon;
function GradientDefs(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "4d6862aaa2391c7c5512298c3deee36e70ec8759135e22b6755899a15922a5fb") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4d6862aaa2391c7c5512298c3deee36e70ec8759135e22b6755899a15922a5fb";
    }
    const { id, gradient, bgColor } = t0;
    if (!gradient) {
        let t1;
        let t2;
        if ($[1] !== bgColor) {
            t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                offset: "0%",
                stopColor: bgColor
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
                lineNumber: 396,
                columnNumber: 12
            }, this);
            t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                offset: "100%",
                stopColor: bgColor
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
                lineNumber: 397,
                columnNumber: 12
            }, this);
            $[1] = bgColor;
            $[2] = t1;
            $[3] = t2;
        } else {
            t1 = $[2];
            t2 = $[3];
        }
        let t3;
        if ($[4] !== id || $[5] !== t1 || $[6] !== t2) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: id,
                    children: [
                        t1,
                        t2
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
                    lineNumber: 407,
                    columnNumber: 18
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
                lineNumber: 407,
                columnNumber: 12
            }, this);
            $[4] = id;
            $[5] = t1;
            $[6] = t2;
            $[7] = t3;
        } else {
            t3 = $[7];
        }
        return t3;
    }
    if (gradient.type === "radial") {
        let t1;
        if ($[8] !== gradient.stops) {
            t1 = gradient.stops.map(_GradientDefsGradientStopsMap);
            $[8] = gradient.stops;
            $[9] = t1;
        } else {
            t1 = $[9];
        }
        let t2;
        if ($[10] !== id || $[11] !== t1) {
            t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("radialGradient", {
                    id: id,
                    cx: "50%",
                    cy: "50%",
                    r: "50%",
                    children: t1
                }, void 0, false, {
                    fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
                    lineNumber: 428,
                    columnNumber: 18
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
                lineNumber: 428,
                columnNumber: 12
            }, this);
            $[10] = id;
            $[11] = t1;
            $[12] = t2;
        } else {
            t2 = $[12];
        }
        return t2;
    }
    const angle = parseFloat(gradient.angle || "135") * (Math.PI / 180);
    const x1 = `${50 - Math.cos(angle) * 50}%`;
    const y1 = `${50 - Math.sin(angle) * 50}%`;
    const x2 = `${50 + Math.cos(angle) * 50}%`;
    const y2 = `${50 + Math.sin(angle) * 50}%`;
    let t1;
    if ($[13] !== gradient.stops) {
        t1 = gradient.stops.map(_GradientDefsGradientStopsMap2);
        $[13] = gradient.stops;
        $[14] = t1;
    } else {
        t1 = $[14];
    }
    let t2;
    if ($[15] !== id || $[16] !== t1 || $[17] !== x1 || $[18] !== x2 || $[19] !== y1 || $[20] !== y2) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                id: id,
                x1: x1,
                y1: y1,
                x2: x2,
                y2: y2,
                children: t1
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
                lineNumber: 452,
                columnNumber: 16
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
            lineNumber: 452,
            columnNumber: 10
        }, this);
        $[15] = id;
        $[16] = t1;
        $[17] = x1;
        $[18] = x2;
        $[19] = y1;
        $[20] = y2;
        $[21] = t2;
    } else {
        t2 = $[21];
    }
    return t2;
}
_c2 = GradientDefs;
// ============================================================================
// Main Component
// ============================================================================
function _GradientDefsGradientStopsMap2(stop_0, i_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
        offset: stop_0.position,
        stopColor: stop_0.color
    }, i_0, false, {
        fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
        lineNumber: 470,
        columnNumber: 10
    }, this);
}
function _GradientDefsGradientStopsMap(stop, i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
        offset: stop.position,
        stopColor: stop.color
    }, i, false, {
        fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
        lineNumber: 473,
        columnNumber: 10
    }, this);
}
function BadgeIcon(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(49);
    if ($[0] !== "4d6862aaa2391c7c5512298c3deee36e70ec8759135e22b6755899a15922a5fb") {
        for(let $i = 0; $i < 49; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4d6862aaa2391c7c5512298c3deee36e70ec8759135e22b6755899a15922a5fb";
    }
    const { badgeType, config: configOverride, size: t1, earned: t2, animate: t3, animationDelay: t4, animationOverride, drawIcon: t5, sx: sxProp, onClick } = t0;
    const size = t1 === undefined ? 56 : t1;
    const earned = t2 === undefined ? true : t2;
    const animate = t3 === undefined ? true : t3;
    const animationDelay = t4 === undefined ? 0 : t4;
    const drawIcon = t5 === undefined ? true : t5;
    const gradientId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    let t6;
    if ($[1] !== gradientId) {
        let t7;
        if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = /:/g;
            $[3] = t7;
        } else {
            t7 = $[3];
        }
        t6 = gradientId.replace(t7, "");
        $[1] = gradientId;
        $[2] = t6;
    } else {
        t6 = $[2];
    }
    const cleanGradientId = `badge-grad-${t6}`;
    let t7;
    if ($[4] !== badgeType || $[5] !== configOverride) {
        t7 = configOverride ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$badgeRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBadgeConfig"])(badgeType ?? "FIRST_SUBMISSION");
        $[4] = badgeType;
        $[5] = configOverride;
        $[6] = t7;
    } else {
        t7 = $[6];
    }
    const config = t7;
    const rarityEffect = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$badgeRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RARITY_EFFECTS"][config.rarity];
    const mountAnim = animationOverride ?? config.animation;
    const hoverAnim = config.hoverAnimation ?? "pulse";
    const shapePath = SHAPE_PATHS[config.shape];
    const filterStyle = earned ? undefined : "grayscale(100%) opacity(0.4)";
    let t8;
    bb0: {
        if (!earned || rarityEffect.glowIntensity === 0) {
            t8 = "none";
            break bb0;
        }
        t8 = `0 0 ${rarityEffect.glowIntensity}px ${rarityEffect.glowColor}`;
    }
    const glowShadow = t8;
    const t9 = animate && earned ? containerVariants[mountAnim] : containerVariants.none;
    const t10 = animate && earned ? "hidden" : "visible";
    const t11 = earned ? hoverVariants[hoverAnim] : undefined;
    let t12;
    if ($[7] !== animationDelay) {
        t12 = {
            delay: animationDelay
        };
        $[7] = animationDelay;
        $[8] = t12;
    } else {
        t12 = $[8];
    }
    const t13 = onClick ? "pointer" : "default";
    let t14;
    if ($[9] !== filterStyle || $[10] !== size || $[11] !== sxProp || $[12] !== t13) {
        t14 = {
            width: size,
            height: size,
            position: "relative",
            cursor: t13,
            filter: filterStyle,
            ...sxProp
        };
        $[9] = filterStyle;
        $[10] = size;
        $[11] = sxProp;
        $[12] = t13;
        $[13] = t14;
    } else {
        t14 = $[13];
    }
    const t15 = `drop-shadow(${glowShadow})`;
    let t16;
    if ($[14] !== t15) {
        t16 = {
            position: "absolute",
            top: 0,
            left: 0,
            filter: t15
        };
        $[14] = t15;
        $[15] = t16;
    } else {
        t16 = $[15];
    }
    let t17;
    if ($[16] !== cleanGradientId || $[17] !== config.bgColor || $[18] !== config.gradient) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(GradientDefs, {
            id: cleanGradientId,
            gradient: config.gradient,
            bgColor: config.bgColor
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
            lineNumber: 589,
            columnNumber: 11
        }, this);
        $[16] = cleanGradientId;
        $[17] = config.bgColor;
        $[18] = config.gradient;
        $[19] = t17;
    } else {
        t17 = $[19];
    }
    const t18 = `url(#${cleanGradientId})`;
    const t19 = earned ? "rgba(255,255,255,0.3)" : "rgba(0,0,0,0.1)";
    let t20;
    if ($[20] !== rarityEffect.borderWidth || $[21] !== shapePath || $[22] !== t18 || $[23] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: shapePath,
            fill: t18,
            stroke: t19,
            strokeWidth: rarityEffect.borderWidth
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
            lineNumber: 601,
            columnNumber: 11
        }, this);
        $[20] = rarityEffect.borderWidth;
        $[21] = shapePath;
        $[22] = t18;
        $[23] = t19;
        $[24] = t20;
    } else {
        t20 = $[24];
    }
    let t21;
    if ($[25] !== size || $[26] !== t16 || $[27] !== t17 || $[28] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 100 100",
            width: size,
            height: size,
            style: t16,
            children: [
                t17,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
            lineNumber: 612,
            columnNumber: 11
        }, this);
        $[25] = size;
        $[26] = t16;
        $[27] = t17;
        $[28] = t20;
        $[29] = t21;
    } else {
        t21 = $[29];
    }
    let t22;
    if ($[30] !== animate || $[31] !== animationDelay || $[32] !== config.icon || $[33] !== config.iconColor || $[34] !== config.iconScale || $[35] !== config.iconTranslate || $[36] !== drawIcon || $[37] !== earned || $[38] !== size) {
        t22 = earned && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DrawableIcon, {
                Icon: config.icon,
                color: config.iconColor,
                size: size,
                draw: animate && drawIcon,
                scale: config.iconScale ?? 1,
                translate: config.iconTranslate ?? [
                    0,
                    0
                ],
                animationDelay: animationDelay + 0.3
            }, void 0, false, {
                fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
                lineNumber: 632,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
            lineNumber: 623,
            columnNumber: 21
        }, this);
        $[30] = animate;
        $[31] = animationDelay;
        $[32] = config.icon;
        $[33] = config.iconColor;
        $[34] = config.iconScale;
        $[35] = config.iconTranslate;
        $[36] = drawIcon;
        $[37] = earned;
        $[38] = size;
        $[39] = t22;
    } else {
        t22 = $[39];
    }
    let t23;
    if ($[40] !== onClick || $[41] !== t10 || $[42] !== t11 || $[43] !== t12 || $[44] !== t14 || $[45] !== t21 || $[46] !== t22 || $[47] !== t9) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MotionBox, {
            variants: t9,
            initial: t10,
            animate: "visible",
            whileHover: t11,
            transition: t12,
            onClick: onClick,
            sx: t14,
            children: [
                t21,
                t22
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/BadgeIcon.tsx",
            lineNumber: 648,
            columnNumber: 11
        }, this);
        $[40] = onClick;
        $[41] = t10;
        $[42] = t11;
        $[43] = t12;
        $[44] = t14;
        $[45] = t21;
        $[46] = t22;
        $[47] = t9;
        $[48] = t23;
    } else {
        t23 = $[48];
    }
    return t23;
}
_s(BadgeIcon, "LGfpeXvmIQWhO5jB01SBAYzTKJw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c3 = BadgeIcon;
const __TURBOPACK__default__export__ = BadgeIcon;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "MotionBox");
__turbopack_context__.k.register(_c1, "DrawableIcon");
__turbopack_context__.k.register(_c2, "GradientDefs");
__turbopack_context__.k.register(_c3, "BadgeIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Gamification/PersonalBestBanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PersonalBestBanner",
    ()=>PersonalBestBanner,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Collapse/Collapse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Gamification/BadgeIcon.tsx [app-client] (ecmascript)");
;
;
;
;
;
;
function PersonalBestBanner(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23);
    if ($[0] !== "5eec0e136788c6a03ab10a2d5abe374c6adf6e97f180c748272851fe5d41a195") {
        for(let $i = 0; $i < 23; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5eec0e136788c6a03ab10a2d5abe374c6adf6e97f180c748272851fe5d41a195";
    }
    const { open, newScore, previousBest, onClose } = t0;
    let t1;
    if ($[1] !== newScore || $[2] !== previousBest) {
        t1 = previousBest != null ? Math.round(newScore - previousBest) : null;
        $[1] = newScore;
        $[2] = previousBest;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const improvement = t1;
    let t2;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Gamification$2f$BadgeIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            badgeType: "TOP_OF_CLASS",
            size: 32,
            earned: true,
            animate: true
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/PersonalBestBanner.tsx",
            lineNumber: 45,
            columnNumber: 10
        }, this);
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            fontWeight: 600,
            border: "2px solid",
            borderColor: "warning.main",
            mb: 2
        };
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle2",
            fontWeight: 700,
            children: "New Personal Best! 🏆"
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/PersonalBestBanner.tsx",
            lineNumber: 59,
            columnNumber: 10
        }, this);
        $[5] = t3;
        $[6] = t4;
    } else {
        t3 = $[5];
        t4 = $[6];
    }
    let t5;
    if ($[7] !== newScore) {
        t5 = Math.round(newScore);
        $[7] = newScore;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] !== improvement) {
        t6 = improvement != null && improvement > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                " — up ",
                improvement,
                " points from your previous best!"
            ]
        }, void 0, true);
        $[9] = improvement;
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    let t7;
    if ($[11] !== previousBest) {
        t7 = previousBest == null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: " — first recorded score for this unit!"
        }, void 0, false);
        $[11] = previousBest;
        $[12] = t7;
    } else {
        t7 = $[12];
    }
    let t8;
    if ($[13] !== t5 || $[14] !== t6 || $[15] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            children: [
                "Score: ",
                t5,
                "%",
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/PersonalBestBanner.tsx",
            lineNumber: 92,
            columnNumber: 10
        }, this);
        $[13] = t5;
        $[14] = t6;
        $[15] = t7;
        $[16] = t8;
    } else {
        t8 = $[16];
    }
    let t9;
    if ($[17] !== onClose || $[18] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            severity: "success",
            icon: t2,
            onClose: onClose,
            sx: t3,
            children: [
                t4,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Gamification/PersonalBestBanner.tsx",
            lineNumber: 102,
            columnNumber: 10
        }, this);
        $[17] = onClose;
        $[18] = t8;
        $[19] = t9;
    } else {
        t9 = $[19];
    }
    let t10;
    if ($[20] !== open || $[21] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Collapse$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            in: open,
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/components/Gamification/PersonalBestBanner.tsx",
            lineNumber: 111,
            columnNumber: 11
        }, this);
        $[20] = open;
        $[21] = t9;
        $[22] = t10;
    } else {
        t10 = $[22];
    }
    return t10;
}
_c = PersonalBestBanner;
const __TURBOPACK__default__export__ = PersonalBestBanner;
var _c;
__turbopack_context__.k.register(_c, "PersonalBestBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_Gamification_10itoqm._.js.map