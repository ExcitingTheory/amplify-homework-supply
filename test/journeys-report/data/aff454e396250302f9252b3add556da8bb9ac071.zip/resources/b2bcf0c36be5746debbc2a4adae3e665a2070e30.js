(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StorageValidationErrorCode",
    ()=>StorageValidationErrorCode,
    "validationErrorMap",
    ()=>validationErrorMap
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
var StorageValidationErrorCode;
(function(StorageValidationErrorCode) {
    StorageValidationErrorCode["NoCredentials"] = "NoCredentials";
    StorageValidationErrorCode["NoIdentityId"] = "NoIdentityId";
    StorageValidationErrorCode["NoKey"] = "NoKey";
    StorageValidationErrorCode["NoSourceKey"] = "NoSourceKey";
    StorageValidationErrorCode["NoDestinationKey"] = "NoDestinationKey";
    StorageValidationErrorCode["NoSourcePath"] = "NoSourcePath";
    StorageValidationErrorCode["NoDestinationPath"] = "NoDestinationPath";
    StorageValidationErrorCode["NoBucket"] = "NoBucket";
    StorageValidationErrorCode["NoRegion"] = "NoRegion";
    StorageValidationErrorCode["InvalidStorageBucket"] = "InvalidStorageBucket";
    StorageValidationErrorCode["InvalidCopyOperationStorageBucket"] = "InvalidCopyOperationStorageBucket";
    StorageValidationErrorCode["InvalidStorageOperationPrefixInput"] = "InvalidStorageOperationPrefixInput";
    StorageValidationErrorCode["InvalidStorageOperationInput"] = "InvalidStorageOperationInput";
    StorageValidationErrorCode["InvalidAWSAccountID"] = "InvalidAWSAccountID";
    StorageValidationErrorCode["InvalidStoragePathInput"] = "InvalidStoragePathInput";
    StorageValidationErrorCode["InvalidUploadSource"] = "InvalidUploadSource";
    StorageValidationErrorCode["ObjectIsTooLarge"] = "ObjectIsTooLarge";
    StorageValidationErrorCode["UrlExpirationMaxLimitExceed"] = "UrlExpirationMaxLimitExceed";
    StorageValidationErrorCode["InvalidLocationCredentialsCacheSize"] = "InvalidLocationCredentialsCacheSize";
    StorageValidationErrorCode["LocationCredentialsStoreDestroyed"] = "LocationCredentialsStoreDestroyed";
    StorageValidationErrorCode["InvalidS3Uri"] = "InvalidS3Uri";
    StorageValidationErrorCode["InvalidCustomEndpoint"] = "InvalidCustomEndpoint";
    StorageValidationErrorCode["ForcePathStyleEndpointNotSupported"] = "ForcePathStyleEndpointNotSupported";
    StorageValidationErrorCode["DnsIncompatibleBucketName"] = "DnsIncompatibleBucketName";
})(StorageValidationErrorCode || (StorageValidationErrorCode = {}));
const validationErrorMap = {
    [StorageValidationErrorCode.NoCredentials]: {
        message: 'Credentials should not be empty.'
    },
    [StorageValidationErrorCode.NoIdentityId]: {
        message: 'Missing identity ID when accessing objects in protected or private access level.'
    },
    [StorageValidationErrorCode.NoKey]: {
        message: 'Missing key in api call.'
    },
    [StorageValidationErrorCode.NoSourceKey]: {
        message: 'Missing source key in copy api call.'
    },
    [StorageValidationErrorCode.NoDestinationKey]: {
        message: 'Missing destination key in copy api call.'
    },
    [StorageValidationErrorCode.NoSourcePath]: {
        message: 'Missing source path in copy api call.'
    },
    [StorageValidationErrorCode.NoDestinationPath]: {
        message: 'Missing destination path in copy api call.'
    },
    [StorageValidationErrorCode.NoBucket]: {
        message: 'Missing bucket name while accessing object.'
    },
    [StorageValidationErrorCode.NoRegion]: {
        message: 'Missing region while accessing object.'
    },
    [StorageValidationErrorCode.UrlExpirationMaxLimitExceed]: {
        message: 'Url Expiration can not be greater than 7 Days.'
    },
    [StorageValidationErrorCode.ObjectIsTooLarge]: {
        message: 'Object size cannot not be greater than 5TB.'
    },
    [StorageValidationErrorCode.InvalidUploadSource]: {
        message: 'Upload source type can only be a `Blob`, `File`, `ArrayBuffer`, or `string`.'
    },
    [StorageValidationErrorCode.InvalidStorageOperationInput]: {
        message: 'Path or key parameter must be specified in the input. Both can not be specified at the same time.'
    },
    [StorageValidationErrorCode.InvalidAWSAccountID]: {
        message: 'Invalid AWS account ID was provided.'
    },
    [StorageValidationErrorCode.InvalidStorageOperationPrefixInput]: {
        message: 'Both path and prefix can not be specified at the same time.'
    },
    [StorageValidationErrorCode.InvalidStoragePathInput]: {
        message: 'Input `path` does not allow a leading slash (/).'
    },
    [StorageValidationErrorCode.InvalidLocationCredentialsCacheSize]: {
        message: 'locationCredentialsCacheSize must be a positive integer.'
    },
    [StorageValidationErrorCode.LocationCredentialsStoreDestroyed]: {
        message: `Location-specific credentials store has been destroyed.`
    },
    [StorageValidationErrorCode.InvalidS3Uri]: {
        message: 'Invalid S3 URI.'
    },
    [StorageValidationErrorCode.InvalidStorageBucket]: {
        message: 'Unable to lookup bucket from provided name in Amplify configuration.'
    },
    [StorageValidationErrorCode.InvalidCopyOperationStorageBucket]: {
        message: 'Missing bucket option in either source or destination.'
    },
    [StorageValidationErrorCode.InvalidCustomEndpoint]: {
        message: 'Invalid S3 custom endpoint.'
    },
    [StorageValidationErrorCode.ForcePathStyleEndpointNotSupported]: {
        message: 'Path style URLs are not supported with S3 Transfer Acceleration.'
    },
    [StorageValidationErrorCode.DnsIncompatibleBucketName]: {
        message: `The bucket name isn't DNS compatible.`
    }
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/errors/StorageError.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StorageError",
    ()=>StorageError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$errors$2f$AmplifyError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/errors/AmplifyError.mjs [app-client] (ecmascript)");
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
class StorageError extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$errors$2f$AmplifyError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyError"] {
    constructor(params){
        super(params);
        // TODO: Delete the following 2 lines after we change the build target to >= es2015
        this.constructor = StorageError;
        Object.setPrototypeOf(this, StorageError.prototype);
    }
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/errors/utils/assertValidationError.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "assertValidationError",
    ()=>assertValidationError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/StorageError.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function assertValidationError(assertion, name) {
    const { message, recoverySuggestion } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validationErrorMap"][name];
    if (!assertion) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"]({
            name,
            message,
            recoverySuggestion
        });
    }
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CHECKSUM_ALGORITHM_CRC32",
    ()=>CHECKSUM_ALGORITHM_CRC32,
    "DEFAULT_ACCESS_LEVEL",
    ()=>DEFAULT_ACCESS_LEVEL,
    "DEFAULT_DELIMITER",
    ()=>DEFAULT_DELIMITER,
    "DEFAULT_PART_SIZE",
    ()=>DEFAULT_PART_SIZE,
    "DEFAULT_PRESIGN_EXPIRATION",
    ()=>DEFAULT_PRESIGN_EXPIRATION,
    "DEFAULT_QUEUE_SIZE",
    ()=>DEFAULT_QUEUE_SIZE,
    "LOCAL_TESTING_S3_ENDPOINT",
    ()=>LOCAL_TESTING_S3_ENDPOINT,
    "MAX_OBJECT_SIZE",
    ()=>MAX_OBJECT_SIZE,
    "MAX_PARTS_COUNT",
    ()=>MAX_PARTS_COUNT,
    "MAX_URL_EXPIRATION",
    ()=>MAX_URL_EXPIRATION,
    "STORAGE_INPUT_KEY",
    ()=>STORAGE_INPUT_KEY,
    "STORAGE_INPUT_PATH",
    ()=>STORAGE_INPUT_PATH,
    "STORAGE_INPUT_PREFIX",
    ()=>STORAGE_INPUT_PREFIX,
    "UPLOADS_STORAGE_KEY",
    ()=>UPLOADS_STORAGE_KEY
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const LOCAL_TESTING_S3_ENDPOINT = 'http://localhost:20005';
const DEFAULT_ACCESS_LEVEL = 'guest';
const DEFAULT_PRESIGN_EXPIRATION = 900;
const MAX_URL_EXPIRATION = 7 * 24 * 60 * 60 * 1000;
const MiB = 1024 * 1024;
const GiB = 1024 * MiB;
const TiB = 1024 * GiB;
/**
 * Default part size in MB that is used to determine if an upload task is single part or multi part.
 */ const DEFAULT_PART_SIZE = 5 * MiB;
const MAX_OBJECT_SIZE = 5 * TiB;
const MAX_PARTS_COUNT = 10000;
const DEFAULT_QUEUE_SIZE = 4;
const UPLOADS_STORAGE_KEY = '__uploadInProgress';
const STORAGE_INPUT_PREFIX = 'prefix';
const STORAGE_INPUT_KEY = 'key';
const STORAGE_INPUT_PATH = 'path';
const DEFAULT_DELIMITER = '/';
const CHECKSUM_ALGORITHM_CRC32 = 'crc-32';
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/errors/CanceledError.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CanceledError",
    ()=>CanceledError,
    "isCancelError",
    ()=>isCancelError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/StorageError.mjs [app-client] (ecmascript)");
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Internal-only class for CanceledError thrown by XHR handler or multipart upload when cancellation is invoked
 * without overwriting behavior.
 *
 * @internal
 */ class CanceledError extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"] {
    constructor(params = {}){
        super({
            name: 'CanceledError',
            message: 'Upload is canceled by user',
            ...params
        });
        // TODO: Delete the following 2 lines after we change the build target to >= es2015
        this.constructor = CanceledError;
        Object.setPrototypeOf(this, CanceledError.prototype);
    }
}
/**
 * Check if an error is caused by user calling `cancel()` on a upload/download task. If an overwriting error is
 * supplied to `task.cancel(errorOverwrite)`, this function will return `false`.
 * @param {unknown} error The unknown exception to be checked.
 * @returns - A boolean indicating if the error was from an upload cancellation
 */ const isCancelError = (error)=>!!error && error instanceof CanceledError;
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/utils/logger.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "logger",
    ()=>logger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Logger$2f$ConsoleLogger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Logger/ConsoleLogger.mjs [app-client] (ecmascript)");
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const logger = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Logger$2f$ConsoleLogger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConsoleLogger"]('Storage');
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/transferTask.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createDownloadTask",
    ()=>createDownloadTask,
    "createUploadTask",
    ()=>createUploadTask
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/CanceledError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/logger.mjs [app-client] (ecmascript)");
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const createCancellableTask = ({ job, onCancel })=>{
    const state = 'IN_PROGRESS';
    let canceledErrorMessage;
    const cancelableTask = {
        cancel: (message)=>{
            const { state: taskState } = cancelableTask;
            if (taskState === 'CANCELED' || taskState === 'ERROR' || taskState === 'SUCCESS') {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`This task cannot be canceled. State: ${taskState}`);
                return;
            }
            cancelableTask.state = 'CANCELED';
            canceledErrorMessage = message;
            onCancel(canceledErrorMessage);
        },
        state
    };
    const wrappedJobPromise = (async ()=>{
        try {
            const result = await job();
            cancelableTask.state = 'SUCCESS';
            return result;
        } catch (e) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCancelError"])(e)) {
                cancelableTask.state = 'CANCELED';
                e.message = canceledErrorMessage ?? e.message;
            }
            cancelableTask.state = 'ERROR';
            throw e;
        }
    })();
    return Object.assign(cancelableTask, {
        result: wrappedJobPromise
    });
};
const createDownloadTask = createCancellableTask;
const createUploadTask = ({ job, onCancel, onResume, onPause, isMultipartUpload })=>{
    const cancellableTask = createCancellableTask({
        job,
        onCancel
    });
    const uploadTask = Object.assign(cancellableTask, {
        pause: ()=>{
            const { state } = uploadTask;
            if (!isMultipartUpload || state !== 'IN_PROGRESS') {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`This task cannot be paused. State: ${state}`);
                return;
            }
            // TODO(eslint): remove this linter suppression.
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            uploadTask.state = 'PAUSED';
            onPause?.();
        },
        resume: ()=>{
            const { state } = uploadTask;
            if (!isMultipartUpload || state !== 'PAUSED') {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`This task cannot be resumed. State: ${state}`);
                return;
            }
            // TODO(eslint): remove this linter suppression.
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            uploadTask.state = 'IN_PROGRESS';
            onResume?.();
        }
    });
    return uploadTask;
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/byteLength.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "byteLength",
    ()=>byteLength
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Calculate the total size of the data to be uploaded. The total size is not required for multipart upload, as it's
 * only used in progress report.
 */ const byteLength = (input)=>{
    if (input === null || input === undefined) return 0;
    if (typeof input === 'string') {
        const blob = new Blob([
            input
        ]);
        return blob.size;
    } else if (typeof input.byteLength === 'number') {
        // handles Uint8Array, ArrayBuffer, Buffer, and ArrayBufferView
        return input.byteLength;
    } else if (typeof input.size === 'number') {
        // handles browser File object
        return input.size;
    }
    return undefined;
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/base64/index.browser.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toBase64",
    ()=>toBase64
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function bytesToBase64(bytes) {
    const base64Str = Array.from(bytes, (x)=>String.fromCodePoint(x)).join('');
    return btoa(base64Str);
}
function toBase64(input) {
    if (typeof input === 'string') {
        return bytesToBase64(new TextEncoder().encode(input));
    }
    return bytesToBase64(new Uint8Array(input.buffer, input.byteOffset, input.byteLength));
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/readFile.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "readFile",
    ()=>readFile
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const readFile = (file)=>{
    // Browser path: use FileReader when available.
    if (typeof FileReader !== 'undefined') {
        return new Promise((resolve, reject)=>{
            const reader = new FileReader();
            reader.onload = ()=>{
                resolve(reader.result);
            };
            reader.onabort = ()=>{
                reject(new Error('Read aborted'));
            };
            reader.onerror = ()=>{
                reject(reader.error);
            };
            reader.readAsArrayBuffer(file);
        });
    }
    // Server (Node.js 18+) path: Blob/File both expose arrayBuffer().
    return file.arrayBuffer();
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/md5.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateContentMd5",
    ()=>calculateContentMd5
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$node_modules$2f40$smithy$2f$md5$2d$js$2f$dist$2d$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/node_modules/@smithy/md5-js/dist-es/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$base64$2f$index$2e$browser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/base64/index.browser.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$readFile$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/readFile.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const calculateContentMd5 = async (content)=>{
    const hasher = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$node_modules$2f40$smithy$2f$md5$2d$js$2f$dist$2d$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Md5"]();
    const buffer = content instanceof Blob ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$readFile$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readFile"])(content) : content;
    hasher.update(buffer);
    const digest = await hasher.digest();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$base64$2f$index$2e$browser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBase64"])(digest);
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/constants.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ABORT_ERROR_CODE",
    ()=>ABORT_ERROR_CODE,
    "ABORT_ERROR_MESSAGE",
    ()=>ABORT_ERROR_MESSAGE,
    "CANCELED_ERROR_CODE",
    ()=>CANCELED_ERROR_CODE,
    "CANCELED_ERROR_MESSAGE",
    ()=>CANCELED_ERROR_MESSAGE,
    "CONTENT_SHA256_HEADER",
    ()=>CONTENT_SHA256_HEADER,
    "NETWORK_ERROR_CODE",
    ()=>NETWORK_ERROR_CODE,
    "NETWORK_ERROR_MESSAGE",
    ()=>NETWORK_ERROR_MESSAGE,
    "SEND_DOWNLOAD_PROGRESS_EVENT",
    ()=>SEND_DOWNLOAD_PROGRESS_EVENT,
    "SEND_UPLOAD_PROGRESS_EVENT",
    ()=>SEND_UPLOAD_PROGRESS_EVENT
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const SEND_UPLOAD_PROGRESS_EVENT = 'sendUploadProgress';
const SEND_DOWNLOAD_PROGRESS_EVENT = 'sendDownloadProgress';
const NETWORK_ERROR_MESSAGE = 'Network Error';
const NETWORK_ERROR_CODE = 'ERR_NETWORK';
const ABORT_ERROR_MESSAGE = 'Request aborted';
const ABORT_ERROR_CODE = 'ERR_ABORTED';
const CANCELED_ERROR_MESSAGE = 'canceled';
const CANCELED_ERROR_CODE = 'ERR_CANCELED';
const CONTENT_SHA256_HEADER = 'x-amz-content-sha256';
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/contentSha256middleware.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "contentSha256MiddlewareFactory",
    ()=>contentSha256MiddlewareFactory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$signer$2f$signatureV4$2f$utils$2f$getHashedPayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/signing/signer/signatureV4/utils/getHashedPayload.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/constants.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * A middleware that adds the x-amz-content-sha256 header to the request if it is not already present.
 * It's required for S3 requests in browsers where the request body is sent in 1 chunk.
 * @see https://docs.aws.amazon.com/AmazonS3/latest/API/sig-v4-header-based-auth.html
 *
 * @internal
 */ const contentSha256MiddlewareFactory = ()=>(next)=>async function contentSha256Middleware(request) {
            if (request.headers[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONTENT_SHA256_HEADER"]]) {
                return next(request);
            } else {
                const hash = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$signer$2f$signatureV4$2f$utils$2f$getHashedPayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHashedPayload"])(request.body);
                request.headers[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONTENT_SHA256_HEADER"]] = hash;
                return next(request);
            }
        };
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/xhrTransferHandler.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "xhrTransferHandler",
    ()=>xhrTransferHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$utils$2f$memoization$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/utils/memoization.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Logger$2f$ConsoleLogger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Logger/ConsoleLogger.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/CanceledError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/StorageError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/constants.mjs [app-client] (ecmascript)");
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const logger = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Logger$2f$ConsoleLogger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConsoleLogger"]('xhr-http-handler');
/**
 * Base transfer handler implementation using XMLHttpRequest to support upload and download progress events.
 *
 * @param request - The request object.
 * @param options - The request options.
 * @returns A promise that will be resolved with the response object.
 *
 * @internal
 */ const xhrTransferHandler = (request, options)=>{
    const { url, method, headers, body } = request;
    const { onDownloadProgress, onUploadProgress, responseType, abortSignal } = options;
    return new Promise((resolve, reject)=>{
        let xhr = new XMLHttpRequest();
        xhr.open(method.toUpperCase(), url.toString());
        Object.entries(headers).filter(([header])=>!FORBIDDEN_HEADERS.includes(header)).forEach(([header, value])=>{
            xhr.setRequestHeader(header, value);
        });
        xhr.responseType = responseType;
        if (onDownloadProgress) {
            xhr.addEventListener('progress', (event)=>{
                onDownloadProgress(convertToTransferProgressEvent(event));
                logger.debug(event);
            });
        }
        if (onUploadProgress) {
            xhr.upload.addEventListener('progress', (event)=>{
                onUploadProgress(convertToTransferProgressEvent(event));
                logger.debug(event);
            });
        }
        xhr.addEventListener('error', ()=>{
            const networkError = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"]({
                message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NETWORK_ERROR_MESSAGE"],
                name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NETWORK_ERROR_CODE"]
            });
            logger.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NETWORK_ERROR_MESSAGE"]);
            reject(networkError);
            xhr = null; // clean up request
        });
        // Handle browser request cancellation (as opposed to a manual cancellation)
        xhr.addEventListener('abort', ()=>{
            // The abort event can be triggered after the error or load event. So we need to check if the xhr is null.
            // When request is aborted by AbortSignal, the promise is rejected in the abortSignal's 'abort' event listener.
            if (!xhr || abortSignal?.aborted) return;
            // Handle abort request caused by browser instead of AbortController
            // see: https://github.com/axios/axios/issues/537
            const error = buildHandlerError(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ABORT_ERROR_MESSAGE"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ABORT_ERROR_CODE"]);
            logger.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ABORT_ERROR_MESSAGE"]);
            reject(error);
            xhr = null; // clean up request
        });
        // Skip handling timeout error since we don't have a timeout
        xhr.addEventListener('readystatechange', ()=>{
            if (!xhr || xhr.readyState !== xhr.DONE) {
                return;
            }
            const onloadend = ()=>{
                // The load event is triggered after the error/abort/load event. So we need to check if the xhr is null.
                if (!xhr) return;
                const responseHeaders = convertResponseHeaders(xhr.getAllResponseHeaders());
                const { responseType: loadEndResponseType } = xhr;
                const responseBlob = xhr.response;
                const responseText = loadEndResponseType === 'text' ? xhr.responseText : '';
                const bodyMixIn = {
                    blob: ()=>Promise.resolve(responseBlob),
                    text: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$utils$2f$memoization$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["withMemoization"])(()=>loadEndResponseType === 'blob' ? readBlobAsText(responseBlob) : Promise.resolve(responseText)),
                    json: ()=>Promise.reject(// S3 does not support JSON response. So fail-fast here with nicer error message.
                        new Error('Parsing response to JSON is not implemented. Please use response.text() instead.'))
                };
                const response = {
                    statusCode: xhr.status,
                    headers: responseHeaders,
                    // The xhr.responseType is only set to 'blob' for streaming binary S3 object data. The streaming data is
                    // exposed via public interface of Storage.get(). So we need to return the response as a Blob object for
                    // backward compatibility. In other cases, the response payload is only used internally, we return it is
                    // {@link ResponseBodyMixin}
                    body: xhr.responseType === 'blob' ? Object.assign(responseBlob, bodyMixIn) : bodyMixIn
                };
                resolve(response);
                xhr = null; // clean up request
            };
            // readystate handler is calling before onerror or ontimeout handlers,
            // so we should call onloadend on the next 'tick'
            // @see https://github.com/axios/axios/blob/9588fcdec8aca45c3ba2f7968988a5d03f23168c/lib/adapters/xhr.js#L98-L99
            setTimeout(onloadend);
        });
        if (abortSignal) {
            const onCanceled = ()=>{
                // The abort event is triggered after the error or load event. So we need to check if the xhr is null.
                if (!xhr) {
                    return;
                }
                const canceledError = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CanceledError"]({
                    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CANCELED_ERROR_CODE"],
                    message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CANCELED_ERROR_MESSAGE"]
                });
                reject(canceledError);
                xhr.abort();
                xhr = null;
            };
            abortSignal.aborted ? onCanceled() : abortSignal.addEventListener('abort', onCanceled);
        }
        if (typeof ReadableStream === 'function' && body instanceof ReadableStream) {
            // This does not matter as previous implementation uses Axios which does not support ReadableStream anyway.
            throw new Error('ReadableStream request payload is not supported.');
        }
        xhr.send(body ?? null);
    });
};
const convertToTransferProgressEvent = (event)=>({
        // `loaded` can exceed the `total` in some cases due to platform issues/bugs e.g. React Native & Expo Android
        // clamp `loaded` values down to `total` if possible.
        transferredBytes: event.lengthComputable ? Math.min(event.loaded, event.total) : event.loaded,
        totalBytes: event.lengthComputable ? event.total : undefined
    });
const buildHandlerError = (message, name)=>{
    const error = new Error(message);
    error.name = name;
    return error;
};
/**
 * Convert xhr.getAllResponseHeaders() string to a Record<string, string>. Note that modern browser already returns
 * header names in lowercase.
 * @param xhrHeaders - string of headers returned from xhr.getAllResponseHeaders()
 */ const convertResponseHeaders = (xhrHeaders)=>{
    if (!xhrHeaders) {
        return {};
    }
    return xhrHeaders.split('\r\n').reduce((headerMap, line)=>{
        const parts = line.split(': ');
        const header = parts.shift();
        const value = parts.join(': ');
        headerMap[header.toLowerCase()] = value;
        return headerMap;
    }, {});
};
const readBlobAsText = (blob)=>{
    const reader = new FileReader();
    return new Promise((resolve, reject)=>{
        reader.onloadend = ()=>{
            if (reader.readyState !== FileReader.DONE) {
                return;
            }
            resolve(reader.result);
        };
        reader.onerror = ()=>{
            reject(reader.error);
        };
        reader.readAsText(blob);
    });
};
// To add more forbidden headers as found set by S3. Intentionally NOT list all of them here to save bundle size.
// https://developer.mozilla.org/en-US/docs/Glossary/Forbidden_header_name
const FORBIDDEN_HEADERS = [
    'host'
];
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "s3TransferHandler",
    ()=>s3TransferHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$userAgent$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/userAgent/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$retry$2f$amzSdkInvocationIdHeaderMiddleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/retry/amzSdkInvocationIdHeaderMiddleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$retry$2f$retryMiddleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/retry/retryMiddleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$retry$2f$amzSdkRequestHeaderMiddleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/retry/amzSdkRequestHeaderMiddleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/signing/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeTransferHandler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeTransferHandler.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$contentSha256middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/contentSha256middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$xhrTransferHandler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/xhrTransferHandler.mjs [app-client] (ecmascript)");
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * S3 transfer handler for browser and React Native based on XHR. On top of basic transfer handler, it also supports
 * x-amz-content-sha256 header, and request&response process tracking.
 *
 * @internal
 */ const s3TransferHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeTransferHandler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeTransferHandler"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$xhrTransferHandler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["xhrTransferHandler"], [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$contentSha256middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contentSha256MiddlewareFactory"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$userAgent$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userAgentMiddlewareFactory"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$retry$2f$amzSdkInvocationIdHeaderMiddleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["amzSdkInvocationIdHeaderMiddlewareFactory"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$retry$2f$retryMiddleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["retryMiddlewareFactory"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$retry$2f$amzSdkRequestHeaderMiddleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["amzSdkRequestHeaderMiddlewareFactory"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signingMiddlewareFactory"]
]);
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildStorageServiceError",
    ()=>buildStorageServiceError,
    "createStringEnumDeserializer",
    ()=>createStringEnumDeserializer,
    "deserializeBoolean",
    ()=>deserializeBoolean,
    "deserializeCompletedPartList",
    ()=>deserializeCompletedPartList,
    "deserializeMetadata",
    ()=>deserializeMetadata,
    "deserializeNumber",
    ()=>deserializeNumber,
    "deserializeStringTag",
    ()=>deserializeStringTag,
    "deserializeTimestamp",
    ()=>deserializeTimestamp,
    "emptyArrayGuard",
    ()=>emptyArrayGuard,
    "map",
    ()=>map
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/StorageError.mjs [app-client] (ecmascript)");
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Maps an object to a new object using the provided instructions.
 * The instructions are a map of the returning mapped object's property names to a single instruction of how to map the
 * value from the original object to the new object. There are two types of instructions:
 *
 * 1. A string representing the property name of the original object to map to the new object. The value mapped from
 * the original object will be the same as the value in the new object, and it can ONLY be string.
 *
 * 2. An array of two elements. The first element is the property name of the original object to map to the new object.
 * The second element is a function that takes the value from the original object and returns the value to be mapped to
 * the new object. The function can return any type.
 *
 * Example:
 * ```typescript
 * const input = {
 *   Foo: 'foo',
 *   BarList: [{value: 'bar1'}, {value: 'bar2'}]
 * }
 * const output = map(input, {
 *   someFoo: 'Foo',
 *   bar: ['BarList', (barList) => barList.map(bar => bar.value)]
 *   baz: 'Baz' // Baz does not exist in input, so it will not be in the output.
 * });
 * // output = { someFoo: 'foo', bar: ['bar1', 'bar2'] }
 * ```
 *
 * @param obj The object containing the data to compose mapped object.
 * @param instructions The instructions mapping the object values to the new object.
 * @returns A new object with the mapped values.
 *
 * @internal
 */ const map = (obj, instructions)=>{
    const result = {};
    for (const [key, instruction] of Object.entries(instructions)){
        const [accessor, deserializer] = Array.isArray(instruction) ? instruction : [
            instruction
        ];
        if (Object.prototype.hasOwnProperty.call(obj, accessor)) {
            result[key] = deserializer ? deserializer(obj[accessor]) : String(obj[accessor]);
        }
    }
    return result;
};
/**
 * Deserializes a string to a number. Returns undefined if input is undefined.
 *
 * @internal
 */ const deserializeNumber = (value)=>value ? Number(value) : undefined;
/**
 * Deserializes a string to a boolean. Returns undefined if input is undefined. Returns true if input is 'true',
 * otherwise false.
 *
 * @internal
 */ const deserializeBoolean = (value)=>{
    return value ? value === 'true' : undefined;
};
/**
 * Deserializes a string to a Date. Returns undefined if input is undefined.
 * It supports epoch timestamp; rfc3339(cannot have a UTC, fractional precision supported); rfc7231(section 7.1.1.1)
 *
 * @see https://www.epoch101.com/
 * @see https://datatracker.ietf.org/doc/html/rfc3339.html#section-5.6
 * @see https://datatracker.ietf.org/doc/html/rfc7231.html#section-7.1.1.1
 *
 * @note For bundle size consideration, we use Date constructor to parse the timestamp string. There might be slight
 * difference among browsers.
 *
 * @internal
 */ const deserializeTimestamp = (value)=>{
    return value ? new Date(value) : undefined;
};
/**
 * Create a function deserializing a string to an enum value. If the string is not a valid enum value, it throws a
 * StorageError.
 *
 * This utility is ONLY preferred if the enum value is critical. Since the enum values are hard-coded, new enum values
 * returned from service would break the library.
 *
 * @example
 * ```typescript
 * const deserializeStringEnum = createStringEnumDeserializer(['a', 'b', 'c'] as const, 'FieldName');
 * const deserializedArray = ['a', 'b', 'c'].map(deserializeStringEnum);
 * // deserializedArray = ['a', 'b', 'c']
 *
 * const invalidValue = deserializeStringEnum('d');
 * // Throws InvalidFieldName: Invalid FieldName: d
 * ```
 *
 * @internal
 */ const createStringEnumDeserializer = (enumValues, fieldName)=>{
    const deserializeStringEnum = (value)=>{
        const parsedEnumValue = value ? enumValues.find((enumValue)=>enumValue === value) : undefined;
        if (!parsedEnumValue) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"]({
                name: `Invalid${fieldName}`,
                message: `Invalid ${fieldName}: ${value}`,
                recoverySuggestion: 'This is likely to be a bug. Please reach out to library authors.'
            });
        }
        return parsedEnumValue;
    };
    return deserializeStringEnum;
};
/**
 * Deserializes a string to a string tag type. The function simply casts the parsed string into a given string tag type.
 * It does NOT validate the string value against the string tag. This behavior is the same to AWS SDK parsing logic of
 * string tag types.
 *
 * If you need to verify the string value, you must use {@link createStringEnumDeserializer} instead.
 *
 * @internal
 */ const deserializeStringTag = (value)=>String(value);
/**
 * Function that makes sure the deserializer receives non-empty array.
 *
 * @internal
 */ const emptyArrayGuard = (value, deserializer)=>{
    if (value === '') {
        return [];
    }
    const valueArray = (Array.isArray(value) ? value : [
        value
    ]).filter((e)=>e != null);
    return deserializer(valueArray);
};
/**
 * @internal
 */ const deserializeMetadata = (headers)=>{
    const objectMetadataHeaderPrefix = 'x-amz-meta-';
    const deserialized = Object.keys(headers).filter((header)=>header.startsWith(objectMetadataHeaderPrefix)).reduce((acc, header)=>{
        acc[header.replace(objectMetadataHeaderPrefix, '')] = headers[header];
        return acc;
    }, {});
    return Object.keys(deserialized).length > 0 ? deserialized : undefined;
};
/**
 * Internal-only method to create a new StorageError from a service error with AWS SDK-compatible interfaces
 * @param error - The output of a service error parser, with AWS SDK-compatible interface(e.g. $metadata)
 * @returns A new StorageError.
 *
 * @internal
 */ const buildStorageServiceError = (error)=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"]({
        name: error.name,
        message: error.message,
        metadata: error.$metadata
    });
/**
 * Internal-only method used for deserializing the parts of a multipart upload.
 *
 * @internal
 */ const deserializeCompletedPartList = (input)=>input.map((item)=>map(item, {
            PartNumber: [
                'PartNumber',
                deserializeNumber
            ],
            ETag: 'ETag',
            ChecksumCRC32: 'ChecksumCRC32'
        }));
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "assignStringVariables",
    ()=>assignStringVariables,
    "serializeObjectConfigsToHeaders",
    ()=>serializeObjectConfigsToHeaders,
    "serializePathnameObjectKey",
    ()=>serializePathnameObjectKey,
    "validateS3RequiredParameter",
    ()=>validateS3RequiredParameter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$utils$2f$extendedEncodeURIComponent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/signing/utils/extendedEncodeURIComponent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$types$2f$errors$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/types/errors.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/StorageError.mjs [app-client] (ecmascript)");
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * @internal
 */ const assignStringVariables = (values)=>{
    const queryParams = {};
    for (const [key, value] of Object.entries(values)){
        if (value != null) {
            queryParams[key] = value.toString();
        }
    }
    return queryParams;
};
/**
 * Serailize the parameters for configuring the S3 object. Currently used by
 * `putObject` and `createMultipartUpload` API.
 *
 * @internal
 */ const serializeObjectConfigsToHeaders = async (input)=>({
        ...assignStringVariables({
            'x-amz-acl': input.ACL,
            'cache-control': input.CacheControl,
            'content-disposition': input.ContentDisposition,
            'content-language': input.ContentLanguage,
            'content-encoding': input.ContentEncoding,
            'content-type': input.ContentType,
            expires: input.Expires?.toUTCString(),
            'x-amz-tagging': input.Tagging,
            ...serializeMetadata(input.Metadata)
        })
    });
const serializeMetadata = (metadata = {})=>Object.keys(metadata).reduce((acc, suffix)=>{
        acc[`x-amz-meta-${suffix.toLowerCase()}`] = metadata[suffix];
        return acc;
    }, {});
/**
 * Serialize the object key to a URL pathname.
 * @see https://github.com/aws/aws-sdk-js-v3/blob/7ed7101dcc4e81038b6c7f581162b959e6b33a04/clients/client-s3/src/protocols/Aws_restXml.ts#L1108
 *
 * @internal
 */ const serializePathnameObjectKey = (url, key)=>{
    return url.pathname.replace(/\/$/, '') + `/${key.split('/').map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$utils$2f$extendedEncodeURIComponent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extendedEncodeURIComponent"]).join('/')}`;
};
function validateS3RequiredParameter(assertion, paramName) {
    if (!assertion) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"]({
            name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$types$2f$errors$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyErrorCode"].Unknown,
            message: 'An unknown error has occurred.',
            underlyingError: new TypeError(`Expected a non-null value for S3 parameter ${paramName}`),
            recoverySuggestion: 'This is likely to be a bug. Please reach out to library authors.'
        });
    }
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/errors/IntegrityError.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IntegrityError",
    ()=>IntegrityError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$types$2f$errors$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/types/errors.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/StorageError.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
class IntegrityError extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"] {
    constructor(params){
        super({
            name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$types$2f$errors$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyErrorCode"].Unknown,
            message: 'An unknown error has occurred.',
            recoverySuggestion: 'This may be a bug. Please reach out to library authors.',
            metadata: params?.metadata
        });
        // TODO: Delete the following 2 lines after we change the build target to >= es2015
        this.constructor = IntegrityError;
        Object.setPrototypeOf(this, IntegrityError.prototype);
    }
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateObjectUrl.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "validateObjectUrl",
    ()=>validateObjectUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$utils$2f$extendedEncodeURIComponent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/signing/utils/extendedEncodeURIComponent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/IntegrityError.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function validateObjectUrl({ bucketName, key, objectURL }) {
    if (!bucketName || !key || !objectURL) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IntegrityError"]();
    }
    const bucketWithDots = bucketName.includes('.');
    const encodedBucketName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$utils$2f$extendedEncodeURIComponent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extendedEncodeURIComponent"])(bucketName);
    const encodedKey = key.split('/').map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$utils$2f$extendedEncodeURIComponent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extendedEncodeURIComponent"]).join('/');
    const isPathStyleUrl = objectURL.pathname === `/${encodedBucketName}/${encodedKey}`;
    const isSubdomainUrl = objectURL.hostname.startsWith(`${encodedBucketName}.`) && objectURL.pathname === `/${encodedKey}`;
    if (!(isPathStyleUrl || !bucketWithDots && isSubdomainUrl)) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IntegrityError"]();
    }
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/xmlParser/dom.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parser",
    ()=>parser
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Drop-in replacement for fast-xml-parser's XmlParser class used in the AWS SDK S3 client XML deserializer. This
 * implementation is not tested against the full xml conformance test suite. It is only tested against the XML responses
 * from S3. This implementation requires the `DOMParser` class in the runtime.
 */ const parser = {
    parse: (xmlStr)=>{
        const domParser = new DOMParser();
        const xml = domParser.parseFromString(xmlStr, 'text/xml');
        const parsedObj = parseXmlNode(xml);
        const rootKey = Object.keys(parsedObj)[0];
        return parsedObj[rootKey];
    }
};
const parseXmlNode = (node)=>{
    if (isDocumentNode(node)) {
        return {
            [node.documentElement.nodeName]: parseXmlNode(node.documentElement)
        };
    }
    if (node.nodeType === Node.TEXT_NODE) {
        return node.nodeValue?.trim();
    }
    if (isElementNode(node)) {
        // Node like <Location>foo</Location> will be converted to { Location: 'foo' }
        // instead of { Location: { '#text': 'foo' } }.
        if (isTextOnlyElementNode(node)) {
            return node.childNodes[0].nodeValue;
        }
        const nodeValue = {};
        // convert attributes
        for (const attr of node.attributes){
            if (!isNamespaceAttributeName(attr.nodeName)) {
                nodeValue[attr.nodeName] = attr.nodeValue;
            }
        }
        // convert child nodes
        if (node.children.length > 0) {
            for (const child of node.children){
                const childValue = parseXmlNode(child);
                if (childValue === undefined) {
                    continue;
                }
                const childName = child.nodeName;
                if (nodeValue[childName] === undefined) {
                    nodeValue[childName] = childValue;
                } else if (Array.isArray(nodeValue[childName])) {
                    nodeValue[childName].push(childValue);
                } else {
                    nodeValue[childName] = [
                        nodeValue[childName],
                        childValue
                    ];
                }
            }
        }
        // Return empty element node as empty string instead of `{}`, which is the default behavior of fast-xml-parser.
        return Object.keys(nodeValue).length === 0 ? '' : nodeValue;
    }
};
const isElementNode = (node)=>node.nodeType === Node.ELEMENT_NODE;
const isDocumentNode = (node)=>node.nodeType === Node.DOCUMENT_NODE;
const isTextOnlyElementNode = (node)=>hasOnlyNamespaceAttributes(node) && node.children.length === 0 && node.firstChild?.nodeType === Node.TEXT_NODE;
const hasOnlyNamespaceAttributes = (node)=>{
    for (const attr of node.attributes){
        if (!isNamespaceAttributeName(attr.nodeName)) {
            return false;
        }
    }
    return true;
};
const isNamespaceAttributeName = (name)=>name === 'xmlns' || name.startsWith('xmlns:');
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/parsePayload.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createXmlErrorParser",
    ()=>createXmlErrorParser,
    "parseXmlBody",
    ()=>parseXmlBody
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$xmlParser$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/xmlParser/dom.mjs [app-client] (ecmascript)");
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Factory creating a parser that parses the JS Error object from the XML
 * response payload.
 *
 * @param input Input object
 * @param input.noErrorWrapping Whether the error code and message are located
 *   directly in the root XML element, or in a nested `<Error>` element.
 *   See: https://smithy.io/2.0/aws/protocols/aws-restxml-protocol.html#restxml-errors
 *
 *   Default to false.
 *
 * @internal
 */ const createXmlErrorParser = ({ noErrorWrapping = false } = {})=>async (response)=>{
        if (!response || response.statusCode < 300) {
            return;
        }
        const { statusCode } = response;
        const body = await parseXmlBody(response);
        const errorLocation = noErrorWrapping ? body : body.Error;
        const code = errorLocation?.Code ? errorLocation.Code : statusCode === 404 ? 'NotFound' : statusCode.toString();
        const message = errorLocation?.message ?? errorLocation?.Message ?? code;
        const error = new Error(message);
        return Object.assign(error, {
            name: code,
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response)
        });
    };
const parseXmlBody = async (response)=>{
    if (!response.body) {
        // S3 can return 200 without a body indicating failure.
        throw new Error('S3 aborted request.');
    }
    const data = await response.body.text();
    if (data?.length > 0) {
        try {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$xmlParser$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parse(data);
        } catch (error) {
            throw new Error(`Failed to parse XML response: ${error}`);
        }
    }
    return {};
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/createRetryDecider.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createRetryDecider",
    ()=>createRetryDecider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$retry$2f$defaultRetryDecider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/retry/defaultRetryDecider.mjs [app-client] (ecmascript)");
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Factory of a {@link RetryDecider} function.
 *
 * @param errorParser function to parse HTTP response wth XML payload to JS
 * 	Error instance.
 * @returns A structure indicating if the response is retryable; And if it is a
 * 	CredentialsExpiredError
 */ const createRetryDecider = (errorParser)=>async (response, error, middlewareContext)=>{
        const defaultRetryDecider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$retry$2f$defaultRetryDecider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRetryDecider"])(errorParser);
        const defaultRetryDecision = await defaultRetryDecider(response, error);
        if (!response) {
            return {
                retryable: defaultRetryDecision.retryable
            };
        }
        const parsedError = await errorParser(response);
        const errorCode = parsedError?.name;
        const errorMessage = parsedError?.message;
        const isCredentialsExpired = isCredentialsExpiredError(errorCode, errorMessage);
        return {
            retryable: defaultRetryDecision.retryable || // If we know the previous retry attempt sets isCredentialsExpired in the
            // middleware context, we don't want to retry anymore.
            !!(isCredentialsExpired && !middlewareContext?.isCredentialsExpired),
            isCredentialsExpiredError: isCredentialsExpired
        };
    };
// Ref: https://github.com/aws/aws-sdk-js/blob/54829e341181b41573c419bd870dd0e0f8f10632/lib/event_listeners.js#L522-L541
const INVALID_TOKEN_ERROR_CODES = [
    'RequestExpired',
    'ExpiredTokenException',
    'ExpiredToken'
];
/**
 * Given an error code, returns true if it is related to invalid credentials.
 *
 * @param errorCode String representation of some error.
 * @returns True if given error indicates the credentials used to authorize request
 * are invalid.
 */ const isCredentialsExpiredError = (errorCode, errorMessage)=>{
    const isExpiredTokenError = !!errorCode && INVALID_TOKEN_ERROR_CODES.includes(errorCode);
    // Ref: https://github.com/aws/aws-sdk-js/blob/54829e341181b41573c419bd870dd0e0f8f10632/lib/event_listeners.js#L536-L539
    const isExpiredSignatureError = !!errorCode && !!errorMessage && errorCode.includes('Signature') && errorMessage.includes('expired');
    return isExpiredTokenError || isExpiredSignatureError;
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SERVICE_NAME",
    ()=>SERVICE_NAME,
    "defaultConfig",
    ()=>defaultConfig,
    "isDnsCompatibleBucketName",
    ()=>isDnsCompatibleBucketName,
    "parseXmlError",
    ()=>parseXmlError,
    "retryDecider",
    ()=>retryDecider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$retry$2f$jitteredBackoff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/retry/jitteredBackoff.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$endpoints$2f$getDnsSuffix$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/endpoints/getDnsSuffix.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/parsePayload.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$createRetryDecider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/createRetryDecider.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/utils/assertValidationError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const DOMAIN_PATTERN = /^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/;
const IP_ADDRESS_PATTERN = /(\d+\.){3}\d+/;
const DOTS_PATTERN = /\.\./;
/**
 * The service name used to sign requests if the API requires authentication.
 */ const SERVICE_NAME = 's3';
/**
 * The endpoint resolver function that returns the endpoint URL for a given region, and input parameters.
 */ const endpointResolver = (options, apiInput)=>{
    const { region, useAccelerateEndpoint, customEndpoint, forcePathStyle } = options;
    let endpoint;
    // 1. get base endpoint
    if (customEndpoint) {
        if (customEndpoint === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LOCAL_TESTING_S3_ENDPOINT"]) {
            endpoint = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](customEndpoint);
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!customEndpoint.includes('://'), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].InvalidCustomEndpoint);
        endpoint = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](`https://${customEndpoint}`);
    } else if (useAccelerateEndpoint) {
        // this ErrorCode isn't expose yet since forcePathStyle param isn't publicly exposed
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!forcePathStyle, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].ForcePathStyleEndpointNotSupported);
        endpoint = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](`https://s3-accelerate.${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$endpoints$2f$getDnsSuffix$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDnsSuffix"])(region)}`);
    } else {
        endpoint = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](`https://s3.${region}.${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$endpoints$2f$getDnsSuffix$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDnsSuffix"])(region)}`);
    }
    // 2. inject bucket name
    if (apiInput?.Bucket) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(isDnsCompatibleBucketName(apiInput.Bucket), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].DnsIncompatibleBucketName);
        if (forcePathStyle || apiInput.Bucket.includes('.')) {
            endpoint.pathname = `/${apiInput.Bucket}`;
        } else {
            endpoint.host = `${apiInput.Bucket}.${endpoint.host}`;
        }
    }
    return {
        url: endpoint
    };
};
/**
 * Determines whether a given string is DNS compliant per the rules outlined by
 * S3. Length, capitaization, and leading dot restrictions are enforced by the
 * DOMAIN_PATTERN regular expression.
 * @internal
 *
 * @see https://github.com/aws/aws-sdk-js-v3/blob/f2da6182298d4d6b02e84fb723492c07c27469a8/packages/middleware-bucket-endpoint/src/bucketHostnameUtils.ts#L39-L48
 * @see https://docs.aws.amazon.com/AmazonS3/latest/dev/BucketRestrictions.html
 */ const isDnsCompatibleBucketName = (bucketName)=>DOMAIN_PATTERN.test(bucketName) && !IP_ADDRESS_PATTERN.test(bucketName) && !DOTS_PATTERN.test(bucketName);
/**
 * Error parser for the XML payload of S3 data plane error response. The error's
 * `Code` and `Message` locates directly at the XML root element.
 *
 * @example
 * ```
 * <?xml version="1.0" encoding="UTF-8"?>
 * 	<Error>
 * 		<Code>NoSuchKey</Code>
 * 		<Message>The resource you requested does not exist</Message>
 * 		<Resource>/mybucket/myfoto.jpg</Resource>
 * 		<RequestId>4442587FB7D0A2F9</RequestId>
 * 	</Error>
 * 	```
 *
 * @internal
 */ const parseXmlError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createXmlErrorParser"])({
    noErrorWrapping: true
});
/**
 * @internal
 */ const retryDecider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$createRetryDecider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRetryDecider"])(parseXmlError);
/**
 * @internal
 */ const defaultConfig = {
    service: SERVICE_NAME,
    endpointResolver,
    retryDecider,
    computeDelay: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$retry$2f$jitteredBackoff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jitteredBackoff"],
    get userAgentValue () {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyUserAgent"])();
    },
    useAccelerateEndpoint: false,
    uriEscapePath: false
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/putObject.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getPresignedPutObjectUrl",
    ()=>getPresignedPutObjectUrl,
    "putObject",
    ()=>putObject
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$signer$2f$signatureV4$2f$presignUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/signing/signer/signatureV4/presignUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$signer$2f$signatureV4$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/signing/signer/signatureV4/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateObjectUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const putObjectSerializer = async (input, endpoint)=>{
    const headers = {
        ...await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializeObjectConfigsToHeaders"])({
            ...input,
            ContentType: input.ContentType ?? 'application/octet-stream'
        }),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
            'content-md5': input.ContentMD5,
            'x-amz-checksum-crc32': input.ChecksumCRC32,
            'x-amz-expected-bucket-owner': input.ExpectedBucketOwner,
            'If-None-Match': input.IfNoneMatch
        })
    };
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.Key, 'Key');
    url.pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializePathnameObjectKey"])(url, input.Key);
    url.search = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrlSearchParams"]({
        'x-id': 'PutObject'
    }).toString();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateObjectUrl"])({
        bucketName: input.Bucket,
        key: input.Key,
        objectURL: url
    });
    return {
        method: 'PUT',
        headers,
        url,
        body: input.Body
    };
};
const putObjectDeserializer = async (response)=>{
    if (response.statusCode >= 300) {
        // error is always set when statusCode >= 300
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response));
    } else {
        return {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(response.headers, {
                ETag: 'etag',
                VersionId: 'x-amz-version-id'
            }),
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response)
        };
    }
};
const putObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], putObjectSerializer, putObjectDeserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'text'
});
/**
 * Get a presigned URL for the `putObject` API.
 *
 * @internal
 */ const getPresignedPutObjectUrl = async (config, input)=>{
    const endpoint = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"].endpointResolver(config, input);
    const { url, headers, method } = await putObjectSerializer({
        ...input,
        Body: undefined
    }, endpoint);
    if (config.userAgentValue) {
        url.searchParams.append(config.userAgentHeader ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["USER_AGENT_HEADER"], config.userAgentValue);
    }
    for (const [headerName, value] of Object.entries(headers).sort(([key1], [key2])=>key1.localeCompare(key2))){
        url.searchParams.append(headerName, value);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$signer$2f$signatureV4$2f$presignUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["presignUrl"])({
        method,
        url,
        body: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$signer$2f$signatureV4$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNSIGNED_PAYLOAD"]
    }, {
        signingService: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"].service,
        signingRegion: config.region,
        ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
        ...config
    });
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/userAgent.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getStorageUserAgentValue",
    ()=>getStorageUserAgentValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/types.mjs [app-client] (ecmascript)");
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function getStorageUserAgentValue(action) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAmplifyUserAgent"])({
        category: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Category"].Storage,
        action
    });
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/utils/resolvePrefix.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resolvePrefix",
    ()=>resolvePrefix
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/utils/assertValidationError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const resolvePrefix = ({ accessLevel, targetIdentityId })=>{
    if (accessLevel === 'private') {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!!targetIdentityId, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].NoIdentityId);
        return `private/${targetIdentityId}/`;
    } else if (accessLevel === 'protected') {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!!targetIdentityId, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].NoIdentityId);
        return `protected/${targetIdentityId}/`;
    } else {
        return 'public/';
    }
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/errors/constants.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "INVALID_STORAGE_INPUT",
    ()=>INVALID_STORAGE_INPUT
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const INVALID_STORAGE_INPUT = 'InvalidStorageInput';
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveS3ConfigAndInput.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resolveS3ConfigAndInput",
    ()=>resolveS3ConfigAndInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/utils/assertValidationError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$resolvePrefix$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/resolvePrefix.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/StorageError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * resolve the common input options for S3 API handlers from Amplify configuration and library options.
 *
 * @param {AmplifyClassV6} amplify The Amplify instance.
 * @param {S3ApiOptions} apiOptions The input options for S3 provider.
 * @returns {Promise<ResolvedS3ConfigAndInput>} The resolved common input options for S3 API handlers.
 * @throws A `StorageError` with `error.name` from `StorageValidationErrorCode` indicating invalid
 *   configurations or Amplify library options.
 *
 * @internal
 */ const resolveS3ConfigAndInput = async (amplify, apiInput)=>{
    const { options: apiOptions } = apiInput ?? {};
    /**
     * IdentityId is always cached in memory so we can safely make calls here. It
     * should be stable even for unauthenticated users, regardless of credentials.
     */ const { identityId } = await amplify.Auth.fetchAuthSession();
    /**
     * A credentials provider function instead of a static credentials object is
     * used because the long-running tasks like multipart upload may span over the
     * credentials expiry. Auth.fetchAuthSession() automatically refreshes the
     * credentials if they are expired.
     *
     * The optional forceRefresh option is set when the S3 service returns expired
     * tokens error in the previous API call attempt.
     */ const credentialsProvider = async (options)=>{
        if (isLocationCredentialsProvider(apiOptions)) {
            assertStorageInput(apiInput);
        }
        // TODO: forceRefresh option of fetchAuthSession would refresh both tokens and
        // AWS credentials. So we do not support forceRefreshing from the Auth until
        // we support refreshing only the credentials.
        const { credentials } = isLocationCredentialsProvider(apiOptions) ? await apiOptions.locationCredentialsProvider(options) : await amplify.Auth.fetchAuthSession();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!!credentials, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].NoCredentials);
        return credentials;
    };
    const { bucket: defaultBucket, region: defaultRegion, dangerouslyConnectToHttpEndpointForTesting, buckets } = amplify.getConfig()?.Storage?.S3 ?? {};
    const { bucket = defaultBucket, region = defaultRegion } = apiOptions?.bucket && resolveBucketConfig(apiOptions, buckets) || {};
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!!bucket, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].NoBucket);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!!region, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].NoRegion);
    const { defaultAccessLevel, prefixResolver = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$resolvePrefix$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolvePrefix"], isObjectLockEnabled } = amplify.libraryOptions?.Storage?.S3 ?? {};
    const accessLevel = apiOptions?.accessLevel ?? defaultAccessLevel ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_ACCESS_LEVEL"];
    const targetIdentityId = accessLevel === 'protected' ? apiOptions?.targetIdentityId ?? identityId : identityId;
    const keyPrefix = await prefixResolver({
        accessLevel,
        targetIdentityId
    });
    return {
        s3Config: {
            credentials: credentialsProvider,
            region,
            useAccelerateEndpoint: apiOptions?.useAccelerateEndpoint,
            ...apiOptions?.customEndpoint ? {
                customEndpoint: apiOptions.customEndpoint
            } : {},
            ...dangerouslyConnectToHttpEndpointForTesting ? {
                customEndpoint: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LOCAL_TESTING_S3_ENDPOINT"],
                forcePathStyle: true
            } : {}
        },
        bucket,
        keyPrefix,
        identityId,
        isObjectLockEnabled
    };
};
const isLocationCredentialsProvider = (options)=>{
    return !!options?.locationCredentialsProvider;
};
const isInputWithCallbackPath = (input)=>{
    return input?.path && typeof input.path === 'function' || input?.destination?.path && typeof input.destination?.path === 'function' || input?.source?.path && typeof input.source?.path === 'function';
};
const isDeprecatedInput = (input)=>{
    return isInputWithKey(input) || isInputWithPrefix(input) || isInputWithCopySourceOrDestination(input);
};
const assertStorageInput = (input)=>{
    if (isDeprecatedInput(input) || isInputWithCallbackPath(input)) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"]({
            name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INVALID_STORAGE_INPUT"],
            message: 'The input needs to have a path as a string value.',
            recoverySuggestion: 'Please provide a valid path as a string value for the input.'
        });
    }
};
const isInputWithKey = (input)=>{
    return !!(typeof input.key === 'string');
};
const isInputWithPrefix = (input)=>{
    return !!(typeof input.prefix === 'string');
};
const isInputWithCopySourceOrDestination = (input)=>{
    return !!(typeof input.source?.key === 'string' || typeof input.destination?.key === 'string');
};
const resolveBucketConfig = (apiOptions, buckets)=>{
    if (typeof apiOptions.bucket === 'string') {
        const bucketConfig = buckets?.[apiOptions.bucket];
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!!bucketConfig, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].InvalidStorageBucket);
        return {
            bucket: bucketConfig.bucketName,
            region: bucketConfig.region
        };
    }
    if (typeof apiOptions.bucket === 'object') {
        return {
            bucket: apiOptions.bucket.bucketName,
            region: apiOptions.bucket.region
        };
    }
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateBucketOwnerID.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "validateBucketOwnerID",
    ()=>validateBucketOwnerID
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/utils/assertValidationError.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const VALID_AWS_ACCOUNT_ID_PATTERN = /^\d{12}/;
const validateBucketOwnerID = (accountID)=>{
    if (accountID === undefined) {
        return;
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(VALID_AWS_ACCOUNT_ID_PATTERN.test(accountID), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].InvalidAWSAccountID);
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/isInputWithPath.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isInputWithPath",
    ()=>isInputWithPath
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const isInputWithPath = (input)=>{
    return input.path !== undefined;
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveIdentityId.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resolveIdentityId",
    ()=>resolveIdentityId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/utils/assertValidationError.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const resolveIdentityId = (identityId)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!!identityId, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].NoIdentityId);
    return identityId;
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateStorageOperationInput.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "validateStorageOperationInput",
    ()=>validateStorageOperationInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/utils/assertValidationError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$isInputWithPath$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/isInputWithPath.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveIdentityId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveIdentityId.mjs [app-client] (ecmascript)");
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const validateStorageOperationInput = (input, identityId)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(// Key present without a path
    !!input.key && !input.path || !input.key && !!input.path, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].InvalidStorageOperationInput);
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$isInputWithPath$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInputWithPath"])(input)) {
        const { path } = input;
        const objectKey = typeof path === 'string' ? path : path({
            identityId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveIdentityId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveIdentityId"])(identityId)
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!objectKey.startsWith('/'), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].InvalidStoragePathInput);
        return {
            inputType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_PATH"],
            objectKey
        };
    } else {
        return {
            inputType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"],
            objectKey: input.key
        };
    }
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/hexUtils.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hexToBase64",
    ()=>hexToBase64,
    "hexToUint8Array",
    ()=>hexToUint8Array
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$base64$2f$index$2e$browser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/base64/index.browser.mjs [app-client] (ecmascript)");
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const hexToUint8Array = (hexString)=>new Uint8Array((hexString.match(/\w{2}/g) ?? []).map((h)=>parseInt(h, 16)));
const hexToBase64 = (hexString)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$base64$2f$index$2e$browser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBase64"])(hexToUint8Array(hexString));
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/crc32.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateContentCRC32",
    ()=>calculateContentCRC32
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$crc$2d$32$2f$crc32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/crc-32/crc32.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$hexUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/hexUtils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$readFile$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/readFile.mjs [app-client] (ecmascript)");
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const CHUNK_SIZE = 1024 * 1024; // 1MB chunks
/**
 * Calculate the CRC32 checksum for given content and return base64 encoded checksum.
 */ const calculateContentCRC32 = async (content, seed = 0)=>{
    let internalSeed = seed;
    if (content instanceof ArrayBuffer || ArrayBuffer.isView(content)) {
        let uint8Array;
        if (content instanceof ArrayBuffer) {
            uint8Array = new Uint8Array(content);
        } else {
            uint8Array = new Uint8Array(content.buffer, content.byteOffset, content.byteLength);
        }
        let offset = 0;
        while(offset < uint8Array.length){
            const end = Math.min(offset + CHUNK_SIZE, uint8Array.length);
            const chunk = uint8Array.slice(offset, end);
            internalSeed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$crc$2d$32$2f$crc32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].buf(chunk, internalSeed) >>> 0;
            offset = end;
        }
    } else {
        let blob;
        if (content instanceof Blob) {
            blob = content;
        } else {
            blob = new Blob([
                content
            ]);
        }
        let offset = 0;
        while(offset < blob.size){
            const end = Math.min(offset + CHUNK_SIZE, blob.size);
            const chunk = blob.slice(offset, end);
            const arrayBuffer = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$readFile$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readFile"])(chunk);
            const uint8Array = new Uint8Array(arrayBuffer);
            internalSeed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$crc$2d$32$2f$crc32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].buf(uint8Array, internalSeed) >>> 0;
            offset = end;
        }
    }
    const hex = internalSeed.toString(16).padStart(8, '0');
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$hexUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBase64"])(hex);
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constructContentDisposition.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "constructContentDisposition",
    ()=>constructContentDisposition
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const constructContentDisposition = (contentDisposition)=>{
    if (!contentDisposition) return undefined;
    if (typeof contentDisposition === 'string') return contentDisposition;
    const { type, filename } = contentDisposition;
    return filename !== undefined ? `${type}; filename="${filename}"` : type;
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/utils/contentType.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getContentType",
    ()=>getContentType
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const MIME_TYPES = {
    // Audio
    aac: 'audio/aac',
    mid: 'audio/midi',
    midi: 'audio/x-midi',
    mp3: 'audio/mpeg',
    oga: 'audio/ogg',
    opus: 'audio/ogg',
    wav: 'audio/wav',
    weba: 'audio/webm',
    // Video
    avi: 'video/x-msvideo',
    mp4: 'video/mp4',
    mpeg: 'video/mpeg',
    ogv: 'video/ogg',
    ts: 'video/mp2t',
    webm: 'video/webm',
    // Images
    apng: 'image/apng',
    avif: 'image/avif',
    bmp: 'image/bmp',
    gif: 'image/gif',
    ico: 'image/vnd.microsoft.icon',
    jpeg: 'image/jpeg',
    jpg: 'image/jpeg',
    png: 'image/png',
    svg: 'image/svg+xml',
    tif: 'image/tiff',
    tiff: 'image/tiff',
    webp: 'image/webp',
    // Text
    css: 'text/css',
    csv: 'text/csv',
    htm: 'text/html',
    html: 'text/html',
    ics: 'text/calendar',
    js: 'text/javascript',
    md: 'text/markdown',
    mjs: 'text/javascript',
    txt: 'text/plain',
    // Application
    abw: 'application/x-abiword',
    arc: 'application/x-freearc',
    azw: 'application/vnd.amazon.ebook',
    bin: 'application/octet-stream',
    bz: 'application/x-bzip',
    bz2: 'application/x-bzip2',
    cda: 'application/x-cdf',
    csh: 'application/x-csh',
    doc: 'application/msword',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    eot: 'application/vnd.ms-fontobject',
    epub: 'application/epub+zip',
    gz: 'application/gzip',
    jar: 'application/java-archive',
    json: 'application/json',
    jsonld: 'application/ld+json',
    mpkg: 'application/vnd.apple.installer+xml',
    odp: 'application/vnd.oasis.opendocument.presentation',
    ods: 'application/vnd.oasis.opendocument.spreadsheet',
    odt: 'application/vnd.oasis.opendocument.text',
    ogx: 'application/ogg',
    pdf: 'application/pdf',
    php: 'application/x-httpd-php',
    ppt: 'application/vnd.ms-powerpoint',
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    rar: 'application/vnd.rar',
    rtf: 'application/rtf',
    sh: 'application/x-sh',
    tar: 'application/x-tar',
    vsd: 'application/vnd.visio',
    webmanifest: 'application/manifest+json',
    xhtml: 'application/xhtml+xml',
    xls: 'application/vnd.ms-excel',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    xml: 'application/xml',
    zip: 'application/zip',
    // Fonts
    otf: 'font/otf',
    ttf: 'font/ttf',
    woff: 'font/woff',
    woff2: 'font/woff2'
};
/**
 * Detect content type from file data or filename extension
 */ const getContentType = (data, key)=>{
    if (data instanceof File && data.type) {
        return data.type;
    }
    const ext = key.split('.').pop()?.toLowerCase();
    return ext ? MIME_TYPES[ext] : undefined;
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/putObjectJob.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "putObjectJob",
    ()=>putObjectJob
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$md5$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/md5.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$putObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/putObject.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/userAgent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveS3ConfigAndInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateBucketOwnerID.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateStorageOperationInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$crc32$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/crc32.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constructContentDisposition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constructContentDisposition.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$contentType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/contentType.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Get a function the returns a promise to call putObject API to S3.
 *
 * @internal
 */ const putObjectJob = (amplify, uploadDataInput, abortSignal, totalLength)=>async ()=>{
        const { options: uploadDataOptions, data } = uploadDataInput;
        const { bucket, keyPrefix, s3Config, isObjectLockEnabled, identityId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveS3ConfigAndInput"])(amplify, uploadDataInput);
        const { inputType, objectKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateStorageOperationInput"])(uploadDataInput, identityId);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateBucketOwnerID"])(uploadDataOptions?.expectedBucketOwner);
        const finalKey = inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"] ? keyPrefix + objectKey : objectKey;
        const { contentDisposition, contentEncoding, contentType = uploadDataOptions?.contentType ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$contentType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getContentType"])(data, objectKey) ?? 'application/octet-stream', preventOverwrite, metadata, checksumAlgorithm, onProgress, expectedBucketOwner, cacheControl } = uploadDataOptions ?? {};
        const checksumCRC32 = checksumAlgorithm === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHECKSUM_ALGORITHM_CRC32"] ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$crc32$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateContentCRC32"])(data) : undefined;
        const contentMD5 = // check if checksum exists. ex: should not exist in react native
        !checksumCRC32 && isObjectLockEnabled ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$md5$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateContentMd5"])(data) : undefined;
        const { ETag: eTag, VersionId: versionId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$putObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putObject"])({
            ...s3Config,
            abortSignal,
            onUploadProgress: onProgress,
            userAgentValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageUserAgentValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].UploadData)
        }, {
            Bucket: bucket,
            Key: finalKey,
            Body: data,
            ContentType: contentType,
            ContentDisposition: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constructContentDisposition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructContentDisposition"])(contentDisposition),
            ContentEncoding: contentEncoding,
            CacheControl: cacheControl,
            Metadata: metadata,
            ContentMD5: contentMD5,
            ChecksumCRC32: checksumCRC32,
            ExpectedBucketOwner: expectedBucketOwner,
            IfNoneMatch: preventOverwrite ? '*' : undefined
        });
        const result = {
            eTag,
            versionId,
            contentType,
            metadata,
            size: totalLength
        };
        return inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"] ? {
            key: objectKey,
            ...result
        } : {
            path: objectKey,
            ...result
        };
    };
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/integrityHelpers.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bothNilOrEqual",
    ()=>bothNilOrEqual,
    "isEqual",
    ()=>isEqual,
    "isNil",
    ()=>isNil,
    "isObject",
    ()=>isObject
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const isNil = (value)=>{
    return value === undefined || value === null;
};
const bothNilOrEqual = (original, output)=>{
    return isNil(original) && isNil(output) || original === output;
};
/**
 * This function is used to determine if a value is an object.
 * It excludes arrays and null values.
 *
 * @param value
 * @returns
 */ const isObject = (value)=>{
    return value != null && typeof value === 'object' && !Array.isArray(value);
};
/**
 * This function is used to compare two objects and determine if they are equal.
 * It handles nested objects and arrays as well.
 * Array order is not taken into account.
 *
 * @param object
 * @param other
 * @returns
 */ const isEqual = (object, other)=>{
    if (Array.isArray(object) && !Array.isArray(other)) {
        return false;
    }
    if (!Array.isArray(object) && Array.isArray(other)) {
        return false;
    }
    if (Array.isArray(object) && Array.isArray(other)) {
        return object.length === other.length && object.every((val, ix)=>isEqual(val, other[ix]));
    }
    if (!isObject(object) || !isObject(other)) {
        return object === other;
    }
    const objectKeys = Object.keys(object);
    const otherKeys = Object.keys(other);
    if (objectKeys.length !== otherKeys.length) {
        return false;
    }
    return objectKeys.every((key)=>{
        return otherKeys.includes(key) && isEqual(object[key], other[key]);
    });
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateMultipartUploadXML.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "validateMultipartUploadXML",
    ()=>validateMultipartUploadXML
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/IntegrityError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$xmlParser$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/xmlParser/dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$integrityHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/integrityHelpers.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function validateMultipartUploadXML(input, xml) {
    if (!input.Parts) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IntegrityError"]();
    }
    const parsedXML = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$xmlParser$2f$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parse(xml);
    const mappedCompletedMultipartUpload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(parsedXML, {
        Parts: [
            'Part',
            (value)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptyArrayGuard"])(value, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeCompletedPartList"])
        ]
    });
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$integrityHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEqual"])(input, mappedCompletedMultipartUpload)) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IntegrityError"]();
    }
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/completeMultipartUpload.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "completeMultipartUpload",
    ()=>completeMultipartUpload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/parsePayload.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateObjectUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateMultipartUploadXML$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateMultipartUploadXML.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const INVALID_PARAMETER_ERROR_MSG = 'Invalid parameter for CompleteMultipartUpload API';
const MISSING_ETAG_ERROR_MSG = 'ETag missing from multipart upload';
const MISSING_ETAG_ERROR_SUGGESTION = 'Please ensure S3 bucket CORS configuration includes ETag as part of its `ExposeHeaders` element';
const completeMultipartUploadSerializer = async (input, endpoint)=>{
    const headers = {
        'content-type': 'application/xml',
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
            'x-amz-checksum-crc32': input.ChecksumCRC32,
            'x-amz-checksum-type': input.ChecksumType,
            'x-amz-expected-bucket-owner': input.ExpectedBucketOwner,
            'If-None-Match': input.IfNoneMatch
        })
    };
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.Key, 'Key');
    url.pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializePathnameObjectKey"])(url, input.Key);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.UploadId, 'UploadId');
    url.search = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrlSearchParams"]({
        uploadId: input.UploadId
    }).toString();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.MultipartUpload, 'MultipartUpload');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateObjectUrl"])({
        bucketName: input.Bucket,
        key: input.Key,
        objectURL: url
    });
    const xml = serializeCompletedMultipartUpload(input.MultipartUpload);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateMultipartUploadXML$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateMultipartUploadXML"])(input.MultipartUpload, xml);
    return {
        method: 'POST',
        headers,
        url,
        body: '<?xml version="1.0" encoding="UTF-8"?>' + xml
    };
};
const serializeCompletedMultipartUpload = (input)=>{
    if (!input.Parts?.length) {
        throw new Error(`${INVALID_PARAMETER_ERROR_MSG}: ${JSON.stringify(input)}`);
    }
    return `<CompleteMultipartUpload xmlns="http://s3.amazonaws.com/doc/2006-03-01/">${input.Parts.map(serializeCompletedPartList).join('')}</CompleteMultipartUpload>`;
};
const serializeCompletedPartList = (input)=>{
    if (input.PartNumber == null) {
        throw new Error(`${INVALID_PARAMETER_ERROR_MSG}: ${JSON.stringify(input)}`);
    }
    if (!input.ETag) {
        throw new Error(`${MISSING_ETAG_ERROR_MSG}: ${JSON.stringify(input)}. ${MISSING_ETAG_ERROR_SUGGESTION}`);
    }
    const eTag = `<ETag>${input.ETag}</ETag>`;
    const partNumber = `<PartNumber>${input.PartNumber}</PartNumber>`;
    const checksumCRC32 = input.ChecksumCRC32 ? `<ChecksumCRC32>${input.ChecksumCRC32}</ChecksumCRC32>` : '';
    return `<Part>${eTag}${partNumber}${checksumCRC32}</Part>`;
};
/**
 * Parse CompleteMultipartUpload API response payload, which may be empty or error indicating internal
 * server error, even when the status code is 200.
 *
 * Ref: https://docs.aws.amazon.com/AmazonS3/latest/API/API_CompleteMultipartUpload.html#API_CompleteMultipartUpload_Example_4
 */ const parseXmlBodyOrThrow = async (response)=>{
    const parsed = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlBody"])(response); // Handles empty body case
    if (parsed.Code !== undefined && parsed.Message !== undefined) {
        const error = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])({
            ...response,
            statusCode: 500
        });
        error.$metadata.httpStatusCode = response.statusCode;
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(error);
    }
    return parsed;
};
const completeMultipartUploadDeserializer = async (response)=>{
    if (response.statusCode >= 300) {
        // error is always set when statusCode >= 300
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response));
    } else {
        const parsed = await parseXmlBodyOrThrow(response);
        const contents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(parsed, {
            ETag: 'ETag',
            Key: 'Key',
            Location: 'Location'
        });
        return {
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response),
            ...contents
        };
    }
};
// CompleteMultiPartUpload API returns 200 status code with empty body or error message.
// This indicates internal server error after the response has been sent to the client.
// Ref: https://docs.aws.amazon.com/AmazonS3/latest/API/API_CompleteMultipartUpload.html#API_CompleteMultipartUpload_Example_4
const retryWhenErrorWith200StatusCode = async (response, error, middlewareContext)=>{
    if (!response) {
        return {
            retryable: false
        };
    }
    if (response.statusCode === 200) {
        if (!response.body) {
            return {
                retryable: true
            };
        }
        const parsed = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlBody"])(response);
        if (parsed.Code !== undefined && parsed.Message !== undefined) {
            return {
                retryable: true
            };
        }
        return {
            retryable: false
        };
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["retryDecider"])(response, error, middlewareContext);
};
const completeMultipartUpload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], completeMultipartUploadSerializer, completeMultipartUploadDeserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'text',
    retryDecider: retryWhenErrorWith200StatusCode
});
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/abortMultipartUpload.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "abortMultipartUpload",
    ()=>abortMultipartUpload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateObjectUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const abortMultipartUploadSerializer = (input, endpoint)=>{
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.Key, 'Key');
    url.pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializePathnameObjectKey"])(url, input.Key);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.UploadId, 'UploadId');
    url.search = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrlSearchParams"]({
        'x-id': 'AbortMultipartUpload',
        uploadId: input.UploadId
    }).toString();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateObjectUrl"])({
        bucketName: input.Bucket,
        key: input.Key,
        objectURL: url
    });
    const headers = {
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
            'x-amz-expected-bucket-owner': input.ExpectedBucketOwner
        })
    };
    return {
        method: 'DELETE',
        headers,
        url
    };
};
const abortMultipartUploadDeserializer = async (response)=>{
    if (response.statusCode >= 300) {
        // error is always set when statusCode >= 300
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response));
    } else {
        return {
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response)
        };
    }
};
const abortMultipartUpload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], abortMultipartUploadSerializer, abortMultipartUploadDeserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'text'
});
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/headObject.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "headObject",
    ()=>headObject
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateObjectUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const headObjectSerializer = async (input, endpoint)=>{
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.Key, 'Key');
    url.pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializePathnameObjectKey"])(url, input.Key);
    url.search = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrlSearchParams"]({
        'response-cache-control': 'no-store'
    }).toString();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateObjectUrl"])({
        bucketName: input.Bucket,
        key: input.Key,
        objectURL: url
    });
    const headers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
        'x-amz-expected-bucket-owner': input.ExpectedBucketOwner
    });
    return {
        method: 'HEAD',
        headers,
        url
    };
};
const headObjectDeserializer = async (response)=>{
    if (response.statusCode >= 300) {
        // error is always set when statusCode >= 300
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response));
    } else {
        const contents = {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(response.headers, {
                ContentLength: [
                    'content-length',
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeNumber"]
                ],
                ContentType: 'content-type',
                ETag: 'etag',
                LastModified: [
                    'last-modified',
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeTimestamp"]
                ],
                VersionId: 'x-amz-version-id'
            }),
            Metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeMetadata"])(response.headers)
        };
        return {
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response),
            ...contents
        };
    }
};
const headObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], headObjectSerializer, headObjectDeserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'text'
});
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/uploadPart.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "uploadPart",
    ()=>uploadPart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateObjectUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const uploadPartSerializer = async (input, endpoint)=>{
    const headers = {
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
            'x-amz-checksum-crc32': input.ChecksumCRC32,
            'content-md5': input.ContentMD5,
            'x-amz-expected-bucket-owner': input.ExpectedBucketOwner
        }),
        'content-type': 'application/octet-stream'
    };
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.Key, 'Key');
    url.pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializePathnameObjectKey"])(url, input.Key);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.PartNumber, 'PartNumber');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.UploadId, 'UploadId');
    url.search = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrlSearchParams"]({
        partNumber: input.PartNumber + '',
        uploadId: input.UploadId
    }).toString();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateObjectUrl"])({
        bucketName: input.Bucket,
        key: input.Key,
        objectURL: url
    });
    return {
        method: 'PUT',
        headers,
        url,
        body: input.Body
    };
};
const uploadPartDeserializer = async (response)=>{
    if (response.statusCode >= 300) {
        // error is always set when statusCode >= 300
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response));
    } else {
        return {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(response.headers, {
                ETag: 'etag'
            }),
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response)
        };
    }
};
const uploadPart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], uploadPartSerializer, uploadPartDeserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'text'
});
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/uploadPartExecutor.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "uploadPartExecutor",
    ()=>uploadPartExecutor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$uploadPart$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/uploadPart.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/logger.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$crc32$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/crc32.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$md5$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/md5.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const uploadPartExecutor = async ({ dataChunkerGenerator, completedPartNumberSet, s3Config, abortSignal, bucket, finalKey, uploadId, onPartUploadCompletion, onProgress, isObjectLockEnabled, useCRC32Checksum, expectedBucketOwner })=>{
    let transferredBytes = 0;
    for (const { data, partNumber, size } of dataChunkerGenerator){
        if (abortSignal.aborted) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug('upload executor aborted.');
            break;
        }
        if (completedPartNumberSet.has(partNumber)) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`part ${partNumber} already uploaded.`);
            transferredBytes += size;
            onProgress?.({
                transferredBytes
            });
        } else {
            // handle cancel error
            let checksumCRC32;
            if (useCRC32Checksum) {
                checksumCRC32 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$crc32$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateContentCRC32"])(data);
            }
            const contentMD5 = // check if checksum exists. ex: should not exist in react native
            !checksumCRC32 && isObjectLockEnabled ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$md5$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateContentMd5"])(data) : undefined;
            const { ETag: eTag } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$uploadPart$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadPart"])({
                ...s3Config,
                abortSignal,
                onUploadProgress: (event)=>{
                    const { transferredBytes: currentPartTransferredBytes } = event;
                    onProgress?.({
                        transferredBytes: transferredBytes + currentPartTransferredBytes
                    });
                }
            }, {
                Bucket: bucket,
                Key: finalKey,
                UploadId: uploadId,
                Body: data,
                PartNumber: partNumber,
                ChecksumCRC32: checksumCRC32,
                ContentMD5: contentMD5,
                ExpectedBucketOwner: expectedBucketOwner
            });
            transferredBytes += size;
            // eTag will always be set even the S3 model interface marks it as optional.
            onPartUploadCompletion(partNumber, eTag, checksumCRC32);
        }
    }
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/listParts.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "listParts",
    ()=>listParts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/parsePayload.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const listPartsSerializer = async (input, endpoint)=>{
    const headers = {};
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.Key, 'Key');
    url.pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializePathnameObjectKey"])(url, input.Key);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.UploadId, 'UploadId');
    url.search = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrlSearchParams"]({
        'x-id': 'ListParts',
        uploadId: input.UploadId
    }).toString();
    return {
        method: 'GET',
        headers,
        url
    };
};
const listPartsDeserializer = async (response)=>{
    if (response.statusCode >= 300) {
        // error is always set when statusCode >= 300
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response));
    } else {
        const parsed = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlBody"])(response);
        const contents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(parsed, {
            UploadId: 'UploadId',
            Parts: [
                'Part',
                (value)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptyArrayGuard"])(value, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeCompletedPartList"])
            ]
        });
        return {
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response),
            ...contents
        };
    }
};
const listParts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], listPartsSerializer, listPartsDeserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'text'
});
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/uploadCache.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cacheMultipartUpload",
    ()=>cacheMultipartUpload,
    "findCachedUploadPartsAndEvictExpired",
    ()=>findCachedUploadPartsAndEvictExpired,
    "getUploadsCacheKey",
    ()=>getUploadsCacheKey,
    "removeCachedUpload",
    ()=>removeCachedUpload,
    "serializeUploadOptions",
    ()=>serializeUploadOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$listParts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/listParts.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/logger.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$contentType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/contentType.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const ONE_HOUR = 1000 * 60 * 60;
/**
 * Find the cached multipart upload id and get the parts that have been uploaded
 * with ListParts API. If the cached upload is expired(1 hour), return null.
 */ const findCachedUploadPartsAndEvictExpired = async ({ resumableUploadsCache, cacheKey, s3Config, bucket, finalKey })=>{
    const allCachedUploads = await listCachedUploadTasks(resumableUploadsCache);
    // Evict all outdated uploads.
    const validCachedUploads = Object.fromEntries(Object.entries(allCachedUploads).filter(([_, cacheValue])=>cacheValue.lastTouched >= Date.now() - ONE_HOUR));
    if (Object.keys(validCachedUploads).length !== Object.keys(allCachedUploads).length) {
        await resumableUploadsCache.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UPLOADS_STORAGE_KEY"], JSON.stringify(validCachedUploads));
    }
    if (!validCachedUploads[cacheKey]) {
        return null;
    }
    const cachedUpload = validCachedUploads[cacheKey];
    cachedUpload.lastTouched = Date.now();
    await resumableUploadsCache.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UPLOADS_STORAGE_KEY"], JSON.stringify(validCachedUploads));
    try {
        const { Parts = [] } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$listParts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["listParts"])(s3Config, {
            Bucket: bucket,
            Key: finalKey,
            UploadId: cachedUpload.uploadId
        });
        return {
            parts: Parts,
            uploadId: cachedUpload.uploadId,
            finalCrc32: cachedUpload.finalCrc32
        };
    } catch (e) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug('failed to list cached parts, removing cached upload.');
        await removeCachedUpload(resumableUploadsCache, cacheKey);
        return null;
    }
};
const listCachedUploadTasks = async (resumableUploadsCache)=>{
    try {
        return JSON.parse(await resumableUploadsCache.getItem(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UPLOADS_STORAGE_KEY"]) ?? '{}');
    } catch (e) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug('failed to parse cached uploads record.');
        return {};
    }
};
/**
 * Serialize the uploadData API options to string so it can be hashed.
 */ const serializeUploadOptions = (options = {})=>{
    const unserializableOptionProperties = [
        'onProgress',
        'resumableUploadsCache',
        'locationCredentialsProvider'
    ];
    const serializableOptionEntries = Object.entries(options).filter(([key])=>!unserializableOptionProperties.includes(key));
    if (options.checksumAlgorithm === 'crc-32') {
        // Additional options to differentiate the upload cache created before introducing the full-object checksum and
        // after. If full-object checksum is enabled, the previous upload caches that created with composite checksum should
        // be ignored.
        serializableOptionEntries.push([
            'checksumType',
            'FULL_OBJECT'
        ]);
    }
    const serializableOptions = Object.fromEntries(serializableOptionEntries);
    return JSON.stringify(serializableOptions);
};
/**
 * Get the cache key of a multipart upload. Data source cached by different: size, content type, bucket, access level,
 * key. If the data source is a File instance, the upload is additionally indexed by file name and last modified time.
 * So the library always created a new multipart upload if the file is modified.
 */ const getUploadsCacheKey = ({ file, size, contentType, bucket, accessLevel, key, optionsHash })=>{
    let levelStr;
    const resolvedContentType = contentType ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$contentType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getContentType"])(file, key) ?? 'application/octet-stream';
    // If no access level is defined, we're using custom gen2 access rules
    if (accessLevel === undefined) {
        levelStr = 'custom';
    } else {
        levelStr = accessLevel === 'guest' ? 'public' : accessLevel;
    }
    const baseId = `${optionsHash}_${size}_${resolvedContentType}_${bucket}_${levelStr}_${key}`;
    if (file) {
        return `${file.name}_${file.lastModified}_${baseId}`;
    } else {
        return baseId;
    }
};
const cacheMultipartUpload = async (resumableUploadsCache, cacheKey, fileMetadata)=>{
    const cachedUploads = await listCachedUploadTasks(resumableUploadsCache);
    cachedUploads[cacheKey] = {
        ...fileMetadata,
        lastTouched: Date.now()
    };
    await resumableUploadsCache.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UPLOADS_STORAGE_KEY"], JSON.stringify(cachedUploads));
};
const removeCachedUpload = async (resumableUploadsCache, cacheKey)=>{
    const cachedUploads = await listCachedUploadTasks(resumableUploadsCache);
    delete cachedUploads[cacheKey];
    await resumableUploadsCache.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UPLOADS_STORAGE_KEY"], JSON.stringify(cachedUploads));
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/progressTracker.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getConcurrentUploadsProgressTracker",
    ()=>getConcurrentUploadsProgressTracker
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Track the progress from multiple concurrent uploads, and invoke the onProgress callback.
 *
 * @internal
 */ const getConcurrentUploadsProgressTracker = ({ size, onProgress })=>{
    const transferredBytesPerListener = [];
    const getTransferredBytes = ()=>transferredBytesPerListener.reduce((acc, transferredBytes)=>acc + transferredBytes, 0);
    return {
        getOnProgressListener: ()=>{
            transferredBytesPerListener.push(0);
            const listenerIndex = transferredBytesPerListener.length - 1;
            return (event)=>{
                const { transferredBytes } = event;
                transferredBytesPerListener[listenerIndex] = transferredBytes;
                onProgress?.({
                    transferredBytes: getTransferredBytes(),
                    totalBytes: size
                });
            };
        }
    };
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/createMultipartUpload.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createMultipartUpload",
    ()=>createMultipartUpload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/parsePayload.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateObjectUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const createMultipartUploadSerializer = async (input, endpoint)=>{
    const headers = {
        ...await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializeObjectConfigsToHeaders"])(input),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
            'x-amz-checksum-algorithm': input.ChecksumAlgorithm,
            'x-amz-checksum-type': input.ChecksumType,
            'x-amz-expected-bucket-owner': input.ExpectedBucketOwner
        })
    };
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.Key, 'Key');
    url.pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializePathnameObjectKey"])(url, input.Key);
    url.search = 'uploads';
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateObjectUrl"])({
        bucketName: input.Bucket,
        key: input.Key,
        objectURL: url
    });
    return {
        method: 'POST',
        headers,
        url
    };
};
const createMultipartUploadDeserializer = async (response)=>{
    if (response.statusCode >= 300) {
        // error is always set when statusCode >= 300
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response));
    } else {
        const parsed = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlBody"])(response);
        const contents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(parsed, {
            UploadId: 'UploadId'
        });
        return {
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response),
            ...contents
        };
    }
};
const createMultipartUpload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], createMultipartUploadSerializer, createMultipartUploadDeserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'text'
});
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/initialUpload.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadOrCreateMultipartUpload",
    ()=>loadOrCreateMultipartUpload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$createMultipartUpload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/createMultipartUpload.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/logger.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constructContentDisposition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constructContentDisposition.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$crc32$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/crc32.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/uploadCache.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Load the in-progress multipart upload from local storage or async storage(RN) if it exists, or create a new multipart
 * upload.
 *
 * @internal
 */ const loadOrCreateMultipartUpload = async ({ s3Config, data, size, contentType, bucket, accessLevel, keyPrefix, key, contentDisposition, contentEncoding, metadata, abortSignal, checksumAlgorithm, optionsHash, resumableUploadsCache, expectedBucketOwner })=>{
    const finalKey = keyPrefix !== undefined ? keyPrefix + key : key;
    let cachedUpload;
    if (!resumableUploadsCache) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug('uploaded cache instance cannot be determined, skipping cache.');
        cachedUpload = undefined;
    } else {
        const uploadCacheKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUploadsCacheKey"])({
            size,
            contentType,
            file: data instanceof File ? data : undefined,
            bucket,
            accessLevel,
            key,
            optionsHash
        });
        const cachedUploadParts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findCachedUploadPartsAndEvictExpired"])({
            s3Config,
            cacheKey: uploadCacheKey,
            bucket,
            finalKey,
            resumableUploadsCache
        });
        cachedUpload = cachedUploadParts ? {
            ...cachedUploadParts,
            uploadCacheKey
        } : undefined;
    }
    if (cachedUpload) {
        return {
            uploadId: cachedUpload.uploadId,
            cachedParts: cachedUpload.parts,
            finalCrc32: cachedUpload.finalCrc32
        };
    } else {
        /**
         * Note: This step reads the uploading file from beginning to end to calculate the CRC32 checksum of the entire
         * object before sending the 1st byte over the wire. This is a performance bottleneck when uploading large files.
         * The rationale to do this is S3 team wants to reduce the possibility of a file getting corrupted(on disk or in
         * memory). So we calculate the full-object checksum as soon as possible in the upload flow.
         *
         * Going forward we should re-evaluate this decision with S3 team. The alternative is calling calculateContentCRC32()
         * as we upload each part sequentially with seeds from already uploaded parts, ideally inside the data chunker.
         */ const finalCrc32 = checksumAlgorithm === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHECKSUM_ALGORITHM_CRC32"] ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$crc32$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateContentCRC32"])(data) : undefined;
        const { UploadId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$createMultipartUpload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMultipartUpload"])({
            ...s3Config,
            abortSignal
        }, {
            Bucket: bucket,
            Key: finalKey,
            ContentType: contentType,
            ContentDisposition: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constructContentDisposition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructContentDisposition"])(contentDisposition),
            ContentEncoding: contentEncoding,
            Metadata: metadata,
            ChecksumAlgorithm: finalCrc32 ? 'CRC32' : undefined,
            ChecksumType: finalCrc32 ? 'FULL_OBJECT' : undefined,
            ExpectedBucketOwner: expectedBucketOwner
        });
        if (resumableUploadsCache) {
            const uploadCacheKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUploadsCacheKey"])({
                size,
                contentType,
                file: data instanceof File ? data : undefined,
                bucket,
                accessLevel,
                key,
                optionsHash
            });
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cacheMultipartUpload"])(resumableUploadsCache, uploadCacheKey, {
                uploadId: UploadId,
                bucket,
                key,
                finalCrc32,
                fileName: data instanceof File ? data.name : ''
            });
        }
        return {
            uploadId: UploadId,
            cachedParts: [],
            finalCrc32
        };
    }
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/calculatePartSize.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculatePartSize",
    ()=>calculatePartSize
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const calculatePartSize = (totalSize)=>{
    if (!totalSize) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PART_SIZE"];
    }
    let partSize = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PART_SIZE"];
    let partsCount = Math.ceil(totalSize / partSize);
    while(partsCount > __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PARTS_COUNT"]){
        partSize *= 2;
        partsCount = Math.ceil(totalSize / partSize);
    }
    return partSize;
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/getDataChunker.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getDataChunker",
    ()=>getDataChunker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/StorageError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$calculatePartSize$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/calculatePartSize.mjs [app-client] (ecmascript)");
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const getDataChunker = (data, totalSize)=>{
    const partSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$calculatePartSize$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculatePartSize"])(totalSize);
    if (data instanceof Blob) {
        return helper(data, 0, data.size, partSize);
    } else if (ArrayBuffer.isView(data)) {
        return helper(data.buffer, data.byteOffset, data.byteLength, partSize);
    } else if (data instanceof ArrayBuffer) {
        return helper(data, 0, data.byteLength, partSize);
    } else if (typeof data === 'string') {
        const blob = new Blob([
            data
        ]);
        return getDataChunker(blob, blob.size);
    } else {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"]({
            name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].InvalidUploadSource,
            ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validationErrorMap"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].InvalidUploadSource]
        });
    }
};
const helper = function*(buffer, byteOffset, byteLength, partSize) {
    let partNumber = 1;
    let startByte = byteOffset;
    let endByte = byteOffset + Math.min(partSize, byteLength);
    while(endByte < byteLength + byteOffset){
        yield {
            partNumber,
            data: buffer.slice(startByte, endByte),
            size: partSize
        };
        partNumber += 1;
        startByte = endByte;
        endByte = startByte + partSize;
    }
    yield {
        partNumber,
        data: buffer.slice(startByte, byteLength + byteOffset),
        size: byteLength + byteOffset - startByte
    };
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/uploadHandlers.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getMultipartUploadHandlers",
    ()=>getMultipartUploadHandlers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$node_modules$2f40$smithy$2f$md5$2d$js$2f$dist$2d$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/node_modules/@smithy/md5-js/dist-es/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/StorageError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/CanceledError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$completeMultipartUpload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/completeMultipartUpload.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$abortMultipartUpload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/abortMultipartUpload.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$headObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/headObject.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/userAgent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveS3ConfigAndInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/logger.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateStorageOperationInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$crc32$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/crc32.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/IntegrityError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$contentType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/contentType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadPartExecutor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/uploadPartExecutor.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/uploadCache.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$progressTracker$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/progressTracker.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$initialUpload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/initialUpload.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$getDataChunker$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/getDataChunker.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$calculatePartSize$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/calculatePartSize.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Create closure hiding the multipart upload implementation details and expose the upload job and control functions(
 * onPause, onResume, onCancel).
 *
 * @internal
 */ const getMultipartUploadHandlers = (amplify, uploadDataInput, size)=>{
    let resolveCallback;
    let rejectCallback;
    let inProgressUpload;
    let resolvedS3Config;
    let abortController;
    let resolvedAccessLevel;
    let resolvedBucket;
    let resolvedKeyPrefix;
    let resolvedIdentityId;
    let uploadCacheKey;
    let finalKey;
    let expectedBucketOwner;
    // Special flag that differentiates HTTP requests abort error caused by pause() from ones caused by cancel().
    // The former one should NOT cause the upload job to throw, but cancels any pending HTTP requests.
    // This should be replaced by a special abort reason. However,the support of this API is lagged behind.
    let isAbortSignalFromPause = false;
    const { resumableUploadsCache } = uploadDataInput.options ?? {};
    const startUpload = async ()=>{
        const { options: uploadDataOptions, data } = uploadDataInput;
        const resolvedS3Options = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveS3ConfigAndInput"])(amplify, uploadDataInput);
        abortController = new AbortController();
        isAbortSignalFromPause = false;
        resolvedS3Config = resolvedS3Options.s3Config;
        resolvedBucket = resolvedS3Options.bucket;
        resolvedIdentityId = resolvedS3Options.identityId;
        expectedBucketOwner = uploadDataOptions?.expectedBucketOwner;
        const { inputType, objectKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateStorageOperationInput"])(uploadDataInput, resolvedIdentityId);
        const { contentDisposition, contentEncoding, contentType = uploadDataOptions?.contentType ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$contentType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getContentType"])(data, objectKey) ?? 'application/octet-stream', metadata, preventOverwrite, onProgress } = uploadDataOptions ?? {};
        finalKey = objectKey;
        // Resolve "key" specific options
        if (inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"]) {
            const accessLevel = uploadDataOptions?.accessLevel;
            resolvedKeyPrefix = resolvedS3Options.keyPrefix;
            finalKey = resolvedKeyPrefix + objectKey;
            resolvedAccessLevel = resolveAccessLevel(amplify, accessLevel);
        }
        const optionsHash = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$crc32$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateContentCRC32"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializeUploadOptions"])(uploadDataOptions));
        if (!inProgressUpload) {
            const { uploadId, cachedParts, finalCrc32 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$initialUpload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadOrCreateMultipartUpload"])({
                s3Config: resolvedS3Config,
                accessLevel: resolvedAccessLevel,
                bucket: resolvedBucket,
                keyPrefix: resolvedKeyPrefix,
                key: objectKey,
                contentType,
                contentDisposition,
                contentEncoding,
                metadata,
                data,
                size,
                abortSignal: abortController.signal,
                checksumAlgorithm: uploadDataOptions?.checksumAlgorithm,
                optionsHash,
                resumableUploadsCache,
                expectedBucketOwner
            });
            inProgressUpload = {
                uploadId,
                completedParts: cachedParts,
                finalCrc32
            };
        }
        uploadCacheKey = size ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUploadsCacheKey"])({
            file: data instanceof File ? data : undefined,
            accessLevel: resolvedAccessLevel,
            contentType: uploadDataOptions?.contentType,
            bucket: resolvedBucket,
            size,
            key: objectKey,
            optionsHash
        }) : undefined;
        const dataChunker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$getDataChunker$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDataChunker"])(data, size);
        const completedPartNumberSet = new Set(inProgressUpload.completedParts.map(({ PartNumber })=>PartNumber));
        const onPartUploadCompletion = (partNumber, eTag, crc32)=>{
            inProgressUpload?.completedParts.push({
                PartNumber: partNumber,
                ETag: eTag,
                // TODO: crc32 can always be added once RN also has an implementation
                ...crc32 ? {
                    ChecksumCRC32: crc32
                } : {}
            });
        };
        const concurrentUploadsProgressTracker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$progressTracker$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getConcurrentUploadsProgressTracker"])({
            size,
            onProgress
        });
        const concurrentUploadPartExecutors = [];
        for(let index = 0; index < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_QUEUE_SIZE"]; index++){
            concurrentUploadPartExecutors.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadPartExecutor$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadPartExecutor"])({
                dataChunkerGenerator: dataChunker,
                completedPartNumberSet,
                s3Config: resolvedS3Config,
                abortSignal: abortController.signal,
                bucket: resolvedBucket,
                finalKey,
                uploadId: inProgressUpload.uploadId,
                onPartUploadCompletion,
                onProgress: concurrentUploadsProgressTracker.getOnProgressListener(),
                isObjectLockEnabled: resolvedS3Options.isObjectLockEnabled,
                useCRC32Checksum: Boolean(inProgressUpload.finalCrc32),
                expectedBucketOwner
            }));
        }
        await Promise.all(concurrentUploadPartExecutors);
        validateCompletedParts(inProgressUpload.completedParts, size);
        const { ETag: eTag } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$completeMultipartUpload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["completeMultipartUpload"])({
            ...resolvedS3Config,
            abortSignal: abortController.signal,
            userAgentValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageUserAgentValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].UploadData)
        }, {
            Bucket: resolvedBucket,
            Key: finalKey,
            UploadId: inProgressUpload.uploadId,
            ChecksumCRC32: inProgressUpload.finalCrc32,
            ChecksumType: inProgressUpload.finalCrc32 ? 'FULL_OBJECT' : undefined,
            IfNoneMatch: preventOverwrite ? '*' : undefined,
            MultipartUpload: {
                Parts: sortUploadParts(inProgressUpload.completedParts)
            },
            ExpectedBucketOwner: expectedBucketOwner
        });
        // If full-object CRC32 checksum is NOT enabled, we need to ensure the upload integrity by making extra HEAD call
        // to verify the uploaded object size.
        if (!inProgressUpload.finalCrc32) {
            const { ContentLength: uploadedObjectSize, $metadata } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$headObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["headObject"])(resolvedS3Config, {
                Bucket: resolvedBucket,
                Key: finalKey,
                ExpectedBucketOwner: expectedBucketOwner
            });
            if (uploadedObjectSize && uploadedObjectSize !== size) {
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$StorageError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageError"]({
                    name: 'Error',
                    message: `Upload failed. Expected object size ${size}, but got ${uploadedObjectSize}.`,
                    metadata: $metadata
                });
            }
        }
        if (resumableUploadsCache && uploadCacheKey) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeCachedUpload"])(resumableUploadsCache, uploadCacheKey);
        }
        const result = {
            eTag,
            contentType,
            metadata
        };
        return inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"] ? {
            key: objectKey,
            ...result
        } : {
            path: objectKey,
            ...result
        };
    };
    const startUploadWithResumability = ()=>startUpload().then(resolveCallback).catch((error)=>{
            const abortSignal = abortController?.signal;
            if (abortSignal?.aborted && isAbortSignalFromPause) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug('upload paused.');
            } else {
                // Uncaught errors should be exposed to the users.
                rejectCallback(error);
            }
        });
    const multipartUploadJob = ()=>new Promise((resolve, reject)=>{
            resolveCallback = resolve;
            rejectCallback = reject;
            startUploadWithResumability();
        });
    const onPause = ()=>{
        isAbortSignalFromPause = true;
        abortController?.abort();
    };
    const onResume = ()=>{
        startUploadWithResumability();
    };
    const onCancel = (message)=>{
        // 1. abort in-flight API requests
        abortController?.abort(message);
        const cancelUpload = async ()=>{
            // 2. clear upload cache.
            if (uploadCacheKey && resumableUploadsCache) {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadCache$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeCachedUpload"])(resumableUploadsCache, uploadCacheKey);
            }
            // 3. clear multipart upload on server side.
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$abortMultipartUpload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abortMultipartUpload"])(resolvedS3Config, {
                Bucket: resolvedBucket,
                Key: finalKey,
                UploadId: inProgressUpload?.uploadId,
                ExpectedBucketOwner: expectedBucketOwner
            });
        };
        cancelUpload().catch((e)=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug('error when cancelling upload task.', e);
        });
        rejectCallback(// Internal error that should not be exposed to the users. They should use isCancelError() to check if
        // the error is caused by cancel().
        new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CanceledError"](message ? {
            message
        } : undefined));
    };
    return {
        multipartUploadJob,
        onPause,
        onResume,
        onCancel
    };
};
const resolveAccessLevel = (amplify, accessLevel)=>accessLevel ?? amplify.libraryOptions.Storage?.S3?.defaultAccessLevel ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_ACCESS_LEVEL"];
const validateCompletedParts = (completedParts, size)=>{
    const partsExpected = Math.ceil(size / (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$calculatePartSize$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculatePartSize"])(size));
    const validPartCount = completedParts.length === partsExpected;
    const sorted = sortUploadParts(completedParts);
    const validPartNumbers = sorted.every((part, index)=>part.PartNumber === index + 1);
    if (!validPartCount || !validPartNumbers) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IntegrityError"]();
    }
};
const sortUploadParts = (parts)=>{
    return [
        ...parts
    ].sort((partA, partB)=>partA.PartNumber - partB.PartNumber);
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "uploadData",
    ()=>uploadData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$node_modules$2f40$smithy$2f$md5$2d$js$2f$dist$2d$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/node_modules/@smithy/md5-js/dist-es/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/utils/assertValidationError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$transferTask$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/transferTask.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$byteLength$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/byteLength.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$putObjectJob$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/putObjectJob.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadHandlers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/multipart/uploadHandlers.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const uploadData = (amplify, input)=>{
    const { data } = input;
    const dataByteLength = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$byteLength$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["byteLength"])(data);
    // Using InvalidUploadSource error code because the input data must NOT be any
    // of permitted Blob, string, ArrayBuffer(View) if byteLength could not be determined.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(dataByteLength !== undefined, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].InvalidUploadSource);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(dataByteLength <= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_OBJECT_SIZE"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].ObjectIsTooLarge);
    if (dataByteLength <= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PART_SIZE"]) {
        // Single part upload
        const abortController = new AbortController();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$transferTask$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUploadTask"])({
            isMultipartUpload: false,
            job: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$putObjectJob$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putObjectJob"])(amplify, input, abortController.signal, dataByteLength),
            onCancel: (message)=>{
                abortController.abort(message);
            }
        });
    } else {
        // Multipart upload
        const { multipartUploadJob, onPause, onResume, onCancel } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$multipart$2f$uploadHandlers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMultipartUploadHandlers"])(amplify, input, dataByteLength);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$transferTask$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUploadTask"])({
            isMultipartUpload: true,
            job: multipartUploadJob,
            onCancel: (message)=>{
                onCancel(message);
            },
            onPause,
            onResume
        });
    }
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/uploadData.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "uploadData",
    ()=>uploadData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/Amplify.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$storage$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/storage/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/uploadData/index.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function uploadData(input) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$uploadData$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadData"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Amplify"], {
        ...input,
        options: {
            ...input?.options,
            // This option enables caching in-progress multipart uploads.
            // It's ONLY needed for client-side API.
            resumableUploadsCache: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$storage$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["defaultStorage"]
        }
    });
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/getObject.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getObject",
    ()=>getObject,
    "getPresignedGetObjectUrl",
    ()=>getPresignedGetObjectUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$signer$2f$signatureV4$2f$presignUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/signing/signer/signatureV4/presignUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$signer$2f$signatureV4$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/middleware/signing/signer/signatureV4/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateObjectUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const USER_AGENT_HEADER = 'x-amz-user-agent';
const getObjectSerializer = async (input, endpoint)=>{
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.Key, 'Key');
    url.pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializePathnameObjectKey"])(url, input.Key);
    url.search = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrlSearchParams"]({
        'x-id': 'GetObject',
        ...input.ResponseCacheControl && {
            'response-cache-control': input.ResponseCacheControl
        }
    }).toString();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateObjectUrl"])({
        bucketName: input.Bucket,
        key: input.Key,
        objectURL: url
    });
    return {
        method: 'GET',
        headers: {
            ...input.Range && {
                Range: input.Range
            },
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
                'x-amz-expected-bucket-owner': input.ExpectedBucketOwner
            })
        },
        url
    };
};
const getObjectDeserializer = async (response)=>{
    if (response.statusCode >= 300) {
        // error is always set when statusCode >= 300
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response));
    } else {
        return {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(response.headers, {
                DeleteMarker: [
                    'x-amz-delete-marker',
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeBoolean"]
                ],
                AcceptRanges: 'accept-ranges',
                Expiration: 'x-amz-expiration',
                Restore: 'x-amz-restore',
                LastModified: [
                    'last-modified',
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeTimestamp"]
                ],
                ContentLength: [
                    'content-length',
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeNumber"]
                ],
                ETag: 'etag',
                ChecksumCRC32: 'x-amz-checksum-crc32',
                ChecksumCRC32C: 'x-amz-checksum-crc32c',
                ChecksumSHA1: 'x-amz-checksum-sha1',
                ChecksumSHA256: 'x-amz-checksum-sha256',
                ChecksumType: 'x-amz-checksum-type',
                MissingMeta: [
                    'x-amz-missing-meta',
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeNumber"]
                ],
                VersionId: 'x-amz-version-id',
                CacheControl: 'cache-control',
                ContentDisposition: 'content-disposition',
                ContentEncoding: 'content-encoding',
                ContentLanguage: 'content-language',
                ContentRange: 'content-range',
                ContentType: 'content-type',
                Expires: [
                    'expires',
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeTimestamp"]
                ],
                WebsiteRedirectLocation: 'x-amz-website-redirect-location',
                ServerSideEncryption: 'x-amz-server-side-encryption',
                SSECustomerAlgorithm: 'x-amz-server-side-encryption-customer-algorithm',
                SSECustomerKeyMD5: 'x-amz-server-side-encryption-customer-key-md5',
                SSEKMSKeyId: 'x-amz-server-side-encryption-aws-kms-key-id',
                BucketKeyEnabled: [
                    'x-amz-server-side-encryption-bucket-key-enabled',
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeBoolean"]
                ],
                StorageClass: 'x-amz-storage-class',
                RequestCharged: 'x-amz-request-charged',
                ReplicationStatus: 'x-amz-replication-status',
                PartsCount: [
                    'x-amz-mp-parts-count',
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeNumber"]
                ],
                TagCount: [
                    'x-amz-tagging-count',
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeNumber"]
                ],
                ObjectLockMode: 'x-amz-object-lock-mode',
                ObjectLockRetainUntilDate: [
                    'x-amz-object-lock-retain-until-date',
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeTimestamp"]
                ],
                ObjectLockLegalHoldStatus: 'x-amz-object-lock-legal-hold'
            }),
            Metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeMetadata"])(response.headers),
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response),
            // @ts-expect-error The body is a CompatibleHttpResponse type because the lower-level handler is XHR instead of
            // fetch, which represents payload in Blob instread of ReadableStream.
            Body: response.body
        };
    }
};
const getObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], getObjectSerializer, getObjectDeserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'blob'
});
/**
 * Get a presigned URL for the `getObject` API.
 *
 * @internal
 */ const getPresignedGetObjectUrl = async (config, input)=>{
    const endpoint = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"].endpointResolver(config, input);
    const { url, headers, method } = await getObjectSerializer(input, endpoint);
    if (config.userAgentValue) {
        url.searchParams.append(config.userAgentHeader ?? USER_AGENT_HEADER, config.userAgentValue);
    }
    if (input.ResponseContentType) {
        url.searchParams.append('response-content-type', input.ResponseContentType);
    }
    if (input.ResponseContentDisposition) {
        url.searchParams.append('response-content-disposition', input.ResponseContentDisposition);
    }
    for (const [headerName, value] of Object.entries(headers).sort(([key1], [key2])=>key1.localeCompare(key2))){
        url.searchParams.append(headerName, value);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$signer$2f$signatureV4$2f$presignUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["presignUrl"])({
        method,
        url,
        body: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$middleware$2f$signing$2f$signer$2f$signatureV4$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNSIGNED_PAYLOAD"]
    }, {
        signingService: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"].service,
        signingRegion: config.region,
        ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
        ...config
    });
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/getProperties.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getProperties",
    ()=>getProperties
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$node_modules$2f40$smithy$2f$md5$2d$js$2f$dist$2d$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/node_modules/@smithy/md5-js/dist-es/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$headObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/headObject.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/userAgent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveS3ConfigAndInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/logger.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateBucketOwnerID.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateStorageOperationInput.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const getProperties = async (amplify, input, action)=>{
    const { s3Config, bucket, keyPrefix, identityId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveS3ConfigAndInput"])(amplify, input);
    const { inputType, objectKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateStorageOperationInput"])(input, identityId);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateBucketOwnerID"])(input.options?.expectedBucketOwner);
    const finalKey = inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"] ? keyPrefix + objectKey : objectKey;
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`get properties of ${objectKey} from ${finalKey}`);
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$headObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["headObject"])({
        ...s3Config,
        userAgentValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageUserAgentValue"])(action ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].GetProperties)
    }, {
        Bucket: bucket,
        Key: finalKey,
        ExpectedBucketOwner: input.options?.expectedBucketOwner
    });
    const result = {
        contentType: response.ContentType,
        size: response.ContentLength,
        eTag: response.ETag,
        lastModified: response.LastModified,
        metadata: response.Metadata,
        versionId: response.VersionId
    };
    return inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"] ? {
        key: objectKey,
        ...result
    } : {
        path: objectKey,
        ...result
    };
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/getUrl.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getUrl",
    ()=>getUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$getObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/getObject.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$putObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/putObject.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$node_modules$2f40$smithy$2f$md5$2d$js$2f$dist$2d$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/node_modules/@smithy/md5-js/dist-es/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveS3ConfigAndInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/utils/assertValidationError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateBucketOwnerID.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateStorageOperationInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constructContentDisposition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constructContentDisposition.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$getProperties$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/getProperties.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const getUrl = async (amplify, input)=>{
    const { options: getUrlOptions } = input;
    const { s3Config, keyPrefix, bucket, identityId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveS3ConfigAndInput"])(amplify, input);
    const { inputType, objectKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateStorageOperationInput"])(input, identityId);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateBucketOwnerID"])(getUrlOptions?.expectedBucketOwner);
    const finalKey = inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"] ? keyPrefix + objectKey : objectKey;
    const operation = getUrlOptions?.method ?? 'GET';
    if (getUrlOptions?.validateObjectExistence && getUrlOptions?.method !== 'PUT') {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$getProperties$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProperties"])(amplify, input, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].GetUrl);
    }
    let urlExpirationInSec = getUrlOptions?.expiresIn ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PRESIGN_EXPIRATION"];
    const resolvedCredential = typeof s3Config.credentials === 'function' ? await s3Config.credentials() : s3Config.credentials;
    const awsCredExpiration = resolvedCredential.expiration;
    if (awsCredExpiration) {
        const awsCredExpirationInSec = Math.floor((awsCredExpiration.getTime() - Date.now()) / 1000);
        urlExpirationInSec = Math.min(awsCredExpirationInSec, urlExpirationInSec);
    }
    const maxUrlExpirationInSec = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_URL_EXPIRATION"] / 1000;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(urlExpirationInSec <= maxUrlExpirationInSec, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].UrlExpirationMaxLimitExceed);
    if (operation === 'PUT') {
        return {
            url: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$putObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPresignedPutObjectUrl"])({
                ...s3Config,
                credentials: resolvedCredential,
                expiration: urlExpirationInSec
            }, {
                Bucket: bucket,
                Key: finalKey,
                ...getUrlOptions?.contentType && {
                    ContentType: getUrlOptions.contentType
                },
                ...getUrlOptions?.contentDisposition && {
                    ContentDisposition: typeof getUrlOptions.contentDisposition === 'string' ? getUrlOptions.contentDisposition : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constructContentDisposition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructContentDisposition"])(getUrlOptions.contentDisposition)
                },
                CacheControl: getUrlOptions?.cacheControl,
                ExpectedBucketOwner: getUrlOptions?.expectedBucketOwner
            }),
            expiresAt: new Date(Date.now() + urlExpirationInSec * 1000)
        };
    }
    return {
        url: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$getObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPresignedGetObjectUrl"])({
            ...s3Config,
            credentials: resolvedCredential,
            expiration: urlExpirationInSec
        }, {
            Bucket: bucket,
            Key: finalKey,
            ...getUrlOptions?.contentDisposition && {
                ResponseContentDisposition: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constructContentDisposition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructContentDisposition"])(getUrlOptions.contentDisposition)
            },
            ...getUrlOptions?.contentType && {
                ResponseContentType: getUrlOptions.contentType
            },
            ResponseCacheControl: getUrlOptions?.cacheControl,
            ExpectedBucketOwner: getUrlOptions?.expectedBucketOwner
        }),
        expiresAt: new Date(Date.now() + urlExpirationInSec * 1000)
    };
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/getUrl.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getUrl",
    ()=>getUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/Amplify.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$getUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/getUrl.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function getUrl(input) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$getUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUrl"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Amplify"], input);
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/downloadData.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "downloadData",
    ()=>downloadData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/Amplify.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveS3ConfigAndInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$node_modules$2f40$smithy$2f$md5$2d$js$2f$dist$2d$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/node_modules/@smithy/md5-js/dist-es/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$getObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/getObject.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/userAgent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$transferTask$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/transferTask.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateBucketOwnerID.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateStorageOperationInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/logger.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const downloadData = (input)=>{
    const abortController = new AbortController();
    const downloadTask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$transferTask$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDownloadTask"])({
        job: downloadDataJob(input, abortController.signal),
        onCancel: (message)=>{
            abortController.abort(message);
        }
    });
    return downloadTask;
};
const downloadDataJob = (downloadDataInput, abortSignal)=>async ()=>{
        const { options: downloadDataOptions } = downloadDataInput;
        const { bucket, keyPrefix, s3Config, identityId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveS3ConfigAndInput"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Amplify"], downloadDataInput);
        const { inputType, objectKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateStorageOperationInput"])(downloadDataInput, identityId);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateBucketOwnerID"])(downloadDataOptions?.expectedBucketOwner);
        const finalKey = inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"] ? keyPrefix + objectKey : objectKey;
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`download ${objectKey} from ${finalKey}.`);
        const { Body: body, LastModified: lastModified, ContentLength: size, ETag: eTag, Metadata: metadata, VersionId: versionId, ContentType: contentType } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$getObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getObject"])({
            ...s3Config,
            abortSignal,
            onDownloadProgress: downloadDataOptions?.onProgress,
            userAgentValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageUserAgentValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].DownloadData)
        }, {
            Bucket: bucket,
            Key: finalKey,
            ...downloadDataOptions?.bytesRange && {
                Range: `bytes=${downloadDataOptions.bytesRange.start}-${downloadDataOptions.bytesRange.end}`
            },
            ResponseCacheControl: downloadDataOptions?.cacheControl,
            ExpectedBucketOwner: downloadDataOptions?.expectedBucketOwner
        });
        const result = {
            body,
            lastModified,
            size,
            contentType,
            eTag,
            metadata,
            versionId
        };
        return inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"] ? {
            key: objectKey,
            ...result
        } : {
            path: objectKey,
            ...result
        };
    };
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/downloadData.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "downloadData",
    ()=>downloadData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/downloadData.mjs [app-client] (ecmascript)");
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function downloadData(input) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$downloadData$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadData"])(input);
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/listObjectsV2.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "listObjectsV2",
    ()=>listObjectsV2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/parsePayload.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/IntegrityError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const listObjectsV2Serializer = (input, endpoint)=>{
    const headers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
        'x-amz-request-payer': input.RequestPayer,
        'x-amz-expected-bucket-owner': input.ExpectedBucketOwner
    });
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
        'list-type': '2',
        'continuation-token': input.ContinuationToken,
        delimiter: input.Delimiter,
        'encoding-type': input.EncodingType,
        'fetch-owner': input.FetchOwner,
        'max-keys': input.MaxKeys,
        prefix: input.Prefix,
        'start-after': input.StartAfter
    });
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    url.search = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrlSearchParams"](query).toString();
    return {
        method: 'GET',
        headers,
        url
    };
};
const listObjectsV2Deserializer = async (response)=>{
    if (response.statusCode >= 300) {
        // error is always set when statusCode >= 300
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response));
    } else {
        const parsed = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$parsePayload$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlBody"])(response);
        const contents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(parsed, {
            CommonPrefixes: [
                'CommonPrefixes',
                (value)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptyArrayGuard"])(value, deserializeCommonPrefixList)
            ],
            Contents: [
                'Contents',
                (value)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptyArrayGuard"])(value, deserializeObjectList)
            ],
            ContinuationToken: 'ContinuationToken',
            Delimiter: 'Delimiter',
            EncodingType: [
                'EncodingType',
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeStringTag"]
            ],
            IsTruncated: [
                'IsTruncated',
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeBoolean"]
            ],
            KeyCount: [
                'KeyCount',
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeNumber"]
            ],
            MaxKeys: [
                'MaxKeys',
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeNumber"]
            ],
            Name: 'Name',
            NextContinuationToken: 'NextContinuationToken',
            Prefix: 'Prefix',
            StartAfter: 'StartAfter'
        });
        const output = {
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response),
            ...contents
        };
        validateCorroboratingElements(output);
        return output;
    }
};
const deserializeCommonPrefixList = (output)=>output.map(deserializeCommonPrefix);
const deserializeCommonPrefix = (output)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(output, {
        Prefix: 'Prefix'
    });
const deserializeObjectList = (output)=>output.map(deserializeObject);
const deserializeObject = (output)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(output, {
        Key: 'Key',
        LastModified: [
            'LastModified',
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeTimestamp"]
        ],
        ETag: 'ETag',
        ChecksumAlgorithm: [
            'ChecksumAlgorithm',
            (value)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptyArrayGuard"])(value, deserializeChecksumAlgorithmList)
        ],
        ChecksumType: [
            'ChecksumType',
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeStringTag"]
        ],
        Size: [
            'Size',
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeNumber"]
        ],
        StorageClass: [
            'StorageClass',
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeStringTag"]
        ],
        Owner: [
            'Owner',
            deserializeOwner
        ]
    });
const deserializeChecksumAlgorithmList = (output)=>output.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeStringTag"]);
const deserializeOwner = (output)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(output, {
        DisplayName: 'DisplayName',
        ID: 'ID'
    });
const validateCorroboratingElements = (response)=>{
    const { IsTruncated, KeyCount, Contents = [], CommonPrefixes = [], NextContinuationToken } = response;
    const validTruncation = IsTruncated && !!NextContinuationToken || !IsTruncated && !NextContinuationToken;
    const validNumberOfKeysReturned = KeyCount === Contents.length + CommonPrefixes.length;
    if (!validTruncation || !validNumberOfKeysReturned) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IntegrityError"]({
            metadata: response.$metadata
        });
    }
};
const listObjectsV2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], listObjectsV2Serializer, listObjectsV2Deserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'text'
});
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateStorageOperationInputWithPrefix.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "validateStorageOperationInputWithPrefix",
    ()=>validateStorageOperationInputWithPrefix
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/utils/assertValidationError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/types/validation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveIdentityId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveIdentityId.mjs [app-client] (ecmascript)");
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
// Local assertion function with StorageOperationInputWithPrefixPath as Input
const _isInputWithPath = (input)=>{
    return input.path !== undefined;
};
const validateStorageOperationInputWithPrefix = (input, identityId)=>{
    // Validate prefix & path not present at the same time
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!(input.prefix && input.path), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].InvalidStorageOperationPrefixInput);
    if (_isInputWithPath(input)) {
        const { path } = input;
        const objectKey = typeof path === 'string' ? path : path({
            identityId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveIdentityId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveIdentityId"])(identityId)
        });
        // Assert on no leading slash in the path parameter
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$utils$2f$assertValidationError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertValidationError"])(!objectKey.startsWith('/'), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$types$2f$validation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageValidationErrorCode"].InvalidStoragePathInput);
        return {
            inputType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_PATH"],
            objectKey
        };
    } else {
        return {
            inputType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_PREFIX"],
            objectKey: input.prefix ?? ''
        };
    }
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/urlDecoder.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "urlDecode",
    ()=>urlDecode
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Decodes a URL-encoded string by replacing '+' characters with spaces and applying `decodeURIComponent`.
 * Reference:
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/decodeURIComponent#decoding_query_parameters_from_a_url
 * @param {string} value - The URL-encoded string to decode.
 * @returns {string} The decoded string.
 */ const urlDecode = (value)=>{
    return decodeURIComponent(value.replace(/\+/g, ' '));
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/list.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "list",
    ()=>list
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$node_modules$2f40$smithy$2f$md5$2d$js$2f$dist$2d$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/node_modules/@smithy/md5-js/dist-es/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$listObjectsV2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/listObjectsV2.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/userAgent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveS3ConfigAndInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/utils/logger.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateBucketOwnerID.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInputWithPrefix$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateStorageOperationInputWithPrefix.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$urlDecoder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/urlDecoder.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/IntegrityError.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const MAX_PAGE_SIZE = 1000;
const list = async (amplify, input)=>{
    const { options = {} } = input;
    const { s3Config, bucket, keyPrefix: generatedPrefix, identityId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveS3ConfigAndInput"])(amplify, input);
    const { inputType, objectKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInputWithPrefix$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateStorageOperationInputWithPrefix"])(input, identityId);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateBucketOwnerID"])(options.expectedBucketOwner);
    const isInputWithPrefix = inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_PREFIX"];
    // @ts-expect-error pageSize and nextToken should not coexist with listAll
    if (options?.listAll && (options?.pageSize || options?.nextToken)) {
        const anyOptions = options;
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`listAll is set to true, ignoring ${anyOptions?.pageSize ? `pageSize: ${anyOptions?.pageSize}` : ''} ${anyOptions?.nextToken ? `nextToken: ${anyOptions?.nextToken}` : ''}.`);
    }
    const listParams = {
        Bucket: bucket,
        Prefix: isInputWithPrefix ? `${generatedPrefix}${objectKey}` : objectKey,
        MaxKeys: options?.listAll ? undefined : options?.pageSize,
        ContinuationToken: options?.listAll ? undefined : options?.nextToken,
        Delimiter: getDelimiter(options),
        ExpectedBucketOwner: options?.expectedBucketOwner,
        EncodingType: 'url'
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`listing items from "${listParams.Prefix}"`);
    const listInputArgs = {
        s3Config,
        listParams
    };
    if (options.listAll) {
        if (isInputWithPrefix) {
            return _listAllWithPrefix({
                ...listInputArgs,
                generatedPrefix
            });
        } else {
            return _listAllWithPath(listInputArgs);
        }
    } else {
        if (isInputWithPrefix) {
            return _listWithPrefix({
                ...listInputArgs,
                generatedPrefix
            });
        } else {
            return _listWithPath(listInputArgs);
        }
    }
};
/** @deprecated Use {@link _listAllWithPath} instead. */ const _listAllWithPrefix = async ({ s3Config, listParams, generatedPrefix })=>{
    const listResult = [];
    let continuationToken = listParams.ContinuationToken;
    do {
        const { items: pageResults, nextToken: pageNextToken } = await _listWithPrefix({
            generatedPrefix,
            s3Config,
            listParams: {
                ...listParams,
                ContinuationToken: continuationToken,
                MaxKeys: MAX_PAGE_SIZE
            }
        });
        listResult.push(...pageResults);
        continuationToken = pageNextToken;
    }while (continuationToken)
    return {
        items: listResult
    };
};
/** @deprecated Use {@link _listWithPath} instead. */ const _listWithPrefix = async ({ s3Config, listParams, generatedPrefix })=>{
    const listParamsClone = {
        ...listParams
    };
    if (!listParamsClone.MaxKeys || listParamsClone.MaxKeys > MAX_PAGE_SIZE) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`defaulting pageSize to ${MAX_PAGE_SIZE}.`);
        listParamsClone.MaxKeys = MAX_PAGE_SIZE;
    }
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$listObjectsV2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["listObjectsV2"])({
        ...s3Config,
        userAgentValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageUserAgentValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].List)
    }, listParamsClone);
    const listOutput = decodeEncodedElements(response);
    validateEchoedElements(listParamsClone, listOutput);
    if (!listOutput?.Contents) {
        return {
            items: []
        };
    }
    return {
        items: listOutput.Contents.map((item)=>({
                key: generatedPrefix ? item.Key.substring(generatedPrefix.length) : item.Key,
                eTag: item.ETag,
                lastModified: item.LastModified,
                size: item.Size
            })),
        nextToken: listOutput.NextContinuationToken
    };
};
const _listAllWithPath = async ({ s3Config, listParams })=>{
    const listResult = [];
    const excludedSubpaths = [];
    let continuationToken = listParams.ContinuationToken;
    do {
        const { items: pageResults, excludedSubpaths: pageExcludedSubpaths, nextToken: pageNextToken } = await _listWithPath({
            s3Config,
            listParams: {
                ...listParams,
                ContinuationToken: continuationToken,
                MaxKeys: MAX_PAGE_SIZE
            }
        });
        listResult.push(...pageResults);
        excludedSubpaths.push(...pageExcludedSubpaths ?? []);
        continuationToken = pageNextToken;
    }while (continuationToken)
    return {
        items: listResult,
        excludedSubpaths
    };
};
const _listWithPath = async ({ s3Config, listParams })=>{
    const listParamsClone = {
        ...listParams
    };
    if (!listParamsClone.MaxKeys || listParamsClone.MaxKeys > MAX_PAGE_SIZE) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$utils$2f$logger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].debug(`defaulting pageSize to ${MAX_PAGE_SIZE}.`);
        listParamsClone.MaxKeys = MAX_PAGE_SIZE;
    }
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$listObjectsV2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["listObjectsV2"])({
        ...s3Config,
        userAgentValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageUserAgentValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].List)
    }, listParamsClone);
    const listOutput = decodeEncodedElements(response);
    validateEchoedElements(listParamsClone, listOutput);
    const { Contents: contents, NextContinuationToken: nextContinuationToken, CommonPrefixes: commonPrefixes } = listOutput;
    const excludedSubpaths = commonPrefixes && mapCommonPrefixesToExcludedSubpaths(commonPrefixes);
    if (!contents) {
        return {
            items: [],
            nextToken: nextContinuationToken,
            excludedSubpaths
        };
    }
    return {
        items: contents.map((item)=>({
                path: item.Key,
                eTag: item.ETag,
                lastModified: item.LastModified,
                size: item.Size
            })),
        nextToken: nextContinuationToken,
        excludedSubpaths
    };
};
const mapCommonPrefixesToExcludedSubpaths = (commonPrefixes)=>{
    return commonPrefixes.reduce((mappedSubpaths, { Prefix })=>{
        if (Prefix) {
            mappedSubpaths.push(Prefix);
        }
        return mappedSubpaths;
    }, []);
};
const getDelimiter = (options)=>{
    if (options?.subpathStrategy?.strategy === 'exclude') {
        return options?.subpathStrategy?.delimiter ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_DELIMITER"];
    }
};
const validateEchoedElements = (listInput, listOutput)=>{
    const validEchoedParameters = listInput.Bucket === listOutput.Name && listInput.Delimiter === listOutput.Delimiter && listInput.MaxKeys === listOutput.MaxKeys && listInput.Prefix === listOutput.Prefix && listInput.ContinuationToken === listOutput.ContinuationToken;
    if (!validEchoedParameters) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$IntegrityError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IntegrityError"]({
            metadata: listOutput.$metadata
        });
    }
};
/**
 * Decodes URL-encoded elements in the S3 `ListObjectsV2Output` response when `EncodingType` is `'url'`.
 * Applies to values for 'Delimiter', 'Prefix', 'StartAfter' and 'Key' in the response.
 */ const decodeEncodedElements = (listOutput)=>{
    if (listOutput.EncodingType !== 'url') {
        return listOutput;
    }
    const decodedListOutput = {
        ...listOutput
    };
    // Decode top-level properties
    [
        'Delimiter',
        'Prefix',
        'StartAfter'
    ].forEach((prop)=>{
        const value = listOutput[prop];
        if (typeof value === 'string') {
            decodedListOutput[prop] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$urlDecoder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlDecode"])(value);
        }
    });
    // Decode 'Key' in each item of 'Contents', if it exists
    if (listOutput.Contents) {
        decodedListOutput.Contents = listOutput.Contents.map((content)=>({
                ...content,
                Key: content.Key ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$urlDecoder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlDecode"])(content.Key) : content.Key
            }));
    }
    // Decode 'Prefix' in each item of 'CommonPrefixes', if it exists
    if (listOutput.CommonPrefixes) {
        decodedListOutput.CommonPrefixes = listOutput.CommonPrefixes.map((content)=>({
                ...content,
                Prefix: content.Prefix ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$urlDecoder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlDecode"])(content.Prefix) : content.Prefix
            }));
    }
    return decodedListOutput;
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/list.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "list",
    ()=>list
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/Amplify.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/list.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function list(input) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["list"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Amplify"], input ?? {});
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/generateDeleteObjectsXml.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateDeleteObjectsXml",
    ()=>generateDeleteObjectsXml
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Escapes special XML characters in a string
 * @param str - String to escape
 * @returns XML-escaped string
 */ const escapeXml = (str)=>{
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
};
/**
 * Generates XML for S3 batch delete operations
 *
 * @param objects - Array of objects to delete with their keys
 * @param quiet - Whether to use quiet mode (default: true)
 * @returns XML string for the delete request
 */ const generateDeleteObjectsXml = (objects, quiet)=>{
    const objectsXml = objects.map((obj)=>`<Object><Key>${escapeXml(obj.Key)}</Key></Object>`).join('');
    return `<?xml version="1.0" encoding="UTF-8"?>
<Delete xmlns="http://s3.amazonaws.com/doc/2006-03-01/">
	<Quiet>${quiet ? 'true' : 'false'}</Quiet>
	${objectsXml}
</Delete>`;
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/deleteObjects.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteObjects",
    ()=>deleteObjects
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$generateDeleteObjectsXml$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/generateDeleteObjectsXml.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$md5$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/md5.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const deleteObjectsSerializer = async (input, endpoint)=>{
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.Delete, 'Delete');
    url.pathname = '/';
    url.search = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrlSearchParams"]({
        delete: ''
    }).toString();
    const body = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$generateDeleteObjectsXml$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateDeleteObjectsXml"])(input.Delete.Objects, input.Delete.Quiet ?? false);
    const contentMd5 = input.ContentMD5 ?? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$md5$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateContentMd5"])(body);
    const headers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
        'x-amz-expected-bucket-owner': input.ExpectedBucketOwner,
        'content-type': 'application/xml',
        'content-md5': contentMd5
    });
    const request = {
        method: 'POST',
        headers,
        url,
        body
    };
    return request;
};
const deleteObjectsDeserializer = async (response)=>{
    if (response.statusCode >= 300) {
        const error = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response);
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(error);
    }
    const text = await response.body.text();
    const deleted = [];
    const errors = [];
    const deletedMatches = text.matchAll(/<Deleted>[\s\S]*?<\/Deleted>/g);
    for (const match of deletedMatches){
        const keyMatch = match[0].match(/<Key>(.*?)<\/Key>/);
        if (keyMatch) {
            deleted.push({
                Key: keyMatch[1]
            });
        }
    }
    const errorMatches = text.matchAll(/<Error>[\s\S]*?<\/Error>/g);
    for (const match of errorMatches){
        const keyMatch = match[0].match(/<Key>(.*?)<\/Key>/);
        const codeMatch = match[0].match(/<Code>(.*?)<\/Code>/);
        const messageMatch = match[0].match(/<Message>(.*?)<\/Message>/);
        errors.push({
            Key: keyMatch?.[1],
            Code: codeMatch?.[1],
            Message: messageMatch?.[1]
        });
    }
    const result = {
        Deleted: deleted,
        Errors: errors,
        $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response)
    };
    return result;
};
const deleteObjects = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], deleteObjectsSerializer, deleteObjectsDeserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'text'
});
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/deleteFolderContents.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteFolderContents",
    ()=>deleteFolderContents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/CanceledError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$listObjectsV2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/listObjectsV2.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$deleteObjects$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/deleteObjects.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/userAgent.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const MAX_KEYS_PER_BATCH = 1000;
/**
 * Deletes all contents of a folder in S3 using batch operations
 *
 * @param params - Configuration object for the delete operation
 * @returns Promise that resolves to the removal result
 */ const deleteFolderContents = async (params)=>{
    const { s3Config, bucket, folderKey, expectedBucketOwner, onProgress, abortSignal } = params;
    try {
        const prefix = folderKey.endsWith('/') ? folderKey : `${folderKey}/`;
        const progressCallback = onProgress ?? (()=>{
        // no-op
        });
        let continuationToken;
        do {
            if (abortSignal?.aborted) {
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CanceledError"]({
                    message: 'Operation was canceled'
                });
            }
            const listResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$listObjectsV2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["listObjectsV2"])({
                ...s3Config,
                userAgentValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageUserAgentValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].Remove),
                abortSignal
            }, {
                Bucket: bucket,
                Prefix: prefix,
                MaxKeys: MAX_KEYS_PER_BATCH,
                ContinuationToken: continuationToken,
                ExpectedBucketOwner: expectedBucketOwner
            });
            if (!listResult.Contents || listResult.Contents.length === 0) {
                break;
            }
            if (abortSignal?.aborted) {
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CanceledError"]({
                    message: 'Operation was canceled'
                });
            }
            const batch = listResult.Contents.map((obj)=>({
                    Key: obj.Key
                }));
            const deleteResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$deleteObjects$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteObjects"])({
                ...s3Config,
                userAgentValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageUserAgentValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].Remove),
                abortSignal
            }, {
                Bucket: bucket,
                Delete: {
                    Objects: batch,
                    Quiet: false
                },
                ExpectedBucketOwner: expectedBucketOwner
            });
            const deleted = deleteResult.Deleted?.map((obj)=>({
                    path: obj.Key
                })) || [];
            const failed = deleteResult.Errors?.map((err)=>({
                    path: err.Key,
                    code: err.Code,
                    message: err.Message
                })) || [];
            progressCallback({
                deleted,
                failed
            });
            continuationToken = listResult.NextContinuationToken;
        }while (continuationToken)
        return {
            path: folderKey
        };
    } catch (error) {
        if (abortSignal?.aborted) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CanceledError"]({
                message: 'Operation was canceled'
            });
        }
        throw error;
    }
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveFinalKey.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resolveFinalKey",
    ()=>resolveFinalKey
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Resolves the final S3 key based on input type and key prefix.
 *
 * @param inputType - The type of input (key-based or path-based)
 * @param objectKey - The object key from the input
 * @param keyPrefix - The key prefix to prepend for key-based inputs
 * @returns The final S3 key to use for the operation
 */ const resolveFinalKey = (inputType, objectKey, keyPrefix)=>{
    return inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"] ? `${keyPrefix}${objectKey}` : objectKey;
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateRemovePath.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "validateRemovePath",
    ()=>validateRemovePath
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Validates that the path is safe for removal operations.
 * Prevents deletion of dangerous paths that could affect entire buckets.
 *
 * @param path - The path to validate
 * @throws Error if the path is considered dangerous
 */ const validateRemovePath = (path)=>{
    const DANGEROUS_PATHS = [
        '',
        '/',
        '*'
    ];
    if (DANGEROUS_PATHS.includes(path.trim())) {
        throw new Error('Cannot delete root or bucket-wide paths');
    }
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/isPathFolder.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isPathFolder",
    ()=>isPathFolder
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$listObjectsV2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/listObjectsV2.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/userAgent.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Determines if a given S3 key represents a folder by checking if objects exist with that prefix.
 *
 * @param params - Configuration object for the folder check
 * @returns Promise that resolves to true if the key represents a folder, false otherwise
 */ const isPathFolder = async (params)=>{
    const { s3Config, bucket, key, expectedBucketOwner } = params;
    try {
        const prefix = key.endsWith('/') ? key : `${key}/`;
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$listObjectsV2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["listObjectsV2"])({
            ...s3Config,
            userAgentValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageUserAgentValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].Remove)
        }, {
            Bucket: bucket,
            Prefix: prefix,
            MaxKeys: 1,
            ExpectedBucketOwner: expectedBucketOwner
        });
        const isFolder = !!(result.Contents && result.Contents.length > 0) || !!(result.CommonPrefixes && result.CommonPrefixes.length > 0);
        return isFolder;
    } catch (error) {
        return false;
    }
};
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/createAbortableTask.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createAbortableTask",
    ()=>createAbortableTask
]);
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function createAbortableTask(executor) {
    const abortController = new AbortController();
    let state = 'IN_PROGRESS';
    const resultPromise = executor(abortController);
    const wrappedPromise = resultPromise.then((result)=>{
        state = 'SUCCESS';
        return result;
    }).catch((error)=>{
        state = abortController.signal.aborted ? 'CANCELED' : 'ERROR';
        throw error;
    });
    const operation = {
        result: wrappedPromise,
        cancel: ()=>{
            abortController.abort();
            state = 'CANCELED';
        },
        get state () {
            return state;
        },
        then: wrappedPromise.then.bind(wrappedPromise),
        catch: wrappedPromise.catch.bind(wrappedPromise),
        finally: wrappedPromise.finally.bind(wrappedPromise)
    };
    return operation;
}
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/deleteObject.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteObject",
    ()=>deleteObject
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/serde/responseInfo.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/utils/amplifyUrl/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/clients/internal/composeServiceApi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/runtime/s3TransferHandler/xhr.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/deserializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/utils/serializeHelpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateObjectUrl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/base.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const deleteObjectSerializer = (input, endpoint)=>{
    const url = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrl"](endpoint.url.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateS3RequiredParameter"])(!!input.Key, 'Key');
    url.pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializePathnameObjectKey"])(url, input.Key);
    url.search = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$utils$2f$amplifyUrl$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplifyUrlSearchParams"]({
        'x-id': 'DeleteObject'
    }).toString();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateObjectUrl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateObjectUrl"])({
        bucketName: input.Bucket,
        key: input.Key,
        objectURL: url
    });
    const headers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$serializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignStringVariables"])({
        'x-amz-expected-bucket-owner': input.ExpectedBucketOwner
    });
    return {
        method: 'DELETE',
        headers,
        url
    };
};
const deleteObjectDeserializer = async (response)=>{
    if (response.statusCode >= 300) {
        // error is always set when statusCode >= 300
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildStorageServiceError"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseXmlError"])(response));
    } else {
        const content = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(response.headers, {
            DeleteMarker: [
                'x-amz-delete-marker',
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeBoolean"]
            ],
            VersionId: 'x-amz-version-id',
            RequestCharged: [
                'x-amz-request-charged',
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$utils$2f$deserializeHelpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deserializeStringTag"]
            ]
        });
        return {
            ...content,
            $metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$serde$2f$responseInfo$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseMetadata"])(response)
        };
    }
};
const deleteObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$clients$2f$internal$2f$composeServiceApi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeServiceApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$runtime$2f$s3TransferHandler$2f$xhr$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["s3TransferHandler"], deleteObjectSerializer, deleteObjectDeserializer, {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$base$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultConfig"],
    responseType: 'text'
});
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/remove.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "remove",
    ()=>remove
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/Platform/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$node_modules$2f40$smithy$2f$md5$2d$js$2f$dist$2d$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/node_modules/@smithy/md5-js/dist-es/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$deleteFolderContents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/deleteFolderContents.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveS3ConfigAndInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveFinalKey$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/resolveFinalKey.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/errors/CanceledError.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateBucketOwnerID.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateRemovePath$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateRemovePath.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/validateStorageOperationInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$isPathFolder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/isPathFolder.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$createAbortableTask$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/createAbortableTask.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$deleteObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/client/s3data/deleteObject.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/utils/userAgent.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function remove(amplify, input) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$createAbortableTask$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAbortableTask"])(executeRemove(amplify, input));
}
const executeRemove = (amplify, input)=>async (abortController)=>{
        try {
            const { s3Config, keyPrefix, bucket, identityId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveS3ConfigAndInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveS3ConfigAndInput"])(amplify, input);
            const { inputType, objectKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateStorageOperationInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateStorageOperationInput"])(input, identityId);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateBucketOwnerID$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateBucketOwnerID"])(input.options?.expectedBucketOwner);
            const finalKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$resolveFinalKey$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveFinalKey"])(inputType, objectKey, keyPrefix);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$validateRemovePath$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateRemovePath"])(finalKey);
            const isFolder = finalKey.endsWith('/') || await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$isPathFolder$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPathFolder"])({
                s3Config,
                bucket,
                key: finalKey,
                expectedBucketOwner: input.options?.expectedBucketOwner
            });
            if (isFolder) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$deleteFolderContents$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteFolderContents"])({
                    s3Config,
                    bucket,
                    folderKey: finalKey,
                    expectedBucketOwner: input.options?.expectedBucketOwner,
                    onProgress: input.options?.onProgress,
                    abortSignal: abortController.signal
                });
            } else {
                if (abortController.signal.aborted) {
                    throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CanceledError"]({
                        message: 'Operation was cancelled'
                    });
                }
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$client$2f$s3data$2f$deleteObject$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteObject"])({
                    ...s3Config,
                    userAgentValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$userAgent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageUserAgentValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$Platform$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageAction"].Remove),
                    abortSignal: abortController.signal
                }, {
                    Bucket: bucket,
                    Key: finalKey,
                    ExpectedBucketOwner: input.options?.expectedBucketOwner
                });
                const result = inputType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$utils$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_INPUT_KEY"] ? {
                    key: objectKey
                } : {
                    path: objectKey
                };
                return result;
            }
        } catch (error) {
            if (abortController.signal.aborted) {
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$errors$2f$CanceledError$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CanceledError"]({
                    message: 'Operation was cancelled'
                });
            }
            throw error;
        }
    };
;
}),
"[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/remove.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "remove",
    ()=>remove
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/core/dist/esm/singleton/Amplify.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@aws-amplify/storage/dist/esm/providers/s3/apis/internal/remove.mjs [app-client] (ecmascript)");
;
;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
function remove(input) {
    if ('key' in input) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["remove"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Amplify"], input);
    } else {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$storage$2f$dist$2f$esm$2f$providers$2f$s3$2f$apis$2f$internal$2f$remove$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["remove"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$aws$2d$amplify$2f$core$2f$dist$2f$esm$2f$singleton$2f$Amplify$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Amplify"], input);
    }
}
;
}),
]);

//# sourceMappingURL=node_modules_%40aws-amplify_storage_dist_esm_0f264bj._.js.map