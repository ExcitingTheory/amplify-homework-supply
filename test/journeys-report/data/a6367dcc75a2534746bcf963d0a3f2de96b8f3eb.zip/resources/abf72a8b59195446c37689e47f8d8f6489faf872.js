(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_02n97_-._.js","static/chunks/node_modules_@mui_icons-material_esm_1t4g4fl._.js"],
    source: "dynamic"
});
